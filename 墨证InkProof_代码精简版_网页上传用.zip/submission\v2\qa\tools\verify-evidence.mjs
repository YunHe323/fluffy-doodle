#!/usr/bin/env node
// v2/qa/tools/verify-evidence.mjs —— 第三方证据包复核（零依赖）
// 用法：node v2/qa/tools/verify-evidence.mjs <inkproof-evidence.json>
// 也可 import { verifyEvidence } 在测试/CI 中使用。
import { promises as fsp } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { sha256Hex, canonicalJson, GENESIS_HASH } from '../../app/core/hash-chain.mjs';

const AI_LAYERS = new Set(['L6']);

export async function verifyEvidence(pkg) {
  const checks = {};
  const errors = [];
  const fail = (id, msg) => { checks[id] = false; errors.push(id + ': ' + msg); };
  const ok = (id) => { checks[id] = true; };

  if (!pkg || typeof pkg !== 'object') { fail('schema', '不是对象'); return { ok: false, checks, errors }; }
  if (pkg.schema !== 'inkproof.evidence.v1') fail('schema', 'schema 不是 inkproof.evidence.v1'); else ok('schema');

  const m = pkg.manifest || {};
  const events = Array.isArray(pkg.events) ? pkg.events : [];
  const genesis = m.genesis_hash || GENESIS_HASH;
  if (genesis !== GENESIS_HASH) fail('genesis', '创世哈希不是 64 个 0'); else ok('genesis');
  if (Number(m.event_count) !== events.length) fail('eventCount', 'manifest.event_count 与 events 数量不一致'); else ok('eventCount');

  let prev = genesis;
  let chainOk = true;
  for (let i = 0; i < events.length; i += 1) {
    const e = events[i] || {};
    if (e.chain_prev !== prev) { fail('chainSeq', `事件 ${i} chain_prev 不匹配`); chainOk = false; break; }
    const rec = { ...e };
    delete rec.chain_prev;
    delete rec.chain_hash;
    let expected;
    try { expected = await sha256Hex(prev + canonicalJson(rec)); } catch (err) { fail('chainHash', '事件 ' + i + ' 无法规范化: ' + err.message); chainOk = false; break; }
    if (expected !== e.chain_hash) { fail('chainHash', `事件 ${i} 链哈希不匹配`); chainOk = false; break; }
    prev = e.chain_hash;
  }
  if (chainOk) ok('chain');
  const headExpected = events.length ? events[events.length - 1].chain_hash : genesis;
  if ((m.head_hash || genesis) !== headExpected) fail('headHash', 'head_hash 与链尾不一致'); else ok('headHash');

  // 画布哈希
  if (pkg.project && pkg.project.canvas && pkg.project.canvas.sha256 && typeof pkg.canvas_png_data_url === 'string') {
    const canvasSha = await sha256Hex(pkg.canvas_png_data_url);
    if (canvasSha === pkg.project.canvas.sha256) ok('canvasHash'); else fail('canvasHash', '画布 PNG SHA-256 不匹配');
  } else { ok('canvasHash'); }

  // AI manifest 与 L6 事件一致性
  const aiEvents = events.filter((e) => AI_LAYERS.has(e.layer) && e.params && e.params.task);
  const ai = m.ai;
  if (!ai) {
    // 旧包无 ai 字段：仅记录，不影响链校验
    ok('aiManifest');
  } else {
    if (Number(ai.calls) !== aiEvents.length) fail('aiCalls', 'manifest.ai.calls 与 L6 AI 事件数不一致');
    else ok('aiCalls');
    if (Number(ai.real_calls || 0) + Number(ai.mock_calls || 0) !== Number(ai.calls)) fail('aiSplit', 'real+mock 不等于 calls'); else ok('aiSplit');
    const realFromEvents = aiEvents.filter((e) => e.params && !e.params.mock).length;
    if (Number(ai.real_calls || 0) !== realFromEvents) fail('aiRealCalls', 'real_calls 与事件不一致'); else ok('aiRealCalls');
    if (Array.isArray(ai.providers) && ai.providers.length) {
      const bad = ai.providers.some((p) => !p || !p.provider || !p.model || !(p.calls >= 0));
      if (bad) fail('aiProviders', 'providers 字段不完整'); else ok('aiProviders');
    } else ok('aiProviders');
    ok('aiManifest');
  }

  // refs
  if (Array.isArray(pkg.refs)) {
    const bad = pkg.refs.some((r) => !r || !r.asset_id || (r.sha256 && !/^[0-9a-f]{64}$/i.test(r.sha256)));
    if (bad) fail('refs', '素材引用字段不完整'); else ok('refs');
  } else ok('refs');

  return { ok: errors.length === 0, checks, errors, summary: { events: events.length, ai_calls: aiEvents.length, real_calls: ai ? ai.real_calls : null, head_hash: m.head_hash || null } };
}

const isMain = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
if (isMain) {
  const file = process.argv[2];
  if (!file) { console.error('用法：node v2/qa/tools/verify-evidence.mjs <inkproof-evidence.json>'); process.exit(2); }
  try {
    const pkg = JSON.parse(await fsp.readFile(file, 'utf8'));
    const r = await verifyEvidence(pkg);
    console.log(JSON.stringify(r, null, 2));
    process.exit(r.ok ? 0 : 1);
  } catch (e) {
    console.error('复核失败：' + (e && e.message || e));
    process.exit(3);
  }
}
