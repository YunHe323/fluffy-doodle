#!/usr/bin/env node
/**
 * v2/qa/tools/ai-proxy-adversarial.mjs —— T97 QA 对抗用例（独立于 owner 自测；假上游 + 真实 serve.mjs）
 *
 * 覆盖：token 缺失/错误（config/chat/image/test/cookie）、x-ai-confirm 缺失不触达上游、Origin 异常 403、
 *       超大 body 413、图片尺寸/参考图数量上限、并发 image 串行、12h URL 404、密钥不泄漏（响应/日志/前端可读位置）、config 权限、非法 JSON。
 * 输出：v2/qa/tools/ai-proxy-adversarial-results.json；控制台 PASS/FAIL。
 */
import http from 'node:http';
import { spawn } from 'node:child_process';
import { promises as fs, statSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPO = path.resolve(__dirname, '..', '..', '..');
const SECRET = 'sk-SECRET-ADVERSARIAL-9f3a';
const TOKEN = 'local-token-ADV';
const TINY_PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
const results = { schema: 'mozheng.qa.ai-proxy-adversarial.v1', at: new Date().toISOString(), checks: {}, logs: [], errors: [], pass: null };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function fakeUpstream() {
  const state = { chatCalls: 0, imageCalls: 0, active: 0, maxActive: 0 };
  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => { raw += c; });
    req.on('end', () => {
      let body = {}; try { body = JSON.parse(raw || '{}'); } catch (e) { body = {}; }
      if (req.url.startsWith('/img.png')) { const png = Buffer.from(TINY_PNG, 'base64'); res.writeHead(200, { 'content-type': 'image/png', 'content-length': png.length }); res.end(png); return; }
      if (req.url.startsWith('/expired.png')) { res.writeHead(404, { 'content-type': 'text/plain' }); res.end('expired'); return; }
      if (req.url.startsWith('/v1/chat/completions')) {
        state.chatCalls += 1;
        if (body.model === 'fail401') { res.writeHead(401); res.end('{"error":"bad"}'); return; }
        if (body.model === 'fail429') { res.writeHead(429); res.end('{"error":"rate"}'); return; }
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify({ id: 'x', model: body.model || 'fake', choices: [{ message: { role: 'assistant', content: JSON.stringify({ summary: 'adv upstream' }) } }], usage: { total_tokens: 3 } }));
        return;
      }
      if (req.url.startsWith('/v1/images/generations')) {
        state.imageCalls += 1; state.active += 1; state.maxActive = Math.max(state.maxActive, state.active);
        const url = body.prompt === 'expired' ? `http://127.0.0.1:${server.address().port}/expired.png` : `http://127.0.0.1:${server.address().port}/img.png`;
        setTimeout(() => { state.active -= 1; res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ model: 'hy-image-v3.0', data: [{ url }] })); }, 220);
        return;
      }
      res.writeHead(404); res.end('nf');
    });
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve({ server, state, port: server.address().port })));
}

async function startServe({ port, configPath, tokenPath, outBuf }) {
  const proc = spawn(process.execPath, [path.join(REPO, 'v2', 'serve.mjs')], {
    cwd: REPO,
    env: { ...process.env, PORT: String(port), AI_CONFIG_PATH: configPath, AI_TOKEN_PATH: tokenPath, AI_LOCAL_TOKEN: TOKEN },
  });
  proc.stdout.on('data', (d) => outBuf.push(String(d)));
  proc.stderr.on('data', (d) => outBuf.push(String(d)));
  for (let i = 0; i < 120; i += 1) {
    await sleep(120);
    try { const r = await fetch(`http://127.0.0.1:${port}/health`); if (r.ok) return proc; } catch (e) { /* wait */ }
  }
  throw new Error('serve 未启动: ' + outBuf.join('').slice(-500));
}

async function req(port, method, pathName, body, headers = {}) {
  const opts = { method, headers: { ...headers } };
  if (body !== undefined && body !== null) { opts.body = typeof body === 'string' ? body : JSON.stringify(body); opts.headers['content-type'] = opts.headers['content-type'] || 'application/json'; }
  const res = await fetch(`http://127.0.0.1:${port}${pathName}`, opts);
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch (e) { /* ignore */ }
  return { status: res.status, text, json, headers: Object.fromEntries(res.headers.entries()) };
}

async function main() {
  const upstream = await fakeUpstream();
  const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'mozheng-ai-adv-'));
  const configPath = path.join(tmp, '.ai-config.json');
  const tokenPath = path.join(tmp, '.ai-token');
  const outBuf = [];
  const port = 4390 + Math.floor(Math.random() * 80);
  const H = { 'x-ai-token': TOKEN };
  const CONF = { 'x-ai-token': TOKEN, 'x-ai-confirm': 'true' };
  const ORIGIN_OK = { origin: `http://127.0.0.1:${port}` };
  let serve = null;
  const check = (k, ok, detail) => { results.checks[k] = !!ok; if (!ok) results.errors.push(k + ': ' + JSON.stringify(detail).slice(0, 300)); else if (detail) results.logs.push(k + ': ' + JSON.stringify(detail).slice(0, 200)); };
  try {
    serve = await startServe({ port, configPath, tokenPath, outBuf });
    // 0) 基础：配置 fake 上游（真实模式）
    let r = await req(port, 'POST', '/api/ai/config', {
      mode: 'real', provider: 'openai-compatible', model: 'fake-model', timeoutMs: 3000,
      providers: { 'openai-compatible': { baseUrl: `http://127.0.0.1:${upstream.port}/v1`, apiKey: SECRET, model: 'fake-model' } },
    }, H);
    check('setupConfig', r.status === 200 && r.json && r.json.ok === true, r.json);
    const fp = r.json && r.json.config && r.json.config.filePermissions;
    check('configFilePermissionsReported', !!fp && (process.platform !== 'win32' || fp.platform === 'win32'), fp || null);
    if (process.platform === 'win32') check('configWindowsAclBestEffort', !!fp && ['ok', 'failed'].includes(fp.acl), fp || null);
    const chatBody = { task: 'analyze', messages: [{ role: 'user', content: 'hi' }] };
    const imgBody = { prompt: 'adv', size: '512x512', count: 1 };

    // 1) token 缺失/错误
    check('tokenMissingConfigGet', (await req(port, 'GET', '/api/ai/config')).status === 401);
    check('tokenWrongConfigGet', (await req(port, 'GET', '/api/ai/config', null, { 'x-ai-token': 'nope' })).status === 401);
    check('tokenMissingConfigPost', (await req(port, 'POST', '/api/ai/config', { mode: 'mock' })).status === 401);
    check('tokenMissingChat', (await req(port, 'POST', '/api/ai/chat', chatBody)).status === 401);
    check('tokenWrongChat', (await req(port, 'POST', '/api/ai/chat', chatBody, { 'x-ai-token': 'nope' })).status === 401);
    check('tokenMissingImage', (await req(port, 'POST', '/api/ai/image', imgBody)).status === 401);
    check('tokenMissingTest', (await req(port, 'POST', '/api/ai/test', {})).status === 401);
    check('tokenCookieOk', (await req(port, 'GET', '/api/ai/config', null, { cookie: 'mozheng_ai_token=' + TOKEN })).status === 200);
    check('tokenCookieWrong', (await req(port, 'GET', '/api/ai/config', null, { cookie: 'mozheng_ai_token=nope' })).status === 401);

    // 2) x-ai-confirm 缺失：不发上游、mock needs-confirm
    const chatBefore = upstream.state.chatCalls, imgBefore = upstream.state.imageCalls;
    r = await req(port, 'POST', '/api/ai/chat', chatBody, H);
    check('confirmMissingChatMock', r.status === 200 && r.json.mode === 'mock' && r.json.reason === 'needs-confirm' && chatBefore === upstream.state.chatCalls, { status: r.status, reason: r.json && r.json.reason, chatCalls: upstream.state.chatCalls });
    r = await req(port, 'POST', '/api/ai/image', imgBody, H);
    check('confirmMissingImageMock', r.status === 200 && r.json.mode === 'mock' && r.json.reason === 'needs-confirm' && imgBefore === upstream.state.imageCalls, { status: r.status, reason: r.json && r.json.reason });
    r = await req(port, 'POST', '/api/ai/chat', chatBody, CONF);
    check('confirmPresentChatReal', r.status === 200 && r.json.mode === 'real', r.json && { mode: r.json.mode });

    // 3) Origin 异常 → 403；正确 Origin → 放行
    const badOrigins = ['http://evil.example.com', `http://127.0.0.1:${port + 1}`];
    for (const [i, origin] of badOrigins.entries()) {
      const st = (await req(port, 'GET', '/api/ai/health', null, { origin })).status;
      check('originBad' + i, st === 403, { origin, status: st });
    }
    const schemeSt = (await req(port, 'GET', '/api/ai/health', null, { origin: 'https://127.0.0.1:' + port })).status;
    results.knownLimitations = results.knownLimitations || [];
    check('originSchemeHttps403', schemeSt === 403, { status: schemeSt });
    check('originGoodHealth', (await req(port, 'GET', '/api/ai/health', null, ORIGIN_OK)).status === 200);
    check('originGoodChat', (await req(port, 'POST', '/api/ai/chat', chatBody, { ...CONF, ...ORIGIN_OK })).status === 200);
    check('originBadChat403', (await req(port, 'POST', '/api/ai/chat', chatBody, { ...CONF, origin: 'http://evil.example.com' })).status === 403);

    // 4) 超大 body → 413（>8MB）
    const huge = 'x'.repeat(8 * 1024 * 1024 + 1024);
    let bodyReject = { mode: null, status: null, json: null };
    try { const br = await req(port, 'POST', '/api/ai/chat', huge, CONF); bodyReject = { mode: 'response', status: br.status, json: br.json }; }
    catch (e) { bodyReject = { mode: 'socket-destroy', status: null, json: null, err: String(e.message || e).slice(0, 80) }; }
    check('bodyTooLargeRejected', bodyReject.status === 413, bodyReject);
    check('bodyTooLargeJson', !!(bodyReject.json && bodyReject.json.error && bodyReject.json.error.code === 'body_too_large'), bodyReject);
    results.bodyLimit = bodyReject;

    // 5) 图片尺寸/参数上限
    check('imageSizeOverArea', (await req(port, 'POST', '/api/ai/image', { prompt: 'x', size: '2048x2048' }, CONF)).status === 400);
    check('imageSizeInvalid', (await req(port, 'POST', '/api/ai/image', { prompt: 'x', size: 'big' }, CONF)).status === 400);
    check('imageRefsOver3', (await req(port, 'POST', '/api/ai/image', { prompt: 'x', size: '512x512', images: ['data:image/png;base64,AA==', 'data:image/png;base64,AA==', 'data:image/png;base64,AA==', 'data:image/png;base64,AA=='] }, CONF)).status === 400);
    r = await req(port, 'POST', '/api/ai/image', { prompt: 'adv', size: '512x512', count: 1, images: ['data:image/png;base64,AA==', 'data:image/png;base64,AA==', 'data:image/png;base64,AA=='] }, CONF);
    check('imageRefs3Ok', r.status === 200 && r.json.mode === 'real', { status: r.status, mode: r.json && r.json.mode });

    // 6) 并发 2 image 应串行（上游最大并发=1）
    const [a, b] = await Promise.all([
      req(port, 'POST', '/api/ai/image', { prompt: 'c1', size: '512x512' }, CONF),
      req(port, 'POST', '/api/ai/image', { prompt: 'c2', size: '512x512' }, CONF),
    ]);
    check('imageSerialized', a.status === 200 && b.status === 200 && upstream.state.maxActive === 1, { maxActive: upstream.state.maxActive, statuses: [a.status, b.status] });

    // 7) 12h URL 404 → 502 image_download + billed:false
    r = await req(port, 'POST', '/api/ai/image', { prompt: 'expired', size: '512x512' }, CONF);
    check('imageUrl404Expired', r.status === 502 && r.json && r.json.billed === false && r.json.error && r.json.error.code === 'image_download' && r.json.error.billed === false, r.json && { status: r.status, error: r.json.error });

    // 8) 密钥不泄漏：响应 / serve 日志 / 前端可读位置（config GET） / 配置响应
    const texts = [r.text];
    const cfgs = [await req(port, 'GET', '/api/ai/config', null, H), await req(port, 'POST', '/api/ai/config', { mode: 'real' }, H)];
    for (const x of cfgs) texts.push(x.text);
    const testRes = await req(port, 'POST', '/api/ai/test', {}, H);
    texts.push(testRes.text);
    const chatRes = await req(port, 'POST', '/api/ai/chat', chatBody, CONF);
    texts.push(chatRes.text);
    check('secretNotInResponses', texts.every((t) => !String(t).includes(SECRET)), texts.filter((t) => String(t).includes(SECRET)).length);
    await sleep(300);
    const logs = outBuf.join('');
    check('secretNotInServeLogs', !logs.includes(SECRET), logs.includes(SECRET) ? logs.slice(0, 200) : 'ok');
    check('configNoKeyReadable', !cfgs[0].text.includes(SECRET) && !cfgs[0].text.includes('apiKey'), cfgs[0].json && { hasKey: cfgs[0].json.hasKey, keyLast4: cfgs[0].json.config && cfgs[0].json.config.providers });
    // 配置内容（非前端）写法：apiKey 在文件中但 0600
    const cfgRaw = await fs.readFile(configPath, 'utf8').catch(() => '');
    let mode = null; try { mode = statSync(configPath).mode & 0o777; } catch (e) { /* ignore */ }
    results.configFile = { hasKeyInFile: cfgRaw.includes(SECRET), mode: mode == null ? null : '0o' + mode.toString(8), platform: process.platform };
    check('configFileContainsKey', cfgRaw.includes(SECRET), { hasKey: cfgRaw.includes(SECRET) });
    if (process.platform !== 'win32') check('configFileMode600', mode === 0o600, results.configFile);

    // 9) 非法 JSON → 400
    const badJson = await req(port, 'POST', '/api/ai/chat', '{not-json', CONF);
    check('badJson400', badJson.status === 400, { status: badJson.status });

    // 10) 清空 key → hasKey=false（mock 降级）
    r = await req(port, 'POST', '/api/ai/config', { providers: { 'openai-compatible': { baseUrl: `http://127.0.0.1:${upstream.port}/v1`, apiKey: '', model: 'fake-model' } } }, H);
    const cfg2 = await req(port, 'GET', '/api/ai/config', null, H);
    check('keyClearedRedacted', r.status === 200 && cfg2.json && cfg2.json.hasKey === false, { hasKey: cfg2.json && cfg2.json.hasKey });

    results.checksCount = Object.keys(results.checks).length;
    results.passCount = Object.values(results.checks).filter(Boolean).length;
    results.pass = results.passCount === results.checksCount;
  } catch (e) {
    results.fatal = String(e.stack || e.message || e);
    results.pass = false;
  } finally {
    try { serve && serve.kill(); } catch (e) { /* ignore */ }
    try { upstream.server.close(); } catch (e) { /* ignore */ }
    try { await fs.rm(tmp, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  }
  await fs.writeFile(path.join(__dirname, 'ai-proxy-adversarial-results.json'), JSON.stringify(results, null, 2), 'utf8');
  console.log('[adv] ' + (results.pass ? 'PASS' : 'FAIL') + ' ' + results.passCount + '/' + results.checksCount);
  if (!results.pass) console.log('[adv] errors: ' + JSON.stringify(results.errors.slice(0, 10)));
  process.exit(results.pass ? 0 : 1);
}

main().catch((e) => { console.error('adversarial 失败：', e.stack || e); process.exit(2); });
