// v2/app/test-image-pan.mjs —— 插入素材后可否操作（变换框）+ 放大后平移画面
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8148;
const out = { schema: 'mozheng.app.image-pan.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  fs.writeFileSync(ROOT + '\\v2\\app\\test-image-pan-result.json', JSON.stringify(out, null, 2), 'utf8');
  process.exit(code);
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('console', (m) => { if (m.type() === 'error') out.errors.push(m.text().slice(0, 200)); });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(800);
  // 1) 打开素材库 → 选第一张 → 插入图层
  await page.click('#btnLibrary');
  await page.waitForFunction(() => !document.getElementById('librarySheet').hidden, null, { timeout: 15000 });
  await page.waitForFunction(() => document.querySelectorAll('#libGrid .lib-card').length > 0, null, { timeout: 15000 });
  await page.click('#libGrid .lib-card');
  await page.waitForTimeout(300);
  await page.click('#libInsertLayer');
  await page.waitForTimeout(1200);
  out.cases.insert = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const h = a.engine.getTransformHandles ? a.engine.getTransformHandles() : null;
    return { tool: a.state.tool, transformActive: !!a.state.transformActive, layerCount: a.engine.getLayers().length, hasHandles: !!h, handleCount: h && h.handles ? h.handles.length : 0 };
  });
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-image-transform-1920.png' });
  // 1b) 拖动变换框内部 → 提交 → undo 还原（验证"抓手"真的能操作图片）
  const canvasRect = await page.locator('#mainCanvas').boundingBox();
  const tinfo = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const b = a.engine.getTransformBounds();
    const r = document.getElementById('mainCanvas').getBoundingClientRect();
    return { b, rect: { x: r.x, y: r.y, w: r.width, h: r.height }, undo: a.engine.getStats().undoDepth };
  });
  const toClient = (docX, docY) => ({ x: tinfo.rect.x + (docX / 1200) * tinfo.rect.w, y: tinfo.rect.y + (docY / 800) * tinfo.rect.h });
  const c0 = toClient(tinfo.b.cx, tinfo.b.cy);
  await page.evaluate(() => { window.__pd = 0; document.getElementById('mainCanvas').addEventListener('pointerdown', () => { window.__pd += 1; }, true); });
  const elAt = await page.evaluate(({ x, y }) => { const el = document.elementFromPoint(x, y); return el ? (el.id || el.className || el.tagName) : null; }, c0);
  await page.mouse.move(c0.x, c0.y);
  await page.mouse.down();
  await page.mouse.move(c0.x + 70, c0.y + 45, { steps: 6 });
  await page.mouse.up();
  await page.waitForTimeout(200);
  const pdCount = await page.evaluate(() => window.__pd || 0);
  const moved = await page.evaluate(() => window.__V2_APP__.engine.getTransformBounds());
  out.cases.transformMove = { before: { cx: tinfo.b.cx, cy: tinfo.b.cy, w: tinfo.b.w, h: tinfo.b.h, undo: tinfo.undo }, elAt, pdCount, after: { cx: moved.cx, cy: moved.cy } };
  await page.keyboard.press('Enter');
  await page.waitForTimeout(250);
  const committed = await page.evaluate(() => {
    const a = window.__V2_APP__;
    return { transformActive: !!a.state.transformActive, undo: a.engine.getStats().undoDepth, bounds: a.engine.getTransformBounds() };
  });
  await page.keyboard.press('Control+z');
  await page.waitForTimeout(250);
  const undone = await page.evaluate(() => ({ undo: window.__V2_APP__.engine.getStats().undoDepth }));
  out.cases.transformMove.committed = committed;
  out.cases.transformMove.undone = undone;
  out.cases.transformOk = Math.abs(moved.cx - tinfo.b.cx) > 40 && Math.abs(moved.cy - tinfo.b.cy) > 25
    && committed.transformActive === false && committed.undo > tinfo.undo && undone.undo < committed.undo;
  // 2) 按 Esc 取消变换 → 切移动工具 → 放大 → 拖拽平移
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  await page.click('#btnToolMove');
  await page.waitForTimeout(200);
  const box = await page.locator('#mainCanvas').boundingBox();
  const cx = box.x + box.width / 2, cy = box.y + box.height / 2;
  await page.mouse.move(cx, cy);
  await page.mouse.wheel(0, -800);
  await page.waitForTimeout(300);
  const before = await page.evaluate(() => ({ zoom: window.__V2_APP__.view.zoom, tx: window.__V2_APP__.view.tx, ty: window.__V2_APP__.view.ty, tool: window.__V2_APP__.state.tool }));
  await page.mouse.move(cx, cy);
  await page.mouse.down();
  await page.mouse.move(cx + 140, cy + 90, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(300);
  const after = await page.evaluate(() => ({ zoom: window.__V2_APP__.view.zoom, tx: window.__V2_APP__.view.tx, ty: window.__V2_APP__.view.ty }));
  out.cases.pan = { before, after, dx: after.tx - before.tx, dy: after.ty - before.ty };
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-pan-1920.png' });
  // 3) 空格+拖拽仍可平移（切回画笔后）
  await page.click('#btnToolBrush');
  await page.waitForTimeout(200);
  await page.keyboard.down('Space');
  await page.mouse.move(cx, cy); await page.mouse.down(); await page.mouse.move(cx - 80, cy - 60, { steps: 5 }); await page.mouse.up();
  await page.keyboard.up('Space');
  await page.waitForTimeout(200);
  const afterSpace = await page.evaluate(() => ({ tx: window.__V2_APP__.view.tx, ty: window.__V2_APP__.view.ty }));
  out.cases.spacePan = { before: after, after: afterSpace, dx: afterSpace.tx - after.tx };
  out.cases.insertOk = out.cases.insert.tool === 'transform' && out.cases.insert.transformActive && out.cases.insert.hasHandles && out.cases.insert.handleCount >= 5;
  out.cases.transformOk = !!out.cases.transformOk;
  out.cases.panOk = Math.abs(out.cases.pan.dx) > 50 && Math.abs(out.cases.pan.dy) > 30 && out.cases.pan.before.zoom > 1;
  out.cases.spacePanOk = Math.abs(out.cases.spacePan.dx) > 30;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.insertOk && out.cases.transformOk && out.cases.panOk && out.cases.spacePanOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  await finish(3);
}
