# 第三方依赖与许可登记（v2/qa）

> QA harness 自身的依赖登记；产品/引擎的第三方登记见 `product/THIRD_PARTY_NOTICES.md` 与 `v2/engine/vendor/THIRD_PARTY_NOTICES.md`。

| 组件 | 版本 | 许可 | 用途 | 引入方式 | 备注 |
|---|---|---|---|---|---|
| **playwright-core** | 1.65.0 | **Apache-2.0** | T51 Playwright 版 QA harness（浏览器自动化：`channel:'msedge'` 复用本机 Edge，默认 headless） | `v2/qa/package.json` devDependency（`npm install`），仅测试期使用，不进产品运行时 | 不下载浏览器（playwright-core 无内置浏览器）；Apache-2.0 全文见 `v2/qa/node_modules/playwright-core/LICENSE` |
| Microsoft Edge（本机安装） | 156.x | 微软许可（系统自带） | 被测运行时 | 不随仓库分发 | `shutil/harness` 通过 CDP/Playwright `channel:'msedge'` 复用 |
| Klecks（参考实现 dist） | 构建产物 | **MIT** | T48/T51 对照组的成熟开源实现（只读启动，不复制代码） | `spike/klecks/vendor/klecks/dist`（源码与许可证见 `spike/klecks/`） | 仅行为观测，不修改、不内联 |
| CanvasKit / Skia | 0.42.0 | BSD-3-Clause | 被测引擎渲染（vendor 在 `v2/engine/vendor/`） | 产品侧依赖，非 QA 引入 | 见 `v2/engine/vendor/LICENSE` |

## 说明

- QA harness 有两套实现：
  1. `browser-smoke.mjs` / `compare/compare.mjs`：**零第三方依赖**（Node 内置 `WebSocket` + `fetch`），保留作应急；
  2. `pw/harness.mjs`：T51 起基于 **playwright-core（Apache-2.0）**，默认 headless、自带等待/超时，不弹用户窗口。
- 运行 `pw/harness.mjs` 前需在 `v2/qa` 执行一次 `npm install`（只装 playwright-core，约 1 个包，不下载浏览器）。
- 所有对比结论只用行为观测；Klecks 代码为 MIT，本项目不复制其代码，仅通过本地静态服务加载其 dist。
