// 连接已运行的 Edge CDP，读取 __APP_DEBUG__ / 截图（用于 OS 级鼠标测试）
import fs from 'node:fs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = process.argv[2] || '9413';
let target = null;
for (let i = 0; i < 100 && !target; i++) {
  try { const r = await fetch(`http://127.0.0.1:${PORT}/json/list`); target = (await r.json()).find((t) => t.type === 'page' && t.url.startsWith('http')); } catch (e) {}
  if (!target) await new Promise((r) => setTimeout(r, 200));
}
if (!target) { console.log('NO TARGET'); process.exit(1); }
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); } };
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
async function ev(expression) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true });
  if (r.result?.exceptionDetails) return { err: JSON.stringify(r.result.exceptionDetails).slice(0, 600) };
  return r.result?.result?.value;
}
try {
  await send('Runtime.enable'); await send('Page.enable');
  const dbg = await ev('window.__APP_DEBUG__ ? window.__APP_DEBUG__() : null');
  const errs = await ev('window.__APP_DEBUG__ ? (window.__appErrors || null) : null');
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync(ROOT + '\\v2\\app\\edge-os-screenshot.png', Buffer.from(shot.result.data, 'base64'));
  console.log(JSON.stringify({ debug: dbg, url: target.url, screenshot: 'v2/app/edge-os-screenshot.png', errs }, null, 2));
} finally { try { ws.close(); } catch (e) {} process.exit(0); }
