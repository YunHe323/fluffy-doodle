﻿# 新旧 harness 结论一致性（legacy CDP compare.mjs vs T51 playwright）

> 生成：2026-11-07T04:48:30.264Z｜旧数据：`compare/compare-summary.json`（headless CDP，3 轮）｜新数据：`pw/results.json`（playwright-core，3 轮）

| 指标 | 旧（CDP） | 新（Playwright） | 差异 | 判定 |
|---|---|---|---|---|
| ours-app · S1 ink | 5431 | 7079 | 1648 | ⚠ 有差异 |
| ours-app · S1 断点 | 0 | 0 | 0 | ✅ 一致 |
| ours-app · S3 undo 后 ink | 4388 | 1602 | -2786 | ⚠ 有差异 |
| ours-brushes · S1 ink | 910 | 1568 | 658 | ⚠ 有差异 |
| ours-brushes · S1 断点 | 0 | 0 | 0 | ✅ 一致 |
| ours-brushes · S3 undo 后 ink | 661 | 882 | 221 | ⚠ 有差异 |
| ours-engine · S1 ink | 747 | 12850 | 12103 | ⚠ 有差异 |
| ours-engine · S1 断点 | 0 | 0 | 0 | ✅ 一致 |
| ours-engine · S3 undo 后 ink | 203 | 3242 | 3039 | ⚠ 有差异 |
| klecks · S1 ink | 495 | 437 | -58 | ✅ 一致 |
| klecks · S1 断点 | 0 | 0 | 0 | ✅ 一致 |
| klecks · S3 undo 后 ink | 204 | 185 | -19 | ✅ 一致 |

**一致性：6/12 项在 ±20% 内一致。**

说明：两版 harness 的采集口径不同（旧版用 canvas 区域截图；新版用页面内 readback），ink 绝对值不可直接横比，**看相对关系与结论方向**：
- 帧稳定/undo 结论：两版均全绿；
- 与 Klecks 的相对关系：两版均“S1 断点持平、帧稳定持平”；
- 新版优势：Playwright 自带等待/超时/截图，3 轮无卡死；旧版保留应急（零依赖）。