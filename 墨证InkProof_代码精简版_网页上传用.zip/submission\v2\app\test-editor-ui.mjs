// v2/app/test-editor-ui.mjs —— 图像调整 + 形状工具 UI 集成
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8159;
const out = { schema: 'mozheng.app.editor-ui.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  fs.writeFileSync(ROOT + '\\v2\\app\\test-editor-ui-result.json', JSON.stringify(out, null, 2), 'utf8');
  process.exit(code);
};
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  // 先画一笔，让当前图层有内容
  const box = await page.locator('#mainCanvas').boundingBox();
  await page.mouse.move(box.x + box.width * 0.35, box.y + box.height * 0.4);
  await page.mouse.down(); await page.mouse.move(box.x + box.width * 0.55, box.y + box.height * 0.55, { steps: 8 }); await page.mouse.up();
  await page.waitForTimeout(400);
  const layers0 = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  // 图像调整
  await page.click('#btnMore');
  await page.waitForTimeout(200);
  await page.click('#btnAdjustLayer');
  await page.waitForTimeout(300);
  out.cases.adjustOpen = await page.evaluate(() => ({ visible: !!document.querySelector('#adjustModal.show'), name: (document.getElementById('adjustLayerName') || {}).textContent }));
  await page.evaluate(() => {
    const set = (id, v) => { const e = document.getElementById(id); e.value = String(v); e.dispatchEvent(new Event('input', { bubbles: true })); };
    set('adjBrightness', 20); set('adjContrast', 15); set('adjSaturation', 10); set('adjHue', 5);
    document.getElementById('btnAdjustApply').click();
  });
  await page.waitForTimeout(900);
  out.cases.adjust = await page.evaluate(() => { const a = window.__V2_APP__; return { layers: a.engine.getLayers().length, records: a.state.records.filter((r) => r.kind === 'adjust_layer').length, names: a.engine.getLayers().map((l) => l.name).slice(-2) }; });
  // 形状工具
  await page.click('#btnToolShape');
  await page.waitForTimeout(250);
  await page.mouse.move(box.x + box.width * 0.3, box.y + box.height * 0.25);
  await page.mouse.down(); await page.mouse.move(box.x + box.width * 0.45, box.y + box.height * 0.4, { steps: 6 }); await page.mouse.up();
  await page.waitForTimeout(900);
  out.cases.shape = await page.evaluate(() => { const a = window.__V2_APP__; return { layers: a.engine.getLayers().length, records: a.state.records.filter((r) => r.kind === 'shape_inserted').length, names: a.engine.getLayers().map((l) => l.name).slice(-2) }; });
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-editor-ui-1920.png' });
  out.cases.layers0 = layers0;
  out.cases.adjustOk = out.cases.adjustOpen.visible && out.cases.adjust.layers === layers0 + 1 && out.cases.adjust.records >= 1;
  out.cases.shapeOk = out.cases.shape.layers === out.cases.adjust.layers + 1 && out.cases.shape.records >= 1;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.adjustOk && out.cases.shapeOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  await finish(3);
}
