// 临时：真实 Qwen3.8-Max 端到端（app → 本地代理 → DashScope）验证
import fs from 'node:fs';
import { chromium } from '../node_modules/playwright-core/index.mjs';
import { verifyEvidence } from './verify-evidence.mjs';
const OUT = 'v2/qa/tools/qwen-real-e2e-results.json';
const res = { schema: 'mozheng.qa.qwen-real-e2e.v1', cases: {}, errors: [], pass: false };
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  await fs.promises.writeFile(OUT, JSON.stringify(res, null, 2), 'utf8');
  process.exit(code);
};
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await ctx.addInitScript(() => {
    try { localStorage.setItem('mozheng.ai.settings.v1', JSON.stringify({ preset: 'qwen', allowReal: true, requireConfirm: false, privacyMode: false })); } catch (e) {}
  });
  const page = await ctx.newPage();
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) res.errors.push(m.text().slice(0, 300)); });
  await page.goto('http://127.0.0.1:4200/v2/app/index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(2500);
  res.cases.state = await page.evaluate(() => {
    const t = window.__V2_APP__.t96;
    const s = t.getState();
    return { preset: s.preset, hasKey: s.hasKey, realEligible: s.realEligible, label: s.label, config: s.config ? { ok: s.config.ok, mode: s.config.mode, provider: s.config.provider, model: s.config.model, hasKey: s.config.hasKey, supports: s.config.supports, baseUrl: s.config.providers && s.config.providers['openai-compatible'] && s.config.providers['openai-compatible'].baseUrl } : null };
  });
  if (!res.cases.state.hasKey || !res.cases.state.realEligible) throw new Error('Qwen 配置未生效：' + JSON.stringify(res.cases.state));
  const analysis = await page.evaluate(async () => {
    const app = window.__V2_APP__;
    app.state.selection = { x: 120, y: 100, width: 240, height: 180 };
    const t0 = Date.now();
    const r = await app.runAnalyze();
    const st = app.state;
    return { ms: Date.now() - t0, hasResult: !!r, observations: (st.analysis && st.analysis.observations || []).length, regions: (st.analysis && st.analysis.regions || []).length, lastCall: st.aiLastCall, modelVersion: st.analysis && st.analysis.modelVersion, err: st.lastError };
  });
  res.cases.analysis = analysis;
  const evidence = await page.evaluate(async () => {
    const app = window.__V2_APP__;
    const canvas = await app.engine.getCompositeDataUrl();
    return await app.buildEvidence({ canvasDataUrl: canvas });
  });
  const v = await verifyEvidence(evidence);
  res.cases.evidence = { ok: v.ok, checks: v.checks, summary: v.summary, ai: evidence.manifest && evidence.manifest.ai };
  await fs.promises.writeFile('v2/qa/tools/qwen-real-evidence.json', JSON.stringify(evidence), 'utf8');
  res.pass = res.cases.state.hasKey === true && res.cases.state.realEligible === true
    && res.cases.analysis.hasResult === true
    && res.cases.analysis.observations >= 1
    && res.cases.evidence.ok === true
    && res.cases.evidence.ai && res.cases.evidence.ai.real_calls >= 1
    && res.errors.length === 0;
  await finish(res.pass ? 0 : 1);
} catch (e) {
  res.fatal = String(e && e.stack || e);
  await finish(3);
}
