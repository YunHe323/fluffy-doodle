/**
 * v2 engine · 输入管线（IInputSource）
 * - Pointer Events：pen / mouse / touch；pointer capture
 * - coalesced events：`getCoalescedEvents()` 内的点全部提交（帧内批量）
 * - pressure：pen 用 e.pressure；mouse/touch 用速度反比模拟（无压感硬件降级）
 * - tilt：透传 tiltX/tiltY（T36 笔刷使用）
 * - 坐标：CSS → 画布像素（兼容缩放/平移后的 getBoundingClientRect）
 * - T49：LineSmoothing（MIT，移植自 Klecks）可选输入平滑；engine.setInputSmoothing(0..1)
 */
import { LineSmoothing } from './line-smoothing.js';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export function attachInput(engine, canvas, opts = {}) {
  let active = false;
  let last = null;
  let lastSpeed = 0;
  /** @type {LineSmoothing|null} */
  let smoother = null;

  function toPoint(e) {
    const rect = canvas.getBoundingClientRect();
    const sx = canvas.width / Math.max(1, rect.width);
    const sy = canvas.height / Math.max(1, rect.height);
    const x = (e.clientX - rect.left) * sx;
    const y = (e.clientY - rect.top) * sy;
    let pressure = e.pressure;
    const pointerType = e.pointerType || 'mouse';
    if (pointerType !== 'pen') {
      // 鼠标/触摸：速度反比模拟压感（速度越快越细）
      pressure = clamp(1 - lastSpeed / 40, 0.25, 1);
    } else if (!(pressure > 0 && pressure <= 1)) {
      pressure = 0.5;
    }
    return { x, y, pressure, tiltX: e.tiltX || 0, tiltY: e.tiltY || 0, timestamp: e.timeStamp || performance.now(), pointerType };
  }

  function trackSpeed(p) {
    if (last) {
      const dt = Math.max(1, p.timestamp - last.timestamp);
      const dist = Math.hypot(p.x - last.x, p.y - last.y);
      lastSpeed = (dist / dt) * 16; // 近似 px/帧
    }
    last = p;
  }

  function down(e) {
    if (active) return;
    if (e.button != null && e.button !== 0) return;
    e.preventDefault();
    active = true;
    last = null;
    lastSpeed = 0;
    canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId);
    const p = toPoint(e);
    trackSpeed(p);
    const smoothing = typeof engine.getInputSmoothing === 'function'
      ? engine.getInputSmoothing()
      : (typeof opts.smoothing === 'number' ? opts.smoothing : 0);
    smoother = new LineSmoothing({ smoothing });
    smoother.onCatchUp((sp) => {
      if (!active || !engine.currentStroke) return;
      engine.appendPoint(Object.assign({}, sp, { timestamp: performance.now() }), { catchUp: true });
      engine.requestFrame();
    });
    engine.beginStroke(p);
    if (smoother) smoother.begin(p);
  }

  function move(e) {
    if (!active) return;
    e.preventDefault();
    const events = typeof e.getCoalescedEvents === 'function' ? e.getCoalescedEvents() : null;
    const list = events && events.length ? events : [e];
    for (let i = 0; i < list.length; i += 1) {
      const p = toPoint(list[i]);
      trackSpeed(p);
      const out = smoother ? smoother.push(p) : p;
      // T41：透传 coalesced 序号/总数（笔刷可据此做插值/去重）
      engine.appendPoint(out, { flush: false, coalescedIndex: i, coalescedCount: list.length });
    }
    engine.requestFrame();
  }

  function up(e) {
    if (!active) return;
    active = false;
    if (smoother) { smoother.stop(); smoother = null; }
    try { canvas.releasePointerCapture && canvas.releasePointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    engine.endStroke();
  }

  function cancel() {
    if (!active) return;
    active = false;
    if (smoother) { smoother.stop(); smoother = null; }
    engine.cancelStroke();
  }

  canvas.addEventListener('pointerdown', down);
  canvas.addEventListener('pointermove', move);
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', cancel);
  canvas.style.touchAction = 'none';

  return function detach() {
    if (smoother) { smoother.stop(); smoother = null; }
    canvas.removeEventListener('pointerdown', down);
    canvas.removeEventListener('pointermove', move);
    canvas.removeEventListener('pointerup', up);
    canvas.removeEventListener('pointercancel', cancel);
  };
}
