/**
 * v2/psd · V2Doc 桥接（T60）
 *
 * 目标：PSD 导入/导出与 v2 统一文档模型 `V2Doc`（v2/engine/src/v2doc.js）互转，
 * 保持与既有 6 样本保真矩阵对齐；不支持项仍由 importer/fidelity 报告（不静默丢失）。
 *
 * 映射规则（与 T60 范围一致，1 级组）：
 *  - PSD group（children）→ V2Doc group；组内 layer → layer.group = groupId
 *  - 1 级以上嵌套：拍平到最近的 1 级组（v2 已知限制，由 fidelity/unsupported 记录）
 *  - blendMode：PSD 内部名 → V2Doc 16 支持名（internalBlendForLayers，不支持回 normal）
 *  - mask：PSD 有 mask canvas → V2Doc mask.exists=true（像素由 psd importer 负责，桥只做结构）
 *  - clip：PSD clip → V2Doc clip
 */
import { createDoc, createGroup, createLayer, normalizeDoc } from '../../engine/src/v2doc.js';
import { INTERNAL_TO_PSD, internalBlendForLayers } from './model.js';

/**
 * PSD 模型 doc（v2/psd/src/model.js 的 Doc）→ V2Doc
 * @param {any} psdDoc
 */
export function psdDocToV2Doc(psdDoc) {
  const groups = [];
  const layers = [];
  const groupNodes = [];
  // 先收集 1 级组，供 layer.group 引用
  for (const node of psdDoc.children || []) {
    if (node.type === 'group') {
      const g = createGroup({
        name: node.name, visible: node.visible !== false,
        opacity: node.opacity == null ? 1 : node.opacity,
        clip: !!node.clip,
        mask: { exists: !!node.mask, enabled: true },
      });
      groups.push(g);
      groupNodes.push({ psdNode: node, group: g });
    }
  }
  function addLayerNode(node, groupId) {
    const layer = createLayer({
      name: node.name,
      visible: node.visible !== false,
      opacity: node.opacity == null ? 1 : node.opacity,
      blend: internalBlendForLayers(node.blendMode),
      clip: !!node.clip,
      group: groupId || null,
      mask: { exists: !!node.mask, enabled: true },
    });
    layers.push(layer);
    return layer;
  }
  for (const node of psdDoc.children || []) {
    if (node.type === 'group') {
      const entry = groupNodes.find((g) => g.psdNode === node);
      for (const child of node.children || []) {
        if (child.type === 'group') {
          // v2 已知限制：仅 1 级组；嵌套组拍平到该 1 级组，结构 diff 由 fidelity 记录
          for (const leaf of child.children || []) if (leaf.type !== 'group') addLayerNode(leaf, entry ? entry.group.id : null);
        } else if (child.type === 'layer') {
          addLayerNode(child, entry ? entry.group.id : null);
        }
      }
    } else if (node.type === 'layer') {
      addLayerNode(node, null);
    }
  }
  return createDoc({
    width: psdDoc.width,
    height: psdDoc.height,
    groups,
    layers,
    activeLayerId: layers.length ? layers[layers.length - 1].id : null,
  });
}

/**
 * V2Doc → PSD 模型 doc（结构；像素 canvas 由 exporter/上层补）
 * @param {any} v2doc
 * @param {{colorMode?:string, bitsPerChannel?:number}} [opts]
 */
export function v2DocToPsdDoc(v2doc, opts = {}) {
  const doc = normalizeDoc(v2doc);
  const children = [];
  const groupChildren = new Map();
  for (const g of doc.groups) {
    const node = {
      type: 'group', name: g.name, visible: g.visible !== false,
      opacity: g.opacity == null ? 1 : g.opacity, blendMode: 'pass through',
      clip: !!g.clip, mask: g.mask && g.mask.exists ? { exists: true } : null, canvas: null, children: [],
    };
    groupChildren.set(g.id, node.children);
    children.push(node);
  }
  for (const l of doc.layers) {
    const node = {
      type: 'layer', name: l.name, visible: l.visible !== false,
      opacity: l.opacity == null ? 1 : l.opacity,
      blendMode: INTERNAL_TO_PSD[l.blend] || 'normal',
      clip: !!l.clip, mask: l.mask && l.mask.exists ? null : null,
      canvas: null, children: [],
    };
    if (l.group && groupChildren.has(l.group)) groupChildren.get(l.group).push(node);
    else children.push(node);
  }
  return {
    schema: 'mozheng.v2.doc',
    width: doc.width,
    height: doc.height,
    colorMode: opts.colorMode || 'RGB',
    bitsPerChannel: opts.bitsPerChannel || 8,
    children,
    unsupported: [],
    source: 'v2doc-bridge',
  };
}

/** 结构对比（用于桥接测试/保真报告）：图层数/组数/蒙版数/混合模式分布 */
export function compareStructure(v2doc, psdDoc) {
  const d = normalizeDoc(v2doc);
  const psdLayers = [];
  const psdGroups = [];
  const psdMasks = [];
  function walk(nodes) {
    for (const n of nodes || []) {
      if (n.type === 'group') { psdGroups.push(n); walk(n.children); }
      else { psdLayers.push(n.name); if (n.mask) psdMasks.push(n.name); }
    }
  }
  walk(psdDoc.children);
  return {
    v2: {
      layers: d.layers.length, groups: d.groups.length,
      masks: d.layers.filter((l) => l.mask.exists).length,
      groupMasks: d.groups.filter((g) => g.mask && g.mask.exists).length,
      groupClips: d.groups.filter((g) => g.clip).length,
    },
    psd: {
      layers: psdLayers.length, groups: psdGroups.length, masks: psdMasks.length,
      groupMasks: psdGroups.filter((n) => n.mask).length,
      groupClips: psdGroups.filter((n) => n.clip).length,
    },
    ok: d.layers.length === psdLayers.length && d.groups.length === psdGroups.length,
  };
}
