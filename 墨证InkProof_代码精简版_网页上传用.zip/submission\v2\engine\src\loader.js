/**
 * v2 engine · CanvasKit 本地加载器（零外网）
 * vendor: ./vendor/canvaskit.js + canvaskit.wasm（0.42.0, BSD-3-Clause）
 */
export async function loadCanvasKit(base = './vendor/') {
  if (window.CanvasKit) return window.CanvasKit;
  if (!window.CanvasKitInit) {
    await new Promise((resolve, reject) => {
      const el = document.createElement('script');
      el.src = `${base}canvaskit.js`;
      el.onload = resolve;
      el.onerror = () => reject(new Error(`无法加载 ${base}canvaskit.js`));
      document.head.appendChild(el);
    });
  }
  if (typeof window.CanvasKitInit !== 'function') {
    throw new Error('canvaskit.js 已加载但未提供 CanvasKitInit()');
  }
  return window.CanvasKitInit({ locateFile: (f) => `${base}${f}` });
}
