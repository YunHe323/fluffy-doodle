/**
 * v2/app/core/ai-provider.mjs —— 真实模型 Provider 抽象（T92 建立；现已通过 v2/serve.mjs 代理接入 Qwen 等真实模型）
 * 注：T92 时期的「未接真 key」注释已过期。当前开发机配置 mode=real 可真实调用，
 *     提交包不带 key 时自动降级 Mock；模型名以服务端 /api/ai/* 回传为准，不在前端臆造。
 *
 * 原则：
 * - 浏览器侧永远不持有真实 API Key；所有模型请求经本地 `v2/serve.mjs` 的 `/api/ai/*` 代理。
 * - 无 key / mode=mock / provider 不可用时自动回退 MockProvider（现有 mock-ai.mjs，离线可演示）。
 * - Provider 统一输出与 app runAnalyze/runDirections/runGenerate/applyCandidate 对齐的结构。
 * - 输出必须经过 normalize（schema + provenance 校验）后才交给 app，禁止模型编造 source。
 *
 * 参考：Moonshot OpenAI-compatible Chat Completions（vision + JSON mode）；
 *       腾讯混元 chat vision + 生图 submit/query；自定义 OpenAI-compatible。
 * 真实模型 ID/计费以官方当前文档为准，本文件只做可配置默认值。
 */
import { mockAnalyze, mockDirections, mockGenerate, MOCK_MODEL } from './mock-ai.mjs';
import { normalizeChatActions, buildMockActions } from './chat-actions.mjs';

export const AI_PROVIDER_VERSION = '0.1.0';
export const DEFAULT_TIMEOUT_MS = 60000;
export const DEFAULT_RETRIES = 2;
export const PROXY_BASE = '';

export const MODEL_HINTS = {
  moonshot: { provider: 'moonshot', baseUrl: 'https://api.moonshot.cn/v1', model: 'kimi-k3.1-pro', vision: true, imageGen: false },
  hunyuan: { provider: 'hunyuan', baseUrl: 'https://api.hunyuan.cloud.tencent.com/v1', model: 'hunyuan-vision', visionModel: 'hunyuan-vision', imageModel: 'hy-image-v3.0', imageGen: true },
  qwen: { provider: 'qwen', baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1', imageBaseUrl: 'https://dashscope.aliyuncs.com', model: 'qwen3.8-max', imageModel: 'qwen-image-3.0', imageGen: true },
  'openai-compatible': { provider: 'openai-compatible', baseUrl: 'https://api.openai.com/v1', model: 'gpt-4o-mini', vision: true, imageGen: false },
};

export class AIProviderError extends Error {
  constructor(message, opts = {}) {
    super(message);
    this.name = 'AIProviderError';
    this.code = opts.code || 'ai_error';
    this.status = opts.status || 0;
    this.retryable = !!opts.retryable;
    this.userMessage = opts.userMessage || message;
    this.requestId = opts.requestId || null;
  }
}

export function mapHttpError(status, body, requestId) {
  const text = typeof body === 'string' ? body : JSON.stringify(body || {});
  if (status === 401 || status === 403) return new AIProviderError('模型鉴权失败（本地未配置有效密钥）', { code: 'auth', status, retryable: false, requestId, userMessage: '模型未配置或密钥无效，已可继续使用 Mock' });
  if (status === 429) return new AIProviderError('模型限流', { code: 'rate_limit', status, retryable: true, requestId, userMessage: '模型繁忙，请稍后重试或继续使用 Mock' });
  if (status >= 500) return new AIProviderError('模型服务错误', { code: 'server', status, retryable: true, requestId, userMessage: '模型服务暂时不可用，请稍后重试' });
  if (status === 400 || status === 422) return new AIProviderError('请求参数被模型拒绝', { code: 'bad_request', status, retryable: false, requestId, userMessage: '模型拒绝请求：' + text.slice(0, 120) });
  return new AIProviderError('模型请求失败', { code: 'http', status, retryable: status >= 500, requestId, userMessage: '模型请求失败，可尝试 Mock' });
}

/** 系统提示：人机协作、不替用户决定、来源三态、禁止编造 provenance */
export const SYSTEM_PROMPT = [
  '你是「墨证」的画布协作 AI 助手。你的职责是观察、解释、给方向，不直接修改用户原画。',
  '必须输出严格 JSON，不要 Markdown/额外文字。',
  '来源三态：observed（客观可见）、inferred（你的推断，必须标 inferred）、user-confirmed（只能由用户操作产生，你不能输出）。',
  '禁止编造 provenance：不得声称自己看到未提供的内容、不得虚构 L0 原件、不得把 inferred 写成 observed。',
  '每个观察/区域必须有 bbox 或 whole 锚点、description、confidence（0–1）和 evidence（引用已有 L1/L2/L4 id 或 visible 证据）。',
  'bbox 使用画布坐标（与输入 selection 的 x/y/w/h 同一坐标系），格式为 [x, y, w, h] 四个数字；不要用裁切图局部坐标。',
  '只给 2–3 个方向；方向是建议，最终由用户选择。',
].join('\n');

/** 用户上下文（选区截图 + 档案摘要 + 意图）；图片 dataURL 由调用方压缩后传入 */
export function buildAnalyzePrompt(input = {}) {
  const { selection, archive, userIntent, mode, aiRole, live } = input;
  const summary = archive || {};
  const ctx = {
    mode: mode || 'collab',
    ai_role: aiRole || 'assistant',
    user_intent: userIntent || '',
    live_state: live || null,
    selection: selection || null,
    archive_summary: {
      L0: summary.L0 || null,
      L1: summary.L1 || null,
      L2: Array.isArray(summary.L2) ? summary.L2.slice(0, 8) : [],
      L4: Array.isArray(summary.L4) ? summary.L4.slice(0, 8) : [],
      L5: Array.isArray(summary.L5) ? summary.L5.slice(0, 8) : [],
    },
  };
  return [
    { role: 'system', content: SYSTEM_PROMPT },
    { role: 'user', content: [{ type: 'text', text: JSON.stringify(ctx) }] },
  ];
}

function clamp01(v) { const n = Number(v); return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0.5; }
function normAnchor(a) {
  if (a && a.type === 'bbox' && Array.isArray(a.value)) {
    const arr = a.value.slice(0, 4).map((v) => Number(v));
    if (arr.length === 4 && arr.every((v) => Number.isFinite(v))) return { type: 'bbox', value: arr };
  }
  return { type: 'whole', value: null };
}

/** 对 analyze 输出做 schema/provenance 规范化；不合规返回降级默认值 */
export function normalizeAnalyzeResult(raw, meta = {}) {
  const r = raw && typeof raw === 'object' ? raw : {};
  const g = r.global && typeof r.global === 'object' ? r.global : {};
  const regions = (Array.isArray(r.regions) ? r.regions : []).slice(0, 8).map((x, i) => ({
    id: String(x.id || `L2-ai-${i + 1}`),
    label: String(x.label || '区域'),
    bbox: (() => { const bb = Array.isArray(x.bbox) ? x.bbox.slice(0, 4).map((v) => Number(v)) : []; return bb.length === 4 && bb.every((v) => Number.isFinite(v)) ? bb : [0, 0, 1, 1]; })(),
    importance: clamp01(x.importance),
    confidence: clamp01(x.confidence),
    source: 'inferred',
  }));
  const observations = (Array.isArray(r.observations) ? r.observations : []).slice(0, 8).map((x, i) => ({
    id: String(x.id || `L4-ai-${i + 1}`),
    kind: ['observation', 'association', 'question', 'teaching'].includes(x.kind) ? x.kind : 'observation',
    text: String(x.text || x.description || '').slice(0, 500),
    source: 'inferred',
    author: 'ai',
    confidence: clamp01(x.confidence),
    anchor: normAnchor(x.anchor || { type: 'bbox', value: x.bbox }),
    evidenceRefs: Array.isArray(x.evidenceRefs) ? x.evidenceRefs.map(String).slice(0, 8) : [],
    modelVersion: meta.modelVersion || null,
  })).filter((o) => o.text);
  return {
    global: {
      summary: String(g.summary || '').slice(0, 300),
      subject: Array.isArray(g.subject) ? g.subject.map(String).slice(0, 6) : [],
      medium: (() => {
        const M = ['digital_painting', 'watercolor', 'oil', 'ink', 'pencil', 'lineart', 'mixed', 'photography', '3d', 'other'];
        const m = g.medium;
        if (m && typeof m === 'object') { const k = String(m.kind || ''); return { kind: M.includes(k) ? k : 'other', detail: String(m.detail || '').slice(0, 120) }; }
        if (typeof m === 'string' && m) return { kind: 'other', detail: m.slice(0, 120) };
        return { kind: 'other', detail: '' };
      })(),
      palette: (() => {
        const raw = Array.isArray(g.palette) ? g.palette : [];
        const out = [];
        for (const c of raw.slice(0, 8)) {
          const hex = typeof c === 'string' ? c : (c && (c.hex || c.color || c.value)) || '';
          const m = String(hex).trim().match(/^#?([0-9a-fA-F]{6})$/);
          if (!m) continue;
          out.push({ hex: '#' + m[1].toLowerCase(), weight: c && typeof c === 'object' ? Number(c.weight) || 0 : 0 });
        }
        return out;
      })(),
      mood: Array.isArray(g.mood) ? g.mood.map(String).slice(0, 6) : [],
    },
    regions,
    observations,
    confidence: clamp01(r.confidence),
    meta: { ...meta, provider: meta.provider || 'unknown', mode: meta.mode || 'real', mock: false },
  };
}

export function normalizeDirections(raw, meta = {}) {
  const list = (Array.isArray(raw && raw.directions) ? raw.directions : []).slice(0, 3).map((d, i) => ({
    id: String(d.id || `dir-ai-${i + 1}`),
    title: String(d.title || '方向').slice(0, 80),
    why: String(d.why || '').slice(0, 400),
    confidence: clamp01(d.confidence),
    tags: Array.isArray(d.tags) ? d.tags.map(String).slice(0, 6) : [],
    source: 'inferred',
    author: 'ai',
  }));
  return { directions: list, meta: { ...meta, provider: meta.provider || 'unknown', mock: false } };
}

export function normalizeGenerate(raw, meta = {}) {
  const list = (Array.isArray(raw && raw.candidates) ? raw.candidates : []).slice(0, 3).map((c, i) => ({
    id: String(c.id || `cand-ai-${i + 1}`),
    label: String(c.label || `方案 ${String.fromCharCode(65 + i)}`).slice(0, 80),
    why: String(c.why || '').slice(0, 400),
    imageDataUrl: String(c.imageDataUrl || ''),
    sha256: c.sha256 || null,
    bytes: Number(c.bytes) || null,
    width: Number(c.width) || 0,
    height: Number(c.height) || 0,
    source: c.source === 'real' ? 'inferred' : 'inferred',
    author: 'ai',
  })).filter((c) => c.imageDataUrl.startsWith('data:image/'));
  return { candidates: list, meta: { ...meta, provider: meta.provider || 'unknown', mock: false } };
}

/** 历史记录/证据用途：把 provider 结果转为 L4/L5/L6 可写入记录（不伪造 user-confirmed） */
export function toArchiveRecords(result, meta = {}) {
  const records = [];
  for (const o of result.observations || []) {
    records.push({ layer: 'L4', id: o.id, anchor: o.anchor, kind: o.kind, text: o.text, source: 'inferred', author: 'ai', confidence: o.confidence, evidence_refs: o.evidenceRefs, model: { provider: meta.provider, model: meta.modelVersion }, meta: { latencyMs: meta.latencyMs, usage: meta.usage || null } });
  }
  for (const c of result.candidates || []) {
    records.push({ layer: 'L6', kind: 'generation', output_asset_id: c.id, source: 'inferred', author: 'ai', model: { provider: meta.provider, model: meta.modelVersion }, params: { sha256: c.sha256 || null, imageBytes: c.bytes || null }, cost_cny: meta.costCny || 0, credits: meta.credits || 0, meta: { latencyMs: meta.latencyMs, usage: meta.usage || null, billed: meta.billed !== false } });
  }
  return records;
}

/** 本地代理请求助手：超时/重试/取消/错误映射；浏览器不接触 key */
class ProxyClient {
  constructor(opts = {}) {
    this.base = opts.baseUrl || PROXY_BASE;
    this.timeoutMs = opts.timeoutMs || DEFAULT_TIMEOUT_MS;
    this.retries = opts.retries == null ? DEFAULT_RETRIES : opts.retries;
    this.signal = opts.signal || null;
    this.token = opts.token || getLocalAiToken() || null;
    this.confirmReal = !!opts.confirmReal;
  }
  async json(path, body, opts = {}) {
    const attempts = Math.max(0, opts.retries == null ? this.retries : opts.retries);
    let lastErr = null;
    for (let i = 0; i <= attempts; i += 1) {
      const ac = new AbortController();
      const timer = setTimeout(() => ac.abort(new DOMException('timeout', 'TimeoutError')), opts.timeoutMs || this.timeoutMs);
      if (this.signal) this.signal.addEventListener('abort', () => ac.abort(), { once: true });
      try {
        const headers = { 'content-type': 'application/json' };
        if (this.token) headers['x-ai-token'] = this.token;
        if (this.confirmReal) headers['x-ai-confirm'] = 'true';
        const res = await fetch(this.base + path, { method: 'POST', headers, body: JSON.stringify(body), signal: ac.signal });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw mapHttpError(res.status, data, data.requestId);
        return data;
      } catch (e) {
        lastErr = e;
        const aborted = e && (e.name === 'AbortError' || e.name === 'TimeoutError');
        if (aborted && this.signal && this.signal.aborted) throw new AIProviderError('已取消', { code: 'cancelled', userMessage: '已取消 AI 请求' });
        if (aborted) { lastErr = new AIProviderError('AI 请求超时', { code: 'timeout', retryable: true, userMessage: 'AI 请求超时，可重试或使用 Mock' }); }
        const retryable = lastErr && lastErr.retryable;
        if (!retryable || i === attempts) break;
        await new Promise((r) => setTimeout(r, 400 * (i + 1)));
      } finally { clearTimeout(timer); }
    }
    throw lastErr || new AIProviderError('AI 请求失败');
  }
}

/** 抽象接口（各 Provider 实现） */
export class AIProvider {
  constructor(cfg = {}) { this.cfg = cfg; this.client = new ProxyClient(cfg); }
  capabilities() { throw new Error('capabilities() 未实现'); }
  async test() { throw new Error('test() 未实现'); }
  async analyze() { throw new Error('analyze() 未实现'); }
  async converse() { throw new Error('converse() 未实现'); }
  async directions() { throw new Error('directions() 未实现'); }
  async generate() { throw new Error('generate() 未实现'); }
}

export class MockProvider extends AIProvider {
  constructor(cfg = {}) { super(cfg); this.model = MOCK_MODEL; }
  capabilities() { return { provider: 'mock', model: this.model, analyze: true, directions: true, generate: true, vision: false, jsonMode: true, stream: true, imageGen: true, mock: true }; }
  async test() { return { ok: true, provider: 'mock', model: this.model, latencyMs: 0, mock: true }; }
  async analyze(input = {}) {
    const t0 = performance.now();
    const res = mockAnalyze({ canvas: { dataUrl: input.image || '', width: input.width || 1024, height: input.height || 768 }, selection: { ...(input.selection || {}) }, context: input.context || {} });
    res.meta = { provider: 'mock', model: this.model, mode: 'mock', mock: true, latencyMs: Math.round(performance.now() - t0) };
    return res;
  }
  async converse(input = {}) {
    const t0 = performance.now();
    const sel = input.selection || {};
    const analysis = input.analysis || {};
    const intent = input.text || '';
    const hist = Array.isArray(input.history) ? input.history.slice(-30) : [];
    const profile = input.profile || {};
    const lib = input.library || {};
    const archive = input.archive || {};
    const events = Array.isArray(input.events) ? input.events : [];
    const summary = analysis.global && analysis.global.summary ? analysis.global.summary : '当前画面还没有结构化观察。';
    const profileBits = [profile.style ? ('风格「' + String(profile.style).slice(0, 80) + '」') : '', profile.avoid ? ('避免「' + String(profile.avoid).slice(0, 80) + '」') : '', profile.medium ? ('媒介「' + String(profile.medium).slice(0, 60) + '」') : ''].filter(Boolean);
    const libCount = lib.count != null ? lib.count : ((lib.assets || []).length);
    const refs = (lib.referenced || []).map((r) => r.fileName).filter(Boolean).slice(0, 3);
    const text = '（Mock 回答｜多轮记忆已生效）我看到的选区是 ' + Math.round(sel.width || 0) + '×' + Math.round(sel.height || 0) + '；' + summary +
      ' 当前素材库 ' + libCount + ' 张' + (refs.length ? '，本轮带上了参考：' + refs.join('、') : '') + '；档案 ' + ((archive.assets || []).length || archive.total || 0) + ' 条。' +
      (profileBits.length ? ' 我记住的你是：' + profileBits.join('，') + '。' : '') +
      (intent ? ' 你问的是「' + intent + '」。' : '') +
      ' 结合' + (input.images && input.images.length ? '画面和' : '') + '对话上下文，建议先明确“保留什么/只动哪里”，再决定局部生成；真实模型会给出更具体的区域级判断。';
    const usage = { prompt_tokens: 120 + hist.length * 40, completion_tokens: 70, total_tokens: 190 + hist.length * 40 };
    const actions = buildMockActions({ selection: input.selection || null, libraryCount: libCount, referenced: lib.referenced || [] });
    return { text, actions: actions.slice(0, 3), meta: { provider: 'mock', model: this.model, mode: 'mock', mock: true, latencyMs: Math.round(performance.now() - t0), usage } };
  }
  async directions(input = {}) {
    const res = mockDirections({ canvas: { dataUrl: input.image || '', width: input.width || 1024, height: input.height || 768 }, selection: { ...(input.selection || {}) }, context: input.context || {}, observationIds: input.observationIds, count: input.count });
    res.meta = { provider: 'mock', model: this.model, mode: 'mock', mock: true };
    return res;
  }
  async generate(input = {}) {
    const res = mockGenerate({ canvas: { dataUrl: input.image || '', width: input.width || 1024, height: input.height || 768 }, selection: { ...(input.selection || {}) }, directionId: input.directionId, context: input.context || {}, count: input.count, size: input.size });
    res.meta = { provider: 'mock', model: this.model, mode: 'mock', mock: true };
    return res;
  }
  async editImage(input = {}) {
    const res = mockGenerate({ canvas: { dataUrl: input.image || '', width: input.width || 1024, height: input.height || 768 }, selection: { ...(input.selection || {}) }, directionId: 'edit', context: { mode: 'edit', prompt: input.prompt || '' }, count: input.count || 1, size: input.size });
    res.meta = { provider: 'mock', model: this.model, mode: 'mock', mock: true };
    res.candidates = (res.candidates || []).map((c) => ({ ...c, why: 'Mock 占位·未调用模型 · Mock 编辑结果（' + String(input.prompt || '').slice(0, 24) + '）· 可落层继续改' }));
    return res;
  }
}

/** OpenAI-compatible（Moonshot / 自定义）：chat vision + JSON mode；generate 可选图生图端点 */
export class OpenAICompatibleProvider extends AIProvider {
  constructor(cfg = {}) {
    super(cfg);
    const hint = MODEL_HINTS['openai-compatible'];
    this.provider = cfg.provider || 'openai-compatible';
    this.model = cfg.model || hint.model;
    this.baseUrl = cfg.baseUrl || hint.baseUrl;
    this.supportsImageGen = !!(cfg.supportsImageGen || (cfg.provider === 'moonshot' && cfg.imageGen));
  }
  capabilities() { return { provider: this.provider, model: this.model, analyze: true, directions: true, generate: this.supportsImageGen, vision: true, jsonMode: true, stream: true, imageGen: this.supportsImageGen, mock: false }; }
  async test() {
    const t0 = performance.now();
    const r = await this.client.json('/api/ai/health', { provider: this.provider, model: this.model }, { retries: 0 });
    return { ok: !!r.ok, provider: this.provider, model: this.model, latencyMs: Math.round(performance.now() - t0), capabilities: this.capabilities() };
  }
  _messages(input, kind) {
    const msgs = buildAnalyzePrompt(input);
    if (input.image) {
      msgs[1].content.push({ type: 'image_url', image_url: { url: input.image } });
    }
    const instruction = kind === 'analyze'
      ? '输出 JSON：{global:{summary,subject[],medium,palette[],mood[]},regions:[{label,bbox,importance,confidence}],observations:[{kind,text,bbox,confidence,evidenceRefs[]}],confidence}'
      : kind === 'directions'
        ? '输出 JSON：{directions:[{title,why,confidence,tags[]}]}（2–3 个）'
        : '输出 JSON：{candidates:[{label,why,imageDataUrl,width,height}]}（1–3 个）';
    msgs.push({ role: 'system', content: instruction });
    return msgs;
  }
  async _chatJson(input, kind) {
    const t0 = performance.now();
    // 注：官方结构化输出文档建议“不要设置 max_tokens”（截断会产生非法 JSON），
    // 这里保留预算值以控制单次成本；bad_json 已标记 retryable:true，由上层决定重试或降级 Mock
    // （JSON.parse 在 ProxyClient 的 HTTP 重试循环之外，标记可重试不等于自动重试）。
    // stream:false 暂时保留（流式接线由另一条线负责），本次不改变对话/视觉的请求形状。
    const body = {
      provider: this.provider, model: this.model, baseUrl: this.baseUrl, task: kind,
      messages: this._messages(input, kind), response_format: { type: 'json_object' }, stream: false,
      temperature: kind === 'analyze' ? 0.4 : 0.7, max_tokens: kind === 'analyze' ? 1800 : 1200,
    };
    // Qwen3.x 默认 thinking 会让视觉分析等 10–60s；协作场景优先速度，显式关闭（可用 cfg.enableThinking 打开）
    if ((/qwen/i.test(String(this.model || '')) || /dashscope/i.test(String(this.baseUrl || ''))) && this.cfg.enableThinking !== true) {
      body.enable_thinking = false;
    }
    const data = await this.client.json('/api/ai/chat', body, { signal: this.cfg.signal, retries: this.cfg.retries });
    const content = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    let parsed;
    try { parsed = typeof content === 'string' ? JSON.parse(content) : content; } catch (e) { throw new AIProviderError('模型输出不是合法 JSON', { code: 'bad_json', retryable: true, userMessage: '模型输出格式异常，可重试或使用 Mock' }); }
    const meta = { provider: this.provider, model: data.model || this.model, modelVersion: (data.usage && data.usage.model_version) || data.model || this.model, latencyMs: Math.round(performance.now() - t0), usage: data.usage || null, requestId: data.requestId || data.id || null, mode: 'real', mock: false, baseUrl: this.baseUrl };
    return { parsed, meta };
  }
  async analyze(input = {}) { const { parsed, meta } = await this._chatJson(input, 'analyze'); return normalizeAnalyzeResult(parsed, meta); }
  async converse(input = {}) {
    const t0 = performance.now();
    const p = input.profile || {};
    const profileLines = [];
    if (p.style) profileLines.push('风格偏好：' + String(p.style).slice(0, 300));
    if (p.avoid) profileLines.push('避免：' + String(p.avoid).slice(0, 300));
    if (p.medium) profileLines.push('常用媒介/场景：' + String(p.medium).slice(0, 200));
    if (p.notes) profileLines.push('备注：' + String(p.notes).slice(0, 500));
    const sys = '你是「墨证」画布协作 AI，和用户进行长期、连续的多轮协作对话。用中文回答，简洁但有判断力；可以分析、追问、给下一步建议；不要假装直接修改了画布。'
      + '只能依据给定的画布/选区/素材库/档案/L6 记录与对话历史，不编造未提供的内容。'
      + '优先结合用户当前选区、整幅画布、私有素材库和过往决策来回答；如果信息不足，明确说需要看哪一块或哪张素材。'
      + '用户是专业/半专业画师，不要用泛泛的套话；给具体、可执行、能落到画布上的建议。'
      + (profileLines.length ? '【用户画像】' + profileLines.join('；') : '')
      + '输出必须是严格 JSON 对象，格式：{"reply":"中文回答","actions":[{"type":"observe|generate|edit|adjust|reference|annotate|export","label":"短按钮文案","reason":"为什么建议","params":{}}]}。'
      + 'actions 0–3 个，只能建议、不能声称已执行；type 只能是上述枚举。不要 Markdown、不要代码块。';
    const messages = [{ role: 'system', content: sys }];
    const hist = Array.isArray(input.history) ? input.history.slice(-30) : [];
    for (const m of hist) {
      if (!m || !m.role || !m.content) continue;
      if (m.role !== 'user' && m.role !== 'assistant') continue;
      messages.push({ role: m.role, content: String(m.content).slice(0, 4000) });
    }
    const stateJson = {
      question: input.text || '',
      conversation_count: input.context && input.context.conversation_count,
      selection: input.selection || null,
      live_state: input.live || null,
      analysis_summary: input.analysis ? {
        summary: input.analysis.global && input.analysis.global.summary,
        observations: (input.analysis.observations || []).slice(0, 6).map((o) => ({ text: o.text, bbox: o.anchor && o.anchor.value, confidence: o.confidence })),
        regions: (input.analysis.regions || []).slice(0, 6).map((r) => ({ label: r.label, bbox: r.bbox })),
      } : null,
      canvas: input.context && input.context.canvas,
      library: input.library || null,
      archive: input.archive || null,
      recent_events: input.events || null,
      context_flags: input.context && input.context.context_flags,
    };
    const parts = [{ type: 'text', text: JSON.stringify(stateJson) }];
    const imgs = Array.isArray(input.images) ? input.images.filter(Boolean) : (input.image ? [input.image] : []);
    // 与 serve.mjs 的 chat 预算保持一致：最多 4 张图，保持调用方给的顺序（多图语义依赖图序）
    for (const img of imgs.slice(0, 4)) parts.push({ type: 'image_url', image_url: { url: img } });
    messages.push({ role: 'user', content: parts });
    const chatBody = { provider: this.provider, model: this.model, baseUrl: this.baseUrl, task: 'chat', messages, stream: false, temperature: 0.65, max_tokens: 1400 };
    if ((/qwen/i.test(String(this.model || '')) || /dashscope/i.test(String(this.baseUrl || ''))) && this.cfg.enableThinking !== true) chatBody.enable_thinking = false;
    const data = await this.client.json('/api/ai/chat', chatBody, { signal: this.cfg.signal, retries: this.cfg.retries });
    const content = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    const raw = typeof content === 'string' ? content : (content && content.text) || '';
    if (!raw) throw new AIProviderError('对话未返回内容', { code: 'empty_response', userMessage: '模型没有返回对话内容，可重试' });
    let text = raw;
    let actions = [];
    try {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.reply === 'string' && parsed.reply.trim()) {
        text = parsed.reply.trim();
        actions = normalizeChatActions(parsed.actions, { max: 3 });
      }
    } catch (e) { /* 容忍模型不返回 JSON：按普通文本处理 */ }
    return { text, actions, meta: { provider: this.provider, model: data.model || this.model, modelVersion: data.model || this.model, latencyMs: Math.round(performance.now() - t0), usage: data.usage || null, requestId: data.requestId || data.id || null, mode: 'real', mock: false, baseUrl: this.baseUrl } };
  }
  async directions(input = {}) { const { parsed, meta } = await this._chatJson(input, 'directions'); return normalizeDirections(parsed, meta); }
  async generate(input = {}) {
    if (!this.supportsImageGen) throw new AIProviderError('当前 provider 不支持生图，已建议使用 Mock/混元', { code: 'no_image_gen', userMessage: '该模型不支持生成图片，可切换混元生图或使用 Mock' });
    const data = await this.client.json('/api/ai/image', { provider: this.provider, model: this.cfg.imageModel || 'image-gen', task: 'generate', prompt: input.prompt || '', image: input.image || null, size: input.size || '1024x1024', count: input.count || 1 }, { signal: this.cfg.signal });
    return normalizeGenerate(data, { provider: this.provider, modelVersion: data.model || 'image-gen', latencyMs: data.latencyMs || 0, usage: data.usage || null, mode: 'real', mock: false });
  }
}

export class MoonshotProvider extends OpenAICompatibleProvider {
  constructor(cfg = {}) {
    super({ ...cfg, provider: 'moonshot', baseUrl: cfg.baseUrl || MODEL_HINTS.moonshot.baseUrl, model: cfg.model || MODEL_HINTS.moonshot.model });
    this.provider = 'moonshot';
  }
}

/** 混元：chat vision（走 /api/ai/chat），生图走 submit/query（由本地代理签名/轮询） */
export class HunyuanProvider extends OpenAICompatibleProvider {
  constructor(cfg = {}) {
    super({ ...cfg, provider: 'hunyuan', baseUrl: cfg.baseUrl || MODEL_HINTS.hunyuan.baseUrl, model: cfg.model || MODEL_HINTS.hunyuan.model, supportsImageGen: true });
    this.provider = 'hunyuan';
    this.imageModel = cfg.imageModel || 'hunyuan-image-3.0';
  }
  capabilities() { return { provider: 'hunyuan', model: this.model, analyze: true, directions: true, generate: true, vision: true, jsonMode: true, stream: true, imageGen: true, mock: false }; }
  /** T91：混元生图 3.0 同步 OpenAI 风格（TokenHub /images/generations，model hy-image-v3.0）；
   * 本地代理负责串行队列、服务端下载 12h URL、sha256；失败不计费。 */
  async generate(input = {}) {
    const t0 = performance.now();
    const images = Array.isArray(input.images) ? input.images.slice(0, 3) : (input.image ? [input.image] : []);
    const data = await this.client.json('/api/ai/image', {
      provider: 'hunyuan', task: 'generate', model: this.imageModel || 'hy-image-v3.0',
      prompt: input.prompt || (input.direction && input.direction.title) || '',
      images, size: input.size || '1024x1024', count: input.count || 1,
    }, { signal: this.cfg.signal });
    return normalizeGenerate(data, {
      provider: 'hunyuan', modelVersion: data.model || this.imageModel || 'hy-image-v3.0',
      latencyMs: Math.round(performance.now() - t0), usage: data.usage || null,
      mode: 'real', mock: !!data.mock, billed: data.billed !== false,
    });
  }

}

/** Qwen：chat 走 OpenAI 兼容；生图走本地代理 DashScope 异步（submit/poll/下载 sha256） */
export class QwenProvider extends OpenAICompatibleProvider {
  constructor(cfg = {}) {
    super({ ...cfg, provider: 'qwen', baseUrl: cfg.baseUrl || MODEL_HINTS.qwen.baseUrl, model: cfg.model || MODEL_HINTS.qwen.model, supportsImageGen: true });
    this.provider = 'qwen';
    this.imageModel = cfg.imageModel || MODEL_HINTS.qwen.imageModel;
    this.imageEditModel = cfg.imageEditModel || 'qwen-image-3.0-pro';
  }
  capabilities() { return { provider: 'qwen', model: this.model, analyze: true, directions: true, generate: true, edit: true, vision: true, jsonMode: true, stream: true, imageGen: true, imageEdit: true, mock: false, imageProtocol: 'dashscope-async' }; }
  async editImage(input = {}) {
    const t0 = performance.now();
    const refs = (Array.isArray(input.images) && input.images.length ? input.images : (input.image ? [input.image] : [])).slice(0, 4);
    const data = await this.client.json('/api/ai/image', {
      provider: 'qwen', task: 'edit', model: this.imageEditModel,
      prompt: input.prompt || '',
      image: refs[0] || null,
      images: refs,
      size: input.size || '1024x1024', count: input.count || 1,
    }, { signal: this.cfg.signal, retries: 0 });
    return normalizeGenerate(data, {
      provider: 'qwen', modelVersion: data.model || this.imageEditModel,
      latencyMs: Math.round(performance.now() - t0), usage: data.usage || null,
      mode: data.mock ? 'mock' : 'real', mock: !!data.mock, billed: data.billed !== false,
    });
  }
  async generate(input = {}) {
    const t0 = performance.now();
    const images = Array.isArray(input.images) ? input.images.slice(0, 3) : (input.image ? [input.image] : []);
    const data = await this.client.json('/api/ai/image', {
      provider: 'qwen', task: 'generate', model: this.imageModel,
      prompt: input.prompt || (input.direction && input.direction.title) || '',
      images, size: input.size || '1024x1024', count: input.count || 1,
    }, { signal: this.cfg.signal });
    return normalizeGenerate(data, {
      provider: 'qwen', modelVersion: data.model || this.imageModel,
      latencyMs: Math.round(performance.now() - t0), usage: data.usage || null,
      mode: 'real', mock: !!data.mock, billed: data.billed !== false,
    });
  }
}

/** 健康检查/能力探测：后端配置存在且可用时才走真实；否则 mock */
export async function loadAiConfig(fetchImpl = fetch, token = getLocalAiToken()) {
  try {
    const headers = { accept: 'application/json' };
    if (token) headers['x-ai-token'] = token;
    const res = await fetchImpl('/api/ai/config', { headers });
    if (!res.ok) throw new Error('config status ' + res.status);
    return await res.json();
  } catch (e) {
    return { ok: false, mode: 'mock', provider: 'mock', hasKey: false, providers: ['mock'], error: String(e && e.message || e) };
  }
}

/**
 * 工厂：无 key/未知 provider/配置失败 → MockProvider；默认不会发真实请求。
 * @param {{provider?:string, model?:string, apiKey?:string, baseUrl?:string, mode?:string, signal?:AbortSignal, timeoutMs?:number, retries?:number, supportsImageGen?:boolean}} cfg
 */
export function createProvider(cfg = {}) {
  const mode = cfg.mode || 'auto';
  if (mode === 'mock' || cfg.mockOnly) return new MockProvider(cfg);
  const provider = String(cfg.provider || '').toLowerCase();
  const hasKey = !!cfg.apiKey || cfg.hasKey === true;
  if (!hasKey && mode !== 'real') return new MockProvider(cfg);
  if (!hasKey && mode === 'real') throw new AIProviderError('未配置真实模型密钥', { code: 'no_key', userMessage: '未配置模型密钥，请使用 Mock 或先在本地配置' });
  if (provider === 'moonshot' || provider === 'kimi') return new MoonshotProvider(cfg);
  if (provider === 'hunyuan' || provider === 'tencent') return new HunyuanProvider(cfg);
  if (provider === 'qwen' || provider === 'dashscope') return new QwenProvider(cfg);
  if (provider === 'openai-compatible' || provider === 'custom') return new OpenAICompatibleProvider({ ...cfg, provider: 'openai-compatible' });
  return new MockProvider(cfg);
}

export const AVAILABLE_PROVIDERS = ['mock', 'moonshot', 'hunyuan', 'qwen', 'openai-compatible'];

/** T99：读取本地注入 token（window 注入优先；兼容 HttpOnly/SameSite cookie 名） */
export function getLocalAiToken() {
  if (typeof window !== 'undefined' && typeof window.__AI_LOCAL_TOKEN__ === 'string' && window.__AI_LOCAL_TOKEN__) return window.__AI_LOCAL_TOKEN__;
  if (typeof document !== 'undefined' && typeof document.cookie === 'string') {
    const m = /(?:^|;\s*)mozheng_ai_token=([^;]+)/.exec(document.cookie);
    if (m) return decodeURIComponent(m[1]);
  }
  return null;
}
