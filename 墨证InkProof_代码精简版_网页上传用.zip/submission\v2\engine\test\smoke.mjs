#!/usr/bin/env node
// v2/engine/test/smoke.mjs —— 零依赖 CDP 冒烟测试（无头 Chrome）
// 用法：node v2/engine/test/smoke.mjs <pageUrl> [port]
// 前置：静态服务器 + Chrome --headless=new --remote-debugging-port=9333 <pageUrl>
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}

const page = await findPage();
if (!page) {
  console.error('smoke: 找不到 demo 页面（检查静态服务器/Chrome 参数）');
  process.exit(2);
}
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = reject; });
let seq = 0;
const pending = new Map();
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
};
const send = (method, params) => new Promise((resolve) => {
  const id = ++seq;
  pending.set(id, resolve);
  ws.send(JSON.stringify({ id, method, params }));
});

const expression = `new Promise(async (resolve) => {
  const t0 = Date.now();
  const waitReady = async () => {
    while (!window.__V2_READY__) {
      if (Date.now() - t0 > 20000) throw new Error('init timeout');
      await new Promise((r) => setTimeout(r, 200));
    }
  };
  try {
    await waitReady();
    const eng = window.__V2__;
    const out = { ready: true, steps: {} };
    const raf = () => new Promise((r) => requestAnimationFrame(r));
    // 1) 3 笔
    for (let s = 0; s < 3; s += 1) {
      eng.beginStroke({ x: 400 + s * 60, y: 700, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
      for (let i = 0; i < 40; i += 1) {
        eng.appendPoint({ x: 400 + s * 60 + i * 6, y: 700 + Math.sin(i / 6) * 80, pressure: 0.4 + (i % 10) / 20, timestamp: performance.now(), pointerType: 'synthetic' });
      }
      eng.endStroke();
      await raf();
    }
    out.steps.draw = eng.getStats();
    // 2) 5 混合模式
    const modes = ['normal', 'multiply', 'screen', 'overlay', 'soft-light'];
    for (const m of modes) eng.setLayerBlend(eng.activeLayerId, m);
    eng.setLayerBlend(eng.activeLayerId, 'normal');
    out.steps.blend = 'ok';
    // 3) undo/redo
    const before = eng.getStats();
    eng.undo(); eng.undo(); eng.redo();
    out.steps.undo = { depthBefore: before.undoDepth, depthAfter: eng.getStats().undoDepth };
    // 4) T41：自定义 provider 注入（上下文透传 + 绘制 + undo）
    const seen = [];
    let customPaint = null;
    const customProvider = {
      id: 'smoke-provider',
      begin(ctx) { seen.push({ phase: 'begin', brush: ctx.brush.type }); },
      radiusFor(ctx) { void ctx; return 10; },
      paintFor(ctx) {
        if (!customPaint) {
          customPaint = new ctx.CK.Paint();
          customPaint.setAntiAlias(true);
          customPaint.setStyle(ctx.CK.PaintStyle.Fill);
          customPaint.setColor(ctx.CK.Color(220, 40, 40, 0.8));
        }
        return customPaint;
      },
      stampFor(ctx) {
        seen.push({ phase: 'stamp', isTile: ctx.isTile, pressure: ctx.pressure, tiltX: ctx.tiltX, tiltY: ctx.tiltY, velocity: ctx.velocity, timestamp: ctx.timestamp, coalescedIndex: ctx.coalescedIndex, coalescedCount: ctx.coalescedCount, pointerType: ctx.pointerType, worldX: ctx.worldX, worldY: ctx.worldY });
        ctx.canvas.drawCircle(ctx.x, ctx.y, ctx.radius, ctx.paint);
      },
      end(ctx) { seen.push({ phase: 'end', cancelled: !!ctx.cancelled }); },
    };
    const prevProvider = eng.setBrushProvider(customProvider);
    const depthBeforeProvider = eng.getStats().undoDepth;
    eng.beginStroke({ x: 900, y: 900, pressure: 0.35, tiltX: 15, tiltY: -8, timestamp: performance.now(), pointerType: 'pen' });
    for (let i = 0; i < 12; i += 1) {
      eng.appendPoint({ x: 900 + i * 8, y: 900 + Math.sin(i / 4) * 30, pressure: 0.35, tiltX: 15, tiltY: -8, timestamp: performance.now(), pointerType: 'pen' }, { coalescedIndex: i % 4, coalescedCount: 4 });
    }
    eng.endStroke();
    const providerStats = eng.getStats();
    eng.undo();
    eng.redo();
    eng.setBrushProvider(prevProvider);
    const stamps = seen.filter((x) => x.phase === 'stamp');
    const allFields = stamps.length > 0 && stamps.every((x) => Number.isFinite(x.pressure) && Number.isFinite(x.tiltX) && Number.isFinite(x.tiltY) && Number.isFinite(x.velocity) && Number.isFinite(x.timestamp) && Number.isFinite(x.coalescedIndex) && Number.isFinite(x.coalescedCount) && typeof x.pointerType === 'string');
    out.steps.provider = {
      providerId: providerStats.brushProvider,
      begin: seen.some((x) => x.phase === 'begin'),
      end: seen.some((x) => x.phase === 'end'),
      stamps: stamps.length,
      liveStamps: stamps.filter((x) => !x.isTile).length,
      tileStamps: stamps.filter((x) => x.isTile).length,
      allFields,
      undoDepthBefore: depthBeforeProvider,
      undoDepthAfter: providerStats.undoDepth,
    };

    // 5) PNG 合成
    const url = await eng.getCompositeDataUrl();
    out.steps.pngBytes = Math.round(url.length * 0.75);
    out.steps.pngOk = url.startsWith('data:image/png;base64,') && out.steps.pngBytes > 1000;
    // 5) benchmark（短）
    const bench = await eng.runBench({ durationMs: 1500 });
    out.steps.bench = bench.cases[0].summary;
    out.steps.statsAfter = eng.getStats();
    out.ok = out.steps.pngOk && out.steps.draw.tileCount > 0 && out.steps.undo.depthAfter === 2
      && out.steps.provider.allFields && out.steps.provider.stamps > 0
      && out.steps.provider.tileStamps > 0 && out.steps.provider.begin && out.steps.provider.end;
    resolve(out);
  } catch (e) {
    resolve({ ready: false, error: String(e && e.stack || e) });
  }
})`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 120000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) {
  console.error('smoke: 无返回', JSON.stringify(r).slice(0, 1500));
  process.exit(3);
}
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('write results failed:', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
