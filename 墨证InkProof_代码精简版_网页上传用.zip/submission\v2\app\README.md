# v2/app · 墨证 InkProof v2 应用（T40）

> 状态：M4.2 应用接回（T40 完成）｜写入范围：`v2/app/`（另改 `v2/start.bat` 默认打开本应用，未改 `v2/engine/`）
> 技术底座：`v2/engine`（CanvasKit + tile 位图层）+ `v2/brushes`（T36 十笔刷 / T41 StrokePaintProvider 注入）
> 产品逻辑/数据模型：沿用 v0.1；`core/` 三个模块**复制自 `product/core/`**（archive-schema / hash-chain / mock-ai），来源已注明，v0.1 保持冻结。

## 运行

```powershell
# 方式 1（推荐）：双击 v2\start.bat —— 自动起本地服务并打开本应用
# 方式 2：
node v2/serve.mjs
# 浏览器打开 http://127.0.0.1:4200/v2/app/index.html
```

必须 HTTP（WASM 不支持 file://）；Chrome/Edge（WebGL2 + WASM）；零外部网络请求。

## 已实现

| 模块 | 内容 |
|---|---|
| 画布 | v2 engine 1200×800、tile 位图层；画笔/橡皮；框选；撤销/重做（engine tile patch undo） |
| 工具条 | 画笔 B / 橡皮 E / 框选 R / 移动 M、颜色、粗细、撤销重做、让 AI 看看 K、不参与档案 |
| 图层面板 | 新建/删除/上移/下移/显示隐藏/混合模式（normal·multiply·screen·overlay·soft-light）/不透明度/点击切换 |
| 笔刷面板 | T36 十种笔刷切换 + 大小/硬度/不透明度实时调参（纹理/动态由 provider 生效） |
| 档案 L0–L6 | L0 画布来源；L1 整体档案；L2 区域；L4 观察（可确认/否决，写回 L5 决策）；L5 决策；L6 AI 生成/导出/模式切换 |
| 卡住协作 mock | 框选 → 让 AI 看看（mockAnalyze）→ 观察卡确认/否决 → 2 个方向（mockDirections）→ 生成候选（mockGenerate）→ 落为新图层 → L6 记录 |
| 证据包 | JSON + PNG + manifest：事件 SHA-256 链、画布/图层摘要、zero_generation；可下载 JSON/PNG 或一键导出 |
| 存证模式 | 禁用 AI；证据包 zero_generation=true；写 L6 mode_change；顶栏/状态栏标识 |
| 一键演示 | 8 步自动播放（暂停/上一步/下一步/退出/接管暂停），真实驱动画布+AI+档案+证据包 |
| 持久化 | localStorage：档案记录 + 模式；画布快照 PNG（刷新后恢复为「恢复快照」图层） |

## 与 v0.1 的差异 / 数据迁移

- **渲染底层**：v0.1 Canvas2D 图层 → v2 CanvasKit tile 位图层 + T36 笔刷 provider。
- **档案 schema**：直接复用 v0.1 `archive-schema.mjs` v0.2.0（记录字段/校验一致）；`hash-chain.mjs` 复用 SHA-256 canonical JSON 链；`mock-ai.mjs` 复用确定性 Mock。旧 v0.1 档案记录（schema 0.1/0.2）可被同 schema 校验；本应用未提供 v0.1 IndexedDB 导入 UI。
- **证据包格式**：v0.1 为 JSON+PNG 分开导出；v2 为单 JSON 内嵌 PNG dataURL + manifest（仍可单独下载 PNG）。
- **持久化**：v0.1 IndexedDB 项目/图层 → v2 localStorage 档案 + 画布快照 PNG（无项目序列化，见限制）。
- **图层能力**：v2 面板为基本图层操作；v0.1 的图层组/蒙版/PSD 未接回（M4.3/M4.4）。
- **一键演示**：保持 8 步主流程，实现更轻量（画布/AI/档案/证据真实联动）。
- **UI 视觉资产**：css/tokens.css、css/app.css、js/icons.js 复用自 v0.1（v0.1 保持冻结；v2 的 HTML/JS 逻辑全部重写）。

## T41 笔刷接口收债（适配结果 + 回归）

1. **移除 `BrushStroke` 子类**（原 T36 通过子类化 `Stroke` 实现逐 stamp 参数）；`v2/brushes/src/brush-controller.js` 现导出 `createProviderFromPreset()`，实现 engine 的 `StrokePaintProvider`：
   - `radiusFor(ctx)`：压力/速度/倾斜/起笔收锋（`ctx.distance`）；
   - `paintFor(ctx)`：硬度 blur、纹理 shader + Modulate、擦除 Clear、速度/倾斜透明度；
   - `stampFor(ctx)`：drawCircle；`begin/end/cancel/dispose` 齐全。
   - `BrushController` 保留预处理：稳定化 EMA → 间距重采样 → 散射 → `engine.beginStroke/appendPoint/endStroke`；笔画事务/undo 全由 engine 负责。
2. **回归结果**（`v2/app/test-result.json`，零 console error）：
   - engine **默认 provider**（v2/engine/demo.html）：绘制 undoBefore 0 → undoAfterDraw 1 → undoAfterUndo 0；tiles 4 ✅ 不回归；
   - **自定义 provider**（T36 demo）：10 种笔刷全部可绘，undoDepth 10、undo 后 9 ✅；
   - v2/app 全流程：绘制/加层/AI 分析（4 obs、2 regions、8 记录）/确认（L5+1）/方向 2/候选 2/落层/L6/证据包（10 事件、链头、5 图层摘要、PNG）/存证模式/演示 8 步启动与退出 ✅；
   - 刷新后：档案 12→12、图层恢复出「恢复快照」✅。
3. **新增限制**：engine 的 `provider.end(ctx)` 不提供 canvas/store，**收笔收锋本轮无法在提交前重绘**（起笔收锋保留）；已在 `v2/brushes/README.md` 记录，建议 M4.2 后续扩展 end 画布能力。

## 测试

```powershell
node v2/app/test-app.mjs    # 零依赖 CDP：默认/自定义 provider 回归 + app 主流程 + 刷新持久化
# 结果：bench 无，见 v2/app/test-result.json；截图 v2/app/app-screenshot.png；画布快照 v2/app/app-canvas.png
```

## 已知限制（M4.2）

1. 无项目级序列化/PSD：刷新恢复依赖画布 PNG 快照，图层结构不保留（M4.4 PSD/项目文件）；
2. 图层删除为 app 级 tile 清理，**不可 undo**；无图层组/蒙版/16 混合（M4.3）；
3. 一键演示期间会改写当前画布；退出时按快照恢复（档案记录恢复为演示前副本），演示中途刷新不做特殊处理；
4. 演示/AI 均为本地 Mock（确定性规则），无真实模型/网络；证据包为演示格式，非 C2PA 生产实现；
5. 未做缩放/平移/触屏手势；画布固定 fit；headless 截图下 WebGL 画面可能空白（浏览器实际可见）；
6. 橡皮为 tile 层 Clear；跨图层擦除/保护、Alpha Lock 等未接。

## 许可

- 本目录自研代码：项目内使用（随仓库 LICENSE 统一）。
- `core/` 三模块复制自 `product/core/`（本项目自研，v0.1 冻结），保留原 schema/语义。
- CanvasKit/Skia：BSD-3-Clause，来自 `v2/engine/vendor/`（见其 LICENSE / THIRD_PARTY_NOTICES）；无 GPL。

## 已知问题 / 排查（P0）

### 症状：页面能打开，但画不出 / 按钮没反应

**最常见原因：用 file:// 直接双击 HTML 打开。** 浏览器安全策略会拦截 CanvasKit WASM 与 ES Module 加载，页面能显示但引擎不工作。
- ✅ 正确方式：双击 **v2\start.bat**（起本地服务并打开 http://127.0.0.1:4200/...），或手动 `node v2/serve.mjs`。
- 页面已内置 **file:// 红色遮挡横幅**（提示改用 start.bat，并可一键尝试本地服务地址）；即使 ESM 被拦截也能显示。
- 其他页面（brushes/engine demo）同理，需通过本地服务打开。

### 排查工具

| 入口 | 用途 |
|---|---|
| `v2/app/index.html?debug=1` | 右下角 debug 角标：engine.ready / CanvasKit / provider / pointerdown 计数 / strokes / undo / tiles / records / lastError |
| `v2/diag.html` | CanvasKit / WebGL2 / WASM / 环境自检（start.bat 会一并打开） |
| 页面顶部红色错误条 | 初始化失败、window error、unhandled rejection、10 秒初始化超时会显示（不再只写状态栏） |

### 判断步骤

1. 看页面顶部是否有红条 / file:// 横幅：有 → 按提示用 start.bat；
2. 打开 `?debug=1`：`engine.ready=false` 或 `CanvasKit=NULL` → 初始化失败（看红条/Console/诊断页）；
3. `engine.ready=true` 但 `pointerdown=0` → pointer 事件没到 canvas（检查是否有遮挡/缩放；把截图和 debug 角标发给开发）；
4. `pointerdown>0` 但 `strokes=0` → 笔刷/引擎问题（app 侧记录 debug，联系开发）。

### 真实 Edge 手动测试记录（2026-11-06）

- 环境：**Microsoft Edge 156（非 headless，真实窗口）** + Windows 11 + RTX 4060，OS 硬件鼠标。
- 方式：真实鼠标按住拖动（OS SendInput 绝对坐标，非 CDP 合成）→ **出线**：pointerdown=2 / strokes=2 / undo=2 / tiles=4，0 console error；CDP 可信输入同样出线（pixels dark=10001）。
- file:// 直接打开：显示红色横幅阻止误用；http 加载：`__V2_APP_READY__=true`、CanvasKit=OK。
- 结果已写入 `test-result.json.edgeManualTest`；截图 `edge-screenshot.png` / `edge-os-screenshot.png`。

### P2 修复记录（QA 002 §4）

- file:// 横幅与初始化超时提示里的 `v2\start.bat` 反斜杠曾被模板字符串/字符串转义吞掉（显示成 `v2start.bat`）；已改为源码双反斜杠（HTML 显示为单反斜杠 `v2\start.bat`），并已用 headless Chrome file:// 打开验证显示正确。

### 橡皮工具修复（brush-engineer 报告 / T43-T44）

- **问题**：`setTool('eraser')` 只改 `state.tool`、不切 preset → 按 E 后仍用当前画笔绘制；切回 B 也不恢复上次画笔。
- **修复**（v2/app/js/app.js）：
  - `setTool('eraser')`：查找 `presets.brushes` 中 `engine.eraser === true` 的预设（当前为 index 9 橡皮）并 `controller.setPreset()`，状态栏显示「橡皮（擦除）」；
  - `setTool('brush')`：用 `state.brushIndex` 恢复上次画笔 preset；画笔面板同时高亮当前预设（`activePresetId`）；
  - 新增 `applyPreset()` 统一 UI/预设切换；画笔 chip 点击与键盘 B/E 走同一路径。
- **回归（v2/app/test-eraser.mjs，headless Chrome + CDP 真实 pointer/keyboard，0 console error）**：
  - 按 E → provider `t36-eraser`；鼠标拖拽擦除后深色像素 27452 → 26636（可见擦除）、undo +1；
  - 按 B → provider 恢复 `t36-hard-round`、状态栏「硬边圆笔」；
  - 选水彩 → E → B → provider 恢复 `t36-watercolor`；
  - 结果：`test-eraser-result.json` / `test-result.json.eraserToolFix`，截图 `eraser-test-screenshot.png`。

### 模拟压感面板（T55）

- **UI 位置**：右侧「笔刷」面板 → 笔刷参数下方「模拟压感 · 鼠标」区块（开关 / 强度 0–2 / 曲线 线性·柔和·强烈 / 平滑 0–300ms / 说明文案）。
- **默认值**（与 T54 DEFAULT_SIMULATED_PRESSURE 对齐）：启用、强度 1.00、柔和、45ms。
- **接口**：调用 controller.setSimulatedPressure({ enabled, strength, curve, smoothingMs })（T54）；若接口缺失面板会显示"等待 T54"并降级但不报错。
- **持久化**：localStorage['mozheng.v2.simPressure.v1']；切换笔刷 / 橡皮、刷新页面均保留；启动时自动应用。
- **headless 回归**（v2/app/test-pressure-panel.mjs，1366×768，CDP 真实 pointer，T54 接口已 frozen，0 console error）：
  - 面板/开关/强度/曲线/平滑均存在；页面 scrollWidth=1366、scrollHeight=768（无横向/页面溢出，侧栏可滚动）；
  - 调参写入 localStorage；切橡皮（provider t36-eraser）后配置不丢；刷新后 UI/localStorage 一致；
  - **同一条「先快后慢」笔迹**：关闭 CV=0.066、中位宽 24px → 开启（强度 2 / strong / 45ms）**CV=0.365–0.398、均值宽 22.3–20.8px**（多轮波动），粗细变化显著；截图 pressure-panel-1366.png。
- 结果：test-result.json.simPressurePanel、test-pressure-panel-result.json。

## Procreate 式布局（T58，依据 `05-交互/v2布局规格_速版.md` §9）

- **画布优先**：取消固定右栏；画布居中、近全屏（1920 下 1437×958），深色画布台 + 白画布 + 投影。
- **顶部工具条 48px**：`[画笔][涂抹][橡皮] ｜ [选区][变换] ｜ [图层][颜色] ｜ [演示][AI] ｜ [更多]`；全宽度统一图标 + tooltip；中央作品名 + 保存点；版本号/存证说明收进「更多 / 设置」。
- **左侧竖排 56px（1366 52px）**：size 滑杆（数值在上）→ 吸管按钮 36×36 → opacity 滑杆；滑杆长度 160/150/120；双击复位（size 18 / opacity 100%），滚轮 ±1（Shift ±10）。
- **浮层**：图层 340（1366 320）、笔刷 360（1366 340）、颜色 300、AI 360（1366 340）、更多 240/220；row 40；“同一时间最多一个浮层”，点外**只关闭不落笔**，Esc 关闭，打开聚焦首个控件，120ms 淡入，`role="dialog" aria-modal="false"`。
- **AI = 3 tab**：观察 / 档案 / 证据；存证模式 chip 在底栏；「让 AI 看看」「不参与档案」「档案记录」保留在 AI 浮层；模拟压感收进笔刷浮层（T55 复用）。
- **底部状态栏 28px（1366 26px）**：撤销/重做 + 缩放（双击 100%）；中间单行上下文提示；右侧 事件 / 图层 / 笔触 / AI 状态 / 哈希 / 协作·存证 chip；1366 隐藏次要文字。
- **快捷键（§9.5）**：B/E 画笔·橡皮；M 矩形选区（L 自由选区、Shift+M 椭圆为 M4.3 占位提示）；V 变换、H 移动（空格拖移）、I 吸管；Ctrl+Z / Ctrl+Shift+Z；`[` `]` 大小、Ctrl+`[` `]` 透明度；0 适配 / 1 100% / ± 缩放；F 全屏；Tab 隐藏 UI；? 帮助；Ctrl+S 快照；Ctrl+Shift+E 证据；滚轮以光标为中心缩放；Esc 浮层优先。
- **字体/文案**：常驻 UI 最小 12px；去掉 A1–A7 / M4.2 / 大段 mock 文案（版本号在设置里）。

**T58 验收（headless，三档）**：1920×1080 / 1536×864 / 1366×768 均无横向/纵向溢出、无固定右栏、底栏完整可见；画布目标 1920 ≥1400×930（实测 1437×958）、1366 ≥980×650（实测 996×664）；浮层单开、点外关闭不落笔、快捷键 B/M/V/]/Esc 通过；`test-app.mjs` 全流程回归、`test-pressure-panel.mjs` 模拟压感回归均通过（0 console error）。截图：`ui-1920.png` / `ui-1536.png` / `ui-1366.png`。

**剩余差异（M4.3 接引擎后补）**：涂抹 S、自由套索 L、椭圆选区 Shift+M、移动 H 画笔器、变换提交为占位；缩放/平移为简化实现（空格拖移 + 滚轮），未做旋转；AI 证据 tab 为摘要+打开证据包，底层导出复用原证据包。

### T58 视觉 polish（Lead 验收反馈）

- **顶栏图标**：改用 Lucide 内联 SVG（18–20px，`currentColor`，默认 78% 不透明度，hover/active 100%）；画笔/涂抹/橡皮｜选区/变换｜图层/颜色｜演示/AI｜更多 分组 8px；窄屏 32px 命中区；全部 tooltip。
- **左栏滑杆**：6px 圆角轨道 + 20px 滑点；数值 12px 在轨道上方、间距 8px；`[ ]`/Ctrl+[ ]/双击复位/滚轮微调保留。
- **底栏**：撤销/重做统一 18px 图标。
- **空态提示**：从画布左下移到**底栏上方居中**胶囊，不压画布边。
- 复测：三档截图重出（`ui-1920.png` / `ui-1536.png` / `ui-1366.png`）；`test-ui.mjs` 三档 0 overflow、canvas 1437×958 / 1113×742 / 996×664、minFont 12、单浮层/点外不落笔/快捷键通过；`test-app.mjs` 全流程回归 0 console error。

### §12 P1 polish（ux 复核）

- 浮层内部字号统一 ≥12px（mock 徽章/副标题/按钮/参数行/更多分组）。
- 左侧滑杆自定义：4px 深色圆角轨 + 16px 蓝点，数值 12px 在上、间距 8px（双击复位/滚轮微调保留）。
- 涂抹禁用态 45% + 「待接入」角标。
- 底栏右组状态用 `·` 分隔；哈希只显 8 位（tooltip 全值）；按宽度分级隐藏（≤1500 隐藏笔触/AI，≤1366 隐藏事件/哈希）。
- 模式开关 84×22 分段控件 + `aria-pressed`。
- 撤销/重做命中区 28×24、图标 16px。
- 浮层 120ms 动画；`max-height` 扣顶栏/底栏（JS 也按底栏高度扣减）。
- 图层浮层 header 显示「当前层数/30」（不再用 L，避免与套索快捷键冲突）。
- 复测：`test-ui.mjs` P1 全项通过（popover minFont 12、mode 84×22+aria、smudge .45+角标、undo 28×24、transition 0.12s、layer header 2/30）；三档截图重出；`test-app.mjs` 回归 0 console error。

## 图层浮层升级 / 项目保存 / PSD（T61，基于 T60 V2Doc）

- **图层面板（340px 浮层）**：
  - 组（1 级）：新建组、拖图层入组/拖出组、折叠展开、组可见性、组不透明度、删除组（保留图层）；
  - 蒙版：添加/删除/启用停用/**应用蒙版**/「画在蒙版」目标切换（白显示黑隐藏）；行内 M 标记；
  - 剪贴、锁定、16 混合模式（分组下拉：正常/变暗/变亮/对比/差值/颜色）、图层不透明度、组分配；
  - 操作：新建、复制、上移/下移、向下合并、拼合全部、删除；lock 时笔触不生效；
  - header 显示「当前图层数/30」；行内 40px、缩略图占位、组行折叠。
- **项目保存/打开（.mozheng）**：
  - 更多 → 保存项目：下载 UTF-8 JSON（format/version/doc + 每层 tile PNG base64 + masks）；文件名 inkproof-YYYYMMDD-HHmm.mozheng；
  - 更多 → 打开项目 / 拖入 .mozheng / .json：校验 format、version≤1、doc.layers，失败给可读 Toast；
  - 自动保存：IndexedDB（mozheng.v2.projects）1.2s 防抖，刷新自动恢复完整图层结构（组/蒙版/剪贴/混合/像素 tile）；无自动保存时回退旧 PNG 快照。
- **PSD**（ag-psd MIT，v2/psd/vendor 本地加载）：
  - 更多 → 导入 PSD / 拖入：importPsd → psdDocToV2Doc → engine.deserializeDoc 后逐层写 tile/蒙版；保真差异摘要 Toast；
  - 更多 → 导出 PSD：逐层从 tile store 渲染 canvas → exporter（结构/组/混合/剪贴/蒙版）；尺寸不同时缩放到当前 1200×800；
- **涂抹按钮**：T62 完成后已启用，点击 controller.setMode('smudge')，再点/切画笔 setMode('brush')。
- **测试**：
  - v2/app/test-layer-doc.mjs（headless，1366×768）：图层组/蒙版/剪贴/16 混合/锁定 全过；画一笔后 .mozheng 保存→打开 tile 往返（tiles=2、PNG 24KB）；IndexedDB 自动保存→刷新恢复 3 图层/1 组/1 蒙版；PSD 导出 298KB→重新导入 3 图层/1 组，0 error；
  - test-app.mjs 全流程回归 0 error；test-ui.mjs 三档布局/P1 全过；
  - 截图：ui-layer-1920.png / ui-layer-1536.png / ui-layer-1366.png（三档），基础 ui-1920/1536/1366.png。
- **已知限制**：Alpha Lock 引擎无接口（仅锁定）；组蒙版/组剪贴/嵌套组不支持；PSD 非 8-bit/文字/样式等按 fidelity 记录；.mozheng 整 tile PNG 未做 bbox 裁剪/压缩；保存不含 undo 历史。

## 图层浮层升级 / 项目保存 / PSD（T61，基于 T60 V2Doc）

- **图层面板（340px 浮层）**：
  - 组（1 级）：新建组、拖图层入组/拖出组、折叠展开、组可见性、组不透明度、删除组（保留图层）；
  - 蒙版：添加/删除/启用停用/**应用蒙版**/「画在蒙版」目标切换（白显示黑隐藏）；行内 M 标记；
  - 剪贴、锁定、16 混合模式（分组下拉：正常/变暗/变亮/对比/差值/颜色）、图层不透明度、组分配；
  - 操作：新建、复制、上移/下移、向下合并、拼合全部、删除；lock 时笔触不生效；
  - header 显示「当前图层数/30」；行内 40px、缩略图占位、组行折叠。
- **项目保存/打开（.mozheng）**：
  - 更多 → 保存项目：下载 UTF-8 JSON（format/version/doc + 每层 tile PNG base64 + masks）；文件名 inkproof-YYYYMMDD-HHmm.mozheng；
  - 更多 → 打开项目 / 拖入 .mozheng / .json：校验 format、version≤1、doc.layers，失败给可读 Toast；
  - 自动保存：IndexedDB（mozheng.v2.projects）1.2s 防抖，刷新自动恢复完整图层结构（组/蒙版/剪贴/混合/像素 tile）；无自动保存时回退旧 PNG 快照。
- **PSD**（ag-psd MIT，v2/psd/vendor 本地加载）：
  - 更多 → 导入 PSD / 拖入：importPsd → psdDocToV2Doc → engine.deserializeDoc 后逐层写 tile/蒙版；保真差异摘要 Toast；
  - 更多 → 导出 PSD：逐层从 tile store 渲染 canvas → exporter（结构/组/混合/剪贴/蒙版）；尺寸不同时缩放到当前 1200×800；
- **涂抹按钮**：T62 完成后已启用，点击 controller.setMode('smudge')，再点/切画笔 setMode('brush')。
- **测试**：
  - v2/app/test-layer-doc.mjs（headless，1366×768）：图层组/蒙版/剪贴/16 混合/锁定 全过；画一笔后 .mozheng 保存→打开 tile 往返（tiles=2、PNG 24KB）；IndexedDB 自动保存→刷新恢复 3 图层/1 组/1 蒙版；PSD 导出 298KB→重新导入 3 图层/1 组，0 error；
  - test-app.mjs 全流程回归 0 error；test-ui.mjs 三档布局/P1 全过；
  - 截图：ui-layer-1920.png / ui-layer-1536.png / ui-layer-1366.png（三档），基础 ui-1920/1536/1366.png。
- **已知限制**：Alpha Lock 引擎无接口（仅锁定）；组蒙版/组剪贴/嵌套组不支持；PSD 非 8-bit/文字/样式等按 fidelity 记录；.mozheng 整 tile PNG 未做 bbox 裁剪/压缩；保存不含 undo 历史。

## T64 工具接入（涂抹 / 选区 / 变换 / 结构 undo）

- **涂抹**：顶栏「涂抹」按钮调用 controller.setMode('smudge')，再点画笔恢复（T62）。修复：setupBrushInput() 原先只对 brush/eraser 绑定输入，涂抹有模式但无 pointer 输入 → 已加 smudge。
- **选区**（顶栏「选区」+ 选项条）：
  - 矩形（M）/ 椭圆（Shift+M）/ 自由套索（L）/ 魔棒（W）；布尔 新选区/添加/减去/相交；羽化 0–50；反选、取消（Ctrl+D）；
  - SelectionManager 蚂蚁线独立 overlay；选区 mask 交给 engine setSelectionImage，笔触/擦除提交时按 alpha DstIn 约束（选区外不落笔）；
  - AI 的「框选 → 让 AI 看看」沿用 state.selection。
- **变换**（顶栏「变换」+ 选项条）：
  - 9 个手柄（8 缩放 + 旋转），Shift 旋转 15° 吸附；拖手柄缩放/旋转，拖内部平移；H/V 翻转；Enter 提交 = 1 步 image undo；Esc 取消；
  - 覆盖层实时绘制包围框/手柄/角度；选区存在时只变换选区内像素（T63）。
- **图层结构操作**：新建/删除/复制/上下移/合并/拼合/建组/移组全部改为 engine API，与笔触、变换共享同一 UndoManager，底栏 undo/redo 可直接撤销。
- **快捷键**：M / Shift+M / L 切选区，V 变换，Enter 提交，Esc 取消（优先变换），Ctrl+D 取消选区；Ctrl+Z/Shift+Z 通用。
- **测试**：v2/app/test-tools.mjs（Playwright-core，channel msedge，headless，硬超时 180s）全过：涂抹模式 + 像素变化、选区建立 + 选区外约束 + Ctrl+D 清除、变换 9 手柄 + 提交 undo、结构新建/复制 undo/redo、三档无溢出；test-app.mjs 全流程 0 error；test-ui.mjs 三档通过。
- 截图：ui-tools-1920.png / ui-tools-1536.png / ui-tools-1366.png。
- 限制：套索为多边形线段（无曲线拟合）；魔棒 512 降采样近似；变换预览为包围框/手柄（不预览像素）；选区不约束蒙版笔触；Alpha Lock 等 T65。

## T68 组蒙版 / 组剪贴（app 接入，T67 引擎）

- **组行**：组蒙版缩略图/徽章（M）、组蒙版按钮（新建并进入编辑 / 编辑中✓）、组剪贴按钮（C✓）；组详情面板：编辑组蒙版、启用/停用、应用组蒙版、删除组蒙版、组剪贴开关、组显隐/不透明度。
- **编辑目标**：点组蒙版按钮 → engine.setActiveGroup(gid) + setActiveTarget('group-mask')，状态栏提示「正在编辑组蒙版：白显示/黑隐藏」；点图层行或再点按钮退出。
- **蒙版笔触修复**：brush-controller 的 append/end 只处理 engine.currentStroke，图层/组蒙版笔触此前无法提交。T68 新增 attachMaskInput()：蒙版目标下直接调用 engine.beginStroke/appendPoint/endStroke，图层蒙版与组蒙版都可绘制、undo、刷新缩略图。
- **undo/redo**：组蒙版新增/删除/启停/应用、组剪贴切换、组蒙版笔触均走 engine 同一 UndoManager；底栏撤销/重做生效。
- **保存/打开**：.mozheng doc.groups 带 mask/clip；组蒙版 tile 存 masks（key=groupId），保存→打开→刷新后组蒙版像素/启用状态与组剪贴保留（测试验证 tiles=2）。
- **PSD**：导入导出保留组/图层结构；**组蒙版像素 PSD 暂不支持**（T67 已知限制，导出时状态栏/toast 标注；fidelity 记录）。
- **测试**：test-layer-doc.mjs 扩展：组蒙版建立→真实 pointer 画入→maskStore tiles=2 / undo、组剪贴开关、保存打开组蒙版+剪贴往返、刷新恢复（groupMasks=1/groupClip=1）、PSD 导出导入结构；三档组蒙版截图 ui-layergroup-{1920,1536,1366}.png；test-app.mjs 0 error；test-tools.mjs 涂抹/选区/变换/结构 undo 回归全过。
- **限制**：组蒙版笔触为白色显示黑色隐藏（橡皮切黑暂未做）；组蒙版 PSD 像素不支持；组仅 1 级。

## T69 模拟压感新默认（app）

- **新默认**（采纳 brush T69 tau50 推荐）：{enabled:true, strength:1.0, curve:'soft', smoothingMs:65, startPressure:0.30, catchUp:true, speedTauMs:50}；面板默认显示平滑 65ms。
- **观感变化**：快笔更细、起笔/追笔更跟手——快 S 真线宽 CV 0.432→0.084、重压 0→0.032、慢 S 持平；代价是快笔 S2 ink 约 1053→675（预期），喜欢旧手感的用户可用回退值。
- **回退值**：{enabled:true, strength:1.0, curve:'soft', smoothingMs:45, startPressure:0.55, catchUp:false, speedTauMs:0}（等价 T54/T59 前默认）。
- **存储/迁移**：key 升版为 mozheng.v2.simPressure.v2；旧 key mozheng.v2.simPressure.v1：
  - 旧默认（enabled/strength1/soft/45ms）→ 自动升级为新默认；
  - 用户自定义（如 1.6/strong/70ms）→ 保留并补齐新字段（startPressure 0.30 / catchUp true / speedTauMs 50）。
- **验证**：2/app/test-pressure-panel.mjs 新增 defaults/migrateDefault/migrateCustom 全过；同笔迹 off CV 0.067 → on（2/strong/45）CV 0.407；test-app 0 error；test-tools 全过。

## T71 素材库 + 完整演示链路（MVP）

- **入口**：顶栏独立「素材」图标（Lucide library，36×36，tooltip/aria，data-demo-target=btnLibrary），位置在「演示」左侧；打开 **1180×720 Sheet**（1366 自动 1180×672），遮罩 rgba(3,5,9,.55) + blur，role=dialog aria-modal=true，160ms 淡入；Esc/右上×/点遮罩关闭，关闭后画布视口/工具/选区不变（不换路由、不重载）。
- **Sheet**：搜索（200ms 防抖，匹配文件名/tags/L1/L2）＋ 4 筛选（全部/待确认/已引用/低置信）＋ 导入素材；3 列卡片（缩略图、标题、tags、来源三态徽章、AI 已读 · N 区域 · M 观察、N 待确认、被本作品引用 N 次）；右侧 380px 详情固定顺序 **L0 原件 → L1 全局 → L2 区域（bbox 叠加预览）→ L4 观察（确认/不对 → 写 L5）→ L5 决策 → 偏好 → 操作**；色板来自真实像素，可点击复制。
- **导入**：文件选择/拖入 PNG/JPG/WebP（≤20MB/张），进度条 + 去重（sha256）；刷新后 IndexedDB 保留（T70 schema，T74 原图 originals store）。
- **在画布使用**：
  - **插入为图层**：优先 api.getOriginal(id,{objectUrl,imageBitmap})（**ObjectURL revoke / ImageBitmap close**；无原图回退缩略图），按 ≤60% 画布居中插入新图层，图层行显示「素材」徽章，L6 asset_inserted，markUsed + projectRefs；
  - **作为 AI 参考**：写 aiReference，AI 浮层顶部显示「参考素材：名称 · tags · L2 区域」chip（可 × 取消，写 L6 reference_removed）；runAnalyze 带 libraryRef，结果标记 libraryRef，asset_ref 落 L6；
  - **证据包**：refs[] 含 asset_id/fileName/sha256/layer_id/L1_id/L2_ids，manifest.refs_count；AI 事件、引用、落层全部进链。
- **示例素材（自制，随包在运行时生成导入）**：雾中山谷-示例.jpg（1600×1200 摄影感插画）、人物线稿-示例.png（1200×1600 白底线稿）、水彩纸-示例.png（1600×1200 纸纹）；每张带 T72 §5.3 可信 mock fixture（L1 总结/tags/情绪、L2 bbox、L4 text/anchor/confidence），空库首次打开自动导入并完成 mock 反解。
- **一键演示 12 步 / ~52s**（自动 4.3s/步，暂停/上一步/下一步/接管/Esc 沿用）：示例作品 → 打开素材库 → 选「雾中山谷」→ L1 → L2 → 确认观察 → 插入为图层 → 框选卡住处 → 让 AI 看看（引用素材）→ 确认观察+方向 → 方案落新图层 → 导出证据包；结束停在证据包，不自动关闭。
- **测试**：v2/app/test-library.mjs（Playwright-core + msedge，headless，硬超时 240s）全过：Sheet 尺寸/卡片/缩略图/详情 L0–L5、搜索、筛选、确认/否决写 L5、导入+sha 去重、插入图层（原图路径 original-bitmap）、AI 引用 chip、分析引用、证据 refs、刷新持久化、12 步演示、三档截图；test-app / test-tools / test-ui 回归 0 error。
- **截图**：ui-library-1920.png / ui-library-1536.png / ui-library-1366.png。
- **限制**：MVP 不做拖拽入画布/多选/PSD 入库/语义搜索/文件夹；mock 反解为确定性占位（UI 标 AI 推断/本地 Mock）；T74 前导入的旧素材无原图会用缩略图；素材库事件与作品 L6 为轻量引用，不写素材库独立证据链。

## T75 素材库演示 P1 打磨

1. **scrim**：rgba(3,5,9,.72) + backdrop-filter blur(2px)，Canvas 上下文更聚焦。
2. **字号**：Sheet 内所有可见文本 ≥12px（来源徽章、状态、tag、mock 标识、详情、操作）。
3. **详情操作条**：详情拆成独立滚动区 + 底部固定操作条（不再 absolute 压住 L2）；滚动条可见、底部留白。
4. **来源三态**：图标 + 12px 文字（● 可见 / △ AI 推断 / ✓ 你确认），不再只靠颜色。
5. **示例素材升级**：三张自制图重绘——层叠远山/雾带/近水的摄影感插画、完整人物线稿（头身/衣褶/排线）、水彩纸纹理（晕染/颗粒/纤维/纸边）；fixture 文案/bbox 同步。
6. **色板**：来自真实像素抽色（T70 extractPalette），hover 显示 hex + 点击复制，色块加亮边。
7. **引用次数**：卡片与详情固定 0/1 显示（最多「被本作品引用 1 次」），避免多轮演示累加。
8. **AI 引用 chip**：文件名最大 180px 截断（ellipsis + title 全名），独立 22×22 移除按钮 + aria-label=移除素材参考。

验证：test-library 全过（scrim/sheetFont12/detailNotCovered/sourceIcons/paletteReal/p1Chip/p1Ref + 原有 open/search/filters/decision/import/insert/aiRef/evidenceRefs/persist/demo/screenshots）；test-app、test-ui 回归 0 error；截图 ui-library-{1920,1536,1366}.png 更新。

## T78 异步导出 + 压缩保存（M4.5 P0）

- **异步任务条**：屏幕底部居中进度条（分块渲染/编码/打包 + 百分比 + 取消）；启动 1.2s 后空闲预热 exportPNGAsync；导出期间画布不冻结、可取消。
- **PNG/证据包**：走 engine.exportPNGAsync（Worker + 分块 readPixels）；证据包先异步 PNG 再计算哈希链；取消抛 AbortError，保持画布可编辑。
- **PSD**：逐层渲染 canvas + 每层 requestAnimationFrame 让帧，进度显示“打包 i/total”；取消在层间生效；最终 ag-psd 打包。
- **4096²**：画布像素 > 2048² 时自动 tileSize 512 分块并在任务条显示“4096² 分块”；小画布 256 tile。
- **保存**：更多→保存项目用 engine.getDocFileBlob({compress:true}) → v2 gzip .mozheng；不支持 CompressionStream 时回退 v1 JSON 并提示。
- **打开**：engine.deserializeDocAuto 自动识别 v1/v2；损坏/尺寸不符给可读错误，不破坏当前画布；状态栏标注 v1/v2 与体积。
- **IndexedDB 自动保存**：1.2s 防抖存压缩 Blob（含 compressed/bytes）；刷新 restoreProject 自动恢复；旧 v1 JSON 记录兼容。
- **失败兜底**：Worker/OffscreenCanvas 不可用→engine 自动同步路径（progress phase=fallback），app 提示“兼容模式：同步导出”；CompressionStream 不可用→保存 v1 并提示。
- **修复**：loadProjectData 在演示未运行时误调 pauseDemo 会翻转 paused 并在后续加载时触发 demo 步骤、篡改画布；已改为仅 demo.active 时暂停。
- **测试**（test-async-export，Playwright/msedge，硬超时 240s）：异步 PNG 像素与同步 diff=0、导出期 longtask=0；取消 AbortError 且可再次导出；v1 8826B→v2 6070B（−31.2%），v2 与 v1 回读像素 diff=0（v1/v2 结构一致）；IDB 自动保存 v2 压缩、刷新恢复；Worker 不可用 fallback、CompressionStream 不可用回退 v1；三档进度条截图无溢出。test-app、test-library、test-layer-doc 回归 0 error。
- **截图**：ui-export-1920.png / ui-export-1536.png / ui-export-1366.png。
- **已知限制**：serializeDoc 的 tile PNG readback 仍为同步主线程（T77 范围外）；保存/打开 roundtrip 与保存前同步合成存在约 17px 抗锯齿差异（引擎 tile PNG 编码既有行为；v2 与 v1 之间 diff=0）；Worker 依赖现代 Chromium/Edge。

## T82 一键演示说明卡（解决“只有框不知道在干什么”）

- **说明卡**：左下固定卡片（不遮画布主体），每步显示 `02 / 12 · 这一步在做什么 · 标题 · 一句说明 · 自动播放剩余秒数`；12 步全部有标题/说明，文案从“术语”改为“做什么/为什么”（如 2/12 打开素材库：“AI 已经读过这些素材……”、8/12 框选卡住的地方、12/12 证据包：“哈希链 / 零生成 / 素材引用都可复核”）。
- **高亮升级**：保留 spotlight 框，新增**目标标签**（示例画布 / 素材库入口 / L1 整体 / L2 区域 / L4 观察 / 插入图层按钮 / 画布选区 / AI 观察 / AI 方向 / 新图层 / 证据包）；顶部目标标签自动放右侧避免遮挡；叠加半透明遮罩，框外点击暂停。
- **控制条**：进度 n/12、上一步、暂停/继续、下一步、**接管**、退出；每步 4.4–5.4s（文案长 +0.5/1s）；暂停保留当前步骤，继续不重放动画。
- **结束**：停在证据包不关闭，底部显示「演示完成 · 12/12 · 证据包已打开：哈希链 / 零生成 / 素材引用」+ 接管画布 / 重播演示 / 回到我的作品。
- **测试**：`test-demo.mjs`（Playwright/msedge，headless，硬超时 240s）——12 步说明卡/标题/说明/标签/步号、时长范围、暂停/继续/上一步、接管、结束停在证据包、三档截图，全过；test-app 0 console error，test-library 回归通过。
- **截图**：ui-demo-1920.png / ui-demo-1536.png / ui-demo-1366.png。

## T86 暖纸创作台视觉实现（方向 B / Paper Atelier）

- **入口/回退**：新增 v2/app/css/paper-theme.css（加载在 tokens/app/procreate 之后）+ `<html data-theme="paper">`；不改 DOM 结构、不改功能逻辑。回退：删除 index.html 的 data-theme="paper"（或注释 paper-theme.css link）即恢复旧深色。
- **Tokens**：纸 100 #FBF6EC / 200 #F4EBDD / 300 #EDE2CF / 400 #E2D2B9 / 500 #D6C4A8；墨 900 #241F19 / 700 #4A4136 / 500 #6C6050；朱砂 #A23F2A；赭金 #8F6B2F；焦点墨青 #2F5E63；纸纹用 CSS 内联 SVG feTurbulence 自制（180×180，≈3.5%，仅 UI；演示降到更低）。
- **组件**：顶栏纸底 + 墨块激活工具 + 朱砂品牌印；左栏自定义竖滑杆（4px 纸轨 + 16px 纸面/朱砂边 thumb、墨色 mono 数值）；浮层纸卡（纸 100/300、12 圆角、暖阴影、墨字）；按钮 primary 墨底纸字、secondary 纸底墨字、danger 朱砂；图层选中朱砂左线；模态/toast/更多菜单纸化。
- **素材库**：scrim rgba(35,27,18,.62)+blur2；五层纸感（Sheet 纸 200 → 头部纸 300 → 卡片纸 100 → 详情纸 100+左线）；字号 ≥12；来源三态图标+文字；色板 hex；详情独立滚动区+底部操作条；L1/L2/L4/L5/引用文字全部补暖纸墨色，解决白字不可见。
- **演示**：说明卡纸卡（朱砂步骤/墨标题/墨 700 正文/赭金进度）、赭金 spotlight + 墨底目标标签、纸色控制条、结束条；与 T82 行为一致。
- **画布**：artboard 固定中性白 #FFFFFF + 1px 墨线/暖阴影，舞台暖纸不接触作品。
- **验收（test-paper.mjs）**：主题/样式加载、纸纹、正文对比 13.8:1、次要 8.5:1、浮层/素材库/演示对比与字号、artboard 白、三档无溢出、0 console error 全过；test-app/test-library/test-ui/test-demo 全部通过。
- **三档截图**：ui-paper-1920/1536/1366.png；同时更新 ui-1920/1536/1366.png、ui-library-*.png、ui-demo-*.png。
- **已知限制**：竖向滑杆已选段以朱砂 thumb 表示（Chromium 垂直 range 的轨道填充能力有限）；纸纹为纯 CSS/SVG，无外部素材。

## T87 暖纸视觉/演示 P1 打磨

1. **演示 scrim**：`.demo-scrim` 改为暖墨 rgba(35,27,18,.56)（.55–.62 区间），spotlight 用 brightness/saturate 提亮目标区域。
2. **说明卡**：宽 404px（1366 380px）、标题 18px、正文 16px；卡内新增步骤进度条（4px 纸轨 + 朱砂填充，按单步时长动画，暂停冻结）。
3. **总时长**：12 步 54.0s（单步 4.4/4.8s，长文案 +0.4s），满足 ≤60s，不删步骤。
4. **结束卡**：T83 纸卡规格——620px 居中、标题 32px、说明 16px、12 号注释；保留“接管画布 / 重播演示 / 回到我的作品”。
5. **素材库操作条**：详情滚动区 padding-bottom 96px，操作条在滚动区外；test-library detailNotCovered 通过。
6. **左栏 thumb**：16px 纸底 #FBF6EC + 2px 朱砂边，不透明；hover 18px。
7. **演示纸纹**：body.demo-running 时顶栏/左栏/底栏/浮层/素材库/说明卡/控制条/结束卡 background-image:none，body::before opacity .15，录屏无噪点。
8. **白画布边界**：1px 墨线 rgba(36,31,25,.78) + 0.30 暖投影/白色内高光，投影/录屏下白纸边界清晰。

验证：test-paper 新增 T87 检查全过（scrim .56、卡 404/16px/进度、总时长 54s、结束卡 32/16/620、演示纸纹 none、detail padding 96、artboard 新边界）；test-demo（总时长、12 步、暂停/接管/结束证据包）全过；test-library/test-ui/test-app 全过。三档截图 ui-paper-*、ui-demo-*、ui-library-*、ui-* 已更新，另出 ui-demo-end-1920.png。

## T85 蒙版橡皮（白显示 / 黑隐藏）

- **接口**：engine T84 的 `setMaskStrokePaint('white'|'black')` 与 `beginStroke(p,{maskPaint})`；app 在蒙版编辑目标（`mask` / `group-mask`）下把工具栏映射为：**画笔 → white（显示/恢复）**、**橡皮 → black（隐藏）**。
- **状态**：进入/退出图层或组蒙版、切换画笔/橡皮、切换图层时同步 paint 与状态栏：`蒙版编辑：白=显示 / 黑=隐藏 · 画笔=显示/橡皮=隐藏（图层/组蒙版）`；退出蒙版恢复 white。
- **笔触/撤销**：蒙版输入走 engine `beginStroke/appendPoint/endStroke`（T60 既有路径），白/黑笔触都进同一 undo 栈；抬笔 `renderLayers()` 刷新图层/组蒙版缩略图。
- **保存/打开/PSD**：mask tiles 随 V2Doc 序列化/反序列化；测试覆盖保存→打开后 mask 存在、tile 保留、PSD 导出 summary.masks=1（组蒙版像素 PSD 仍为已知限制）。
- **验证**：`test-mask-eraser.mjs`（Playwright/msedge，headless）——图层蒙版橡皮隐藏（mask darkFraction>0、合成变化）、undo 恢复、画笔白恢复、组蒙版橡皮/undo、保存打开、PSD、三档无溢出全过；`test-layer-doc.mjs` 新增 maskEraser 通过；test-app 0 console error。
- **截图**：ui-mask-1920.png / ui-mask-1536.png / ui-mask-1366.png（层浮层打开、状态栏提示可见）。
- **限制**：组蒙版像素导出 PSD 仍不支持（T67/T84 记录）；组仅 1 级。

## T81 异步保存 / PSD 导出（T79 API）

- **保存项目**：更多→保存项目改为 `engine.saveDocAsync({compress:true,onProgress,signal})`；底部任务条显示“保存 tile n / 完成 / 百分比”，可**取消**（AbortError 后可再次保存）；保存为 v2 gzip Blob 并下载；启动 1.2s 后空闲调用 `warmUpExportAsync()` + `warmUpSaveAsync()`。
- **IndexedDB 自动保存**：1.2s 防抖改走异步压缩保存（保存压缩 Blob + bytes/compressed）；手动导出/PSD 进行中时延后重试，避免与 engine 保存任务并发；刷新后 `deserializeDocAuto` 恢复。
- **PSD 导出**：改走 `engine.exportPSDAsync({onProgress,signal})`（逐层读取→worker ag-psd 打包），任务条显示逐层读取/打包进度，可取消（`cancelPSDExport`）；失败/不支持时回退既有 `psdExportBuffer` 同步路径。
- **降级**：`saveDocAsync` 不存在或 Worker/OffscreenCanvas 不可用 → 回退 `getDocFileBlob` 同步保存；`exportPSDAsync` 不存在 → 回退同步 PSD 导出；均 toast“兼容模式”。
- **测试（test-save-psd.mjs，Playwright/msedge，headless）**：
  - 保存 12,520B（v2 gzip），progress phases encode/done，**longtask 0**；PSD 8BPS 201,030B，phases render/done，**longtask 0**；
  - 取消保存/PSD 均 AbortError，随后可再次成功；API/Worker 缺失降级保存与 PSD 均成功；
  - 保存→刷新→IDB 恢复：图层/结构一致、v1 打开成功；渲染像素差异 22px、每通道最大 1（engine tile PNG/alpha 编解码舍入，非压缩导致；v2/v1 数据同源）。
  - test-app、test-library、test-layer-doc 全过，0 console error。
- **三档截图**：ui-save-1920.png / ui-save-1536.png / ui-save-1366.png（保存进度条）。
- **限制**：engine tile PNG 编解码在软边像素有 ≤1/通道舍入；首次未预热保存可能有 1 次暖机长任务（启动空闲预热已降低概率）。

## T90 默认 dirty present（≤2048²）+ 大文档 full

- **默认策略**：app 初始化/恢复/打开项目/PSD 导入后调用 `applyPresentStrategyForSize()`：文档面积 **≤2048²** → `engine.setPresentStrategy('dirty')` + `presentRetained=true`；**>2048²**（如 4096²）→ `setPresentStrategy('full')` + `presentRetained=false`，避免 full 保留帧 +64MB。
- **1200×800 当前策略**：dirty / 保留帧；About 面板「呈现策略」显示 `dirty · 保留帧 · 1200×800`。大文档策略通过纯函数 `presentPolicyForSize()` 决定，支持打开/切换尺寸时重算。
- **回退**：`engine.setPresentStrategy('full')` 即可回退；无 UI 开关（按 T90 只读展示）。
- **测试（test-present.mjs，Playwright/msedge，headless）**：
  - 默认 dirty/retained；policy：1200×800 + 2048² → dirty/retained，2049×2048 + 4096² → full/不保留；
  - dirty vs full 绘制像素 diff=0；undo 后 diff=0；exportPNGAsync 两策略字节相同、像素 diff=0；
  - 多笔后帧稳定、dirty/redraw 13.7%、与 full 像素 diff=0；
  - About 显示当前策略；三档截图无溢出；0 console error。
- **附带修复**：`openModal` 使用 `.show` 但旧 CSS 只写 `.open`，导致 About/档案/证据模态实际不可见——已加 `.modal-mask.show` 别名；同时修复 app.css 4 处 content 引号未闭合。test-app/test-ui/test-library/test-demo/test-paper/test-layer-doc/test-mask-eraser/test-save-psd/test-present 全过。
- **截图**：ui-present-1920.png / ui-present-1536.png / ui-present-1366.png。

## T96 AI 模型接入（默认 Mock / 手动确认 / 不接真 key）

- **设置入口**：更多→设置 / 关于 →「AI 模型接入」。Provider：本地 Mock（默认）/ Moonshot Kimi K3.1 Pro（`https://api.moonshot.cn/v1`、`kimi-k3.1-pro`）/ 混元生图 3.0（`https://tokenhub.tencentmaas.com/v1`、`hy-image-v3.0`）/ 混元视觉 Hy4（`https://api.hunyuan.cloud.tencent.com/v1`，模型可手填）/ 自定义 OpenAI-compatible。
- **配置**：baseURL、model、API Key（password，只显示 hasKey；POST `/api/ai/config` 保存到本地代理 `.ai-config.json`，前端 input 清空、localStorage/页面不落 key）；保存配置 / 测试连接（`/api/ai/test`）/ 清除 Key；开关：允许真实调用（默认关）、每次手动确认（默认开）、隐私模式强制 Mock（默认开）。
- **确认**：真实调用前弹出确认卡，写明「将把选区裁切的 base64 图片 / 档案摘要（L1/L2/L4 最近记录）发送给 provider/model，是否继续？」；取消不发送、不写假记录；不会发送素材库原件/API Key/证据链。
- **接线**：`runAnalyze / runDirections / runGenerate` 改为 `createProvider()`，provider 经本地代理；无 key / 关闭真实 / 隐私模式 / 代理不可用 → Mock。provider/model/latency/usage/requestId 写入 `state.aiLastCall` 与 L6（critique；生成落层 generation 带 cost/credits）；AI 面板显示「本地 Mock / Kimi · 真实 / 混元 · 真实」徽章；候选文案为「局部方案（选区裁切 patch → 新图层）」，混元显示 ¥0.2/张、1/1 串行估费。
- **错误态**：401/429/超时/坏 JSON 映射成中文提示（含可重试），写失败 L6（error_code/error_message/retryable），画布可继续；不自动静默真实调用。
- **测试（test-ai-provider.mjs，headless，mock 代理 + 本地假上游）**：defaults/mock/settingsUi/testNoKey/save（脱敏、无 key 泄漏）/testReal/confirm/cancel（无请求、无记录）/real（structured JSON、usage、L6）/directions/generate（混元 image，1 张 patch）/apply（新图层 cost 0.2）/error401/badjson（可读错误+失败 L6）/三档截图/无非预期 console 全过；test-app、test-ui 0 error。
- **截图**：ui-ai-settings-1920.png / ui-ai-settings-1536.png / ui-ai-settings-1366.png。
- **限制 / 注意**：
  - 浏览器真实调用要求页面注入本地 token（`window.__AI_LOCAL_TOKEN__`）；当前 T95 serve.mjs 静态页尚未自动注入，普通 serve 直开页面时 config/test/real 会被 401 拒绝（Mock 完全可用）。测试通过 addInitScript 注入 token。
  - 真实模型未接真 key；真实上游用假服务器验证；混元生图无 mask 局部重绘，候选是选区裁切 patch 落新图层；Kimi 图片仅 base64；结果 URL 12h 服务端缓存。
  - 分析按 token 计费（待实测），生图按 ¥0.2/张估算。

## T101 Qwen 生图接入（qwen3.8-max 视觉 + Qwen-Image 3.0）

- **预设**：更多→设置→AI 模型接入 → Qwen3.8 Max（provider `qwen`，baseURL `https://dashscope.aliyuncs.com/compatible-mode/v1`，chat `qwen3.8-max`，imageModel `qwen-image-3.0`）；能力显示 **vision ✓ / image ✓**。
- **协议**：Qwen 生图由 T100 本地代理转 DashScope 异步 submit/poll，服务端下载结果并算 sha256，前端只走 `/api/ai/image`；候选含 `sha256/bytes/width/height`。
- **文案/限制**：Qwen 生图异步排队、面积 512²–2048²、参考图 0–3 张、按张计费（价格待实测）、结果本地落盘、任务超时 180s；候选 = 局部方案 patch → 新图层（可撤销/变换/蒙版），不是整图重绘；生图 A 面板显示「Qwen / qwen-image-3.0 · 价格待实测 · 异步排队 · 1/1 串行 · 局部 patch」。
- **证据**：落层 L6 generation 含 `model.provider=qwen`、`model.model/modelVersion=qwen-image-3.0`、`params.candidate_sha256`、`local_patch:true`、`cost_cny:0`（价格待实测）；撤销后图层移除、L6 证据保留。
- **测试**：`test-qwen-image.mjs`（fake DashScope 异步上游 + serve 本地代理，token 注入）：config/preset/qwenSubmit（model= qwen-image-3.0、size 1024*1024、watermark false、n=2、参考图 base64）/queue（submit→2 poll→下载 1 次）/generate/note/apply/undo/ui/三档截图/noConsoleErrors 全绿；test-app/test-ui 0 error。
- **真实 key**：已用本机配置（provider qwen）跑通真实链路，数据见 `test-result.json.qwenImage.real`：Qwen3.8-max 视觉分析 8.7s/927 tokens；方向 6.6s/790 tokens；Qwen-Image 生图 **20.1s**、2 候选、首张 1,236,634B/1024²、sha256 `29a287…`；落层 +1、undo -1、L6 generation model=qwen-image-3.0 + candidate_sha256；证据 manifest real_calls=3/providers=qwen；不打印/不提交 key。
  - 实拍截图：`ui-ai-qwen-real-candidate-{1920,1536,1366}.png`、`ui-ai-qwen-real-applied-{1920,1536,1366}.png`；真实候选 PNG 样本 `qwen-real-candidate.png`。
  - 限制：Qwen 价格未实测（L6 cost 0、UI 标注待实测）；无 mask 局部重绘；本次画布为空白，候选是低对比补光 patch。
