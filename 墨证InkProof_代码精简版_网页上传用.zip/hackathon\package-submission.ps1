﻿# DEPRECATED —— 旧 PowerShell 打包器已废弃：它主动排除了全部 QA 脚本、测试结果 JSON 与彩排截图，
# 导致 README 的「已验证」结论在包内一条都无法复现，且混入了 mock 时代旧 PPT。
# 唯一入口请改用纯 Node、零依赖、幂等、含证据与密钥扫描的新脚本：
#     node hackathon/package-submission.mjs
# 本文件仅做一行转发，保留它是为了兼容旧文档里出现的 powershell -File 命令。
node (Join-Path $PSScriptRoot 'package-submission.mjs') @args
exit $LASTEXITCODE
