#!/usr/bin/env node
// v2/qa/tools/ai-proxy-test.mjs —— T95 AI 代理测试（零依赖：假上游 + serve.mjs）
// 用法：node v2/qa/tools/ai-proxy-test.mjs
// 覆盖：config 脱敏/写入、token 校验、chat/image 转发、SSE、401/429/超时、无 key/未确认 Mock、不泄漏 key。
import http from 'node:http';
import { spawn } from 'node:child_process';
import { promises as fs } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPO = path.resolve(__dirname, '..', '..', '..');
const results = { schema: 'mozheng.qa.ai-proxy.v1', at: new Date().toISOString(), checks: {}, errors: [] };
const allTexts = [];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const SECRET = 'sk-test-SECRET-1234';
const TOKEN = 'local-token-TEST';
const TINY_PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

function fakeUpstream() {
  const state = { chatCalls: 0, imageCalls: 0, imgUrlCalls: 0, active: 0, maxActive: 0, lastAuth: null, lastBody: null, lastChatRaw: null };
  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => { raw += c; });
    req.on('end', () => {
      let body = {};
      try { body = JSON.parse(raw || '{}'); } catch (e) { body = {}; }
      state.lastAuth = req.headers.authorization || null;
      state.lastBody = body;
      if (req.url.startsWith('/v1/chat/completions')) state.lastChatRaw = raw;
      if (req.url.startsWith('/img.png')) {
        state.imgUrlCalls += 1;
        const png = Buffer.from(TINY_PNG, 'base64');
        res.writeHead(200, { 'content-type': 'image/png', 'content-length': png.length });
        res.end(png);
        return;
      }
      if (req.url.startsWith('/expired.png')) {
        state.imgUrlCalls += 1;
        res.writeHead(404, { 'content-type': 'text/plain' });
        res.end('expired');
        return;
      }
      if (req.url.startsWith('/v1/chat/completions')) {
        state.chatCalls += 1;
        if (state.lastAuth !== 'Bearer ' + SECRET) { res.writeHead(401, { 'content-type': 'application/json' }); res.end(JSON.stringify({ error: { message: 'invalid key' } })); return; }
        if (body.model === 'fail401') { res.writeHead(401, { 'content-type': 'application/json' }); res.end('{"error":"bad key"}'); return; }
        if (body.model === 'fail429') { res.writeHead(429, { 'content-type': 'application/json' }); res.end('{"error":"rate"}'); return; }
        if (body.model === 'slow') { setTimeout(() => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ id: 'slow', model: 'slow', choices: [{ message: { content: '{}' } }] })); }, 900); return; }
        if (body.stream) {
          res.writeHead(200, { 'content-type': 'text/event-stream; charset=utf-8', 'cache-control': 'no-store' });
          res.write('data: ' + JSON.stringify({ id: 'chatcmpl-fake', object: 'chat.completion.chunk', choices: [{ delta: { content: '{"global":' } }] }) + '\n\n');
          setTimeout(() => { res.write('data: ' + JSON.stringify({ id: 'chatcmpl-fake', object: 'chat.completion.chunk', choices: [{ delta: { content: '{}' } }] }) + '\n\n'); res.write('data: [DONE]\n\n'); res.end(); }, 30);
          return;
        }
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify({ id: 'chatcmpl-fake', model: body.model || 'fake-model', choices: [{ index: 0, message: { role: 'assistant', content: JSON.stringify({ global: { summary: 'fake upstream' }, regions: [], observations: [], confidence: 0.8 }) } }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } }));
        return;
      }
      if (req.url.startsWith('/v1/images/generations')) {
        state.imageCalls += 1;
        state.active += 1; state.maxActive = Math.max(state.maxActive, state.active);
        if (state.lastAuth !== 'Bearer ' + SECRET) { state.active -= 1; res.writeHead(401); res.end('{"error":"bad key"}'); return; }
        const url = body.prompt === 'expired'
          ? `http://127.0.0.1:${server.address().port}/expired.png`
          : `http://127.0.0.1:${server.address().port}/img.png`;
        setTimeout(() => {
          state.active -= 1;
          res.writeHead(200, { 'content-type': 'application/json' });
          res.end(JSON.stringify({ model: 'hy-image-v3.0', data: [{ url }, { url }], usage: { images: 1 } }));
        }, 250);
        return;
      }
      res.writeHead(404); res.end('not found');
    });
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve({ server, state, port: server.address().port })));
}

async function waitServe(port) {
  for (let i = 0; i < 100; i += 1) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/health`);
      if (res.ok) return port;
    } catch (e) { /* wait */ }
    await sleep(100);
  }
  throw new Error('serve 未启动');
}
async function req(port, method, pathName, body, headers = {}) {
  const res = await fetch(`http://127.0.0.1:${port}${pathName}`, {
    method, headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  allTexts.push(text);
  let json = null; try { json = JSON.parse(text); } catch (e) { /* text */ }
  return { status: res.status, text, json, headers: Object.fromEntries(res.headers) };
}

const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'ai-proxy-'));
const configPath = path.join(tmp, '.ai-config.json');
const tokenPath = path.join(tmp, '.ai-token');
let upstream = null, serve = null;
try {
  upstream = await fakeUpstream();
  const port = 4390 + Math.floor(Math.random() * 80);
  serve = spawn(process.execPath, [path.join(REPO, 'v2', 'serve.mjs')], {
    cwd: REPO,
    env: { ...process.env, PORT: String(port), AI_CONFIG_PATH: configPath, AI_TOKEN_PATH: tokenPath, AI_LOCAL_TOKEN: TOKEN },
    stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true,
  });
  let serveOut = ''; serve.stdout.on('data', (d) => { serveOut += d; }); serve.stderr.on('data', (d) => { serveOut += d; });
  let serveExit = null;
  serve.on('exit', (code, signal) => { serveExit = { code, signal }; });
  try { await waitServe(port); } catch (e) { throw new Error('serve 未启动: ' + (serveOut.slice(-800) || '') + ' exit=' + JSON.stringify(serveExit)); }
  await sleep(100);
  const H = { 'x-ai-token': TOKEN };
  const base = upstream.state;

  // 1) health（无 token 可读；未配置 → mock）
  let r = await req(port, 'GET', '/api/ai/health');
  results.checks.healthMock = r.status === 200 && r.json.ok === true && r.json.mode === 'mock';
  // 2) token 校验
  results.checks.tokenMissingConfig = (await req(port, 'GET', '/api/ai/config')).status === 401;
  results.checks.tokenWrongConfig = (await req(port, 'GET', '/api/ai/config', null, { 'x-ai-token': 'wrong' })).status === 401;
  r = await req(port, 'GET', '/api/ai/config', null, H);
  results.checks.configReadable = r.status === 200 && r.json.ok === true;
  // 3) 写配置（真实上游 = fake），响应脱敏
  r = await req(port, 'POST', '/api/ai/config', {
    mode: 'real', provider: 'openai-compatible', model: 'fake-model', timeoutMs: 5000,
    providers: { 'openai-compatible': { baseUrl: `http://127.0.0.1:${upstream.port}/v1`, apiKey: SECRET, model: 'fake-model' } },
  }, H);
  results.checks.configWrite = r.status === 200 && r.json.ok === true;
  results.checks.configRedacted = !r.text.includes(SECRET) && r.json.config.hasKey === true && r.json.config.providers['openai-compatible'].keyLast4 === '1234';
  r = await req(port, 'GET', '/api/ai/config', null, H);
  results.checks.configNoKeyLeak = !r.text.includes(SECRET) && r.json.hasKey === true;
  r = await req(port, 'GET', '/api/ai/health');
  results.checks.healthReal = r.status === 200 && r.json.mode === 'real' && r.json.hasKey === true;

  // 3b) T99：正常 serve 打开页面 → 注入 token → config/test/真实(mock 上游) 不再 401
  const pageRes = await fetch(`http://127.0.0.1:${port}/v2/app/index.html`);
  const pageHtml = await pageRes.text();
  const tokenMatch = /window\.__AI_LOCAL_TOKEN__=("(?:[^"\\]|\\.)*")/.exec(pageHtml);
  let pageToken = null;
  try { pageToken = tokenMatch ? JSON.parse(tokenMatch[1]) : null; } catch (e) { pageToken = null; }
  results.checks.pageTokenInjected = pageRes.status === 200 && pageToken === TOKEN && /no-store/.test(String(pageRes.headers.get('cache-control') || ''));
  const jsText = await (await fetch(`http://127.0.0.1:${port}/v2/app/js/app.js`)).text();
  results.checks.staticJsNoToken = !jsText.includes(TOKEN);
  if (!pageToken) pageToken = TOKEN; // 兜底：仅测试页注入失败时仍验证 API token 路径
  r = await req(port, 'GET', '/api/ai/config', null, { 'x-ai-token': pageToken });
  results.checks.pageConfigNot401 = r.status === 200;
  r = await req(port, 'POST', '/api/ai/test', {}, { 'x-ai-token': pageToken });
  results.checks.pageTestNot401 = r.status === 200;
  r = await req(port, 'POST', '/api/ai/chat', { task: 'analyze', messages: [{ role: 'user', content: 'hi' }] }, { 'x-ai-token': pageToken, 'x-ai-confirm': 'true' });
  results.checks.pageRealChatWorks = r.status === 200 && r.json.mode === 'real';
  results.checks.crossOriginCannotUseToken = (await req(port, 'GET', '/api/ai/config', null, { 'x-ai-token': pageToken, origin: 'https://evil.example.com' })).status === 403;

  // 4) 未确认 → Mock（即使有 key）
  r = await req(port, 'POST', '/api/ai/chat', { task: 'analyze', messages: [{ role: 'user', content: 'hi' }] }, H);
  results.checks.chatNeedsConfirmMock = r.status === 200 && r.json.mode === 'mock' && r.json.reason === 'needs-confirm' && !!(r.json.choices && r.json.choices[0]);
  // 5) 确认 → 转发
  const chatBody = { task: 'analyze', model: 'fake-model', messages: [{ role: 'user', content: 'hi' }], response_format: { type: 'json_object' } };
  r = await req(port, 'POST', '/api/ai/chat', chatBody, { ...H, 'x-ai-confirm': 'true' });
  results.checks.chatForward = r.status === 200 && r.json.mode === 'real' && r.json.choices[0].message.content.includes('fake upstream') && base.chatCalls >= 1;
  results.checks.chatAuthForwarded = base.lastAuth === 'Bearer ' + SECRET;
  // 6) SSE 转发
  r = await req(port, 'POST', '/api/ai/chat', { ...chatBody, stream: true }, { ...H, 'x-ai-confirm': 'true' });
  results.checks.chatSSE = r.status === 200 && String(r.headers['content-type'] || '').includes('text/event-stream') && /data:/.test(r.text) && /\[DONE\]/.test(r.text);
  // 7a) Kimi-style：chat 图片 URL → 代理转 base64 再转发
  r = await req(port, 'POST', '/api/ai/chat', {
    task: 'analyze', model: 'fake-model',
    messages: [{ role: 'user', content: [
      { type: 'text', text: 'look' },
      { type: 'image_url', image_url: { url: `http://127.0.0.1:${upstream.port}/img.png` } },
    ] }],
  }, { ...H, 'x-ai-confirm': 'true' });
  results.checks.chatImageBase64 = r.status === 200 && String(base.lastChatRaw || '').includes('data:image/png;base64,') && !String(base.lastChatRaw || '').includes('/img.png');
  // 7b) 混元式 {url} → 代理服务端下载 + sha256，不把 URL 交给前端
  const imgBefore = base.shape = { imageCalls: base.imageCalls, imgUrlCalls: base.imgUrlCalls };
  r = await req(port, 'POST', '/api/ai/image', { task: 'generate', prompt: 'url test', size: '512x512', count: 1 }, { ...H, 'x-ai-confirm': 'true' });
  results.checks.imageUrlCached = r.status === 200 && r.json.mode === 'real' && Array.isArray(r.json.candidates)
    && r.json.candidates[0].imageDataUrl.startsWith('data:image/png;base64,')
    && /^[0-9a-f]{64}$/.test(r.json.candidates[0].sha256 || '')
    && !r.text.includes('/img.png') && base.imgUrlCalls > imgBefore.imgUrlCalls;
  // 7c) 12h URL 失效（假上游 404）→ 502 失败不计费
  r = await req(port, 'POST', '/api/ai/image', { task: 'generate', prompt: 'expired', size: '512x512', count: 1 }, { ...H, 'x-ai-confirm': 'true' });
  results.checks.imageExpired = r.status === 502 && r.json.billed === false && r.json.error && r.json.error.billed === false;
  // 7d) 尺寸/参考图限制
  results.checks.imageSizeLimit = (await req(port, 'POST', '/api/ai/image', { prompt: 'x', size: '2048x2048' }, { ...H, 'x-ai-confirm': 'true' })).status === 400;
  results.checks.imageRefLimit = (await req(port, 'POST', '/api/ai/image', { prompt: 'x', size: '512x512', images: ['data:image/png;base64,AA==', 'data:image/png;base64,AA==', 'data:image/png;base64,AA==', 'data:image/png;base64,AA=='] }, { ...H, 'x-ai-confirm': 'true' })).status === 400;
  // 7e) 并发 1：两个 image 请求同时发，假上游 maxActive 应为 1
  const [i1, i2] = await Promise.all([
    req(port, 'POST', '/api/ai/image', { prompt: 'concurrent-a', size: '512x512' }, { ...H, 'x-ai-confirm': 'true' }),
    req(port, 'POST', '/api/ai/image', { prompt: 'concurrent-b', size: '512x512' }, { ...H, 'x-ai-confirm': 'true' }),
  ]);
  results.checks.imageSerialQueue = i1.status === 200 && i2.status === 200 && base.maxActive === 1;
  // 8) 上游错误映射：401/429/超时
  await req(port, 'POST', '/api/ai/config', { model: 'fail401' }, H);
  results.checks.upstream401 = (await req(port, 'POST', '/api/ai/chat', { ...chatBody, model: 'fail401' }, { ...H, 'x-ai-confirm': 'true' })).status === 401;
  await req(port, 'POST', '/api/ai/config', { model: 'fail429' }, H);
  results.checks.upstream429 = (await req(port, 'POST', '/api/ai/chat', { ...chatBody, model: 'fail429' }, { ...H, 'x-ai-confirm': 'true' })).status === 429;
  await req(port, 'POST', '/api/ai/config', { model: 'slow', timeoutMs: 300 }, H);
  const slow = await req(port, 'POST', '/api/ai/chat', { ...chatBody, model: 'slow' }, { ...H, 'x-ai-confirm': 'true' });
  results.checks.timeout = slow.status === 504;
  // 9) 无 key/Mock 模式
  await req(port, 'POST', '/api/ai/config', { mode: 'mock', providers: { 'openai-compatible': { apiKey: '' } } }, H);
  r = await req(port, 'POST', '/api/ai/chat', { task: 'analyze' }, H);
  results.checks.mockNoKey = r.status === 200 && r.json.mode === 'mock' && r.json.reason === 'no_key';
  r = await req(port, 'POST', '/api/ai/image', { task: 'generate', size: '256x256' }, H);
  results.checks.mockImage = r.status === 200 && r.json.mode === 'mock' && Array.isArray(r.json.candidates);
  // 10) test 端点 + 全响应无 secret
  results.checks.testEndpoint = (await req(port, 'POST', '/api/ai/test', {}, H)).status === 200;
  results.checks.noSecretInResponses = !allTexts.some((t) => t.includes(SECRET));
  results.checks.serveLogNoSecret = !serveOut.includes(SECRET);
  results.pass = Object.values(results.checks).every(Boolean);
} catch (e) {
  results.errors.push(String((e && e.stack) || e));
  results.pass = false;
} finally {
  try { upstream && upstream.server.close(); } catch (e) { /* ignore */ }
  try { serve && serve.kill(); } catch (e) { /* ignore */ }
  await fs.rm(tmp, { recursive: true, force: true }).catch(() => {});
}
console.log(JSON.stringify(results, null, 2));
await fs.writeFile(path.join(__dirname, 'ai-proxy-test-results.json'), JSON.stringify(results, null, 2), 'utf8');
process.exit(results.pass ? 0 : 1);
