// v2/app/test-qwen-image.mjs — T101 Qwen-Image 3.0 app 生图接入（fake DashScope 异步上游）
import { spawn } from 'node:child_process';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const TOKEN = 't101-test-token';
const UP = 8171;
const APP = 8172;
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Z4z8AAAAASUVORK5CYII=', 'base64');
const out = { schema: 'mozheng.app.qwen-image-test.v1', cases: {}, errors: [] };
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 't101-'));
let polls = 0; let submitBody = null; let imgHits = 0;
const fake = http.createServer((req, res) => {
  const send = (code, obj, type = 'application/json') => { res.writeHead(code, { 'content-type': type }); res.end(type === 'application/json' ? JSON.stringify(obj) : obj); };
  if (req.method === 'POST' && req.url.includes('/api/v1/services/aigc/image-generation/generation')) {
    let b = ''; req.on('data', (c) => { b += c; }); req.on('end', () => { try { submitBody = JSON.parse(b); } catch (e) { submitBody = null; } send(200, { output: { task_id: 'task-qwen-1', task_status: 'PENDING' }, request_id: 'rq-1' }); });
    return;
  }
  if (req.method === 'GET' && req.url.includes('/api/v1/tasks/task-qwen-1')) {
    polls += 1;
    if (polls <= 1) return send(200, { output: { task_id: 'task-qwen-1', task_status: 'RUNNING' } });
    // T120：结果图改回 data URL（服务端直通，不再经回环下载——回环会被 SSRF 参考图防护拦截）
    return send(200, { output: { task_id: 'task-qwen-1', task_status: 'SUCCEEDED', results: [{ url: 'data:image/png;base64,' + PNG.toString('base64') }, { url: 'data:image/png;base64,' + PNG.toString('base64') }] }, usage: { image_count: 2 } });
  }
  if (req.method === 'GET' && req.url.includes('/img.png')) { imgHits += 1; return send(200, PNG, 'image/png'); }
  send(404, { error: 'not found' });
});
await new Promise((r) => fake.listen(UP, '127.0.0.1', r));
const serve = spawn(process.execPath, [path.join(ROOT, 'v2', 'serve.mjs')], { cwd: ROOT, env: { ...process.env, PORT: String(APP), AI_LOCAL_TOKEN: TOKEN, AI_CONFIG_PATH: path.join(tmp, 'c.json'), AI_TOKEN_PATH: path.join(tmp, 't'), AI_TEST_ALLOW_LOOPBACK_UPSTREAM: '1' }, stdio: 'ignore' });
let actual = null;
for (let i = 0; i < 80 && !actual; i += 1) {
  for (let p = APP; p <= APP + 10; p += 1) { try { const r = await fetch(`http://127.0.0.1:${p}/health`); if (r.ok) { actual = p; break; } } catch (e) { /* ignore */ } }
  if (!actual) await new Promise((r) => setTimeout(r, 200));
}
if (!actual) throw new Error('serve 未启动');
let browser = null; let errors = [];
const done = (code = 0) => { try { fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'test-qwen-image-result.json'), JSON.stringify(out, null, 2), 'utf8'); } catch (e) {} process.exit(code); };
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_240s'; done(3); }, 240000);
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await ctx.addInitScript((token) => { window.__AI_LOCAL_TOKEN__ = token; }, TOKEN);
  const page = await ctx.newPage();
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(`http://127.0.0.1:${actual}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(900);
  // 通过代理配置 qwen（fake 上游）
  out.cases.config = await page.evaluate(async (cfg) => {
    const token = window.__AI_LOCAL_TOKEN__;
    const res = await fetch('/api/ai/config', { method: 'POST', headers: { 'content-type': 'application/json', 'x-ai-token': token }, body: JSON.stringify(cfg) });
    const data = await res.json();
    await window.__V2_APP__.t96.refreshConfig();
    window.__V2_APP__.t96.setPreset('qwen');
    window.__V2_APP__.t96.setToggles({ allowReal: true, requireConfirm: true, privacyMode: false });
    return { data, state: window.__V2_APP__.t96.getState() };
  }, { mode: 'real', provider: 'qwen', model: 'qwen3.8-max', privacyMode: false, dashscopePollMs: 60, providers: { qwen: { baseUrl: `http://127.0.0.1:${UP}/compatible-mode/v1`, imageBaseUrl: `http://127.0.0.1:${UP}`, model: 'qwen3.8-max', imageModel: 'qwen-image-3.0', imageProtocol: 'dashscope-async', apiKey: 'qwen-test-key-never-frontend' } } });
  await page.waitForTimeout(400);
  out.cases.preset = await page.evaluate(() => { const a = window.__V2_APP__; const s = a.t96.getState(); return { realEligible: s.realEligible, preset: s.preset, label: s.label, badge: a.t96.providerBadge(), presets: a.t96.getPresets ? Object.keys(a.t96.getPresets()) : [] }; });
  // 候选生成（直接设 directions 避免再走 chat）
  await page.evaluate(() => {
    const a = window.__V2_APP__;
    a.state.analysis = { global: { summary: 'Qwen 局部测试画面', subject: ['山'], medium: { kind: 'digital' }, palette: ['#7f97a8'], mood: ['安静'] }, observations: [], regions: [], confidence: 0.7 };
    a.state.directions = [{ id: 'dir-qwen-1', title: '保留雾带留白', why: '局部更安静', confidence: 0.7, tags: ['局部'] }];
    a.state.selectedDirection = null; a.state.candidates = null; a.closePopovers(); a.runGenerate('dir-qwen-1');
  });
  await page.waitForTimeout(400);
  out.cases.confirm = await page.evaluate(() => ({ visible: document.getElementById('aiConfirmModal').classList.contains('show'), text: document.getElementById('aiConfirmText').textContent }));
  await page.click('#btnAiConfirmOk');
  for (let i = 0; i < 80; i += 1) {
    await page.waitForTimeout(150);
    const has = await page.evaluate(() => (window.__V2_APP__.state.candidates || []).length > 0);
    if (has) break;
  }
  out.cases.generate = await page.evaluate(() => { const a = window.__V2_APP__; const c = (a.state.candidates || [])[0]; return { candidates: (a.state.candidates || []).length, meta: a.t96.getLastCall(), candidate: c ? { id: c.id, sha256: c.sha256, bytes: c.bytes, width: c.width, height: c.height, image: String(c.imageDataUrl || '').startsWith('data:image/') } : null, badge: a.t96.providerBadge(), note: (document.querySelector('.ai-candidate-note') || {}).textContent }; });
  out.cases.upstream = { submit: submitBody, polls, imgHits };
  // 落层 + L6
  const beforeLayers = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.evaluate(() => { const b = document.querySelector('[data-cand="0"]'); if (b) b.click(); });
  await page.waitForTimeout(600);
  out.cases.apply = await page.evaluate((before) => { const a = window.__V2_APP__; const gen = [...a.state.records].reverse().find((r) => r.layer === 'L6' && r.kind === 'generation'); return { layerDelta: a.engine.getLayers().length - before, generation: gen }; }, beforeLayers);
  // 设置面板能力/文案
  await page.evaluate(() => document.getElementById('btnMore').click()); await page.waitForTimeout(120); await page.evaluate(() => document.getElementById('btnAbout').click()); await page.waitForTimeout(300);
  await page.selectOption('#aiProviderSelect', 'qwen');
  out.cases.ui = await page.evaluate(() => ({ option: [...document.querySelectorAll('#aiProviderSelect option')].map((o) => o.value), license: document.querySelector('#aiAccessCard .license-note').textContent, status: document.getElementById('aiTestStatus').textContent }));
  const afterApply = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.evaluate(() => { const a = window.__V2_APP__; if (a.engine && typeof a.engine.undo === 'function') a.engine.undo(); });
  await page.waitForTimeout(500);
  out.cases.undo = await page.evaluate((n) => ({ layers: window.__V2_APP__.engine.getLayers().length, delta: window.__V2_APP__.engine.getLayers().length - n }), afterApply);
  await page.evaluate(() => document.getElementById('aiAccessCard').scrollIntoView({ block: 'center' }));
  await page.screenshot({ path: path.join(ROOT, 'v2', 'app', 'ui-ai-qwen-1920.png') });
  // 三档截图（Qwen 设置/能力）
  const shots = {};
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await page.setViewportSize({ width: w, height: h });
    await page.waitForTimeout(200);
    await page.evaluate(() => document.getElementById('aiAccessCard').scrollIntoView({ block: 'center' }));
    await page.waitForTimeout(200);
    await page.screenshot({ path: path.join(ROOT, 'v2', 'app', 'ui-ai-qwen-' + w + '.png') });
    shots[w] = await page.evaluate(() => { const r = document.getElementById('aiAccessCard').getBoundingClientRect(); return { overX: document.documentElement.scrollWidth > innerWidth + 1, overY: document.documentElement.scrollHeight > innerHeight + 1, cardVisible: r.width > 100 && r.bottom <= innerHeight + 1 && r.top >= -1, val: (document.getElementById('aiProviderSelect') || {}).value }; });
  }
  out.cases.screenshots = shots;
  out.errors = errors.slice(0, 10);
  out.pass = {
    config: out.cases.config.state.realEligible === true && out.cases.config.state.preset === 'qwen',
    preset: out.cases.preset.realEligible && out.cases.preset.label === 'Qwen' && /Qwen/.test(out.cases.preset.badge),
    qwenSubmit: out.cases.upstream.submit && out.cases.upstream.submit.model === 'qwen-image-3.0' && out.cases.upstream.submit.parameters && out.cases.upstream.submit.parameters.size === '1024*1024' && out.cases.upstream.submit.parameters.watermark === false && out.cases.upstream.submit.parameters.n === 2,
    queue: out.cases.upstream.polls >= 1 && out.cases.upstream.imgHits === 1,
    generate: out.cases.generate.candidates >= 1 && out.cases.generate.meta.provider === 'qwen' && out.cases.generate.meta.mock === false && out.cases.generate.candidate && /^[0-9a-f]{64}$/i.test(String(out.cases.generate.candidate.sha256)) && out.cases.generate.candidate.image,
    note: /价格待实测/.test(out.cases.generate.note || '') && /异步排队/.test(out.cases.generate.note || ''),
    apply: out.cases.apply.layerDelta === 1 && out.cases.apply.generation && out.cases.apply.generation.model.provider === 'qwen' && out.cases.apply.generation.params.candidate_sha256 && out.cases.apply.generation.cost_cny === 0,
    ui: out.cases.ui.option.filter((x) => x === 'qwen').length === 1 && /Qwen 生图/.test(out.cases.ui.license) && /异步/.test(out.cases.ui.license) && /vision ✓ \/ image ✓/.test(out.cases.ui.status),
    undo: out.cases.undo.delta === -1,
    screenshots: Object.values(shots).every((v) => !v.overX && !v.overY && v.cardVisible && v.val === 'qwen'),
    noConsoleErrors: out.errors.length === 0,
  };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} finally {
  clearTimeout(hard);
  try { await browser.close(); } catch (e) {}
  try { fake.close(); } catch (e) {}
  try { serve.kill(); } catch (e) {}
  done(0);
}
