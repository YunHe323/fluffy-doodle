#!/usr/bin/env node
/**
 * v2/qa/tools/guides-test.mjs — T106-B 自测（Node，无浏览器、无第三方依赖）
 * 运行：node v2/qa/tools/guides-test.mjs
 * 覆盖：grid/thirds 边界与 0 尺寸抛错、吸附阈值/空数组/负坐标/边界 clamp、
 *      镜像点/镜像笔迹（空数组/数组或对象点格式）、笔刷光标半径/硬度/压力、nearestGuideValue 边界。
 */
import {
  GUIDE_DEFAULTS,
  gridLines,
  thirdsLines,
  normalizeGuides,
  nearestGuideValue,
  snapPoint,
  mirrorPoint,
  mirrorStroke,
  brushCursorCircle,
} from '../../app/core/guides.mjs';

let pass = 0;
const failures = [];
function ok(name, cond, detail = '') {
  if (cond) { pass += 1; return; }
  failures.push(`${name}${detail ? ` :: ${detail}` : ''}`);
}
function eq(name, actual, expected) {
  ok(name, Object.is(actual, expected), `expected ${String(expected)}, got ${String(actual)}`);
}
function near(name, actual, expected, tol = 0.001) {
  ok(name, Math.abs(actual - expected) <= tol, `expected ≈${expected}±${tol}, got ${actual}`);
}
function deep(name, actual, expected) {
  ok(name, JSON.stringify(actual) === JSON.stringify(expected), `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}
function throws(name, fn, ctor = Error) {
  try { fn(); failures.push(`${name} :: 未抛错`); } catch (e) {
    if (e instanceof ctor) { pass += 1; return; }
    failures.push(`${name} :: 抛错类型 ${e.constructor.name}（期望 ${ctor.name}）: ${e.message}`);
  }
}

/* ---------------- 0. 导出 / 默认值 ---------------- */
eq('GUIDE_DEFAULTS.spacing', GUIDE_DEFAULTS.spacing, 80);
eq('GUIDE_DEFAULTS.majorEvery', GUIDE_DEFAULTS.majorEvery, 4);
eq('GUIDE_DEFAULTS.threshold', GUIDE_DEFAULTS.threshold, 6);
eq('GUIDE_DEFAULTS.axis', GUIDE_DEFAULTS.axis, 'both');
eq('GUIDE_DEFAULTS.hardness', GUIDE_DEFAULTS.hardness, 0.8);
eq('GUIDE_DEFAULTS.pressure', GUIDE_DEFAULTS.pressure, 1);
for (const [name, fn] of Object.entries({ gridLines, thirdsLines, normalizeGuides, nearestGuideValue, snapPoint, mirrorPoint, mirrorStroke, brushCursorCircle })) {
  eq(`导出函数 ${name}`, typeof fn, 'function');
}

/* ---------------- 1. gridLines ---------------- */
const g = gridLines(400, 300, { spacing: 100, majorEvery: 2 });
deep('grid vertical values', g.vertical.map((l) => l.value), [100, 200, 300]);
deep('grid vertical major', g.vertical.map((l) => l.major), [false, true, false]);
deep('grid horizontal values', g.horizontal.map((l) => l.value), [100, 200]);
deep('grid horizontal major', g.horizontal.map((l) => l.major), [false, true]);
eq('grid spacing 回显', g.spacing, 100);
eq('grid majorEvery 回显', g.majorEvery, 2);

const gDefault = gridLines(400, 400);
deep('默认 spacing80 竖向内部线', gDefault.vertical.map((l) => l.value), [80, 160, 240, 320]);
deep('默认 majorEvery4：仅 320 为主线', gDefault.vertical.map((l) => l.major), [false, false, false, true]);
deep('默认 400x400 横竖向相同', gDefault.horizontal.map((l) => l.value), gDefault.vertical.map((l) => l.value));

deep('spacing 等于宽：无内部线', gridLines(80, 80, { spacing: 80 }).vertical, []);
deep('spacing 大于宽：无线', gridLines(50, 50, { spacing: 100 }).vertical, []);
deep('majorEvery=1 全部主线', gridLines(300, 10, { spacing: 100, majorEvery: 1 }).vertical.map((l) => l.major), [true, true]);
eq('非整数倍间距只取内部线', gridLines(250, 250, { spacing: 100 }).vertical.length, 2);
ok('grid 返回新数组（两次调用互不影响）', (() => {
  const a = gridLines(400, 400);
  a.vertical.push({ value: 1, major: true, index: 9 });
  const b = gridLines(400, 400);
  return b.vertical.length === 4;
})());
throws('grid width=0 抛错', () => gridLines(0, 100), RangeError);
throws('grid height=0 抛错', () => gridLines(100, 0), RangeError);
throws('grid 负尺寸抛错', () => gridLines(-1, 100), RangeError);
throws('grid NaN 尺寸抛错', () => gridLines(NaN, 100), RangeError);
throws('grid spacing=0 抛错', () => gridLines(100, 100, { spacing: 0 }), RangeError);
throws('grid spacing 负数抛错', () => gridLines(100, 100, { spacing: -5 }), RangeError);
throws('grid majorEvery=0 抛错', () => gridLines(100, 100, { majorEvery: 0 }), RangeError);
throws('grid majorEvery 非整数抛错', () => gridLines(100, 100, { majorEvery: 1.5 }), RangeError);

/* ---------------- 2. thirdsLines ---------------- */
deep('thirds 400x300', thirdsLines(400, 300), { vertical: [133.333, 266.667], horizontal: [100, 200] });
deep('thirds 精确 1/3、2/3', thirdsLines(300, 600), { vertical: [100, 200], horizontal: [200, 400] });
throws('thirds width=0 抛错', () => thirdsLines(0, 100), RangeError);
throws('thirds height=0 抛错', () => thirdsLines(100, 0), RangeError);
throws('thirds 负尺寸抛错', () => thirdsLines(100, -3), RangeError);

/* ---------------- 3. normalizeGuides ---------------- */
deep('normalize 数字→竖向', normalizeGuides([10, 20]).x, [10, 20]);
deep('normalize 对象 axis', normalizeGuides([{ axis: 'y', value: 30 }]).y, [30]);
deep('normalize {x}/{y}', normalizeGuides([{ x: 1 }, { y: 2 }]).all, [{ axis: 'x', value: 1 }, { axis: 'y', value: 2 }]);
deep('normalize 空数组', normalizeGuides([]), { x: [], y: [], all: [] });
deep('normalize null', normalizeGuides(null), { x: [], y: [], all: [] });
throws('normalize 非数组抛错', () => normalizeGuides('x'), TypeError);
throws('normalize 无法解析项抛错', () => normalizeGuides([{ foo: 1 }]), TypeError);

/* ---------------- 4. nearestGuideValue ---------------- */
deep('nearest 空数组 → null', nearestGuideValue(10, []), { value: null, distance: Infinity, index: -1 });
deep('nearest 正常命中', nearestGuideValue(20, [10, 20.5]), { value: 20.5, distance: 0.5, index: 1 });
near('nearest 距离字段', nearestGuideValue(18, [10, 20]).distance, 2);
eq('nearest 阈值内（等于 threshold）命中', nearestGuideValue(16, [10], 6).value, 10);
eq('nearest 超出 threshold → null', nearestGuideValue(16.001, [10], 6).value, null);
eq('nearest 恰好 threshold 边界', nearestGuideValue(6, [0], 6).value, 0);
eq('nearest threshold=0 只命中相等', nearestGuideValue(5, [5], 0).value, 5);
eq('nearest threshold=0 不相近 → null', nearestGuideValue(5.0001, [5], 0).value, null);
eq('nearest 平局取第一个', nearestGuideValue(5, [0, 10], 6).value, 0);
eq('nearest object guides（value/x/y）', nearestGuideValue(28, [{ value: 30 }, { x: 40 }, { y: 50 }]).value, 30);
eq('nearest 跳过无法解析项', nearestGuideValue(28, [{ foo: 1 }, 30]).value, 30);
throws('nearest value 非数字抛错', () => nearestGuideValue('10', [10]), TypeError);
throws('nearest threshold 负数抛错', () => nearestGuideValue(10, [10], -1), RangeError);
throws('nearest guides 非数组抛错', () => nearestGuideValue(10, 'x'), TypeError);

/* ---------------- 5. snapPoint ---------------- */
const snapEmpty = snapPoint({ x: 97, y: 53 }, { guides: [] });
deep('空 guides 不吸附', snapEmpty, { x: 97, y: 53, snappedX: false, snappedY: false, guideX: null, guideY: null });
eq('snap 返回原坐标类型', snapEmpty.x, 97);

const snapX = snapPoint({ x: 97, y: 53 }, { guides: [100], threshold: 6 });
eq('x 吸附到 100', snapX.x, 100);
eq('snappedX true', snapX.snappedX, true);
eq('guideX 记录', snapX.guideX, 100);
eq('y 不变', snapX.y, 53);
eq('snappedY false', snapX.snappedY, false);
eq('guideY null', snapX.guideY, null);

const snapBoth = snapPoint({ x: 96.5, y: 118 }, { guides: [100, { axis: 'y', value: 120 }], threshold: 6 });
deep('双向吸附', snapBoth, { x: 100, y: 120, snappedX: true, snappedY: true, guideX: 100, guideY: 120 });

const snapThr = snapPoint({ x: 106, y: 0 }, { guides: [100], threshold: 6 });
eq('距离=threshold 仍吸附', snapThr.x, 100);
const snapOut = snapPoint({ x: 106.001, y: 0 }, { guides: [100], threshold: 6 });
eq('超出 threshold 不吸附', snapOut.x, 106.001);
eq('超出 threshold snappedX false', snapOut.snappedX, false);

const snapClamp = snapPoint({ x: -5, y: 120 }, { guides: [], width: 100, height: 100 });
deep('负坐标 + 尺寸 → clamp 到画布内', snapClamp, { x: 0, y: 100, snappedX: false, snappedY: false, guideX: null, guideY: null });
const snapNoClamp = snapPoint({ x: -5, y: 120 }, { guides: [] });
eq('无尺寸不 clamp（允许负/超出）', snapNoClamp.x, -5);
eq('无尺寸 y 不 clamp', snapNoClamp.y, 120);

const snapNegGuide = snapPoint({ x: -4, y: 10 }, { guides: [{ x: -6 }], threshold: 6 });
eq('负向 guide 可吸附', snapNegGuide.x, -6);

throws('snap point 缺失抛错', () => snapPoint(null), TypeError);
throws('snap point.x 非数字抛错', () => snapPoint({ x: NaN, y: 0 }), TypeError);
throws('snap width=0 抛错', () => snapPoint({ x: 1, y: 1 }, { width: 0 }), RangeError);
throws('snap height=0 抛错', () => snapPoint({ x: 1, y: 1 }, { height: 0 }), RangeError);
throws('snap threshold 负数抛错', () => snapPoint({ x: 1, y: 1 }, { threshold: -2 }), RangeError);

/* ---------------- 6. mirrorPoint ---------------- */
deep('mirror axis=x', mirrorPoint({ x: 30, y: 20 }, { axis: 'x', width: 200, height: 100 }), { x: 170, y: 20 });
deep('mirror axis=y', mirrorPoint({ x: 30, y: 20 }, { axis: 'y', width: 200, height: 100 }), { x: 30, y: 80 });
deep('mirror axis=both（默认）', mirrorPoint({ x: 30, y: 20 }, { width: 200, height: 100 }), { x: 170, y: 80 });
deep('mirror 画布中心不动', mirrorPoint({ x: 100, y: 50 }, { axis: 'both', width: 200, height: 100 }), { x: 100, y: 50 });
deep('mirror 负坐标→画布外（不 clamp）', mirrorPoint({ x: -10, y: 20 }, { axis: 'x', width: 200, height: 100 }), { x: 210, y: 20 });
throws('mirror axis 非法抛错', () => mirrorPoint({ x: 1, y: 1 }, { axis: 'z', width: 10, height: 10 }), TypeError);
throws('mirror width=0 抛错', () => mirrorPoint({ x: 1, y: 1 }, { width: 0, height: 10 }), RangeError);
throws('mirror height=0 抛错', () => mirrorPoint({ x: 1, y: 1 }, { width: 10, height: 0 }), RangeError);
throws('mirror point 非法抛错', () => mirrorPoint({ x: 'a', y: 1 }, { width: 10, height: 10 }), TypeError);

/* ---------------- 7. mirrorStroke ---------------- */
deep('空笔迹 → []', mirrorStroke([], { width: 200, height: 100 }), []);
const strokeXY = [{ x: 30, y: 20, t: 1 }, { x: 40, y: 30 }];
const mx = mirrorStroke(strokeXY, { axis: 'x', width: 200, height: 100 });
eq('axis=x 返回 1 条镜像笔迹', mx.length, 1);
deep('axis=x 镜像坐标 + 保留额外字段', mx[0], [{ x: 170, y: 20, t: 1 }, { x: 160, y: 30 }]);
const my = mirrorStroke(strokeXY, { axis: 'y', width: 200, height: 100 });
deep('axis=y 镜像', my[0], [{ x: 30, y: 80, t: 1 }, { x: 40, y: 70 }]);
const mboth = mirrorStroke(strokeXY, { width: 200, height: 100 });
eq('both 返回 3 条镜像笔迹', mboth.length, 3);
deep('both[0]=X 镜像', mboth[0], [{ x: 170, y: 20, t: 1 }, { x: 160, y: 30 }]);
deep('both[1]=Y 镜像', mboth[1], [{ x: 30, y: 80, t: 1 }, { x: 40, y: 70 }]);
deep('both[2]=中心对称', mboth[2], [{ x: 170, y: 80, t: 1 }, { x: 160, y: 70 }]);
const strokeArr = [[30, 20], [40, 30]];
deep('数组点格式保持数组', mirrorStroke(strokeArr, { axis: 'x', width: 200, height: 100 }), [[[170, 20], [160, 30]]]);
deep('单点笔迹数组格式', mirrorStroke([[10, 10]], { axis: 'x', width: 100, height: 100 }), [[[90, 10]]]);
throws('mirrorStroke 非数组抛错', () => mirrorStroke(null, { width: 10, height: 10 }), TypeError);
throws('mirrorStroke 无效点抛错', () => mirrorStroke([{ x: 1 }], { width: 10, height: 10 }), TypeError);
throws('mirrorStroke 数组点长度不足抛错', () => mirrorStroke([[1]], { width: 10, height: 10 }), TypeError);
throws('mirrorStroke width=0 抛错', () => mirrorStroke([], { width: 0, height: 10 }), RangeError);
throws('mirrorStroke axis 非法抛错', () => mirrorStroke([], { axis: 'z', width: 10, height: 10 }), TypeError);

/* ---------------- 8. brushCursorCircle ---------------- */
const c1 = brushCursorCircle({ x: 10, y: 20, size: 40 });
near('cursor radius=20（pressure 默认1）', c1.radius, 20);
near('cursor inner=radius*0.8', c1.innerRadius, 16);
near('cursor alpha=0.35+0.45*0.8', c1.alpha, 0.71);
const cHard0 = brushCursorCircle({ x: 0, y: 0, size: 40, hardness: 0, pressure: 1 });
near('hardness=0 inner=0', cHard0.innerRadius, 0);
near('hardness=0 alpha=0.35', cHard0.alpha, 0.35);
const cHard1 = brushCursorCircle({ x: 0, y: 0, size: 40, hardness: 1, pressure: 1 });
near('hardness=1 inner=radius', cHard1.innerRadius, cHard1.radius);
near('hardness=1 alpha=0.8', cHard1.alpha, 0.8);
const cPressure = brushCursorCircle({ x: 0, y: 0, size: 40, pressure: 0.5 });
near('pressure=0.5 radius=size/2*0.75', cPressure.radius, 15);
const cPressureLow = brushCursorCircle({ x: 0, y: 0, size: 40, pressure: 0 });
near('pressure=0 radius=size/4', cPressureLow.radius, 10);
const cClamp = brushCursorCircle({ x: 0, y: 0, size: 40, pressure: 5, hardness: -2 });
near('pressure>1 clamp 到 1', cClamp.radius, 20);
near('hardness<0 clamp 到 0', cClamp.innerRadius, 0);
ok('alpha 在 [0,1]', cClamp.alpha >= 0 && cClamp.alpha <= 1);
throws('cursor size=0 抛错', () => brushCursorCircle({ x: 0, y: 0, size: 0 }), RangeError);
throws('cursor size 负数抛错', () => brushCursorCircle({ x: 0, y: 0, size: -4 }), RangeError);
throws('cursor x 非数字抛错', () => brushCursorCircle({ x: 'a', y: 0, size: 4 }), TypeError);
throws('cursor 缺 size 抛错', () => brushCursorCircle({ x: 0, y: 0 }), TypeError);
throws('cursor opts 非法抛错', () => brushCursorCircle(null), TypeError);

/* ---------------- summary ---------------- */
if (failures.length) {
  console.error(`✗ guides self-test failed: ${failures.length} 项失败 / ${pass + failures.length} 项`);
  for (const f of failures) console.error('  - ' + f);
  process.exit(1);
}
console.log(`✓ guides self-test passed: ${pass} 项断言全部通过（Node，无浏览器）`);
process.exit(0);
