// v2/app/test-mask-compare.mjs —— 选区 mask 落层（框外保留）+ 候选对比滑杆
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8158;
const out = { schema: 'mozheng.app.mask-compare.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  fs.writeFileSync(ROOT + '\\v2\\app\\test-mask-compare-result.json', JSON.stringify(out, null, 2), 'utf8');
  process.exit(code);
};
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1200);
  // UX-T120：空白画布预检会拦截 runAnalyze；先画一笔让画布非空。
  await page.evaluate(() => {
    const c = window.__V2_APP__.controller;
    c.begin({ x: 420, y: 320, pressure: 0.8, timestamp: performance.now() });
    for (let i = 1; i <= 14; i++) c.append({ x: 420 + i * 18, y: 320 + Math.sin(i / 4) * 50, pressure: 0.7, timestamp: performance.now() + i * 16 });
    c.end();
  });
  await page.waitForTimeout(300);
  // 建立真实引擎选区（矩形）
  await page.evaluate(() => {
    const a = window.__V2_APP__;
    a.t96.setToggles({ allowReal: false, privacyMode: true });
    const sm = a.t64.selectionManager;
    sm.clear ? sm.clear() : null;
    sm.rect(300, 220, 700, 520);
    a.state.selection = { x: 300, y: 220, width: 400, height: 300 };
    a.drawSelection();
  });
  const before = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    const url = await a.engine.getCompositeDataUrl();
    return { url, hasSel: a.t64.hasSelection(), layers: a.engine.getLayers().length };
  });
  await page.evaluate(async () => {
    const a = window.__V2_APP__;
    await a.runAnalyze();
    await a.runDirections();
    const d = a.state.directions && a.state.directions[0];
    await a.runGenerate(d ? d.id : 'mock-dir-1');
  });
  await page.waitForTimeout(800);
  const cand = await page.evaluate(() => ({ n: (window.__V2_APP__.state.candidates || []).length, maskedBefore: null }));
  // 对比 UI
  await page.evaluate(() => window.__V2_APP__.openPopover('popAI'));
  await page.waitForTimeout(250);
  const compare = await page.evaluate(() => {
    const a = window.__V2_APP__;
    try { a.t101.renderAI(); } catch (e) { /* ignore */ }
    const btn = document.querySelector('[data-compare-cand]');
    if (btn) btn.click();
    const range = document.getElementById('candCompareRange');
    const result = document.querySelector('.cand-compare-stage .cmp-result');
    if (range) { range.value = '70'; range.dispatchEvent(new Event('input', { bubbles: true })); }
    return { hasBtn: !!btn, hasRange: !!range, clip: result ? getComputedStyle(result).clipPath : null, stage: !!document.querySelector('.cand-compare-stage') };
  });
  // 落层
  await page.click('[data-cand="0"]');
  await page.waitForTimeout(900);
  const after = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    const url = await a.engine.getCompositeDataUrl();
    const records = a.state.records.filter((r) => r.kind === 'generation').slice(-2).map((r) => ({ masked: r.params && r.params.masked, mask_policy: r.params && r.params.mask_policy, skill: r.params && r.params.skill }));
    return { url, layers: a.engine.getLayers().length, transformActive: !!a.state.transformActive, records };
  });
  // 像素比较：选区外应完全一致
  out.cases.mask = await page.evaluate(async ({ beforeUrl, afterUrl, sel }) => {
    const load = (src) => new Promise((res) => { const i = new Image(); i.onload = () => res(i); i.src = src; });
    const [ib, ia] = await Promise.all([load(beforeUrl), load(afterUrl)]);
    const c = document.createElement('canvas'); c.width = ib.width; c.height = ib.height;
    const g = c.getContext('2d');
    g.drawImage(ib, 0, 0); const b = g.getImageData(0, 0, c.width, c.height).data;
    g.clearRect(0, 0, c.width, c.height); g.drawImage(ia, 0, 0); const a = g.getImageData(0, 0, c.width, c.height).data;
    let outsideDiff = 0, insideDiff = 0;
    for (let y = 0; y < c.height; y += 1) for (let x = 0; x < c.width; x += 1) {
      const i = (y * c.width + x) * 4;
      const diff = Math.abs(b[i] - a[i]) + Math.abs(b[i + 1] - a[i + 1]) + Math.abs(b[i + 2] - a[i + 2]) + Math.abs(b[i + 3] - a[i + 3]);
      const inside = x >= sel.x && x < sel.x + sel.width && y >= sel.y && y < sel.y + sel.height;
      if (inside) insideDiff += diff; else outsideDiff += diff;
    }
    return { outsideDiff, insideDiff, pixels: c.width * c.height };
  }, { beforeUrl: before.url, afterUrl: after.url, sel: { x: 300, y: 220, width: 400, height: 300 } });
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-mask-compare-1920.png' });
  out.cases.candidates = cand;
  out.cases.compare = compare;
  out.cases.apply = { layers: after.layers, transformActive: after.transformActive, records: after.records };
  out.cases.maskOk = out.cases.mask.outsideDiff === 0 && out.cases.mask.insideDiff > 0 && before.hasSel;
  out.cases.compareOk = compare.hasBtn && compare.hasRange && compare.stage;
  out.cases.applyOk = after.layers === before.layers + 1 && after.transformActive && after.records.some((r) => r.masked === true) && after.records.some((r) => r.skill === 'image.generate');
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.maskOk && out.cases.compareOk && out.cases.applyOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  await finish(3);
}
