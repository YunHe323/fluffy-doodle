#!/usr/bin/env node
// v2/engine/test/group-mask.mjs —— T67 组蒙版/组剪贴测试（零依赖 CDP）
// 语义：组蒙版空白 tile = 隐藏（DstIn 透明）；白色蒙版笔触 = 显示（Procreate 式白显黑隐）。
// 用法：node v2/engine/test/group-mask.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const checks = {};
  const mkEngine = async () => {
    const canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 512;
    const eng = new Engine({ canvas, width: 512, height: 512, layers: 1 });
    await eng.init(); eng.setBrush({ type: 'soft', sizePx: 30 });
    return eng;
  };
  const draw = (eng, x0, y, x1) => {
    eng.beginStroke({ x: x0, y, pressure: 0.9, timestamp: performance.now(), pointerType: 'synthetic' });
    for (let i = 1; i < 28; i += 1) eng.appendPoint({ x: x0 + (x1 - x0) * i / 27, y, pressure: 0.9, timestamp: performance.now(), pointerType: 'synthetic' });
    return eng.endStroke();
  };
  const regionInk = async (url, x0, y0, x1, y1) => {
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const cx = c.getContext('2d'); cx.drawImage(img, 0, 0);
    const d = cx.getImageData(0, 0, c.width, c.height).data;
    let ink = 0;
    for (let y = y0; y < y1; y += 1) for (let x = x0; x < x1; x += 1) {
      const i = (y * c.width + x) * 4;
      if (d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220) ink += 1;
    }
    return ink;
  };
  // 建组蒙版空白 tile（透明 = 隐藏）：覆盖 group 内容所在 tile（group y=300 → ty=1, x 0..470 → tx=0,1）
  const blankMaskTiles = (eng, groupId) => {
    for (const key of ['0,1', '1,1']) {
      const tile = eng.maskStore.ensureTile(groupId, key);
      tile.surface.getCanvas().clear(eng.CK.TRANSPARENT);
      tile.surface.flush();
      tile.image = tile.surface.makeImageSnapshot();
    }
  };

  // ===== A. 组蒙版 =====
  const eng = await mkEngine();
  draw(eng, 40, 100, 250);                  // 基础层（不受组蒙版影响）
  eng.addGroup('G'); const group = eng.getGroups()[0];
  eng.addLayer({ name: '组内层', group: group.id });
  draw(eng, 40, 300, 470); await raf(); await raf();
  checks.groupRenders = (await regionInk(await eng.getCompositeDataUrl(), 300, 280, 450, 320)) > 100;
  eng.addGroupMask(group.id);
  blankMaskTiles(eng, group.id); await raf();
  checks.groupMaskBlankHides = (await regionInk(await eng.getCompositeDataUrl(), 60, 280, 240, 320)) < 20;
  eng.setActiveGroup(group.id);
  eng.setActiveTarget('group-mask');
  draw(eng, 40, 300, 100); await raf(); await raf();   // 白显
  const revealedUrl = await eng.getCompositeDataUrl();
  checks.groupMaskReveal = (await regionInk(revealedUrl, 45, 280, 95, 320)) > 20
    && (await regionInk(revealedUrl, 180, 280, 240, 320)) < 20;
  checks.groupMaskKeepsBase = (await regionInk(revealedUrl, 100, 80, 240, 120)) > 100;
  eng.undo(); await raf();
  checks.groupMaskUndo = (await regionInk(await eng.getCompositeDataUrl(), 45, 280, 95, 320)) < 20;
  eng.setGroupMaskEnabled(group.id, false); await raf();
  checks.groupMaskDisable = (await regionInk(await eng.getCompositeDataUrl(), 180, 280, 240, 320)) > 20;
  eng.setGroupMaskEnabled(group.id, true); await raf();
  checks.groupMaskEnable = (await regionInk(await eng.getCompositeDataUrl(), 180, 280, 240, 320)) < 20;
  // 序列化（透明 mask tiles + 白笔触）→ 加载后语义保持
  const json = eng.serializeDoc();
  const eng2 = await mkEngine();
  eng2.deserializeDoc(json); await raf(); await raf();
  const doc2 = eng2.getDoc();
  checks.serializeGroupMask = doc2.groups[0].mask.exists === true;
  checks.serializeMaskTiles = eng2.maskStore.listTiles(group.id).length >= 2;
  checks.serializeRender = (await regionInk(await eng2.getCompositeDataUrl(), 180, 280, 240, 320)) < 20;
  eng2.dispose();
  // 删除组蒙版
  eng.removeGroupMask(group.id); await raf();
  checks.groupMaskRemove = (await regionInk(await eng.getCompositeDataUrl(), 180, 280, 240, 320)) > 20;
  eng.dispose();

  // ===== B. 组剪贴（独立引擎） =====
  const engB = await mkEngine();
  draw(engB, 40, 300, 250);                       // 基础层左半
  engB.addGroup('G2'); const g2 = engB.getGroups()[0];
  engB.addLayer({ name: '组内层', group: g2.id });
  draw(engB, 40, 300, 470); await raf(); await raf();
  engB.setGroupClip(g2.id, true); await raf();
  const clipUrl = await engB.getCompositeDataUrl();
  checks.groupClipRightHidden = (await regionInk(clipUrl, 300, 280, 450, 320)) < 20;
  checks.groupClipLeftVisible = (await regionInk(clipUrl, 60, 280, 220, 320)) > 100;
  engB.setGroupClip(g2.id, false); await raf();
  checks.groupClipOff = (await regionInk(await engB.getCompositeDataUrl(), 300, 280, 450, 320)) > 100;
  engB.dispose();

  // ===== C. PSD 桥 =====
  const { psdDocToV2Doc, v2DocToPsdDoc, compareStructure } = await import('/v2/psd/src/v2doc-bridge.js');
  const psdDoc = { width: 512, height: 512, children: [{ type: 'group', name: 'G', mask: { exists: true }, clip: true, children: [{ type: 'layer', name: 'L', mask: null }] }] };
  const v2 = psdDocToV2Doc(psdDoc);
  const back = v2DocToPsdDoc(v2);
  const cmp = compareStructure(v2, psdDoc);
  checks.psdBridge = v2.groups[0].mask.exists === true && v2.groups[0].clip === true
    && !!back.children[0].mask && back.children[0].clip === true
    && cmp.v2.groupMasks === 1 && cmp.psd.groupMasks === 1;

  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  return { ok: checks.ok, checks, environment: { headless: /HeadlessChrome/.test(navigator.userAgent) } };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1500)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
