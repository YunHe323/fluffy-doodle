# 路演 demo v2 · Qwen 原生多模态能力审计与利用方案

> 任务：t2 · owner：multimodal-ai · 日期：**2026-11-08**（Asia/Shanghai）
> 依据（全部本地可查）：`v2/serve.mjs`、`v2/app/core/ai-provider.mjs`、`v2/app/core/mock-ai.mjs`、`v2/app/core/chat-actions.mjs`、`v2/app/core/skills/builtin.mjs`、`v2/app/js/app.js`、`06-技术/模型能力调研_2026-11.md`、`06-技术/多模态融合与开源借鉴.md`、`06-技术/成本与延迟估算.md`、`v2/qa/tools/*`
> 官方文档：千问AI平台（platform.qianwenai.com）文档中心，**2026-11-08 在线核对**，逐条标 ●；阿里云百炼旧文档入口仍可用，域名见 §8-1。
> 用途：给 demo 导演/实现者一份"**现在能安全现场调什么、什么只能预置、什么根本做不到**"的决策底稿。

**标记法**

| 标记 | 含义 |
|---|---|
| ● | 官方文档可证（附链接，`§9` 有清单） |
| ■ | 本项目真实调用实测（附证据文件） |
| ◐ | 二手/教程，未官方复核 |
| ○ | 本文推断，需实测确认 |
| ? | 待验证（列入 §8） |

---

## 0. 一页结论

**一句话**：Qwen 侧我们要的**能力全都有**（原生视觉、多图、编辑、流式、结构化、思考、全模态语音），**卡点几乎全在我们自己的接线方式**——前端全程 `stream:false`、proxy 把输出面积钉死在 1MP、编辑路径允许 4 张图（超官方上限）、bbox 没有坐标系契约、语音走的是浏览器 Web Speech 而不是 Qwen。

| # | 结论 | 影响 |
|---|---|---|
| 1 | **流式能力已接通但前端从未使用**（proxy 已 SSE 透传，`ai-provider.mjs:303` 固定 `stream:false`） | 8–10s 的空等可以直接变成"AI 在思考"的 wow；**最高性价比改动** |
| 2 | **生图/编辑受"混元时代"的本地校验限制**：`serve.mjs:274` 面积 ≤1024²、`:276` 参考图 ≤3 张，报错文案还是"混元限制" | Qwen-Image 官方支持到 2048²（`qwen-image-3.0` 输出 1K/2K 同价 ¥0.18；`qwen-image-3.0-pro` 1K ¥0.25 / 2K ¥0.50 ●），我们现在**只能出 1MP** |
| 3 | **图像编辑路径会送 4 张图**（`serve.mjs:511`、`app.js:3989`），官方上限 3 张 | 用户引用 3 张素材时**必然 400**；路演现场必须堵死 |
| 4 | **bbox 没有坐标系契约**：只发选区裁切图、不发整幅，模型返回的坐标被直接当画布坐标用（`app.js:3655-3663`） | "AI 指认画布区域"在真实模型下**可能指错地方**，看上去像造假 |
| 5 | **语音是浏览器 Web Speech API**（`app.js:3634`），Chrome 走境外服务 | 国内现场大概率识别失败；Qwen 侧有 omni / ASR 两条现成路（¥0.00022/秒起） |
| 6 | **图像编辑 51s、生图 16s**（■ 实测） | 不能设计成"等结果"的环节，必须做成"提交→继续讲→回来揭晓"的时间线 |
| 7 | 官方 `json_schema` 严格模式**不支持多模态输入** | 视觉结构化只能 `json_object`，字段稳定性靠 prompt + 客户端校验（现有 `normalizeAnalyzeResult` 正好是对的位置） |

**路演建议**：现场**实时跑**「选区内视觉理解（≤6s）」+「流式对话（含可展开的思考）」+「语音一句话」+「AI 指认区域」；**异步跑**「图像编辑」并在 2 分钟后揭晓；**预置**「高质量长思考/复杂编辑成品」，且**在 UI 上标"预置样本"**。详见 §4、§7。

---

## 1. 证据基线

### 1.1 当前配置快照（`v2/.ai-config.json`，密钥不在此复制）

| 项 | 值 |
|---|---|
| mode | `real`；`privacyMode:false` |
| provider / model | `qwen` / `qwen3.8-max` |
| baseUrl（chat） | `https://dashscope.aliyuncs.com/compatible-mode/v1` |
| imageBaseUrl / imageModel | `https://dashscope.aliyuncs.com` / `qwen-image-3.0` |
| imageEditModel | 默认 `qwen-image-3.0-pro`（`serve.mjs:80`、`app.js:2659`） |
| imageProtocol | `dashscope-async`（submit → poll → 服务端下载 sha256） |
| 轮询 | `dashscopePollMs:2500`、`dashscopeMaxPolls:80`（≈200s 上限） |
| 搜索/思考 | 视图理解路径显式 `enable_thinking:false`（`ai-provider.mjs:306-309`） |

> ⚠️ 配置文件里有真实 key（`v2/.ai-config.json`，已 0600/ACL 收紧）。**本文档与任何交付物都不得复制该 key**；路演前建议轮换。

### 1.2 已跑通的真实调用（■）

| 链路 | 证据文件 | 实测 | 关键数据 |
|---|---|---|---|
| 选区视觉理解 | `v2/qa/tools/qwen-real-e2e-results.json` | **21.3s** | 1271 tokens（image_tokens 72）、2 观察 / 2 区域、`real_calls=1`、证据包第三方校验 pass |
| 自由对话 | `v2/qa/tools/qwen-chat-real-results.json` | **3.1s**（provider 内 2.7s） | 330 tokens、image_tokens 90 |
| 文生图 | `v2/qa/tools/qwen-image-real-results.json` | **16.4s** | 1024×1024、1,154,038B、sha256、响应不含上游 URL |
| 图像编辑 | `v2/qa/tools/qwen-image-edit-app-results.json` | **51.1s** | `qwen-image-3.0-pro`、2416×1728、6.6MB、`input_image_count=1`、`qima_output_2k`、落层后 transformActive |
| 标注/定位/浮层/语音入口 | `v2/app/test-multimodal-result.json` | — | 全部在 **Mock** 模式验证；语音只验证"按钮存在 + SpeechRecognition 存在" |

> 全部实测均为**单次**，不构成 P50/P95。`模型能力调研_2026-11.md §10` 另记一次视觉分析 14.4s / 1238 tokens，与 21.3s 同量级。

### 1.3 本次核过的官方文档（●，2026-11-08）

| 主题 | 文档 | 本方案用到的结论 |
|---|---|---|
| 模型卡 | [qwen3.8-max](https://platform.qianwenai.com/docs/models/qwen3-8-max.md) | 输入 Image/Text/**Video**；FC ✓；结构化输出 ✓；1M 上下文（最大输入 991,808、最大输出 131,072、思维链上限 262,144）；¥12/¥36 每百万，缓存命中 ¥1.5/¥1 |
| 视觉输入 | [分析图像与视频](https://platform.qianwenai.com/docs/developer-guides/multimodal/vision.md) | 3.8-Max 最多 **2048 张图**（URL/本地）/ **250 张**（base64）；图像 token = `h·w/1024+2`；默认 `max_pixels=2,621,440`；`vl_high_resolution_images=true` 上限 16384 token；body ≤64MB；单图 base64 ≤20MB；支持 2D/3D 定位（bbox） |
| 图像编辑 | [图像编辑](https://platform.qianwenai.com/docs/developer-guides/image-generation/image-editing.md) | 3.0 系**输入 1–3 张**、**输出 1–6 张**；2.1 系输入 **1–10 张**；`size` 总像素 512²–2048²；**不支持 mask**（兼容模式明确写"也不支持 mask"）；`prompt_extend` 默认 true；`enable_thinking` 默认 **true**；URL 24h；**按成功张数计费**，失败不计费；官方语言=简中/英 |
| 结构化输出 | [结构化输出](https://platform.qianwenai.com/docs/developer-guides/text-generation/structured-output.md) | `json_object` 要求 prompt 含 "JSON"；`json_schema` 仅部分模型；**多模态输入不支持 `json_schema`，自动降级为 `json_object`**；结构化输出时**不建议设 `max_tokens`**（截断产生非法 JSON） |
| 流式 | [流式输出](https://platform.qianwenai.com/docs/developer-guides/run-and-scale/streaming.md) | SSE `data:` 行 + `[DONE]`；`stream_options.include_usage` 末帧给 usage；思考模式两阶段 `delta.reasoning_content` → `delta.content`；**stream + json_object 可同时用**；非流式超时 ≥300s |
| 思考 | [思考模式](https://platform.qianwenai.com/docs/developer-guides/text-generation/thinking.md) | `qwen3.8-max` 混合模式**默认开**；`reasoning_effort`（low/medium/xhigh，默认 xhigh）与 `thinking_budget` **不能同时传**；`preserve_thinking` 默认开（历史思维链会计入输入并计费）；思考 token 按输出计费 |
| 全模态 | [全模态概述](https://www.alibabacloud.com/help/zh/model-studio/omni/)、[音视频文件理解](https://platform.qianwenai.com/docs/developer-guides/speech/multimodal-speech.md) | `qwen3.8-omni-flash`：文本/图片/音频/视频输入→**文本输出**，1M 上下文，思考默认开，FC+联网搜索，音频 ≤3h；**Qwen-Omni 所有请求必须 `stream:true`**；音频入参 `{type:'input_audio', input_audio:{data, format}}`；价格 ¥0.8/¥2.7 每百万 |
| 语音识别 | [模型价格](https://platform.qianwenai.com/docs/developer-guides/getting-started/model-prices.md) | `qwen3-asr-flash` **¥0.00022/秒**；`qwen-audio-3.1-asr-flash` ¥0.8/¥2.7 每百万 token |
| 计价 | 同上 + [qwen-image 定价行] | `qwen-image-3.0` 输入图 ¥0.02/张、输出 1K/2K **¥0.18**；`qwen-image-3.0-pro` 输出 **1K ¥0.25 / 2K ¥0.50**；`qwen-image-2.1-turbo` **¥0.1**（**无输入图片计费**，1–10 张参考） |

---

## 2. 能力矩阵

### 2.1 视觉理解（图 → 结构化/文本）

| 能力 | 官方能力 | 本项目现状 | 状态 | 成本 | 延迟 |
|---|---|---|---|---|---|
| 单张裁切图理解 | ● 支持 base64/URL | 选区裁切 → `qwen3.8-max`，`json_object` | **已接入可用** ■ | **≈¥0.035/次**（1,271 token 实测：入 ¥12 / 出 ¥36 每百万） | **14–21s** ■ |
| 整幅画布理解 | ● 同左 | 仅对话面板有 `canvas` chip（默认**关**，`app.js:163`）；analyze/directions/generate 都不发整幅 | **已接一半** | +~500 token ≈ ¥0.006 | +1s |
| 多图（对比/多页） | ● 3.8-Max 最多 2048 张（URL）/250（base64） | 对话最多 2 张（proxy `serve.mjs:395` 硬上限 2、`ai-provider.mjs:358` 再 slice 3） | **被自己限制** | 线性 | +0.5–1s/张（1024 级 ≈ 683 token） |
| 手绘标注随图 | ○ 图里画了红圈模型能看见 | 已做：标注层合成进裁切图（`app.js:2852-2855`） | **已接入（Mock 验）** | 0 | 0 |
| bbox/区域定位 | ● 支持 2D/3D 定位 | 要求返回 `bbox`，但**无坐标系约定**（`ai-provider.mjs:292`、`:85-88` 直接转 Number） | **半可用，有指错风险** | 0 | 0 |
| 高分辨率细节 | ● `vl_high_resolution_images` 最高 16384 token | 裁切图 ≤1568 边长（`app.js:2845`），≈1600 token | 已用默认档 | 按 token | +1–3s |
| 视频/多帧 | ● 3.8-Max 支持视频输入 | 未接（编辑器没有时间轴，短期不需要） | **不接** | — | — |

### 2.2 生图 / 编辑 / 多图参考

| 能力 | 官方能力 | 本项目现状 | 状态 | 成本 | 延迟 |
|---|---|---|---|---|---|
| 文生图 / 图生图 | ● `qwen-image-3.0` 异步；`n` 1–6 | 走 DashScope 异步 + 轮询 + 下载 sha256（`serve.mjs:424-504`） | **已接入可用** ■ | ¥0.18/张（+输入图 ¥0.02） | **16.4s/次** ■（2 张串行） |
| 原生多图参考 | ● 3.0 系 **1–3**；2.1 系 **1–10** | 前端最多 3（`app.js:3923`），proxy 也 3（`serve.mjs:276`） | **已接入，上限卡在 3** | 3.0：3×¥0.02；2.1-turbo：**0** | — |
| 图像编辑（图文→图） | ● `qwen-image-3.0-pro` 同步 `multimodal-generation` | 已接（`serve.mjs:507-555`），落层可继续改 | **已接入可用** ■ | 1K ¥0.25 / 2K ¥0.50 + 输入 ¥0.02 | **51.1s** ■ |
| 局部编辑 / mask | ● **无 mask 参数**（兼容模式红字明确）；官方另有 `wanx-x-painting` / 万相系列做真 mask | 现状不是 mask inpaint，而是"**裁切 → 整块编辑 → 客户端用选区 alpha 反向裁切**"（`app.js:3306-3319`），L6 里写 `mask_policy:selection_alpha` | **必须澄清语义**（见 §7.3-c） | 同上 | 同上 |
| 输出分辨率 | ● 512²–2048² | **被 proxy 卡在 ≤1024²**（`serve.mjs:274`，报错文案写"混元"） | **被自己限制** | 3.0：1K/2K **同价 ¥0.18**；3.0-pro：1K ¥0.25 / 2K ¥0.50 ● | 2K 更慢 ? |
| 多轮编辑 | ● 编辑接口本身无会话状态；靠把上一轮结果当 `image` 再传 | 可做（结果已落层，可再"按描述修改"） | **可用，未编排** | 每次一张 | 每次 ~51s |
| seed / negative_prompt / prompt_extend | ● 均支持 | **均未传**（`serve.mjs:441-445` 只有 size/n/prompt_extend/watermark/enable_thinking） | **未用足** | 0 | `prompt_extend` 默认开 ≈ +3–5s ● |
| 4 张图送编辑 | ● 3.0 系上限 3 | `dashscopeImageEdit` `slice(0,4)`、`app.js:3989` 也 4 | **必然 400 的 bug** | 0 | 0 |

### 2.3 文本侧：流式 / 结构化 / 工具 / 长上下文 / 思考

| 能力 | 官方能力 | 本项目现状 | 状态 | 成本 | 延迟 |
|---|---|---|---|---|---|
| SSE 流式 | ● `stream:true`、`stream_options.include_usage`、`[DONE]` | proxy 已透传（`serve.mjs:414-418`）；**前端全部 `stream:false`**（`ai-provider.mjs:303`、`:360`） | **已接通未使用** | 同价 | 首 token 亚秒 ○ |
| 两阶段流（思考→正文） | ● `delta.reasoning_content` → `delta.content` | 完全没接 | **未接（最大空白）** | 思考 token 按输出计费 | — |
| 结构化 `json_object` | ● 需 prompt 含 "JSON" | 已用（`response_format` + system prompt 含 JSON ✓） | **已接入可用** | 0 | — |
| 结构化 `json_schema` | ● 严格模式；**多模态输入自动降级** | 未用 | **视觉路径用不了**（协议限制）；纯文本路径可用 | 0 | — |
| 结构化 + `max_tokens` | ● 官方建议**不要设**（会截断） | 设了 1800/1200（`ai-provider.mjs:304`），且 `bad_json` **不可重试** | **有截断风险** | — | — |
| Function Calling | ● 支持（模型卡 + 思考文档） | 未用；"行动建议"靠 JSON 文本 + 本地白名单（`chat-actions.mjs`） | **未用足**（现方案更安全，可不换） | 无额外费 | — |
| 长上下文 | ● 1M（输入 991,808） | proxy 硬限 30 条 / 6 万字 / 2 图（`serve.mjs:395`） | **远未用足，但不需要**（画布上下文本来小） | 输入 ¥12/M | — |
| 思考模式 | ● 默认开；`reasoning_effort`/`thinking_budget`；不能同时传 | 视觉/对话**强制关**（为速度）；无 UI 开关 | **关闭是正确默认**，缺"按需开" | 思考 token = 输出价 | 开 ≈ 3× ●（项目内实测 13.1s vs 2.05s） |
| 上下文缓存 | ● 隐式缓存 ¥1.5/M（命中） | 未主动利用（system prompt 固定，天然可命中） | **未观测** | 可省 ~87% 输入费 | — |
| 前缀续写 | ● partial-mode | 未用 | 不接 | — | — |

### 2.4 语音与全模态

| 能力 | 官方能力 | 本项目现状 | 状态 | 成本 | 延迟 |
|---|---|---|---|---|---|
| 语音输入（意图） | ● `qwen3.8-omni-flash` 收 `input_audio`（wav/mp3），必须 stream | 浏览器 `SpeechRecognition`（`app.js:3634-3654`），Chrome 走境外服务 | **用错了技术**（国内大概率不可用） | ¥0 | 取决于网络 |
| 纯语音转写 | ● `qwen3-asr-flash` ¥0.00022/s；`qwen-audio-3.1-asr-flash` ¥0.8/¥2.7 每百万 | 未接 | **未接** | 10s ≈ **¥0.0022** | ? |
| 音视频理解 | ● omni 音频 ≤3h / 视频 ≤2h | 未接（不需要） | 不接 | ¥0.8/¥2.7 | — |
| 语音输出 / 实时双工 | ● `qwen3.5-omni-plus` 可出音频；`qwen-audio-3.x-realtime` 双工 | 未接 | **建议不接**（现场噪音 + 时延风险） | 音频输出 ¥72–213/M | 高 |
| 声音复刻 | ● 支持 | 不接 | — | — | — |

---

## 3. 已接入 / 未用足 / 协议限制（逐项定位）

### 3.1 已经接好、现在就能用的（别重写）

1. **密钥不出前端**：`/api/ai/*` 代理 + 本地 token 注入（`serve.mjs:622-627`）+ `x-ai-confirm` 二次确认（`serve.mjs:190`）= 可信基础。
2. **生图串行队列**：`enqueueImage`（`serve.mjs:252-261`）保证并发 1，不会打爆上游。
3. **结果不落临时 URL**：生成后立刻下载 → sha256 → dataURL（`serve.mjs:304-312`），规避 12h/24h 过期。
4. **Mock/真实同 shape**：`mockAnalyze/mockDirections/mockGenerate` 与真实返回同结构，`mock:true` + L6 `assertions.mock_only` 贯穿（`mock-ai.mjs`、`app.js:3018`）。
5. **来源三态**：`observed / inferred / user-confirmed`，模型输出一律被强制成 `inferred`（`ai-provider.mjs:100-108`），`user-confirmed` 只能由用户点"确认"产生（`app.js:3173-3192`）——这条是全项目最硬的"不伪造"资产。
6. **行动白名单**：7 种 action + 参数白名单 + 脚本/URL 过滤（`chat-actions.mjs:31-123`），模型无法越权执行。

### 3.2 已接入但被我们自己的限制卡住（**本次要动的**）

| # | 位置 | 现状 | 后果 | 建议 |
|---|---|---|---|---|
| A | `ai-provider.mjs:303`、`:360` | `stream:false` 写死 | 8–20s 空等，没有任何过程反馈 | 改流式（§5-L2） |
| B | `serve.mjs:274` | `area > 1024*1024` 直接 400，文案"混元生图限制" | Qwen 2K 档不可用；报错误导 | 按 provider 分支：qwen 用 2048² + 512² 下限；文案改中性 |
| C | `serve.mjs:276` | `refs.length > 3` 直接 400 | 无法用 2.1 系（1–10 张）；文案"混元 3.0 限制" | 按 `imageModel` 查上限表 |
| D | `serve.mjs:511`、`app.js:3989` | 编辑送最多 4 张 | **3 张素材 + 选区 = 4 张 → 400** | 卡到 3 张并在 UI 提示"编辑最多 3 张（含选区）" |
| E | `serve.mjs:395` | 对话图片硬上限 2 | 多图参考/图层引用做不了 | 提到 3–4 张（配合 UI 明确显示"将发送 N 张图"） |
| F | `app.js:3363` | L6 `cost_cny` 写死"qwen ? 0.18 : 0.2" | 编辑 2K 实际 ¥0.52，账本记 ¥0.18（低估 3×） | 按 model×档位查价表 |
| G | `ai-provider.mjs:313` | `bad_json` 不可重试 | 截断/格式异常直接失败，现场只能重来 | 标 `retryable:true`，或去掉 `max_tokens` + 缩 schema |
| H | `serve.mjs:441-445` | 未传 `seed`/`negative_prompt` | 无法复现、无法排除元素 | 加 `seed`（可复现路演效果）、`negative_prompt` |

### 3.3 完全没接、但 Qwen 已经有的（**新增亮点来源**）

1. **流式两阶段**（思考可见 + 逐字）→ §5-L2
2. **多图上下文**（选区 + 整幅 + 参考 + 图层）→ §5-L1 / L4
3. **bbox 作为一等公民**（AI 指认 → 一键变选区/蒙版）→ §5-L3
4. **Qwen 语音输入**（omni 一步 / ASR 两步）→ §5-L5
5. **`seed` + `prompt_extend` 显式开关**（可复现的"同种子重出"）→ §5-L2 附赠

---

## 4. 路演安全子集与降级策略

### 4.1 四级真实度模型（贯穿 UI / 账本 / 台词）

| 级 | 名称 | 定义 | UI 必须显示 | L6 `assertions` |
|---|---|---|---|---|
| **A** | 实时 | 本次点击 → 本次上游返回 | `实时 · Qwen3.8-Max · 4.2s · ¥0.06` | `type:'real_model'` |
| **B** | 预置样本 | **此前**真实生成、已落盘的真实产物（带原始 sha256/model/时间） | `预置样本 · 2026-11-07 · qwen-image-3.0-pro · b8790a…` | `type:'cached_sample'`（**不是** real_model） |
| **C** | 预录 | 录屏/视频，非当前会话产物 | 画面角标 `预录` + 主持人台词明示 | 不写 AI 记录（或 `type:'prerecorded'`） |
| **D** | Mock | 本地确定性占位，**不联网** | `Mock 占位 · 未调用模型` + 画布角标 | `type:'mock_only'` |

> 铁律：**A→B/C/D 的降级必须可见**（Toast + 面板徽章 + 记录三处同时变）。静默降级 = 造假。

### 4.2 现场可安全调用的清单

| 动作 | 模型/接口 | 预期 | 现场阈值 | 超时 | 兜底 |
|---|---|---|---|---|---|
| 选区理解（2 观察 + 2 区域） | `qwen3.8-max`，thinking off，裁切 ≤768 边长，输出 schema 精简 | 3–6s（调优后）○；现状 14–21s ■ | 8s | 15s | 第 4s 起显示"仍在推理"进度；>15s 切 **B 预置**（同选区） |
| 流式对话（含思考开关） | 同上 + `stream:true` | 首 token 1–2s ○；整段 3–6s | 首 token 3s | 25s | 首 token 超时 → 切 **D Mock**（并标 Moment） |
| 方向建议 | 同上 | 3–8s | 12s | 20s | B 预置（基于同一份观察） |
| 文生图 2 张 | `qwen-image-3.0` 异步 | 16s ■（2 张串行） | 40s | 90s | 提交后立刻给"排队中 1/2"；>40s 允许继续讲，回来揭晓；失败→B 预置 |
| 图像编辑 1 张 | `qwen-image-3.0-pro` 同步 | **51s** ■ | 120s | 180s | **默认走"提交→继续讲→回来"**；否则用 B |
| 语音一句话 | `qwen3.8-omni-flash`（stream）或 `qwen3-asr-flash` | 1–3s ○ | 6s | 15s | 失败 → 输入框自动填入"（语音不可用，请打字）"，**不假装听到了** |
| 深度思考演示 | `qwen3.8-max` + `enable_thinking:true` + `thinking_budget:600` | 8–15s ○ | 20s | 40s | 只演示 1 次，放对话面板，不放在主链路 |

> 延迟目标不是猜的：官方给的是"非流式超时 ≥300s、思考约 3× 慢、prompt_extend +3–5s"，项目内实测 §1.2。**P50/P95 必须实测**（§8-3）。

### 4.3 判定与切换逻辑（给实现者的伪代码）

```js
// 每个 AI 动作统一走这一层，禁止各调用点自己判断
async function safeAi(kind, payload, opts) {
  const cfg = await refreshAiConfig();                    // 已有
  const realOk = cfg.hasKey && cfg.mode === 'real' && !cfg.privacyMode && aiRuntime.allowReal;
  const netOk  = await probeHealth({ timeout: 1500 });    // /api/ai/health + 1 次 ping
  const budgetOk = aiBudget.spendable(kind);              // §4.4
  if (realOk && netOk && budgetOk) {
    try {
      const r = await withDeadline(callReal(kind, payload), opts.deadlineMs);
      return { tier: 'A', ...r };
    } catch (e) {
      aiLog('degrade', `${kind} 实时失败(${e.code}) → 预置`);
      // 不要 try/catch 后再假装成功
    }
  }
  if (cache.has(kind, payload)) return { tier: 'B', ...cache.get(kind, payload), cachedAt, sha256 };
  return { tier: 'D', ...mockFor(kind, payload) };
}
// UI: tier !== 'A' 时，面板徽章 + Toast + L6 assertion 三处同步
```

### 4.4 预算护栏（8–10 分钟一场）

| 项 | 单价 | 场次用量 | 小计 |
|---|---|---|---|
| 视觉理解 ×4 | ≈¥0.035（1,271 token ■） | 4 | ¥0.14 |
| 对话 ×6（约 0.6–1.2k token/次） | ¥0.005–0.02 | 6 | ¥0.09 |
| 深度思考 ×1（600 思考 token） | ≈¥0.03 | 1 | ¥0.03 |
| 文生图 ×2 批（各 2 张） | ¥0.18 | 4 张 | ¥0.72 |
| 图像编辑 ×1（2K） | ¥0.50 + 输入 ¥0.02 | 1 | ¥0.52 |
| 语音 ×3 | ≈¥0.003 | 3 | ¥0.01 |
| **合计** | | | **≈ ¥1.51** |

建议硬护栏：**单场上限 ¥20 / 200 次**，超出即 §4.3 的 D 分支；`limits.perMinute:10` 已有（`serve.mjs:70`）。

---

## 5. 五个"原生多模态"亮点交互

> 排序 = 建议实现顺序（性价比 × 风险）。每个都给"现状 → 改什么 → 风险 → 验收"。

### L1 · 三个视角一起给（选区 + 整幅 + 参考，一次调用）

**一句话**：现在是"AI 只看见你框的那一小块"；改成"AI 同时看见这块、整幅、和你给的参考"，它才能说出"这块和整体关系如何"。

| 项 | 内容 |
|---|---|
| 交互脚本 | 用户框选后，AI 面板顶部"上下文条"显示三枚胶囊：`选区 360×260`｜`整幅 1024×768`｜`参考 2 张`。点"让 AI 看看"时三枚同时亮，AI 回答里出现"**相对整幅**"的判断（如"这块的明度比整体高半档，落在这里会抢主体"）。 |
| 现状 | `runAnalyze` 只发 `aiSelectionCrop()`（`app.js:3108`）；整幅只有对话面板可选且默认关（`app.js:163`）；`directions`/`generate` 同样只发裁切。 |
| 改动 | ① `buildAnalyzePrompt` 增加 `images:[{role:'selection',rect,scale},{role:'canvas',scale}]` 清单，**文本里明确"图1=选区裁切图，图2=整幅缩略图"**（官方要求多图顺序与提示词编号一一对应 ●）；② `ai-provider._messages` 追加整幅图（缩放 ≤768 长边，JPEG q0.8）；③ proxy 图片预算 2→3（`serve.mjs:395`）；④ 面板显示"将发送 2 张图 / 共 N tokens 估算"。 |
| 成本/延迟 | 整幅 768×576 ≈ 434 token；+¥0.006；+0.5–1s |
| 风险 | ① 模型把"整幅"当成"要改的图"→ 必须在 prompt 里写清"图2 仅用于空间关系判断，不要描述其细节以外的东西"；② token 预算：3072×2048 画布缩到 768 后细节丢失，AI 可能说"看不清细节"——**这恰恰是诚实的表现**，不要用压缩去骗它。 |
| 验收 | 一次真实调用返回里 ≥1 条 observation 的 text 含"整体/整幅/画面"的相对判断；`L6.params.images = [{role,sha256}]` 可查；UI 显示实际发送张数。 |

---

### L2 · 「先想后写」：两阶段流式 + 阶段进度（**P0，最划算**）

**一句话**：把 8–20s 的黑箱等待，变成"读图 → 思考（可展开）→ 逐字写出 → 落档"的可视过程。这是 Qwen 原生能力，不是动画包装。

| 项 | 内容 |
|---|---|
| 交互脚本 | 点"让 AI 看看"后：<br>① `读取选区 360×260`（本地，即时）<br>② `AI 正在看…`（首 token 到达前，扫描线动画，**已有** `startAiScan`）<br>③ 若开了"深度思考"：出现可折叠的"思考中"小窗，等宽 12px，实时滚动，最多显示 240 字，标注"这是模型的推理过程，不是它对画面的描述"<br>④ 正文逐字出现（≥60 字/秒的视觉节奏；实际按 token 来，**不额外补帧**）<br>⑤ 完成后卡片逐条 fade-in（观察/区域），并显示 `实时 · 4.2s · 1,271 tokens · ¥0.035` |
| 现状 | proxy 已 SSE 透传（`serve.mjs:414-418`）；前端 `ProxyClient.json()` 只认 `res.json()`（`ai-provider.mjs:190-193`）；`stream:false` 写死。UI 只有 `aiScanTimer` 假扫描（`app.js:2938-2965`）。 |
| 改动 | ① `ProxyClient` 加 `stream(path, body, onEvent)`：`fetch` + `res.body.getReader()` + `TextDecoder` 按行切 `data:`，`[DONE]` 收尾；② `AIProvider.analyze/converse` 接受 `onDelta(phase, text)`；③ proxy 透传时补 `stream_options:{include_usage:true}`（末帧拿 usage）；④ `aiBeginTask/aiPhase` 接三段 phase；⑤ **JSON 仍在结束后整体 parse**——只有"思考文本/纯文本回答"逐字，卡片不逐字。 |
| 成本 | 思考 token 按输出（¥36/M）；600 token = ¥0.022。日/场护栏见 §4.4 |
| 风险 | ① **JSON 不能边流边 parse**：绝不做"看起来在打字但其实是假 JSON"的动画，否则等于造假。② 若把 `reasoning_content` 包装成"AI 在观察你的画"——**这是误导**，它只是语言推理（可能写着"用户想要描述图片…"）。UI 文案必须中性。③ 取消/超时：`cancelAiRequest`（`app.js:2996`）要 abort reader；已发出的请求仍可能计费（现有文案已正确）。④ 部分模型/地区 SSE 可能被中间代理缓冲 → 本地 127.0.0.1 无此问题。 |
| 验收 | 首 token 时间可测（`performance.now()` 记录 `ttftMs` 并写入 L6）；`onDelta` 收到 ≥3 个 `reasoning_content` 片段（开思考时）；关掉思考时仍走流式但无 phase ③；取消后 500ms 内 UI 回到空闲且不产生半个结果。 |

---

### L3 · 「AI 指认」：bbox 契约 + 画布上真的圈出来 + 一键变选区/蒙版（**P0，最有说服力**）

**一句话**：AI 说"问题在袖口褶皱"，光标就飞到袖口，虚线框亮起，点一下变成你的选区。这是"视觉 grounding"的可视化，而不是一句形容词。

| 项 | 内容 |
|---|---|
| 交互脚本 | 观察卡片右侧多两枚按钮：`在画布定位`（已有）/`设为选区`。点"在画布定位"时：画布外框脉冲一次 → 目标区域橙色虚线框 + 编号徽章 + 600ms 缓动飞行（不是瞬移）。批量：`把 3 条都标出来`。AI 回复正文里的 `#2` 变成可点 chip。 |
| 现状 | `renderAiCanvasOverlay`（`app.js:3664-3707`）已能画橙框+编号+蓝框+标签；`locateObservation`（`:3655-3663`）直接把 `bbox` 当画布坐标赋给 `state.selection`。**但模型拿到的是裁切图，坐标系从未约定**。 |
| 改动（关键：坐标系） | ① **prompt 契约**：要求 `bbox:[x,y,w,h]` 为**所收到那一张图的像素坐标**，并新增 `image_index`；同时给 `coord_hint:"crop_px"`。② **前端换算**：`canvasX = sel.x + bbox[0]/crop.scale`（`crop.scale` 由 `aiCropRect` 已在返回里，`app.js:2856`）。③ **校验**：`0 ≤ x, x+w ≤ crop.width*(1+ε)`，越界标 `invalid_anchor` 并**拒绝定位**（不静默 clamp 到别处）。④ **Mock 对齐**：`mockAnalyze` 现在输出的是画布坐标（`mock-ai.mjs:141-164`），需改为 crop 坐标（或加 `coord_space:'canvas_px'` 字段让前端分支），否则"Mock 好用、真实指错"——最坏的一种不一致。⑤ 加 `normalized` 兜底：若所有 bbox ≤1，判定为 0–1 归一化并自动换算。 |
| 亮点加强 | 定位时同步高亮对应图层（若该区域主要由某图层贡献）；`annotate` action 可把 bbox 直接转为"标注模式"的初始圈。 |
| 成本 | 0（复用同一次调用） |
| 风险 | ① **官方只对 Qwen2.5-VL 明写"480–2560px 检测效果良好，超出可能偏移"●**，3.8 系无明确区间 → 用小裁切（≤768）+ 二次确认降低风险；② 模型可能返回"对话式"坐标描述而非数组 → `normAnchor` 已有回退 `whole`（`:85-88`），但 `whole` 会让"定位"按钮变哑，需要 UI 上明确"该条无坐标"；③ 多区域重叠 → 只高亮所选那条，避免满屏框。 |
| 验收 | 10 组固定素材：定位框与人工标注框 IoU 中位数 ≥0.5（○ 目标）；越界/格式错必须走 `invalid_anchor` 分支而不是乱跳；L6 记录 `anchor_coord_space`。 |

---

### L4 · 「对话里点名图层」：@图层 作为可引用的视觉上下文

**一句话**：`@"背景" 这层太抢了，能压下去但保留笔触吗？` —— 把编辑器内部对象（图层）变成多模态输入的一部分。这是"编辑器原生对象 ↔ 模型"的桥，开源/商业产品里少见。

| 项 | 内容 |
|---|---|
| 交互脚本 | 对话输入框打 `@` 弹出图层列表（含可见性/混合模式小标），选中后变成 chip；发送时自动把该图层可见像素渲染成缩略图（≤512 长边）作为**第 3 张图**，并在 payload 里给 `layer:{id,name,blend,opacity,bounds}`。AI 回复可回引 `@背景`，点击 chip → 图层高亮 + 属性面板定位。 |
| 现状 | `buildChatContext` 只给 `active_layer` 名字 + 图层数量（`app.js:3536`）；`aiLayerCrop()` 已能渲染单个图层（`:2866-2882`）但只用在图像工作台；chat images 上限 2（`serve.mjs:395`）。 |
| 改动 | ① 新增图层选择器 UI（复用 `renderLayers` 的列表组件）；② `aiLayerCrop` 支持按 layerId 渲染（现在只取 active）；③ `chat-actions` 白名单加 `layerId`（`chat-actions.mjs:95-104` 的 `reference` 类型）；④ proxy 图片上限 2→4；⑤ prompt 里给"图N = 图层「X」可见内容"。 |
| 成本 | 每图层 ≈ 340 token（512²）≈ ¥0.004 |
| 风险 | ① 图层含大面积透明 → 缩略图黑底会误导模型，须合成到白/棋盘底并在 prompt 说明"透明区域为空白"；② 图层数量多时上下文膨胀 → 元数据限 8 层、缩略图限 2 张；③ `@` 解析失败要静默降级成普通文本（不能吞掉用户输入）。 |
| 验收 | 引用图层后，AI 回复能说出该图层特有内容（如"@线稿 里那段断线"）；L6 `params.layers=[{id,sha256}]`；未引用时行为不变。 |

---

### L5 · 「说一句就改」：Qwen 语音 → 结构化意图 → 直接执行（**换掉 Web Speech**）

**一句话**：按住说话 3 秒，松开 2 秒后意图框里出现"把雾改成冷的、保留我的笔触"，并自动带上选区——然后直接生成。

| 项 | 内容 |
|---|---|
| 交互脚本 | 按住 `🎤`：波形 + `听…`；松手：`转写中`（≤3s）→ 文本框出现转写，且自动追加"意图：保留笔触，只改选区"；点生成。可编辑后再发（**不自动执行花钱动作**，保持"AI 只建议"原则）。 |
| 现状 | `startVoiceInput` 用 `window.SpeechRecognition`（`app.js:3634-3654`），Chrome 的识别走 Google 云端，国内现场大概率 `network` 错误；`test-multimodal` 只验证了"按钮在、API 在"。 |
| 两条实现路（建议先 B 后 A） | **A（一步）**：录音 → 16kHz 单声道 WAV（手写 44 字节头 + PCM16，约 40 行，无依赖）→ `POST /api/ai/audio` → proxy 调 `qwen3.8-omni-flash`，`content:[{input_audio:{data:'data:;base64,'+b64,format:'wav'}},{text:'把下面这段口语整理成一句画布编辑指令，只输出指令本身'}]`。**官方要求 Qwen-Omni 请求必须 `stream:true`**，proxy 聚合后一次性返回文本。成本 ≈ 10s 音频 ≈ ¥0.002。<br>**B（两步，更稳）**：`/api/ai/asr` → `qwen3-asr-flash`（¥0.00022/秒）拿纯转写；再复用现有 `qwen3.8-max` 做"口语→结构化指令"。两步可各自降级，且 ASR 不吃思考模式。 |
| 改动 | ① 新端点 `/api/ai/audio`（proxy 侧，含 base64 体积上限 ~6MB）；② 前端 `MediaRecorder` → WAV 编码器（或用 `AudioWorklet` 直采 PCM）；③ 失败时文本框填"（语音不可用，请打字）"——**绝不填假文本**；④ 保留 Web Speech 作为可选后备（如果现场浏览器恰好可用）。 |
| 成本 | ≤¥0.01/次 |
| 风险 | ① 麦克风权限：`127.0.0.1` 属安全上下文，`getUserMedia` 可用 ○（需实测）；② 现场噪音 → 演示时用**领夹麦**或预录一段音频文件做"回放输入"（并标注"这是预录音频"）；③ `format` 只示例 wav/mp3，webm 是否支持 ?→ 必须转 WAV；④ 方言：omni 支持 39 种中文方言 ●，是可讲的加分项。 |
| 验收 | 真实录音 3 条（含 1 条带专业术语）转写准确率 ≥90%（人工判读）；失败路径 100% 有可见提示且不产生脏文本；L6 记录 `audio_ms`、`asr_model`、`text_sha256`（**不存原始音频**）。 |

---

## 6. 实现要点与风险汇总

| # | 交互 | 主要改动点 | 工作量 | 风险 | 回退 |
|---|---|---|---|---|---|
| L2 | 两阶段流式 | `ai-provider.mjs` 加 `stream()`；`app.js` phase 三段；proxy 加 `stream_options` | 中（1–1.5d） | 中（JSON 不能流式解析、思考文案误导） | 开关 `useStream=false` 回同步 |
| L3 | AI 指认 | prompt 契约 + `ai-provider` 归一化 + `app.js` 换算/校验 + Mock 坐标对齐 | 中（1d） | **高**（指错=翻车） | 关掉"设为选区"，只留"定位"并加二次确认 |
| L1 | 三视角 | `_messages` 多图 + prompt 图序 + proxy 预算 | 小（0.5d） | 低（多花一点 token） | 单图模式一键切回 |
| L4 | @图层 | 图层选择器 + `aiLayerCrop(layerId)` + action 白名单 + proxy 预算 | 中（1–1.5d） | 中（透明底误导、上下文膨胀） | 只支持 active layer |
| L5 | 语音 | 新 `/api/ai/audio` + WAV 编码 + UI 状态机 | 中（1d，含真机调试） | 中高（麦克风/噪音/格式） | 退回打字；Web Speech 作后备 |
| — | 修 B/C/D/E/F/G/H | `serve.mjs` 校验按 provider 分支、编辑卡 3 张、成本按价表、`bad_json` 可重试 | 小（0.5d） | 低 | 单测覆盖即可 |

**横向技术风险**

1. **域名/协议迁移**：官方新文档统一用 `https://maas.qianwenaiapi.com/...`，我们配的是 `dashscope.aliyuncs.com`。两条都通（■ 实测在旧域名上跑通异步生图），但**路演前必须二选一验证**并把 `baseUrl` 写死进 `.ai-config.json`，不靠默认值（§8-1）。
2. **编辑耗时 51s**：任何"点完等结果"的设计都会冷场。必须做成"提交 → 讲别的 → 回来揭晓"，且提交后立刻显示 `任务已提交 · 排队 1/1`（对应真实 `taskId`，不是假进度）。
3. **中文/英文是官方语言**：图像编辑官方只保证简中/英 ●，提示词混用英文品牌名可能降质 → prompt 里做术语白名单。
4. **`prompt_extend` 默认开**：+3–5s ●。生图想快就显式 `prompt_extend:false`（现有代码写死 true，`serve.mjs:442`）。
5. **`preserve_thinking` 默认开**：多轮对话把历史 `reasoning_content` 回传会**计入输入费** ●。我们现在关思考所以没事；一旦开思考，要把历史 thinking 剥掉。

---

## 7. 「不伪造」边界（**这一节是红线，实现必须遵守**）

### 7.1 四态标注规范（UI 文案模板）

| 级 | 面板徽章 | 卡片尾注 | 画布/导出 |
|---|---|---|---|
| A 实时 | `实时` | `Qwen3.8-Max · 4.2s · 1,271 tokens · ¥0.035` | 无额外标 |
| B 预置 | `预置样本` | `2026-11-07 生成 · qwen-image-3.0-pro · sha256 b8790a…` | 图层名前缀 `[预置]` |
| C 预录 | `预录` | 画面角标 `预录 · 非实时` | 导出文件名含 `prerecorded` |
| D Mock | `Mock 占位` | `未调用模型 · 本地确定性占位 · ¥0` | **图片内嵌**"MOCK"字样 + 画布右下角小角标 |

> D 级现在只做了"文字标注"：`mockGenerate` 生成的是渐变 SVG（`mock-ai.mjs:274-293`），**图上没有任何标识**。投影到大屏时，观众只看画面会以为是真的。→ **必须在 SVG 里烧进 `MOCK 占位 · 未调用模型` 文字**，并在 `applyCandidate` 落层时给图层名加 `[Mock]`。

### 7.2 账本与证据链硬规则

1. `billed`：**只有**上游 2xx 且结果图片下载成功才 `true`；预置/Mock 一律 `false`（现有 `billed` 逻辑正确，`serve.mjs:568/574/580`）。
2. `cost_cny`：按 `model × 档位` 查价表（§2.2 / §9），**禁止写死**（现状 `app.js:3363` 写死 0.18 → 必须修）。
3. `assertions`：`real_model` / `cached_sample` / `mock_only` / `prerecorded` 四选一，**互斥**。
4. `source`：模型产出永远是 `inferred`；`observed` 只给用户自己的操作；`user-confirmed` 只能由用户点击产生。**任何"预置结果自动写成 user-confirmed"= 破坏整条证据链**。
5. 坐标/尺度：`anchor` 必须带 `coord_space`（`crop_px` / `canvas_px` / `norm01`），否则第三方复核无法判定对错。

### 7.3 禁止清单（含现有 3 处"必须改"）

| 禁止 | 为什么 | 现状 |
|---|---|---|
| 把 Mock 结果说成"模型生成" | 演示诚信底线 | ✅ 已合规（文字标注 + L6 `mock_only`）；❌ 图片本身无标识 → 改 |
| 把预置结果写成 `real_model` | 证据包可被第三方验伪 | ⚠️ 目前**没有预置机制**，新增时必须按 §7.1-B |
| 把"裁切 + alpha 合成"说成"mask 局部重绘" | Qwen 编辑**没有 mask 参数** ● | ❌ **需要改文案**：现在 L6 写 `mask_policy:'selection_alpha'`（对），但 UI 说"按选区 mask 裁切"（易被听成 inpainting）→ 统一说"**按选区裁切落地，未使用模型 mask（模型不支持）**" |
| 把 `reasoning_content` 说成"AI 在观察你的画" | 思考是语言推理，不是视觉注视 | 新增流式时的高危点 → 文案固定为"模型的推理过程" |
| 静默降级 | 观众无法分辨真假 | ⚠️ 现有 `mockReason` 会带回来，但 UI 只在部分位置显示 → 三处同步 |
| 用假进度条模拟真实排队 | 生图有真实 `taskId` 与轮询次数 | ⚠️ `aiScanTimer` 是纯动画 → 只允许用在"首 token 之前"，一旦有真实阶段就必须切真实阶段 |
| 把预录视频说成"现在正在跑" | — | 台词里必须有一句"这段是预录，因为真实编辑要 50 秒" |

### 7.4 演示脚本 ↔ 真实度对照（建议 8–10 分钟）

| 时间 | 段落 | 真实度 | 备注 |
|---|---|---|---|
| 0:00–1:30 | 圈选 → 让 AI 看看（流式 + 指认） | **A** | L2 + L3 主秀 |
| 1:30–3:00 | 确认/否决观察 → 写回 L5 → 证据链 | A（本地操作） | 强调 `user-confirmed` 只能人造 |
| 3:00–4:00 | 语音说一句 → 意图 → 提交生成 | **A**（L5） | 生图**提交后不等待** |
| 4:00–5:30 | `@图层` 对话（为什么要压背景） | **A**（L4） | 这里放"深度思考"开一次 |
| 5:30–7:00 | 图像编辑：提交 → 讲"AI 不改原画/非破坏" → 回来揭晓 | **A**（51s 藏在讲解里） | 若超时 → B |
| 7:00–8:30 | 导出证据包 → 第三方 verify → sha256/成本/tokens 全对 | A | 这是"墨证"的差异化核心 |
| 8:30–10:00 | 预置的高质量成组（预置样本，标注）+ 未来路线 | **B** | 明确说"这是昨天跑出来的，今天现场跑要 50 秒" |

---

## 8. 待验证清单（路演前必须清）

| # | 项 | 怎么验 | 影响 |
|---|---|---|---|
| 1 | **baseUrl 域名**：`dashscope.aliyuncs.com` vs `maas.qianwenaiapi.com` 哪个对当前 key 有效 | 各发 1 次 ping + 1 次视觉 | 全链路可用性 |
| 2 | 视觉理解**调优后**延迟（裁切 ≤768、输出 schema 精简、`max_tokens` 策略） | 10 次计时，记 TTFT / total | 决定 L2 能否"6s 内出结果" |
| 3 | 文生图 / 编辑 **P50/P95**（各 10 次，含 2K） | 计时脚本 | 决定"等/不等" |
| 4 | 编辑送 3 张图（1 选区 + 2 素材）是否 200 | 直接打 `task:'edit'` | 修 D 后回归 |
| 5 | 3.8 系 bbox 精度（10 张固定素材，算 IoU） | 离线脚本 | L3 是否敢做"设为选区" |
| 6 | `qwen3.8-omni-flash` 走本地 proxy 的 WAV 输入（含 16k/mono/3–8s） | 真实录音 3 条 | L5 主路 |
| 7 | `qwen-image-2.1-turbo`（¥0.1、1–10 参考、透明输出）实际效果 | 同 prompt A/B | 是否换主力生成模型（省 44%） |
| 8 | 隐式缓存命中率（固定 system prompt 连打 5 次，看 `prompt_tokens_details.cached_tokens`） | 已实测字段存在（`cached_tokens:0`），需重测 | 输入成本可降 ~87% |
| 9 | 2K 输出（`size:'2048*2048'`）质量与耗时 | 3 次 | 是否把"落层清晰度"作为卖点 |
| 10 | 麦克风在 127.0.0.1 + Edge/Chrome 的权限与录音可用性 | 现场留 30 分钟 | L5 可行性 |

---

## 9. 来源清单

**官方（●，全部 2026-11-08 访问）**

1. qwen3.8-max 模型卡 — https://platform.qianwenai.com/docs/models/qwen3-8-max.md
2. 分析图像与视频 — https://platform.qianwenai.com/docs/developer-guides/multimodal/vision.md
3. 图像编辑 — https://platform.qianwenai.com/docs/developer-guides/image-generation/image-editing.md
4. 结构化输出 — https://platform.qianwenai.com/docs/developer-guides/text-generation/structured-output.md
5. 流式输出 — https://platform.qianwenai.com/docs/developer-guides/run-and-scale/streaming.md
6. 思考模式 — https://platform.qianwenai.com/docs/developer-guides/text-generation/thinking.md
7. 全模态概述 — https://www.alibabacloud.com/help/zh/model-studio/omni/
8. 音视频文件理解 — https://platform.qianwenai.com/docs/developer-guides/speech/multimodal-speech.md
9. 模型价格 — https://platform.qianwenai.com/docs/developer-guides/getting-started/model-prices.md
10. 函数调用（结论引用自 3/6 的交叉说明） — https://platform.qianwenai.com/docs/developer-guides/tool-calling/function-calling.md

**本地文件**

11. `v2/serve.mjs`（代理、校验、队列、下载、SSE 透传）
12. `v2/app/core/ai-provider.mjs`（provider 抽象、normalize、prompt）
13. `v2/app/core/chat-actions.mjs`（行动白名单）
14. `v2/app/core/skills/builtin.mjs`（skill 契约）
15. `v2/app/core/mock-ai.mjs`（Mock 形状与 SVG 占位）
16. `v2/app/js/app.js`（AI 面板、裁切、落层、overlay、语音、成本写入）
17. `06-技术/模型能力调研_2026-11.md` §10（Qwen 实测记录）
18. `06-技术/多模态融合与开源借鉴.md`（交互范式来源与 clean-room 声明）
19. `06-技术/成本与延迟估算.md`（价格/延迟基线）
20. `v2/qa/tools/qwen-real-e2e-results.json`、`qwen-chat-real-results.json`、`qwen-image-real-results.json`、`qwen-image-edit-app-results.json`、`v2/app/test-multimodal-result.json`（■ 证据）

---

## 10. 给 Lead 的三句话

1. **Qwen 侧不用找新能力，先把已付的钱用起来**：流式（已接通未使用）、多图（上限被人为设成 2）、2K 输出（被 1MP 校验挡住）、语音（用错了 Web Speech）——**四个改动加起来约 3 天，就能把"等待"变成"表演"**。
2. **路演真正的 wow 不是"生成得多好"，是"AI 指得准 + 全程可举证"**：所以 **L3（bbox 契约 + 画布指认）优先级高于任何生图升级**；而它现在有一个必须先修的地基——坐标系契约与 Mock/真实坐标不一致，不修就是"演示时指错地方"。
3. **降级必须写在脸上**：预置样本、预录、Mock 各有各的位置，但 UI 徽章 / 图层名 / L6 断言三处必须同时说真话；现有三处文案要立刻改（Mock 图无内嵌标识、成本写死 ¥0.18、把 alpha 裁切说成 mask）。
