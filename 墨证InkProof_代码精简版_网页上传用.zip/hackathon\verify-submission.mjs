#!/usr/bin/env node
'use strict';

/*
 * 墨证 InkProof · 提交包独立验证工具（verify-submission.mjs）
 * ---------------------------------------------------------------
 * 作者：独立核查员（团队 D）。只新建本文件，不修改任何被检查文件。
 *
 * 性质：
 *   - 纯 Node 内置模块、零 npm 依赖、只读、可重复运行（同样的包应得到同样的判定）。
 *   - 唯一可能的写入是显式运行时把机器可读结果写到 JSON（默认 <dir>/VERIFY-RESULT.json）；
 *     --dry-run 不写任何文件。脚本本轮不应对真实 submission/ 执行默认写入。
 *   - 所有被检查文件的读取路径都限制在 --dir 指定的目录内（防 ../ 越界、不跟随符号链接）。
 *   - 大于 5MB 的文件（如 canvaskit.wasm / 大 png）与二进制扩展名跳过文本扫描。
 *
 * 用法：
 *   node hackathon/verify-submission.mjs [--dir submission] [--json <输出路径>] [--dry-run] [--help]
 *   --dir      待检查目录，默认 ./submission
 *   --json     结果 JSON 路径，默认 <dir>/VERIFY-RESULT.json
 *   --dry-run  只打印报告，不写任何文件（自测用，不污染提交包）
 *
 * 退出码：存在 FAIL -> 1；仅 WARN 或全 PASS -> 0；参数/目录错误 -> 1。
 *
 * ---------------------------------------------------------------
 * 【密钥扫描豁免规则】（刻意收紧，避免放过真实值；绝不打印匹配到的值）
 *
 * 1. 只命中「赋值形态的值」：敏感键名后跟 : 或 = 再跟引号字符串，或
 *    `Authorization: Bearer <实值>`。源码中作为标识符出现的 apiKey
 *    （如 target.apiKey、p.apiKey || ''、'Bearer ' + target.apiKey）不是赋值实值，
 *    其捕获值要么是空串要么是短占位，不会被判为真实密钥。
 * 2. 已知测试占位符一律豁免（前缀/形态/语义白名单，写在 isPlaceholder 中）：
 *      sk-test- / sk-local- / sk-upstream- / <...> / YOUR_ / xxx /
 *      qwen-test-key- / fake-key- / *-never-frontend / example / placeholder /
 *      dummy / wiring-check / 空串 / 纯 URL；
 *    另含收紧版语义词（与团队 A 打包脚本 package-submission.mjs 的 PLACEHOLDER 口径对齐）：
 *      test / mock / dummy / example / placeholder / sample / fake / never / frontend /
 *      adversarial / probe / stub / sandbox / your_key / xxxx / replace / insert /
 *      upstream / demo / wiring-check / secret。
 *    （secret 用于豁免 QA 脚本里 sk-...secret... 形态的本地假值；真实凭证为随机串，
 *     几乎不会含这些语义词。仍不加裸 `local` 之类过宽词。）
 *    依据：真实凭证通常是「sk- + 无语义随机串」，不会含这些词；本包 QA 脚本里的假 key
 *    均带 adversarial / probe / test 等语义。收紧点：不加裸 `local`/`secret` 这类过宽词，
 *    且【所有赋值形态命中（含被豁免的）都会逐条列出 file+line+type 供人工复核】，
 *    因此不存在「静默放过真实值」。
 *    本包已知的三处占位实值（不判为真实密钥）：
 *      'qwen-test-key-never-frontend'（全为字母+连字符，无数字）
 *      'sk-test-SECRET-1234'（命中 sk-test- 前缀）
 *      'fake-key-for-local-wiring-check'（全为字母+连字符，无数字，含 fake/local 语义）
 * 3. 「疑似真实值」判定采用用户给定的收紧规则：
 *      值长度 >= 20 且 同时含字母与数字（字母数字混合）且 非第 2 条任一已知占位形态。
 *    真实 key（如 sk-proj-Ab3x...9kL）通常长且含数字，会命中；占位值不会。
 * 4. 无论豁免与否，输出只含「文件名 + 行号 + 命中类型(+判定标签)」，
 *    绝不把匹配到的值写进 stdout 或 JSON。
 * ---------------------------------------------------------------
 */

import fs from 'node:fs';
import path from 'node:path';

const TOOL = 'inkproof.verify-submission';
const VERSION = '1.0.0';
const MAX_TEXT_BYTES = 5 * 1024 * 1024; // >5MB 跳过文本扫描

// ---------- 参数解析 ----------
function parseArgs(argv) {
  const opts = { dir: 'submission', json: null, dryRun: false, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--dir') { opts.dir = argv[++i]; }
    else if (a === '--json') { opts.json = argv[++i]; }
    else if (a === '--dry-run') { opts.dryRun = true; }
    else if (a === '--help' || a === '-h') { opts.help = true; }
    else if (a.startsWith('--dir=')) { opts.dir = a.slice(6); }
    else if (a.startsWith('--json=')) { opts.json = a.slice(7); }
    else { return { error: '未知参数: ' + a }; }
  }
  if (!opts.dir) return { error: '--dir 不能为空' };
  if (opts.json === null) opts.json = null; // 延迟到 run() 里按 dir 决定默认值
  return { opts };
}

function printHelp() {
  process.stdout.write([
    '用法: node hackathon/verify-submission.mjs [--dir <目录>] [--json <输出路径>] [--dry-run]',
    '',
    '  --dir       待检查目录（默认 ./submission）',
    '  --json      机器可读结果 JSON（默认 <dir>/VERIFY-RESULT.json，仅显式运行时写）',
    '  --dry-run   只打印报告、不写任何文件（自测用）',
    '  --help      显示本帮助',
    '',
    '退出码: 有 FAIL=1；仅 WARN/全 PASS=0。',
    '',
  ].join('\n'));
}

// ---------- 路径工具（防越界） ----------
const DIR = { abs: '' };

function toPosix(p) { return p.split(path.sep).join('/'); }

function within(dir, rel) {
  // 把相对路径解析到 dir 内；任何 ../ 越界返回 null。
  const root = path.resolve(dir);
  const abs = path.resolve(root, String(rel));
  if (abs !== root && !abs.startsWith(root + path.sep)) return null;
  return abs;
}

function relOf(abs) {
  const r = path.relative(DIR.abs, abs);
  return toPosix(r) || '.';
}

function fileExists(rel) {
  const abs = within(DIR.abs, rel);
  if (!abs) return false;
  try { return fs.statSync(abs).isFile(); } catch { return false; }
}

function fileSize(rel) {
  const abs = within(DIR.abs, rel);
  if (!abs) return 0;
  try { return fs.statSync(abs).size; } catch { return 0; }
}

// ---------- 只读遍历 ----------
const BINARY_EXT = new Set([
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.ico', '.wasm', '.psd',
  '.mp4', '.mov', '.zip', '.gz', '.tgz', '.7z', '.ppt', '.pptx', '.pdf',
  '.pyc', '.woff', '.woff2', '.ttf', '.eot', '.exe', '.dll', '.so', '.bin',
]);

function isTextScannable(f) {
  if (f.size > MAX_TEXT_BYTES) return false;       // 大文件跳过
  if (BINARY_EXT.has(f.ext)) return false;         // 二进制扩展名跳过
  return true;
}

function walk(dir, base, out) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
  catch { return; }
  for (const e of entries) {
    if (e.isSymbolicLink()) continue; // 不跟随符号链接，防越界
    const abs = path.join(dir, e.name);
    const rel = base ? base + '/' + e.name : e.name;
    if (e.isDirectory()) { walk(abs, rel, out); continue; }
    if (!e.isFile()) continue;
    let size = 0;
    try { size = fs.statSync(abs).size; } catch { /* ignore */ }
    const ext = path.extname(e.name).toLowerCase();
    out.push({ rel, abs, size, ext, base: e.name });
  }
}

function readText(rel) {
  const abs = within(DIR.abs, rel);
  if (!abs) return null;
  let buf;
  try { buf = fs.readFileSync(abs); } catch { return null; }
  if (buf.length > MAX_TEXT_BYTES) return null;
  if (buf.includes(0)) return null; // 含 NUL，视为二进制，跳过
  return buf.toString('utf8');
}

// ---------- 结果模型 ----------
const result = {
  tool: TOOL,
  version: VERSION,
  timestamp: new Date().toISOString(),
  dir: '',            // 绝对路径，run() 填充
  dirExists: false,
  options: {},
  summary: { PASS: 0, WARN: 0, FAIL: 0, exitCode: 0 },
  stats: {},
  checks: [],
};

function addCheck(id, name, status, message, evidence, extra) {
  const c = { id, name, status, message, evidence: evidence || [] };
  if (extra) Object.assign(c, extra);
  result.checks.push(c);
}

// =====================================================================
// 检查项 1 · 密钥扫描
// =====================================================================
const SECRET_BASENAMES = new Set(['.ai-config.json', '.ai-token']);
const ASSIGN_KEY_RE = /(?:["']?(?:api[_-]?key|secret[_-]?key|secret|token|password|authorization)["']?\s*[:=]\s*)(["'])([^"']*)\1/gi;
const BEARER_RE = /(?:Authorization\s*:\s*)?Bearer\s+([A-Za-z0-9._~+/\-=]{8,})/gi;

const PLACEHOLDER_RULES = [
  /^sk-test-/i, /^sk-local-/i, /^sk-upstream-/i,
  /^</, /^YOUR_/i, /^xxx/i,
  /^qwen-test-key-/i, /^fake-key-/i, /-never-frontend$/i,
  /example/i, /placeholder/i, /dummy/i, /wiring-check/i,
  // 收紧版语义词：真实凭证为无语义随机串，不含这些词；命中仍会全部列出供人工复核。
  /test|mock|dummy|example|placeholder|sample|fake|never|frontend|adversarial|probe|stub|sandbox|your[_-]?key|xxxx|replace|insert|upstream|demo|wiring-check|secret/i,
];

function isPlaceholder(v) {
  const t = String(v).trim();
  if (t.length === 0) return true;
  if (/^<.*>$/.test(t)) return true;                 // <...>
  if (/^https?:\/\//i.test(t)) return true;          // 纯 URL
  if (PLACEHOLDER_RULES.some((r) => r.test(t))) return true;
  return false;
}

function looksReal(v) {
  const t = String(v).trim();
  if (t.length < 20) return false;                   // 长度门槛
  if (!/[A-Za-z]/.test(t) || !/[0-9]/.test(t)) return false; // 字母数字混合
  if (isPlaceholder(t)) return false;                // 已知占位形态
  return true;
}

function check1_secrets(files) {
  const hits = [];            // 所有赋值形态命中（不含值）
  const deniedFiles = [];     // 被打进包的敏感配置文件
  let scanned = 0, skippedLarge = 0;

  for (const f of files) {
    if (SECRET_BASENAMES.has(f.base)) deniedFiles.push(f.rel);
    if (!isTextScannable(f)) { if (f.size > MAX_TEXT_BYTES) skippedLarge++; continue; }
    const text = readText(f.rel);
    if (text === null) continue;
    scanned++;
    const lines = text.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      ASSIGN_KEY_RE.lastIndex = 0;
      let m;
      while ((m = ASSIGN_KEY_RE.exec(line)) !== null) {
        const value = m[2];
        const verdict = looksReal(value) ? 'suspected-real' : 'placeholder-or-identifier';
        hits.push({ file: f.rel, line: i + 1, type: '敏感键明文赋值', verdict });
      }
      BEARER_RE.lastIndex = 0;
      while ((m = BEARER_RE.exec(line)) !== null) {
        const value = m[1];
        const verdict = looksReal(value) ? 'suspected-real' : 'placeholder-or-identifier';
        hits.push({ file: f.rel, line: i + 1, type: 'Authorization: Bearer 实值', verdict });
      }
    }
  }

  const real = hits.filter((h) => h.verdict === 'suspected-real');
  const placeholders = hits.length - real.length;
  const fail = deniedFiles.length > 0 || real.length > 0;

  const evidence = [];
  for (const h of hits.slice(0, 40)) {
    evidence.push(`${h.file}:${h.line} [${h.type}] (${h.verdict})`);
  }
  if (hits.length > 40) evidence.push(`…另有 ${hits.length - 40} 条命中，完整明细见 JSON`);
  for (const d of deniedFiles) evidence.push(`包内存在敏感配置文件: ${d}`);

  let message;
  if (fail) {
    message = `FAIL：发现 ${real.length} 处疑似真实密钥明文赋值、${deniedFiles.length} 个敏感配置文件（详见证据；不打印值）。`;
  } else {
    message = `PASS：未发现疑似真实密钥赋值；敏感配置文件 0 个。共扫描 ${scanned} 个文本文件，` +
      `命中 ${hits.length} 处「赋值形态」，其中 ${placeholders} 处为已知占位/标识符（按豁免规则不计），` +
      `跳过 >5MB 文件 ${skippedLarge} 个。`;
  }
  addCheck(1, '密钥扫描', fail ? 'FAIL' : 'PASS', message, evidence, {
    scannedTextFiles: scanned,
    skippedLargeFiles: skippedLarge,
    assignmentHits: hits.length,
    placeholderHits: placeholders,
    suspectedRealHits: real.length,
    deniedFiles,
    hitDetails: hits, // 仅 file/line/type/verdict，绝不含值
  });
  return { scanned, skippedLarge };
}

// =====================================================================
// 检查项 2 · 完整度
// =====================================================================
const KEY_FILES = [
  'LICENSE', 'VERIFY.md', 'README.md', 'hackathon/demo/index.html',
  'v2/serve.mjs', 'v2/app/index.html', 'v2/engine/vendor/canvaskit.wasm',
  'v2/engine/vendor/LICENSE', 'THIRD_PARTY_NOTICES.md',
];

function check2_completeness(files) {
  const qaToolsMjs = files.filter((f) => /^v2\/qa\/tools\/[^/]+\.mjs$/.test(f.rel)).length;
  const appTestMjs = files.filter((f) => /^v2\/app\/test-[^/]*\.mjs$/.test(f.rel)).length;
  const resultJson = files.filter((f) => /result/i.test(f.base) && /\.json$/i.test(f.base)).length;
  const png = files.filter((f) => /\.png$/i.test(f.base)).length;
  const rehearsalPng = files.filter((f) => /^rehearsal-.*\.png$/i.test(f.base)).length;
  const md = files.filter((f) => /\.md$/i.test(f.base)).length;

  const present = [], missing = [];
  for (const k of KEY_FILES) (fileExists(k) ? present : missing).push(k);

  const stats = {
    totalFiles: files.length,
    qaToolsMjs, appTestMjs, resultJson, png, rehearsalPng, md,
    keyFilesPresent: present.length,
    keyFilesTotal: KEY_FILES.length,
  };
  Object.assign(result.stats, stats);

  const emptyGroups = [];
  if (qaToolsMjs === 0) emptyGroups.push('v2/qa/tools/*.mjs');
  if (appTestMjs === 0) emptyGroups.push('v2/app/test-*.mjs');
  if (resultJson === 0) emptyGroups.push('*result*.json');
  if (rehearsalPng === 0) emptyGroups.push('rehearsal-*.png');
  if (md === 0) emptyGroups.push('*.md');

  const fail = missing.length > 0 || emptyGroups.length > 0;
  const evidence = [
    `v2/qa/tools/*.mjs = ${qaToolsMjs}`,
    `v2/app/test-*.mjs = ${appTestMjs}`,
    `*result*.json = ${resultJson}`,
    `*.png = ${png}（其中 rehearsal-*.png = ${rehearsalPng}）`,
    `*.md = ${md}`,
    `总文件数 = ${files.length}`,
    `关键文件 ${present.length}/${KEY_FILES.length} 存在`,
  ];
  for (const m of missing) evidence.push(`关键文件缺失: ${m}`);
  for (const g of emptyGroups) evidence.push(`计数为 0 的类别: ${g}`);

  const message = fail
    ? `FAIL：关键文件缺失 ${missing.length} 个 / 空类别 ${emptyGroups.length} 个。`
    : `PASS：9 个关键文件齐全；各类证据计数均 > 0（QA 脚本 ${qaToolsMjs}、测试脚本 ${appTestMjs}、` +
      `结果 JSON ${resultJson}、彩排截图 ${rehearsalPng}、md ${md}）。`;
  addCheck(2, '完整度', fail ? 'FAIL' : 'PASS', message, evidence, { missing, emptyGroups, stats });
}

// =====================================================================
// 检查项 3 · README 宣称 -> 证据对照
// =====================================================================
const BACKTICK_RE = /`([^`\n]+)`/g;

function extractRefPaths(text) {
  const set = new Set();
  const skipped = [];
  let m;
  BACKTICK_RE.lastIndex = 0;
  while ((m = BACKTICK_RE.exec(text)) !== null) {
    const s = m[1].trim();
    if (!s) continue;
    if (/^https?:\/\//i.test(s)) continue;                 // URL
    if (/\s/.test(s)) continue;                            // 命令 / 含空格说明
    if (/^[A-Za-z]:[\\/]/.test(s)) continue;              // Windows 绝对路径
    if (/^\.\./.test(s)) { skipped.push(s); continue; }   // ../node_modules/... 相对 import，不是包内文件
    if (/^[.#~$*<{(\[]/.test(s)) { skipped.push(s); continue; } // 扩展名 / 占位 / 命令开头
    if (!/^[A-Za-z0-9_\-./]+$/.test(s)) { skipped.push(s); continue; } // 非路径字符（events[] 等）
    if (/[<>%*…]/.test(s) || /T1xx/i.test(s) || /\.\.\./.test(s)) { skipped.push(s); continue; } // 通配/占位
    if (!/\.[A-Za-z0-9]{1,8}$/.test(s)) continue;         // 纯目录：跳过
    const parts = s.split('/');
    const basename = parts[parts.length - 1];
    if (basename.startsWith('.')) { skipped.push(s); continue; } // .mjs / .mozheng / v2/.ai-config.json 等隐藏项
    if (parts.length === 1 && (s.match(/\./g) || []).length >= 2) { skipped.push(s); continue; } // manifest.attest 之类字段名
    // 验证器自身产物：本轮运行结束时才写入 <dir>/VERIFY-RESULT.json。
    // 全新重建的包首次运行时该文件尚不存在，属于时序假阳性，不计为「宣称指向的证据缺失」。
    if (s === 'VERIFY-RESULT.json') { skipped.push(s); continue; }
    set.add(s);
  }
  return { paths: [...set], skipped };
}

function resolveRef(p, files) {
  // ① 包根基准 ② hackathon/ 基准（README 内 scripts/ 等相对 hackathon/ 目录）
  // ③ 裸文件名按 basename 在包内任意位置兜底查找（如 final-core-regression.txt 在 v2/qa/tools/ 下）
  for (const c of [p, 'hackathon/' + p]) {
    const abs = within(DIR.abs, c);
    if (abs && fs.existsSync(abs)) { try { if (fs.statSync(abs).isFile()) return c; } catch {} }
  }
  const base = p.split('/').pop();
  const found = files.find((f) => f.base === base);
  return found ? found.rel : null;
}

function check3_readmeRefs(files) {
  const sources = ['README.md', 'VERIFY.md'];
  const allPaths = new Set();
  const allSkipped = new Set();
  const sourceInfo = [];
  for (const src of sources) {
    const text = readText(src);
    if (text === null) { sourceInfo.push(`${src}（不可读/不存在）`); continue; }
    const { paths, skipped } = extractRefPaths(text);
    sourceInfo.push(`${src}: 抽取 ${paths.length} 条相对路径，跳过 ${skipped.length} 条通配/占位/非路径`);
    paths.forEach((p) => allPaths.add(p));
    skipped.forEach((p) => allSkipped.add(p));
  }
  const paths = [...allPaths].sort();
  const missing = [], resolved = [];
  for (const p of paths) {
    const hit = resolveRef(p, files);
    if (hit) resolved.push({ claimed: p, resolvedAs: hit });
    else missing.push(p);
  }
  // 分级：含目录前缀的缺失优先复核；裸文件名可能是「测试预期输出」或文档已声明不在包内，作 WARN 供人工判定。
  const strongMissing = missing.filter((p) => p.includes('/'));
  const weakMissing = missing.filter((p) => !p.includes('/'));
  const evidence = [
    ...sourceInfo,
    `确定路径 ${paths.length} 条，包内命中 ${resolved.length} 条，缺失 ${missing.length} 条` +
      `（含目录前缀 ${strongMissing.length} / 裸文件名 ${weakMissing.length}）`,
    '注：VERIFY-RESULT.json 是本验证器自身在本次运行结束时才写入的产物，已从「宣称→证据」路径核对中排除，避免全新重建包首次运行的时序假阳性。',
  ];
  for (const m of strongMissing) evidence.push(`缺失(含目录前缀，优先复核): ${m}`);
  for (const m of weakMissing) evidence.push(`缺失(裸文件名，可能是测试产物/文档已声明不在包内): ${m}`);
  if (allSkipped.size) evidence.push(`通配/占位/非路径（不判缺失，供人工看）: ${[...allSkipped].slice(0, 8).join(' , ')}${allSkipped.size > 8 ? ' …' : ''}`);

  const status = missing.length === 0 ? 'PASS' : 'WARN';
  const message = status === 'WARN'
    ? `WARN：${missing.length} 条反引号路径在包内找不到（含目录前缀 ${strongMissing.length} 条、裸文件名 ${weakMissing.length} 条）；` +
      `已列清单供人工判定——路径基准差异、或文档描述的是「测试预期输出 / 明确不在包内」的引用，均可能。`
    : `PASS：README/VERIFY 抽取的 ${paths.length} 条相对路径在包内均可命中。`;
  addCheck(3, 'README 宣称 → 证据对照', status, message, evidence, {
    extracted: paths.length, resolved, missing, strongMissing, weakMissing, skippedWildcards: [...allSkipped],
  });
}

// =====================================================================
// 检查项 4 · 死链检查（start.bat / README / VERIFY 里的 127.0.0.1/v2/ 地址）
// =====================================================================
const RAW_URL_RE = /http:\/\/127\.0\.0\.1:[^\s"'`)]+/g;

function extractV2Urls(text) {
  const out = new Set();
  let m;
  RAW_URL_RE.lastIndex = 0;
  while ((m = RAW_URL_RE.exec(text)) !== null) {
    const raw = m[0];
    const mm = raw.match(/^http:\/\/127\.0\.0\.1:[^/]*(\/.*)$/);
    if (!mm) continue;
    let pathPart = mm[1].replace(/[),，。；、）】》]+$/, ''); // 去尾部中文标点
    if (!/\/v2\//.test(pathPart)) continue;                  // 只检查 /v2/... 静态资源
    pathPart = pathPart.split('?')[0].split('#')[0];
    let rel = pathPart.replace(/^\/+/, '');
    try { rel = decodeURIComponent(rel); } catch { /* 保留原样 */ }
    out.add(rel);
  }
  return [...out];
}

function check4_deadLinks() {
  const sources = ['v2/start.bat', 'README.md', 'VERIFY.md'];
  const urlSet = new Set();
  const srcInfo = [];
  for (const src of sources) {
    const text = readText(src);
    if (text === null) { srcInfo.push(`${src}（不可读/不存在）`); continue; }
    const urls = extractV2Urls(text);
    srcInfo.push(`${src}: 解析出 ${urls.length} 个 /v2/ 静态地址`);
    urls.forEach((u) => urlSet.add(u));
  }
  const urls = [...urlSet].sort();
  const missing = [], ok = [];
  for (const u of urls) {
    const abs = within(DIR.abs, u);
    const found = abs && fs.existsSync(abs);
    (found ? ok : missing).push(u);
  }
  const evidence = [
    ...srcInfo,
    `共 ${urls.length} 个唯一 /v2/ 地址，命中 ${ok.length} 个，404 候选 ${missing.length} 个`,
  ];
  for (const m of missing) evidence.push(`404 候选: /${m}`);

  const fail = missing.length > 0;
  const message = fail
    ? `FAIL：${missing.length} 个对外/启动地址映射到包内文件不存在（评审曾发现 3 个 404）。`
    : `PASS：${urls.length} 个 /v2/ 地址映射的文件全部存在，无 404。`;
  addCheck(4, '死链检查', fail ? 'FAIL' : 'PASS', message, evidence, {
    urls, ok, missing,
  });
}

// =====================================================================
// 检查项 5 · 许可检查
// =====================================================================
function check5_license() {
  const licenseOk = fileExists('LICENSE') && fileSize('LICENSE') > 0;
  const notices = readText('v2/engine/vendor/THIRD_PARTY_NOTICES.md');
  const bsdOk = notices !== null && notices.includes('BSD-3-Clause');
  const badLines = [];
  for (const src of ['README.md', 'VERIFY.md']) {
    const text = readText(src);
    if (text === null) continue;
    const lines = text.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (/CanvasKit（Apache-2\.0）/.test(line) ||
          (/Apache-2\.0/.test(line) && /CanvasKit/i.test(line))) {
        badLines.push(`${src}:${i + 1} [Apache-2.0 与 CanvasKit 同句]`);
      }
    }
  }
  const evidence = [
    `LICENSE 存在且非空 = ${licenseOk}`,
    `v2/engine/vendor/THIRD_PARTY_NOTICES.md 含 BSD-3-Clause = ${bsdOk}`,
    `README/VERIFY 中「CanvasKit + Apache-2.0」违规行 = ${badLines.length}`,
  ];
  for (const b of badLines) evidence.push(`违规: ${b}`);
  const fail = !licenseOk || !bsdOk || badLines.length > 0;
  const message = fail
    ? 'FAIL：许可口径存在问题（LICENSE / BSD-3-Clause 声明 / CanvasKit 许可措辞）。'
    : 'PASS：项目 LICENSE 非空、CanvasKit 声明为 BSD-3-Clause、README/VERIFY 未把 CanvasKit 写成 Apache-2.0。';
  addCheck(5, '许可检查', fail ? 'FAIL' : 'PASS', message, evidence, {
    licenseOk, bsdOk, badLines,
  });
}

// =====================================================================
// 检查项 6 · 口径一致性（ERROR / WARN 分级）
// =====================================================================
const ERROR_PATTERNS = [
  { type: '能证明没用 AI', re: /能证明没用\s*AI/g },
  { type: '能证明没用过 AI', re: /能证明没用过\s*AI/g },
  { type: '防篡改存证', re: /防篡改存证/g },
  { type: '证明这是她画的', re: /证明这是她画的/g },
];
const WARN_PATTERNS = [
  { type: '禁用词(首创/首个/颠覆/重新定义)', re: /首创|首个|颠覆|重新定义/g },
  { type: '3 分钟演示', re: /3\s*分钟演示/g },
  { type: '146 文件', re: /146\s*文件/g },
  { type: '4200 写死端口', re: /127\.0\.0\.1:4200|:4200|4200\s*端口|4200\s*在跑|4200\s*健康|本机\s*4200|默认\s*4200|服务\s*4200/g },
];
const DYN_PORT_HINT = /动态端口|实际端口|实际打印|以窗口|被占用|占用自动|顺延|runtime-port|端口以|<\s*实际端口\s*>/;
const NEGATION_HINT = /不|禁止|禁用|避免|不说|不称|不是|别|勿|无|排除|红线/;

function check6_wording(files) {
  const mdFiles = files.filter((f) => /\.md$/i.test(f.base) && isTextScannable(f));
  const errorHits = [], warnHits = [];
  let scannedMd = 0;
  for (const f of mdFiles) {
    const text = readText(f.rel);
    if (text === null) continue;
    scannedMd++;
    const lines = text.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      for (const p of ERROR_PATTERNS) {
        p.re.lastIndex = 0;
        if (p.re.test(line)) errorHits.push({ file: f.rel, line: i + 1, type: p.type });
      }
      for (const p of WARN_PATTERNS) {
        p.re.lastIndex = 0;
        if (!p.re.test(line)) continue;
        // 4200：若同一行是「动态端口」说明，视为豁免不算残留
        if (p.type === '4200 写死端口' && DYN_PORT_HINT.test(line)) continue;
        const negated = p.type.startsWith('禁用词') && NEGATION_HINT.test(line);
        warnHits.push({ file: f.rel, line: i + 1, type: p.type, negatedOrList: negated });
      }
    }
  }

  const evidence = [];
  for (const h of errorHits) evidence.push(`ERROR ${h.file}:${h.line} [${h.type}]`);
  for (const h of warnHits.slice(0, 60)) {
    evidence.push(`WARN  ${h.file}:${h.line} [${h.type}]${h.negatedOrList ? ' (否定句/禁用清单，供人工判定)' : ''}`);
  }
  if (warnHits.length > 60) evidence.push(`…另有 ${warnHits.length - 60} 条 WARN，完整明细见 JSON`);

  const status = errorHits.length > 0 ? 'FAIL' : (warnHits.length > 0 ? 'WARN' : 'PASS');
  const message = status === 'FAIL'
    ? `FAIL：发现 ${errorHits.length} 处越界宣称残留（ERROR，须改）；另有 ${warnHits.length} 处 WARN 供人工判定（扫描 ${scannedMd} 个 .md）。`
    : status === 'WARN'
      ? `PASS(有 WARN)：无 ERROR 越界宣称；${warnHits.length} 处 WARN 命中（禁用词/3 分钟演示/146 文件/4200 写死端口），已列行号供人工判定（扫描 ${scannedMd} 个 .md）。`
      : `PASS：${scannedMd} 个 .md 未发现任何口径残留。`;
  addCheck(6, '口径一致性', status, message, evidence, {
    scannedMd, errorHits, warnHits,
  });
}

// =====================================================================
// 检查项 7 · 旧材料（mock 时代 PPT/PDF）
// =====================================================================
function check7_oldPitch(files) {
  const docs = files.filter((f) => /\.(ppt|pptx|pdf)$/i.test(f.base));
  const rootLevel = docs.filter((f) => !f.rel.includes('/'));
  const archived = docs.filter((f) => /^_archive_pitch_DEPRECATED\//.test(f.rel));
  const elsewhere = docs.filter((f) => f.rel.includes('/') && !/^_archive_pitch_DEPRECATED\//.test(f.rel));
  const deprecatedOk = fileExists('_archive_pitch_DEPRECATED/DEPRECATED.md');

  const evidence = [
    `包内 PPT/PDF 共 ${docs.length} 个（包根 ${rootLevel.length} / 归档目录 ${archived.length} / 其它位置 ${elsewhere.length}）`,
    `_archive_pitch_DEPRECATED/DEPRECATED.md 存在 = ${deprecatedOk}`,
  ];
  for (const f of rootLevel) evidence.push(`包根违规: ${f.rel}`);
  for (const f of elsewhere) evidence.push(`非归档位置违规: ${f.rel}`);

  const fail = rootLevel.length > 0 || elsewhere.length > 0 || (archived.length > 0 && !deprecatedOk);
  const message = fail
    ? 'FAIL：存在未正确归档的 mock 时代 PPT/PDF，或归档目录缺 DEPRECATED.md。'
    : (docs.length === 0
        ? 'PASS：包内无 mock 时代 PPT/PDF。'
        : `PASS：${docs.length} 个旧 PPT/PDF 均在 _archive_pitch_DEPRECATED/ 且 DEPRECATED.md 存在。`);
  addCheck(7, '旧材料', fail ? 'FAIL' : 'PASS', message, evidence, {
    total: docs.length, rootLevel: rootLevel.map((f) => f.rel),
    archived: archived.map((f) => f.rel), elsewhere: elsewhere.map((f) => f.rel), deprecatedOk,
  });
}

// =====================================================================
// 检查项 8 · 用户验证诚信（是否代填真实数据）
// =====================================================================
const USER_VALIDATION_TARGETS = ['hackathon/用户验证.md', 'hackathon/用户验证表.html'];
const SUSPECT_PATTERNS = [
  { type: '具体均分', re: /平均\s*[0-9]/ },
  { type: '具体分数', re: /[0-9]\.[0-9]+\s*分/ },
  { type: 'U 行已填数据', re: /\|\s*U[1-9]\s*\|\s*[^|\s]/ },
  { type: '原话实值', re: /原话[:：]\s*["「“']/ },
  { type: '具体人数', re: /共\s*[0-9]+\s*位|完成\s*[0-9]+\s*位|[0-9]+\s*位(?:用户|真实验证)[^，。]{0,8}(?:已完成|参与|试用)/ },
  { type: '均分实值', re: /均分[:：]?\s*[0-9]/ },
];

function check8_userValidation() {
  const hits = [], absent = [];
  for (const rel of USER_VALIDATION_TARGETS) {
    const text = readText(rel);
    if (text === null) { absent.push(rel); continue; }
    const lines = text.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      for (const p of SUSPECT_PATTERNS) {
        if (p.re.test(lines[i])) hits.push({ file: rel, line: i + 1, type: p.type });
      }
    }
  }
  const evidence = [];
  for (const a of absent) evidence.push(`目标文件缺失/不可读: ${a}`);
  for (const h of hits.slice(0, 40)) evidence.push(`疑似已填真实数据 ${h.file}:${h.line} [${h.type}]`);
  if (hits.length > 40) evidence.push(`…另有 ${hits.length - 40} 条，完整明细见 JSON`);
  if (hits.length === 0 && absent.length === 0) evidence.push('两份材料均为空白模板，未发现具体分数/人数/原话。');

  const status = (hits.length > 0 || absent.length > 0) ? 'WARN' : 'PASS';
  const message = status === 'WARN'
    ? `WARN：用户验证材料有 ${hits.length} 处疑似已填真实数据、${absent.length} 个文件缺失（本项必须由真人执行，Agent 不得代填）；已列行号供人工判定。`
    : 'PASS：用户验证材料保持空白模板，未发现被代填的分数/人数/原话。';
  addCheck(8, '用户验证诚信', status, message, evidence, { absent, hits });
}

// =====================================================================
// 检查项 9 · 汇总
// =====================================================================
function check9_summary() {
  const counts = { PASS: 0, WARN: 0, FAIL: 0 };
  for (const c of result.checks) counts[c.status]++;
  const exitCode = counts.FAIL > 0 ? 1 : 0; // 有 FAIL 返回 1；仅 WARN 返回 0
  const checked = counts.PASS + counts.WARN + counts.FAIL; // 不含汇总行自身
  result.summary = { ...counts, exitCode };
  result.stats.checksTotal = checked;
  const evidence = [
    `PASS=${counts.PASS} WARN=${counts.WARN} FAIL=${counts.FAIL}`,
    `退出码=${exitCode}`,
  ];
  addCheck(9, '汇总', counts.FAIL > 0 ? 'FAIL' : (counts.WARN > 0 ? 'WARN' : 'PASS'),
    `汇总：${checked} 项检查（不含本汇总行），PASS=${counts.PASS} / WARN=${counts.WARN} / FAIL=${counts.FAIL}；退出码 ${exitCode}。`,
    evidence, { pass: counts.PASS, warn: counts.WARN, fail: counts.FAIL, exitCode });
  return exitCode;
}

// ---------- 人类可读报告 ----------
function printReport() {
  const L = [];
  L.push('============================================================');
  L.push(` 墨证 InkProof · 提交包独立验证  v${VERSION}`);
  L.push(` 目录(绝对): ${result.dir}`);
  L.push(` 运行时间  : ${result.timestamp}`);
  L.push(` 模式      : ${result.options.dryRun ? 'dry-run（不写任何文件）' : '只读检查 + 写结果 JSON'}`);
  L.push('============================================================');
  for (const c of result.checks) {
    L.push('');
    L.push(`[${c.status}] ${c.id}. ${c.name}`);
    L.push(`   ${c.message}`);
    for (const e of c.evidence) L.push(`   - ${e}`);
  }
  L.push('');
  L.push('------------------------------------------------------------');
  const s = result.stats;
  L.push(` 统计: 总文件 ${s.totalFiles ?? '-'} | QA脚本 ${s.qaToolsMjs ?? '-'} | 测试脚本 ${s.appTestMjs ?? '-'} | ` +
         `结果JSON ${s.resultJson ?? '-'} | PNG ${s.png ?? '-'} | 彩排PNG ${s.rehearsalPng ?? '-'} | md ${s.md ?? '-'}`);
  L.push(` 汇总: PASS=${result.summary.PASS} WARN=${result.summary.WARN} FAIL=${result.summary.FAIL} 退出码=${result.summary.exitCode}`);
  L.push('------------------------------------------------------------');
  if (!result.options.dryRun && result.options.jsonPath) {
    L.push(` 结果 JSON: ${result.options.jsonPath}`);
  } else if (result.options.dryRun) {
    L.push(' 结果 JSON: 未写入（dry-run）');
  }
  process.stdout.write(L.join('\n') + '\n');
}

// ---------- 主流程 ----------
function run() {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed.error) {
    process.stderr.write('参数错误: ' + parsed.error + '\n');
    printHelp();
    process.exitCode = 1;
    return;
  }
  const opts = parsed.opts;
  if (opts.help) { printHelp(); return; }

  DIR.abs = path.resolve(opts.dir);
  result.dir = DIR.abs;
  const jsonPath = opts.json || path.join(DIR.abs, 'VERIFY-RESULT.json');
  result.options = { dir: opts.dir, jsonPath: path.resolve(jsonPath), dryRun: opts.dryRun };

  // 目录不存在：优雅报错，不崩溃
  let dirStat;
  try { dirStat = fs.statSync(DIR.abs); } catch { dirStat = null; }
  if (!dirStat || !dirStat.isDirectory()) {
    result.dirExists = false;
    addCheck(0, '目录可访问性', 'FAIL',
      `待检查目录不存在或不是目录: ${DIR.abs}（请用 --dir 指向有效目录）`, [DIR.abs]);
    check9_summary();
    printReport();
    if (!opts.dryRun) writeJson(path.resolve(jsonPath));
    process.exitCode = result.summary.exitCode;
    return;
  }
  result.dirExists = true;

  const files = [];
  walk(DIR.abs, '', files);
  files.sort((a, b) => a.rel.localeCompare(b.rel));

  const secretStats = check1_secrets(files);
  check2_completeness(files);
  check3_readmeRefs(files);
  check4_deadLinks();
  check5_license();
  check6_wording(files);
  check7_oldPitch(files);
  check8_userValidation();
  const exitCode = check9_summary();

  Object.assign(result.stats, {
    textFilesScannedForSecrets: secretStats.scanned,
    largeFilesSkipped: secretStats.skippedLarge,
  });

  printReport();
  if (!opts.dryRun) writeJson(path.resolve(jsonPath));
  process.exitCode = exitCode;
}

function writeJson(absPath) {
  try {
    fs.writeFileSync(absPath, JSON.stringify(result, null, 2), 'utf8');
  } catch (e) {
    // 优雅报错：写 JSON 失败不影响检查结论，仅提示
    process.stderr.write(`警告：结果 JSON 写入失败 (${absPath}): ${e && e.message ? e.message : e}\n`);
  }
}

run();
