// v2/app/test-paper.mjs — T86 暖纸感视觉验收（token/对比度/纸纹/三档截图）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8119;
const out = { schema: 'mozheng.app.paper-test.v1', cases: {}, errors: [] };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
let browser = null;
let errors = [];
const finish = (code = 0) => { try { fs.writeFileSync(ROOT + '\\v2\\app\\test-paper-result.json', JSON.stringify(out, null, 2), 'utf8'); } catch (e) {} process.exit(code); };
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_180s'; finish(3); }, 180000);
try {
  await new Promise((r) => setTimeout(r, 800));
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const context = await browser.newContext({ viewport: { width: 1920, height: 1080 } });
  const page = await context.newPage();
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  const load = async (w, h) => {
    await page.setViewportSize({ width: w, height: h });
    await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
    await page.waitForTimeout(500);
  };
  await load(1920, 1080);
  out.cases.tokens = await page.evaluate(() => {
    const $ = (s) => document.querySelector(s);
    const rgb = (s) => { const m = String(s).match(/rgba?\((\d+)[, ]+(\d+)[, ]+(\d+)/); return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null; };
    const lum = (c) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
    const contrast = (fg, bg) => { const a = lum(rgb(fg)), b = lum(rgb(bg)); return Math.round(((Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05)) * 10) / 10; };
    const cs = (s) => getComputedStyle($(s));
    const bodyBg = cs('body').backgroundColor; const bodyText = cs('body').color;
    const topbarBg = cs('.pro-topbar').backgroundColor; const docColor = cs('.pro-doc').color;
    return {
      theme: document.documentElement.dataset.theme,
      stylesheet: !!document.querySelector('link[href*="paper-theme.css"]'),
      bodyBg, bodyText, bodyContrast: contrast(bodyText, bodyBg),
      topbarBg, docColor, docContrast: contrast(docColor, topbarBg),
      appGrain: getComputedStyle($('#app')).backgroundImage.includes('data:image/svg'),
      artboardBg: cs('#mainCanvas').backgroundColor,
      artboardBorder: cs('#mainCanvas').borderTopColor,
      artboardShadow: cs('#mainCanvas').boxShadow,
      activeToolBg: cs('.pro-btn.active').backgroundColor,
      activeToolColor: cs('.pro-btn.active .ico').color,
      sliderThumb: (() => { try { return getComputedStyle($('#leftSizeRange'), '::-webkit-slider-thumb').backgroundColor; } catch (e) { return null; } })(),
    };
  });
  // 浮层
  await page.click('#btnPanelLayers');
  await page.waitForTimeout(400);
  out.cases.popover = await page.evaluate(() => {
    const $ = (s) => document.querySelector(s);
    const cs = (s) => getComputedStyle($(s));
    const rgb = (s) => { const m = String(s).match(/rgba?\((\d+)[, ]+(\d+)[, ]+(\d+)/); return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null; };
    const lum = (c) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
    const contrast = (fg, bg) => { const a = lum(rgb(fg)), b = lum(rgb(bg)); return Math.round(((Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05)) * 10) / 10; };
    const pop = $('#popLayers');
    return { open: pop.classList.contains('open'), bg: cs('#popLayers').backgroundColor, color: cs('#popLayers').color, headText: cs('#popLayers .pro-pop-head h3').color, headFont: cs('#popLayers .pro-pop-head h3').fontSize, bodyFont: cs('#popLayers .pro-pop-body').fontSize, contrast: contrast(cs('#popLayers').color, cs('#popLayers').backgroundColor) };
  });
  await page.keyboard.press('Escape');
  // 素材库
  await page.evaluate(() => window.__V2_APP__.t71.openLibrarySheet());
  await page.waitForTimeout(1200);
  out.cases.library = await page.evaluate(() => {
    const $ = (s) => document.querySelector(s);
    const cs = (s) => getComputedStyle($(s));
    const rgb = (s) => { const m = String(s).match(/rgba?\((\d+)[, ]+(\d+)[, ]+(\d+)/); return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null; };
    const lum = (c) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
    const contrast = (fg, bg) => { const a = lum(rgb(fg)), b = lum(rgb(bg)); return Math.round(((Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05)) * 10) / 10; };
    const sheet = cs('#librarySheet'); const sheetBg = sheet.backgroundColor;
    let minFont = 99;
    document.querySelectorAll('#librarySheet *').forEach((el) => {
      const st = getComputedStyle(el); const txt = (el.textContent || '').trim();
      if (!txt || el.offsetParent === null) return;
      const fs = parseFloat(st.fontSize) || 99; if (fs < minFont) minFont = fs;
    });
    return {
      scrim: cs('#libraryBackdrop').backgroundColor,
      sheetBg, headerBg: cs('.lib-head').backgroundColor,
      cardBg: cs('.lib-card').backgroundColor, detailBg: cs('.lib-detail').backgroundColor,
      h1Color: cs('.lib-h1').color, h1Contrast: contrast(cs('.lib-h1').color, sheetBg),
      summaryColor: cs('.lib-l1-summary').color, summaryContrast: contrast(cs('.lib-l1-summary').color, sheetBg),
      kvColor: cs('.lib-kv').color, kvContrast: contrast(cs('.lib-kv').color, sheetBg),
      minFont, sourceIcons: document.querySelectorAll('#libGrid .lib-src .lib-src-ico').length,
      detailPadBottom: cs('.lib-detail-body').paddingBottom,
      paletteHex: [...document.querySelectorAll('#libDetail .lib-palette span')].every((x) => /^#[0-9a-f]{6}$/i.test(x.title)),
    };
  });
  await page.evaluate(() => window.__V2_APP__.t71.closeLibrarySheet());
  // 演示说明卡
  await page.click('#btnDemo');
  await page.waitForTimeout(1500);
  out.cases.demo = await page.evaluate(() => {
    const $ = (s) => document.querySelector(s);
    const cs = (s) => getComputedStyle($(s));
    const rgb = (s) => { const m = String(s).match(/rgba?\((\d+)[, ]+(\d+)[, ]+(\d+)/); return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null; };
    const lum = (c) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
    const contrast = (fg, bg) => { const a = lum(rgb(fg)), b = lum(rgb(bg)); return Math.round(((Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05)) * 10) / 10; };
    return { cardBg: cs('#demoNarr').backgroundColor, titleColor: cs('#demoNarrTitle').color, textColor: cs('#demoNarrText').color, contrast: contrast(cs('#demoNarrText').color, cs('#demoNarr').backgroundColor), step: document.getElementById('demoStepLabel').textContent, label: document.getElementById('demoSpotlightLabel').textContent, spotlightBorder: cs('#demoSpotlight').borderTopColor };
  });
  out.cases.t87 = await page.evaluate(() => {
    const $ = (s) => document.querySelector(s);
    const cs = (s) => getComputedStyle($(s));
    const steps = window.__V2_APP__.t82.steps();
    const totalDuration = steps.reduce((a, b) => a + b.duration, 0);
    const scrim = cs('#demoScrim').backgroundColor;
    const m = scrim.match(/rgba?\(([^)]+)\)/);
    const parts = m ? m[1].split(',').map((x) => Number(x.trim())) : [];
    const end = $('.demo-end');
    const oldDisplay = end.style.display; end.style.display = 'block';
    const endCardWidth = Math.round(end.getBoundingClientRect().width);
    end.style.display = oldDisplay;
    return {
      scrimAlpha: parts.length >= 4 ? parts[3] : null,
      cardWidth: Math.round($('#demoNarr').getBoundingClientRect().width),
      narrFont: cs('#demoNarrText').fontSize,
      narrTitleFont: cs('#demoNarrTitle').fontSize,
      hasCardProgress: !!$('#demoNarrProgress') && getComputedStyle($('#demoNarrProgress')).animationName.includes('t87-card-progress'),
      totalDuration,
      endTitleFont: cs('.demo-end h3').fontSize,
      endDescFont: cs('.demo-end p').fontSize,
      endCardWidth,
      demoTopbarGrain: cs('.pro-topbar').backgroundImage,
      demoCardGrain: cs('#demoNarr').backgroundImage,
      bodyBeforeOpacity: getComputedStyle(document.body, '::before').opacity,
    };
  });
  await page.evaluate(() => window.__V2_APP__.t82.exitDemo());
  // 三档截图
  const shots = {};
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await load(w, h);
    await page.screenshot({ path: ROOT + '\\v2\\app\\ui-paper-' + w + '.png' });
    shots[w] = await page.evaluate(() => ({ overX: document.documentElement.scrollWidth > innerWidth + 1, overY: document.documentElement.scrollHeight > innerHeight + 1, theme: document.documentElement.dataset.theme, bodyBg: getComputedStyle(document.body).backgroundColor }));
  }
  out.cases.screenshots = shots;
  out.errors = errors.slice(0, 10);
  out.pass = {
    theme: out.cases.tokens.theme === 'paper' && out.cases.tokens.stylesheet && out.cases.tokens.appGrain,
    contrast: out.cases.tokens.bodyContrast >= 13 && out.cases.tokens.docContrast >= 7,
    artboard: out.cases.tokens.artboardBg === 'rgb(255, 255, 255)' && out.cases.tokens.artboardBorder.includes('36, 31, 25'),
    activeTool: out.cases.tokens.activeToolBg === 'rgb(36, 31, 25)' && out.cases.tokens.activeToolColor === 'rgb(251, 246, 236)',
    popover: out.cases.popover.open && out.cases.popover.contrast >= 7 && parseFloat(out.cases.popover.headFont) >= 12 && parseFloat(out.cases.popover.bodyFont) >= 12,
    library: out.cases.library.scrim.includes('35, 27, 18') && out.cases.library.minFont >= 11.5 && out.cases.library.h1Contrast >= 7 && out.cases.library.summaryContrast >= 7 && out.cases.library.kvContrast >= 4.5 && out.cases.library.sourceIcons >= 2 && out.cases.library.paletteHex,
    demo: parseFloat(out.cases.demo.contrast) >= 7 && out.cases.demo.label.length > 0 && /\/ 12$/.test(out.cases.demo.step),
    screenshots: Object.values(shots).every((v) => !v.overX && !v.overY && v.theme === 'paper'),
    t87: out.cases.t87.scrimAlpha >= 0.55 && out.cases.t87.scrimAlpha <= 0.62 && out.cases.t87.cardWidth >= 380 && out.cases.t87.cardWidth <= 430 && out.cases.t87.narrFont === '16px' && out.cases.t87.hasCardProgress && out.cases.t87.totalDuration <= 60000 && out.cases.t87.endTitleFont === '32px' && out.cases.t87.endDescFont === '16px' && out.cases.t87.endCardWidth === 620 && out.cases.t87.demoTopbarGrain === 'none' && out.cases.t87.demoCardGrain === 'none' && parseFloat(out.cases.t87.bodyBeforeOpacity) <= 0.15 && out.cases.library.detailPadBottom === '96px',
    noConsoleErrors: out.errors.length === 0,
  };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} finally {
  clearTimeout(hard);
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  finish(0);
}
