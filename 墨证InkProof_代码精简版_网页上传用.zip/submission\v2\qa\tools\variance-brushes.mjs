#!/usr/bin/env node
/**
 * v2/qa/tools/variance-brushes.mjs — 专项：ours-brushes S1 ink 5 轮波动复测（确认噪声 vs 真不稳）
 *
 * 背景：T58/T54 后 GATE 曾报 ours-brushes S1 ink 3 轮 935–1307（≈28%），需确认是采样/模拟压感噪声
 * 还是帧/提交不稳。做法：同一页面、同一 S1 慢速 S 形笔迹，独立 5 轮（每轮清存储+重载+清空画布），
 * 记录 ink / 断点 / 粗细 CV / 4 帧稳定；用「中位 ± 容差」判断，并输出结论。
 *
 * 默认 headless、独立端口、不弹窗；只写 v2/qa/tools/variance-brushes.json。
 * 用法：node v2/qa/tools/variance-brushes.mjs [--rounds 5]
 */
import { spawn } from 'node:child_process';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const QA = path.resolve(__dirname, '..');
const REPO = path.resolve(QA, '..', '..');
const require = createRequire(import.meta.url);
const argv = process.argv.slice(2);
const argOf = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? argv[i + 1] : d; };
const ROUNDS = Number(argOf('--rounds', 5));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const OUT_FILE = path.join(__dirname, 'variance-brushes.json');

const S1 = (() => { const a = []; for (let i = 0; i <= 40; i += 1) { const t = i / 40; a.push([0.12 + 0.76 * t, 0.5 + 0.28 * Math.sin(t * Math.PI * 2)]); } return a; })();
const HELPERS = `
window.__VAR__ = {
  async grab() { const e = window.__V2__ || (window.__BRUSH_DEMO__ && window.__BRUSH_DEMO__.engine); if (!e) return null; if (e.compositor && e.store) e.compositor.compositeAll(e.store); return await e.getCompositeDataUrl(); },
  async load(src) { try { const img = new Image(); img.src = src; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const x = c.getContext('2d'); x.drawImage(img, 0, 0); return { w: c.width, h: c.height, d: x.getImageData(0, 0, c.width, c.height).data }; } catch (e) { return null; } },
  async stats(curUrl, refUrl, points) {
    const cur = await this.load(curUrl); const ref = refUrl ? await this.load(refUrl) : null;
    if (!cur) return { decodeFailed: true };
    const W = cur.w, H = cur.h; const centers = [];
    for (let s = 0; s < 12; s += 1) { const t = (s + 0.5) / 12; const fi = Math.min(points.length - 1, t * (points.length - 1)); const i0 = Math.floor(fi), i1 = Math.min(points.length - 1, i0 + 1), f = fi - i0; const px = points[i0][0] + (points[i1][0] - points[i0][0]) * f; const py = points[i0][1] + (points[i1][1] - points[i0][1]) * f; const r = Math.max(8, Math.min(44, Math.round(Math.min(W, H) * 0.05))); centers.push({ x: Math.round(px * W), y: Math.round(py * H), r }); }
    let ink = 0; const seg = new Array(12).fill(0); const samples = new Array(12).fill(0);
    for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) {
      const i = (y * W + x) * 4; const bg = cur.d[i] < 34 && cur.d[i + 1] < 36 && cur.d[i + 2] < 42;
      const isInk = !bg && ref && ref.w === W && ref.h === H && (Math.abs(cur.d[i] - ref.d[i]) > 24 || Math.abs(cur.d[i + 1] - ref.d[i + 1]) > 24 || Math.abs(cur.d[i + 2] - ref.d[i + 2]) > 24);
      if (!isInk) continue; ink += 1;
      for (let s = 0; s < 12; s += 1) { const c0 = centers[s]; samples[s] += 1; if (Math.abs(x - c0.x) <= c0.r && Math.abs(y - c0.y) <= c0.r) seg[s] += 1; }
    }
    const dens = seg.map((v, s) => (samples[s] ? v / samples[s] : 0));
    const covered = dens.filter((v) => v > 0.01).length;
    const mean = dens.reduce((a, b) => a + b, 0) / dens.length;
    const sd = Math.sqrt(dens.reduce((a, b) => a + (b - mean) * (b - mean), 0) / dens.length);
    return { ink, breakpoints: 12 - covered, thicknessCV: mean > 0 ? Math.round((sd / mean) * 1000) / 1000 : null };
  },
};`;

function median(a) { const s = [...a].sort((x, y) => x - y); const m = Math.floor(s.length / 2); return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; }
function std(a) { const m = a.reduce((x, y) => x + y, 0) / a.length; return Math.sqrt(a.reduce((x, y) => x + (y - m) ** 2, 0) / a.length); }

async function startServer() {
  const portFile = path.join(REPO, 'v2', '.runtime-port');
  await fsp.rm(portFile, { force: true }).catch(() => {});
  const proc = spawn(process.execPath, [path.join(REPO, 'v2', 'serve.mjs')], { cwd: REPO, env: { ...process.env, PORT: '4265' }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  for (let i = 0; i < 120; i += 1) {
    await sleep(150);
    try { const p = Number(String(await fsp.readFile(portFile, 'utf8')).trim()); const r = await fetch(`http://127.0.0.1:${p}/v2/brushes/demo.html`); if (r.ok) return { origin: `http://127.0.0.1:${p}`, proc }; } catch { /* wait */ }
  }
  throw new Error('无法启动静态服务');
}

async function main() {
  const { chromium } = require('playwright-core');
  const srv = await startServer();
  const browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--window-size=1600,1000', '--window-position=-3000,-3000'] });
  const result = { schema: 'mozheng.variance.v1', at: new Date().toISOString(), headless: true, target: 'ours-brushes', scenario: 'S1 慢速 S 形', rounds: [], summary: null };
  try {
    const ctx = await browser.newContext({ viewport: { width: 1532, height: 791 }, deviceScaleFactor: 1 });
    for (let round = 1; round <= ROUNDS; round += 1) {
      const page = await ctx.newPage();
      page.setDefaultTimeout(90000);
      try {
        await page.goto(`${srv.origin}/v2/brushes/demo.html`, { waitUntil: 'load' });
        await page.evaluate(`(() => { try { localStorage.clear(); sessionStorage.clear(); } catch (e) {} })()`).catch(() => {});
        await page.reload({ waitUntil: 'load' }).catch(() => {});
        await page.waitForFunction('window.__BRUSH_READY__ === true', { timeout: 60000 }).catch(() => {});
        await page.waitForTimeout(1200);
        await page.evaluate(HELPERS);
        const rect = await page.evaluate(`(() => { const c = [...document.querySelectorAll('canvas')].map((c) => { const r = c.getBoundingClientRect(); return { id: c.id, x: r.x, y: r.y, cw: r.width, ch: r.height }; }).filter((c) => c.cw > 50).sort((a, b) => b.cw * b.ch - a.cw * a.ch)[0]; return c || null; })()`);
        const x = (f) => Math.round(rect.x + rect.cw * f); const y = (f) => Math.round(rect.y + rect.ch * f);
        const undoAll = () => page.evaluate(`(() => { const e = window.__V2__; let g = 0; while (e && e.canUndo && e.canUndo() && g < 400) { e.undo(); g += 1; } if (e && e.compositor) e.compositor.compositeAll(e.store); return g; })()`).catch(() => {});
        await undoAll(); await page.waitForTimeout(300);
        const ref = await page.evaluate('window.__VAR__.grab()');
        await page.mouse.move(x(S1[0][0]), y(S1[0][1]));
        await page.mouse.down();
        for (let i = 1; i < S1.length; i += 1) { await page.mouse.move(x(S1[i][0]), y(S1[i][1])); await sleep(12); }
        await page.mouse.up();
        await page.waitForTimeout(350);
        const cur = await page.evaluate('window.__VAR__.grab()');
        const st = await page.evaluate((a) => window.__VAR__.stats(a.cur, a.ref, a.points), { cur, ref, points: S1 });
        const frames = [];
        for (const t of [0, 16, 50, 200]) { if (t) await sleep(20); const u = await page.evaluate('window.__VAR__.grab()'); const s2 = await page.evaluate((a) => window.__VAR__.stats(a.cur, a.ref, a.points), { cur: u, ref, points: S1 }); frames.push({ t, ink: s2.ink }); }
        result.rounds.push({ round, canvas: rect, final: st, frames, bufMtime: new Date().toISOString() });
        console.log(`[variance] round ${round}: ink=${st.ink} bp=${st.breakpoints} cv=${st.thicknessCV} frames=${frames.map((f) => f.ink).join('/')}`);
      } catch (e) {
        result.rounds.push({ round, error: String(e && (e.message || e)) });
        console.log(`[variance] round ${round}: ERROR ${String(e && e.message || e).slice(0, 120)}`);
      } finally { await page.close().catch(() => {}); }
    }
    const inks = result.rounds.map((r) => r.final?.ink).filter((v) => typeof v === 'number');
    const bps = result.rounds.map((r) => r.final?.breakpoints).filter((v) => typeof v === 'number');
    const cvs = result.rounds.map((r) => r.final?.thicknessCV).filter((v) => typeof v === 'number');
    const med = inks.length ? median(inks) : null;
    const sd = inks.length > 1 ? std(inks) : 0;
    const cvPct = med ? Math.round((sd / med) * 1000) / 10 : null;
    const pctRange = med ? Math.round(((Math.max(...inks) - Math.min(...inks)) / med) * 1000) / 10 : null;
    const framesStable = result.rounds.every((r) => (r.frames || []).every((f) => f.ink === r.frames[0].ink));
    const verdict = {
      n: inks.length,
      inkMedian: med, inkSd: Math.round(sd * 10) / 10, inkCvPercent: cvPct, inkRangePercentOfMedian: pctRange,
      breakpointsAllEqual: bps.length > 0 && new Set(bps).size === 1,
      framesStable,
      toleranceUsed: '中位 ± 25%（GATE 口径：结构指标为门槛，ink 波动仅记录）',
      conclusion: null,
    };
    if (pvOk(verdict)) verdict.conclusion = '噪声（同结构、帧稳定、ink 离散在 ±25% 内），不是白板/掉帧；阈值口径保持「结构门槛 + ink 记录」';
    else if (verdict.breakpointsAllEqual && framesStable) verdict.conclusion = 'ink 波动超 ±25% 但结构/帧全稳定 → 判定为模拟压感/输入时序噪声（非渲染缺陷）；建议 GATE 门槛用结构指标，ink 记中位±容差';
    else verdict.conclusion = '存在结构/帧不稳定 → 转 tech/brush 排查（附 5 轮 JSON）';
    result.summary = verdict;
    await fsp.writeFile(OUT_FILE, JSON.stringify(result, null, 2), 'utf8');
    console.log('[variance] 汇总：' + JSON.stringify(verdict));
  } finally {
    await browser.close().catch(() => {});
    try { srv.proc.kill(); } catch { /* ignore */ }
    await fsp.rm(path.join(REPO, 'v2', '.runtime-port'), { force: true }).catch(() => {});
  }
}
function pvOk(v) { return v.breakpointsAllEqual && v.framesStable && v.inkCvPercent != null && v.inkCvPercent <= 25; }

main().catch((e) => { console.error('variance 失败：', e.stack || e); process.exit(2); });
