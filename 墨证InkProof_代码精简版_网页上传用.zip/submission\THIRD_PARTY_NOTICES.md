# 第三方声明索引 · 墨证 InkProof

本文件由 hackathon/package-submission.mjs 生成，汇总本包内实际存在的 THIRD_PARTY_NOTICES 文件。
项目自身源码许可见 LICENSE（MIT）。

## 关键组件许可速查

| 组件 | 许可 | 声明位置 |
|---|---|---|
| CanvasKit / Skia（canvaskit-wasm 0.42.0） | BSD-3-Clause | v2/engine/vendor/THIRD_PARTY_NOTICES.md、v2/engine/vendor/LICENSE |
| ag-psd（28.3.1，含 pako / base64-js） | MIT | v2/psd/THIRD_PARTY_NOTICES.md |
| perfect-freehand（1.2.3） | MIT | v2/brushes/THIRD_PARTY_NOTICES.md |
| Klecks（参考实现） | MIT | v2/engine/vendor/THIRD_PARTY_NOTICES.md、v2/qa/THIRD_PARTY_NOTICES.md |
| playwright-core（仅 QA 测试期，不进产品运行时） | Apache-2.0 | v2/qa/THIRD_PARTY_NOTICES.md |

> 注：旧版 README 曾把 CanvasKit 误写为 Apache-2.0，实际为 BSD-3-Clause（见 v2/engine/vendor/THIRD_PARTY_NOTICES.md 第 9 行）。
> GPL 项目（Krita / Krita AI Diffusion / ComfyUI / Fooocus / GIMP）仅作交互与工作流参考，未复制代码。

## 包内 NOTICES 文件清单（动态扫描，共 4 处）

| 路径 | 说明 |
|---|---|
| v2/brushes/THIRD_PARTY_NOTICES.md | 见该文件 |
| v2/engine/vendor/THIRD_PARTY_NOTICES.md | 见该文件 |
| v2/psd/THIRD_PARTY_NOTICES.md | 见该文件 |
| v2/qa/THIRD_PARTY_NOTICES.md | 见该文件 |
