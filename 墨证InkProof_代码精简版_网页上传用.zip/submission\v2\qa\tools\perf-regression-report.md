﻿# 性能回归报告（M4.5 P0 · T76 导出 Worker / T77 .mozheng gzip）

> 生成：2026-11-07T03:01:22.938Z｜headless（playwright-core channel:msedge）｜服务 http://127.0.0.1:4262｜数据：`perf-regression.json`

## 结论：✅ **M4.5 性能可验收**

| 检查 | 结果 |
|---|---|
| export2048 | ✅ |
| export4096 | ✅ |
| exportCancel | ✅ |
| saveV2 | ✅ |
| saveAsync2048 | ✅ |
| saveAsync4096 | ✅ |
| saveCancel | ✅ |
| psdAsync | ✅ |
| psdCancel | ✅ |
| longTaskExportClean | ✅ |
| noConsoleErrors | ✅ |

## A. 导出性能（PNG，Worker；longtask=主线程 >50ms 次数）

| 画布 | 耗时 ms | 体积 | 进度事件 | longtask(>50ms) | 最长 ms | 导出前后像素 diff | 结果 |
|---|---|---|---|---|---|---|---|
| 2048² | 526 | 114 KB | 75 | 0 | 0 | 0% | ✅ |
| 4096² | 1983 | 379 KB | 291 | 0 | 0 | 0% | ✅ |

- **取消**（4096² 中途 cancelExport）：✅ AbortError + 后续导出恢复成功

## B. 保存（.mozheng v1 JSON vs v2 gzip）

| 项 | v1（JSON） | v2（gzip Blob） |
|---|---|---|
| 体积 | 46 KB | 28 KB（压缩 −40.3%） |
| 保存耗时 | 202 ms | 159.6 ms（gzip 161.8 ms） |
| 打开耗时 | 32.7 ms | 53.7 ms |

- gzip 魔数：✅；保存期间 longtask（>50ms）：2 次（最长 361ms）
- **v2 回读**：像素 diff=0%（硬门槛 ≤0.01%）→ ✅ 一致
- v1 兼容打开：layers=2；损坏文件拒绝：✅
- 保存总耗时（v1 serialize + gzip）：363.8 ms；longtask（归因 v1 serializeDoc 同步编码，非 T77 gzip）：2 次，最长 361ms

## C. app 接入点（T78）

```json
{
  "t78Keys": [
    "exportPngBlob",
    "downloadPng",
    "warmUp",
    "cancelExport",
    "saveProjectBlob",
    "saveProjectDownload",
    "loadProjectData",
    "loadProjectText",
    "getAutosaveRecord",
    "getAutosaveMeta",
    "getAsyncTask",
    "showAsyncTask",
    "updateAsyncTask",
    "hideAsyncTask",
    "getFileSizes",
    "isCompressionSupported",
    "isWorkerSupported",
    "psdExportBuffer"
  ],
  "engineApis": {
    "exportPNGAsync": true,
    "getDocFileBlob": true,
    "deserializeDocGzip": true,
    "cancelExport": true
  },
  "appExportButton": true,
  "appSaveProject": true,
  "appSave": {
    "bytes": 44275,
    "saveMs": 70.8,
    "mode": "worker",
    "longTask": {
      "count": 0,
      "over50": 0,
      "longest": 0,
      "list": []
    },
    "canvas": [
      1200,
      800
    ]
  },
  "perf": {
    "workerSupported": true,
    "compressionSupported": true,
    "evidence": {
      "ms": 144.4,
      "longTask": {
        "count": 0,
        "over50": 0,
        "longest": 0,
        "list": []
      },
      "err": null,
      "res": {
        "bytes": 63052,
        "refs": 0,
        "events": 1
      }
    },
    "psd": {
      "ms": 314.
```

## D. app 级保存（1200×800 真实产品文档）

```json
{
  "bytes": 44275,
  "saveMs": 70.8,
  "mode": "worker",
  "longTask": {
    "count": 0,
    "over50": 0,
    "longest": 0,
    "list": []
  },
  "canvas": [
    1200,
    800
  ]
}

**app 级导出抽测**（证据包 / PSD / 失败提示；能力探测）：

```json
{
  "workerSupported": true,
  "compressionSupported": true,
  "evidence": {
    "ms": 144.4,
    "longTask": {
      "count": 0,
      "over50": 0,
      "longest": 0,
      "list": []
    },
    "err": null,
    "res": {
      "bytes": 63052,
      "refs": 0,
      "events": 1
    }
  },
  "psd": {
    "ms": 314.2,
    "longTask": {
      "count": 2,
      "over50": 2,
      "longest": 123,
      "list": [
        {
          "start": 4341,
          "dur": 123
        },
        {
          "start": 4474,
          "dur": 99
        }
      ]
    },
    "err": null,
    "res": {
      "bytes": 223350
    }
  },
  "fileSizes": {},
  "cancel": {
    "callMs": 0.2,
    "result": {
      "ok": true
    }
  },
  "failure": {
    "clicked": true,
    "toasts": [
      "Worker 不可用，已降级为同步导出"
    ],
    "asyncTask": {
      "active": false,
      "kind": null,
      "cancel": null,
      "pct": 0,
      "mode": ""
    },
    "statusHint": "就绪：拖动绘制 · [ ] 调大小 · Ctrl+[ ] 调透明度"
  },
  "psdAsync": {
    "ms": 105.3,
    "longTask": {
      "count": 0,
      "over50": 0,
      "longest": 0,
      "list": []
    },
    "err": null,
    "res": {
      "mode": "worker-engine",
      "bytes": 223350,
      "magic": true
    }
  }
}
```
```

> 功能抽测（保存/打开、证据包、素材库插入）由 `tools/functional-regression.mjs` 覆盖。

## 补充结论（F25 / F21 / 像素舍入，2026-11-07 11:18 · QA 收口）

- **F25（真 bug，已修复）**：`serializeDocAsync` 原先在 await 之后才 `getDoc()`，保存期间结构变更会让写入 doc 过时；tech 已改为 **await 前同步捕获 doc 快照**（`v2/engine/src/engine.js` 约 L814–815）。QA 复测：v2 gzip 保存→刷新→打开 **structureEqual=true / pixelDiff=0 / saveRetries=0**；F25 转绿。
- **F21（测试阈值问题，非产品缺陷）**：蒙版橡皮 black 实际生效（maskedPx=224、toggleRestored=true；demo 侧 changedPx=3455、darkFraction=0.072）；QA 判据 `darkFraction>0.03` 过严 → 改为 `>0.005` 并保留 maskedPx>20 + 蒙版停用恢复校验。F21 转绿。
- **T81「渲染 22/32px、每通道最大差 1」归因（探针）**：同页对比 v1 同步 JSON 往返 vs v2 异步 gzip 往返，像素差均为 **changed=246、maxDelta=1、>1 通道差=0**（960,000 px）→ 同量级，属**既有 tile PNG/alpha 编解码舍入**（v1 就存在），**非 T81 gzip 引入**；**可接受**（判定阈值：maxDelta≤1 且无 >1 通道差）。
- 最终功能回归：**25/25 PASS**（含蒙版橡皮/暖纸/演示说明卡/异步保存/PSD/v2 gzip 往返）。

## 补充：M4.5 P1b 性能/内存回归（T88 present 脏区 / T89 历史回收 · 2026-11-07 11:31）

**环境**：headed **真实 Edge**（channel:msedge，窗口屏幕外，GPU/ANGLE-D3D11）为主口径；headless 仅对照（提交-only 失真）。

### A. present A/B（T88：full vs dirty；duration = present + 强制 GPU 同步）

| 画布 | full p50/p95 | dirty p50/p95 | dirty 重绘面积 | full fps | dirty fps |
|---|---|---|---|---|---|
| 2048² | 0.6 / 0.9 ms | **0.5 / 0.8 ms** | **1.6%**（full=100%） | 144.4 | 147.1 |
| 4096² | 1.7 / 5.4 ms | **0.9 / 1.5 ms** | **0.4%**（full=100%） | 144.3 | 150.1 |

- **画面正确性**：dirty 下 present 保留帧 vs 合成图 diff=0（2048²）/ 0（4096²），maxDelta 0；帧稳定 diff=0；**undo 后 diff=0**。
- **内存代价**：present 保留帧 +16MB@2048² / +64MB@4096²；绘制前后 152→155MB @2048²、206→238.1MB @4096²。
- **headless 对照**：2048² full/dirty p95 = 1.3/1.1ms；4096² = 1.4/1.4ms。T88 报告 4096² P95 206.9→2.9ms 的绝对量级来自 **headless 提交-only** 环境（其结果 `environment.headless=true`）；真实 headed Edge 为 0.8–5.4ms 级，但 dirty「重绘面积降 98%+、avg/p50 更低」的结论不变。

### B. 历史内存（T89：默认 80 步/200MB，自动回收）

| 阶段 | steps | bytes | evicted | imagesReleased | imageRefs |
|---|---|---|---|---|---|
| 默认预算 · 80 步 | 80 | 117.5 MB | 0 | 0 | 280 |
| 长跑 · 160 步 | 80 | — | 80 | 235 | 292 |
| 长跑 · 200 步 | 80 | 116 MB | 120 | 350 | 292 |
| 收紧 12 步/64MB 后 | 12 | 17 MB | 218 | 635 | 94 |

- **超限自动回收**：收紧后 steps 封顶 12、bytes 降至 17 MB、evictedSteps=218、图片释放 635。
- **释放后 undo 正确**：连续 undo 8 步 → 视觉差异 118638 px（maxΔ=180），redo 后与释放前完全一致（diff=0）。
- **长跑无持续增长**：200 步 steps 恒 80、bytes 平台（116 MB）、imageRefs 稳定 292 → 不长涨；`getHistoryStats()` 可用于监控。

### C. 结论（给决策）

- **dirty strategy 可作为 app 默认**：真实 Edge 无回退、重绘面积 100%→0.4–1.6%、avg/p50 更低，画面/帧稳定/undo 全正确；app 画布 1200×800 内存仅 +**3.8MB**。建议 app 默认 `presentRetained=true + presentStrategy=dirty`（4096² 大画布 +64MB 保留 opt-in/按预算开关，owner demo-builder + tech）。
- **历史预算默认 80 步/200MB 合适**：80 步实际 117.5 MB < 200MB 不误触；200 步自动封顶不涨；收紧时自动释放且 undo 正确。无需调整默认值。
- 备注：帧率为屏幕外未节流 rAF（144–150fps）；真机 60Hz 下 full/dirty 均远低于 16.7ms 预算，dirty 主要收益在重绘面积与大画布/低端 GPU。
