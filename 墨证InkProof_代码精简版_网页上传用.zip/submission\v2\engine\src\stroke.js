/**
 * v2 engine · 笔触事务（IStroke 实现）· T41 注入点版
 *
 * - begin → append（每帧批量，含 coalesced 点）→ end：提交到受影响 tile + 生成 undo patch
 * - 实时反馈：engine 在主 surface 上直接画 stamp（1 帧内可见）；end 时由 tile 快照重合成
 * - 笔刷：不再写死 hard/soft；由 StrokePaintProvider 注入（默认 engine-default 实现 hard/soft）
 *
 * Provider 接口见 `brush-provider.js`；ctx 透传：
 *   pressure / tiltX / tiltY / velocity / timestamp / elapsed / distance / index /
 *   coalescedIndex / coalescedCount / pointerType / worldX,worldY / isTile,tileX,tileY
 */
import { createDefaultBrushProvider } from './brush-provider.js';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export class Stroke {
  /**
   * @param {any} CK
   * @param {import('./tile-store.js').TileStore} store
   * @param {string} layerId
   * @param {{type:string,sizePx:number,opacity?:number}} brush
   * @param {any} firstPoint
   * @param {{provider?:any}} [opts]
   */
  constructor(CK, store, layerId, brush, firstPoint, opts = {}) {
    this.CK = CK;
    this.store = store;
    this.layerId = layerId;
    this.brush = {
      type: brush && brush.type ? brush.type : 'soft',
      sizePx: brush && brush.sizePx ? brush.sizePx : 64,
      opacity: brush && brush.opacity != null ? brush.opacity : 1,
    };
    const provider = opts && opts.provider;
    this.provider = provider && typeof provider.radiusFor === 'function' ? provider : createDefaultBrushProvider();
    this.points = [firstPoint];
    /** @type {any[]} 每个点的完整上下文（含 radius/velocity/coalesced 等） */
    this.records = [];
    this.affected = new Set();
    this._startTs = Number.isFinite(firstPoint.timestamp) ? firstPoint.timestamp : performance.now();
    this._last = null;
    this._distance = 0;
    this._cancelled = false;
    if (typeof this.provider.begin === 'function') {
      this.provider.begin(this.strokeCtx());
    }
    this._record(firstPoint, { coalescedIndex: 0, coalescedCount: 1 });
  }

  /** 一次笔触的顶层上下文（begin/end 回调使用） */
  strokeCtx() {
    return {
      CK: this.CK,
      provider: this.provider,
      brush: this.brush,
      layerId: this.layerId,
      points: this.points,
      startTs: this._startTs,
      distance: this._distance,
      cancelled: this._cancelled,
    };
  }

  _record(p, opts) {
    const timestamp = Number.isFinite(p.timestamp) ? p.timestamp : performance.now();
    let dist = 0;
    let velocity = 0;
    if (this._last) {
      const dx = p.x - this._last.x;
      const dy = p.y - this._last.y;
      dist = Math.hypot(dx, dy);
      const dt = Math.max(0, timestamp - this._last.timestamp);
      velocity = dt > 0 ? dist / dt : 0;
      this._distance += dist;
    }
    this._last = { x: p.x, y: p.y, timestamp };
    const pressure = p.pressure == null ? 0.5 : clamp(p.pressure, 0, 1);
    const ctx = {
      CK: this.CK,
      provider: this.provider,
      brush: this.brush,
      layerId: this.layerId,
      canvas: null,
      x: p.x,
      y: p.y,
      worldX: p.x,
      worldY: p.y,
      pressure,
      tiltX: p.tiltX || 0,
      tiltY: p.tiltY || 0,
      velocity,
      distance: this._distance,
      timestamp,
      elapsed: timestamp - this._startTs,
      index: this.points.length - 1,
      coalescedIndex: opts && opts.coalescedIndex != null ? opts.coalescedIndex : this.points.length - 1,
      coalescedCount: opts && opts.coalescedCount != null ? opts.coalescedCount : 1,
      pointerType: p.pointerType || 'synthetic',
      isTile: false,
      tileX: 0,
      tileY: 0,
      radius: 0,
      paint: null,
    };
    ctx.radius = Math.max(0.5, Number(this.provider.radiusFor(ctx)) || 0.5);
    this.records.push(ctx);
    this._addAffected(ctx);
    return ctx;
  }

  _addAffected(ctx) {
    const r = ctx.radius;
    const tx0 = Math.max(0, Math.floor((ctx.worldX - r) / this.store.tileSize));
    const ty0 = Math.max(0, Math.floor((ctx.worldY - r) / this.store.tileSize));
    const tx1 = Math.min(this.store.tilesW - 1, Math.floor((ctx.worldX + r) / this.store.tileSize));
    const ty1 = Math.min(this.store.tilesH - 1, Math.floor((ctx.worldY + r) / this.store.tileSize));
    for (let ty = ty0; ty <= ty1; ty += 1) {
      for (let tx = tx0; tx <= tx1; tx += 1) this.affected.add(`${tx},${ty}`);
    }
  }

  /** 对给定 canvas 执行 provider.paintFor + provider.stampFor（缺省画圆） */
  _paintAndStamp(ctx) {
    const provider = this.provider;
    if (typeof provider.paintFor === 'function') {
      ctx.paint = provider.paintFor(ctx) || null;
    }
    if (typeof provider.stampFor === 'function') {
      provider.stampFor(ctx);
    } else if (ctx.paint) {
      ctx.canvas.drawCircle(ctx.x, ctx.y, ctx.radius, ctx.paint);
    }
  }

  /** 每帧的实时 stamp（主 surface 绝对坐标） */
  stampLive(canvas) {
    const rec = this.records[this.records.length - 1];
    if (!rec) return;
    const ctx = Object.assign({}, rec, {
      canvas,
      x: rec.worldX,
      y: rec.worldY,
      isTile: false,
      tileX: 0,
      tileY: 0,
      paint: null,
    });
    this._paintAndStamp(ctx);
  }

  append(p, opts = {}) {
    this.points.push(p);
    this._record(p, opts);
  }

  /** T44：把最新点画到指定 canvas（实时预览层 / 离屏合成），不直接画 on-screen framebuffer */
  stampTo(canvas) {
    const rec = this.records[this.records.length - 1];
    if (!rec) return;
    const ctx = Object.assign({}, rec, {
      canvas,
      x: rec.worldX,
      y: rec.worldY,
      isTile: false,
      tileX: 0,
      tileY: 0,
      paint: null,
    });
    this._paintAndStamp(ctx);
  }

  /** 兼容旧调用（T36 子类曾使用）：返回按 provider 计算的半径 */
  radiusFor(p) {
    const rec = this.records[this.records.length - 1];
    const ctx = Object.assign({}, rec || this.strokeCtx(), {
      worldX: p.x, worldY: p.y, x: p.x, y: p.y, pressure: p.pressure == null ? 0.5 : clamp(p.pressure, 0, 1),
      radius: 0, paint: null,
    });
    return Math.max(0.5, Number(this.provider.radiusFor(ctx)) || 0.5);
  }

  /** 兼容旧调用：按 provider 返回 paint（调用方负责不释放缓存 paint） */
  paintFor(p) {
    const rec = this.records[this.records.length - 1];
    const ctx = Object.assign({}, rec || this.strokeCtx(), {
      worldX: p.x, worldY: p.y, x: p.x, y: p.y, pressure: p.pressure == null ? 0.5 : clamp(p.pressure, 0, 1),
      radius: this.radiusFor(p), paint: null,
    });
    return typeof this.provider.paintFor === 'function' ? this.provider.paintFor(ctx) : null;
  }

  /**
   * 提交笔迹：写入受影响 tile（before/after 快照 + patch）。
   * @returns {{entry:any, dirtyKeys:string[]}}
   */
  commit() {
    if (typeof this.provider.end === 'function') {
      this.provider.end(this.strokeCtx());
    }
    const store = this.store;
    const patches = [];
    const dirtyKeys = [...this.affected];
    for (const key of dirtyKeys) {
      const tile = store.ensureTile(this.layerId, key);
      const before = store.captureBefore(this.layerId, key);
      const { tx, ty } = store.keyXY(key);
      const surface = tile.surface;
      const c = surface.getCanvas();
      c.save();
      for (const rec of this.records) {
        const lx = rec.worldX - tx * store.tileSize;
        const ly = rec.worldY - ty * store.tileSize;
        const r = rec.radius;
        if (lx + r < 0 || ly + r < 0 || lx - r > store.tileSize || ly - r > store.tileSize) continue;
        const ctx = Object.assign({}, rec, {
          canvas: c,
          x: lx,
          y: ly,
          isTile: true,
          tileX: tx,
          tileY: ty,
          paint: null,
        });
        this._paintAndStamp(ctx);
      }
      c.restore();
      surface.flush();
      const after = surface.makeImageSnapshot();
      tile.image = after;
      patches.push({ key, before, after });
    }
    const entry = {
      id: `stroke-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      strokeId: entryIdSafe(),
      layerId: this.layerId,
      patches,
      points: this.points.length,
    };
    return { entry, dirtyKeys };
  }

  /** 取消：不写 tile / 不生成 undo；通知 provider（cancel 优先，否则 end({cancelled:true})） */
  cancel() {
    this._cancelled = true;
    const ctx = Object.assign(this.strokeCtx(), { cancelled: true });
    if (typeof this.provider.cancel === 'function') this.provider.cancel(ctx);
    else if (typeof this.provider.end === 'function') this.provider.end(ctx);
  }

  dispose() {
    this.points = [];
    this.records = [];
    this.affected.clear();
  }
}

let strokeCounter = 0;
function entryIdSafe() {
  strokeCounter += 1;
  return `s${Date.now().toString(36)}-${strokeCounter}`;
}
