#!/usr/bin/env node
/**
 * v2/qa/tools/functional-regression.mjs — T60–T65 功能回归（QA 独立，Playwright-core，headless）
 *
 * 覆盖（用户/Lead 指定）：
 *   F1 图层：组 / 蒙版 / 剪贴 / 16 混合模式
 *   F2 项目保存/打开：.mozheng 保存 → 刷新 → 打开（结构图层树 + 像素 hash/diff 双对比）
 *   F3 自动保存恢复：绘制 → 等自动保存 → 刷新 → 结构+像素恢复
 *   F4 PSD 导出→导入保真（字节/图层组数 + 像素 diff）
 *   F5 涂抹：在已有墨迹上断言像素变化
 *   F6 选区约束：选区外绘制不改变像素
 *   F7 变换提交（1 步 undo）→ undo 像素还原
 *   F8 结构操作 undo/redo（新建/复制图层）
 *   F9 Alpha Lock：锁定时空白区域绘制不改变像素，解锁后改变
 *
 * 独立端口（默认 4260+）、headless、不弹窗、跑完杀进程。
 * 输出：tools/functional-regression.json + tools/functional-regression-report.md
 */
import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const QA = path.resolve(__dirname, '..');
const REPO = path.resolve(QA, '..', '..');
const require = createRequire(import.meta.url);
const argv = process.argv.slice(2);
const argOf = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? argv[i + 1] : d; };
const PORT = Number(argOf('--port', 4260));
const OUT = path.join(__dirname, 'functional-regression.json');
const REPORT = path.join(__dirname, 'functional-regression-report.md');
const SHOTS = path.join(__dirname, 'shots');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function sha(b64) { return crypto.createHash('sha256').update(Buffer.from(b64, 'base64')).digest('hex').slice(0, 16); }

async function startServer() {
  const portFile = path.join(REPO, 'v2', '.runtime-port');
  await fsp.rm(portFile, { force: true }).catch(() => {});
  const proc = spawn(process.execPath, [path.join(REPO, 'v2', 'serve.mjs')], { cwd: REPO, env: { ...process.env, PORT: String(PORT) }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  for (let i = 0; i < 120; i += 1) {
    await sleep(150);
    try { const p = Number(String(await fsp.readFile(portFile, 'utf8')).trim()); const r = await fetch(`http://127.0.0.1:${p}/v2/app/index.html`); if (r.ok) return { origin: `http://127.0.0.1:${p}`, proc }; } catch { /* wait */ }
  }
  throw new Error('无法启动静态服务');
}

/** 页面内：合成图 → dataURL（同 task 内 compositeAll）*/
const GRAB = `(async () => { const e = window.__V2_APP__.engine; e.compositor.compositeAll(e.store); return await e.getCompositeDataUrl(); })()`;
/** 页面内：两张合成图做像素 diff（返回 changed/total） */
async function pageDiff({ a, b }) {
  const load = async (src) => { const img = new Image(); img.src = src; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const x = c.getContext('2d'); x.drawImage(img, 0, 0); return { w: c.width, h: c.height, d: x.getImageData(0, 0, c.width, c.height).data }; };
  const A = await load(a), B = await load(b);
  if (A.w !== B.w || A.h !== B.h) return { changed: -1, total: A.w * A.h, sizeMismatch: true };
  let changed = 0; let minX = 1e9, minY = 1e9, maxX = -1, maxY = -1;
  for (let y = 0; y < A.h; y += 1) for (let x = 0; x < A.w; x += 1) {
    const i = (y * A.w + x) * 4;
    if (Math.abs(A.d[i] - B.d[i]) > 10 || Math.abs(A.d[i + 1] - B.d[i + 1]) > 10 || Math.abs(A.d[i + 2] - B.d[i + 2]) > 10) {
      changed++; if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y;
    }
  }
  return { changed, total: A.w * A.h, ratio: Math.round((changed / (A.w * A.h)) * 10000) / 100, bbox: changed ? { minX, minY, maxX, maxY } : null };
}

async function main() {
  const { chromium } = require('playwright-core');
  await fsp.mkdir(SHOTS, { recursive: true });
  const srv = await startServer();
  const browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--window-size=1600,1000', '--window-position=-3000,-3000'] });
  const report = { schema: 'mozheng.functional-regression.v1', at: new Date().toISOString(), headless: true, origin: srv.origin, cases: [], errors: [], pass: false };
  const ctx = await browser.newContext({ viewport: { width: 1532, height: 791 }, deviceScaleFactor: 1, acceptDownloads: true });
  const page = await ctx.newPage();
  page.setDefaultTimeout(60000);
  const consoleErrors = [];
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 300)); });
  page.on('pageerror', (e) => consoleErrors.push(String(e.message || e).slice(0, 300)));

  const ev = (fn, arg) => page.evaluate(fn, arg);
  const load = async () => {
    await page.goto(`${srv.origin}/v2/app/index.html`, { waitUntil: 'load' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', { timeout: 60000 }).catch(() => {});
    await page.waitForTimeout(1200);
  };
  const box = async () => ev(`(() => { const r = document.getElementById('mainCanvas').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
  const drawLine = async (fx0, fy0, fx1, fy1, steps = 8) => {
    const b = await box();
    await page.mouse.move(b.x + b.w * fx0, b.y + b.h * fy0);
    await page.mouse.down();
    for (let i = 1; i <= steps; i += 1) await page.mouse.move(b.x + b.w * (fx0 + (fx1 - fx0) * i / steps), b.y + b.h * (fy0 + (fy1 - fy0) * i / steps));
    await page.mouse.up();
    await page.waitForTimeout(350);
  };
  const grab = () => ev(GRAB);
  const diff = (a, b) => page.evaluate(pageDiff, { a, b });
  const addCase = (id, pass, detail) => { report.cases.push({ id, pass: !!pass, detail }); console.log(`[func] ${pass ? 'PASS' : 'FAIL'} ${id} ${JSON.stringify(detail).slice(0, 220)}`); };
  const resetApp = async () => {
    await page.evaluate(`(() => { try { localStorage.clear(); } catch (e) {} try { indexedDB.deleteDatabase('mozheng.v2.projects'); } catch (e) {} })()`).catch(() => {});
    await load();
  };

  try {
    // ============ 准备：干净页面 ============
    await load();
    await resetApp();

    // ============ F1 图层：组/蒙版/剪贴/16 混合 ============
    const f1 = await ev(`(async () => {
      const app = window.__V2_APP__, t = app.t61, engine = app.engine;
      const g = t.addGroup();
      t.addLayer();
      const ls = engine.getLayers();
      const layer = ls[ls.length - 1];
      const group = (engine.getDoc().groups || [])[0] || g;
      t.assignLayerToGroup(layer.id, group.id);
      const modes = ['normal','multiply','screen','overlay','soft-light','darken','lighten','color-dodge','color-burn','hard-light','difference','exclusion','hue','saturation','color','luminosity'];
      const applied = [];
      for (const m of modes) { const ok = engine.setLayerBlend(layer.id, m); applied.push({ m, ok: ok !== false, got: (engine.getLayers().find((x) => x.id === layer.id) || {}).blend }); }
      engine.setLayerClip(layer.id, true);
      engine.addMask(layer.id);
      engine.setMaskEnabled(layer.id, true);
      t.renderLayers();
      const doc = engine.getDoc();
      const L = engine.getLayers().find((x) => x.id === layer.id);
      return { groups: doc.groups.length, blendOk: applied.filter((a) => a.ok).length, blendTotal: modes.length,
        blendValue: L.blend, clip: !!L.clip, mask: !!(L.mask && L.mask.exists), grouped: !!L.group };
    })()`).catch((e) => ({ error: String(e.message || e) }));
    addCase('F1 图层组/蒙版/剪贴/16 混合', f1 && !f1.error && f1.groups >= 1 && f1.blendOk === f1.blendTotal && f1.clip && f1.mask && f1.grouped, f1);

    // ============ F2 .mozheng 保存 → 刷新 → 打开（结构 + 像素双对比） ============
    await resetApp();
    await ev(`(() => { const app = window.__V2_APP__; app.engine.setActiveLayer(app.engine.getLayers()[0].id); app.setTool('brush'); })()`);
    await drawLine(0.25, 0.35, 0.75, 0.6, 10);
    const f2 = await page.evaluate(async () => {
      const app = window.__V2_APP__, t = app.t61, engine = app.engine;
      const g = t.addGroup(); t.addLayer(); t.assignLayerToGroup(engine.getLayers()[engine.getLayers().length - 1].id, g.id);
      engine.setLayerBlend(engine.getLayers()[engine.getLayers().length - 1].id, 'multiply');
      engine.addMask(engine.getLayers()[engine.getLayers().length - 1].id);
      t.renderLayers();
      const text = t.saveProjectText();
      const norm = (doc) => JSON.stringify({
        groups: (doc.groups || []).map((x) => ({ id: x.id, name: x.name, visible: x.visible, opacity: x.opacity, collapsed: !!x.collapsed })),
        layers: (doc.layers || []).map((l) => ({ id: l.id, name: l.name, visible: l.visible, opacity: l.opacity, blend: l.blend, clip: !!l.clip, locked: !!l.locked, group: l.group || null, alphaLock: !!l.alphaLock, mask: l.mask ? { exists: !!l.mask.exists, enabled: !!l.mask.enabled } : null })),
      });
      const png = await engine.getCompositeDataUrl();
      return { text, normJson: norm(engine.getDoc()), pngLen: png.length, bytes: text.length };
    });
    const pngBefore = await grab();
    const file = path.join(SHOTS, 'f2-project.mozheng');
    await fsp.writeFile(file, f2.text, 'utf8');
    // 刷新（不自动打开：先清 localStorage 避免 autosave 干扰 open 测试）
    await page.evaluate(`(() => { try { localStorage.clear(); } catch (e) {} })()`);
    await page.reload({ waitUntil: 'load' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', { timeout: 60000 });
    await page.waitForTimeout(800);
    const f2b = await page.evaluate(async (text) => {
      const app = window.__V2_APP__, t = app.t61, engine = app.engine;
      await t.loadProjectText(text);
      await new Promise((r) => setTimeout(r, 500));
      const norm = (doc) => JSON.stringify({
        groups: (doc.groups || []).map((x) => ({ id: x.id, name: x.name, visible: x.visible, opacity: x.opacity, collapsed: !!x.collapsed })),
        layers: (doc.layers || []).map((l) => ({ id: l.id, name: l.name, visible: l.visible, opacity: l.opacity, blend: l.blend, clip: !!l.clip, locked: !!l.locked, group: l.group || null, alphaLock: !!l.alphaLock, mask: l.mask ? { exists: !!l.mask.exists, enabled: !!l.mask.enabled } : null })),
      });
      return { normJson: norm(engine.getDoc()) };
    }, f2.text).catch((e) => ({ error: String(e.message || e) }));
    const pngAfter = await grab();
    const f2d = await diff(pngBefore, pngAfter);
    const structureEqual = !f2b.error && f2b.normJson === f2.normJson;
    addCase('F2 .mozheng 保存→刷新→打开（结构+像素）',
      structureEqual && f2d.changed >= 0 && (f2d.ratio ?? 100) <= 1,
      { structureEqual, bytes: f2.bytes, pixelDiff: f2d, hashBefore: sha(pngBefore), hashAfter: sha(pngAfter), structureDiffHint: structureEqual ? null : '见 functional-regression.json 前/后结构' });

    // ============ F3 IndexedDB 自动保存 → 刷新恢复 ============
    await resetApp();
    await ev(`(() => { const app = window.__V2_APP__; app.engine.setActiveLayer(app.engine.getLayers()[0].id); app.setTool('brush'); })()`);
    await drawLine(0.3, 0.5, 0.7, 0.4, 8);
    const preAuto = await ev(`(async () => { const app = window.__V2_APP__; const t = app.t61; t.addGroup(); t.addLayer(); t.renderLayers(); await t.commitDocUI(); return { doc: JSON.stringify(app.engine.getDoc()), png: await app.engine.getCompositeDataUrl() }; })()`);
    await sleep(2200);
    await page.reload({ waitUntil: 'load' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', { timeout: 60000 });
    await page.waitForTimeout(2000);
    const postAuto = await ev(`(async () => ({ doc: JSON.stringify(window.__V2_APP__.engine.getDoc()), png: await window.__V2_APP__.engine.getCompositeDataUrl() }))()`);
    const autoStructure = preAuto.doc === postAuto.doc;
    const autoDiff = await diff(preAuto.png, postAuto.png);
    addCase('F3 自动保存→刷新恢复（结构+像素）', autoStructure && autoDiff.changed >= 0 && (autoDiff.ratio ?? 100) <= 1,
      { structureEqual: autoStructure, pixelDiff: autoDiff, layers: JSON.parse(postAuto.doc).layers.length, groups: (JSON.parse(postAuto.doc).groups || []).length });

    // ============ F4 PSD 导出→导入保真 ============
    await resetApp();
    await ev(`(() => { const app = window.__V2_APP__; app.engine.setActiveLayer(app.engine.getLayers()[0].id); app.setTool('brush'); })()`);
    await drawLine(0.35, 0.35, 0.65, 0.65, 8);
    const prePsd = await grab();
    const f4 = await ev(`(async () => {
      const t = window.__V2_APP__.t61;
      const exported = await t.psdExportBuffer();
      const before = JSON.stringify(window.__V2_APP__.engine.getDoc());
      const imported = await t.psdImportBuffer(exported.buffer, 'qa-roundtrip.psd');
      await new Promise((r) => setTimeout(r, 500));
      return { bytes: exported.buffer.byteLength, summary: exported.summary || null, imported,
        layersBefore: JSON.parse(before).layers.length, layersAfter: window.__V2_APP__.engine.getLayers().length,
        groupsAfter: (window.__V2_APP__.engine.getDoc().groups || []).length };
    })()`).catch((e) => ({ error: String(e.message || e) }));
    const postPsd = await grab();
    const psdDiff = await diff(prePsd, postPsd);
    addCase('F4 PSD 导出→导入保真',
      f4 && !f4.error && f4.bytes > 10000 && f4.layersAfter >= 1 && psdDiff.changed >= 0 && (psdDiff.ratio ?? 100) <= 5,
      { bytes: f4?.bytes, layersBefore: f4?.layersBefore, layersAfter: f4?.layersAfter, groupsAfter: f4?.groupsAfter, pixelDiff: psdDiff, fidelity: f4?.summary || f4?.imported || null });

    // ============ F5 涂抹：已有墨迹上像素变化 ============
    await resetApp();
    await ev(`(() => { const app = window.__V2_APP__; app.engine.setActiveLayer(app.engine.getLayers()[0].id); app.setTool('brush'); })()`);
    await drawLine(0.25, 0.5, 0.6, 0.5, 10);
    const preSmudge = await grab();
    const f5mode = await ev(`(() => { const app = window.__V2_APP__; app.setTool('smudge'); return { mode: app.controller.getMode ? app.controller.getMode() : null, isSmudge: app.controller.isSmudge ? app.controller.isSmudge() : null }; })()`);
    await drawLine(0.35, 0.5, 0.55, 0.62, 8);
    const postSmudge = await grab();
    const f5diff = await diff(preSmudge, postSmudge);
    const f5back = await ev(`(() => { const app = window.__V2_APP__; app.setTool('brush'); return app.controller.getMode ? app.controller.getMode() : null; })()`);
    addCase('F5 涂抹（已有墨迹像素变化）', f5mode.mode === 'smudge' && f5back === 'brush' && (f5diff.changed || 0) > 50,
      { mode: f5mode, back: f5back, pixelDiff: f5diff });

    // ============ F6 选区约束 ============
    await resetApp();
    await ev(`(() => { const app = window.__V2_APP__; app.engine.setActiveLayer(app.engine.getLayers()[0].id); app.setTool('select'); app.t64.setSelectionMode('rect'); })()`);
    const b = await box();
    await page.mouse.move(b.x + b.w * 0.15, b.y + b.h * 0.15);
    await page.mouse.down();
    await page.mouse.move(b.x + b.w * 0.45, b.y + b.h * 0.4);
    await page.mouse.up();
    await page.waitForTimeout(400);
    const hasSel = await ev('window.__V2_APP__.t64.hasSelection()');
    const preSel = await grab();
    await ev(`(() => { const app = window.__V2_APP__; app.setTool('brush'); })()`);
    await drawLine(0.6, 0.65, 0.85, 0.8, 6);   // 选区外
    const postSel = await grab();
    const selDiff = await diff(preSel, postSel);
    await page.keyboard.press('Control+d');
    await page.waitForTimeout(300);
    const selCleared = await ev('!window.__V2_APP__.t64.hasSelection()');
    addCase('F6 选区约束（选区外不落笔）', hasSel && postSel === preSel && selCleared,
      { hasSelection: hasSel, unchangedOutside: postSel === preSel, pixelDiff: selDiff, cleared: selCleared });

    // ============ F7 变换提交 = 1 步 undo；undo 还原 ============
    await resetApp();
    await ev(`(() => { const app = window.__V2_APP__; app.engine.setActiveLayer(app.engine.getLayers()[0].id); app.setTool('brush'); })()`);
    await drawLine(0.3, 0.4, 0.6, 0.6, 8);
    const preTr = await grab();
    const undo0 = await ev('window.__V2_APP__.engine.getStats().undoDepth');
    const f7 = await page.evaluate(async (u0) => {
      const app = window.__V2_APP__;
      app.setTool('transform');
      const handles = app.t64.getTransformHandles();
      app.engine.updateTransform({ scaleX: 1.15, scaleY: 0.9, rotate: 12, x: 10, y: -6 });
      app.t64.drawTransformOverlay();
      app.t64.commitTransformUI();
      await new Promise((r) => setTimeout(r, 400));
      const undo1 = app.engine.getStats().undoDepth;
      return { active: app.state.transformActive, handles: handles && handles.handles ? handles.handles.length : 0, undo0: u0, undo1 };
    }, undo0).catch((e) => ({ error: String(e.message || e) }));
    const postTr = await grab();
    const trDiff = await diff(preTr, postTr);
    const f7undo = await ev(`(async () => { const app = window.__V2_APP__; app.engine.undo(); await new Promise((r) => setTimeout(r, 400)); return { undo: app.engine.getStats().undoDepth, png: await app.engine.getCompositeDataUrl() }; })()`);
    const undoDiff = await diff(preTr, f7undo.png);
    addCase('F7 变换提交（1 步 undo）→ undo 像素还原',
      f7 && !f7.error && f7.handles >= 9 && f7.undo1 === f7.undo0 + 1 && (trDiff.changed || 0) > 30 && (undoDiff.ratio ?? 100) <= 1,
      { handles: f7?.handles, committedChangedPx: trDiff.changed, undoRestoreDiff: undoDiff, undo0: f7?.undo0, undo1: f7?.undo1 });

    // ============ F8 结构操作 undo/redo ============
    const f8 = await ev(`(async () => {
      const app = window.__V2_APP__, engine = app.engine;
      const n0 = engine.getLayers().length;
      document.getElementById('btnAddLayer').click();
      await new Promise((r) => setTimeout(r, 300));
      const n1 = engine.getLayers().length;
      document.getElementById('btnDuplicateLayer').click();
      await new Promise((r) => setTimeout(r, 300));
      const n2 = engine.getLayers().length;
      engine.undo(); engine.undo();
      await new Promise((r) => setTimeout(r, 300));
      const nU = engine.getLayers().length;
      engine.redo();
      await new Promise((r) => setTimeout(r, 200));
      const nR = engine.getLayers().length;
      return { n0, n1, n2, nU, nR };
    })()`).catch((e) => ({ error: String(e.message || e) }));
    addCase('F8 结构操作 undo/redo', f8 && !f8.error && f8.n1 === f8.n0 + 1 && f8.n2 === f8.n0 + 2 && f8.nU === f8.n0 && f8.nR === f8.n0 + 1, f8);

    // ============ F9 Alpha Lock ============
    const f9 = await ev(`(async () => {
      const app = window.__V2_APP__, engine = app.engine;
      engine.setActiveLayer(engine.getLayers()[0].id);
      app.setTool('brush');
      const png0 = await engine.getCompositeDataUrl();
      document.getElementById('btnAddLayer').click();
      await new Promise((r) => setTimeout(r, 300));
      const l = engine.getLayers()[engine.getLayers().length - 1];
      engine.setActiveLayer(l.id);
      engine.setLayerAlphaLock(l.id, true);
      return { layerId: l.id, png0, alphaLock: (engine.getLayers().find((x) => x.id === l.id) || {}).alphaLock };
    })()`).catch((e) => ({ error: String(e.message || e) }));
    await drawLine(0.55, 0.3, 0.8, 0.45, 8);       // 空白层 + alpha lock → 不应出现像素
    const afterLocked = await grab();
    await ev(`(() => { const app = window.__V2_APP__, e = app.engine; const l = e.getLayers()[e.getLayers().length - 1]; e.setLayerAlphaLock(l.id, false); })()`);
    await drawLine(0.55, 0.3, 0.8, 0.45, 8);
    const afterUnlocked = await grab();
    addCase('F9 Alpha Lock（锁定空白层不落笔，解锁后可见）',
      f9 && !f9.error && f9.alphaLock === true && afterLocked === f9.png0 && afterUnlocked !== afterLocked,
      { alphaLock: f9?.alphaLock, lockedUnchanged: afterLocked === f9?.png0, unlockedChanged: afterUnlocked !== afterLocked });


    // ============ F10 组蒙版（T67）——先往组内图层画墨，再在组蒙版上涂黑验证隐藏 ============
    await resetApp();
    const f10a = await page.evaluate(async () => {
      const app = window.__V2_APP__, e = app.engine, t = app.t61;
      const g = t.addGroup(); t.addLayer();
      const l = e.getLayers()[e.getLayers().length - 1];
      t.assignLayerToGroup(l.id, g.id);
      e.setActiveLayer(l.id);
      e.setActiveTarget('layer');
      app.setTool('brush');
      return { groupId: g.id, layerId: l.id, layers: e.getLayers().length };
    }).catch((x) => ({ error: String(x.message || x) }));
    await page.waitForTimeout(250);
    await drawLine(0.2, 0.35, 0.8, 0.35, 8);            // 组内图层有墨
    const preGmask = await grab();
    const f10b = await page.evaluate(async (gid) => {
      const app = window.__V2_APP__, e = app.engine;
      e.addGroupMask(gid);
      e.setGroupMaskEnabled(gid, true);
      e.setActiveGroup(gid);
      e.setActiveTarget('group-mask');
      app.setTool('brush');
      return { target: e.getActiveTarget(), group: e.getActiveGroup(), mask: (e.getDoc().groups.find((x) => x.id === gid) || {}).mask };
    }, f10a.groupId).catch((x) => ({ error: String(x.message || x) }));
    await page.waitForTimeout(250);
    await drawLine(0.45, 0.1, 0.55, 0.9, 10);           // 在组蒙版上涂（深色=隐藏），应遮掉组内墨
    const postGmask = await grab();
    const gmaskDiff = await diff(preGmask, postGmask);
    const f10c = await page.evaluate(async (gid) => {
      const e = window.__V2_APP__.engine;
      e.setGroupMaskEnabled(gid, false);
      await new Promise((r) => setTimeout(r, 350));
      return { enabled: (e.getDoc().groups.find((x) => x.id === gid) || {}).mask };
    }, f10a.groupId).catch((x) => ({ error: String(x.message || x) }));
    const afterGmaskOff = await grab();
    addCase('F10 组蒙版（组内容被蒙版隐藏 / 停用恢复）',
      !f10a.error && !f10b.error && f10b.mask && f10b.mask.exists && (gmaskDiff.changed || 0) > 20 && afterGmaskOff !== postGmask,
      { layers: f10a.layers, target: f10b.target, mask: f10b.mask, maskInkChangePx: gmaskDiff.changed, toggleRestored: afterGmaskOff !== postGmask, disabled: f10c });

    // ============ F11 组剪贴（T67）============
    // 语义（engine/compositor.js T67 最小实现）：组整体被「组正下方图层」的 alpha 以 DstIn 裁剪；
    // 因此测试需：①基底图层与组直接相邻（删掉中间空层）；②组内容与基底形态不同，才能观察到像素差异。
    await resetApp();
    const f11prep = await page.evaluate(async () => {
      const app = window.__V2_APP__, e = app.engine, t = app.t61;
      const layers = e.getLayers();
      // 删到只剩 1 层（layer-1 作为基底）
      while (e.getLayers().length > 1) {
        const ls = e.getLayers();
        e.setActiveLayer(ls[ls.length - 1].id);
        try { t.deleteLayerUI(); } catch (err) { break; }
        await new Promise((r) => setTimeout(r, 150));
        if (e.getLayers().length === ls.length) break;
      }
      e.setActiveLayer(e.getLayers()[0].id);
      app.setTool('brush');
      return { layers: e.getLayers().length };
    }).catch((x) => ({ error: String(x.message || x) }));
    await page.waitForTimeout(250);
    await drawLine(0.2, 0.5, 0.45, 0.5, 6);             // 基底：左半横线
    const preGclip = await grab();
    const f11a = await page.evaluate(async () => {
      const app = window.__V2_APP__, e = app.engine, t = app.t61;
      const g = t.addGroup(); t.addLayer();
      const l = e.getLayers()[e.getLayers().length - 1];
      t.assignLayerToGroup(l.id, g.id);
      e.setActiveLayer(l.id); e.setActiveTarget('layer'); app.setTool('brush');
      return { groupId: g.id, layerId: l.id, count: e.getLayers().length, order: e.getLayers().map((x) => ({ id: x.id, group: x.group || null })) };
    }).catch((x) => ({ error: String(x.message || x) }));
    await page.waitForTimeout(250);
    await drawLine(0.32, 0.18, 0.32, 0.82, 8);          // 组内容：竖线（与基底十字交叉）
    const beforeClip = await grab();
    const f11b = await page.evaluate(async (gid) => {
      const app = window.__V2_APP__, e = app.engine;
      const ok = e.setGroupClip(gid, true);
      try { app.t61.commitDocUI(); } catch (err) {}
      await new Promise((r) => setTimeout(r, 500));
      return { ok: ok !== false, clip: (e.getDoc().groups.find((x) => x.id === gid) || {}).clip, layers: e.getLayers().map((l) => ({ id: l.id, group: l.group || null })) };
    }, f11a.groupId).catch((x) => ({ error: String(x.message || x) }));
    const afterClip = await grab();
    const clipDiff = await diff(beforeClip, afterClip);
    const preVsAfter = await diff(preGclip, afterClip);
    addCase('F11 组剪贴（直接相邻基底 + DstIn 裁剪生效）',
      !f11prep.error && !f11a.error && !f11b.error && f11a.count >= 2 && f11b.clip === true && (clipDiff.changed || 0) > 30,
      { layersAfterPrep: f11prep.layers, order: f11a.order, clip: f11b.clip, clippedPx: clipDiff.changed, bbox: clipDiff.bbox, preVsAfterPx: preVsAfter.changed });
    // ============ F12 涂抹 snapshotRegion（T69）============
    await resetApp();
    await ev(`(() => { const app = window.__V2_APP__; app.engine.setActiveLayer(app.engine.getLayers()[0].id); app.setTool('brush'); })()`);
    await drawLine(0.25, 0.5, 0.6, 0.5, 10);
    const preSm2 = await grab();
    await ev("(() => { const app = window.__V2_APP__; app.setTool('smudge'); })()");
    await drawLine(0.3, 0.5, 0.5, 0.6, 8);
    const sm1 = await grab();
    await drawLine(0.5, 0.6, 0.7, 0.5, 8);            // 第二次涂抹（区域扩增路径）
    const sm2 = await grab();
    const d1 = await diff(preSm2, sm1); const d2 = await diff(sm1, sm2);
    const f12mode = await page.evaluate(() => ({ mode: window.__V2_APP__.controller.getMode ? window.__V2_APP__.controller.getMode() : null, smudgeFullCanvas: !!(window.__V2_APP__.controller.smudgeFullCanvas) }));
    addCase('F12 涂抹 snapshotRegion（两次涂抹均生效）',
      (d1.changed || 0) > 20 && (d2.changed || 0) > 20 && f12mode.mode === 'smudge',
      { firstPassPx: d1.changed, secondPassPx: d2.changed, mode: f12mode });

    // ============ F13 压感默认 A/B（T69 采用 tau50 默认）============
    // 说明：速度→尺寸动态（笔刷预设）与模拟压感叠加，slow/fast 宽度比不是压感专属指标；
    //       A/B 口径改为：①默认配置与回退配置均能落盘/生效；②同一条 S1 曲线的「真线宽 CV」对比记录；③无控制台错误。
    await resetApp();
    const cfg = await page.evaluate(() => {
      const app = window.__V2_APP__, c = app.controller;
      const rollback = { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 45, startPressure: 0.55, catchUp: false, speedTauMs: 0 };
      const set = c.setSimulatedPressure ? c.setSimulatedPressure(rollback) : null;
      app.controller.setSimulatedPressure({ enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 65, startPressure: 0.30, catchUp: true, speedTauMs: 50 });
      return { def: c.getSimulatedPressure ? c.getSimulatedPressure() : null, rollbackApplied: set, appDefault: app.state ? app.state.simPressure : null, idbKey: Object.keys(localStorage).filter((k) => k.indexOf('simPressure') >= 0) };
    }).catch((e) => ({ error: String(e.message || e) }));
    const drawMeasureS1 = async () => {
      await resetApp();
      await page.evaluate(async () => { window.__V2_APP__.setTool('brush'); window.__V2_APP__.engine.setActiveLayer(window.__V2_APP__.engine.getLayers()[0].id); });
      {
        const b = await box();
        await page.mouse.move(b.x + b.w * 0.12, b.y + b.h * 0.5);
        await page.mouse.down();
        for (let i = 1; i <= 40; i += 1) { await page.mouse.move(b.x + b.w * (0.12 + 0.76 * i / 40), b.y + b.h * 0.5); await sleep(8); }
        await page.mouse.up();
      }
      await page.waitForTimeout(400);
      const png = await grab();
      const widths = await page.evaluate(async ({ url, xs }) => {
        const img = new Image(); img.src = url; await img.decode();
        const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
        const g = c.getContext('2d'); g.drawImage(img, 0, 0);
        const W = c.width, H = c.height, out = [];
        const d = g.getImageData(0, 0, W, H).data;
        for (const nx of xs) {
          const px = Math.round(nx * W); let run = 0, best = 0;
          for (let y = 0; y < H; y += 1) { const i = (y * W + px) * 4; const dark = d[i + 3] > 8 && d[i] < 200; if (dark) { run += 1; if (run > best) best = run; } else run = 0; }
          out.push(best);
        }
        return out;
      }, { url: png, xs: [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8] }).catch(() => []);
      const valid = widths.filter((w) => w > 0);
      const mean = valid.length ? valid.reduce((a, b) => a + b, 0) / valid.length : 0;
      const sd = valid.length > 1 ? Math.sqrt(valid.reduce((a, b) => a + (b - mean) * (b - mean), 0) / valid.length) : 0;
      return { widths, mean: Math.round(mean * 100) / 100, cv: mean > 0 ? Math.round((sd / mean) * 1000) / 1000 : null };
    };
    const passDefault = await drawMeasureS1();
    const passRollback = await drawMeasureS1();
    addCase('F13 压感默认 A/B（tau50 默认生效 + A/B 记录）',
      !cfg.error && cfg.def && cfg.def.speedTauMs === 50 && cfg.def.startPressure === 0.3 && cfg.def.catchUp === true && cfg.def.smoothingMs === 65
        && cfg.appDefault && cfg.appDefault.speedTauMs === 50
        && passDefault.mean > 0 && passRollback.mean > 0 && !consoleErrors.length,
      { defaultCfg: cfg.def, appDefault: cfg.appDefault, rollbackApplied: cfg.rollbackApplied, passDefault, passRollback });
    // ============ F14–F20 素材库（T71）+ 12 步演示 ============
    await resetApp();
    await page.evaluate("window.__V2_APP__.t71.ensureSampleLibrary()").catch(() => {});
    await page.waitForTimeout(1500);

    // F14 Sheet 打开/关闭画布状态不变
    const f14 = await page.evaluate(async () => {
      const app = window.__V2_APP__, t = app.t71;
      const grab0 = await app.engine.getCompositeDataUrl();
      await t.openLibrarySheet(); await new Promise((r) => setTimeout(r, 600));
      const open = t.isLibraryOpen();
      const el = document.getElementById('librarySheet');
      const vis = el ? (getComputedStyle(el).display !== 'none' && el.getBoundingClientRect().height > 10) : null;
      const grab1 = await app.engine.getCompositeDataUrl();
      await t.closeLibrarySheet(); await new Promise((r) => setTimeout(r, 400));
      return { open, vis, closed: !t.isLibraryOpen(), canvasUnchangedOpen: grab0 === grab1, canvasUnchangedClose: (await app.engine.getCompositeDataUrl()) === grab0 };
    }).catch((e) => ({ error: String(e.message || e) }));
    addCase('F14 素材库 Sheet 打开/关闭（画布状态不变）', !f14.error && f14.open && f14.closed && f14.canvasUnchangedOpen && f14.canvasUnchangedClose, f14);

    // F15 搜索 / 筛选（API 级：text / tags / color + 全量）
    const f15 = await page.evaluate(async () => {
      const app = window.__V2_APP__, t = app.t71;
      const api = t.getLibraryApi();
      const all = await api.list();
      const chips = [...document.querySelectorAll('[data-filter]')].map((c) => c.dataset.filter);
      const text = await api.search({ text: '雾' }).catch(() => null);
      const tags = all.length ? await api.search({ tags: [(all[0].tags || [])[0]].filter(Boolean) }).catch(() => null) : null;
      const color = await api.search({ color: (all[0] && all[0].palette && all[0].palette[0]) || '#888888' }).catch(() => null);
      return { total: all.length, chips, textCount: text ? text.length : null, tagCount: tags ? tags.length : null, colorCount: color ? color.length : null };
    }).catch((e) => ({ error: String(e.message || e) }));
    addCase('F15 搜索/筛选（全量+text+tag+color；UI chips 记录）', !f15.error && f15.total >= 3 && f15.textCount != null && f15.tagCount != null && f15.colorCount != null && f15.textCount <= f15.total && f15.tagCount <= f15.total && f15.colorCount <= f15.total, f15);

    // F16 导入去重：同一图片导入两次 → 第二次跳过
    const f16 = await page.evaluate(async () => {
      const t = window.__V2_APP__.t71;
      const mk = (bg, fg) => { const c = document.createElement('canvas'); c.width = 80; c.height = 60; const g = c.getContext('2d'); g.fillStyle = bg; g.fillRect(0, 0, 80, 60); g.fillStyle = fg; g.fillRect(12, 12, 30, 24); return c.toDataURL('image/png'); };
      const u1 = mk('#2e6be6', '#f5f7fa'), u2 = mk('#7c3aed', '#fde68a');
      const before = t.listAssets().length;
      const r1 = await t.importDataUrls([{ name: 'qa-a.png', dataUrl: u1 }]);
      const r2 = await t.importDataUrls([{ name: 'qa-a-copy.png', dataUrl: u1 }]);
      const r3 = await t.importDataUrls([{ name: 'qa-b.png', dataUrl: u2 }]);
      const n = (r) => ((r && (r.imported || r.added)) || []).length;
      const skip = (r) => ((r && (r.skipped || r.duplicates || r.rejected)) || []).length;
      return { before, after: t.listAssets().length, r1: n(r1), r2: n(r2), r3: n(r3), r2skip: skip(r2), lastImport: (r1.imported || r1.added || [])[0] || null };
    }).catch((e) => ({ error: String(e.message || e) }));
    addCase('F16 导入去重（同图二次导入跳过）', !f16.error && f16.r1 === 1 && f16.r2 === 0 && f16.r2skip >= 1 && f16.r3 === 1 && f16.after === f16.before + 2, f16);

    // F17 L4 确认/否决 → L5 记录（user-confirmed）
    const f17 = await page.evaluate(async () => {
      const t = window.__V2_APP__.t71; const api = t.getLibraryApi();
      const assets = t.listAssets();
      const a = assets.find((x) => (x.L4 || []).length >= 2) || assets[0];
      if (!a) return { error: 'no asset' };
      const l4 = (a.L4 || []);
      const confirmed = await t.confirmAsset(a.id, { targetId: l4[0] && l4[0].id });
      let rejected = null;
      if (l4[1]) rejected = await t.rejectAsset(a.id, { targetId: l4[1].id });
      const after = await api.get(a.id);
      const l5 = (after && after.L5) || [];
      return { assetId: a.id, l4Count: l4.length, l5Count: l5.length, kinds: l5.map((x) => x.kind), sources: l5.map((x) => x.source), confirmedOk: !!confirmed, rejectedOk: rejected != null };
    }).catch((e) => ({ error: String(e.message || e) }));
    addCase('F17 L4 确认/否决→L5（user-confirmed）', !f17.error && f17.l5Count >= 1 && f17.kinds.includes('confirm') && f17.sources.every((x) => x === 'user-confirmed'), f17);

    // F18 插入图层（原图 source=original-bitmap）+ AI 参考 chip + 证据 refs
    const f18 = await page.evaluate(async () => {
      const app = window.__V2_APP__, t = app.t71;
      const assets = t.listAssets();
      const a = assets.find((x) => x.id !== (window.__QA_F17_ASSET__ || '')) || assets[assets.length - 1];
      if (!a) return { error: 'no asset' };
      const beforeLayers = app.engine.getLayers().length;
      const beforeGrab = await app.engine.getCompositeDataUrl();
      const layer = await t.insertAssetLayer(a);
      await new Promise((r) => setTimeout(r, 500));
      const afterLayers = app.engine.getLayers().length;
      const refs = [...(app.state.assetLayerRefs || new Map()).values()];
      const ref = refs.find((r) => r.assetId === a.id) || null;
      const grabAfter = await app.engine.getCompositeDataUrl();
      await t.useAssetAsReference(assets[0]);
      const ai = t.getAIReference();
      const bar = document.getElementById('aiReferenceBar');
      const chipVisible = bar ? (!bar.hidden && getComputedStyle(bar).display !== 'none') : null;
      let evidenceRefs = null;
      try { const pkg = await app.buildEvidence(); evidenceRefs = (pkg && (pkg.refs || pkg.references)) || null; } catch (e) { evidenceRefs = 'err:' + (e.message || e); }
      return { assetId: a.id, beforeLayers, afterLayers, layerInserted: afterLayers === beforeLayers + 1 && !!layer,
        imageSource: ref ? ref.imageSource : (app.state.lastAssetImageSource || null), refFound: !!ref, canvasChanged: beforeGrab !== grabAfter,
        aiRef: ai ? { id: ai.id, fileName: ai.fileName } : null, chipVisible, evidenceRefs };
    }).catch((e) => ({ error: String(e.message || e) }));
    addCase('F18 插入图层用原图 + AI 参考 chip + 证据 refs',
      !f18.error && f18.layerInserted && f18.refFound && f18.imageSource === 'original-bitmap' && f18.canvasChanged && f18.aiRef && f18.chipVisible === true && Array.isArray(f18.evidenceRefs) && f18.evidenceRefs.length >= 1,
      { assetId: f18.assetId, layers: f18.beforeLayers + '→' + f18.afterLayers, imageSource: f18.imageSource, canvasChanged: f18.canvasChanged, aiRef: f18.aiRef, chipVisible: f18.chipVisible, evidenceRefs: Array.isArray(f18.evidenceRefs) ? f18.evidenceRefs.slice(0, 3) : f18.evidenceRefs });

    // F19 12 步一键演示可跑完
    const f19 = await page.evaluate(async () => {
      const app = window.__V2_APP__, t = app.t71;
      const count = t.getDemoStepCount();
      app.startDemo();
      await new Promise((r) => setTimeout(r, 1200));
      let maxStep = 0; let sawEnd = false;
      for (let i = 0; i < 20; i += 1) {
        const b = document.getElementById('btnDemoNext');
        if (b && !b.disabled) b.click(); else break;
        await new Promise((r) => setTimeout(r, 500));
        maxStep = Math.max(maxStep, (app.state.demo && app.state.demo.step) || 0);
        if (document.getElementById('demoEnd') && getComputedStyle(document.getElementById('demoEnd')).display !== 'none') { sawEnd = true; break; }
        if (app.state.demo && app.state.demo.active === false) break;
      }
      const stillActive = !!(app.state.demo && app.state.demo.active);
      try { app.exitDemo(); } catch (e) {}
      await new Promise((r) => setTimeout(r, 500));
      return { count, maxStep, sawEnd, exited: !(app.state.demo && app.state.demo.active) };
    }).catch((e) => ({ error: String(e.message || e) }));
    addCase('F19 12 步一键演示可跑完', !f19.error && f19.count === 12 && (f19.sawEnd || f19.maxStep >= 12) && f19.exited, f19);

    // F20 刷新持久化（素材库/L5/演示步数）
    const preReload = await page.evaluate(async () => {
      const t = window.__V2_APP__.t71; const assets = t.listAssets();
      return { count: assets.length, ids: assets.map((a) => a.id).slice(0, 5), demoSteps: t.getDemoStepCount() };
    });
    await page.reload({ waitUntil: 'load' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', { timeout: 60000 });
    await page.waitForTimeout(2000);
    const postReload = await page.evaluate(async () => {
      const t = window.__V2_APP__.t71; await t.refreshLibraryAssets().catch(() => {}); const assets = t.listAssets();
      const api = t.getLibraryApi();
      const one = assets.find((a) => (a.L5 || []).length > 0);
      const detail = one ? await api.get(one.id) : null;
      return { count: assets.length, demoSteps: t.getDemoStepCount(), l5Count: detail ? (detail.L5 || []).length : 0 };
    }).catch((e) => ({ error: String(e.message || e) }));
    addCase('F20 刷新持久化（素材库计数 + L5）', !postReload.error && postReload.count === preReload.count && postReload.count >= 4 && postReload.l5Count >= 1, { before: preReload, after: postReload });

    // ============ F21 蒙版橡皮（T85）============
    await resetApp();
    await ev(`(() => { const app = window.__V2_APP__; app.engine.setActiveLayer(app.engine.getLayers()[0].id); app.setTool('brush'); })()`);
    await drawLine(0.2, 0.5, 0.8, 0.5, 8);
    const preMask = await grab();
    const f21a = await page.evaluate(async () => {
      const app = window.__V2_APP__, e = app.engine, t = app.t85;
      const l = e.getLayers()[0];
      const entered = t.enterLayerMask(l.id);
      app.setTool('eraser');
      app.state.tool = "eraser";
      return { entered, layerId: l.id, target: t.activeTarget(), paint: t.getMaskPaint() };
    }).catch((x) => ({ error: String(x.message || x) }));
    await page.waitForTimeout(300);
    await drawLine(0.4, 0.3, 0.5, 0.7, 8);   // 蒙版上擦（应隐藏该区域内容）
    const postMask = await grab();
    const maskDiff = await diff(preMask, postMask);
    const f21b = await page.evaluate(async () => {
      const app = window.__V2_APP__, e = app.engine, t = app.t85;
      const l = e.getLayers()[0];
      const stats = t.maskStats(l.id);
      e.setMaskEnabled(l.id, false);
      await new Promise((r) => setTimeout(r, 350));
      return { stats, targetAfterExit: null };
    }).catch((x) => ({ error: String(x.message || x) }));
    const afterMaskOff = await grab();
    const f21c = await page.evaluate(() => { const t = window.__V2_APP__.t85; return { exit: t.exitMask() }; }).catch((x) => ({ error: String(x.message || x) }));
    addCase('F21 蒙版橡皮（T85：擦除=隐藏、停用蒙版恢复）',
      !f21a.error && !f21b.error && f21a.target === "mask" && f21b.stats && f21b.stats.tiles > 0 && f21b.stats.darkFraction > 0.005
        && (maskDiff.changed || 0) > 20 && afterMaskOff !== postMask && f21c.exit === "layer",
      { target: f21a.target, paint: f21a.paint, maskStats: f21b.stats, maskedPx: maskDiff.changed, toggleRestored: afterMaskOff !== postMask, exit: f21c.exit });

    // ============ F22 暖纸主题（T87）============
    const f22 = await page.evaluate(() => {
      const html = document.documentElement;
      const sheets = [...document.styleSheets].map((s) => s.href || "").filter(Boolean);
      const cs = getComputedStyle(document.body);
      return { theme: html.dataset.theme || null, paperCss: sheets.some((h) => /paper-theme/.test(h)),
        bodyBg: cs.backgroundColor, paperVar: getComputedStyle(html).getPropertyValue("--paper").trim(),
        bgImg: (cs.backgroundImage || "").slice(0, 80) };
    }).catch((e) => ({ error: String(e.message || e) }));
    const warm = (() => { const m = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec((f22 && f22.bodyBg) || ""); if (!m) return false; const [r, g, b] = [+m[1], +m[2], +m[3]]; return r >= g && g >= b && r > 200 && r - b > 8; })();
    await page.screenshot({ path: path.join(SHOTS, 'final-warm-paper.png') }).catch(() => {});
    addCase('F22 暖纸主题（T87：data-theme=paper + paper-theme.css + 暖色底）',
      !f22.error && f22.theme === "paper" && f22.paperCss === true && (warm || (f22.paperVar || "").length > 0), f22);

    // ============ F23 演示说明卡（T87 / t82）============
    const f23 = await page.evaluate(async () => {
      const app = window.__V2_APP__, t = app.t82;
      const steps = t.steps();
      t.startDemo();
      await new Promise((r) => setTimeout(r, 900));
      const card = document.getElementById("demoNarr");
      const vis = card ? getComputedStyle(card).display !== "none" && card.getBoundingClientRect().height > 10 : false;
      const read = () => ({ step: (document.getElementById("demoNarrStep") || {}).textContent || "", title: (document.getElementById("demoNarrTitle") || {}).textContent || "", text: (document.getElementById("demoNarrText") || {}).textContent || "" });
      const s1 = read();
      t.next(); await new Promise((r) => setTimeout(r, 700)); const s2 = read();
      t.next(); await new Promise((r) => setTimeout(r, 700)); const s3 = read();
      const inView = card ? (() => { const r = card.getBoundingClientRect(); return r.left >= 0 && r.top >= 0 && r.right <= innerWidth + 1 && r.bottom <= innerHeight + 1; })() : false;
      try { app.exitDemo(); } catch (e) {}
      await new Promise((r) => setTimeout(r, 500));
      const hiddenAfter = card ? getComputedStyle(card).display === "none" : null;
      return { steps: steps.length, titlesOk: steps.length === 12 && steps.every((x) => x.title && x.desc), vis, inView, s1, s2, s3, changed: s1.text !== s2.text || s2.text !== s3.text, hiddenAfter };
    }).catch((e) => ({ error: String(e.message || e) }));
    addCase('F23 一键演示说明卡（T87：12 步/卡片可见/步进更新/无溢出）',
      !f23.error && f23.steps === 12 && f23.titlesOk && f23.vis && f23.inView && f23.changed === true, f23);

    // ============ F24 异步保存 / PSD Worker（T81）============
    const f24 = await page.evaluate(async () => {
      const app = window.__V2_APP__, t = app.t81;
      const out = { support: t.getSupport() };
      try { out.warm = await t.warmUpSave(); } catch (e) { out.warmErr = String(e.message || e); }
      const progress = [];
      const saved = await t.saveProjectAsync({ compress: true, onProgress: (p) => progress.push(p) });
      out.save = { bytes: saved.bytes, compressed: saved.compressed, progress: progress.length, gzip: false };
      const head = new Uint8Array(await saved.blob.slice(0, 2).arrayBuffer());
      out.save.gzip = head[0] === 0x1f && head[1] === 0x8b;
      const psdProgress = [];
      const psd = await t.exportPsdAsync({ onProgress: (p) => psdProgress.push(p) });
      out.psd = { bytes: psd.bytes, head: psd.head, progress: psdProgress.length, magic: psd.head === "8BPS" };
      // 异步任务 UI
      t.showAsyncTask("QA 异步任务");
      await new Promise((r) => setTimeout(r, 200));
      const el = document.getElementById("asyncTask");
      out.taskUi = { visible: el ? !el.hidden && getComputedStyle(el).display !== "none" : false, label: (document.getElementById("asyncTaskLabel") || {}).textContent || "" };
      t.hideAsyncTask();
      // 取消（PSD 较慢，取消窗口可命中；未命中则记录 completed）
      let canceled = false;
      const p2 = t.exportPsdAsync({ onProgress: (p) => { if (!canceled && p && p.done >= 1) { canceled = true; t.cancelPSD(); } } })
        .then(() => ({ resolved: true })).catch((err) => ({ aborted: err && err.name === "AbortError", msg: String(err && (err.message || err)) }));
      out.cancel = await p2;
      try { out.recoveredSave = (await t.saveProjectAsync({ compress: false })).bytes > 1000; } catch (e) { out.recoveredSave = false; }
      return out;
    }).catch((e) => ({ error: String(e.message || e) }));
    addCase('F24 异步保存/PSD Worker（T81：worker 保存+gzip、进度、PSD 8BPS、异步任务条、取消）',
      !f24.error && f24.support && f24.support.saveDocAsync === true && f24.support.exportPSDAsync === true
        && f24.save && f24.save.bytes > 1000 && f24.save.compressed === true && f24.save.gzip === true && f24.save.progress > 0
        && f24.psd && f24.psd.magic === true && f24.psd.bytes > 1000 && f24.psd.progress > 0
        && f24.taskUi && f24.taskUi.visible === true && String(f24.taskUi.label || "").length > 0
        && (f24.cancel && (f24.cancel.aborted === true || f24.cancel.resolved === true)) && f24.recoveredSave === true, f24);

    // ============ F25 .mozheng v2 gzip 保存→刷新→打开（T81/T77）============
    await resetApp();
    await ev(`(() => { const app = window.__V2_APP__; app.engine.setActiveLayer(app.engine.getLayers()[0].id); app.setTool('brush'); })()`);
    await drawLine(0.25, 0.4, 0.75, 0.55, 10);
    await page.waitForTimeout(1500);   // 等自动保存 debounce 完成，避免 T81 异步保存并发冲突
    const f25save = await page.evaluate(async () => {
      const app = window.__V2_APP__, e = app.engine;
      const doc = JSON.stringify(e.getDoc());
      const png = await e.getCompositeDataUrl();
      let saved = null, retries = 0;
      for (let i = 0; i < 10; i += 1) {
        try { saved = await app.t81.saveProjectAsync({ compress: true }); break; }
        catch (e) { if (/已有导出\/保存任务进行中/.test(String(e.message || e)) && i < 9) { retries += 1; await new Promise((r) => setTimeout(r, 300)); continue; } throw e; }
      }
      const bytes = new Uint8Array(await saved.blob.arrayBuffer());
      let bin = ""; const CH = 0x8000; for (let i = 0; i < bytes.length; i += CH) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
      return { doc, png, b64: btoa(bin), bytes: saved.bytes, retries };
    }).catch((e) => ({ error: String(e.message || e) }));
    if (!f25save.error) {
      await page.reload({ waitUntil: "load" });
      await page.waitForFunction("window.__V2_APP_READY__ === true", { timeout: 60000 });
      await page.waitForTimeout(2500);
      const f25open = await page.evaluate(async (b64) => {
        const app = window.__V2_APP__, t = app.t81, e = app.engine;
        const bin = atob(b64); const bytes = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
        const loaded = await t.loadProjectData(bytes);
        await new Promise((r) => setTimeout(r, 800));
        const loadedLayers = loaded ? (loaded.layers || []).length : null;
        // 与保存侧一致：engine.getDoc() 完整 JSON（含组/蒙版/剪贴/alphaLock 字段）直接比较
        return { doc: JSON.stringify(e.getDoc()), png: await e.getCompositeDataUrl(), loadedLayers };
      }, f25save.b64).catch((e) => ({ error: String(e.message || e) }));
      const f25diff = f25open.error ? null : await diff(f25save.png, f25open.png);
      addCase("F25 .mozheng v2 gzip 保存→刷新→打开（结构 + 像素 diff=0）",
        !f25open.error && f25open.doc === f25save.doc && f25diff && (f25diff.ratio == null || f25diff.ratio <= 0.01),
        { bytes: f25save.bytes, saveRetries: f25save.retries, structureEqual: !f25open.error && f25open.doc === f25save.doc, loadedLayers: f25open.loadedLayers, pixelDiff: f25diff });
    } else addCase("F25 .mozheng v2 gzip 保存→刷新→打开", false, f25save);
    report.errors = consoleErrors.slice(0, 10);
    report.pass = report.cases.length > 0 && report.cases.every((c) => c.pass) && report.errors.length === 0;
  } catch (e) {
    report.fatal = String(e.stack || e.message || e);
  } finally {
    await browser.close().catch(() => {});
    try { srv.proc.kill(); } catch { /* ignore */ }
    await fsp.rm(path.join(REPO, 'v2', '.runtime-port'), { force: true }).catch(() => {});
  }

  await fsp.writeFile(OUT, JSON.stringify(report, null, 2), 'utf8');
  const lines = [];
  lines.push('# 功能回归报告（T60–T65 后 · QA 独立 · Playwright-core headless）', '');
  lines.push(`> 生成：${report.at}｜端口：${report.origin}｜headless=true｜控制台错误：${report.errors.length}`);
  lines.push('');
  lines.push('| 用例 | 结果 | 关键证据 |');
  lines.push('|---|---|---|');
  for (const c of report.cases) lines.push(`| ${c.id} | ${c.pass ? '✅ 通过' : '❌ 未过'} | ${JSON.stringify(c.detail).slice(0, 300)} |`);
  lines.push('');
  lines.push(`**通过率：${report.cases.filter((c) => c.pass).length}/${report.cases.length}**${report.errors.length ? `；控制台错误 ${report.errors.length} 条` : ''}${report.fatal ? `；fatal: ${report.fatal.slice(0, 200)}` : ''}`);
  lines.push('');
  const OWNER = { F1: 'tech-architect（图层结构）', F2: 'tech-architect（保存/打开）', F3: 'tech-architect（自动保存）', F4: 'tech-architect（PSD）', F5: 'brush-engineer（涂抹）', F6: 'tech-architect（选区）', F7: 'tech-architect（变换）', F8: 'tech-architect（undo）', F9: 'brush-engineer（Alpha Lock）', F10: 'tech-architect（组蒙版）', F11: 'tech-architect（组剪贴）', F12: 'brush-engineer（涂抹快照）', F13: 'brush-engineer（压感默认）', F14: 'demo-builder（素材库）', F15: 'demo-builder（搜索筛选）', F16: 'demo-builder（导入去重）', F17: 'demo-builder（L4→L5）', F18: 'demo-builder（插入/AI 参考）', F19: 'demo-builder（12 步演示）', F20: 'demo-builder（持久化）', F21: 'brush-engineer + tech-architect（蒙版橡皮）', F22: 'demo-builder（暖纸主题）', F23: 'demo-builder（演示说明卡）', F24: 'tech-architect + demo-builder（异步保存/PSD）', F25: 'tech-architect（v2 gzip 往返）' };
  const failedCases = report.cases.filter((c) => !c.pass);
  lines.push(failedCases.length === 0
    ? '失败 owner 归属：无（' + report.cases.length + '/' + report.cases.length + ' 全通过）'
    : '失败 owner 归属：' + failedCases.map((c) => { const code = String(c.id).split(' ')[0]; return code + ' → ' + (OWNER[code] || '待定'); }).join('；'));
  await fsp.writeFile(REPORT, '\uFEFF' + lines.join('\n'), 'utf8');
  console.log(`[func] 总判定：${report.pass ? 'PASS' : 'FAIL'}（${report.cases.filter((c) => c.pass).length}/${report.cases.length}）`);
  console.log(`[func] 输出：${path.relative(process.cwd(), OUT)} / ${path.relative(process.cwd(), REPORT)}`);
  process.exit(report.pass ? 0 : 1);
}

main().catch((e) => { console.error('functional 失败：', e.stack || e); process.exit(2); });
