/**
 * v2/library · 素材资产模型（T70，MVP）
 *
 * 对齐 v0.1 `v2/app/core/archive-schema.mjs`（L0–L6 / 来源三态 / anchor / confidence）：
 * 本模块**复用其常量**（LAYERS/SOURCES/ANCHOR_TYPES/MVP_LAYERS）并按其字段命名，输出可转 archive 记录。
 *
 * Asset（IndexedDB `assets` 表）：
 * {
 *   id: 'asset-<sha16>', sha256, fileName, mime, bytes, width, height,
 *   createdAt, updatedAt, tags[], palette[], usageCount,
 *   L0: {layer,source:'observed',author:'user',anchor:{type:'whole'},...},
 *   L1: {layer,source:'inferred',confidence,anchor:{type:'whole'},summary,subject,medium,palette,mood,modelVersion},
 *   L2: [{id,layer:'L2',source:'inferred',confidence,label,bbox,anchor:{type:'bbox',value}}],
 *   L4: [{id,layer:'L4',kind,source:'inferred',author:'ai',confidence,text,anchor,evidenceRefs,modelVersion}],
 *   L5: [{id,layer:'L5',kind:'confirm'|'reject'|'use',targetId,tags,at,source:'user-confirmed'}],
 *   source: ['observed','inferred','user-confirmed'], modelVersion, projectRefs:[]
 * }
 */
import { LAYERS, MVP_LAYERS, SOURCES, ANCHOR_TYPES, SCHEMA_VERSION } from '../app/core/archive-schema.mjs';

export const LIBRARY_SCHEMA = 'mozheng.library.v1';
export const ASSET_VERSION = 1;
export { LAYERS, MVP_LAYERS, SOURCES, ANCHOR_TYPES, SCHEMA_VERSION };

export const LIBRARY_DB = 'mozheng-library';
export const LIBRARY_DB_VERSION = 2; // T74: + originals store

export const MOCK_MODEL = 'mock-ai@0.1.0';

const clamp01 = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0.5;
};
const round2 = (n) => Math.round(Number(n) * 100) / 100;
const asArray = (v) => (Array.isArray(v) ? v : []);

/** 生成稳定 asset id（sha256 前 16 hex） */
export function assetIdForSha(sha256) {
  return `asset-${String(sha256 || '').slice(0, 16)}`;
}

/** 从 mock 反解结果构建资产记录（不含缩略图） */
export function buildAsset({ sha256, fileName, mime, bytes, width, height, analysis, palette, createdAt, modelVersion }) {
  const now = createdAt || new Date().toISOString();
  const l2 = asArray(analysis && analysis.regions).map((r, i) => ({
    id: r.id || `L2-mock-${String(i + 1).padStart(3, '0')}`,
    layer: 'L2',
    label: r.label || '区域',
    source: 'inferred',
    confidence: clamp01(r.confidence),
    bbox: asArray(r.bbox).map((v) => Math.round(v)),
    importance: clamp01(r.importance),
    anchor: { type: 'bbox', value: asArray(r.bbox).map((v) => Math.round(v)) },
  }));
  const l4 = asArray(analysis && analysis.observations).map((o, i) => ({
    id: o.id || `L4-mock-${String(i + 1).padStart(3, '0')}`,
    layer: 'L4',
    kind: o.kind || 'observation',
    source: 'inferred',
    author: 'ai',
    confidence: clamp01(o.confidence),
    text: o.text || '',
    anchor: { type: 'bbox', value: asArray(o.anchor && o.anchor.value).map((v) => Math.round(v)) },
    evidenceRefs: asArray(o.evidenceRefs),
    modelVersion: o.modelVersion || modelVersion || MOCK_MODEL,
  }));
  const global = (analysis && analysis.global) || {};
  const l1 = {
    layer: 'L1',
    source: 'inferred',
    confidence: round2(analysis ? analysis.confidence : 0.5),
    anchor: { type: 'whole', value: null },
    summary: global.summary || '',
    subject: asArray(global.subject),
    medium: global.medium || null,
    palette: asArray(global.palette),
    mood: asArray(global.mood),
    modelVersion: modelVersion || MOCK_MODEL,
  };
  const l0 = {
    layer: 'L0',
    source: 'observed',
    author: 'user',
    confidence: 1,
    anchor: { type: 'whole', value: null },
    fileName, mime, bytes, width, height, sha256: sha256 || null,
    importedAt: now,
  };
  const tags = new Set(asArray(global.mood));
  if (global.medium && global.medium.kind) tags.add(global.medium.kind);
  for (const s of asArray(global.subject)) tags.add(s);
  for (const p of asArray(analysis && analysis.regions)) if (p.label) tags.add(p.label);
  return normalizeAsset({
    id: assetIdForSha(sha256),
    sha256,
    fileName,
    mime,
    bytes,
    width,
    height,
    createdAt: now,
    updatedAt: now,
    tags: [...tags].slice(0, 24),
    palette: asArray(palette).length ? palette : asArray(global.palette).map((p) => p.hex),
    usageCount: 0,
    L0: l0,
    L1: l1,
    L2: l2,
    L4: l4,
    L5: [],
    source: ['observed', 'inferred'],
    modelVersion: modelVersion || MOCK_MODEL,
    projectRefs: [],
  });
}

export function normalizeAsset(input) {
  if (!input || typeof input !== 'object') throw new TypeError('asset 必须是对象');
  const tags = [...new Set(asArray(input.tags).map(String).filter(Boolean))].slice(0, 32);
  const palette = [...new Set(asArray(input.palette).map(String).filter(Boolean))].slice(0, 16);
  const l5 = asArray(input.L5).filter((d) => d && d.layer === 'L5');
  const sources = new Set(asArray(input.source));
  for (const d of l5) sources.add('user-confirmed');
  if (input.L0) sources.add('observed');
  if (input.L1) sources.add('inferred');
  return {
    ...input,
    schema: LIBRARY_SCHEMA,
    version: ASSET_VERSION,
    tags,
    palette,
    L2: asArray(input.L2),
    L4: asArray(input.L4),
    L5: l5,
    source: [...sources],
    projectRefs: asArray(input.projectRefs),
    usageCount: Math.max(0, Math.floor(Number(input.usageCount) || 0)),
    createdAt: input.createdAt || new Date().toISOString(),
    updatedAt: input.updatedAt || input.createdAt || new Date().toISOString(),
  };
}

export function validateAsset(asset) {
  const errors = [];
  if (!asset || typeof asset !== 'object') return { ok: false, errors: ['asset 非对象'] };
  if (asset.schema !== LIBRARY_SCHEMA) errors.push(`schema 应为 ${LIBRARY_SCHEMA}`);
  if (!/^[0-9a-f]{64}$/i.test(String(asset.sha256 || ''))) errors.push('sha256 非法');
  if (!asset.fileName) errors.push('fileName 缺失');
  if (!(asset.width > 0) || !(asset.height > 0)) errors.push('width/height 非法');
  if (!asset.L0 || asset.L0.layer !== 'L0' || asset.L0.source !== 'observed') errors.push('L0 缺失/来源非 observed');
  if (!asset.L1 || asset.L1.layer !== 'L1' || asset.L1.source !== 'inferred') errors.push('L1 缺失/来源非 inferred');
  if (!Array.isArray(asset.L2)) errors.push('L2 非数组');
  if (!Array.isArray(asset.L4)) errors.push('L4 非数组');
  if (!Array.isArray(asset.L5)) errors.push('L5 非数组');
  for (const r of asset.L2) {
    if (!r.anchor || r.anchor.type !== 'bbox' || !Array.isArray(r.anchor.value)) errors.push(`L2 ${r.id} anchor 非法`);
    if (!(r.confidence >= 0 && r.confidence <= 1)) errors.push(`L2 ${r.id} confidence 非法`);
  }
  for (const o of asset.L4) {
    if (!o.text) errors.push(`L4 ${o.id} text 缺失`);
    if (!(o.confidence >= 0 && o.confidence <= 1)) errors.push(`L4 ${o.id} confidence 非法`);
  }
  if (asset.source && !asArray(asset.source).includes('observed')) errors.push('source 缺 observed');
  return { ok: errors.length === 0, errors };
}

/** 转成 v0.1 archive-schema 记录数组（L0/L1/L2/L4/L5），供兼容/导出 */
export function toArchiveRecords(asset) {
  const records = [];
  records.push({ ...asset.L0, assetId: asset.id });
  records.push({ ...asset.L1, assetId: asset.id });
  for (const r of asset.L2) records.push({ ...r, assetId: asset.id });
  for (const o of asset.L4) records.push({ ...o, assetId: asset.id });
  for (const d of asset.L5) records.push({ ...d, assetId: asset.id });
  return records;
}

export { round2, clamp01 };
