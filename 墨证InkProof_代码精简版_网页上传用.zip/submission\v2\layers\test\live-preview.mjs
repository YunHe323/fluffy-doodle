#!/usr/bin/env node
// v2/layers/test/live-preview.mjs —— T45 LayerSystem 实时预览回归（零依赖 CDP）
// 用法：node v2/layers/test/live-preview.mjs <demoUrl> [port] [outJson]
// 验证：未 end 时已有内容保留 + 新笔迹可见；cancel/undo/redo；蒙版 live 预览正确。
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/layers/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/layers/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}

const page = await findPage();
if (!page) { console.error('找不到 layers demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `new Promise(async (resolve) => {
  const errors = [];
  window.addEventListener('error', (e) => errors.push(String(e.message)));
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  try {
    const t0 = Date.now();
    while (!window.__LAYERS_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
    const ls = window.__LAYERS__;
    const W = ls.width, H = ls.height;
    const checks = {};
    const capture = async () => {
      const url = await ls.getCompositeDataUrl();
      const img = new Image(); img.src = url; await img.decode();
      const c = document.createElement('canvas'); c.width = W; c.height = H;
      const cx = c.getContext('2d'); cx.drawImage(img, 0, 0);
      return cx.getImageData(0, 0, W, H).data;
    };
    const isInk = (d, x, y) => { const i = (y * W + x) * 4; return d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220; };
    const regionInk = (d, x0, y0, x1, y1) => { let n = 0; for (let y = y0; y <= y1; y += 2) for (let x = x0; x <= x1; x += 2) if (isInk(d, x, y)) n += 1; return n; };
    const pts = (x0, y, x1) => { const arr = []; for (let x = x0; x <= x1; x += 12) arr.push({ x, y: y + Math.sin((x - x0) / 40) * 6, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' }); return arr; };
    const play = async (x0, y, x1, end = true) => {
      const arr = pts(x0, y, x1);
      ls.beginStroke(arr[0]);
      for (let i = 1; i < arr.length; i += 1) ls.appendPoint(arr[i]);
      if (end) { ls.endStroke(); await raf(); } else { await raf(); await raf(); }
    };

    // 1) 第一笔 end
    await play(300, 1000, 700, true);
    const a = await capture();
    checks.firstEndInk = regionInk(a, 280, 960, 720, 1040);

    // 2) 第二笔 begin+append 未 end：第一笔仍在 + 新笔迹可见
    const arr2 = pts(300, 1400, 700);
    ls.beginStroke(arr2[0]);
    for (let i = 1; i < arr2.length; i += 1) ls.appendPoint(arr2[i]);
    await raf(); await raf();
    const b = await capture();
    checks.liveFirstVisible = regionInk(b, 280, 960, 720, 1040);
    checks.liveSecondVisible = regionInk(b, 280, 1360, 720, 1440);
    ls.endStroke(); await raf();
    const c = await capture();
    checks.afterEndBoth = regionInk(c, 280, 960, 720, 1040) + regionInk(c, 280, 1360, 720, 1440);

    // 3) cancel
    const arr3 = pts(300, 1800, 700);
    ls.beginStroke(arr3[0]);
    for (let i = 1; i < arr3.length; i += 1) ls.appendPoint(arr3[i]);
    await raf(); await raf();
    const d = await capture();
    checks.liveThirdVisible = regionInk(d, 280, 1760, 720, 1840);
    ls.cancelStroke(); await raf();
    const e = await capture();
    checks.afterCancel = regionInk(e, 280, 1760, 720, 1840);

    // 4) undo/redo 第二笔
    ls.undo(); await raf();
    const f = await capture();
    checks.afterUndoSecond = regionInk(f, 280, 1360, 720, 1440);
    checks.afterUndoFirstStill = regionInk(f, 280, 960, 720, 1040);
    ls.redo(); await raf();
    const g = await capture();
    checks.afterRedoSecond = regionInk(g, 280, 1360, 720, 1440);

    // 5) 蒙版 live：先铺透明蒙版 tile（=隐藏）→ 画蒙版笔触实时露出被覆盖区域
    const layerId = ls.activeLayerId;
    const CK = ls.CK;
    for (const key of ['1,3', '2,3', '1,4', '2,4']) {
      const tile = ls.maskStore.ensureTile(layerId, key);
      tile.surface.getCanvas().clear(CK.TRANSPARENT);
      tile.surface.flush();
      tile.image = tile.surface.makeImageSnapshot();
    }
    ls.addMask(layerId);
    await raf();
    const h = await capture();
    checks.maskHidesLayer = regionInk(h, 280, 960, 720, 1040);
    ls.setActiveTarget('mask');
    const mpts = pts(380, 1000, 520);
    ls.beginStroke(mpts[0]);
    for (let i = 1; i < mpts.length; i += 1) ls.appendPoint(mpts[i]);
    await raf(); await raf();
    const i2 = await capture();
    checks.maskLiveRevealed = regionInk(i2, 360, 960, 560, 1040);
    checks.maskLiveFarHidden = regionInk(i2, 620, 960, 720, 1040);
    ls.endStroke(); await raf();
    const j = await capture();
    checks.maskEndRevealed = regionInk(j, 360, 960, 560, 1040);
    ls.undo(); await raf();
    const k = await capture();
    checks.maskUndoHidden = regionInk(k, 360, 960, 560, 1040);
    ls.setActiveTarget('layer');

    checks.ok = checks.firstEndInk > 100
      && checks.liveFirstVisible > 100
      && checks.liveSecondVisible > 100
      && checks.afterEndBoth > 200
      && checks.liveThirdVisible > 50
      && checks.afterCancel < 10
      && checks.afterUndoSecond < 10
      && checks.afterUndoFirstStill > 100
      && checks.afterRedoSecond > 100
      && checks.maskHidesLayer < 10
      && checks.maskLiveRevealed > 50
      && checks.maskLiveFarHidden < 10
      && checks.maskEndRevealed > 50
      && checks.maskUndoHidden < 10
      && errors.length === 0;
    resolve({ ok: checks.ok, checks, errors, environment: { browser: (navigator.userAgent.match(/Chrome\\/[\\d.]+/) || [])[0] || '', headless: /HeadlessChrome/.test(navigator.userAgent) } });
  } catch (e) {
    resolve({ ok: false, error: String(e && e.stack || e), errors });
  }
})`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1200)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败:', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
