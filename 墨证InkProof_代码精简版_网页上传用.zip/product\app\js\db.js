// product/app/js/db.js
// IndexedDB 持久化（零依赖）：projects / layers / archive_records / events / generations / meta
// 说明：所有数据仅存本机浏览器；图层位图以 Blob 存储，项目导出时转 dataURL。
import { state, APP_VERSION, SCHEMA_VERSION, uid, nowIso } from './state.js';

const DB_NAME = 'inkproof';
const DB_VERSION = 1;

const STORES = [
  { name: 'projects', keyPath: 'id' },
  { name: 'layers', keyPath: 'id', indexes: [['projectId', 'projectId']] },
  { name: 'archive_records', keyPath: 'key', indexes: [['projectId', 'projectId']] },
  { name: 'events', keyPath: 'key', indexes: [['projectId', 'projectId']] },
  { name: 'generations', keyPath: 'key', indexes: [['projectId', 'projectId']] },
  { name: 'meta', keyPath: 'key' }
];

let dbPromise = null;

/** 打开（或初始化）IndexedDB */
export function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const def of STORES) {
        let store;
        if (!db.objectStoreNames.contains(def.name)) {
          store = db.createObjectStore(def.name, { keyPath: def.keyPath });
        } else {
          store = req.transaction.objectStore(def.name);
        }
        for (const [indexName, keyPath] of def.indexes || []) {
          if (!store.indexNames.contains(indexName)) store.createIndex(indexName, keyPath, { unique: false });
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('IndexedDB 打开失败'));
    req.onblocked = () => reject(new Error('IndexedDB 被其它标签页占用'));
  });
  return dbPromise;
}

function wrapRequest(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('IndexedDB 请求失败'));
  });
}
async function txDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('事务失败'));
    tx.onabort = () => reject(tx.error || new Error('事务中止'));
  });
}

export async function put(storeName, record) {
  const db = await openDB();
  const tx = db.transaction(storeName, 'readwrite');
  tx.objectStore(storeName).put(record);
  await txDone(tx);
  return record;
}
export async function get(storeName, key) {
  const db = await openDB();
  return wrapRequest(db.transaction(storeName, 'readonly').objectStore(storeName).get(key));
}
export async function getAll(storeName) {
  const db = await openDB();
  return wrapRequest(db.transaction(storeName, 'readonly').objectStore(storeName).getAll());
}
export async function getAllByProject(storeName, projectId) {
  const db = await openDB();
  const store = db.transaction(storeName, 'readonly').objectStore(storeName);
  return wrapRequest(store.index('projectId').getAll(projectId));
}
export async function del(storeName, key) {
  const db = await openDB();
  const tx = db.transaction(storeName, 'readwrite');
  tx.objectStore(storeName).delete(key);
  await txDone(tx);
}

/* ---------------- 项目元数据 ---------------- */
export function projectSnapshot() {
  return {
    id: state.projectId,
    name: state.projectName,
    width: 1200,
    height: 800,
    mode: state.mode,
    aiRole: state.aiRole,
    activeLayerId: state.activeLayerId,
    layerOrder: state.layers.map((l) => l.id),
    strokeCount: state.strokeCount,
    selection: state.selection,
    modeStartedAt: state.modeStartedAt,
    createdAt: state.projectCreatedAt || nowIso(),
    updatedAt: nowIso(),
    appVersion: APP_VERSION,
    schemaVersion: SCHEMA_VERSION
  };
}
export async function saveProjectMeta() {
  if (!state.projectId) return null;
  const project = projectSnapshot();
  await put('projects', project);
  await saveMeta('lastProjectId', state.projectId);
  return project;
}
export async function listProjects() {
  const rows = await getAll('projects');
  return rows.sort((a, b) => String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')));
}

/* ---------------- 图层位图 ---------------- */
export async function saveLayerRecord(layerRecord) {
  await put('layers', layerRecord);
}
export async function loadLayerRecords(projectId) {
  const rows = await getAllByProject('layers', projectId);
  return rows.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
}
export async function deleteLayerRecord(layerId) {
  await del('layers', layerId);
}

/* ---------------- 档案记录 ---------------- */
export async function saveArchiveRecord(record) {
  await put('archive_records', { ...record, key: `${record.asset_id}:${record.id}`, projectId: state.projectId });
}
export async function loadArchiveRecords(projectId) {
  const rows = await getAllByProject('archive_records', projectId);
  return rows.sort((a, b) => String(a.created_at || '').localeCompare(String(b.created_at || '')));
}

/* ---------------- 事件链 / L6 ---------------- */
export async function saveEventRecord(event) {
  await put('events', { ...event, key: `${state.projectId}:${event.seq}`, projectId: state.projectId });
}
export async function loadEventRecords(projectId) {
  const rows = await getAllByProject('events', projectId);
  return rows.sort((a, b) => a.seq - b.seq);
}
export async function saveGenerationRecord(record) {
  await put('generations', { ...record, key: `${state.projectId}:${record.id}`, projectId: state.projectId });
}
export async function loadGenerationRecords(projectId) {
  const rows = await getAllByProject('generations', projectId);
  return rows.sort((a, b) => String(a.created_at || '').localeCompare(String(b.created_at || '')));
}

/* ---------------- meta / 清空 ---------------- */
export async function saveMeta(key, value) { await put('meta', { key, value }); }
export async function loadMeta(key) {
  const row = await get('meta', key);
  return row ? row.value : null;
}
export async function clearAllData() {
  const db = await openDB();
  const names = STORES.map((s) => s.name);
  const tx = db.transaction(names, 'readwrite');
  for (const n of names) tx.objectStore(n).clear();
  await txDone(tx);
}

/* ---------------- dataURL ↔ Blob（避免网络请求） ---------------- */
export function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error('读取 Blob 失败'));
    reader.readAsDataURL(blob);
  });
}
export function dataUrlToBlob(dataUrl) {
  const [head, body] = String(dataUrl).split(',');
  const mime = (head.match(/data:([^;]+)/) || [])[1] || 'image/png';
  const binary = atob(body || '');
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

/* ---------------- 项目导出 / 导入（JSON 往返） ---------------- */
export async function exportProjectJson() {
  const projectId = state.projectId;
  const project = (await get('projects', projectId)) || projectSnapshot();
  const layers = await loadLayerRecords(projectId);
  const archive = await loadArchiveRecords(projectId);
  const events = await loadEventRecords(projectId);
  const generations = await loadGenerationRecords(projectId);
  const layersOut = [];
  for (const layer of layers) {
    const dataUrl = layer.blob ? await blobToDataUrl(layer.blob) : null;
    layersOut.push({ ...layer, blob: undefined, dataUrl });
  }
  return {
    format: 'inkproof.project',
    format_version: 1,
    exported_at: nowIso(),
    app_version: APP_VERSION,
    schema_version: SCHEMA_VERSION,
    project,
    layers: layersOut,
    archive_records: archive,
    events,
    generations
  };
}

export async function importProjectJson(json) {
  if (!json || json.format !== 'inkproof.project') throw new Error('不是有效的 InkProof 项目文件');
  if (!Array.isArray(json.layers) || !Array.isArray(json.events)) throw new Error('项目文件缺少 layers/events');
  await clearAllData();
  const projectId = uid('project');
  const idMap = new Map();
  const project = { ...json.project, id: projectId, updatedAt: nowIso() };
  await put('projects', project);
  // 图层
  const layers = [];
  for (let i = 0; i < json.layers.length; i += 1) {
    const layer = json.layers[i];
    const newId = uid('layer');
    idMap.set(layer.id, newId);
    const blob = layer.dataUrl ? dataUrlToBlob(layer.dataUrl) : null;
    const rec = {
      id: newId, projectId, name: layer.name, kind: layer.kind,
      visible: layer.visible !== false, opacity: layer.opacity ?? 1,
      offset: layer.offset || { x: 0, y: 0 }, bbox: layer.bbox || null,
      aiMeta: layer.aiMeta || null, order: i, createdAt: layer.createdAt || nowIso(), blob
    };
    await put('layers', rec);
    layers.push(rec);
  }
  // 档案（保留原记录 id；asset_id 保持原样——v0.1 单项目场景）
  for (const record of json.archive_records || []) {
    await put('archive_records', { ...record, projectId });
  }
  // 事件（保留链；seq/hash 原样）
  for (const event of json.events || []) {
    await put('events', { ...event, projectId, key: `${projectId}:${event.seq}` });
  }
  for (const gen of json.generations || []) {
    await put('generations', { ...gen, projectId, key: `${projectId}:${gen.id}` });
  }
  await saveMeta('lastProjectId', projectId);
  return { projectId, layerIdMap: idMap };
}

/** 关闭数据库连接（清空数据前调用；页面重载自动恢复） */
export async function closeDB() {
  if (!dbPromise) return;
  const db = await dbPromise.catch(() => null);
  if (db) db.close();
  dbPromise = null;
}
