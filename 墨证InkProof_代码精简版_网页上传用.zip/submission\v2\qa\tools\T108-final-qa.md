# T108 最终独立 QA：对称 undo 合并 + 网格/三分线/变换吸附

> 执行：qa-engineer（独立 QA｜task-116）｜日期：2026-11-07 19:5x｜只写 `v2/qa/tools/`；**未改 app**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、单浏览器串行、小批次（每批 1–3 个，日志落盘 `archive/baseline-t108-final/logs/`）。

## 结论

**可交付（Deliverable）——P0/P1/P2 = 0。**
Lead 本轮修复/新增全部独立复核通过：对称 undo 合并（x/y/both 均 1 步）、普通画笔历史未被 mergeTop 破坏、网格/三分线吸附与 transform 拖拽吸附均按预期；T107 遗留的「形状吸附记录 1px 偏差」已关闭（本轮记录精确 `x=240/y=160`）。真实证据无变化，**未新增付费调用**。

## 1. 新功能测试（全部 PASS）

| 测试 | 结果 | 关键证据 |
|---|---|---|
| `test-symmetry.mjs` | **PASS** | `undoDelta=1`（steps 0→1）；leftInk **533**、rightInk **864**；单次 undo 后左右墨迹 **0/0**；0 error |
| `test-shape-snap.mjs` | **PASS** | `shape_inserted` 记录 **x=240、y=160**、w=h=80、anchor `[240,160,80,80]`；`snapDocPoint` 网格 **(240,160)**、三分线 **(400,266.667=800/3)**；0 error |

## 2. 重点独立核验（QA 自建探针，全部 PASS）

### 2.1 对称 x / y / both 的 history 步数 + undo 归零
| 轴 | steps 增量 | 新增墨（lt/rt/lb/rb） | 单次 undo 后（lt/rt/lb/rb） |
|---|---|---|---|
| x | **1** | 1080 / 808 / 0 / 0 | 0 / 0 / 0 / 0 ✅ |
| y | **1** | 816 / 0 / 809 / 0 | 0 / 0 / 0 / 0 ✅ |
| both | **1** | 824 / 809 / 809 / 855 | 0 / 0 / 0 / 0 ✅ |
| 关闭对称 | — | 824 / 0 / 0 / 0 | **不重放**（仅原笔迹半区）✅ |

> `UndoManager.mergeTop` 生效：x/y/both 不再分别占 2/4 步，均合并为 **1 步**。

### 2.2 普通画笔历史（确保 mergeTop 未破坏）
| 检查 | 结果 |
|---|---|
| 单笔 undo 步数增量 | **1** ✅ |
| 第二笔 undo 步数增量 | **1**（未错误合并成 1 笔）✅ |
| undo 后像素 diff（vs 画前） | **0** ✅ |
| redo 后像素 diff（vs 画后） | **0** ✅ |

### 2.3 transform 拖拽吸附
| 场景 | 结果 |
|---|---|
| 网格（showGrid）：拖到 doc≈(241,161) | transform 中心位移 **(-22.5,-83.5)** = 按吸附点 (240,160) 的期望值（未吸附应为 -21.5/-82.5）✅ |
| 三分线（showThirds）：拖到 doc≈(397,269) | 位移 **(160,106.667)** = 按吸附点 (400,266.667) 的期望值 ✅ |

### 2.4 其它
- 密钥：config GET 仅 `hasKey/keyLast4`（`configMasked=true`），无泄漏。
- 0 console error（QA 探针全程）。

## 3. 模块单测（Node-only，全部 PASS）

`guides-test` **124 断言**、`asset-batch-test` **11/11**、`asset-ai-test` **10/10**、`editor-ops-test` **77 断言**、`skill-runtime-test` **PASS**。

## 4. 回归（全部 PASS，0 console error）

test-app、test-ui、test-text-edit、test-guides、test-editor-basics、test-mask-compare、test-editor-ui、test-ux-p0、test-ai-provider、test-interaction-sequences（**9/9**）、test-asset-batch、test-symmetry、test-shape-snap —— 逐项小批次复跑，exit 0、errors 0。

## 5. 真实证据核对（未新增付费调用）

| 证据 | 核对 |
|---|---|
| `asset-real-read-results.json`（17:12，未更新） | pass=true；**22,955ms**；real / qwen3.8-max / latency 22,225ms / **L2=5、L4=4** ✅ |
| `qwen-real-e2e-results.json`（16:53，未更新） | pass=true；**21,337ms**；obs=2、regions=2、mock=false、real_calls=1 ✅ |
| 新增付费调用 | **0**（两证据 mtime 未变，仅核对） |

## 6. 密钥 / 残留 / 稳定性

- 密钥：无 DOM/localStorage/sessionStorage/已加载 JS 泄漏；config 脱敏；未打印 key。
- 残留：**Edge 0、测试端口 0**（每批后清理，含一次瞬时监听端口已被确认关闭）。
- 稳定性：单浏览器串行、小批次；无 OOM/超时。

## 7. 问题清单

| # | 级别 | 问题 | 状态 |
|---|---|---|---|
| — | — | P0 / P1 / P2 | **均无** |
| — | ~~P2~~ | T107 遗留：形状吸附记录 1px 偏差（239/159） | **已关闭**：本轮 `shape_inserted` 精确 x=240/y=160 ✅ |

## 8. 产物与归档

- `v2/qa/tools/T108-final-qa.md`（本报告）
- `v2/qa/tools/archive/baseline-t108-final/`：`logs/`（全部原始输出）、各 result JSON、`focus-results.json`（对称/画笔/transform/密钥 4 项核验）、`qwen-real-e2e-results.json`、`asset-real-read-results.json`、README
- GATE：`v2/qa/tools/GATE-pw.md`「T108-F 最终独立 QA」行
