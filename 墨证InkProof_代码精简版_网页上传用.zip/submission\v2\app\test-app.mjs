// v2/app/test-app.mjs — T40 冒烟 + T41 provider 回归（零依赖 CDP）
// 1) engine 默认 provider：v2/engine/demo.html 绘制/undo
// 2) 自定义 provider：v2/brushes/demo.html 10 笔刷（由 test-demo.mjs 覆盖，这里复核 init）
// 3) v2/app：初始化 → 画笔绘制 → 图层 → AI 框选/观察/方向/生成落层 → 档案 → 证据包 → 存证模式 → 演示
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const PORT_HTTP = 8101;
const PORT_CDP = 9407;
const python = spawn('python', ['-m', 'http.server', String(PORT_HTTP), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
await sleep(900);
const profile = path.join(os.tmpdir(), 'apptest-' + Date.now());
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist',
  '--window-size=1680,1000', '--hide-scrollbars',
  `--remote-debugging-port=${PORT_CDP}`, `--user-data-dir=${profile}`, 'about:blank',
], { stdio: 'ignore' });
let target = null;
for (let i = 0; i < 200 && !target; i++) {
  try { const r = await fetch(`http://127.0.0.1:${PORT_CDP}/json/list`); target = (await r.json()).find((t) => t.type === 'page'); } catch (e) {}
  if (!target) await sleep(150);
}
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map(); const errors = [];
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); return; }
  if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text);
  if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push(m.params.args.map((a) => a.value || a.description).join(' '));
};
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
async function ev(expression) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true });
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1400));
  return r.result?.result?.value;
}
async function nav(url) { await send('Page.navigate', { url }); }
async function waitFor(expr, timeoutMs = 120000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) { if (await ev(expr).catch(() => false)) return true; await sleep(250); }
  return false;
}
const report = {};
try {
  await send('Runtime.enable'); await send('Page.enable');
  // ---- 1) engine 默认 provider 回归 ----
  await nav(`http://127.0.0.1:${PORT_HTTP}/v2/engine/demo.html`);
  if (!await waitFor('!!window.__V2_READY__')) throw new Error('engine demo 未就绪');
  report.defaultProvider = await ev(`(async () => {
    const e = window.__V2__;
    const before = e.getStats().undoDepth;
    e.beginStroke({ x: 300, y: 300, pressure: 0.7, timestamp: performance.now() });
    for (let i = 1; i <= 20; i++) e.appendPoint({ x: 300 + i * 15, y: 300 + Math.sin(i / 3) * 30, pressure: 0.6, timestamp: performance.now() + i * 16 });
    e.endStroke();
    const afterDraw = e.getStats();
    e.undo();
    const afterUndo = e.getStats();
    return { provider: e.getBrushProvider().id, undoBefore: before, undoAfterDraw: afterDraw.undoDepth, undoAfterUndo: afterUndo.undoDepth, tiles: afterDraw.tileCount };
  })()`);
  // ---- 2) 自定义 provider demo（T36）----
  await nav(`http://127.0.0.1:${PORT_HTTP}/v2/brushes/demo.html`);
  if (!await waitFor('!!window.__BRUSH_READY__')) throw new Error('brush demo 未就绪');
  report.customProvider = await ev(`(async () => {
    const d = window.__BRUSH_DEMO__; const e = d.engine;
    const out = [];
    for (let bi = 0; bi < d.presets.brushes.length; bi++) {
      d.controller.setPreset(d.presets.brushes[bi]);
      const y = 120 + bi * 70;
      d.controller.begin({ x: 120, y, pressure: 0.75, timestamp: performance.now() });
      for (let i = 1; i <= 14; i++) d.controller.append({ x: 120 + i * 30, y: y + Math.sin(i / 3) * 14, pressure: 0.6, timestamp: performance.now() + i * 16 });
      d.controller.end();
      out.push({ id: d.presets.brushes[bi].id, tiles: e.getStats().tileCount });
    }
    const draws = e.getStats();
    const undoOk = e.canUndo();
    e.undo();
    return { count: out.length, ids: out.map(o => o.id), provider: e.getBrushProvider().id, tiles: draws.tileCount, undoDepth: draws.undoDepth, canUndo: undoOk, afterUndo: e.getStats().undoDepth };
  })()`);
  // ---- 3) v2/app 冒烟 ----
  await nav(`http://127.0.0.1:${PORT_HTTP}/v2/app/index.html`);
  if (!await waitFor('!!window.__V2_APP_READY__', 180000)) throw new Error('v2 app 未就绪：' + await ev('document.querySelector("#statusHint")?.textContent || "?"'));
  report.appInit = await ev(`(() => ({ threads: window.__V2_APP__.state.records.length, layers: window.__V2_APP__.engine.layers.length, title: document.title, status: document.querySelector('#statusHint').textContent }))()`);
  report.appDraw = await ev(`(async () => {
    const { controller, engine, state } = window.__V2_APP__;
    controller.begin({ x: 200, y: 240, pressure: 0.8, timestamp: performance.now() });
    for (let i = 1; i <= 30; i++) controller.append({ x: 200 + i * 22, y: 240 + Math.sin(i / 5) * 60, pressure: 0.7, timestamp: performance.now() + i * 16 });
    controller.end();
    return { tiles: engine.getStats().tileCount, undo: engine.getStats().undoDepth, strokes: state.strokes };
  })()`);
  report.appAddLayer = await ev(`(() => { document.getElementById('btnAddLayer').click(); return window.__V2_APP__.engine.layers.length; })()`);
  report.appAnalyze = await ev(`(async () => {
    const { state } = window.__V2_APP__;
    state.selection = { x: 360, y: 220, width: 520, height: 380 };
    const r = await window.__V2_APP__.runAnalyze();
    return { observations: r ? r.observations.length : 0, regions: r ? r.regions.length : 0, records: state.records.length };
  })()`);
  report.appConfirm = await ev(`(async () => {
    const { state, confirmObservation } = window.__V2_APP__;
    const obs = state.analysis.observations[0];
    confirmObservation(obs.id, true);
    return { l5: state.records.filter(r => r.layer === 'L5').length, confirmed: state.records.find(r => r.id === obs.id).source };
  })()`);
  report.appGenerate = await ev(`(async () => {
    const { state, runDirections, runGenerate, applyCandidate } = window.__V2_APP__;
    await runDirections();
    await runGenerate(state.directions[0].id);
    await applyCandidate(0);
    return { dirs: state.directions.length, candidates: state.candidates.length, layers: window.__V2_APP__.engine.layers.length, l6: state.records.filter(r => r.layer === 'L6').length };
  })()`);
  report.appEvidence = await ev(`(async () => {
    const pkg = await window.__V2_APP__.buildEvidence();
    return { events: pkg.events.length, head: pkg.manifest.head_hash.slice(0, 12), layers: pkg.manifest.layers.length, zero: pkg.manifest.attest.zero_generation, hasPng: !!pkg.canvas_png_data_url };
  })()`);
  report.appAttest = await ev(`(() => { document.getElementById('btnToggleAttest').click(); return { mode: window.__V2_APP__.state.mode, disabled: document.getElementById('btnAskAi').disabled }; })()`);
  await ev(`(() => { const b = document.getElementById('btnToggleAttest'); if (window.__V2_APP__.state.mode === 'attest') b.click(); })()`);
  report.appDemo = await ev(`(async () => {
    document.getElementById('btnDemo').click();
    await new Promise(r => setTimeout(r, 1500));
    const active = document.getElementById('demoBar').style.display !== 'none';
    document.getElementById('btnDemoExit').click();
    await new Promise(r => setTimeout(r, 800));
    return { started: active, exited: document.getElementById('demoBar').style.display === 'none' };
  })()`);
  // ---- 持久化：刷新后档案与快照恢复 ----
  const beforeReload = await ev('({ records: window.__V2_APP__.state.records.length, layers: window.__V2_APP__.engine.layers.length })');
  await send('Page.reload');
  if (!await waitFor('!!window.__V2_APP_READY__', 180000)) throw new Error('刷新后 app 未就绪');
  await sleep(800);
  const afterReload = await ev('({ records: window.__V2_APP__.state.records.length, layers: window.__V2_APP__.engine.layers.length, snapshotLayer: window.__V2_APP__.engine.layers.some(l => l.name.includes("恢复快照")) })');
  const canvasUrl = await ev('(async () => { const e = window.__V2_APP__.engine; e.compositor.compositeAll(e.store); return await e.getCompositeDataUrl(); })()');
  try { fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'app-canvas.png'), Buffer.from(canvasUrl.split(',')[1], 'base64')); } catch (e) { /* ignore */ }
  report.appPersist = { beforeReload, afterReload, canvasPngBytes: Math.round((canvasUrl || '').length * 0.75) };

  const shot = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'app-screenshot.png'), Buffer.from(shot.result.data, 'base64'));
  report.errors = errors.slice(0, 10);
  fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'test-result.json'), JSON.stringify(report, null, 2), 'utf8');
  console.log(JSON.stringify(report, null, 2));
  console.log('screenshot:', path.join(ROOT, 'v2', 'app', 'app-screenshot.png'));
} catch (e) {
  report.fatal = String(e.stack || e);
  report.errors = errors.slice(0, 10);
  try { fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'test-result.json'), JSON.stringify(report, null, 2), 'utf8'); } catch (e2) { /* ignore */ }
  console.log('FATAL', e.stack || e);
  console.log('errors:', JSON.stringify(errors.slice(0, 10)));
} finally {
  try { ws.close(); } catch (e) {}
  chrome.kill(); python.kill();
  await sleep(500);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
  process.exit(0);
}
