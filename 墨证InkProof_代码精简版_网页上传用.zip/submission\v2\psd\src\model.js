/**
 * v2/psd · 文档模型与工具
 * v2 图层模型（与 T37 的 LayerSystem 元数据对齐；像素用 HTMLCanvasElement）：
 *   Doc { width,height,colorMode,bitsPerChannel,children:Node[],unsupported:[] }
 *   Node { type:'layer'|'group', name, visible, opacity(0–1), blendMode(internal),
 *          clip, mask:canvas|null, canvas:canvas|null, children:Node[], features:string[] }
 */
export const PSD_TO_INTERNAL = {
  'pass through': 'passThrough',
  normal: 'normal', dissolve: 'dissolve',
  darken: 'darken', multiply: 'multiply', 'color burn': 'color-burn', 'linear burn': 'linear-burn', 'darker color': 'darker-color',
  lighten: 'lighten', screen: 'screen', 'color dodge': 'color-dodge', 'linear dodge': 'linear-dodge', 'lighter color': 'lighter-color',
  overlay: 'overlay', 'soft light': 'soft-light', 'hard light': 'hard-light', 'vivid light': 'vivid-light', 'linear light': 'linear-light', 'pin light': 'pin-light', 'hard mix': 'hard-mix',
  difference: 'difference', exclusion: 'exclusion', subtract: 'subtract', divide: 'divide',
  hue: 'hue', saturation: 'saturation', color: 'color', luminosity: 'luminosity',
};

export const INTERNAL_TO_PSD = Object.fromEntries(Object.entries(PSD_TO_INTERNAL).map(([k, v]) => [v, k]));

/** T37 LayerSystem 支持的混合模式（16 种内部名） */
export const LAYERS_SUPPORTED = new Set([
  'normal', 'dissolve', 'darken', 'multiply', 'color-burn', 'lighten', 'screen', 'color-dodge',
  'overlay', 'soft-light', 'hard-light', 'difference', 'exclusion', 'hue', 'saturation', 'color', 'luminosity',
]);

export const COLOR_MODES = { 0: 'Bitmap', 1: 'Grayscale', 2: 'Indexed', 3: 'RGB', 4: 'CMYK', 7: 'Multichannel', 8: 'Duotone', 9: 'Lab' };
export const COLOR_MODE_RGB = 3;

export function createCanvas(width, height) {
  const c = document.createElement('canvas');
  c.width = width;
  c.height = height;
  return c;
}

export function cloneCanvas(src) {
  if (!src) return null;
  const c = createCanvas(src.width, src.height);
  c.getContext('2d').drawImage(src, 0, 0);
  return c;
}

export function createDoc(width, height, opts = {}) {
  return {
    schema: 'mozheng.v2.doc',
    width,
    height,
    colorMode: opts.colorMode || 'RGB',
    bitsPerChannel: opts.bitsPerChannel || 8,
    children: [],
    unsupported: [],
    source: opts.source || null,
  };
}

/** 把 ag-psd 的（可能被裁剪的）层 canvas 归一化到整画布坐标 */
export function normalizeLayerCanvas(layerCanvas, layer, width, height) {
  if (!layerCanvas) return null;
  const c = createCanvas(width, height);
  const ctx = c.getContext('2d');
  ctx.drawImage(layerCanvas, layer.left || 0, layer.top || 0);
  return c;
}

/** 蒙版 canvas 归一化：透明=隐藏，白色 alpha=可见（defaultColor 255 时铺白底） */
export function normalizeMaskCanvas(mask, width, height) {
  if (!mask || !mask.canvas) return null;
  const c = createCanvas(width, height);
  const ctx = c.getContext('2d');
  if (mask.defaultColor === 255) {
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, width, height);
  }
  const left = mask.left != null ? mask.left : (mask.positionRelativeToLayer ? 0 : 0);
  const top = mask.top != null ? mask.top : (mask.positionRelativeToLayer ? 0 : 0);
  ctx.drawImage(mask.canvas, left, top);
  return c;
}

export function clamp01(v) {
  if (!Number.isFinite(v)) return 1;
  return Math.max(0, Math.min(1, v));
}

export function internalBlendForLayers(blendMode) {
  return LAYERS_SUPPORTED.has(blendMode) ? blendMode : 'normal';
}

/** 统计文档结构（用于保真报告） */
export function docStats(doc) {
  let layers = 0, groups = 0, masks = 0, maxDepth = 0;
  function walk(nodes, depth) {
    maxDepth = Math.max(maxDepth, depth);
    for (const n of nodes) {
      if (n.type === 'group') { groups += 1; walk(n.children || [], depth + 1); } else layers += 1;
      if (n.mask) masks += 1;
    }
  }
  walk(doc.children || [], 0);
  return { layers, groups, masks, maxDepth };
}
