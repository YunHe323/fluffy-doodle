#!/usr/bin/env node
// v2/qa/tools/verify-evidence-integration.mjs —— 用真实 app 生成证据包，再用第三方复核器校验
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from '../node_modules/playwright-core/index.mjs';
import { verifyEvidence } from './verify-evidence.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..', '..', '..');
const PORT = 8145;
const results = { schema: 'mozheng.qa.verify-evidence-integration.v1', cases: {}, pass: false, errors: [] };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  await fs.promises.writeFile(path.join(__dirname, 'verify-evidence-integration-results.json'), JSON.stringify(results, null, 2), 'utf8');
  process.exit(code);
};
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon/i.test(m.text())) results.errors.push(m.text()); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(800);
  const pkg = await page.evaluate(async () => {
    const app = window.__V2_APP__;
    await app.runAnalyze().catch(() => null);
    const canvas = await app.engine.getCompositeDataUrl();
    return await app.buildEvidence({ canvasDataUrl: canvas });
  });
  const verify = await verifyEvidence(pkg);
  results.cases.verify = { ok: verify.ok, checks: verify.checks, errors: verify.errors, summary: verify.summary };
  results.cases.aiManifest = { present: !!(pkg.manifest && pkg.manifest.ai), calls: pkg.manifest && pkg.manifest.ai ? pkg.manifest.ai.calls : null, providers: pkg.manifest && pkg.manifest.ai ? pkg.manifest.ai.providers : null };
  const tampered = JSON.parse(JSON.stringify(pkg));
  tampered.events[0].text = (tampered.events[0].text || '') + '（篡改）';
  const verifyTampered = await verifyEvidence(tampered);
  results.cases.tampered = { ok: verifyTampered.ok, expectedFail: !verifyTampered.ok, errors: verifyTampered.errors };
  results.cases.noConsoleErrors = { ok: results.errors.length === 0 };
  results.pass = verify.ok === true && verifyTampered.ok === false
    && results.cases.aiManifest.present === true && results.cases.aiManifest.calls >= 1
    && results.cases.noConsoleErrors.ok === true;
  await finish(results.pass ? 0 : 1);
} catch (e) {
  results.fatal = String(e && e.stack || e);
  await finish(3);
}
