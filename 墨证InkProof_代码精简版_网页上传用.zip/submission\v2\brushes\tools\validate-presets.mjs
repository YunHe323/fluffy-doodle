#!/usr/bin/env node
// v2/brushes/tools/validate-presets.mjs
// 零依赖校验器：用最小 JSON Schema 子集校验 presets/defaults.json + 纹理清单一致性。
// 用法：node v2/brushes/tools/validate-presets.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BRUSH_DIR = path.resolve(HERE, '..');
const SCHEMA = JSON.parse(fs.readFileSync(path.join(BRUSH_DIR, 'schema', 'brush.schema.json'), 'utf8'));
const PRESETS = JSON.parse(fs.readFileSync(path.join(BRUSH_DIR, 'presets', 'defaults.json'), 'utf8'));
const MANIFEST = JSON.parse(fs.readFileSync(path.join(BRUSH_DIR, 'textures', 'manifest.json'), 'utf8'));

const errors = [];
const fail = (p, msg) => errors.push(`${p}: ${msg}`);

function typeOf(v) {
  if (v === null) return 'null';
  if (Array.isArray(v)) return 'array';
  if (Number.isInteger(v)) return 'integer';
  return typeof v;
}

function resolveRef(ref) {
  if (!ref.startsWith('#/')) throw new Error('unsupported $ref: ' + ref);
  return ref.slice(2).split('/').reduce((o, k) => o && o[k.replace(/~1/g, '/').replace(/~0/g, '~')], SCHEMA);
}

function validate(value, schema, p) {
  if (!schema || typeof schema !== 'object') return;
  if (schema.$ref) return validate(value, resolveRef(schema.$ref), p);
  const types = schema.type ? (Array.isArray(schema.type) ? schema.type : [schema.type]) : null;
  if (types) {
    const actual = typeOf(value);
    const ok = types.some((t) => t === actual || (t === 'number' && (actual === 'number' || actual === 'integer')));
    if (!ok) return fail(p, `expected ${types.join('|')}, got ${actual} (${JSON.stringify(value).slice(0, 40)})`);
  }
  if (schema.enum) {
    const ok = schema.enum.some((e) => JSON.stringify(e) === JSON.stringify(value));
    if (!ok) fail(p, `expected one of ${JSON.stringify(schema.enum)}, got ${JSON.stringify(value)}`);
  }
  if (typeof value === 'number') {
    if (schema.minimum != null && value < schema.minimum) fail(p, `value ${value} < minimum ${schema.minimum}`);
    if (schema.maximum != null && value > schema.maximum) fail(p, `value ${value} > maximum ${schema.maximum}`);
  }
  if (typeof value === 'string') {
    if (schema.minLength != null && value.length < schema.minLength) fail(p, `length ${value.length} < ${schema.minLength}`);
    if (schema.maxLength != null && value.length > schema.maxLength) fail(p, `length ${value.length} > ${schema.maxLength}`);
    if (schema.pattern && !new RegExp(schema.pattern).test(value)) fail(p, `"${value}" does not match ${schema.pattern}`);
  }
  if (Array.isArray(value)) {
    if (schema.minItems != null && value.length < schema.minItems) fail(p, `array length ${value.length} < ${schema.minItems}`);
    if (schema.maxItems != null && value.length > schema.maxItems) fail(p, `array length ${value.length} > ${schema.maxItems}`);
    if (schema.uniqueItems && new Set(value.map((v) => JSON.stringify(v))).size !== value.length) fail(p, 'array items not unique');
    if (schema.items) value.forEach((v, i) => validate(v, schema.items, `${p}[${i}]`));
  }
  if (typeOf(value) === 'object') {
    for (const req of schema.required || []) if (!(req in value)) fail(p, `missing required "${req}"`);
    const props = schema.properties || {};
    for (const [k, v] of Object.entries(value)) {
      if (props[k]) validate(v, props[k], `${p}.${k}`);
      else if (schema.additionalProperties === false) fail(p, `unexpected property "${k}"`);
    }
  }
}

function checkCurve(curve, p) {
  if (!Array.isArray(curve) || curve.length !== 5) return fail(p, 'pressureCurve must have exactly 5 numbers');
  if (!curve.every((v) => typeof v === 'number' && v >= 0 && v <= 1)) return fail(p, 'pressureCurve values must be 0..1');
  for (let i = 1; i < curve.length; i++) if (curve[i] < curve[i - 1]) fail(p, 'pressureCurve must be non-decreasing');
}

const ids = new Set();
const assetIds = new Set(MANIFEST.assets.map((a) => a.id));
if (PRESETS.brushes.length !== 11) fail('presets', `expected 11 brushes (10 paint/eraser + T62 smudge), got ${PRESETS.brushes.length}`);
for (const [i, brush] of PRESETS.brushes.entries()) {
  const p = `brushes[${i}](${brush.id || '?'})`;
  validate(brush, SCHEMA, p);
  if (ids.has(brush.id)) fail(p, `duplicate id "${brush.id}"`);
  ids.add(brush.id);
  checkCurve(brush.size?.pressureCurve, `${p}.size.pressureCurve`);
  checkCurve(brush.opacity?.pressureCurve, `${p}.opacity.pressureCurve`);
  checkCurve(brush.flow?.pressureCurve, `${p}.flow.pressureCurve`);
  const assetId = brush.texture?.assetId;
  if (assetId != null && !assetIds.has(assetId)) fail(`${p}.texture.assetId`, `"${assetId}" not in textures/manifest.json`);
  if (brush.texture?.assetId) {
    const file = path.join(BRUSH_DIR, 'textures', MANIFEST.assets.find((a) => a.id === assetId).file);
    if (!fs.existsSync(file)) fail(`${p}.texture.assetId`, `texture file missing: ${file}`);
  }
}
for (const asset of MANIFEST.assets) {
  const file = path.join(BRUSH_DIR, 'textures', asset.file);
  if (!fs.existsSync(file)) fail('textures.manifest', `missing file ${asset.file}`);
}

if (errors.length) {
  console.error(`✗ validate failed: ${errors.length} error(s)`);
  for (const e of errors) console.error('  - ' + e);
  process.exit(1);
}
const usedTextures = new Set(PRESETS.brushes.map((b) => b.texture?.assetId).filter(Boolean));
console.log(`✓ validate ok: ${PRESETS.brushes.length} brushes, ${ids.size} unique ids, ${usedTextures.size}/${MANIFEST.assets.length} textures used, curves valid`);
