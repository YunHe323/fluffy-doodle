/**
 * v2/engine/examples/brush-controller-adapter.js
 *
 * T41 适配示例：把 T36 的「笔刷预设 + 动态参数」接入引擎的 StrokePaintProvider 注入点，
 * 不再子类化 `v2/engine/src/stroke.js` 的 Stroke。
 *
 * 分工建议：
 * - T36 `BrushController` 仍负责 **输入预处理**（稳定化、间距重采样、散点/抖动、taper 计算），
 *   把处理后的点通过 `engine.beginStroke / appendPoint / endStroke` 提交；
 * - 本 Provider 负责 **每 stamp 的 radius / paint / stamp**（压力、速度、倾斜、硬度、纹理）。
 *
 * 示例只覆盖 hard/soft/动态尺寸/动态透明度/硬度；纹理与 eraser 需要 T36 自己的
 * CanvasKit shader/colorFilter 逻辑（在 paintFor 里返回对应的 Paint 即可）。
 */
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;

/** 5 点压力曲线（与 T36 brush-controller.js 的 curveAt 语义一致） */
function curveAt(curve, t) {
  if (!curve || curve.length !== 5) return clamp(t, 0, 1);
  const x = clamp(t, 0, 1) * 4;
  const i = Math.min(3, Math.floor(x));
  return lerp(curve[i], curve[i + 1], x - i);
}

/**
 * @param {object} preset T36 预设（presets/defaults.json 中的一项）
 * @param {{color?:{r:number,g:number,b:number}, textures?:any, texture?:any}} [opts]
 * @returns {object} StrokePaintProvider
 */
export function createProviderFromPreset(preset, opts = {}) {
  if (!preset || !preset.size) throw new Error('createProviderFromPreset: 需要 T36 预设');
  const color = opts.color || { r: 31, g: 35, b: 40 };
  let CK = null;
  const paints = new Map();
  const masks = new Map();

  function paintKey(presetId) { return presetId || preset.id || 'preset'; }

  return {
    id: `t36-${preset.id || 'preset'}`,
    name: preset.name || 'T36 preset',

    begin(ctx) {
      // 每次笔触开始时可重置 taper 等状态（若 T36 需要在引擎侧保存）
      this._strokeStartedAt = ctx.startTs;
    },

    radiusFor(ctx) {
      const pressure = clamp(ctx.pressure, 0, 1);
      let r = (preset.size.base * 0.5) * curveAt(preset.size.pressureCurve, pressure);
      const speedNorm = clamp(ctx.velocity / 2, 0, 1); // px/ms → 0–1（近似）
      const tiltNorm = Math.min(1, Math.hypot(ctx.tiltX || 0, ctx.tiltY || 0) / 90);
      const dyn = preset.dynamics || {};
      if (dyn.tiltSizeFactor) r *= 1 + dyn.tiltSizeFactor * tiltNorm * 0.6;
      if (dyn.speedSizeFactor) r *= 1 + dyn.speedSizeFactor * (speedNorm - 0.3);
      return Math.max(0.5, r);
    },

    paintFor(ctx) {
      const CKRef = CK;
      if (!CKRef) return null;
      const pressure = clamp(ctx.pressure, 0, 1);
      const key = paintKey(preset.id);
      let paint = paints.get(key);
      if (!paint) {
        paint = new CKRef.Paint();
        paint.setAntiAlias(true);
        paint.setStyle(CKRef.PaintStyle.Fill);
        paints.set(key, paint);
      }
      const speedNorm = clamp(ctx.velocity / 2, 0, 1);
      const tiltNorm = Math.min(1, Math.hypot(ctx.tiltX || 0, ctx.tiltY || 0) / 90);
      const dyn = preset.dynamics || {};
      let alpha = preset.opacity.base * curveAt(preset.opacity.pressureCurve, pressure);
      if (dyn.speedOpacityFactor) alpha *= 1 + dyn.speedOpacityFactor * (speedNorm - 0.3);
      if (dyn.tiltOpacityFactor) alpha *= 1 + dyn.tiltOpacityFactor * tiltNorm * 0.5;
      const hardness = clamp(preset.hardness.base + (preset.hardness.pressureFactor || 0) * (pressure - 0.5), 0, 1);
      const sigma = Math.max(0, 1 - hardness) * ctx.radius * 0.85;
      paint.setBlendMode(CKRef.BlendMode.SrcOver);
      paint.setColor(CKRef.Color(color.r, color.g, color.b, clamp(alpha, 0, 1)));
      if (sigma > 0.6) {
        const mk = sigma.toFixed(2);
        let mask = masks.get(mk);
        if (!mask) {
          mask = CKRef.MaskFilter.MakeBlur(CKRef.BlurStyle.Normal, sigma, true);
          masks.set(mk, mask);
        }
        paint.setMaskFilter(mask);
      } else {
        paint.setMaskFilter(null);
      }
      // 纹理：T36 可在 paint.setShader(...) / setColorFilter(...) 后返回同一个 paint
      return paint;
    },

    stampFor(ctx) {
      // 引擎已提供 canvas；缺省为画圆，T36 可以换成 drawImage/drawPath 等
      if (!ctx.paint) return;
      ctx.canvas.drawCircle(ctx.x, ctx.y, ctx.radius, ctx.paint);
    },

    end(ctx) { void ctx; },

    cancel(ctx) { void ctx; },

    dispose() {
      for (const p of paints.values()) { try { p.delete(); } catch (e) { /* ignore */ } }
      for (const m of masks.values()) { try { m.delete(); } catch (e) { /* ignore */ } }
      paints.clear();
      masks.clear();
      CK = null;
    },

    /** 引擎在第一次 stamp 前会把 CK 放进 ctx；也可由宿主注入 */
    bindCanvasKit(canvasKit) { CK = canvasKit; },
  };
}
