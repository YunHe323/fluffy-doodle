# v2 engine（M4.1）· CanvasKit + 256² tile 位图层

> 主路线：**CanvasKit / Skia WASM（BSD-3）** + 自建 tile 图层/输入/undo（用户 2026-11-06 已拍板）。
> 归属：T35（M4.1）｜实现计划：`06-技术/v2实现计划.md`｜选型：`06-技术/三路线选型对比.md` v1.3。

## 目录

```
v2/engine/
├─ demo.html              # 最小 demo：2048²、2 图层、硬/软笔刷、5 混合、undo/redo、缩放
├─ src/
│  ├─ loader.js           # 本地 vendor 加载（零外网）
│  ├─ tile-store.js       # 256² 稀疏 tile 存储（GPU RenderTarget + ImageSnapshot）
│  ├─ compositor.js       # 图层合成（normal/multiply/screen/overlay/soft-light）+ 脏区合成
│  ├─ stroke.js           # IStroke 笔触事务（begin/append/end、stamp、tile patch、Provider 注入）
│  ├─ brush-provider.js   # T41 默认笔刷 Provider（hard/soft）与 StrokePaintProvider 接口
│  ├─ input.js            # IInputSource（Pointer Events/coalesced/pressure/tilt/速度压感模拟）
│  ├─ undo.js             # IUndo：tile patch before/after 快照栈（80 步 / 200MB 上限）
│  └─ engine.js           # IEngine 实现 + 简易 benchmark（mozheng.bench.v1 兼容）
├─ examples/brush-controller-adapter.js  # T36 预设 → StrokePaintProvider 最小适配
├─ test/smoke.mjs         # 无头 Chrome CDP 冒烟测试（零依赖，含 provider 注入冒烟）
├─ test/live-preview.mjs  # T44 实时预览回归（拖动中内容保留/擦除/undo）
├─ vendor/                # CanvasKit 0.42.0（canvaskit.js/.wasm/LICENSE/package.json/index.d.ts）
└─ README.md              # 本文件
```

## 运行

> **P2（QA 002 §4）：file:// 直接打开检测横幅**
> 直接双击 `v2/engine/demo.html`（`file://`）时，浏览器会拦截 CanvasKit WASM / ES Module；页面会显示同款红色提示（样式与 app/brushes 一致）：说明原因，并给出 `v2\start.bat`、`node v2/serve.mjs`、`http://127.0.0.1:4200/v2/engine/demo.html` 三种打开方式。另有 15s 初始化超时 `#fatalBar`；通过 HTTP 打开时不显示横幅。
> 回归：`file://` 下 `#fileProtocolOverlay` 存在且可见；`http://` 下不存在且 `window.__V2_READY__=true`。

```powershell
# 仓库根目录
python -m http.server 8899 --bind 127.0.0.1
# 浏览器打开
# http://127.0.0.1:8899/v2/engine/demo.html
```

- 必须通过 HTTP 打开（WASM 不支持 `file://`）。
- 环境：Chrome/Edge（WebGL2 + WASM）。无外网请求；CanvasKit 全部从本地 `vendor/` 加载。
- 交互：画布拖动画笔；右侧切图层/混合/撤销；`Ctrl+Z` / `Ctrl+Shift+Z`；`[` `]` 调笔刷大小；`Ctrl+滚轮`缩放。

## 已实现（M4.1 骨架）

- ✅ **tile 位图层**：256² 稀疏分配，GPU `RenderTarget` + `ImageSnapshot`；图层元数据（名称/可见/不透明度/混合）。
- ✅ **合成器**：5 种混合模式（normal/multiply/screen/overlay/soft-light，saveLayer 图层隔离）；脏 tile 合成（只重绘受影响 tile）。
- ✅ **输入管线**：pen/mouse/touch；`getCoalescedEvents()` 批内逐点提交；pressure/tilt 透传；鼠标速度反压感模拟。
- ✅ **笔触事务**：`beginStroke/appendPoint/endStroke/cancelStroke`；实时 stamp 反馈 + 结束时写入 tile；每笔生成 undo patch。
- ✅ **撤销/重做**：tile patch before/after 快照；默认 80 步；内存上限 200MB（超限丢最旧）。
- ✅ **demo**：2048²、2 图层、硬/软笔刷、5 混合、undo/redo、缩放、PNG 导出、benchmark。
- ✅ **benchmark**：`engine.runBench()` 输出 `mozheng.bench.v1` 兼容对象（延迟/fps/tile/内存估算）。
- ✅ **笔刷注入点（T41）**：`setBrushProvider()/getBrushProvider()`；默认 provider 保持 hard/soft 观感，自定义笔刷无需子类化 `Stroke`。
- ✅ **实时预览修复（T44）**：离屏 live layer + 每帧确定性重绘；不再依赖 on-screen framebuffer 跨帧保留（修复「拖动中白板、停笔才出现」）；擦除笔刷 live 用图层隔离 + `DstOut`。

## 实时预览（T44 修复，2026-11-06）

- **旧实现（已移除）**：`beginStroke/appendPoint` 直接把 stamp 画在 on-screen WebGL framebuffer 上，然后每帧 `surface.flush()`；未开 `preserveDrawingBuffer` 时 framebuffer 跨帧不保证保留 → 拖动中只剩零散 stamp（看起来白板），`endStroke` 的 `compositeAll` 才让线条出现。
- **新实现**：当前笔触写入**离屏 live layer**（`CK.MakeRenderTarget` GPU surface）；每个 rAF 确定性重绘：`clear → 全部图层 tile → 当前 live 内容 → flush`。结束/取消/undo/redo 清空 live 并重新合成。
- **擦除笔刷**：live layer 存白色覆盖 mask；合成时在**当前图层隔离（saveLayer）**内用 `DstOut` 擦除 → 实时露出下层（不会白盖，也不会把背景擦成透明）。
- **回归**：`v2/engine/test/live-preview.mjs`（第一笔 end 后 ink>0；第二笔 begin+append 未 end 时第一笔仍在且新笔可见；end/cancel/undo/redo；eraser live 中心白/边缘保留/undo 恢复）。结果：`results/live-preview.json`。
- **成本**：每帧全量合成（当前 2048² demo 实测合成约 0.2–0.7ms；4096² 后续可做脏区优化）；live surface 额外一份画布内存（2048²≈16MB，4096²≈64MB）。
- `bench/` 延迟口径不变（输入→帧提交代理）。

### T46：present 全量确定性帧（2026-11-06）

QA 在真实 Edge 复现发现：T44 只修了 live 帧，**present 路径仍坏**——`endStroke` 走 `compositeDirty` 只画脏 tile，而 on-screen framebuffer 已被清空 → 抬笔后空白/残缺；`undo/redo` 的 `compositeDirtySafe` 同理；brushes 页全白约 2.7s、app 约 800ms 才恢复。

- **修复**：`endStroke / undo / redo / cancelStroke / 图层结构变化` 全部走 **`presentFull()`**：`clear → 全部图层 tile → live（若有）→ flush`；present 后再补 **2–3 帧全量 burst**，抵消浏览器合成后清空 drawing buffer 的时机差异。
- `compositeDirtySafe()` 标记 deprecated，内部改为全量 present（保留 API 兼容）；可见 surface 上不再做局部脏区绘制。
- 参考实现比对：`06-技术/参考实现比对_Klecks.md`（Klecks MIT 的显式 present/tile undo/line smoothing；product v0.1 的全量 `renderComposite` 基线；CanvasKit flush 语义）。
- **帧稳回归**：`v2/engine/test/present-stability.mjs`——两笔 end 后 0/16/50/200ms 截图非空且稳定；undo 后与「只画第一笔」参考帧一致；结果 `results/present-stability.json`。
- **剩余**：全量合成 2048² 实测 ~12.5ms（QA）可接受；4096²/脏区优化（保留上一帧全量纹理再 blit）留 M4.5。

## 笔刷注入接口（T41，StrokePaintProvider）

引擎不再写死 hard/soft。自定义笔刷（如 T36）实现 Provider 并通过 `engine.setBrushProvider(provider)` 注入：

```js
const provider = {
  id: 'my-brush',
  begin(ctx) {},                       // 可选：笔触开始（ctx.canvas = null）
  radiusFor(ctx) { return 12; },       // 必填：本 stamp 半径 px
  paintFor(ctx) { return ctx.paint; }, // 可选：返回配置好的 CanvasKit Paint（provider 负责缓存/释放）
  stampFor(ctx) { ctx.canvas.drawCircle(ctx.x, ctx.y, ctx.radius, ctx.paint); }, // 可选：完整自定义绘制
  end(ctx) {},                         // 可选：笔触结束（commit 前）
  cancel(ctx) {},                      // 可选：取消（不写 tile/undo）
  dispose() {},                        // 可选：释放 provider 自己创建的 Paint/MaskFilter/Image
};
engine.setBrushProvider(provider);
```

**ctx 透传字段（每 stamp）**：
`CK, provider, brush{type,sizePx,opacity}, layerId, canvas（实时=主 surface / 提交=tile surface）, x,y（绘制坐标）, worldX,worldY, pressure, tiltX,tiltY, velocity（px/ms）, distance（px）, timestamp, elapsed, index, coalescedIndex, coalescedCount, pointerType, isTile, tileX, tileY, radius, paint`。

- `paintFor` 只在需要 Paint 时实现；`stampFor` 可完全接管绘制（绘制到 `ctx.canvas`）。
- 引擎不 delete provider 返回的 Paint（provider 负责生命周期；`dispose()` 统一释放）。
- **T36 适配要求**：保留 `BrushController` 的稳定化/间距/散点等**输入预处理**；移除 `BrushStroke extends Stroke` 子类，改为实现 Provider。最小示例：`examples/brush-controller-adapter.js`。
- 兼容性：默认 provider 复刻原 hard/soft 行为；T35 原有 smoke 不回归；`test/smoke.mjs` 已加自定义 provider 冒烟（上下文透传 + 绘制 + undo）。

## 接口

完整契约见 `06-技术/v2实现计划.md` §2（IEngine / IStroke / ILayerStore / IUndo / IInputSource）。demo 暴露：

```js
window.__V2__        // Engine 实例
window.__V2_READY__  // 初始化完成
window.__V2_BENCH__  // 最近一次 benchmark 结果
```

常用方法：
`beginStroke(point)` / `appendPoint(point)` / `endStroke()` / `undo()` / `redo()` /
`setBrush({type,sizePx})` / `addLayer()` / `setActiveLayer(id)` / `setLayerBlend(id, mode)` /
`getStats()` / `getCompositeDataUrl()` / `runBench({durationMs})` / `setBrushProvider(provider)` / `getBrushProvider()`。

## 未实现 / 后续任务

| 项 | 归属 |
|---|---|
| 10 种笔刷、动态/纹理、Brush Studio 参数 | T36（`v2/brushes/`） |
| 组/蒙版/剪贴/16 混合、选区/变换 | T37（`v2/layers/`、`v2/selection/`） |
| PSD 导入导出、项目序列化、证据包 | M4.4（`v2/psd/`） |
| 4096²×8 含驱动内存 tracing 复核（T38 仅分项 704MiB） | M4 监控项（真机桌面 Chrome） |
| 真实手绘板（P3，用户暂缓） | 后续有硬件再补 |
| 非 headless 桌面 Chrome 性能复跑、Safari 兼容 | M4.5 |

## 开源复用（T49，2026-11-06）

按用户要求「站在开源成熟项目肩膀上」，首批移植/改写三项（MIT Klecks，保留版权头与 NOTICES）：

| 项 | 实现 | 说明 |
|---|---|---|
| **present / 整帧 blit** | `engine.js`：`presentSurface`（离屏全帧 RenderTarget）+ `presentFull()` 合成保留帧 + `_blitRetained()` 整帧 blit 到 on-screen；`_schedulePresentBurst()` 也走 blit；`presentDirty()` 当前统一全量重绘保留帧（增量脏区留后续） | 与 T44/T46 兼容；T46「任何 present 必须整帧上屏」保持 |
| **tile undo 增强** | `undo.js`：`pause/resume`、`replaceTop`、`validate`、`listeners`、`memoryEstimate`；`engine.js` 暴露 `pauseHistory/resumeHistory/replaceTopHistory/onHistoryChange` | 参考 Klecks KlHistory 改写 |
| **LineSmoothing 输入平滑** | `src/line-smoothing.js`（MIT 移植）+ `input.js` 接入；`engine.setInputSmoothing(0..1)`，默认 0 不改变行为；demo 加「平滑」滑杆 | 算法：mix + 80ms 延迟/35ms 追赶 |

- 测试：`v2/engine/test/leverage.mjs` → `results/leverage.json`（ok=true，16 项全过：present/undo/smoothing）。
- 回归：`present-stability`、`live-preview`、`smoke` 全绿；`presentFull`/`blit` 代理各 0.1ms（headless；真实 Edge 全量合成 ~12.5ms@2048²）。
- 许可：`vendor/THIRD_PARTY_NOTICES.md` §Klecks（MIT 全文 + 使用范围）；来源清单 `06-技术/开源杠杆清单.md`。
- 内存：保留帧额外 +16MB（2048²）/+64MB（4096²）；可用 `presentRetained:false` 关闭保留帧（回退直画 on-screen）。4096²×8 分项约 768MiB，贴近 800MiB 预算，M4.5 复核。

### T49 后续复核（2026-11-06，试用期不改默认）

- **4096² 内存**：T38 分项 704MiB + live surface 64MiB + present 保留帧 64MiB = **832MiB（超 800）**；`presentRetained:false` 时 = **768MiB（余量 32MiB，驱动不可观测）**。
- **自适应（已实现）**：`presentRetained` 默认按面积——**≤2048² 开（正确性优先）、>2048² 自动关（内存预算）**；显式 `opts.presentRetained` 可覆盖；`engine.setPresentRetained(bool)` 支持运行时切换（切换即重绘，行为等价）。**试用期 1200×800 / 2048² 默认渲染行为不变**。
- 复核脚本：`test/memory-4096-review.mjs` → `results/memory-4096-review.json`（ok=true；auto4096=0MB、auto2048=16MB、toggle 16→0→16 正常；两种模式绘制/合成均正常）。证据：`06-技术/对比检验证据/memory-4096.json`。
- **脏区增量**：CanvasKit RenderTarget snapshot 后增量绘制读回异常，当前统一全量重绘保留帧 + 整帧 blit；增量优化留 M4.5（不影响当前版本）。
- **file:// 横幅（QA 002 §4）**：除全屏 `#fileProtocolOverlay` 外，file:// 时同时显示置顶红色 `#fatalBar`（headless 验证：两者均可见；http 不显示）。

## 选区 / 变换 / 结构 undo（T63，2026-11-06）

- **选区**：`setSelectionImage(img)` / `getSelectionImage()` / `clearSelection()` / `hasSelection()`；笔触提交时按选区 alpha 对**实际 tile** DstIn 裁剪（undo patch 同步裁剪）。
- **变换**：`beginTransform(layerId)` → `updateTransform({x,y,scaleX,scaleY,rotate,flipH,flipV})` → `commitTransform()`（1 步 undo，`kind:'image'`）/ `cancelTransform()`；`getTransformHandles()`（8+旋转柄）、`dragTransformHandle(id,x,y,{snap})`（Shift 15° 吸附）；有选区时只变换选区内像素。
- **结构 undo**：`addGroup/addLayer/deleteLayer/duplicateLayer/moveLayer/moveToGroup/mergeDown/flattenAll` 与笔触/变换共用同一 `UndoManager`；结构快照含 V2Doc + tile image 引用（不立即 delete，M4.5 引用计数）；T60 `serializeDoc` 兼容。
- **T62**：`snapshotRegion(layerId,bbox)` 按区域出图（涂抹/变换用，避免整画布复制）。
- 测试：`test/selection-transform.mjs`、`test/doc.mjs`；限制：选区只约束图层笔触；结构快照大文档内存需 M4.5 优化。

## Alpha Lock / 快照释放（T65，2026-11-06）

- `setLayerAlphaLock(id, true/false)`：开启后笔刷/擦除只作用于已有不透明像素 alpha 内（新增透明区域不落笔）；实现为笔触提交时按**笔触前 tile alpha** DstIn 裁切（实际 tile + undo patch 同步）。
- V2Doc `layer.alphaLock` 字段 + T60 `serializeDoc/deserializeDoc` 保留；LayerSystem `getDoc/applyDoc` 同步（`setLayerAlphaLock` 同名）。
- `releaseHistorySnapshots()`：显式释放历史/结构快照与 detach 的 image（跳过当前 tile 仍引用的图），清空 undo/redo 后仍可继续绘制；`dispose()` 前自动调用。LayerSystem 同名 API。
- 测试：`test/alpha-lock.mjs`（锁定前后/undo/橡皮/doc/序列化/LayerSystem/释放后绘制，8/8）；doc/present-stability/t37-smoke/smoke 不回退。
- 组蒙版/组剪贴未做（时间；T37 已知差异，M4.5/后续）。

## 组蒙版 / 组剪贴（T67，2026-11-06）

- **组蒙版**：`addGroupMask(groupId)` / `removeGroupMask` / `setGroupMaskEnabled` / `applyGroupMask`；`setActiveGroup(id)` + `setActiveTarget('group-mask')` 后笔刷编辑组蒙版（undo entry `storeKind:'group-mask'`）；maskStore 以 groupId 为 key。
- **语义**：组蒙版影响整组合成（成员画完后 DstIn 组蒙版）；空白 mask tile = 隐藏、白色笔触 = 显示（Procreate 式）；`applyGroupMask` 把组蒙版烘焙到成员图层（混合模式为近似）。
- **组剪贴**：`setGroupClip(groupId, true)` —— 组整体被其**下方图层 alpha** DstIn 裁切（最小语义；基底层 = 扁平顺序前一层，不支持任意组间引用）。
- V2Doc `groups[].mask/clip`；`.mozheng` masks 按 groupId 序列化；PSD 桥 group.mask/clip 结构映射。
- 测试：`test/group-mask.mjs`（15 项全过：隐藏/显示/undo/启停/删除/序列化/组剪贴/PSD 桥）。
- 限制：PSD 组 mask 像素未落地（仅结构 fidelity）；组剪贴不支持任意组引用；applyGroupMask 对 blend 为近似；组仍仅 1 级。

## 蒙版笔触 white/black（T84）

- `setMaskStrokePaint('white'|'black')` / `beginStroke(p, { maskPaint })`：作用于 `activeTarget='mask'`（图层蒙版）或 `'group-mask'`（组蒙版），`storeKind` 分别为 `mask`/`group-mask`。
- 语义：**white=显示/恢复**（在蒙版上画白）；**black=隐藏/橡皮**（DstOut 擦除蒙版 alpha）；普通图层笔触不受影响。
- 黑色首次触碰空白图层蒙版 tile 时会先铺白再擦除，保证未画区域仍可见；undo 回到铺白后的可见状态；组蒙版同理。
- live 预览：`_liveInfo` 返回 `mask-erase`/`group-mask-erase`，compositor 用 DstOut 实时隐藏；`getCompositeDataUrl`/present 已包含蒙版 live。
- 序列化不需要改：mask tile 的 RGBA 已保存；undo entry 仍为 `{kind:'paint',storeKind,layerId,patches}`。
- 测试：`test/mask-paint.mjs`（图层/组蒙版 white+black、live、undo、序列化、普通笔触不回归）。

## 已知限制（M4.1 范围内）

1. **undo 快照暂不释放**：before/after 图像可能被当前 tile 或后续 patch 引用，M4.1 保守不删除（内存随会话增长）；M4.5 加引用计数/压缩。
2. **笔迹提交为整笔重放**：一笔结束才写入 tile（实时阶段画在主 surface 上）；超长笔迹的首帧可见性依赖 rAF，后续可做帧内 tile 增量。
3. **混合模式为图层组级 saveLayer**，非逐像素优化；16 种混合模式待 T37。
4. **内存为估算**（tile surface+image + undo 历史 + WASM 堆），未含 GPU 驱动/缓存；4096²×8 分项 704MiB（T38），含驱动是否 ≤800MB **未验证**。
5. 无组/蒙版/选区/PSD/图层合并/变换。
6. benchmark 为合成轨迹（无压感硬件），延迟为「输入→帧提交」代理指标，不能代表真实手感。

## 许可

- CanvasKit / Skia：**BSD-3-Clause**，`vendor/LICENSE` 必须保留；v2 阶段登记见 `vendor/THIRD_PARTY_NOTICES.md`（版本/SHA/来源/义务）；合并产品时按 `product/THIRD_PARTY_NOTICES.md` §B/§D 登记版本/SHA 与 Skia third_party 许可。
- 冒烟结果留档：`results/bench.json`（CDP + 真实 GPU；非正式 benchmark，环境/限制见文件内 notes）。
- 本目录自制代码：项目内使用（MIT 待定，随仓库 LICENSE 统一）。

## 测试

```powershell
# 1) 起静态服务器（仓库根目录）
python -m http.server 8899 --bind 127.0.0.1
# 2) 起 Chrome（无头 + 远程调试）
#    "C:\Program Files\Google\Chrome\Application\chrome.exe" --headless=new --remote-debugging-port=9333 --user-data-dir=<tmp> http://127.0.0.1:8899/v2/engine/demo.html
# 3) 运行冒烟测试
node v2/engine/test/smoke.mjs http://127.0.0.1:8899/v2/engine/demo.html 9333
```

冒烟测试覆盖：初始化 → 3 笔绘制 → 5 混合模式 → undo/redo → 合成 PNG → 简短 benchmark。

```powershell
# T44 实时预览回归（拖动中内容保留/擦除/undo）
node v2/engine/test/live-preview.mjs http://127.0.0.1:8899/v2/engine/demo.html 9333 v2/engine/results/live-preview.json
# T46 present 帧稳定回归（0/16/50/200ms 截图 + undo 参考帧）
node v2/engine/test/present-stability.mjs http://127.0.0.1:8899/v2/engine/demo.html 9333 v2/engine/results/present-stability.json
```
