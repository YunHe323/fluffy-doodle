# 性能/内存回归方案（M4.5 P1b：T88 present 脏区/双缓冲/4096 优化 · T89 历史 image 引用计数/自动回收）

> 状态：**待命**（等 T88/T89 完成通知；期间不启动浏览器）。
> 执行：headless Edge（playwright-core `channel:'msedge'`，真实 Edge 内核 + D3D11；如 Lead 要求有头证据再单独申请，窗口移至屏幕外）。
> 输出：`tools/perf-memory-regression.json` / `tools/perf-regression-report.md` 增补 / 归档 `tools/archive/baseline-m45-p1b/`。

## 0. T88/T89 落地后先探测 API（防御式，以代码为准）

| 能力 | 候选 API（探测 `engine.*` / app hooks） |
|---|---|
| present 统计 | `getPresentStats()` / `presentStats` / `getStats().present*`（P50/P95、fps、lastPresentMs、dirtyArea/redrawRatio、doubleBuffer） |
| 脏区/双缓冲 | `presentDirty(keys)`、`presentFull()`、`_presentSurface`/`_presentBack`、`dirtyKeys` 统计 |
| 历史内存 | `getHistoryStats()` / `historyBytes` / `memoryEstimateMB`、`setHistoryLimit`/`maxHistoryBytes`、`releaseHistorySnapshots()`、`trimHistory()`、`_imageRefs` 引用计数 |
| app 侧 | `window.__V2_APP__.t88/t89`（若暴露）、`engine.getStats()` |

## 1. 三页冒烟 + GATE 无回退

```powershell
node v2/qa/tools/harness.mjs   # 3 页冒烟 + 4 目标×3 轮（T80 真线宽 CV 口径）
```
门槛：冒烟 3/3；GATE「全部闸门通过」；与 `archive/baseline-final3/` 对比无新增 ❌。

## 2. present 性能（T88）

| 用例 | 指标 |
|---|---|
| 2048² / 4096² 绘制中 | 帧间隔 **P50/P95**、fps、最长帧；主线程 longtask（>50ms 次数/最长） |
| 重绘面积 | 每帧 dirtyArea / 画布面积比（若 T88 暴露）；全量回退次数 |
| 内存 | 绘制前后 `memoryEstimateMB`、峰值；present surface 双缓冲占用（2048²/4096² ×2） |
| 正确性 | 绘制中/后 3 帧读回像素一致（双缓冲不撕裂）；undo 后帧正确 |

采集：页面内 `requestAnimationFrame` 时间戳序列（绘制期间）→ P50/P95/fps；`PerformanceObserver({entryTypes:['longtask']})`；`engine.getStats()` 采样。
判定：以 T88 规格为准；若规格未给数值，按「4096² P95 ≤ 50ms（≥20fps）、2048² P95 ≤ 33ms（≥30fps）、longtask >50ms = 0」作建议门槛，并在报告中注明「建议值，待 tech 确认」。

## 3. 历史内存（T89）

| 用例 | 指标/判定 |
|---|---|
| 80 步压力 | 每 10 步 `memoryEstimateMB`/`historyBytes` 采样；记录增长曲线 |
| 超限自动释放 | 超过 T89 上限后 estimate 下降（释放生效）、无 OOM/崩溃、UI 可用 |
| 释放后 undo 正确 | 释放后连续 undo 10 步，像素与预期一致（像素 diff=0 vs 释放前快照） |
| 长跑无持续增长 | 200 步后最终内存 ≤ 平台期 ×1.1，且无单调线性增长（斜率≈0） |
| 引用计数 | 若 T89 暴露 `_imageRefs`：绘制/undo/释放后引用计数归零无泄漏 |

## 4. 产物

| 产物 | 内容 |
|---|---|
| `tools/perf-memory-regression.json` | 帧时间序列、P50/P95/fps、longtask、内存采样、undo 正确性 |
| `tools/perf-regression-report.md` | 增补「M4.5 P1b 性能/内存」章节 + 对比表 |
| `tools/archive/baseline-m45-p1b/` | GATE/results/rounds/功能/perf/内存 全套基线 |
| `GATE-pw.md` | 增补「P1b 性能/内存回归」一行结论 |

## 5. 已知前置约束

- 用户曾投诉有头 Edge 弹窗 → 默认 headless；`--headed` 仅在有头证据被要求时使用（窗口 `-3000,-3000`，先通知 Lead）。
- 独立端口 4260+/4310+，跑完杀进程，检查 0 残留（msedge 命令行匹配 `v2-qa-profile|playwright`）。
