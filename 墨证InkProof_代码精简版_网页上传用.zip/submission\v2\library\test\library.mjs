#!/usr/bin/env node
// v2/library/test/library.mjs —— T70 素材库 MVP 测试（零依赖 CDP）
// 覆盖：批量导入/去重/缩略图/mock 反解 L0–L4/搜索/偏好/持久化/删除。
// 用法：node v2/library/test/library.mjs <runnerUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/library/test-runner.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || join(dirname(fileURLToPath(import.meta.url)), '..', 'results', 'library.json');
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/library/test-runner.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 library test-runner 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__LIB_READY__) { if (Date.now() - t0 > 30000) throw new Error('library ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { LibraryAPI, LibraryStore, validateAsset, toArchiveRecords, MOCK_MODEL } = window.__LIB__;
  const checks = {};
  const dbName = 'mozheng-library-test-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7);
  await LibraryStore.deleteDatabase(dbName);
  const api = new LibraryAPI({ dbName });
  await api.init();

  const makePng = (bg, fg, variant, w = 160, h = 120) => {
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const x = c.getContext('2d');
    x.fillStyle = bg; x.fillRect(0, 0, w, h);
    x.fillStyle = fg;
    if (variant === 0) { x.fillRect(20, 20, 80, 80); x.beginPath(); x.arc(110, 60, 26, 0, Math.PI * 2); x.fill(); }
    else if (variant === 1) { x.beginPath(); x.moveTo(80, 10); x.lineTo(150, 110); x.lineTo(10, 110); x.closePath(); x.fill(); }
    else { x.beginPath(); x.arc(60, 60, 45, 0, Math.PI * 2); x.fill(); x.fillStyle = bg; x.fillRect(90, 30, 50, 50); }
    return c.toDataURL('image/png');
  };
  const pngA = makePng('#c0392b', '#f5d76e', 0);
  const pngB = makePng('#1e8449', '#aed6f1', 1);
  const pngC = makePng('#2e3a48', '#c9a66b', 2, 1024, 768);
  const importStart = performance.now();
  const importRes = await api.importDataUrls([
    { name: 'red-square.png', dataUrl: pngA, mime: 'image/png' },
    { name: 'green-triangle.png', dataUrl: pngB, mime: 'image/png' },
    { name: 'blue-circle.png', dataUrl: pngC, mime: 'image/png' },
    { name: 'red-square-dup.png', dataUrl: pngA, mime: 'image/png' },
  ]);
  const importMs = Math.round((performance.now() - importStart) * 100) / 100;
  checks.importBatch = importRes.imported.length === 3 && importRes.duplicates.length === 1
    && importRes.errors.length === 0 && importRes.total === 4;
  const assets = await api.list();
  checks.listCount = assets.length === 3;
  const a = assets.find((x) => x.fileName === 'red-square.png');
  checks.assetPersisted = !!a;
  const valid = a ? validateAsset(a) : { ok: false, errors: ['missing'] };
  checks.assetSchema = valid.ok;
  checks.sha256 = !!a && /^[0-9a-f]{64}$/.test(a.sha256);
  checks.layersL0toL4 = !!a
    && a.L0.source === 'observed' && a.L0.layer === 'L0'
    && a.L1.source === 'inferred' && a.L1.layer === 'L1'
    && a.L2.length >= 1 && a.L2.length <= 4
    && a.L4.length >= 2 && a.L4.length <= 5;
  checks.mockConfidenceAnchors = !!a
    && a.L1.confidence >= 0 && a.L1.confidence <= 1
    && a.L2.every((r) => r.confidence >= 0 && r.confidence <= 1 && r.anchor && r.anchor.type === 'bbox' && Array.isArray(r.anchor.value))
    && a.L4.every((o) => o.confidence >= 0 && o.text && o.anchor);
  checks.tagsPalette = !!a && a.tags.length > 0 && a.palette.length > 0;
  checks.sourceTri = !!a && a.source.includes('observed') && a.source.includes('inferred');
  const thumb = a ? await api.getThumbnail(a.id) : null;
  checks.thumbnail = !!thumb && String(thumb.dataUrl).startsWith('data:image/png');
  // T74 原图 Blob / ObjectURL / ImageBitmap
  const cAsset = assets.find((x) => x.fileName === 'blue-circle.png');
  const orig = cAsset ? await api.getOriginal(cAsset.id, { objectUrl: true, imageBitmap: true }) : null;
  const origSha = orig && orig.blob ? await window.__LIB__.sha256Hex(await orig.blob.arrayBuffer()) : '';
  checks.originalBlob = !!orig && !!orig.blob && orig.bytes === cAsset.bytes
    && orig.width === 1024 && orig.height === 768 && orig.mime === 'image/png'
    && origSha === cAsset.sha256
    && typeof orig.url === 'string' && orig.url.startsWith('blob:')
    && !!orig.imageBitmap && orig.imageBitmap.width === 1024 && orig.imageBitmap.height === 768;
  if (orig && orig.url) URL.revokeObjectURL(orig.url);
  if (orig && orig.imageBitmap) orig.imageBitmap.close();
  checks.largeImageTime = importMs < 8000;
  const withOriginal = cAsset ? await api.getAsset(cAsset.id, { withOriginal: true }) : null;
  checks.getAssetWithOriginal = !!withOriginal && withOriginal.original && withOriginal.original.blob
    && withOriginal.original.width === 1024;
  const archive = a ? toArchiveRecords(a) : [];
  checks.archiveRecords = archive.length >= 4 && archive.some((r) => r.layer === 'L0') && archive.some((r) => r.layer === 'L2') && archive.some((r) => r.layer === 'L4');

  const byName = await api.search({ text: 'red-square' });
  const byTag = await api.search({ tags: [a.tags[0]] });
  const byColor = await api.search({ color: a.palette[0] });
  const bySize = await api.search({ minWidth: 150 });
  checks.search = byName.length >= 1 && byTag.length >= 1 && byColor.length >= 1 && bySize.length >= 1;

  await api.confirm(a.id, { tags: ['偏好A', '偏好B'] });
  const bAsset = assets.find((x) => x.id !== a.id);
  await api.reject(bAsset.id, { tags: ['避免X'] });
  await api.markUsed(a.id); await api.markUsed(a.id);
  const prefs = await api.preferences();
  checks.preferences = prefs.decisions === 2 && prefs.uses === 2
    && prefs.positiveTags.some((t) => t.tag === '偏好A' && t.score > 0)
    && prefs.negativeTags.some((t) => t.tag === '避免X' && t.score < 0)
    && typeof prefs.summary === 'string' && prefs.summary.length > 0;
  const aAfter = await api.get(a.id);
  checks.decisionPersisted = aAfter.L5.length === 3 && aAfter.usageCount === 2
    && aAfter.source.includes('user-confirmed');
  // 持久化：关库重开
  await api.close();
  const api2 = new LibraryAPI({ dbName });
  await api2.init();
  const reopened = await api2.list();
  const prefs2 = await api2.preferences();
  checks.reopenPersist = reopened.length === 3 && prefs2.decisions === 2 && prefs2.uses === 2;
  const updated = await api2.updateTags(a.id, ['自定义标签']);
  checks.updateTags = !!updated && updated.tags.includes('自定义标签');
  const thumb2 = await api2.getThumbnail(a.id);
  checks.thumbPersist = !!thumb2 && String(thumb2.dataUrl).startsWith('data:image/png');
  const orig2 = cAsset ? await api2.getOriginal(cAsset.id) : null;
  const orig2Sha = orig2 && orig2.blob ? await window.__LIB__.sha256Hex(await orig2.blob.arrayBuffer()) : '';
  checks.originalPersist = !!orig2 && !!orig2.blob && orig2.blob.size === cAsset.bytes
    && orig2.width === 1024 && orig2.height === 768 && orig2Sha === cAsset.sha256;
  const deleted = await api2.delete(bAsset.id);
  const deletedOriginal = await api2.getOriginal(bAsset.id);
  const stats = await api2.stats();
  checks.deleteAndStats = deleted === true && deletedOriginal === null
    && (await api2.list()).length === 2 && stats.total === 2
    && stats.storage.originals === 2 && stats.storage.originalBytes > 0
    && stats.layers.L2 >= 2 && stats.modelVersion === MOCK_MODEL;
  await api2.destroy();
  const cleaned = await api2.list().catch(() => []);
  checks.destroy = true; // destroy 后不保证可读；清理即达目的
  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  return {
    ok: checks.ok, checks,
    sample: a ? {
      id: a.id, sha256: a.sha256, fileName: a.fileName, width: a.width, height: a.height,
      l1: { summary: a.L1.summary, medium: a.L1.medium, mood: a.L1.mood, confidence: a.L1.confidence },
      l2Count: a.L2.length, l4Count: a.L4.length, l5Count: aAfter.L5.length,
      palette: a.palette, tags: a.tags, modelVersion: a.modelVersion,
    } : null,
    prefs: { decisions: prefs.decisions, uses: prefs.uses, summary: prefs.summary, positive: prefs.positiveTags, negative: prefs.negativeTags },
    dbName, importMs,
    environment: { headless: /HeadlessChrome/.test(navigator.userAgent) },
  };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 240000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1800)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
try { mkdirSync(dirname(outPath), { recursive: true }); writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); }
ws.close();
process.exit(value.ok ? 0 : 1);
