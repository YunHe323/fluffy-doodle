/**
 * v2 engine · tile 位图层存储（256² 稀疏分配，RGBA）
 *
 * 每个 tile = CanvasKit GPU RenderTarget(256×256) + 当前 ImageSnapshot。
 * - 稀疏：只有被笔迹触及的 tile 才分配 surface；未分配 tile 视为全透明。
 * - 合成器只读 tile.image；撤销/重做通过 before/after 快照还原。
 * - 本模块不感知笔刷与合成顺序（只做存储）。
 */
export const TILE = 256;

export class TileStore {
  /**
   * @param {any} CK CanvasKit 实例
   * @param {any} gr GrDirectContext（GPU）
   * @param {number} width
   * @param {number} height
   */
  constructor(CK, gr, width, height) {
    this.CK = CK;
    this.gr = gr;
    this.width = width;
    this.height = height;
    this.tileSize = TILE;
    this.tilesW = Math.ceil(width / TILE);
    this.tilesH = Math.ceil(height / TILE);
    /** @type {Map<string, Map<string, {surface:any, image:any}>>} layerId -> tiles */
    this.layers = new Map();
    this._blank = null;
  }

  ensureLayer(layerId) {
    let map = this.layers.get(layerId);
    if (!map) {
      map = new Map();
      this.layers.set(layerId, map);
    }
    return map;
  }

  keyFor(x, y) {
    return `${Math.floor(x / TILE)},${Math.floor(y / TILE)}`;
  }

  keyXY(key) {
    const [tx, ty] = key.split(',').map(Number);
    return { tx, ty };
  }

  /** @returns {{surface:any,image:any}|null} */
  get(layerId, key) {
    const map = this.layers.get(layerId);
    return map ? map.get(key) || null : null;
  }

  /** 分配（或取回）tile；tile 初始为全透明 */
  ensureTile(layerId, key) {
    const map = this.ensureLayer(layerId);
    let tile = map.get(key);
    if (tile && !tile.surface) {
      // 共享空白 tile 被写入时，就地升级为真实可写 RenderTarget。
      const surface = this.CK.MakeRenderTarget(this.gr, TILE, TILE);
      if (!surface) throw new Error(`MakeRenderTarget 失败：${layerId}/${key}`);
      const c = surface.getCanvas();
      c.clear(this.CK.TRANSPARENT);
      c.drawImage(tile.image, 0, 0);
      surface.flush();
      tile = { surface, image: surface.makeImageSnapshot() };
      map.set(key, tile);
      return tile;
    }
    if (tile) return tile;
    const surface = this.CK.MakeRenderTarget(this.gr, TILE, TILE);
    if (!surface) throw new Error(`MakeRenderTarget 失败：${layerId}/${key}`);
    const c = surface.getCanvas();
    c.clear(this.CK.TRANSPARENT);
    surface.flush();
    tile = { surface, image: surface.makeImageSnapshot() };
    map.set(key, tile);
    return tile;
  }

  /** 登记一个「共享全透明」tile，不分配 GPU surface。
   *  T117 P1-5：4096² 蒙版只需写选区 bbox 内的 tile，bbox 外用空白 tile 占位
   *  （保持所有 tile 都在 maskStore 中，DstIn 语义不变），省掉 200+ 次 MakeRenderTarget/flush/snapshot。 */
  putBlank(layerId, key) {
    const map = this.ensureLayer(layerId);
    if (map.has(key)) return map.get(key);
    const tile = { surface: null, image: this.blankImage() };
    map.set(key, tile);
    return tile;
  }

  /** 全透明 tile 的 Image（不分配图层 tile）。
   *  必须 encode→decode 生成独立 Image：直接返回 surface.makeImageSnapshot() 会在
   *  surface.delete() 后变成懒快照失效指针，合成时抛 "Cannot pass deleted object"。 */
  blankImage() {
    if (this._blank) return this._blank;
    const surface = this.CK.MakeRenderTarget(this.gr, TILE, TILE);
    const c = surface.getCanvas();
    c.clear(this.CK.TRANSPARENT);
    surface.flush();
    const snap = surface.makeImageSnapshot();
    const raw = snap.encodeToBytes();
    const copy = new Uint8Array(raw.length);
    copy.set(raw);
    try { snap.delete(); } catch (e) { /* ignore */ }
    try { surface.delete(); } catch (e) { /* ignore */ }
    this._blank = this.CK.MakeImageFromEncoded(copy);
    return this._blank;
  }

  /** 受影响 tile 的 before 快照（未分配 tile 用透明快照） */
  captureBefore(layerId, key) {
    const tile = this.get(layerId, key);
    return tile ? tile.image : this.blankImage();
  }

  /** 用快照覆盖 tile（撤销/重做还原）；返回新的 image */
  applyImage(layerId, key, img) {
    const tile = this.ensureTile(layerId, key);
    const c = tile.surface.getCanvas();
    c.clear(this.CK.TRANSPARENT);
    c.drawImage(img, 0, 0);
    tile.surface.flush();
    tile.image = tile.surface.makeImageSnapshot();
    return tile.image;
  }

  /** 笔迹提交后写入 tile：由 stroke 回调，参数为 tile 本地坐标画笔 */
  withCanvas(layerId, key, fn) {
    const tile = this.ensureTile(layerId, key);
    const c = tile.surface.getCanvas();
    fn(c, this.keyXY(key));
    tile.surface.flush();
    return tile;
  }

  refreshImage(layerId, key) {
    const tile = this.get(layerId, key);
    if (!tile) return null;
    if (!tile.surface) return tile.image; // 共享空白 tile：无需重新快照
    tile.image = tile.surface.makeImageSnapshot();
    return tile.image;
  }

  /** T62/T63：按 bbox 生成图层区域快照（GPU Image）；避免整画布复制，供涂抹/变换临时使用 */
  snapshotRegion(layerId, bbox) {
    const x = Math.max(0, Math.floor(bbox.x || 0));
    const y = Math.max(0, Math.floor(bbox.y || 0));
    const w = Math.max(1, Math.min(this.width - x, Math.ceil(bbox.w || this.width)));
    const h = Math.max(1, Math.min(this.height - y, Math.ceil(bbox.h || this.height)));
    const CK = this.CK;
    const surface = CK.MakeRenderTarget(this.gr, w, h);
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    const tx0 = Math.floor(x / TILE), ty0 = Math.floor(y / TILE);
    const tx1 = Math.floor((x + w - 1) / TILE), ty1 = Math.floor((y + h - 1) / TILE);
    for (let ty = ty0; ty <= ty1; ty += 1) {
      for (let tx = tx0; tx <= tx1; tx += 1) {
        const tile = this.get(layerId, `${tx},${ty}`);
        if (!tile) continue;
        c.drawImage(tile.image, tx * TILE - x, ty * TILE - y);
      }
    }
    surface.flush();
    const img = surface.makeImageSnapshot();
    surface.delete();
    return img;
  }

  listTiles(layerId) {
    const map = this.layers.get(layerId);
    return map ? [...map.keys()] : [];
  }

  allKeys() {
    const keys = new Set();
    for (const map of this.layers.values()) for (const k of map.keys()) keys.add(k);
    return [...keys];
  }

  count(layerId) {
    const map = this.layers.get(layerId);
    return map ? map.size : 0;
  }

  /** 估算：每 tile = surface + image 两份 RGBA */
  memoryBytes() {
    let n = 0;
    for (const map of this.layers.values()) n += map.size;
    return n * TILE * TILE * 4 * 2;
  }

  dispose() {
    for (const map of this.layers.values()) {
      for (const tile of map.values()) {
        try { tile.image.delete(); } catch (e) { /* ignore */ }
        try { tile.surface.delete(); } catch (e) { /* ignore */ }
      }
      map.clear();
    }
    this.layers.clear();
    try { this._blank && this._blank.delete(); } catch (e) { /* ignore */ }
    this._blank = null;
  }
}
