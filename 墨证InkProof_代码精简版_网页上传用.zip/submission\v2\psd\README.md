# v2 PSD 导入 / 导出（T39）

> 目标：与 Procreate/Photoshop 互通——PSD → v2 图层模型 → 可编辑画布 → 导回 PSD；**不支持项生成 fidelity_report，不静默丢弃**。
> 依赖：T35 engine + T37 LayerSystem（只读复用，未改其实现）｜第三方：**ag-psd 28.3.1（MIT）**。
> 结果：`v2/psd/results/fidelity.json`、`fidelity.md`、`manifest.json`、`samples/*.psd`。

## 目录

```
v2/psd/
├─ demo.html              # 载入 PSD → 图层树/预览/不支持项 → 导出/载入引擎
├─ test-runner.html       # 6 样本往返测试（浏览器内生成 + 导入/导出/比对 + 引擎集成）
├─ src/
│  ├─ model.js            # v2 文档模型、PSD↔内部混合模式映射、canvas 归一化
│  ├─ importer.js         # PSD → v2 doc + fidelity_report
│  ├─ exporter.js         # v2 doc → PSD（图层/组/蒙版/混合/不透明度/剪贴）
│  ├─ fidelity.js         # 结构 + 像素保真比对
│  ├─ integration.js      # v2 doc → LayerSystem（tile/组/蒙版同步）
│  └─ samples.js          # 6 个程序生成测试 PSD（CC0）
├─ test/psd-roundtrip.mjs # 零依赖 CDP 测试（写 results/）
├─ vendor/ag-psd/         # bundle.js + LICENSE + package.json + README_PSD.md
├─ THIRD_PARTY_NOTICES.md    # ag-psd MIT + pako/base64-js + pdf.js 注记
└─ results/               # fidelity.json/md、manifest.json、samples/*.psd
```

## 运行

```powershell
node v2/serve.mjs                  # 或 python -m http.server 8899 --bind 127.0.0.1
# demo：
# http://127.0.0.1:4200/v2/psd/demo.html
# 测试：
#   Chrome --headless=new --remote-debugging-port=9333 http://127.0.0.1:8899/v2/psd/test-runner.html
#   node v2/psd/test/psd-roundtrip.mjs http://127.0.0.1:8899/v2/psd/test-runner.html 9333
```

## 覆盖范围

| 能力 | 导入（PSD→v2） | 导出（v2→PSD） | 说明 |
|---|---|---|---|
| 栅格图层 | ✅ canvas（含裁剪层 top/left 归一化） | ✅ 全尺寸透明 canvas | 无损 |
| 图层组 | ✅ 递归读入 | ✅ `children` 递归写 | 引擎集成只支持 1 级组（T37 限制） |
| 图层蒙版 | ✅ `mask.canvas`（defaultColor/禁用记录） | ✅ `mask.canvas` | 6/6 样本保留 |
| 混合模式 | ✅ 28 种 PSD 名 → 内部 16 种 + passThrough | ✅ 反向映射 | 未支持名降级 normal 并记录 |
| 不透明度 / 可见性 / 剪贴 | ✅ | ✅ | 不透明度按 PSD 1/255 量化 |
| 文字 / 智能对象 | ⚠ 记录 + 空白占位（不可编辑） | ⚠ 占位空图层 | **不静默丢弃** |
| 图层样式 / 调整层 / 矢量 | ⚠ 记录（未烘焙/近似） | ⚠ 不导出样式 | — |
| 非 8-bit / 非 RGB | ⚠ 记录，按 8-bit RGB 栅格近似 | — | — |
| 合成图/缩略图 | — | 不生成（PSD 仍可读） | 由调用方或 M4.4 补 |

## 保真矩阵（2026-11-06，Headless Chrome 156 + ag-psd 28.3.1）

| 样本 | 结构 | 像素通过率 | 蒙版 | 混合 | 源/往返字节 | 不支持项 | 判定 |
|---|---|---|---|---|---|---|---|
| 01-pure-raster（纯栅格） | ✓ | 100.0% | ✓ | ✓ | 23978 / 23978 | 无 | ✓ |
| 02-multi-group（多图层组） | ✓ | 100.0% | ✓ | ✓ | 37310 / 37310 | 无 | ✓ |
| 03-mask（图层蒙版） | ✓ | 100.0% | ✓ | ✓ | 19354 / 19354 | 无 | ✓ |
| 04-blend（混合模式） | ✓ | 100.0% | ✓ | ✓ | 45996 / 45996 | 无 | ✓ |
| 05-procreate-style（Procreate 结构模拟） | ✓ | 100.0% | ✓ | ✓ | 45574 / 45574 | 无 | ✓ |
| 06-unsupported-text（文字层） | ✓ | 100.0% | ✓ | ✓ | 28286 / 19750 | **text**（占位） | ✓ |

**汇总**：样本 6/6、结构通过率 **100%**、像素通过率 **100%**、蒙版保留 **6/6**、不支持项报告 **✓（文字）**、引擎集成 **✓**（导入 4 层到 LayerSystem，可继续绘制，PNG 19KB）。
> 像素判据：逐图层 canvas 比对，`changedPct ≤1%` 且 `meanAbsDiff ≤1.5/255`；不透明度容差 2/255。
> 06 源/往返字节差异来自文字层（不可栅格化，保留空白占位）——结构/像素仍通过，且 fidelity 明确记录。

## 测试集来源与许可

| 样本 | 来源 | 许可 | 备注 |
|---|---|---|---|
| 01–06 全部 | **本项目程序生成**（浏览器内用 ag-psd 写入合成数据） | **CC0-1.0** | 无第三方美术资产 |
| 05 Procreate 风格 | 结构模拟（组/剪贴/蒙版/不透明度/multiply） | CC0-1.0 | **非真实 Procreate 导出**；Procreate 未参与 |
| 06 文字层 | 合成文字层（ArialMT 描述） | CC0-1.0 | 仅用于验证「不支持项报告」 |

样本二进制：`v2/psd/results/samples/*-source.psd` / `*-roundtrip.psd`；来源/许可/哈希见 `results/manifest.json`。

## 与 T35/T37 集成

```js
import { importPsd } from './src/importer.js';
import { exportPsd } from './src/exporter.js';
import { applyDocumentToLayerSystem } from './src/integration.js';

const { doc, fidelity } = importPsd(arrayBuffer);
// 导入后可编辑（引擎 tile 位图）：
applyDocumentToLayerSystem(doc, layerSystem); // 组/混合/不透明度/剪贴/蒙版同步
const psdBuffer = exportPsd(doc);             // 导回 PSD
```

- 组：LayerSystem 仅 1 级；更深的组在集成时按 1 级处理（fidelity 记录组数量，不改结构）。
- 蒙版：通过 `LayerSystem.maskStore` 写入（T37 暂无公开 setter；已在 integration.js 注明内部 API）。
- 引擎内绘制的像素/撤销由 LayerSystem 负责；导出取当前 doc 模型（引擎画布结果需上层回写 doc，M4.4 补）。

## 已知限制

1. 文字层不可编辑（占位空白）；智能对象/图层样式/调整层/矢量同理（记录 + 近似/丢弃）。
2. 组蒙版、组剪贴、多级嵌套组：LayerSystem 集成降级（引擎 T37 限制）。
3. 导入后引擎新增笔画不会自动回写 doc；正式导出需在 M4.4 接「引擎 → doc」同步。
4. PSD 合成图/缩略图不生成（不影响 PS/Procreate 打开）。
5. 非 8-bit / CMYK 等按 8-bit RGB 近似；2/16-bit 精度损失已记录。
6. 测试集为程序生成（含 Procreate 结构模拟），非真实第三方 PSD；后续可补真实 Procreate/PS 文件（需用户提供并记录许可）。

## 许可

- **ag-psd 28.3.1：MIT**（`vendor/ag-psd/LICENSE`）；bundle 内含 **pako 2.1.0 / base64-js 1.5.1（MIT）**。
- **pdf.js Apache-2.0 注记**：继承 T24 第三方清单（ag-psd 文本/字体部分参考关系）；当前 bundle 未包含 pdf.js 代码，若启用相关能力需附 Apache-2.0 许可与 NOTICE（详见 `THIRD_PARTY_NOTICES.md`）。
- 测试集 PSD：本项目生成，**CC0-1.0**；Procreate 样本为结构模拟，不含 Procreate 资产。
- 合并 `product/` 时需将以上条目登记到 `product/THIRD_PARTY_NOTICES.md`（由 Lead 许可流程审核）。
