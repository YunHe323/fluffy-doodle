// v2/qa/tools/test-roadshow-realedit.mjs —— 验证路演第 5 拍「真实提交（约 50s）」：真实编辑 → 按选区落层 → 框外 diff
import { chromium } from '../node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const out = { schema: 'mozheng.roadshow.realedit.v1', cases: {}, errors: [], pass: false };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 300)));
page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 300)); });
try {
  await page.goto('http://127.0.0.1:4200/v2/app/index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
  await sleep(1000);
  await page.click('#btnRoadshow'); await sleep(300);
  await page.click('#btnRoadshowStart');
  await page.waitForFunction('(() => { const t = window.__V2_APP__ && window.__V2_APP__.t122; return !!(t && t.state().prepared); })()', null, { timeout: 60000 });
  await sleep(600);
  await page.evaluate(() => window.__V2_APP__.t122.goto(4)); await sleep(400);
  out.cases.before = await page.evaluate(() => {
    const app = window.__V2_APP__;
    return { selection: app.state.selection, layerCount: app.engine.getLayers().length, realEligible: app.t122.badge().label };
  });
  // 抓 before 画布像素
  await page.evaluate(async () => {
    const app = window.__V2_APP__;
    const url = await app.engine.getCompositeDataUrl();
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = app.engine.width; c.height = app.engine.height;
    c.getContext('2d').drawImage(img, 0, 0);
    window.__RS_BEFORE__ = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
  });
  const t0 = Date.now();
  await page.click('[data-rs-act="realEdit"]');
  await page.waitForFunction('(() => { const t = window.__V2_APP__ && window.__V2_APP__.t122; return !!(t && t.state().appliedReal); })()', null, { timeout: 240000 }).catch(() => {});
  await sleep(1500);
  out.cases.edit = await page.evaluate(() => {
    const app = window.__V2_APP__;
    const st = app.t122.state();
    const layers = app.engine.getLayers();
    const layer = layers.find((l) => l.id === st.editLayerId) || null;
    const gen = (app.state.records || []).filter((r) => r.layer === 'L6' && r.kind === 'generation' && r.params && !r.params.cached_sample && !r.params.preset_sample).slice(-1)[0] || null;
    return { appliedReal: st.appliedReal, editLayerId: st.editLayerId, layerName: layer && layer.name, layerBounds: layer && layer.bounds, layerCount: layers.length, genParams: gen && gen.params, cost: gen && gen.cost_cny, latency: gen && (gen.params && gen.params.latency_ms) };
  });
  out.cases.elapsedMs = Date.now() - t0;
  out.cases.pixels = await page.evaluate(async () => {
    const app = window.__V2_APP__;
    const before = window.__RS_BEFORE__;
    const url = await app.engine.getCompositeDataUrl();
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = app.engine.width; c.height = app.engine.height;
    c.getContext('2d').drawImage(img, 0, 0);
    const after = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    const s = app.state.selection;
    let inside = 0, outside = 0, sampled = 0;
    for (let y = 0; y < c.height; y += 4) {
      for (let x = 0; x < c.width; x += 4) {
        const i = (y * c.width + x) * 4;
        const d = Math.abs(after[i] - before[i]) + Math.abs(after[i + 1] - before[i + 1]) + Math.abs(after[i + 2] - before[i + 2]);
        const isIn = x >= s.x && x < s.x + s.width && y >= s.y && y < s.y + s.height;
        sampled += 1;
        if (d > 6) { if (isIn) inside += 1; else outside += 1; }
      }
    }
    return { sampled, insideChanged: inside, outsideChanged: outside, threshold: 6 };
  });
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-roadshow-real-edit-1920.png' });
  out.cases.badge = await page.evaluate(() => ({ label: (document.getElementById('roadshowBadge') || {}).textContent, meta: (document.getElementById('roadshowMeta') || {}).textContent }));
  out.cases.noErrors = out.errors.length === 0;
  out.pass = !!out.cases.edit.appliedReal && out.cases.pixels.insideChanged > 0 && out.cases.noErrors;
  console.log(JSON.stringify(out, null, 2));
  await browser.close();
  process.exit(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  console.log(JSON.stringify(out, null, 2));
  try { await browser.close(); } catch (err) {}
  process.exit(3);
}
