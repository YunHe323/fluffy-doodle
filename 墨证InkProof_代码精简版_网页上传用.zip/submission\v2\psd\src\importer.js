/**
 * v2/psd · PSD 导入（ag-psd → v2 图层模型）
 *
 * 支持：栅格层 / 组（1+ 级读入）/ 蒙版 / 混合模式 / 不透明度 / 可见性 / 剪贴
 * 不支持项（文字、智能对象、图层样式、调整层、矢量、非 8-bit、非 RGB 等）：
 *   写入 `fidelity.items`，并尽量保留为栅格/空白占位——**不静默丢弃**。
 */
import {
  PSD_TO_INTERNAL, COLOR_MODES, COLOR_MODE_RGB, createDoc, normalizeLayerCanvas,
  normalizeMaskCanvas, clamp01,
} from './model.js';

export function importPsd(buffer, agPsd = window.agPsd) {
  if (!agPsd) throw new Error('importPsd: ag-psd 未加载');
  const ab = toArrayBuffer(buffer);
  const psd = agPsd.readPsd(ab, { skipThumbnail: true });
  const width = psd.width;
  const height = psd.height;
  const colorMode = COLOR_MODES[psd.colorMode] || 'RGB';
  const bitsPerChannel = psd.bitsPerChannel || 8;
  const doc = createDoc(width, height, { colorMode, bitsPerChannel, source: 'psd' });
  const items = [];

  if (colorMode !== 'RGB') {
    items.push({ path: '(doc)', feature: 'colorMode', action: 'approx', detail: `色彩模式 ${colorMode} → 按 RGB 栅格近似（ag-psd 已解码）` });
  }
  if (bitsPerChannel !== 8) {
    items.push({ path: '(doc)', feature: 'bitsPerChannel', action: 'approx', detail: `${bitsPerChannel}-bit → 8-bit 栅格（精度降级）` });
  }

  walk(psd.children || [], doc.children, [], items, { width, height });
  doc.unsupported = items;

  const counts = {};
  for (const it of items) counts[it.feature] = (counts[it.feature] || 0) + 1;
  return {
    doc,
    fidelity: {
      schema: 'mozheng.psd.import.v1',
      generatedAt: new Date().toISOString(),
      source: { width, height, colorMode, bitsPerChannel },
      items,
      summary: { itemCount: items.length, byFeature: counts },
    },
  };
}

function walk(layers, out, path, items, dims) {
  for (let i = 0; i < layers.length; i += 1) {
    const layer = layers[i];
    const name = layer.name || `图层 ${i + 1}`;
    const p = path.concat(name);
    const isGroup = Array.isArray(layer.children);
    const node = {
      type: isGroup ? 'group' : 'layer',
      name,
      visible: !layer.hidden,
      opacity: clamp01(layer.opacity == null ? 1 : layer.opacity),
      blendMode: PSD_TO_INTERNAL[layer.blendMode] || (isGroup ? 'passThrough' : 'normal'),
      clip: !!layer.clipping,
      mask: null,
      canvas: null,
      children: [],
      features: [],
    };

    if (layer.text) {
      node.features.push('text');
      items.push({ path: p.join('/'), feature: 'text', action: 'placeholder-raster', detail: '文字层：内容/排版不可编辑，保留空白占位（ag-psd 不生成文字栅格）' });
    }
    if (layer.smartObject || layer.placedLayer) {
      node.features.push('smartObject');
      items.push({ path: p.join('/'), feature: 'smartObject', action: 'approx', detail: '智能对象：保留可视栅格（若存在），源文件/变换不可编辑' });
    }
    if (layer.effects) {
      node.features.push('effects');
      items.push({ path: p.join('/'), feature: 'effects', action: 'dropped', detail: '图层样式（阴影/发光等）未渲染，已记录' });
    }
    if (layer.adjustment || layer.channelMixer || layer.gradientFill || layer.patternFill) {
      node.features.push('adjustment');
      items.push({ path: p.join('/'), feature: 'adjustment', action: 'dropped', detail: '调整层/填充层未烘焙（栅格近似为空时保留占位）' });
    }
    if (layer.vectorFill || layer.vectorStroke || layer.vectorMask) {
      node.features.push('vector');
      items.push({ path: p.join('/'), feature: 'vector', action: 'approx', detail: '矢量蒙版/描边：仅保留栅格结果（若有），不可编辑' });
    }

    if (isGroup) {
      walk(layer.children, node.children, p, items, dims);
      out.push(node);
      continue;
    }

    const canvas = normalizeLayerCanvas(layer.canvas, layer, dims.width, dims.height);
    if (canvas) node.canvas = canvas;
    else if (!layer.text && !layer.smartObject) {
      items.push({ path: p.join('/'), feature: 'canvas-missing', action: 'dropped', detail: '层没有可用栅格数据（可能为调整层/文字层/空层）' });
    }

    if (layer.mask) {
      if (layer.mask.disabled) {
        items.push({ path: p.join('/'), feature: 'mask-disabled', action: 'approx', detail: '蒙版已禁用 → 导入为启用（保持视觉一致）' });
      }
      const maskCanvas = normalizeMaskCanvas(layer.mask, dims.width, dims.height);
      if (maskCanvas) node.mask = maskCanvas;
      else items.push({ path: p.join('/'), feature: 'mask-missing', action: 'dropped', detail: '蒙版无栅格数据' });
    }
    out.push(node);
  }
}

function toArrayBuffer(buffer) {
  if (buffer instanceof ArrayBuffer) return buffer;
  if (buffer && buffer.buffer) {
    const start = buffer.byteOffset || 0;
    const len = buffer.byteLength || buffer.length || buffer.buffer.byteLength;
    return buffer.buffer.slice(start, start + len);
  }
  throw new Error('importPsd: 不支持的 buffer 类型');
}
