/**
 * v2/library · 图片 → 缩略图 / 调色板 / mock 反解（T70）
 * 复用 v2/app/core/mock-ai.mjs（mockAI@0.1.0），生成 L1 全局 / L2 区域 / L4 观察；
 * 来源三态：L0 observed、L1/L2/L4 inferred、L5 user-confirmed。
 */
import { mockAnalyze, MOCK_MODEL } from '../app/core/mock-ai.mjs';
import { buildAsset, assetIdForSha, LIBRARY_SCHEMA, ASSET_VERSION } from './library-schema.mjs';

export { MOCK_MODEL };

const DEFAULT_THUMB = 320;

function canvas2d(w, h) {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w));
  c.height = Math.max(1, Math.round(h));
  return c;
}

/** 读取图片（dataURL/blob URL） */
export function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('图片加载失败'));
    img.src = src;
  });
}

/** 生成缩略图（PNG dataURL，最长边 maxSide） */
export function makeThumbnail(image, maxSide = DEFAULT_THUMB) {
  const scale = Math.min(1, maxSide / Math.max(image.width, image.height));
  const w = Math.max(1, Math.round(image.width * scale));
  const h = Math.max(1, Math.round(image.height * scale));
  const c = canvas2d(w, h);
  const ctx = c.getContext('2d');
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(image, 0, 0, w, h);
  return { dataUrl: c.toDataURL('image/png'), width: w, height: h };
}

/** 从图片抽样主色（最多 8 个 hex，按出现频率排序） */
export function extractPalette(image, maxColors = 8) {
  const w = 32, h = 32;
  const c = canvas2d(w, h);
  const ctx = c.getContext('2d');
  ctx.drawImage(image, 0, 0, w, h);
  let data;
  try { data = ctx.getImageData(0, 0, w, h).data; } catch (e) { return []; }
  const buckets = new Map();
  for (let i = 0; i < data.length; i += 4) {
    const a = data[i + 3];
    if (a < 24) continue;
    const r = data[i] & 0xf0, g = data[i + 1] & 0xf0, b = data[i + 2] & 0xf0;
    const key = `${r},${g},${b}`;
    buckets.set(key, (buckets.get(key) || 0) + 1);
  }
  return [...buckets.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, maxColors)
    .map(([k, n]) => {
      const [r, g, b] = k.split(',').map(Number);
      const hex = '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('');
      return { hex, weight: Math.round(n / (w * h) * 100) / 100 };
    });
}

/**
 * 对一张图片做 mock 反解，返回可用于入库的 asset（不含缩略图）。
 * @param {{image:HTMLImageElement|ImageBitmap, fileName:string, mime?:string, bytes?:number,
 *          sha256:string, dataUrl?:string, context?:object}} input
 */
export function analyzeImage(input) {
  const image = input.image;
  const width = input.width || image.width;
  const height = input.height || image.height;
  const dataUrl = input.dataUrl || '';
  const analysis = mockAnalyze({
    canvas: { width, height, dataUrl },
    selection: { rect: { x: 0, y: 0, width, height } },
    context: {
      mode: 'collab',
      ai_role: 'assistant',
      projectId: input.context && input.context.projectId,
      fileName: input.fileName,
      ...(input.context || {}),
    },
  });
  const palette = extractPalette(image);
  return buildAsset({
    sha256: input.sha256,
    fileName: input.fileName,
    mime: input.mime || 'image/png',
    bytes: input.bytes || 0,
    width, height,
    analysis,
    palette: palette.map((p) => p.hex),
    modelVersion: analysis.model || MOCK_MODEL,
  });
}

/** 轻量：仅用于已有 dataUrl 的图片（测试/导入共用） */
export async function analyzeDataUrl(dataUrl, meta) {
  const image = await loadImage(dataUrl);
  return analyzeImage({ image, dataUrl, width: image.width, height: image.height, ...meta });
}

export { LIBRARY_SCHEMA, ASSET_VERSION, assetIdForSha };
