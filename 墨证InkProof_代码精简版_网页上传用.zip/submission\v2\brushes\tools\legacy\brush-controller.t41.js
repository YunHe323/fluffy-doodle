/**
 * 【归档副本 · 仅用于 T43 A/B 对照测试】
 * 这是 T41「收债版」的 v2/brushes/src/brush-controller.js（T43 改写前的版本），
 * 原样保存于 tools/legacy/，仅被 tools/continuity-ab.html 加载，用于量化 T43 手感改动的「前后对比」。
 * 生产代码请使用 src/brush-controller.js；本文件不参与 demo/app 运行。
 *
 * 原始注释：
 * T36 笔刷系统 · T41 收债版：不再子类化 Stroke，改为实现 engine 的 StrokePaintProvider 注入点。
 * 已知限制：engine 的 provider.end(ctx) 不提供 canvas/store，因此收笔收锋（taper.end）暂无法在提交前重绘。
 */
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;

export function curveAt(curve, t) {
  if (!curve || curve.length !== 5) return clamp(t, 0, 1);
  const x = clamp(t, 0, 1) * 4;
  const i = Math.min(3, Math.floor(x));
  return lerp(curve[i], curve[i + 1], x - i);
}

function seededRandom(seed) {
  let s = seed >>> 0 || 1;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export async function loadTexture(CK, url) {
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const buf = await res.arrayBuffer();
    return CK.MakeImageFromEncoded(new Uint8Array(buf));
  } catch (e) {
    console.warn('[brushes-legacy] texture load failed:', url, e && e.message);
    return null;
  }
}

export async function loadTextures(CK, manifest, baseUrl) {
  const out = {};
  for (const asset of manifest.assets) {
    const image = await loadTexture(CK, `${baseUrl}${asset.file}`);
    const mask = asset.maskFile ? await loadTexture(CK, `${baseUrl}${asset.maskFile}`) : null;
    if (image) out[asset.id] = { image, mask };
  }
  return out;
}

export function createProviderFromPreset(preset, opts = {}) {
  if (!preset || !preset.size) throw new Error('createProviderFromPreset: 需要 T36 预设');
  const textures = opts.textures || {};
  const colorRef = { value: opts.color || { r: 31, g: 35, b: 40 } };
  const paints = new Map();
  const masks = new Map();
  const shaders = new Map();

  function shaderFor(ctx, assetId) {
    const CK = ctx.CK;
    if (shaders.has(assetId)) return shaders.get(assetId);
    const entry = textures[assetId];
    const img = entry && (entry.mask || entry.image);
    let shader = null;
    if (img) {
      try {
        const texScale = 0.22 / Math.max(0.5, Math.min(4, (preset.texture && preset.texture.scale) || 1));
        shader = img.makeShaderOptions(
          CK.TileMode.Repeat, CK.TileMode.Repeat,
          CK.FilterMode.Linear, CK.MipmapMode.None,
          [texScale, 0, 0, 0, texScale, 0, 0, 0, 1],
        );
      } catch (e) { console.warn('[brushes-legacy] makeShader failed', e && e.message); }
    }
    shaders.set(assetId, shader);
    return shader;
  }

  function paintFor(ctx) {
    const CK = ctx.CK;
    const paintKey = ctx.brush.type === 'eraser' ? 'eraser' : (preset.id || 'preset');
    let paint = paints.get(paintKey);
    if (!paint) {
      paint = new CK.Paint();
      paint.setAntiAlias(true);
      paint.setStyle(CK.PaintStyle.Fill);
      paints.set(paintKey, paint);
    }
    const dyn = preset.dynamics || {};
    const pressure = clamp(ctx.pressure == null ? 0.5 : ctx.pressure, 0, 1);
    const velocityNorm = clamp(ctx.velocity / 2, 0, 1);
    const tiltNorm = Math.min(1, Math.hypot(ctx.tiltX || 0, ctx.tiltY || 0) / 90);
    if (preset.engine && preset.engine.eraser) {
      paint.setBlendMode(CK.BlendMode.Clear);
      paint.setShader(null);
      paint.setColorFilter(null);
      paint.setMaskFilter(null);
      paint.setAlphaf(1);
      return paint;
    }
    paint.setBlendMode(CK.BlendMode.SrcOver);
    let alpha = preset.opacity.base * curveAt(preset.opacity.pressureCurve, pressure);
    alpha = preset.opacity.min + (alpha - preset.opacity.min);
    alpha *= Math.pow(clamp(preset.flow.base, 0.02, 1), 0.55);
    if (dyn.speedOpacityFactor) alpha *= 1 + dyn.speedOpacityFactor * (velocityNorm - 0.3);
    if (dyn.tiltOpacityFactor) alpha *= 1 + dyn.tiltOpacityFactor * tiltNorm * 0.5;
    alpha = clamp(alpha, 0, 1);
    const textureId = preset.texture && preset.texture.assetId;
    const shader = textureId ? shaderFor(ctx, textureId) : null;
    const radius = ctx.radius || 1;
    paint.setShader(null);
    paint.setColorFilter(null);
    if (shader) {
      paint.setShader(shader);
      try {
        const mode = CK.BlendMode.Modulate;
        paint.setColorFilter(CK.ColorFilter.MakeBlend(CK.Color(colorRef.value.r, colorRef.value.g, colorRef.value.b, 1), mode));
      } catch (e) { /* 老版本无 MakeBlend 时降级 */ }
      paint.setAlphaf(alpha);
    } else {
      paint.setColor(CK.Color(colorRef.value.r, colorRef.value.g, colorRef.value.b, alpha));
    }
    const hardness = clamp(preset.hardness.base + (preset.hardness.pressureFactor || 0) * (pressure - 0.5), 0, 1);
    const sigma = Math.max(0, 1 - hardness) * radius * 0.85;
    if (sigma > 0.6) {
      const key = sigma.toFixed(2);
      let mask = masks.get(key);
      if (!mask) {
        mask = CK.MaskFilter.MakeBlur(CK.BlurStyle.Normal, sigma, true);
        masks.set(key, mask);
      }
      paint.setMaskFilter(mask);
    } else {
      paint.setMaskFilter(null);
    }
    return paint;
  }

  function radiusFor(ctx) {
    const dyn = preset.dynamics || {};
    const pressure = clamp(ctx.pressure == null ? 0.5 : ctx.pressure, 0, 1);
    let r = (preset.size.base * 0.5) * curveAt(preset.size.pressureCurve, pressure);
    const velocityNorm = clamp(ctx.velocity / 2, 0, 1);
    const tiltNorm = Math.min(1, Math.hypot(ctx.tiltX || 0, ctx.tiltY || 0) / 90);
    if (dyn.tiltSizeFactor) r *= 1 + dyn.tiltSizeFactor * tiltNorm * 0.6;
    if (dyn.speedSizeFactor) r *= 1 + dyn.speedSizeFactor * (velocityNorm - 0.3);
    const taperStart = preset.taper && preset.taper.start ? preset.taper.start : 0;
    if (taperStart > 0) {
      const len = Math.max(6, preset.size.base * taperStart * 2);
      const dist = ctx.distance || 0;
      r *= clamp(dist / len, 0.2, 1);
    }
    return Math.max(0.5, r);
  }

  return {
    id: `t36-${preset.id || 'preset'}`,
    name: preset.name || 'T36 preset',
    preset,
    begin(ctx) { void ctx; },
    radiusFor,
    paintFor,
    stampFor(ctx) {
      if (!ctx.paint) return;
      ctx.canvas.drawCircle(ctx.x, ctx.y, ctx.radius, ctx.paint);
    },
    end(ctx) { void ctx; },
    cancel(ctx) { void ctx; },
    setColor(rgb) { colorRef.value = rgb; },
    dispose() {
      for (const p of paints.values()) { try { p.delete(); } catch (e) { /* ignore */ } }
      for (const m of masks.values()) { try { m.delete(); } catch (e) { /* ignore */ } }
      for (const s of shaders.values()) { try { s && s.delete(); } catch (e) { /* ignore */ } }
      paints.clear(); masks.clear(); shaders.clear();
    },
  };
}

export class BrushController {
  constructor(engine, preset, opts = {}) {
    this.engine = engine;
    this.preset = JSON.parse(JSON.stringify(preset));
    this.opts = opts || {};
    this.provider = createProviderFromPreset(this.preset, { textures: this.opts.textures, color: this.opts.color });
    engine.setBrushProvider(this.provider);
    this.lastRaw = null;
    this.smoothed = null;
    this.lastStamp = null;
    this.strokeSeed = 1;
    this.rng = seededRandom(1);
    this.pointCount = 0;
  }

  get brushSpec() {
    return { type: this.preset.engine && this.preset.engine.eraser ? 'eraser' : 'brush', sizePx: this.preset.size.base, opacity: this.preset.opacity.base };
  }

  setPreset(preset) {
    this.preset = JSON.parse(JSON.stringify(preset));
    const old = this.engine.getBrushProvider ? this.engine.getBrushProvider() : null;
    this.provider = createProviderFromPreset(this.preset, { textures: this.opts.textures, color: this.opts.color });
    this.engine.setBrushProvider(this.provider);
    if (old && old !== this.provider && typeof old.dispose === 'function') {
      try { old.dispose(); } catch (e) { /* ignore */ }
    }
  }

  setColor(rgb) {
    this.opts.color = rgb;
    if (this.provider && typeof this.provider.setColor === 'function') this.provider.setColor(rgb);
  }

  setParam(path, value) {
    const parts = path.split('.');
    let o = this.preset;
    for (let i = 0; i < parts.length - 1; i += 1) o = o && o[parts[i]];
    if (o) o[parts[parts.length - 1]] = value;
    if (this.provider) this.provider.preset = this.preset;
  }

  begin(p) {
    const engine = this.engine;
    if (!engine || !engine.ready) throw new Error('engine not ready');
    if (engine.currentStroke) engine.cancelStroke();
    this.strokeSeed = (Date.now() % 1e9) + 1;
    this.rng = seededRandom(this.strokeSeed);
    this.pointCount = 0;
    this.lastRaw = { ...p };
    this.smoothed = { x: p.x, y: p.y, pressure: p.pressure == null ? 0.5 : p.pressure, timestamp: p.timestamp || performance.now() };
    engine.beginStroke(this.smoothed, this.brushSpec);
    this.lastStamp = { ...this.smoothed };
    engine.requestFrame();
    return true;
  }

  append(p) {
    if (!this.engine || !this.engine.currentStroke) return;
    const preset = this.preset;
    const stab = preset.smoothing ? preset.smoothing.stabilizer : 0;
    const k = 1 / (1 + stab * 9);
    this.lastRaw = { ...p };
    this.smoothed = {
      x: lerp(this.smoothed.x, p.x, 1 - k),
      y: lerp(this.smoothed.y, p.y, 1 - k),
      pressure: p.pressure == null ? this.smoothed.pressure : p.pressure,
      tiltX: p.tiltX || 0,
      tiltY: p.tiltY || 0,
      timestamp: p.timestamp || performance.now(),
    };
    const target = this.smoothed;
    let guard = 0;
    while (guard < 200) {
      guard += 1;
      const pressure = this.lastStamp.pressure == null ? 0.5 : this.lastStamp.pressure;
      const curRadius = (preset.size.base * 0.5) * curveAt(preset.size.pressureCurve, pressure);
      const step = Math.max(preset.spacing.minPx, curRadius * 2 * preset.spacing.ratio);
      const d = Math.hypot(target.x - this.lastStamp.x, target.y - this.lastStamp.y);
      if (d < step) break;
      const t = step / d;
      const next = {
        x: lerp(this.lastStamp.x, target.x, t),
        y: lerp(this.lastStamp.y, target.y, t),
        pressure: lerp(pressure, target.pressure, t),
        tiltX: target.tiltX, tiltY: target.tiltY,
        timestamp: target.timestamp,
        pointerType: target.pointerType || 'synthetic',
      };
      this._emit(next);
      this.lastStamp = next;
    }
    this.engine.requestFrame();
  }

  _emit(p) {
    const preset = this.preset;
    this.pointCount += 1;
    const scatter = preset.scatter || { count: 1, positionJitter: 0 };
    const count = Math.max(1, scatter.count | 0);
    const base = { x: p.x, y: p.y, pressure: p.pressure, tiltX: p.tiltX, tiltY: p.tiltY, timestamp: p.timestamp, pointerType: p.pointerType };
    for (let i = 0; i < count; i += 1) {
      const jitter = i === 0 ? { x: 0, y: 0 } : {
        x: (this.rng() - 0.5) * 2 * scatter.positionJitter * preset.size.base * 0.5,
        y: (this.rng() - 0.5) * 2 * scatter.positionJitter * preset.size.base * 0.5,
      };
      this.engine.appendPoint({ ...base, x: p.x + jitter.x, y: p.y + jitter.y }, { flush: false });
    }
    this.engine.requestFrame();
  }

  end() {
    if (!this.engine || !this.engine.currentStroke) return null;
    return this.engine.endStroke();
  }

  cancel() {
    if (this.engine && this.engine.currentStroke) this.engine.cancelStroke();
  }

  undo() { return this.engine.undo(); }
  redo() { return this.engine.redo(); }
}
