// v2/app/test-editor-basics.mjs —— 数值变换 / 选区复制粘贴 / 图层复制重命名 / AI 会话时间线
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8150;
const out = { schema: 'mozheng.app.editor-basics.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  fs.writeFileSync(ROOT + '\\v2\\app\\test-editor-basics-result.json', JSON.stringify(out, null, 2), 'utf8');
  process.exit(code);
};
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1200);
  // 先在画布上画一笔，保证有内容可复制
  const box = await page.locator('#mainCanvas').boundingBox();
  const cx = box.x + box.width / 2, cy = box.y + box.height / 2;
  await page.mouse.move(cx - 80, cy - 30); await page.mouse.down(); await page.mouse.move(cx + 80, cy + 40, { steps: 8 }); await page.mouse.up();
  await page.waitForTimeout(400);
  // 1) 选区 → Ctrl+C → Ctrl+V：图层 +1
  out.cases.copyPaste = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    a.state.selection = { x: 500, y: 300, width: 200, height: 140 };
    a.drawSelection();
    const before = a.engine.getLayers().length;
    const ok = await a.copySelectionPixels(false);
    const mid = a.engine.getLayers().length;
    const pasted = await a.pasteClipboardPixels();
    return { before, mid, after: a.engine.getLayers().length, copyOk: ok, pasted: !!pasted, clipboard: !!a.pixelClipboard || 'internal' };
  });
  await page.waitForTimeout(300);
  // 2) 数值变换：设置 W=200 H=120 X=100 Y=80
  out.cases.numeric = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    a.setTool('transform');
    await new Promise((r) => setTimeout(r, 200));
    const set = (id, v) => { const el = document.getElementById(id); el.value = String(v); el.dispatchEvent(new Event('change', { bubbles: true })); };
    set('trW', 200); set('trH', 120); set('trX', 100); set('trY', 80);
    await new Promise((r) => setTimeout(r, 150));
    const b = a.engine.getTransformBounds();
    const inputs = ['trX', 'trY', 'trW', 'trH', 'trRot'].map((id) => Number(document.getElementById(id).value));
    return { bounds: b, inputs };
  });
  await page.evaluate(() => window.__V2_APP__.commitTransformUI());
  await page.waitForTimeout(300);
  // 3) Ctrl+J 复制图层
  out.cases.duplicate = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    const before = a.engine.getLayers().length;
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'j', ctrlKey: true, bubbles: true }));
    await new Promise((r) => setTimeout(r, 200));
    return { before, after: a.engine.getLayers().length };
  });
  // 4) 双击图层名重命名
  out.cases.rename = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    const row = document.querySelector('#layerList .layer-row:not(.group-row)');
    const nameEl = row && row.querySelector('.ly-name');
    if (!nameEl) return { ok: false };
    nameEl.dispatchEvent(new MouseEvent('dblclick', { bubbles: true }));
    await new Promise((r) => setTimeout(r, 100));
    const input = row.querySelector('input');
    if (!input) return { ok: false };
    input.value = '测试重命名'; input.dispatchEvent(new Event('blur'));
    await new Promise((r) => setTimeout(r, 150));
    const names = a.engine.getLayers().map((l) => l.name);
    return { ok: names.includes('测试重命名'), names };
  });
  // 4b) 历史面板：打开更多，点最旧一条，undo depth 下降
  await page.evaluate(() => window.__V2_APP__.openPopover('popMore'));
  await page.waitForTimeout(250);
  out.cases.history = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const before = a.engine.getStats().undoDepth;
    const rows = [...document.querySelectorAll('#historyList [data-history-depth]')];
    const target = rows.length ? rows[rows.length - 1] : null;
    if (target) target.click();
    return { rows: rows.length, before, after: a.engine.getStats().undoDepth, clicked: !!target };
  });
  await page.evaluate(() => window.__V2_APP__.closePopovers());
  await page.waitForTimeout(150);
  // 5) Mock AI 会话时间线
  await page.evaluate(() => { const a = window.__V2_APP__; a.t96.setToggles({ allowReal: false, privacyMode: true }); a.state.selection = { x: 260, y: 220, width: 380, height: 260 }; });  await page.evaluate(() => window.__V2_APP__.runAnalyze());
  await page.waitForTimeout(900);
  out.cases.aiSession = await page.evaluate(() => {
    const a = window.__V2_APP__;
    return { session: a.state.aiSession.length, rows: document.querySelectorAll('#aiBody .ai-session-row').length, steps: document.querySelectorAll('#aiBody .ai-step').length, cancelHidden: document.getElementById('btnAiCancel').hidden };
  });
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-editor-basics-1920.png' });
  out.cases.copyOk = out.cases.copyPaste.copyOk && out.cases.copyPaste.after > out.cases.copyPaste.before;
  out.cases.numericOk = !!out.cases.numeric.bounds && Math.abs(out.cases.numeric.bounds.w - 200) < 2 && Math.abs(out.cases.numeric.bounds.h - 120) < 2 && Math.abs((out.cases.numeric.bounds.cx - out.cases.numeric.bounds.w / 2) - 100) < 3;
  out.cases.duplicateOk = out.cases.duplicate.after === out.cases.duplicate.before + 1;
  out.cases.renameOk = !!out.cases.rename.ok;
  out.cases.historyOk = out.cases.history.rows >= 1 && out.cases.history.clicked && out.cases.history.after < out.cases.history.before;
  out.cases.aiSessionOk = out.cases.aiSession.session >= 1 && out.cases.aiSession.rows >= 1 && out.cases.aiSession.steps === 5;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.copyOk && out.cases.numericOk && out.cases.duplicateOk && out.cases.renameOk && out.cases.historyOk && out.cases.aiSessionOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  await finish(3);
}
