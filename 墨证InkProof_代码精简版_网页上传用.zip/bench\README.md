# bench/ · 统一画布引擎 Benchmark（v0.1 规格）

> 项目一 · T26 交付物（第 1 部分：harness 规格与数据格式）
> 作者：tech-architect｜日期：2026-11-06｜状态：**规格定稿，T25 可据此实现 adapter**
> 依据：`06-技术/画布引擎v2_预研.md` §6（本文件的指标来源）、`00-画布引擎v2计划.md` §1/§3
> 目标：让 **Klecks（T25）** 与 **CanvasKit（T26）** 两条 spike 用**同一页面、同一 case、同一口径**产出可比较数据；选型只认这些数据。

---

## 0. 现状与边界

- 当前目录只有本规范与（即将加入的）`bench/index.html`；两条 spike 各自在 `spike/klecks/`、`spike/canvaskit/` 实现 adapter 并在报告里引用本页导出的 JSON。
- **不接入 product/**；不修改 `product/app|server|core|test`。
- 本 benchmark 是**工程对比工具**，不是产品功能；允许粗糙，但测量口径必须固定。
- 许可：页面与 harness 代码自制（MIT 目标）；两条 spike 引入的库按各自许可（Klecks MIT / CanvasKit BSD-3），不引入 GPL。

---

## 1. 目录

```
bench/
├─ README.md              ← 本文件（口径/格式/用法）
├─ index.html             ← 统一测量页面（零依赖，单文件；已交付）
├─ adapter-template.js    ← BenchAdapter 模板（T25/T29/T26 复制后实现）
├─ results/
│  ├─ klecks.json         ← T25 产出（由页面导出后放入）
│  ├─ webgl2.json         ← T29 产出
│  └─ canvaskit.json      ← T26 产出（vendor 到位后）
└─ tools/
   └─ compare.mjs         ← 零依赖：两份 JSON → markdown 对比表 + 硬门槛判定
```

> T25 与 T26 的 adapter 代码放在各自 `spike/<name>/` 下，**不复制到 bench/**；页面通过 `<script>` 或本地 URL 加载各自的 adapter 文件。

---

## 2. 运行方式

```bash
# 在仓库根目录（bench/ 与 spike/ 的父目录）起任意静态服务（WASM 需要 http，不能 file://）
python -m http.server 8080
# 打开 http://127.0.0.1:8080/bench/index.html
```

- 页面不依赖任何外部 CDN/字体/网络；CanvasKit spike 的 `canvaskit.wasm` 由 `spike/canvaskit/vendor/` 本地提供。
- 机器要求：同一台机器、同一浏览器（推荐 Chrome/Edge 稳定版）、关闭省电模式/扩展；接手绘板时记录型号。
- 首次运行先做 2 次 warmup（不计入），正式每 case 跑 3 次取中位数；页面自动记录环境信息。

---

## 3. Adapter 契约（T25/T26 必须实现）

页面只通过全局 `window.BenchAdapter` 驱动被测引擎，避免页面耦合具体实现：

```js
/** @typedef {Object} BenchAdapter */
window.BenchAdapter = {
  id: 'klecks',                 // 'klecks' | 'canvaskit' | 'custom'
  version: '0.0.0',             // 被测代码版本/commit（写进结果 JSON）
  license: 'MIT',               // 被测引擎许可（写进结果 JSON）

  /**
   * 初始化画布。
   * @param {{canvas: HTMLCanvasElement, width: number, height: number, layers: number,
   *          blendMode?: string, brush?: {type: string, sizePx: number}}} config
   */
  async init(config) {},

  /** 笔画生命周期：坐标为画布 CSS 像素；pressure 0–1；timestamp 为事件 timeStamp（ms） */
  beginStroke(point) {},        // point = {x, y, pressure, timestamp, pointerType, tiltX?, tiltY?}
  moveStroke(point) {},
  endStroke() {},

  /** 撤销 n 步（用于 undo 计时；每次 undo 后页面会等待一次 rAF） */
  async undo(steps) {},

  /** 合成图导出（视觉采样/完整性用） */
  async getCompositeDataUrl() {},   // PNG dataURL

  /** 额外统计（可选）：显存估算、tile 数、纹理数等 */
  getStats() { return {}; },

  dispose() {},
};
```

**adapter 必须保证**：
1. `moveStroke` 返回后，该点已进入渲染管线（页面在下一个 rAF 记录延迟；若引擎内部异步合帧，需在标记时机调用 `window.benchPointDrawn?.(timestamp)` 以便页面记录真实呈现时间）。
2. 不修改画布尺寸/DOM 结构以外的全局状态；不主动下载/上传。
3. `undo` 计时包含引擎内部完成时间（页面只测 await 前后差值）。
4. **可选方法**：`setBlendMode(mode)`（B5 混合模式测量需要；未实现则该 case 报错跳过）、`getStats()`（扩展统计，放 `case.extras`，不得挤占标准字段）。
5. 复制起点：`bench/adapter-template.js`（含注释与 TODO）；T25/T29/T26 各自在 `spike/<route>/adapter.js` 实现，**不复制到 bench/**。

---

## 4. 测量协议（写死，两条路线完全一致）

### 4.1 环境信息（每个结果必带）

`ua / browser+version / os / GPU vendor+renderer（WebGL `WEBGL_debug_renderer_info` 或 CanvasKit 报告）/ refreshHz（rAF 实测）/ devicePixelRatio / pointerType / canvas 尺寸 / 被测 adapter id+version+license / 时间戳`

### 4.2 笔迹延迟（核心指标）

- 合成路径：脚本以固定速度在画布上画 S 形轨迹（每帧 1–3 个点，模拟 60/120/144Hz 输入），每个点携带 `event.timeStamp`。
- 延迟 = **该点被渲染进合成帧的时间 − 事件 timeStamp**；页面在 rAF 回调中记录 `performance.now()`，adapter 若异步呈现则用 `window.benchPointDrawn(ts)` 回填更准确的呈现时间。
- 统计 P50 / P95 / 最差 / 样本数；报告里必须注明「**代理指标**：浏览器无法观测真实扫描out，数值偏乐观；两路线比较以同口径为准」。
- 同时记录 `pointerType`（pen/mouse）；鼠标时用速度映射 pressure（见 §4.5）。

### 4.3 帧率

- 连续绘制 **10 秒**（B1 轨迹循环），统计 rAF 间隔：`fpsP50 / fpsP95 / maxFrameMs / droppedFrames`。
- 判定以 fps P95（恶劣帧）与 maxFrameMs 为主，避免只看平均。

### 4.4 内存

- `performance.memory.usedJSHeapSize`（Chromium，非标准）在 case 前/后/30s 采样；报告 `jsHeapMB`、增量、线性回归斜率（泄漏趋势）。
- GPU/tile 内存不可直接观测：adapter `getStats()` 可回填 `gpuEstimateMB/tileCount`（仅备注，不作为硬门槛依据）。
- 30 分钟长跑（B9）单独记录每 60s 采样序列。

### 4.5 压感模拟

- `pointerType === 'pen'`：用真实 `PointerEvent.pressure` / `tiltX/tiltY`。
- 无手绘板时：用移动速度反比映射 `pressure = clamp(1 - speed/maxSpeed, 0.2, 1)`，并在结果 `environment.pointerType = 'mouse-simulated-pressure'`；**两种来源的结果不可直接混比**。
- **当前用户环境只有鼠标**：所有报告必须标注「软件/无压感硬件」；延迟数字不得当作最终结论（已记录于 `00-画布引擎v2计划.md`）。

### 4.6 undo

- 画 20 笔（每笔 ≤200 点）后连续 undo 80 步（不足则按实际步数），记录每步耗时：`undoP50/undoP95/undoMaxMs`。
- 同时记录 undo 前后 heap 差值（近似历史内存）。

### 4.7 画质采样

- 固定笔刷参数绘制 8 条标准笔迹（直线/大弧/压感斜坡/快速折返/纹理/橡皮/两种大小），导出 PNG dataURL 存结果 JSON 的 `visualSamples`（或另存 `bench/results/<route>-brushes.png` 并在 JSON 引用）。
- 盲评：3 名插画师/美术生 5 分制（与 v0.1 对比），结果写进 spike 报告，不进 JSON 硬指标。

### 4.8 冷启动

- `performance.timeOrigin` → adapter 首帧可用（`init` resolve + 首帧 rAF）时间；CanvasKit 额外记录 wasm 下载/实例化/首帧分段。

### 4.9 PSD（B8，可选/外部）

- 不在页面内跑；由 T26 用 node 或页面外的脚本对 10 个固定 PSD 执行「导入→导出→重导入」，记录层数/组/蒙版/混合模式/不透明度一致性与合成图 MAE；结果作为独立 JSON 附在 `bench/results/<route>-psd.json`，字段见 §5.4。

---

## 5. 结果 JSON 格式（`mozheng.bench.v1`）

### 5.1 顶层

```json
{
  "schema": "mozheng.bench.v1",
  "createdAt": "2026-11-06T12:00:00Z",
  "adapter": { "id": "canvaskit", "version": "0.1.0+<commit>", "license": "BSD-3-Clause" },
  "engine": { "name": "CanvasKit/Skia", "notes": "tile 256; baseline v0.1 composite=" },
  "environment": {
    "ua": "...", "browser": "Chrome 160", "os": "Windows 11",
    "gpuVendor": "...", "gpuRenderer": "...", "rendererApi": "CanvasKit/WebGL2",
    "refreshHz": 144, "devicePixelRatio": 1, "pointerType": "pen",
    "machine": "同机对比编号 M1（Lead 指定）"
  },
  "cases": [ { "...": "见 5.2" } ],
  "verdict": {
    "score": 0.0,
    "weights": { "latency": 0.3, "fps": 0.25, "memory": 0.15, "quality": 0.15, "psd": 0.1, "effort": 0.05 },
    "hardFail": ["latencyP95"],
    "notes": []
  }
}
```

### 5.2 case 条目

```json
{
  "id": "B1",
  "description": "2048² × 20 层，64px 软圆笔，S 形 3 秒",
  "config": { "canvas": [2048, 2048], "layers": 20, "brush": "soft-round", "sizePx": 64, "blend": "normal" },
  "runs": 3,
  "samples": { "latencyMs": [12.1, 13.0], "frameMs": [14.2, 14.8] },
  "summary": { "latencyP50": 12.1, "latencyP95": 16.3, "latencyMax": 21.0,
               "fpsP50": 68, "fpsP95": 61, "maxFrameMs": 22.0,
               "undoP50": 0, "undoP95": 0, "jsHeapMB": 210, "jsHeapDeltaMB": 4 },
  "pass": { "latency": true, "fps": true, "memory": true },
  "visualSampleRef": "bench/results/canvaskit-brushes.png#B1"
}
```

### 5.3 必填 vs 可选

- 必填：`schema/adapter/environment/cases[].id/config/summary/pass`。
- 可选：`engine.notes`、`getStats()` 回填的扩展字段（放 `case.extras`，不得挤占标准字段）。

### 5.4 PSD 结果（独立文件）

```json
{ "schema": "mozheng.bench.psd.v1", "route": "canvaskit",
  "samples": [{ "file": "case-01.psd", "layersIn": 12, "layersOut": 12,
                "groups": true, "masks": true, "blendModes": "5/5", "opacity": true,
                "compositeMAE": 0.012, "pass": true, "notes": "" }],
  "summary": { "passRate": 0.8, "notes": "调整层被合并（预期）" } }
```

---

## 6. Case 矩阵（与 T24 §6.1 一致，页面逐一跑）

| ID | 画布 | 层数 | 操作 | 主要看 |
|---|---|---|---|---|
| B1 | 2048² | 20 | 64px 软圆笔 S 形 3s ×3 | 延迟/fps |
| B2 | 2048² | 20 | 8px 铅笔快速短笔画 200 笔 | 小笔刷延迟/掉帧 |
| B3 | 4096² | 8 | 64px 软圆笔 3s | 大画布 fps/内存 |
| B4 | 4096² | 8 | 256px 纹理笔刷 2s | 纹理采样性能 |
| B5 | 2048² | 20 | multiply/soft-light 合成切换 10 次 | 混合模式成本 |
| B6 | 2048² | 20 | 20 笔后 undo 80 步 | undo 单步/内存 |
| B7 | 2048² | 10 | 冷启动 → 首帧 | 冷启动（含 wasm 分段） |
| B8 | — | — | 10 个 PSD 往返（外部脚本） | PSD 保真 |
| B9 | 2048² | 20 | 30 分钟随机笔画（可选，长跑） | 泄漏/崩溃 |

**执行顺序**：warmup（B1×2）→ B7 → B1 → B2 → B3 → B4 → B5 → B6 →（可选 B9）；每 case 间刷新页面，避免状态污染。

---

## 7. 判定与打分（与 T24 §6.4 一致）

| 项 | 权重 | 硬门槛（不过即淘汰） |
|---|---|---|
| 延迟 | 30% | P50 ≤16ms 且 P95 ≤33ms（B1） |
| 帧率 | 25% | B1 ≥55fps；B3 ≥45fps（fps P95） |
| 内存 | 15% | B3 ≤800MB，B9 无持续泄漏 |
| 画质 | 15% | 盲评 ≥4/5（与 v0.1 对比） |
| PSD/图层 | 10% | B8 passRate ≥80%（子集：栅格+组+蒙版+5 混合模式） |
| 工程代价 | 5% | 人日估算在预算内（R2 ≤55 / R1 ≤40，见预研 §3） |

- `verdict.hardFail` 列出未过硬门槛的项；任一路线硬门槛不过 → 淘汰。两路线都不过 → 回用户决策（降级目标或 R3 长周期）。
- 评分仅用于**排序**，不允许用加权总分掩盖硬门槛。

---

## 8. 有效性要求（防「看起来达标」）

1. **同机同浏览器**：两路线必须同一台机器、同一浏览器版本、同一刷新率设置；结果 JSON 的 `environment.machine` 相同。
2. **同 case 同轨迹**：页面用固定 seed 生成轨迹与压感序列，两路线一致。
3. **warmup 与中位数**：每 case 2 次 warmup + 3 次正式取中位数；记录离散度（P95 已含）。
4. **禁用干扰**：关闭省电模式/后台标签/扩展；不插外接 4K 屏改变刷新率。
5. **代理指标声明**：延迟为「输入→帧提交」代理，不声称等于屏上感知延迟；报告里必须写明。
6. **不得删除离群点**：可报告但不得从原始 `samples` 中删除；分析时说明。
7. **结果可复现**：结果 JSON 必须带 adapter 版本/commit 与页面版本；页面顶部显示 `bench v0.1`。

---

## 9. T25 / T26 的分工

| 角色 | 任务 | 产出 |
|---|---|---|
| T25（demo-builder） | 在 `spike/klecks/` 实现 `window.BenchAdapter`（Klecks 渲染 + 压力笔刷 + 图层 + undo），用 `bench/index.html` 跑 B1–B7/B9 | `bench/results/klecks.json`（+ 截图）+ `spike/klecks/README.md` |
| T29（demo-builder） | 零依赖 WebGL2 tile spike（`spike/webgl/`）：同一 adapter 契约、同一 B1–B9、同一 JSON；结果写 `bench/results/webgl2.json` | `spike/webgl/评估报告.md` + `bench/results/webgl2.json` |
| T26（tech） | 提供 `bench/index.html` 与对比脚本；在 `spike/canvaskit/` 实现 adapter；跑同矩阵；收集包体/首屏数据 | `bench/index.html`、`bench/results/canvaskit.json`、`spike/canvaskit/评估报告.md` |
| Lead | 主持选型会，按 §7 硬门槛 + 数据 | 选型决定（M3） |

> T25 若先于 `bench/index.html` 就绪，可先按本规格实现 adapter，页面就绪后再接；adapter 契约不变。

---

## 10. 变更记录与待办

| 版本 | 日期 | 变更 |
|---|---|---|
| 0.1.0 | 2026-11-06 | 首版规格：adapter 契约、B1–B9 矩阵、JSON 格式、口径与打分（与 T24 §6 对齐） |

**待办（T26 剩余）**：
1. ✅ `bench/index.html`（零依赖单文件）：环境采集、B1–B7/B9 自动跑、手动真实指针模式、结果 JSON 导出、表格展示。
2. ✅ `bench/tools/compare.mjs`：读两份 JSON → markdown 对比表 + 硬门槛判定（`--strict` 失败 exit 1）。
3. ✅ `bench/adapter-template.js`：adapter 模板（T25/T29/T26 共用契约）。
4. ⏳ CanvasKit vendor：等待 `spike/_vendor/canvaskit-wasm-*.tgz` → 按 `spike/canvaskit/README.md` §2 解包并登记哈希；之后实现 adapter、跑 bench、写 `spike/canvaskit/评估报告.md`。
5. ⏳ 与 T25（Klecks）/T29（WebGL2）结果合并成选型会材料（含包体、内存、首屏、人日复估）。

**未决（交 Lead/用户）**：
- 若目标设备包含 iPad/Safari，需追加一组 iPad 数据（本规格先桌面 Chromium）。
- 手绘板型号/刷新率会影响延迟结论，需在选型会前固定测试机。

---

## 11. 离线 Vendor 与 T29/Klecks 对齐（2026-11-06）

- **Vendor 状态**：`spike/_vendor/klecks-main.zip` 已由用户放置（T25 使用）；`canvaskit-wasm-*.tgz` 待放置。放置后按 `spike/canvaskit/README.md` §2 解包 → 拷入 `spike/canvaskit/vendor/` → 登记版本与 SHA-256 → 更新 `product/THIRD_PARTY_NOTICES.md`（BSD-3，由 Lead 许可流程审核）。
- **T29 对齐**：T29（零依赖 WebGL2 tile spike，`spike/webgl/`）与 T25/T26 使用**同一 adapter 契约（§3）、同一 B1–B9 用例（§6）、同一 `mozheng.bench.v1` JSON（§5）**；T29 复制 `bench/adapter-template.js` 实现，结果写 `bench/results/webgl2.json`。
- **选型材料**：三条路线结果统一用 `node bench/tools/compare.mjs a.json b.json` 生成同一张表；选型只认该表 + §7 硬门槛，不允许用单项平均分掩盖硬门槛失败。
- **无压感硬件**：当前用户只有鼠标（速度模拟压感）；报告必须标注「软件/无压感硬件」，延迟数字不作最终结论。
- **零外网**：本目录全部文件（页面/模板/脚本）零依赖、无外部 CDN/字体/请求；`compare.mjs` 只读文件并打印。

---

## 12. P1/P2 前置复测（T34，仅 CanvasKit 先跑）

> 选型文档 §7 要求：P1（20 层全满）与 P2（80 步满栈 undo）通过后才进入 M4。R2 主候选已跑通；R3 仅在 R2 失败时按回退条款补测。

| case | 内容 | 通过标准 | 工具 |
|---|---|---|---|
| `P1-2048x2048-20L` | 2048²×20 层全满（每层全尺寸内容）+ 顶层笔迹 3s | fps P95 ≥55；估算内存 ≤800MB | `bench/p1p2.html?case=p1-2048` |
| `P1-4096x4096-8L` | 4096²×8 层全满 + 顶层笔迹 3s | fps P95 ≥45；估算内存 ≤800MB | `bench/p1p2.html?case=p1-4096` |
| `P2-undo80` | 2048² 真实 80 笔 → undo 80 步 | undo P95 ≤100ms；历史估算≤400MB；全撤后空白校验 | `bench/p1p2.html?case=p2` |

- 结果：`bench/results/canvaskit-p1p2.json` + 报告 `bench/results/canvaskit-p1p2.md`。
- 内存估算口径：图层纹理(w×h×4×layers) + 主 surface(w×h×4) + WASM 堆（不含 GPU 驱动/缓存）；P2 历史为 Picture 指令记录，非整层快照。
- 环境必须标注：GPU / 是否 headless / 无压感硬件；延迟为代理指标。
