// v2/app/test-present.mjs — T90 app 默认 dirty present（≤2048²）/ 大文档 full
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8124;
const out = { schema: 'mozheng.app.present-test.v1', cases: {}, errors: [] };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
let browser = null; let errors = [];
const finish = (code = 0) => { try { fs.writeFileSync(ROOT + '\\v2\\app\\test-present-result.json', JSON.stringify(out, null, 2), 'utf8'); } catch (e) {} process.exit(code); };
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_240s'; finish(3); }, 240000);
try {
  await new Promise((r) => setTimeout(r, 800));
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const context = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  const page = await context.newPage();
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  const load = async (w = 1366, h = 768) => {
    await page.setViewportSize({ width: w, height: h });
    await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
    await page.waitForTimeout(700);
  };
  await load();
  out.cases.init = await page.evaluate(() => {
    const app = window.__V2_APP__; const t = app.t90;
    return { get: t.get(), decide: { small: t.decide(1200, 800), edge: t.decide(2048, 2048), large: t.decide(4096, 4096), over: t.decide(2049, 2048) }, about: document.getElementById('aboutPresent') ? document.getElementById('aboutPresent').textContent : null };
  });
  const box = await page.locator('#mainCanvas').boundingBox();
  const draw = async (n = 1) => {
    for (let k = 0; k < n; k += 1) {
      const y = 0.28 + k * 0.03;
      await page.mouse.move(box.x + box.width * 0.28, box.y + box.height * y);
      await page.mouse.down();
      for (let i = 1; i <= 10; i++) await page.mouse.move(box.x + box.width * (0.28 + i * 0.035), box.y + box.height * (y + i * 0.012));
      await page.mouse.up();
      await page.waitForTimeout(80);
    }
    await page.waitForTimeout(250);
  };
  await page.evaluate(() => { const a = window.__V2_APP__; a.engine.setActiveLayer(a.engine.getLayers()[0].id); a.setTool('brush'); });
  await draw(2);
  out.cases.dirtyDraw = await page.evaluate(() => ({ get: window.__V2_APP__.t90.get() }));
  // dirty vs full 绘制像素
  out.cases.drawDiff = await page.evaluate(async () => {
    const app = window.__V2_APP__; const t = app.t90;
    const decode = async (url) => { const img = new Image(); img.src = url; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; c.getContext('2d').drawImage(img, 0, 0); return c.getContext('2d').getImageData(0, 0, c.width, c.height).data; };
    const diff = (a, b) => { let n = 0; for (let i = 0; i < a.length; i += 4) if (a[i] !== b[i] || a[i + 1] !== b[i + 1] || a[i + 2] !== b[i + 2] || a[i + 3] !== b[i + 3]) n += 1; return n; };
    const dirty = await app.engine.getCompositeDataUrl();
    t.setStrategy('full');
    await new Promise((r) => requestAnimationFrame(r));
    const full = await app.engine.getCompositeDataUrl();
    const d1 = diff(await decode(dirty), await decode(full));
    t.applyPresentStrategy();
    await new Promise((r) => requestAnimationFrame(r));
    const dirty2 = await app.engine.getCompositeDataUrl();
    const d2 = diff(await decode(dirty2), await decode(full));
    return { dirtyVsFull: d1, restoredDirtyVsFull: d2, strategy: app.engine.getPresentStrategy() };
  });
  // undo
  out.cases.undoDiff = await page.evaluate(async () => {
    const app = window.__V2_APP__; const e = app.engine; const t = app.t90;
    const decode = async (url) => { const img = new Image(); img.src = url; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; c.getContext('2d').drawImage(img, 0, 0); return c.getContext('2d').getImageData(0, 0, c.width, c.height).data; };
    const diff = (a, b) => { let n = 0; for (let i = 0; i < a.length; i += 4) if (a[i] !== b[i] || a[i + 1] !== b[i + 1] || a[i + 2] !== b[i + 2] || a[i + 3] !== b[i + 3]) n += 1; return n; };
    t.applyPresentStrategy();
    e.undo(); e.presentFull(); await new Promise((r) => requestAnimationFrame(r));
    const dirtyUndo = await e.getCompositeDataUrl();
    t.setStrategy('full');
    const fullUndo = await e.getCompositeDataUrl();
    return { diff: diff(await decode(dirtyUndo), await decode(fullUndo)), undoDepth: e.getStats().undoDepth, strategy: e.getPresentStrategy() };
  });
  // 导出像素 diff（dirty vs full）
  out.cases.exportDiff = await page.evaluate(async () => {
    const app = window.__V2_APP__; const e = app.engine; const t = app.t90;
    const decode = async (blob) => { const img = await createImageBitmap(blob); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; c.getContext('2d').drawImage(img, 0, 0); img.close(); return c.getContext('2d').getImageData(0, 0, c.width, c.height).data; };
    const diff = (a, b) => { let n = 0; for (let i = 0; i < a.length; i += 4) if (a[i] !== b[i] || a[i + 1] !== b[i + 1] || a[i + 2] !== b[i + 2] || a[i + 3] !== b[i + 3]) n += 1; return n; };
    for (let i = 0; i < 60 && e._exportJob; i += 1) await new Promise((r) => setTimeout(r, 100));
    t.applyPresentStrategy();
    const dirty = await e.exportPNGAsync({});
    t.setStrategy('full');
    const full = await e.exportPNGAsync({});
    const d = diff(await decode(dirty), await decode(full));
    t.applyPresentStrategy();
    return { bytes: [dirty.size, full.size], diff: d };
  });
  // 帧稳定：多笔后画面与 full 一致；撤销恢复
  await draw(6);
  out.cases.stability = await page.evaluate(async () => {
    const app = window.__V2_APP__; const e = app.engine; const t = app.t90;
    const decode = async (url) => { const img = new Image(); img.src = url; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; c.getContext('2d').drawImage(img, 0, 0); return c.getContext('2d').getImageData(0, 0, c.width, c.height).data; };
    const diff = (a, b) => { let n = 0; for (let i = 0; i < a.length; i += 4) if (a[i] !== b[i] || a[i + 1] !== b[i + 1] || a[i + 2] !== b[i + 2] || a[i + 3] !== b[i + 3]) n += 1; return n; };
    const stats = t.get().stats;
    const dirty = await e.getCompositeDataUrl();
    t.setStrategy('full');
    const full = await e.getCompositeDataUrl();
    return { diff: diff(await decode(dirty), await decode(full)), lastMode: stats.lastMode, lastRedrawPct: stats.lastRedrawPct, strategy: e.getPresentStrategy() };
  });
  // 关于面板显示
  await page.evaluate(() => window.__V2_APP__.t90.applyPresentStrategy());
  await page.click('#btnMore');
  await page.waitForTimeout(200);
  await page.click('#btnAbout');
  await page.waitForTimeout(300);
  out.cases.about = await page.evaluate(() => ({ present: document.getElementById('aboutPresent').textContent, open: document.getElementById('aboutModal').classList.contains('show') }));
  // 三档截图（About 显示当前策略）
  const shots = {};
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await load(w, h);
    await page.click('#btnMore');
    await page.waitForTimeout(200);
    await page.click('#btnAbout');
    await page.waitForTimeout(400);
    await page.screenshot({ path: ROOT + '\\v2\\app\\ui-present-' + w + '.png' });
    shots[w] = await page.evaluate(() => ({ overX: document.documentElement.scrollWidth > innerWidth + 1, overY: document.documentElement.scrollHeight > innerHeight + 1, present: document.getElementById('aboutPresent').textContent, aboutOpen: document.getElementById('aboutModal').classList.contains('show'), strategy: window.__V2_APP__.engine.getPresentStrategy() }));
    await page.evaluate(() => { const x = document.querySelector('#aboutModal .close-x'); if (x) x.click(); });
  }
  out.cases.screenshots = shots;
  out.errors = errors.slice(0, 10);
  out.pass = {
    defaultDirty: out.cases.init.get.strategy === 'dirty' && out.cases.init.get.retained === true,
    policy: out.cases.init.decide.small.strategy === 'dirty' && out.cases.init.decide.edge.strategy === 'dirty' && out.cases.init.decide.edge.retained === true && out.cases.init.decide.large.strategy === 'full' && out.cases.init.decide.large.retained === false && out.cases.init.decide.over.strategy === 'full',
    about: String(out.cases.init.about || '').includes('dirty') && out.cases.about.open && out.cases.about.present.includes('dirty'),
    drawPixels: out.cases.drawDiff.dirtyVsFull === 0 && out.cases.drawDiff.restoredDirtyVsFull === 0,
    undo: out.cases.undoDiff.diff === 0 && out.cases.undoDiff.undoDepth >= 1,
    export: out.cases.exportDiff.diff === 0 && out.cases.exportDiff.bytes[0] > 1000 && out.cases.exportDiff.bytes[1] > 1000,
    stability: out.cases.stability.diff === 0 && (out.cases.stability.lastMode === 'dirty' || out.cases.stability.lastMode === 'burst' || out.cases.stability.lastRedrawPct < 1),
    screenshots: Object.values(shots).every((v) => !v.overX && !v.overY && v.aboutOpen && v.strategy === 'dirty'),
    noConsoleErrors: out.errors.length === 0,
  };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} finally {
  clearTimeout(hard);
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  finish(0);
}
