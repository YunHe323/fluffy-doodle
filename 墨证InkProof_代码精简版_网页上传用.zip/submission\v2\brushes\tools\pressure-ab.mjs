/**
 * v2/brushes/tools/pressure-ab.mjs · T69 模拟压感默认参数 A/B（headless，真实 GPU，不弹窗）
 * 对比：T54 默认 vs T59 opt-in（慢S/快S/轻压/重压）：
 *   真线宽 CV（Python 后处理）、压力轨迹、笔触耗时 / 长帧数（>32ms）；保存画布 PNG 供 sheet。
 * 产物：samples/pressure-ab/{default,opt}-{scenario}.png + samples/pressure-ab/raw.json
 * 运行（项目根目录，先 node v2/serve.mjs）：node v2/brushes/tools/pressure-ab.mjs
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
const OUT = path.join(ROOT, 'v2', 'brushes', 'samples', 'pressure-ab');
fs.mkdirSync(OUT, { recursive: true });
const CDP_PORT = Number((process.argv.find((a) => a.startsWith('--cdp=')) || '').split('=')[1] || 9599);
const HEADLESS = !process.argv.includes('--headed');
function resolveBase() {
  if (process.env.INKPROOF_BASE) return process.env.INKPROOF_BASE;
  try {
    const port = fs.readFileSync(path.join(ROOT, 'v2', '.runtime-port'), 'utf8').trim();
    if (/^\d+$/.test(port)) return 'http://127.0.0.1:' + port;
  } catch (e) { /* ignore */ }
  return 'http://127.0.0.1:4200';
}
const URL_ARG = `${resolveBase()}/v2/brushes/tools/pressure-ab.html`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const EDGE = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
].find((p) => fs.existsSync(p));
let ws = null; let msgId = 0; const pending = new Map();
const send = (method, params = {}) => new Promise((resolve) => { const id = ++msgId; pending.set(id, resolve); ws.send(JSON.stringify({ id, method, params })); });
async function ev(expression, timeoutMs = 240000) {
  const r = await Promise.race([send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true }), sleep(timeoutMs).then(() => ({ __t: true }))]);
  if (r.__t) throw new Error('evaluate timeout');
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1500));
  return r.result?.result?.value;
}
const report = { schema: 'inkproof.pressure-ab.v1', headless: HEADLESS, ok: false, variants: {} };
const profile = path.join(os.tmpdir(), 'pab-' + Date.now());
const args = ['--remote-debugging-port=' + CDP_PORT, '--user-data-dir=' + profile, '--no-first-run', '--no-default-browser-check'];
if (HEADLESS) args.push('--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1400,1000');
else args.push('--window-size=1400,1000', '--window-position=-3000,-3000', '--start-minimized');
args.push(URL_ARG);
const browser = spawn(EDGE, args, { stdio: 'ignore' });
try {
  let target = null;
  for (let i = 0; i < 400 && !target; i += 1) {
    try { const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json(); target = list.find((t) => t.type === 'page' && /^https?:/.test(t.url)); } catch (e) { /* wait */ }
    if (!target) await sleep(150);
  }
  if (!target) throw new Error('no target');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { const r = pending.get(m.id); pending.delete(m.id); r(m); } };
  await send('Runtime.enable');
  const t0 = Date.now(); let ready = false;
  while (Date.now() - t0 < 90000) {
    const err = await ev('window.__PA_ERROR__ || null').catch(() => null);
    if (err) throw new Error('page error: ' + err);
    ready = await ev('!!window.__PA_READY__').catch(() => false);
    if (ready) break;
    await sleep(300);
  }
  if (!ready) throw new Error('pressure-ab not ready');
  for (const variantId of ['default', 'opt']) {
    const data = await ev(`window.__runPressureAB__(${JSON.stringify(variantId)})`);
    const entry = { label: data.label, cfg: data.cfg, scenarios: {} };
    for (const [scenId, sc] of Object.entries(data.scenarios)) {
      const file = path.join(OUT, `${variantId}-${scenId}.png`);
      if (sc.image) fs.writeFileSync(file, Buffer.from(sc.image.split(',')[1], 'base64'));
      entry.scenarios[scenId] = { label: sc.label, runs: sc.runs, image: path.relative(ROOT, file).replace(/\\/g, '/') };
      const med = (arr) => { const v = arr.slice().sort((a, b) => a - b); return v[Math.floor(v.length / 2)]; };
      console.log(variantId, scenId, 'ms', med(sc.runs.map((r) => r.ms)), 'longFrames', med(sc.runs.map((r) => r.longFrames)), 'pressure', JSON.stringify(sc.runs[0].pressure));
    }
    report.variants[variantId] = entry;
  }
  report.ok = !!(report.variants.default && report.variants.opt);
  fs.writeFileSync(path.join(OUT, 'raw.json'), JSON.stringify(report, null, 2));
} catch (e) {
  report.fatal = String(e && e.stack || e);
  console.log(JSON.stringify({ ok: false, fatal: report.fatal }, null, 2));
  try { fs.writeFileSync(path.join(OUT, 'raw.json'), JSON.stringify(report, null, 2)); } catch (err) { /* ignore */ }
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  try { browser.kill(); } catch (e) { /* ignore */ }
  await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  process.exit(report.ok ? 0 : 1);
}
