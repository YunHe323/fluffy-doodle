// product/test/archive-schema.test.mjs
import test from 'node:test';
import assert from 'node:assert/strict';

import {
  SCHEMA_VERSION, LAYERS, MVP_LAYERS, MODES, SOURCES, AI_ROLES,
  validateArchiveRecord, validateMany, assertArchiveRecord,
} from '../core/archive-schema.mjs';
import {
  validL0, validL1, validL2, validL4, validL5, validL6Generation, validL6ModeChange,
} from './fixtures.mjs';

test('常量与 v0.2 对齐', () => {
  assert.equal(SCHEMA_VERSION, '0.2.0');
  assert.deepEqual([...LAYERS], ['L0', 'L1', 'L2', 'L3', 'L4', 'L5', 'L6']);
  assert.ok(MVP_LAYERS.includes('L4') && !MVP_LAYERS.includes('L3'));
  assert.deepEqual([...MODES], ['collab', 'attest']);
  assert.deepEqual([...SOURCES], ['observed', 'inferred', 'user-confirmed']);
  assert.deepEqual([...AI_ROLES], ['tool', 'assistant', 'collaborator']);
});

test('合法记录全部通过（L0/L1/L2/L4/L5/L6）', () => {
  const records = [validL0(), validL1(), validL2(), validL4(), validL5(), validL6Generation(), validL6ModeChange()];
  for (const record of records) {
    const result = validateArchiveRecord(record);
    assert.equal(result.ok, true, `${record.id} 不应有错：${JSON.stringify(result.errors)}`);
    assert.deepEqual(result.errors, []);
  }
});

test('validateMany 汇总与 assertArchiveRecord 抛错', () => {
  const many = validateMany([validL1(), { id: 'L1-bad' }]);
  assert.equal(many.ok, false);
  assert.equal(many.total, 2);
  assert.equal(many.invalidCount, 1);
  assert.equal(many.errors[0].index, 1);

  let thrown = null;
  try {
    assertArchiveRecord({ id: 'L1-bad' });
  } catch (error) {
    thrown = error;
  }
  assert.ok(thrown, '应当抛出 ArchiveSchemaError');
  assert.match(thrown.message, /档案记录不合法/);
  assert.equal(thrown.name, 'ArchiveSchemaError');
  assert.ok(Array.isArray(thrown.errors) && thrown.errors.length > 0);
});

test('公共字段必填：缺 mode / ai_role 报错', () => {
  const noMode = validL1();
  delete noMode.mode;
  const r1 = validateArchiveRecord(noMode);
  assert.equal(r1.ok, false);
  assert.ok(r1.errors.some((e) => e.path === 'mode' && e.error === 'required'));

  const noRole = validL1();
  delete noRole.ai_role;
  const r2 = validateArchiveRecord(noRole);
  assert.ok(r2.errors.some((e) => e.path === 'ai_role' && e.error === 'required'));
});

test('枚举与格式：source/author/mode/ai_role/时间/sha256', () => {
  const bad = validL1({ source: 'guessed', author: 'robot', mode: 'solo', ai_role: 'boss' });
  const result = validateArchiveRecord(bad);
  const paths = result.errors.map((e) => e.path);
  assert.ok(paths.includes('source'));
  assert.ok(paths.includes('author'));
  assert.ok(paths.includes('mode'));
  assert.ok(paths.includes('ai_role'));

  const badTime = validateArchiveRecord(validL1({ created_at: '2026-11-06 18:00' }));
  assert.equal(badTime.ok, false);

  const badSha = validateArchiveRecord(validL0({ sha256: 'abc' }));
  assert.ok(badSha.errors.some((e) => e.path === 'sha256'));

  const legacyVersion = validateArchiveRecord(validL1({ schema_version: '0.1.0' }));
  assert.equal(legacyVersion.ok, true, '迁移期应兼容 0.1.x');
});

test('锚点规则：bbox 长度、whole 值、region 指向', () => {
  const badBbox = validateArchiveRecord(validL2({ anchor: { type: 'bbox', value: [1, 2, 3] } }));
  assert.ok(badBbox.errors.some((e) => e.path === 'anchor.value' && e.error === 'invalid_bbox'));

  const badWhole = validateArchiveRecord(validL1({ anchor: { type: 'whole', value: [0, 0, 1, 1] } }));
  assert.ok(badWhole.errors.some((e) => e.path === 'anchor.value'));

  const badRegion = validateArchiveRecord(validL4({ anchor: { type: 'region', value: 'a7' } }));
  assert.ok(badRegion.errors.some((e) => e.path === 'anchor.value'));
});

test('L0：默认不训练 + AI 处理授权字段', () => {
  const trainOn = validateArchiveRecord(validL0({ consent: { allow_training: true, allow_ai_processing: true, allow_display: false } }));
  assert.equal(trainOn.ok, false);

  const missingAiProcessing = validateArchiveRecord(validL0({ consent: { allow_training: false, allow_display: false } }));
  assert.ok(missingAiProcessing.errors.some((e) => e.path === 'consent.allow_ai_processing'));

  const wrongAuthor = validateArchiveRecord(validL0({ author: 'ai' }));
  assert.equal(wrongAuthor.ok, false);
});

test('L4：AI 观察必须带证据', () => {
  const record = validL4({ author: 'ai', evidence_refs: [] });
  const result = validateArchiveRecord(record);
  assert.equal(result.ok, false);
  assert.ok(result.errors.some((e) => e.path === 'evidence_refs' && e.error === 'required'));

  const userNote = validateArchiveRecord(validL4({ author: 'user', source: 'user-confirmed', evidence_refs: [] }));
  assert.equal(userNote.ok, true);
});

test('L5：created_by 只能是用户或用户接受 AI 建议', () => {
  const bad = validateArchiveRecord(validL5({ created_by: 'ai' }));
  assert.equal(bad.ok, false);
  const ok = validateArchiveRecord(validL5({ created_by: 'ai-suggested-user-accepted' }));
  assert.equal(ok.ok, true);
});

test('L6：generation 必带 credits/cost/output；mode_change 必带 from/to/actor', () => {
  const noCredits = validL6Generation();
  delete noCredits.credits;
  const r1 = validateArchiveRecord(noCredits);
  assert.ok(r1.errors.some((e) => e.path === 'credits' && e.error === 'required'));

  const noOutput = validL6Generation({ output_asset_id: '' });
  assert.equal(validateArchiveRecord(noOutput).ok, false);

  const noActor = validL6ModeChange();
  delete noActor.actor;
  const r2 = validateArchiveRecord(noActor);
  assert.ok(r2.errors.some((e) => e.path === 'actor' && e.error === 'required'));

  const badFrom = validateArchiveRecord(validL6ModeChange({ from_mode: 'solo' }));
  assert.equal(badFrom.ok, false);

  const noRole = validL6Generation({ ai_role: null });
  assert.ok(validateArchiveRecord(noRole).errors.some((e) => e.path === 'ai_role'));
});

test('非法层与被删除字段报错', () => {
  const badLayer = validateArchiveRecord({ ...validL1(), layer: 'L9' });
  assert.equal(badLayer.ok, false);

  const notObject = validateArchiveRecord(null);
  assert.equal(notObject.ok, false);
  assert.equal(notObject.errors[0].error, 'invalid_type');
});
