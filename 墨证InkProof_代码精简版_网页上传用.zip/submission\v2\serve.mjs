// v2/serve.mjs — 零依赖本地服务：静态文件 + AI 代理（T95）
// 用法：node v2/serve.mjs
// 端口：默认 4200；占用自动 +1（最多 +10），实际端口写 v2/.runtime-port
// AI 配置：v2/.ai-config.json（0600；不提交）或环境变量；仅监听 127.0.0.1。
import http from 'node:http';
import crypto from 'node:crypto';
import { promises as fs, statSync as fsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';
import { spawnSync } from 'node:child_process';
import os from 'node:os';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const BASE_PORT = Number(process.env.PORT) || 4200;
const MAX_TRIES = 10;
const HOST = '127.0.0.1';
const PORT_FILE = path.join(__dirname, '.runtime-port');
const AI_CONFIG_PATH = process.env.AI_CONFIG_PATH || path.join(__dirname, '.ai-config.json');
const AI_TOKEN_PATH = process.env.AI_TOKEN_PATH || path.join(__dirname, '.ai-token');
const MAX_BODY = 8 * 1024 * 1024;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml', '.wasm': 'application/wasm', '.ico': 'image/x-icon',
};

function safeJoin(root, urlPath) {
  const decoded = decodeURIComponent(urlPath.split('?')[0]);
  const p = path.normalize(path.join(root, decoded));
  if (!p.startsWith(root + path.sep) && p !== root) return null;
  return p;
}

// ---------- P0-1：静态资源访问白名单 ----------
// 背景：旧版把 ROOT 设为整个项目根，静态分支不过滤点文件/敏感扩展名，
// 导致 GET /v2/.ai-config.json 可直接读到明文 apiKey（绕过 redactedConfig 的脱敏）。
// 规则：只允许 v2/ 与 hackathon/ 两个公开根；拒绝任何点文件段、凭据文件与归档/密钥类扩展名。
const STATIC_ROOTS = ['v2', 'hackathon'];
const STATIC_BLOCKED_NAMES = new Set([
  '.ai-config.json', '.ai-token', '.env', '.npmrc', '.netrc',
  'id_rsa', 'id_ed25519', 'credentials', 'secrets.json',
]);
const STATIC_BLOCKED_EXT = /\.(?:pem|p12|pfx|key|keystore|zip|7z|rar|tar|gz|tgz|bak|db|sqlite|sqlite3|log|env)$/i;
function blockedStaticPath(urlPath) {
  let decoded;
  try { decoded = decodeURIComponent(String(urlPath).split('?')[0]); } catch (e) { return true; }
  const segs = decoded.split(/[\\/]/).filter(Boolean);
  if (segs.some((s) => s.startsWith('.') || s === '..')) return true;
  if (segs.length === 0) return false;
  if (!STATIC_ROOTS.includes(segs[0].toLowerCase())) return true;
  const base = segs[segs.length - 1].toLowerCase();
  if (STATIC_BLOCKED_NAMES.has(base)) return true;
  if (STATIC_BLOCKED_EXT.test(base)) return true;
  return false;
}

// ---------- P1：上游 / 参考图 URL 安全（SSRF + 密钥外带） ----------
// 返回 null 表示可安全访问公网；否则返回风险标识。
function urlRisk(raw) {
  let u;
  try { u = new URL(String(raw)); } catch (e) { return 'invalid_url'; }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return 'bad_protocol';
  const h = u.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal')) return 'private_host';
  if (h === '::1' || h === '0:0:0:0:0:0:0:1' || h === '0.0.0.0') return 'private_host';
  if (/^127\./.test(h) || /^10\./.test(h) || /^192\.168\./.test(h) || /^169\.254\./.test(h) || /^0\./.test(h)) return 'private_host';
  const m172 = /^172\.(\d+)\./.exec(h);
  if (m172 && Number(m172[1]) >= 16 && Number(m172[1]) <= 31) return 'private_host';
  const m100 = /^100\.(\d+)\./.exec(h);
  if (m100 && Number(m100[1]) >= 64 && Number(m100[1]) <= 127) return 'private_host';
  if (!h.includes('.') && !h.includes(':')) return 'single_label_host';
  return null;
}
function assertConfigUrls(obj, prefix = '') {
  // 测试专用逃生口：T96 假上游在回环地址；仅当显式设置该环境变量时放行回环/内网配置。
  // 默认（未设置）行为不变：一律拒绝。凭据剥离（upstreamCredentialRisk）不受此开关影响。
  if (process.env.AI_TEST_ALLOW_LOOPBACK_UPSTREAM === '1') return;
  if (!obj || typeof obj !== 'object') return;
  for (const [k, v] of Object.entries(obj)) {
    if (typeof v === 'string' && v && /url$/i.test(k)) {
      const risk = urlRisk(v);
      if (risk) throw Object.assign(new Error('不允许把上游地址配置为内网/回环/非 HTTP(S) 地址（' + prefix + k + '）'), { status: 400, code: 'unsafe_upstream' });
    } else if (v && typeof v === 'object' && !Array.isArray(v)) {
      assertConfigUrls(v, prefix + k + '.');
    }
  }
}

// ---------- 本地 token（防 CSRF；优先环境变量） ----------
async function loadLocalToken() {
  if (process.env.AI_LOCAL_TOKEN) return String(process.env.AI_LOCAL_TOKEN);
  try { return (await fs.readFile(AI_TOKEN_PATH, 'utf8')).trim(); } catch (e) { /* generate */ }
  const token = crypto.randomBytes(24).toString('hex');
  try { await fs.writeFile(AI_TOKEN_PATH, token, { mode: 0o600 }); } catch (e) { /* ignore */ }
  return token;
}
const LOCAL_TOKEN = await loadLocalToken();

// ---------- 配置 ----------
function envOverrides(cfg = {}) {
  const out = { ...cfg, providers: { ...(cfg.providers || {}) } };
  if (process.env.MOONSHOT_API_KEY) out.providers.moonshot = { ...(out.providers.moonshot || {}), apiKey: process.env.MOONSHOT_API_KEY };
  if (process.env.HUNYUAN_SECRET_ID) out.providers.hunyuan = { ...(out.providers.hunyuan || {}), secretId: process.env.HUNYUAN_SECRET_ID };
  if (process.env.HUNYUAN_SECRET_KEY) out.providers.hunyuan = { ...(out.providers.hunyuan || {}), secretKey: process.env.HUNYUAN_SECRET_KEY };
  if (process.env.OPENAI_API_KEY) out.providers['openai-compatible'] = { ...(out.providers['openai-compatible'] || {}), apiKey: process.env.OPENAI_API_KEY };
  if (process.env.AI_PROVIDER) out.provider = process.env.AI_PROVIDER;
  if (process.env.AI_MODEL) out.model = process.env.AI_MODEL;
  if (process.env.AI_BASE_URL) out.providers[out.provider || 'openai-compatible'] = { ...(out.providers[out.provider || 'openai-compatible'] || {}), baseUrl: process.env.AI_BASE_URL };
  return out;
}
async function readConfig() {
  let raw = {};
  try { raw = JSON.parse(await fs.readFile(AI_CONFIG_PATH, 'utf8')); } catch (e) { raw = {}; }
  const cfg = envOverrides(raw);
  cfg.providers = cfg.providers || {};
  cfg.mode = cfg.mode === 'mock' ? 'mock' : 'real';
  cfg.provider = cfg.provider || 'openai-compatible';
  cfg.model = cfg.model || null;
  cfg.timeoutMs = Number(cfg.timeoutMs) || 60000;
  cfg.privacyMode = !!cfg.privacyMode;
  cfg.limits = { perMinute: 10, ...(cfg.limits || {}) };
  return cfg;
}
function providerCfg(cfg, id) { return (cfg.providers && cfg.providers[id]) || {}; }
// 若上游指向内网/回环或非 HTTPS，一律剥离凭据：本地无密钥模型代理仍可用，但 Bearer key 绝不发过去。
function upstreamCredentialRisk(urls) {
  for (const raw of urls) {
    if (!raw) continue;
    const risk = urlRisk(raw);
    if (risk) return risk;
    try { if (new URL(raw).protocol !== 'https:') return 'insecure_transport'; } catch (e) { return 'invalid_url'; }
  }
  return null;
}
function resolveTarget(cfg) {
  const provider = String(cfg.provider || '').toLowerCase();
  const p = providerCfg(cfg, provider);
  const baseUrl = String(p.baseUrl || cfg.baseUrl || '').replace(/\/+$/, '');
  const model = p.model || cfg.model || null;
  const imageModel = p.imageModel || cfg.imageModel || (provider === 'qwen' ? 'qwen-image-3.0' : (provider === 'hunyuan' ? 'hy-image-v3.0' : null));
  const imageEditModel = p.imageEditModel || cfg.imageEditModel || (provider === 'qwen' ? 'qwen-image-3.0-pro' : null);
  const imageProtocol = p.imageProtocol || cfg.imageProtocol || (provider === 'qwen' ? 'dashscope-async' : null);
  // T119：'async' 表示编辑直接走异步 image-generation（部分聚合网关无同步 multimodal 端点）
  const imageEditProtocol = p.imageEditProtocol || cfg.imageEditProtocol || null;
  const imageBaseUrl = String(p.imageBaseUrl || cfg.imageBaseUrl || (provider === 'qwen' ? 'https://dashscope.aliyuncs.com' : baseUrl)).replace(/\/+$/, '');
  const unsafeUpstream = upstreamCredentialRisk([baseUrl, imageBaseUrl, p.chatUrl, p.imageUrl]);
  // 凭据只在「所有上游均为公网 HTTPS」时保留；否则剥离，避免密钥被发到任意地址。
  const apiKey = unsafeUpstream ? '' : (p.apiKey || '');
  const secretId = unsafeUpstream ? '' : (p.secretId || '');
  const secretKey = unsafeUpstream ? '' : (p.secretKey || '');
  return { provider, apiKey, secretId, secretKey, baseUrl, model, imageModel, imageEditModel, imageProtocol, imageEditProtocol, imageBaseUrl, cfg: p, unsafeUpstream };
}
function hasKey(target) {
  if (!target) return false;
  if (target.provider === 'hunyuan') return !!(target.secretId && target.secretKey) || !!target.apiKey;
  return !!target.apiKey;
}
function redactedConfig(cfg) {
  const target = resolveTarget(cfg);
  const providers = {};
  for (const id of ['moonshot', 'hunyuan', 'qwen', 'openai-compatible']) {
    const p = providerCfg(cfg, id);
    providers[id] = {
      baseUrl: p.baseUrl || null, model: p.model || null,
      hasKey: !!(p.apiKey || (p.secretId && p.secretKey)),
      keyLast4: p.apiKey ? String(p.apiKey).slice(-4) : null,
    };
  }
  return {
    ok: true, mode: cfg.mode, provider: cfg.provider, model: cfg.model || target.model || null,
    hasKey: hasKey(target), providers, privacyMode: !!cfg.privacyMode,
    // T120：配置里是否存了 key（与剥离无关）。上游为内网/回环时凭据被剥离（hasKey=false），
    // 但「本地代理/测试假上游」本就是无凭据调用，前端据此判定真实调用资格，避免黑洞。
    hasStoredKey: !!(target.cfg && (target.cfg.apiKey || (target.cfg.secretId && target.cfg.secretKey))),
    // 上游不安全时凭据已被剥离，此处明确告知，避免「有 key 却调不通」的黑洞。
    unsafeUpstream: target.unsafeUpstream || null,
    credentialPolicy: '仅当所有上游均为公网 HTTPS 时才附带密钥；内网/本地代理不发送任何凭据。',
    supports: { vision: true, stream: true, imageGen: cfg.provider === 'qwen' || cfg.provider === 'hunyuan' || !!providerCfg(cfg, 'openai-compatible').imageUrl },
    limits: cfg.limits,
    filePermissions: LAST_CONFIG_PERM,
    disclosure: '真实调用会把选区截图/上下文发送给所选模型 provider；可在配置 privacyMode=true 或设置中关闭。',
  };
}
let LAST_CONFIG_PERM = { platform: process.platform, mode: null, acl: 'pending' };
function tightenConfigPermissions(file) {
  const info = { platform: process.platform, mode: null, acl: 'skipped' };
  try { info.mode = '0o' + (requireMode(file) & 0o777).toString(8); } catch (e) { /* ignore */ }
  if (process.platform === 'win32') {
    try {
      const user = process.env.USERNAME || process.env.USER || '';
      const r = spawnSync('icacls', [file, '/inheritance:r', '/grant:r', (user || 'CURRENT_USER') + ':F'], { windowsHide: true, encoding: 'utf8' });
      info.acl = r && r.status === 0 ? 'ok' : 'failed';
      if (r && r.status !== 0) info.aclError = String((r.stderr || r.stdout || '')).slice(0, 200);
    } catch (e) { info.acl = 'failed'; info.aclError = String(e && e.message || e).slice(0, 200); }
  } else {
    info.acl = 'posix-0600';
  }
  return info;
}
function requireMode(file) { try { return fsSync.statSync(file).mode; } catch (e) { return 0; } }

async function writeConfig(patch) {
  // P1：禁止把上游地址改到内网/回环（否则后续 POST 会把 Bearer <key> 发给该地址）
  assertConfigUrls(patch);
  let current = {};
  try { current = JSON.parse(await fs.readFile(AI_CONFIG_PATH, 'utf8')); } catch (e) { current = {}; }
  const next = { ...current };
  for (const k of ['mode', 'provider', 'model', 'timeoutMs', 'privacyMode', 'limits', 'baseUrl', 'imageProtocol', 'imageEditProtocol', 'imageBaseUrl', 'dashscopePollMs', 'dashscopeMaxPolls', 'visionFastModel']) {
    if (patch[k] !== undefined) next[k] = patch[k];
  }
  if (patch.providers && typeof patch.providers === 'object') {
    next.providers = { ...(current.providers || {}) };
    for (const [id, p] of Object.entries(patch.providers)) {
      if (!p || typeof p !== 'object') continue;
      const keep = { ...(next.providers[id] || {}) };
      for (const f of ['apiKey', 'baseUrl', 'model', 'secretId', 'secretKey', 'region', 'imageModel', 'imageEditModel', 'imageBaseUrl', 'imageUrl', 'chatUrl', 'imageProtocol']) {
        if (p[f] !== undefined) { if (p[f] === '') delete keep[f]; else keep[f] = p[f]; }
      }
      next.providers[id] = keep;
    }
  }
  await fs.mkdir(path.dirname(AI_CONFIG_PATH), { recursive: true });
  const tmp = AI_CONFIG_PATH + '.tmp-' + process.pid;
  await fs.writeFile(tmp, JSON.stringify(next, null, 2), 'utf8');
  try { await fs.chmod(tmp, 0o600); } catch (e) { /* Windows 可能不支持 */ }
  await fs.rename(tmp, AI_CONFIG_PATH);
  try { await fs.chmod(AI_CONFIG_PATH, 0o600); } catch (e) { /* Windows 可能不支持 POSIX 权限 */ }
  LAST_CONFIG_PERM = tightenConfigPermissions(AI_CONFIG_PATH);
  return next;
}

// ---------- HTTP 工具 ----------
function readJson(req, limit = MAX_BODY) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    let tooLarge = false;
    req.on('data', (c) => {
      if (tooLarge) return;
      size += c.length;
      if (size > limit) {
        tooLarge = true;
        req.pause();
        reject(Object.assign(new Error('body too large'), { status: 413, code: 'body_too_large' }));
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(Object.assign(new Error('invalid json'), { status: 400 })); } });
    req.on('error', reject);
  });
}
function sendJson(res, status, obj) {
  if (res.headersSent) { try { res.end(); } catch (e) { /* ignore */ } return; }
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function aiError(res, status, code, message, requestId) {
  sendJson(res, status, { ok: false, error: { code, message, userMessage: message, status, requestId: requestId || null } });
}
function tokenOk(req) {
  const header = req.headers['x-ai-token'];
  const cookie = String(req.headers.cookie || '').split(';').map((s) => s.trim()).find((s) => s.startsWith('mozheng_ai_token='));
  const token = header || (cookie ? decodeURIComponent(cookie.split('=')[1]) : '');
  return !!token && token === LOCAL_TOKEN;
}
function confirmed(req) { return String(req.headers['x-ai-confirm'] || '') === 'true'; }
function originOk(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try {
    const u = new URL(origin);
    return u.protocol === 'http:' && (u.hostname === '127.0.0.1' || u.hostname === 'localhost') && (!u.port || u.port === String(server.address() ? server.address().port : ''));
  } catch (e) { return false; }
}
function timeoutSignal(ms) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(Object.assign(new Error('timeout'), { name: 'TimeoutError' })), ms);
  return { signal: ac.signal, clear: () => clearTimeout(timer) };
}
function mapUpstreamError(status, bodyText) {
  if (status === 401 || status === 403) return { status: 401, code: 'auth', message: '模型鉴权失败（本地未配置有效密钥）' };
  if (status === 429) return { status: 429, code: 'rate_limit', message: '模型限流，请稍后重试' };
  if (status >= 500) return { status: 502, code: 'upstream', message: '模型服务暂时不可用' };
  return { status: 400, code: 'upstream_bad_request', message: '模型拒绝请求：' + String(bodyText || '').slice(0, 160) };
}
async function fetchUpstream(target, pathSuffix, payload, timeoutMs) {
  const base = target.baseUrl || target.cfg.baseUrl || '';
  if (!base && !(pathSuffix === '/chat/completions' && target.cfg.chatUrl) && !(pathSuffix === '/images/generations' && target.cfg.imageUrl)) {
    throw Object.assign(new Error('未配置上游 baseUrl'), { status: 500, code: 'no_config' });
  }
  const url = pathSuffix === '/chat/completions' && target.cfg.chatUrl ? target.cfg.chatUrl
    : pathSuffix === '/images/generations' && target.cfg.imageUrl ? target.cfg.imageUrl
      : base + pathSuffix;
  const { signal, clear } = timeoutSignal(timeoutMs || 60000);
  try {
    const headers = { 'content-type': 'application/json' };
    if (target.apiKey) headers.authorization = 'Bearer ' + target.apiKey;
    if (target.provider === 'hunyuan' && target.secretId) {
      headers['x-hunyuan-secret-id'] = target.secretId;
      headers['x-hunyuan-secret-key'] = target.secretKey;
    }
    const res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(payload), signal });
    return { res, clear };
  } catch (e) { clear(); throw e; }
}

// ---------- Mock（无 key/privacy/未确认，与真实同 shape） ----------
let mockModule = null;
async function getMock() { if (!mockModule) mockModule = await import('./app/core/mock-ai.mjs'); return mockModule; }
async function mockChat(body) {
  const { mockAnalyze, mockDirections, mockGenerate } = await getMock();
  const task = body.task || 'analyze';
  let content;
  if (task === 'directions') content = mockDirections({ canvas: { dataUrl: '', width: 1024, height: 768 }, selection: body.selection || {}, context: body.context || {}, count: body.count || 2 });
  else if (task === 'generate') content = mockGenerate({ canvas: { dataUrl: '', width: 1024, height: 768 }, selection: body.selection || {}, directionId: body.directionId || 'mock-dir-1', context: body.context || {}, count: body.count || 2 });
  else content = mockAnalyze({ canvas: { dataUrl: body.image || '', width: body.width || 1024, height: body.height || 768 }, selection: body.selection || {}, context: body.context || {} });
  return { id: 'chatcmpl-mock', object: 'chat.completion', model: 'mock-ai@0.1.0', choices: [{ index: 0, message: { role: 'assistant', content: JSON.stringify(content) }, finish_reason: 'stop' }], usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 } };
}
async function mockImage(body) {
  const { mockGenerate } = await getMock();
  const size = typeof body.size === 'string' ? body.size.split('x').map(Number) : [1024, 1024];
  const w = Number(size[0]) || 1024, h = Number(size[1]) || 1024;
  const res = mockGenerate({ canvas: { dataUrl: '', width: w, height: h }, selection: { rect: { x: 0, y: 0, width: w, height: h } }, directionId: body.directionId || 'mock-dir-1', count: body.count || 1 });
  return { ok: true, mode: 'mock', model: 'mock-ai@0.1.0', candidates: res.candidates, usage: null };
}

// ---------- T91：生图串行队列 / 服务端下载 / 校验 ----------
const IMAGE_QUEUE = { chain: Promise.resolve(), active: 0, maxActive: 0 };
function enqueueImage(fn) {
  const run = IMAGE_QUEUE.chain.then(async () => {
    IMAGE_QUEUE.active += 1;
    IMAGE_QUEUE.maxActive = Math.max(IMAGE_QUEUE.maxActive, IMAGE_QUEUE.active);
    try { return await fn(); } finally { IMAGE_QUEUE.active -= 1; }
  });
  IMAGE_QUEUE.chain = run.catch(() => {});
  return run;
}
function sha256Hex(buf) { return crypto.createHash('sha256').update(buf).digest('hex'); }
function parseImageSize(size) {
  const m = /^(\d{2,5})\s*[x×*]\s*(\d{2,5})$/.exec(String(size || '').trim());
  if (!m) return null;
  const width = Number(m[1]), height = Number(m[2]);
  if (!width || !height) return null;
  return { width, height, area: width * height };
}
// Qwen-Image 官方输出：总像素 512²–2048²（与 provider 无关，统一放行到 2K）
const IMAGE_MIN_AREA = 512 * 512;
const IMAGE_MAX_AREA = 2048 * 2048;
const IMAGE_SIZE_HINT = '输出尺寸需在 512×512 到 2048×2048 之间';
// 参考图上限：Qwen-Image 2.1 系 1–10 张；3.0 系及其它 1–3 张
function imageRefLimit(body, target) {
  const model = [body && body.model, target && target.imageModel].filter(Boolean).join(' ');
  return /2\.1/.test(model) ? 10 : 3;
}
function validateImageRequest(body, target) {
  const size = String(body.size || '1024x1024');
  const parsed = parseImageSize(size);
  if (!parsed) return { ok: false, status: 400, code: 'bad_size', message: 'size 必须为 WxH（整数）' };
  if (parsed.area > IMAGE_MAX_AREA || parsed.area < IMAGE_MIN_AREA) {
    return { ok: false, status: 400, code: parsed.area > IMAGE_MAX_AREA ? 'size_too_large' : 'size_too_small', message: IMAGE_SIZE_HINT };
  }
  const refs = Array.isArray(body.images) ? body.images.slice() : (body.image ? [body.image] : []);
  const refLimit = imageRefLimit(body, target);
  if (refs.length > refLimit) return { ok: false, status: 400, code: 'too_many_refs', message: '参考图最多 ' + refLimit + ' 张（当前模型上限）' };
  const images = [];
  for (const ref of refs) {
    const s = String(ref || '');
    if (!s.startsWith('data:image/') && !/^https?:\/\//i.test(s)) return { ok: false, status: 400, code: 'bad_ref', message: '参考图必须是 dataURL 或 URL' };
    images.push(s);
  }
  return { ok: true, size, parsed, images };
}
async function downloadImage(url, rid, timeoutMs = 30000) {
  if (String(url).startsWith('data:image/')) {
    const b64 = String(url).split(',')[1] || '';
    const buf = Buffer.from(b64, 'base64');
    return { buf, mime: (String(url).split(';')[0] || 'data:image/png').replace('data:', '') };
  }
  if (!/^https?:\/\//i.test(String(url))) throw Object.assign(new Error('非法图片 URL'), { status: 400, code: 'bad_image_url' });
  // P1：禁止参考图 URL 指向回环/内网/云元数据，并禁止重定向绕过（SSRF）。
  const risk = urlRisk(url);
  if (risk) throw Object.assign(new Error('参考图 URL 不允许指向内网/回环地址'), { status: 400, code: 'unsafe_image_url' });
  const { signal, clear } = timeoutSignal(timeoutMs);
  try {
    const res = await fetch(url, { signal, redirect: 'manual' });
    if (res.status >= 300 && res.status < 400) throw Object.assign(new Error('参考图 URL 不允许重定向'), { status: 400, code: 'image_redirect_blocked' });
    if (!res.ok) throw Object.assign(new Error('图片下载失败（URL 可能已过期/失效）'), { status: 502, code: 'image_download', expired: res.status === 403 || res.status === 404 });
    const ab = await res.arrayBuffer();
    if (ab.byteLength > 20 * 1024 * 1024) throw Object.assign(new Error('图片过大（>20MB）'), { status: 502, code: 'image_too_large' });
    const mime = (res.headers.get('content-type') || 'image/png').split(';')[0].trim();
    if (!/^image\//i.test(mime)) throw Object.assign(new Error('参考图响应不是图片'), { status: 502, code: 'image_bad_content_type' });
    return { buf: Buffer.from(ab), mime };
  } catch (e) {
    if (e && e.name === 'TimeoutError') throw Object.assign(new Error('图片下载超时'), { status: 504, code: 'image_download_timeout' });
    throw e;
  } finally { clear(); }
}
async function cacheAndEncodeImage(url, rid) {
  const { buf, mime } = await downloadImage(url, rid);
  const sha256 = sha256Hex(buf);
  const dir = path.join(os.tmpdir(), 'mozheng-ai-images');
  await fs.mkdir(dir, { recursive: true }).catch(() => {});
  const cachedPath = path.join(dir, sha256 + (mime.includes('jpeg') ? '.jpg' : '.png'));
  await fs.writeFile(cachedPath, buf).catch(() => {});
  return { imageDataUrl: 'data:' + mime + ';base64,' + buf.toString('base64'), sha256, bytes: buf.byteLength, cachedPath, mime };
}

// ---------- T91：聊天图片统一转 base64（Kimi 视觉不接受图片 URL） ----------
async function toBase64Image(url) {
  const s = String(url || '');
  if (s.startsWith('data:image/')) return s;
  if (!/^https?:\/\//i.test(s)) return s;
  const { signal, clear } = timeoutSignal(30000);
  try {
    const res = await fetch(s, { signal });
    if (!res.ok) throw new Error('image fetch ' + res.status);
    const ab = await res.arrayBuffer();
    if (ab.byteLength > 20 * 1024 * 1024) throw new Error('image too large');
    const mime = (res.headers.get('content-type') || 'image/png').split(';')[0];
    return 'data:' + mime + ';base64,' + Buffer.from(ab).toString('base64');
  } finally { clear(); }
}
async function normalizeChatImages(payload) {
  const msgs = payload.messages || [];
  for (const m of msgs) {
    if (!Array.isArray(m.content)) continue;
    for (const item of m.content) {
      if (item && item.type === 'image_url' && item.image_url) {
        item.image_url.url = await toBase64Image(item.image_url.url);
      } else if (item && item.type === 'image') {
        if (item.image_url) item.image_url.url = await toBase64Image(item.image_url.url);
        else if (typeof item.url === 'string') { item.type = 'image_url'; item.image_url = { url: await toBase64Image(item.url) }; delete item.url; }
        else if (typeof item.dataUrl === 'string') { item.type = 'image_url'; item.image_url = { url: item.dataUrl }; }
      }
    }
  }
  return payload;
}

// ---------- AI 路由 ----------
async function handleAi(req, res, pathname) {
  if (!pathname.startsWith('/api/ai/')) return false;
  if (!originOk(req)) { aiError(res, 403, 'origin', '非法 Origin'); return true; }
  const cfg = await readConfig();
  const target = resolveTarget(cfg);
  // T120：内网/回环上游凭据按设计被剥离（hasKey=false），但本地代理/测试假上游本就无凭据调用；
  // 配置里存了 key 即视为真实调用资格（凭据仍绝不外发——剥离逻辑在 resolveTarget 内不变）。
  const storedKey = !!(target.cfg && (target.cfg.apiKey || (target.cfg.secretId && target.cfg.secretKey)));
  const realEligible = cfg.mode !== 'mock' && !cfg.privacyMode && (hasKey(target) || (!!target.unsafeUpstream && storedKey));
  const rid = 'r_' + crypto.randomBytes(4).toString('hex');
  const mockReason = !realEligible ? (cfg.privacyMode ? 'privacy' : 'no_key') : 'needs-confirm';

  if (pathname === '/api/ai/health' && req.method === 'GET') {
    sendJson(res, 200, { ok: true, mode: realEligible ? 'real' : 'mock', provider: realEligible ? cfg.provider : 'mock', hasKey: hasKey(target), privacyMode: cfg.privacyMode, model: cfg.model || target.model || 'mock-ai@0.1.0', mock: !realEligible, serverTime: new Date().toISOString() });
    return true;
  }
  if (pathname === '/api/ai/config') {
    if (!tokenOk(req)) { aiError(res, 401, 'token', '本地 token 缺失或无效'); return true; }
    if (req.method === 'GET') { sendJson(res, 200, redactedConfig(cfg)); return true; }
    if (req.method === 'POST') { const body = await readJson(req); await writeConfig(body); sendJson(res, 200, { ok: true, config: redactedConfig(await readConfig()) }); return true; }
    aiError(res, 405, 'method', 'method not allowed'); return true;
  }
  if (pathname === '/api/ai/test') {
    if (!tokenOk(req)) { aiError(res, 401, 'token', '本地 token 缺失或无效'); return true; }
    if (!realEligible) { sendJson(res, 200, { ok: true, mode: 'mock', provider: 'mock', hasKey: false, mock: true, latencyMs: 0 }); return true; }
    try {
      const payload = { model: target.model, messages: [{ role: 'user', content: 'ping' }], max_tokens: 1 };
      const { res: up, clear } = await fetchUpstream(target, '/chat/completions', payload, Math.min(cfg.timeoutMs, 15000));
      const status = up.status;
      if (!up.ok) { const text = await up.text().catch(() => ''); clear(); const m = mapUpstreamError(status, text); aiError(res, m.status, m.code, m.message, rid); return true; }
      await up.json().catch(() => ({})); clear();
      sendJson(res, 200, { ok: true, mode: 'real', provider: cfg.provider, model: target.model, latencyMs: 0, mock: false });
    } catch (e) { sendJson(res, e && e.name === 'TimeoutError' ? 504 : 502, { ok: false, error: { code: e && e.name === 'TimeoutError' ? 'timeout' : 'network', message: '上游不可达', status: 502 } }); }
    return true;
  }
  if (pathname === '/api/ai/chat' && req.method === 'POST') {
    if (!tokenOk(req)) { aiError(res, 401, 'token', '本地 token 缺失或无效'); return true; }
    const body = await readJson(req);
    {
      const msgs = Array.isArray(body.messages) ? body.messages : [];
      let textChars = 0, images = 0;
      for (const m of msgs) {
        if (typeof m.content === 'string') textChars += m.content.length;
        else if (Array.isArray(m.content)) {
          for (const it of m.content) {
            if (!it) continue;
            if (typeof it.text === 'string') textChars += it.text.length;
            if (it.type === 'image_url' || it.image) images += 1;
          }
        }
      }
      if (msgs.length > 30 || textChars > 60000 || images > 4) {
        aiError(res, 413, 'budget', '对话上下文超出本地代理预算（最多30条/6万字符/4张图）；请清空对话或关闭整幅画布上下文');
        return true;
      }
    }
    if (!realEligible || !confirmed(req)) {
      const mock = await mockChat(body);
      sendJson(res, 200, { ok: true, requestId: rid, mode: 'mock', model: mock.model, latencyMs: 1, mock: true, reason: mockReason, choices: mock.choices, usage: mock.usage });
      return true;
    }
    const payload = { ...body, model: body.model || target.model, stream: !!body.stream };
    delete payload.provider; delete payload.baseUrl; delete payload.task; delete payload.width; delete payload.height;
    await normalizeChatImages(payload); // Kimi/Hy4：dataURL/Blob/URL → base64 dataURL
    let upstream, clear;
    const t0 = Date.now();
    try { ({ res: upstream, clear } = await fetchUpstream(target, '/chat/completions', payload, cfg.timeoutMs)); }
    catch (e) { const st = e && e.name === 'TimeoutError' ? 504 : 502; aiError(res, st, st === 504 ? 'timeout' : 'network', st === 504 ? 'AI 请求超时' : '上游不可达'); return true; }
    const status = upstream.status;
    if (!upstream.ok) { const text = await upstream.text().catch(() => ''); clear(); const m = mapUpstreamError(status, text); aiError(res, m.status, m.code, m.message, rid); return true; }
    if (payload.stream) {
      res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
      try { Readable.fromWeb(upstream.body).pipe(res); } catch (e) { /* client closed */ }
      clear(); return true;
    }
    const data = await upstream.json().catch(() => ({})); clear();
    sendJson(res, 200, { ok: true, requestId: rid, mode: 'real', mock: false, model: data.model || target.model, latencyMs: Date.now() - t0, choices: data.choices || [], usage: data.usage || null, rawId: data.id || null });
    return true;
  }
  // T119（2026-11-08）：DashScope 异步任务共享轮询/结果解析，供生图与编辑两条路径复用。
  // 背景：部分 OpenAI 兼容聚合网关只开放异步 image-generation 端点，同步 multimodal-generation
  // 不可用（实测 fetch 失败/429）。编辑路径在同步失败后回落到这里。
  async function dashscopeAsyncPoll(target, taskId, rid, label) {
    const base = target.imageBaseUrl || target.baseUrl;
    const interval = Math.max(20, Number(cfg.dashscopePollMs) || 2000);
    const maxPolls = Math.max(1, Number(cfg.dashscopeMaxPolls) || 90);
    let last = null;
    for (let i = 0; i < maxPolls; i += 1) {
      await new Promise((r) => setTimeout(r, interval));
      try {
        const pollRes = await fetch(base + '/api/v1/tasks/' + encodeURIComponent(taskId), { headers: { authorization: 'Bearer ' + target.apiKey } });
        if (!pollRes.ok) { const text = await pollRes.text().catch(() => ''); const m = mapUpstreamError(pollRes.status, text); return { error: { status: m.status, code: 'dashscope_poll', message: m.message + '（失败不计费）' } }; }
        last = await pollRes.json().catch(() => ({}));
      } catch (e) { return { error: { status: 502, code: 'dashscope_poll_network', message: label + '轮询网络错误（失败不计费）' } }; }
      const st = (last.output && (last.output.task_status || last.output.status)) || last.task_status || last.status;
      if (st === 'SUCCEEDED' || st === 'SUCCESS' || st === 'succeeded') break;
      if (st === 'FAILED' || st === 'CANCELED' || st === 'UNKNOWN') return { error: { status: 502, code: 'dashscope_failed', message: label + '任务失败（失败不计费）', taskId, raw: last } };
    }
    const st = (last && last.output && (last.output.task_status || last.output.status)) || (last && (last.task_status || last.status));
    if (!st || !/SUCCEEDED|SUCCESS/s.test(String(st))) return { error: { status: 504, code: 'dashscope_timeout', message: label + '超时（失败不计费）', taskId } };
    return { last };
  }
  async function dashscopeCollectImages(last, rid, prefix, why) {
    const output = (last && last.output) || {};
    let results = output.results || output.result || (last && last.results) || [];
    // Qwen-Image 异步成功：output.choices[0].message.content[] = [{ image: "https://..." }]
    if ((!Array.isArray(results) || results.length === 0) && Array.isArray(output.choices)) {
      results = [];
      for (const ch of output.choices) {
        const content = ch && ch.message && ch.message.content;
        if (Array.isArray(content)) for (const part of content) if (part && (part.image || part.url)) results.push(part);
        else if (content && typeof content === 'object' && content.image) results.push(content);
      }
    }
    const candidates = [];
    for (let i = 0; i < (Array.isArray(results) ? results : [results]).length; i += 1) {
      const item = Array.isArray(results) ? results[i] : results;
      const url = item && (item.url || item.image_url || item.image);
      if (!url) continue;
      try {
        // T120：data URL 直通（不下载、不过 SSRF 参考图校验——它不是网络地址）。
        // 生产环境 DashScope 返回 https URL，行为不变；测试假上游可回 base64。
        if (typeof url === 'string' && url.startsWith('data:image/')) {
          const b64 = url.slice(url.indexOf(',') + 1);
          const buf = Buffer.from(b64, 'base64');
          candidates.push({ id: prefix + '-' + (i + 1), label: why + ' ' + String.fromCharCode(65 + i), why: why + '（data URL 直通）', imageDataUrl: url, sha256: sha256Hex(buf), bytes: buf.length, source: 'real' });
          continue;
        }
        const cached = await cacheAndEncodeImage(url, rid);
        candidates.push({ id: prefix + '-' + (i + 1), label: why + ' ' + String.fromCharCode(65 + i), why: why + '（服务端已缓存）', imageDataUrl: cached.imageDataUrl, sha256: cached.sha256, bytes: cached.bytes, source: 'real' });
      } catch (e) { /* 单张下载失败 */ }
    }
    return candidates;
  }
  // T100：Qwen-Image DashScope 异步 submit → poll → 服务端下载 URL + sha256
  async function dashscopeImage(target, body, valid, rid) {
    const base = target.imageBaseUrl || target.baseUrl;
    if (!base) return { error: { status: 500, code: 'no_config', message: 'Qwen 生图未配置 imageBaseUrl/baseUrl' } };
    const prompt = body.prompt || '';
    const refs = valid.images || [];
    const size = String(valid.size).replace(/[xX×]/g, '*');
    // 官方参数：seed（可复现）/ negative_prompt（排除元素）/ prompt_extend（默认 true）
    const parameters = {
      size, n: body.count || 1,
      prompt_extend: typeof body.prompt_extend === 'boolean' ? body.prompt_extend : true,
      watermark: false, enable_thinking: false,
    };
    const seedNum = Number(body.seed);
    if (body.seed !== undefined && body.seed !== null && body.seed !== '' && Number.isFinite(seedNum)) parameters.seed = seedNum;
    if (typeof body.negative_prompt === 'string' && body.negative_prompt.trim()) parameters.negative_prompt = body.negative_prompt;
    const submitBody = {
      model: body.model || target.imageModel || 'qwen-image-3.0',
      input: {
        messages: [{
          role: 'user',
          content: [
            { text: prompt },
            ...refs.map((img) => ({ image: img })),
          ],
        }],
      },
      parameters,
    };
    const signalBox = timeoutSignal(Math.min(Number(process.env.AI_IMAGE_SUBMIT_TIMEOUT_MS) || 30000, 30000));
    let submitRes;
    try {
      submitRes = await fetch(base + '/api/v1/services/aigc/image-generation/generation', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + target.apiKey, 'X-DashScope-Async': 'enable' },
        body: JSON.stringify(submitBody), signal: signalBox.signal,
      });
    } catch (e) {
      signalBox.clear();
      return { error: { status: 504, code: e && e.name === 'TimeoutError' ? 'timeout' : 'network', message: e && e.name === 'TimeoutError' ? 'Qwen 提交超时（失败不计费）' : 'Qwen 上游不可达（失败不计费）' } };
    } finally { signalBox.clear(); }
    if (!submitRes.ok) {
      const text = await submitRes.text().catch(() => ''); const m = mapUpstreamError(submitRes.status, text);
      return { error: { status: m.status, code: m.code, message: m.message + '（失败不计费）' } };
    }
    const submitData = await submitRes.json().catch(() => ({}));
    const taskId = (submitData.output && (submitData.output.task_id || submitData.output.taskId)) || submitData.task_id || submitData.id;
    if (!taskId) return { error: { status: 502, code: 'dashscope_no_task', message: 'Qwen 未返回 task_id（失败不计费）' } };
    const interval = Math.max(20, Number(cfg.dashscopePollMs) || 2000);
    const maxPolls = Math.max(1, Number(cfg.dashscopeMaxPolls) || 90);
    let last = null;
    for (let i = 0; i < maxPolls; i += 1) {
      await new Promise((r) => setTimeout(r, interval));
      try {
        const pollRes = await fetch(base + '/api/v1/tasks/' + encodeURIComponent(taskId), { headers: { authorization: 'Bearer ' + target.apiKey } });
        if (!pollRes.ok) { const text = await pollRes.text().catch(() => ''); const m = mapUpstreamError(pollRes.status, text); return { error: { status: m.status, code: 'dashscope_poll', message: m.message + '（失败不计费）' } }; }
        last = await pollRes.json().catch(() => ({}));
      } catch (e) { return { error: { status: 502, code: 'dashscope_poll_network', message: 'Qwen 轮询网络错误（失败不计费）' } }; }
      const st = (last.output && (last.output.task_status || last.output.status)) || last.task_status || last.status;
      if (st === 'SUCCEEDED' || st === 'SUCCESS' || st === 'succeeded') break;
      if (st === 'FAILED' || st === 'CANCELED' || st === 'UNKNOWN') return { error: { status: 502, code: 'dashscope_failed', message: 'Qwen 生图任务失败（失败不计费）', taskId, raw: last } };
    }
    const st = (last && last.output && (last.output.task_status || last.output.status)) || (last && (last.task_status || last.status));
    if (!st || !/SUCCEEDED|SUCCESS/s.test(String(st))) return { error: { status: 504, code: 'dashscope_timeout', message: 'Qwen 生图超时（失败不计费）', taskId } };
    const output = (last && last.output) || {};
    let results = output.results || output.result || (last && last.results) || [];
    // Qwen-Image 异步成功：output.choices[0].message.content[] = [{ image: "https://..." }]
    if ((!Array.isArray(results) || results.length === 0) && Array.isArray(output.choices)) {
      results = [];
      for (const ch of output.choices) {
        const content = ch && ch.message && ch.message.content;
        if (Array.isArray(content)) for (const part of content) if (part && (part.image || part.url)) results.push(part);
        else if (content && typeof content === 'object' && content.image) results.push(content);
      }
    }
    const candidates = [];
    for (let i = 0; i < (Array.isArray(results) ? results : [results]).length; i += 1) {
      const item = Array.isArray(results) ? results[i] : results;
      const url = item && (item.url || item.image_url || item.image);
      if (!url) continue;
      try {
        const cached = await cacheAndEncodeImage(url, rid);
        candidates.push({ id: 'cand-qwen-' + (i + 1), label: '方案 ' + String.fromCharCode(65 + i), why: 'Qwen-Image 生成（服务端已缓存）', imageDataUrl: cached.imageDataUrl, sha256: cached.sha256, bytes: cached.bytes, width: valid.parsed.width, height: valid.parsed.height, source: 'real' });
      } catch (e) { /* 单张下载失败 */ }
    }
    if (!candidates.length) return { error: { status: 502, code: 'image_download', message: 'Qwen 结果图片下载失败（URL 可能过期；失败不计费）', taskId } };
    return { candidates, model: submitData.model || target.imageModel || 'qwen-image-3.0', taskId, usage: (last && last.usage) || submitData.usage || null };
  }

  // T119：异步编辑回落 —— 实测部分 OpenAI 兼容聚合网关上同步 multimodal-generation 不可用，
  // 而异步 image-generation 端点接受输入图（usage.input_image_count=1）可做保结构编辑。
  async function dashscopeImageEditAsync(target, body, valid, rid) {
    const base = target.imageBaseUrl || target.baseUrl;
    if (!base) return { error: { status: 500, code: 'no_config', message: 'Qwen 图像编辑未配置 imageBaseUrl/baseUrl' } };
    const prompt = body.prompt || '';
    const imgList = (valid.images && valid.images.length ? valid.images : (body.image ? [body.image] : [])).filter(Boolean);
    if (!imgList.length) return { error: { status: 400, code: 'no_input_image', message: '图像编辑需要输入图片' } };
    const size = String(valid.size || '1024x1024').replace(/[xX×]/g, '*');
    const model = body.model || target.imageEditModel || 'qwen-image-3.0-pro';
    const submitBody = {
      model,
      input: { messages: [{ role: 'user', content: [...imgList.map((image) => ({ image })), { text: prompt }] }] },
      parameters: { size, n: 1, prompt_extend: false, watermark: false, enable_thinking: false },
    };
    const signalBox = timeoutSignal(Math.min(Number(process.env.AI_IMAGE_SUBMIT_TIMEOUT_MS) || 30000, 30000));
    let submitRes;
    try {
      submitRes = await fetch(base + '/api/v1/services/aigc/image-generation/generation', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + target.apiKey, 'X-DashScope-Async': 'enable' },
        body: JSON.stringify(submitBody), signal: signalBox.signal,
      });
    } catch (e) {
      signalBox.clear();
      return { error: { status: 502, code: 'network', message: 'Qwen 异步编辑上游不可达（失败不计费）' } };
    } finally { signalBox.clear(); }
    if (!submitRes.ok) {
      const text = await submitRes.text().catch(() => ''); const m = mapUpstreamError(submitRes.status, text);
      return { error: { status: m.status, code: m.code, message: m.message + '（失败不计费）' } };
    }
    const submitData = await submitRes.json().catch(() => ({}));
    const taskId = (submitData.output && (submitData.output.task_id || submitData.output.taskId)) || submitData.task_id || submitData.id;
    if (!taskId) return { error: { status: 502, code: 'dashscope_no_task', message: 'Qwen 异步编辑未返回 task_id（失败不计费）' } };
    const polled = await dashscopeAsyncPoll(target, taskId, rid, 'Qwen 异步编辑');
    if (polled.error) return polled;
    const candidates = await dashscopeCollectImages(polled.last, rid, 'cand-qwen-edit-async', 'Qwen-Image-Edit（异步）');
    if (!candidates.length) return { error: { status: 502, code: 'image_download', message: 'Qwen 异步编辑结果图片下载失败（URL 可能过期；失败不计费）', taskId } };
    return { candidates, model, usage: (polled.last && polled.last.usage) || null, requestId: (polled.last && polled.last.request_id) || null, taskId, editPath: 'async-image-generation' };
  }

  // Qwen-Image-Edit：同步 multimodal-generation（image + text → image）；服务端下载+sha256
  async function dashscopeImageEdit(target, body, valid, rid) {
    const base = target.imageBaseUrl || target.baseUrl;
    if (!base) return { error: { status: 500, code: 'no_config', message: 'Qwen 图像编辑未配置 imageBaseUrl/baseUrl' } };
    const prompt = body.prompt || '';
    // 官方图像编辑 3.0 系最多 3 张输入（含选区图）；超过直接 400，不静默截断
    const imgList = (valid.images && valid.images.length ? valid.images : (body.image ? [body.image] : [])).filter(Boolean);
    if (imgList.length > 3) return { error: { status: 400, code: 'too_many_images', message: '图像编辑最多 3 张输入（含选区图）' } };
    if (!imgList.length) return { error: { status: 400, code: 'no_input_image', message: '图像编辑需要输入图片' } };
    const model = body.model || target.imageEditModel || 'qwen-image-3.0-pro';
    const submitBody = {
      model,
      input: { messages: [{ role: 'user', content: [...imgList.map((image) => ({ image })), { text: prompt }] }] },
      parameters: { prompt_extend: true, watermark: false, enable_thinking: false },
    };
    // T119：同步 multimodal 在部分网关不可用，超时收紧到 20s（可配置）以加快异步回落。
    const timeoutMs = Math.min(Number(process.env.AI_IMAGE_EDIT_TIMEOUT_MS) || Number(cfg.imageEditSyncTimeoutMs) || 20000, 300000);
    const signalBox = timeoutSignal(timeoutMs);
    let upstream;
    try {
      upstream = await fetch(base + '/api/v1/services/aigc/multimodal-generation/generation', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + target.apiKey },
        body: JSON.stringify(submitBody), signal: signalBox.signal,
      });
    } catch (e) {
      signalBox.clear();
      return { error: { status: e && e.name === 'TimeoutError' ? 504 : 502, code: e && e.name === 'TimeoutError' ? 'timeout' : 'network', message: e && e.name === 'TimeoutError' ? 'Qwen 图像编辑超时（失败不计费）' : 'Qwen 上游不可达（失败不计费）' } };
    } finally { signalBox.clear(); }
    if (!upstream.ok) {
      const text = await upstream.text().catch(() => ''); const m = mapUpstreamError(upstream.status, text);
      return { error: { status: m.status, code: m.code, message: m.message + '（失败不计费）' } };
    }
    const data = await upstream.json().catch(() => ({}));
    const choices = (data.output && data.output.choices) || data.choices || [];
    const candidates = [];
    let idx = 0;
    for (const ch of choices) {
      const content = ch && ch.message && ch.message.content;
      const parts = Array.isArray(content) ? content : (content ? [content] : []);
      for (const part of parts) {
        const url = part && (part.image || part.url || part.image_url);
        if (!url) continue;
        try {
          const cached = await cacheAndEncodeImage(url, rid);
          candidates.push({ id: 'cand-qwen-edit-' + (idx + 1), label: '编辑 ' + String.fromCharCode(65 + idx), why: 'Qwen-Image-Edit（服务端已缓存·可继续修改）', imageDataUrl: cached.imageDataUrl, sha256: cached.sha256, bytes: cached.bytes, source: 'real' });
          idx += 1;
        } catch (e) { /* 单张下载失败 */ }
      }
    }
    if (!candidates.length) return { error: { status: 502, code: 'image_download', message: 'Qwen 编辑结果图片下载失败（URL 可能过期；失败不计费）' } };
    return { candidates, model, usage: data.usage || null, requestId: data.request_id || null };
  }

  if (pathname === '/api/ai/image' && req.method === 'POST') {
    if (!tokenOk(req)) { aiError(res, 401, 'token', '本地 token 缺失或无效'); return true; }
    const body = await readJson(req);
    const valid = validateImageRequest(body, target);
    if (!valid.ok) { aiError(res, valid.status, valid.code, valid.message, rid); return true; }
    const doImage = async () => {
      if (!realEligible || !confirmed(req)) {
        const mock = await mockImage({ ...body, size: valid.size });
        const withSha = (mock.candidates || []).map((c) => ({
          ...c, sha256: c.imageDataUrl ? sha256Hex(Buffer.from(String(c.imageDataUrl).split(',')[1] || '', 'base64')) : null,
        }));
        sendJson(res, 200, { ...mock, candidates: withSha, requestId: rid, latencyMs: 1, mock: true, billed: false, reason: mockReason });
        return true;
      }
      if (body.task === 'edit' && (target.provider === 'qwen' || target.imageProtocol === 'dashscope-async')) {
        // T119：配置 imageEditProtocol='async' 时跳过同步 multimodal（该网关不可用），直接异步编辑。
        let ed = target.imageEditProtocol === 'async'
          ? await dashscopeImageEditAsync(target, body, valid, rid)
          : await dashscopeImageEdit(target, body, valid, rid);
        // T119：部分 OpenAI 兼容聚合网关不提供同步 multimodal-generation（实测 fetch 失败/429），
        // 此时回落到异步 image-generation（接受输入图，usage.input_image_count 可证）。鉴权失败不回落。
        if (ed.error && target.imageEditProtocol !== 'async' && /network|timeout|upstream|rate_limit/.test(String(ed.error.code || '')) && (valid.images || []).length) {
          const fb = await dashscopeImageEditAsync(target, body, valid, rid);
          if (!fb.error) ed = fb;
          else ed = { error: { ...ed.error, fallbackAttempted: true, fallbackError: fb.error } };
        }
        if (ed.error) { sendJson(res, ed.error.status || 502, { ok: false, billed: false, error: { ...ed.error, status: ed.error.status || 502, billed: false, requestId: rid } }); return true; }
        sendJson(res, 200, { ok: true, requestId: ed.requestId || rid, mode: 'real', model: ed.model, latencyMs: 0, candidates: ed.candidates, usage: ed.usage || null, billed: true, provider: 'qwen', task: 'edit', editPath: ed.editPath || 'sync-multimodal', taskId: ed.taskId || null });
        return true;
      }
      if (target.imageProtocol === 'dashscope-async' || target.provider === 'qwen') {
        const ds = await dashscopeImage(target, body, valid, rid);
        if (ds.error) { sendJson(res, ds.error.status || 502, { ok: false, billed: false, error: { ...ds.error, status: ds.error.status || 502, billed: false, requestId: rid } }); return true; }
        sendJson(res, 200, { ok: true, requestId: rid, mode: 'real', model: ds.model, latencyMs: 0, candidates: ds.candidates, usage: ds.usage || null, billed: true, provider: 'qwen', taskId: ds.taskId });
        return true;
      }
      const payload = { model: body.model || target.imageModel || target.cfg.imageModel || 'hy-image-v3.0', prompt: body.prompt || '', size: valid.size, n: body.count || 1 };
      if (valid.images.length) payload.images = valid.images;
      let upstream, clear;
      try { ({ res: upstream, clear } = await fetchUpstream(target, '/images/generations', payload, cfg.timeoutMs)); }
      catch (e) {
        const st = e && e.name === 'TimeoutError' ? 504 : 502;
        sendJson(res, st, { ok: false, billed: false, error: { code: st === 504 ? 'timeout' : 'network', message: st === 504 ? 'AI 请求超时（失败不计费）' : '上游不可达（失败不计费）', status: st, billed: false } });
        return true;
      }
      const status = upstream.status;
      if (!upstream.ok) {
        const text = await upstream.text().catch(() => ''); clear(); const m = mapUpstreamError(status, text);
        sendJson(res, m.status, { ok: false, billed: false, error: { code: m.code, message: m.message + '（失败不计费）', status: m.status, billed: false, requestId: rid } });
        return true;
      }
      const data = await upstream.json().catch(() => ({})); clear();
      const candidates = [];
      for (let i = 0; i < (data.data || []).length; i += 1) {
        const d = data.data[i];
        try {
          const src = d.b64_json ? ('data:image/png;base64,' + d.b64_json) : (d.url || '');
          if (!src) continue;
          const cached = await cacheAndEncodeImage(src, rid); // 12h URL 只在服务端立即下载，不交给前端
          candidates.push({ id: 'cand-real-' + (i + 1), label: '方案 ' + String.fromCharCode(65 + i), why: '模型生成（已本地缓存）', imageDataUrl: cached.imageDataUrl, sha256: cached.sha256, bytes: cached.bytes, width: valid.parsed.width, height: valid.parsed.height, source: 'real' });
        } catch (e) { /* 单张失败不影响其他；失败不计费由上游语义 */ }
      }
      if (!candidates.length) { sendJson(res, 502, { ok: false, billed: false, error: { code: 'image_download', message: '图片下载失败（URL 可能 12h 过期；失败不计费）', status: 502, billed: false } }); return true; }
      sendJson(res, 200, { ok: true, requestId: rid, mode: 'real', model: data.model || target.imageModel || 'hy-image-v3.0', latencyMs: 0, candidates, usage: data.usage || null, billed: true });
      return true;
    };
    await enqueueImage(doImage); // 混元默认并发 1：串行队列
    return true;
  }

  aiError(res, 404, 'not_found', '未知 AI 端点');
  return true;
}

// ---------- T99：仅对本地 app 页面注入 token（不写静态 JS） ----------
function injectAiToken(html) {
  if (html.includes('window.__AI_LOCAL_TOKEN__')) return html;
  const tag = `<script>window.__AI_LOCAL_TOKEN__=${JSON.stringify(LOCAL_TOKEN)};</script>`;
  if (html.includes('<head>')) return html.replace('<head>', '<head>' + tag);
  return tag + html;
}
function isAppIndex(file) {
  const rel = path.relative(ROOT, file).split(path.sep).join('/');
  return rel === 'v2/app/index.html';
}

// ---------- 静态服务 ----------
const server = http.createServer(async (req, res) => {
  try {
    const urlPath = req.url || '/';
    if (urlPath === '/health' || urlPath.startsWith('/health?')) { sendJson(res, 200, { ok: true, port: server.address().port, pid: process.pid }); return; }
    if (urlPath.startsWith('/api/ai/')) { await handleAi(req, res, urlPath.split('?')[0]); return; }
    const p = urlPath === '/' ? '/v2/engine/demo.html' : urlPath;
    // P0-1：静态资源必须先过白名单，再交给 safeJoin。ROOT 是整个项目根，
    // 不过滤就会把 .ai-config.json / .ai-token / backups / 归档 zip 一并发出去。
    if (blockedStaticPath(p)) { res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }); res.end('forbidden'); return; }
    let file = safeJoin(ROOT, p);
    if (!file) { res.writeHead(403); res.end('forbidden'); return; }
    let stat;
    try { stat = await fs.stat(file); } catch { res.writeHead(404); res.end('not found'); return; }
    if (stat.isDirectory()) { file = path.join(file, 'index.html'); try { stat = await fs.stat(file); } catch { res.writeHead(404); res.end('not found'); return; } }
    const ext = path.extname(file).toLowerCase();
    let body = await fs.readFile(file);
    if (ext === '.html' && isAppIndex(file)) {
      body = Buffer.from(injectAiToken(body.toString('utf8')), 'utf8');
    }
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(body);
  } catch (e) {
    const status = e && e.status ? e.status : (e && e.name === 'TimeoutError' ? 504 : 500);
    const code = e && e.code ? e.code : ((e && e.name === 'TimeoutError') ? 'timeout' : 'server');
    const message = status === 413 ? 'body_too_large' : ((e && e.name === 'TimeoutError') ? 'AI 请求超时' : (e && e.message) || 'server error');
    aiError(res, status, code, message);
    if (status === 413) res.on('finish', () => { try { req.destroy(); } catch (err) { /* ignore */ } });
  }
});

async function listen(port) {
  return new Promise((resolve, reject) => {
    const onError = (err) => { server.off('listening', onListening); reject(err); };
    const onListening = () => { server.off('error', onError); resolve(port); };
    server.once('error', onError); server.once('listening', onListening); server.listen(port, HOST);
  });
}
let actualPort = null;
for (let i = 0; i <= MAX_TRIES; i++) {
  try { actualPort = await listen(BASE_PORT + i); break; }
  catch (e) { if (e && e.code === 'EADDRINUSE') continue; console.error('启动失败：', e); process.exitCode = 1; throw e; }
}
if (actualPort == null) { console.error('端口被占用，无法启动'); process.exit(1); }
if (!process.env.PORT) await fs.writeFile(PORT_FILE, String(actualPort), 'utf8');
console.log('==========================================');
console.log(' Mozheng v2 demo server');
console.log(` 笔刷试用  http://${HOST}:${actualPort}/v2/brushes/demo.html`);
console.log(` 引擎 demo http://${HOST}:${actualPort}/v2/engine/demo.html`);
console.log(` 图层 demo http://${HOST}:${actualPort}/v2/layers/demo.html`);
console.log(` 选区 demo http://${HOST}:${actualPort}/v2/selection/demo.html`);
console.log(` AI 代理   http://${HOST}:${actualPort}/api/ai/health`);
console.log(` AI 配置   ${AI_CONFIG_PATH}`);
console.log(` 本地 token ${process.env.AI_LOCAL_TOKEN ? '(env)' : AI_TOKEN_PATH}`);
console.log(' 关闭本窗口即停止服务');
console.log('==========================================');
