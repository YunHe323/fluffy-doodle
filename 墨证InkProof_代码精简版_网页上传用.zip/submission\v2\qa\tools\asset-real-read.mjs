// v2/qa/tools/asset-real-read.mjs —— 真实 Qwen 视觉重读素材（素材库 × API × Skill）
import { chromium } from '../node_modules/playwright-core/index.mjs';
import fs from 'node:fs';
const OUT = 'v2/qa/tools/asset-real-read-results.json';
const res = { schema: 'mozheng.qa.asset-real-read.v1', cases: {}, errors: [], pass: false };
let browser = null;
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('mozheng.ai.settings.v1', JSON.stringify({ preset: 'qwen', allowReal: true, requireConfirm: false, privacyMode: false })); } catch (e) {} });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => res.errors.push(String(e.message || e).slice(0, 300)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) res.errors.push(m.text().slice(0, 300)); });
  await page.goto('http://127.0.0.1:4200/v2/app/index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1800);
  await page.click('#btnLibrary');
  await page.waitForFunction(() => document.querySelectorAll('#libGrid .lib-card').length > 0, null, { timeout: 20000 });
  await page.waitForTimeout(700);
  const before = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const list = a.state.library.assets || [];
    return { count: list.length, first: list[0] && { id: list[0].id, name: list[0].fileName, source: list[0].analysisSource || 'mock', l2: (list[0].L2 || []).length, l4: (list[0].L4 || []).length } };
  });
  await page.click('#libReanalyzeReal');
  const t0 = Date.now();
  await page.waitForFunction(() => {
    const a = window.__V2_APP__;
    const list = a.state.library.assets || [];
    return list.some((x) => x.analysisSource === 'real');
  }, null, { timeout: 120000 });
  await page.waitForTimeout(600);
  const after = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const list = a.state.library.assets || [];
    const one = list.find((x) => x.analysisSource === 'real');
    return { asset: one ? { id: one.id, name: one.fileName, source: one.analysisSource, model: one.modelVersion, analysis: one.analysis, l1: one.L1 && one.L1.summary, l2: (one.L2 || []).length, l4: (one.L4 || []).length, tags: (one.tags || []).slice(0, 10) } : null, records: a.state.records.filter((r) => r.kind === 'critique' && r.params && r.params.task === 'asset_decompose').map((r) => ({ model: r.model, latency: r.latency_ms, skills: r.params.skill, obs: r.params.observations })) };
  });
  res.cases.before = before;
  res.cases.after = after;
  res.cases.ms = Date.now() - t0;
  await page.screenshot({ path: 'v2/app/ui-asset-real-read-1920.png' });
  res.pass = !!(after.asset && after.asset.source === 'real' && after.asset.model && after.asset.l2 > 0 && after.asset.l4 > 0 && after.records.length >= 1 && after.records[0].skills === 'asset.decompose' && res.errors.length === 0);
} catch (e) { res.fatal = String(e && e.stack || e); } finally { try { await browser.close(); } catch (e) {} }
await fs.promises.writeFile(OUT, JSON.stringify(res, null, 2), 'utf8');
console.log(JSON.stringify(res, null, 2));
process.exit(res.pass ? 0 : 1);
