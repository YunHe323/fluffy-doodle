# Code of Conduct

## Our pledge

We want Mozheng to be a welcoming, harassment-free project for everyone — regardless of experience level, age, body size, visible or invisible disability, ethnicity, gender identity and expression, education, nationality, personal appearance, race, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy community.

## Our standards

**Examples of behavior that contributes to a positive environment:**

- Being kind, patient, and respectful in reviews and discussions.
- Assuming good intent, while being precise about technical concerns.
- Giving and accepting constructive feedback gracefully.
- Crediting others' work and ideas; respecting licenses and attribution.
- Focusing on what is best for the project and its users.

**Examples of unacceptable behavior:**

- Harassment, insults, derogatory comments, or personal attacks.
- Sexualized language or imagery, and unwelcome sexual attention.
- Trolling, deliberate disruption, or sustained bad-faith argument.
- Publishing others' private information (including artwork, messages, or identity) without explicit permission.
- Discrimination or exclusionary jokes based on personal characteristics.
- Any conduct that would reasonably be considered inappropriate in a professional setting.

## Scope

This Code of Conduct applies in all project spaces — issues, pull requests, discussions, chat, and any public or private communication related to the project. It also applies when an individual is representing the project in public spaces.

## Reporting

If you experience or witness unacceptable behavior, please report it privately to the maintainers:

- **Contact:** `<MAINTAINER CONTACT TO BE FILLED>` (replace before public release)
- Reports will be reviewed promptly and fairly. The privacy of the reporter will be respected.

## Enforcement

Maintainers may take any action they deem appropriate, including:

1. A private warning and clarification of expectations.
2. Removing or editing comments, commits, code, or other contributions.
3. A temporary or permanent ban from participating in the project.

## Attribution

This document is a short, project-specific code of conduct inspired by the spirit of the Contributor Covenant, version 2.1. It is intentionally concise; it is not a verbatim copy.
