---
name: Bug report
about: Something is broken or behaves unexpectedly
labels: bug
---

## Summary

<!-- A clear, one-sentence description of the bug. -->

## Environment

- OS: <!-- Windows 11 / macOS 14 / Ubuntu 24.04 -->
- Browser + version: <!-- Chrome 1xx / Edge 1xx -->
- Node.js version (`node -v`):
- Mozheng version: <!-- Settings → About, or /api/health `version` -->
- How you started: <!-- start.bat / start.sh / node server/server.mjs -->

## Steps to reproduce

1.
2.
3.

**Expected:** <!-- what should happen -->

**Actual:** <!-- what happened, including exact error text -->

## Evidence

- Screenshot / screen recording:
- Console errors (browser DevTools → Console):
- Terminal / service output:

> Please do **not** attach private artwork, personal data, API keys, or full evidence packages unless you are comfortable sharing them. A cropped screenshot or a redacted reproduction is enough.

## Data safety

- Did this affect your local projects or archives? <!-- yes/no/unknown -->
- Did it happen in mock mode, or with a configured provider? <!-- mock / provider / not sure -->

## Additional context

<!-- Anything else: recent changes, frequency, related issues. -->
