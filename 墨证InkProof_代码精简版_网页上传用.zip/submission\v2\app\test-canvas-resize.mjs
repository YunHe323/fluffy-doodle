// v2/app/test-canvas-resize.mjs —— 画布尺寸 / 裁剪到选区（保留图层、清空历史）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8166;
const out = { schema: 'mozheng.app.canvas-resize.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-canvas-resize-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
const stats = async (page) => page.evaluate(async () => {
  const a = window.__V2_APP__;
  const url = await a.engine.getCompositeDataUrl();
  const img = new Image(); img.src = url; await img.decode();
  const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
  const g = c.getContext('2d'); g.drawImage(img, 0, 0);
  const d = g.getImageData(0, 0, c.width, c.height).data;
  let ink = 0; for (let i = 0; i < d.length; i += 4) if (d[i] < 240 || d[i + 1] < 240 || d[i + 2] < 240) ink += 1;
  return { w: a.engine.width, h: a.engine.height, imgW: img.width, imgH: img.height, layers: a.engine.getLayers().length, ink, steps: a.engine.getHistoryStats().steps, canvasW: document.getElementById('mainCanvas').width, canvasH: document.getElementById('mainCanvas').height, records: a.state.records.filter((r) => r.kind === 'canvas_resized').length };
});
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  const box = await page.locator('#mainCanvas').boundingBox();
  await page.mouse.move(box.x + box.width * 0.42, box.y + box.height * 0.42);
  await page.mouse.down(); await page.mouse.move(box.x + box.width * 0.55, box.y + box.height * 0.55, { steps: 10 }); await page.mouse.up();
  await page.waitForTimeout(500);
  const before = await stats(page);
  out.cases.before = before;
  await page.click('#btnMore'); await page.waitForTimeout(200);
  await page.click('#btnCanvasResize'); await page.waitForTimeout(300);
  out.cases.modal = await page.evaluate(() => ({ show: !!document.querySelector('#canvasResizeModal.show'), title: (document.getElementById('canvasResizeTitle') || {}).textContent, w: (document.getElementById('resizeWidth') || {}).value, h: (document.getElementById('resizeHeight') || {}).value }));
  await page.fill('#resizeWidth', '800'); await page.fill('#resizeHeight', '600');
  await page.click('#btnCanvasResizeApply');
  await page.waitForTimeout(1600);
  const resized = await stats(page);
  out.cases.resized = resized;
  // resize 之后仍应能画（GL/store 重建后 BrushController 正常工作）
  const box2 = await page.locator('#mainCanvas').boundingBox();
  await page.mouse.move(box2.x + box2.width * 0.45, box2.y + box2.height * 0.45);
  await page.mouse.down(); await page.mouse.move(box2.x + box2.width * 0.55, box2.y + box2.height * 0.55, { steps: 8 }); await page.mouse.up();
  await page.waitForTimeout(600);
  const afterDraw = await stats(page);
  out.cases.afterDraw = afterDraw;
  out.cases.drawAfterResizeOk = afterDraw.ink > resized.ink + 100;
  // 裁剪：设置状态选区，打开裁剪 modal
  await page.evaluate(() => { const a = window.__V2_APP__; a.state.selection = { x: 100, y: 80, width: 400, height: 300 }; a.drawSelection(); });
  await page.click('#btnMore'); await page.waitForTimeout(200);
  await page.click('#btnCropSelection'); await page.waitForTimeout(300);
  out.cases.cropModal = await page.evaluate(() => ({ show: !!document.querySelector('#canvasResizeModal.show'), title: (document.getElementById('canvasResizeTitle') || {}).textContent, w: (document.getElementById('resizeWidth') || {}).value, h: (document.getElementById('resizeHeight') || {}).value, anchorDisabled: (document.getElementById('resizeAnchor') || {}).disabled }));
  await page.click('#btnCanvasResizeApply');
  await page.waitForTimeout(1600);
  const cropped = await stats(page);
  out.cases.cropped = cropped;
  out.cases.persist = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    const json = a.engine.serializeDoc();
    await a.t61.loadProjectText(json);
    await new Promise((r) => setTimeout(r, 600));
    const s = { w: a.engine.width, h: a.engine.height, layers: a.engine.getLayers().length, steps: a.engine.getHistoryStats().steps, names: a.engine.getLayers().map((l) => l.name) };
    return s;
  });
  await page.waitForTimeout(500);
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-canvas-resize-1920.png' });
  out.cases.resizeOk = resized.w === 800 && resized.h === 600 && resized.imgW === 800 && resized.imgH === 600 && resized.layers === before.layers && resized.canvasW === 800 && resized.canvasH === 600 && resized.steps === 0 && resized.records >= 1 && resized.ink > 0;
  out.cases.persistOk = out.cases.persist.w === 400 && out.cases.persist.h === 300 && out.cases.persist.layers === before.layers;
  out.cases.cropOk = cropped.w === 400 && cropped.h === 300 && cropped.imgW === 400 && cropped.imgH === 300 && cropped.layers === before.layers && cropped.records >= 2 && cropped.ink > 0;
  out.cases.modalOk = out.cases.modal.show && out.cases.modal.title === '画布尺寸' && out.cases.modal.w === String(before.w) && out.cases.cropModal.show && out.cases.cropModal.title === '裁剪画布' && out.cases.cropModal.w === '400' && out.cases.cropModal.anchorDisabled === true;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.resizeOk && out.cases.drawAfterResizeOk && out.cases.cropOk && out.cases.persistOk && out.cases.modalOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
