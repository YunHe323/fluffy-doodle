// v2/app/test-save-psd.mjs — T81 app 异步保存/PSD（T79 API）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8122;
const out = { schema: 'mozheng.app.save-psd-test.v1', cases: {}, errors: [] };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
let browser = null; let errors = [];
const finish = (code = 0) => { try { fs.writeFileSync(ROOT + '\\v2\\app\\test-save-psd-result.json', JSON.stringify(out, null, 2), 'utf8'); } catch (e) {} process.exit(code); };
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_240s'; finish(3); }, 240000);
try {
  await new Promise((r) => setTimeout(r, 800));
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const context = await browser.newContext({ viewport: { width: 1366, height: 768 }, acceptDownloads: true });
  const page = await context.newPage();
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  const load = async () => {
    await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
    await page.waitForTimeout(600);
  };
  await load();
  // 画一点内容，确保有 tiles/图层
  const box = await page.locator('#mainCanvas').boundingBox();
  await page.evaluate(() => { const a = window.__V2_APP__; a.engine.setActiveLayer(a.engine.getLayers()[0].id); a.engine.setLayerLocked(a.engine.getLayers()[0].id, false); a.setTool('brush'); });
  await page.mouse.move(box.x + box.width * 0.3, box.y + box.height * 0.4); await page.mouse.down();
  for (let i = 1; i <= 8; i++) await page.mouse.move(box.x + box.width * (0.3 + i * 0.025), box.y + box.height * (0.4 + i * 0.02));
  await page.mouse.up(); await page.waitForTimeout(1800);

  out.cases.warm = await page.evaluate(async () => { const t = window.__V2_APP__.t81; const t0 = performance.now(); const ok = await t.warmUpSave(); await new Promise((r) => setTimeout(r, 300)); return { ok, ms: Math.round(performance.now() - t0) }; });

  // 保存进度 + 长任务
  out.cases.save = await page.evaluate(async () => {
    const app = window.__V2_APP__; const t = app.t81;
    const prog = [];
    const beforePng = await app.engine.getCompositeDataUrl();
    localStorage.setItem('t81-before-png', beforePng);
    localStorage.setItem('t81-before-doc', JSON.stringify(app.engine.getDoc()));
    window.__LT = []; window.__LTO = new PerformanceObserver((l) => window.__LT.push(...l.getEntries().map((e) => e.duration)));
    try { window.__LTO.observe({ entryTypes: ['longtask'] }); } catch (e) {}
    const r = await t.saveProjectAsync({ onProgress: (p) => prog.push(p) });
    await new Promise((r2) => setTimeout(r2, 250));
    try { window.__LTO.disconnect(); } catch (e) {}
    return { bytes: r.bytes, compressed: r.compressed, phases: [...new Set(prog.map((p) => p.phase))], longTasks: window.__LT.length, maxLong: window.__LT.length ? Math.max(...window.__LT) : 0, pngLen: beforePng.length };
  });

  // 实际保存按钮路径（写 IDB + 下载）
  out.cases.saveDownload = await page.evaluate(async () => { const t = window.__V2_APP__.t81; const r = await t.saveProjectDownload(); return { ok: !!r && r.bytes > 100, bytes: r ? r.bytes : 0 }; });
  await page.waitForTimeout(600);

  // 取消保存 → 可再次保存
  out.cases.cancelSave = await page.evaluate(async () => {
    const t = window.__V2_APP__.t81;
    let err = null;
    const p = t.saveDocAsync({ onProgress: () => {} });
    setTimeout(() => { try { t.cancelSave(); } catch (e) {} }, 3);
    try { await p; } catch (e) { err = { name: e.name, message: e.message }; }
    await new Promise((r) => setTimeout(r, 200));
    let ok = false;
    try { const r = await t.saveProjectAsync(); ok = r.bytes > 100; } catch (e) { ok = false; }
    return { err, ok };
  });

  // 刷新 → 自动恢复 → 像素 diff=0
  await page.waitForTimeout(500);
  await page.reload();
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(900);
  out.cases.reload = await page.evaluate(async () => {
    const app = window.__V2_APP__; const t = app.t81;
    const before = localStorage.getItem('t81-before-png');
    const after = await app.engine.getCompositeDataUrl();
    const decode = async (url) => { const img = new Image(); img.src = url; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; c.getContext('2d').drawImage(img, 0, 0); return c.getContext('2d').getImageData(0, 0, c.width, c.height).data; };
    let diff = 0; let maxDiff = 0; let opaqueDiff = 0;
    try { const a = await decode(before); const b = await decode(after); for (let i = 0; i < a.length; i += 4) {
      const d = Math.max(Math.abs(a[i] - b[i]), Math.abs(a[i + 1] - b[i + 1]), Math.abs(a[i + 2] - b[i + 2]), Math.abs(a[i + 3] - b[i + 3]));
      if (d > 0) diff += 1; if (d > maxDiff) maxDiff = d;
      if (a[i + 3] === 255 && b[i + 3] === 255 && Math.max(Math.abs(a[i] - b[i]), Math.abs(a[i + 1] - b[i + 1]), Math.abs(a[i + 2] - b[i + 2])) > 0) opaqueDiff += 1;
    } } catch (e) { diff = -1; }
    const layers = app.engine.getLayers().length;
    const rec = await t.getAutosaveRecord();
    let docRoundtrip = false;
    try {
      if (rec && rec.blob) { await t.loadProjectData(rec.blob); docRoundtrip = JSON.stringify(app.engine.getDoc()) === localStorage.getItem('t81-before-doc'); }
    } catch (e) { docRoundtrip = false; }
    // v1 打开
    const v1 = app.t61.saveProjectText();
    const v1doc = await t.loadProjectText(v1);
    return { diff, maxDiff, opaqueDiff, docRoundtrip, pixelTolerance: 'PNG/alpha rounding <=1 per channel (engine tile codec)', layers, autosave: { has: !!(rec && (rec.blob || rec.json)), compressed: rec ? rec.compressed !== false : null, bytes: rec ? (rec.bytes || 0) : 0 }, v1: { layers: v1doc.layers.length, groups: v1doc.groups.length } };
  });

  // PSD 异步 + 进度/长任务
  out.cases.psd = await page.evaluate(async () => {
    const app = window.__V2_APP__; const t = app.t81;
    const prog = [];
    window.__LT2 = []; window.__LTO2 = new PerformanceObserver((l) => window.__LT2.push(...l.getEntries().map((e) => e.duration)));
    try { window.__LTO2.observe({ entryTypes: ['longtask'] }); } catch (e) {}
    const r = await t.exportPsdAsync({ onProgress: (p) => prog.push(p) });
    await new Promise((res) => setTimeout(res, 250));
    try { window.__LTO2.disconnect(); } catch (e) {}
    return { bytes: r.bytes, head: r.head, phases: [...new Set(prog.map((p) => p.phase))], longTasks: window.__LT2.length, maxLong: window.__LT2.length ? Math.max(...window.__LT2) : 0 };
  });
  out.cases.cancelPsd = await page.evaluate(async () => {
    const t = window.__V2_APP__.t81;
    let err = null; let cancelled = false;
    const p = t.exportPsdAsync({ onProgress: (pr) => { if (!cancelled && pr.phase === 'render') { cancelled = true; try { t.cancelPSD(); } catch (e) {} } } });
    try { await p; } catch (e) { err = { name: e.name, message: e.message }; }
    await new Promise((r) => setTimeout(r, 200));
    let ok = false; try { const r = await t.exportPsdAsync(); ok = r.bytes > 100 && r.head === '8BPS'; } catch (e) { ok = false; }
    return { err, ok };
  });

  // 降级：API/Worker 不可用
  out.cases.fallback = await page.evaluate(async () => {
    const app = window.__V2_APP__; const e = app.engine; const t = app.t81;
    const origSave = e.saveDocAsync; const origPsd = e.exportPSDAsync; const origWorker = window.Worker;
    let saveOk = false; let psdOk = false;
    try {
      e.saveDocAsync = undefined; Object.defineProperty(window, 'Worker', { value: undefined, configurable: true });
      const r = await t.saveProjectDownload(); saveOk = !!r && r.bytes > 100;
    } catch (err) { saveOk = false; } finally {
      e.saveDocAsync = origSave; try { Object.defineProperty(window, 'Worker', { value: origWorker, configurable: true }); } catch (err) {}
    }
    try {
      e.exportPSDAsync = undefined;
      const r = await t.exportPsdDownload(); psdOk = !!r && r.bytes > 100;
    } catch (err) { psdOk = false; } finally { e.exportPSDAsync = origPsd; }
    return { saveOk, psdOk };
  });

  // 三档截图（保存进度态）
  const shots = {};
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await page.setViewportSize({ width: w, height: h });
    await load();
    await page.evaluate(() => { const t = window.__V2_APP__.t78; t.showAsyncTask('保存项目', () => {}, { mode: 'save' }); t.updateAsyncTask({ phase: 'encode', done: 3, total: 8 }); });
    await page.waitForTimeout(300);
    await page.screenshot({ path: ROOT + '\\v2\\app\\ui-save-' + w + '.png' });
    shots[w] = await page.evaluate(() => ({ overX: document.documentElement.scrollWidth > innerWidth + 1, overY: document.documentElement.scrollHeight > innerHeight + 1, task: !document.getElementById('asyncTask').hidden, text: document.getElementById('asyncTaskLabel').textContent }));
    await page.evaluate(() => window.__V2_APP__.t78.hideAsyncTask());
  }
  out.cases.screenshots = shots;
  out.errors = errors.slice(0, 10);
  out.pass = {
    warm: out.cases.warm.ok || out.cases.save.longTasks === 0,
    saveProgress: out.cases.save.compressed && out.cases.save.phases.includes('encode') && out.cases.save.phases.includes('done') && out.cases.save.bytes > 100,
    saveLongTask: out.cases.save.longTasks === 0 || (out.cases.save.longTasks === 1 && out.cases.save.maxLong < 20),
    saveDownload: out.cases.saveDownload.ok,
    cancelSave: out.cases.cancelSave.err && out.cases.cancelSave.err.name === 'AbortError' && out.cases.cancelSave.ok,
    reloadPixel: out.cases.reload.diff <= 32 && out.cases.reload.maxDiff <= 1,
    docRoundtrip: out.cases.reload.docRoundtrip,
    autosave: out.cases.reload.autosave.has && out.cases.reload.autosave.compressed,
    v1Open: out.cases.reload.v1.layers >= 1,
    psd: out.cases.psd.head === '8BPS' && out.cases.psd.bytes > 100 && out.cases.psd.phases.includes('render') && out.cases.psd.phases.includes('done'),
    psdLongTask: out.cases.psd.longTasks === 0 || (out.cases.psd.longTasks === 1 && out.cases.psd.maxLong < 20),
    cancelPsd: out.cases.cancelPsd.err && out.cases.cancelPsd.err.name === 'AbortError' && out.cases.cancelPsd.ok,
    fallback: out.cases.fallback.saveOk && out.cases.fallback.psdOk,
    screenshots: Object.values(shots).every((v) => !v.overX && !v.overY && v.task),
  };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} finally {
  clearTimeout(hard);
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  finish(0);
}
