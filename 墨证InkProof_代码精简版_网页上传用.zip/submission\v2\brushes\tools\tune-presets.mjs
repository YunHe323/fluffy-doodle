#!/usr/bin/env node
/**
 * v2/brushes/tools/tune-presets.mjs
 * T43 手感调参表：以「基础模板 + 每笔刷覆盖」的方式重写 presets/defaults.json。
 * - 所有字段显式给出，便于 review 前后差异；
 * - 调参依据：Procreate 常见笔刷观感 + 真实浏览器实测（见 手感报告.md）；
 * - 用法：node v2/brushes/tools/tune-presets.mjs   （然后 node v2/brushes/tools/validate-presets.mjs）
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BRUSH_DIR = path.resolve(HERE, '..');
const OUT = path.join(BRUSH_DIR, 'presets', 'defaults.json');

const deep = (o) => JSON.parse(JSON.stringify(o));
const identityTexture = () => ({
  assetId: null,
  scale: 1,
  pressureScale: 0,
  rotationDeg: 0,
  rotationJitter: 0,
  roll: 0,
  blendMode: 'multiply',
  contrast: 1,
  brightness: 0,
});
const zeroDyn = () => ({ speedSizeFactor: 0, speedOpacityFactor: 0, tiltSizeFactor: 0, tiltOpacityFactor: 0, tiltAngleJitter: 0 });
const zeroColor = () => ({ hueJitter: 0, saturationJitter: 0, valueJitter: 0, backgroundMix: 0 });
const smudgeOff = () => ({ enabled: false, strength: 0, length: 0 });

/** 基础模板：只放所有笔刷共用的默认值 */
function brush(over) {
  const b = {
    id: over.id,
    name: over.name,
    nameEn: over.nameEn,
    category: over.category,
    engine: { strokeMode: 'stamp', blendMode: 'normal', eraser: false, ...(over.engine || {}) },
    size: { base: 32, min: 1, max: 512, pressureCurve: [0.15, 0.35, 0.6, 0.82, 1], ...(over.size || {}) },
    spacing: { ratio: 0.08, minPx: 0.5, ...(over.spacing || {}) },
    tip: { shape: 'circle', roundness: 1, angleDeg: 0, ...(over.tip || {}) },
    hardness: { base: 0.9, pressureFactor: 0, ...(over.hardness || {}) },
    opacity: { base: 1, min: 0.1, pressureCurve: [0.2, 0.42, 0.66, 0.86, 1], ...(over.opacity || {}) },
    flow: { base: 0.9, pressureCurve: [0.4, 0.6, 0.8, 0.95, 1], ...(over.flow || {}) },
    texture: { ...identityTexture(), ...(over.texture || {}) },
    colorDynamics: { ...zeroColor(), ...(over.colorDynamics || {}) },
    scatter: { positionJitter: 0, angleJitter: 0, count: 1, ...(over.scatter || {}) },
    dynamics: { ...zeroDyn(), ...(over.dynamics || {}) },
    smoothing: { stabilizer: 0.15, predictionMs: 0, ...(over.smoothing || {}) },
    wetness: { enabled: false, spread: 0, edgeDarkening: 0, drying: 0, ...(over.wetness || {}) },
    smudge: { enabled: false, strength: 0, length: 0, ...(over.smudge || {}) },
    performance: { maxStampsPerFrame: 2048, preferTileComposite: true, ...(over.performance || {}) },
    tags: over.tags || [],
    taper: { start: 0.06, end: 0.14, ...(over.taper || {}) },
    // T52：路径引擎（默认 bezier 回退；hard-round/pencil/ink-liner 用 perfect-freehand 轮廓）
    pathEngine: over.pathEngine || 'bezier',
    ...(over.perfectFreehand ? { perfectFreehand: over.perfectFreehand } : {}),
  };
  return b;
}

const brushes = [
  brush({
    id: 'hard-round', name: '硬边圆笔', nameEn: 'Hard Round', category: 'basic',
    tags: ['基础', '线稿'],
    // T43：Procreate 硬笔特征——压力主要影响「尺寸」，不透明度基本维持（轻压=细而实）
    size: { base: 36, min: 1, max: 512, pressureCurve: [0.12, 0.35, 0.6, 0.82, 1] },
    spacing: { ratio: 0.05, minPx: 0.4 },
    hardness: { base: 0.92, pressureFactor: 0.04 },
    opacity: { base: 1, min: 0.85, pressureCurve: [0.85, 0.9, 0.95, 0.98, 1] },
    flow: { base: 1, pressureCurve: [0.85, 0.9, 0.95, 1, 1] },
    dynamics: { speedSizeFactor: 0.04, speedOpacityFactor: 0.06, tiltSizeFactor: 0.1, tiltOpacityFactor: 0.05, tiltAngleJitter: 0 },
    smoothing: { stabilizer: 0.18, predictionMs: 0 },
    taper: { start: 0.05, end: 0.14 },
    performance: { maxStampsPerFrame: 2048, preferTileComposite: true },
    // T52：perfect-freehand(MIT) 轮廓参数已登记，但默认 pathEngine='bezier'；
    // 用户试用 + GATE 复测通过前不改变默认笔刷观感，仅 demo/调用方可 opt-in。
    pathEngine: 'bezier',
    perfectFreehand: { thinning: 0.62, smoothing: 0.6, streamline: 0.35 },
  }),
  brush({
    id: 'soft-round', name: '软边圆笔', nameEn: 'Soft Round', category: 'basic',
    tags: ['基础', '上色'],
    // T43：软边不要糊成一团（hardness 0.15→0.32），流量降低让叠色可控
    size: { base: 56, min: 1, max: 512, pressureCurve: [0.15, 0.38, 0.62, 0.84, 1] },
    spacing: { ratio: 0.07, minPx: 0.4 },
    hardness: { base: 0.4, pressureFactor: 0.08 },
    opacity: { base: 0.95, min: 0.12, pressureCurve: [0.15, 0.35, 0.6, 0.82, 1] },
    flow: { base: 0.72, pressureCurve: [0.35, 0.55, 0.75, 0.92, 1] },
    colorDynamics: { backgroundMix: 0.05 },
    dynamics: { speedSizeFactor: 0.03, speedOpacityFactor: 0.08, tiltSizeFactor: 0.12, tiltOpacityFactor: 0.08, tiltAngleJitter: 0 },
    smoothing: { stabilizer: 0.22, predictionMs: 0 },
    taper: { start: 0.1, end: 0.18 },
  }),
  brush({
    id: 'pencil', name: '铅笔', nameEn: 'Pencil', category: 'texture',
    tags: ['纹理', '素描'],
    // T43：颗粒不再被 4.5x 放大（纹理 scale 语义改为 1=1:1 纹素），纸张颗粒滚动；倾斜加宽
    size: { base: 8, min: 1, max: 64, pressureCurve: [0.15, 0.35, 0.6, 0.82, 1] },
    spacing: { ratio: 0.035, minPx: 0.35 },
    hardness: { base: 0.66, pressureFactor: 0.1 },
    opacity: { base: 0.92, min: 0.16, pressureCurve: [0.18, 0.36, 0.56, 0.78, 1] },
    flow: { base: 0.9, pressureCurve: [0.25, 0.45, 0.65, 0.85, 1] },
    texture: { assetId: 'pencil-noise', scale: 0.85, pressureScale: 0.2, rotationJitter: 0.35, roll: 0.35, contrast: 1.35 },
    colorDynamics: { hueJitter: 0.02, saturationJitter: 0.03, valueJitter: 0.08, backgroundMix: 0.08 },
    scatter: { positionJitter: 0.06, angleJitter: 0.2, count: 1 },
    dynamics: { speedSizeFactor: 0, speedOpacityFactor: 0.22, tiltSizeFactor: 0.3, tiltOpacityFactor: 0.15, tiltAngleJitter: 0 },
    smoothing: { stabilizer: 0.12, predictionMs: 0 },
    taper: { start: 0.12, end: 0.22 },
    // T52：perfect-freehand 参数已登记，默认仍走 bezier（opt-in；见 手感报告 §12）
    pathEngine: 'bezier',
    perfectFreehand: { thinning: 0.55, smoothing: 0.65, streamline: 0.3 },
  }),
  brush({
    id: 'airbrush', name: '喷枪', nameEn: 'Airbrush', category: 'air',
    tags: ['喷枪', '过渡'],
    // T43：低流量慢叠色；散射 3 dab；收锋更长
    size: { base: 110, min: 8, max: 512, pressureCurve: [0.25, 0.45, 0.65, 0.85, 1] },
    spacing: { ratio: 0.1, minPx: 1 },
    hardness: { base: 0.02, pressureFactor: 0 },
    opacity: { base: 0.6, min: 0.05, pressureCurve: [0.05, 0.15, 0.3, 0.55, 0.9] },
    flow: { base: 0.22, pressureCurve: [0.1, 0.2, 0.35, 0.55, 0.85] },
    colorDynamics: { backgroundMix: 0.15 },
    scatter: { positionJitter: 0.25, angleJitter: 0.6, count: 3 },
    dynamics: { speedSizeFactor: 0, speedOpacityFactor: -0.12, tiltSizeFactor: 0.15, tiltOpacityFactor: 0, tiltAngleJitter: 0 },
    smoothing: { stabilizer: 0.28, predictionMs: 0 },
    taper: { start: 0.25, end: 0.3 },
  }),
  brush({
    id: 'chalk', name: '粉笔', nameEn: 'Chalk', category: 'dry',
    tags: ['干画', '颗粒'],
    // T43：颗粒 1:1 + 滚动，降低整体黑度让颗粒呼吸；轻压仍可见
    size: { base: 46, min: 4, max: 256, pressureCurve: [0.2, 0.42, 0.62, 0.82, 1] },
    spacing: { ratio: 0.09, minPx: 0.6 },
    hardness: { base: 0.58, pressureFactor: -0.08 },
    opacity: { base: 0.88, min: 0.16, pressureCurve: [0.16, 0.32, 0.52, 0.76, 1] },
    flow: { base: 0.65, pressureCurve: [0.25, 0.4, 0.6, 0.8, 1] },
    texture: { assetId: 'chalk', scale: 0.9, pressureScale: 0.4, rotationJitter: 0.5, roll: 0.5, contrast: 1.25 },
    colorDynamics: { hueJitter: 0.02, saturationJitter: 0.05, valueJitter: 0.12, backgroundMix: 0.12 },
    scatter: { positionJitter: 0.18, angleJitter: 0.45, count: 2 },
    dynamics: { speedSizeFactor: 0.08, speedOpacityFactor: 0.18, tiltSizeFactor: 0.22, tiltOpacityFactor: 0.15, tiltAngleJitter: 0.2 },
    smoothing: { stabilizer: 0.1, predictionMs: 0 },
    performance: { maxStampsPerFrame: 1024, preferTileComposite: true },
    taper: { start: 0.15, end: 0.22 },
  }),
  brush({
    id: 'charcoal', name: '炭笔', nameEn: 'Charcoal', category: 'dry',
    tags: ['干画', '素描'],
    // T43：椭圆笔尖跟随笔画 + 粗颗粒滚动；整体压暗但不糊
    size: { base: 64, min: 6, max: 384, pressureCurve: [0.15, 0.32, 0.52, 0.75, 1] },
    spacing: { ratio: 0.1, minPx: 0.7 },
    tip: { shape: 'ellipse', roundness: 0.62, angleDeg: 20, followStroke: true },
    hardness: { base: 0.52, pressureFactor: -0.12 },
    opacity: { base: 0.86, min: 0.08, pressureCurve: [0.08, 0.22, 0.42, 0.68, 1] },
    flow: { base: 0.68, pressureCurve: [0.2, 0.35, 0.55, 0.78, 1] },
    texture: { assetId: 'grain-coarse', scale: 0.85, pressureScale: 0.5, rotationJitter: 0.6, roll: 0.6, contrast: 1.3, brightness: -0.02 },
    colorDynamics: { hueJitter: 0.02, saturationJitter: 0.06, valueJitter: 0.14, backgroundMix: 0.15 },
    scatter: { positionJitter: 0.14, angleJitter: 0.5, count: 2 },
    dynamics: { speedSizeFactor: 0.08, speedOpacityFactor: 0.22, tiltSizeFactor: 0.28, tiltOpacityFactor: 0.2, tiltAngleJitter: 0.3 },
    smoothing: { stabilizer: 0.08, predictionMs: 0 },
    performance: { maxStampsPerFrame: 1024, preferTileComposite: true },
    taper: { start: 0.18, end: 0.28 },
    engine: { strokeMode: 'stamp', blendMode: 'multiply', eraser: false },
  }),
  brush({
    id: 'ink-liner', name: '墨水线稿', nameEn: 'Ink Liner', category: 'basic',
    tags: ['线稿', '钢笔'],
    // T43：稳定化 0.5 保平滑 + 收笔追尾；速度→线性变细；压力主要影响尺寸
    size: { base: 4, min: 1, max: 32, pressureCurve: [0.25, 0.45, 0.65, 0.85, 1] },
    spacing: { ratio: 0.03, minPx: 0.3 },
    hardness: { base: 1, pressureFactor: 0 },
    opacity: { base: 1, min: 0.9, pressureCurve: [0.9, 0.93, 0.96, 0.98, 1] },
    flow: { base: 1, pressureCurve: [0.9, 0.93, 0.96, 1, 1] },
    dynamics: { speedSizeFactor: -0.18, speedOpacityFactor: 0, tiltSizeFactor: 0, tiltOpacityFactor: 0, tiltAngleJitter: 0 },
    smoothing: { stabilizer: 0.4, predictionMs: 4 },
    engine: { strokeMode: 'continuous', blendMode: 'normal', eraser: false },
    taper: { start: 0.06, end: 0.16 },
    // T52：perfect-freehand 参数已登记，默认仍走 bezier（opt-in；见 手感报告 §12）
    pathEngine: 'bezier',
    perfectFreehand: { thinning: 0.5, smoothing: 0.55, streamline: 0.55 },
  }),
  brush({
    id: 'marker', name: '马克笔', nameEn: 'Marker', category: 'basic',
    tags: ['上色', '叠色'],
    // T43：椭圆笔尖（横向扁头）+ 画布织纹固定，不再糊成黑带
    size: { base: 34, min: 2, max: 128, pressureCurve: [0.55, 0.72, 0.85, 0.95, 1] },
    spacing: { ratio: 0.06, minPx: 0.5 },
    tip: { shape: 'ellipse', roundness: 0.52, angleDeg: 0, followStroke: false },
    hardness: { base: 0.8, pressureFactor: 0 },
    opacity: { base: 0.62, min: 0.3, pressureCurve: [0.5, 0.62, 0.75, 0.88, 1] },
    flow: { base: 0.6, pressureCurve: [0.45, 0.6, 0.75, 0.9, 1] },
    texture: { assetId: 'canvas-weave', scale: 1, pressureScale: 0, rotationJitter: 0.05, roll: 0, blendMode: 'overlay', contrast: 0.9, brightness: 0.03 },
    colorDynamics: { hueJitter: 0, saturationJitter: 0.02, valueJitter: 0.02, backgroundMix: 0.1 },
    dynamics: { speedSizeFactor: 0, speedOpacityFactor: 0.12, tiltSizeFactor: 0.12, tiltOpacityFactor: 0, tiltAngleJitter: 0 },
    smoothing: { stabilizer: 0.16, predictionMs: 0 },
    engine: { strokeMode: 'stamp', blendMode: 'multiply', eraser: false },
    taper: { start: 0.12, end: 0.12 },
  }),
  brush({
    id: 'watercolor', name: '水彩', nameEn: 'Watercolor', category: 'wet',
    tags: ['湿画', '水彩'],
    // T43：沉淀颗粒 1:1 左右（不再出现巨大气泡），散射+软边近似湿边
    size: { base: 96, min: 8, max: 512, pressureCurve: [0.2, 0.4, 0.6, 0.8, 1] },
    spacing: { ratio: 0.12, minPx: 1 },
    hardness: { base: 0.12, pressureFactor: -0.15 },
    opacity: { base: 0.55, min: 0.08, pressureCurve: [0.08, 0.22, 0.42, 0.68, 1] },
    flow: { base: 0.42, pressureCurve: [0.15, 0.3, 0.5, 0.72, 1] },
    texture: { assetId: 'watercolor-granulation', scale: 0.8, pressureScale: 0.3, rotationJitter: 0.15, roll: 0.15, contrast: 1.1, brightness: -0.02 },
    colorDynamics: { hueJitter: 0.03, saturationJitter: 0.05, valueJitter: 0.06, backgroundMix: 0.25 },
    scatter: { positionJitter: 0.2, angleJitter: 0.3, count: 3 },
    dynamics: { speedSizeFactor: -0.12, speedOpacityFactor: -0.15, tiltSizeFactor: 0.2, tiltOpacityFactor: 0.12, tiltAngleJitter: 0 },
    smoothing: { stabilizer: 0.26, predictionMs: 8 },
    wetness: { enabled: true, spread: 0.6, edgeDarkening: 0.5, drying: 0.35 },
    engine: { strokeMode: 'continuous', blendMode: 'multiply', eraser: false },
    taper: { start: 0.2, end: 0.26 },
  }),
  brush({
    id: 'eraser', name: '橡皮', nameEn: 'Eraser', category: 'basic',
    tags: ['基础', '擦除'],
    // T43：硬橡皮，压感尺寸；T44 引擎 live 用白色 mask + DstOut
    size: { base: 44, min: 2, max: 256, pressureCurve: [0.15, 0.35, 0.6, 0.85, 1] },
    spacing: { ratio: 0.07, minPx: 0.5 },
    hardness: { base: 0.92, pressureFactor: 0 },
    opacity: { base: 1, min: 0.45, pressureCurve: [0.45, 0.62, 0.8, 0.95, 1] },
    flow: { base: 1, pressureCurve: [0.6, 0.8, 0.95, 1, 1] },
    dynamics: { speedSizeFactor: 0, speedOpacityFactor: 0, tiltSizeFactor: 0, tiltOpacityFactor: 0, tiltAngleJitter: 0 },
    smoothing: { stabilizer: 0.18, predictionMs: 0 },
    engine: { strokeMode: 'stamp', blendMode: 'normal', eraser: true },
    taper: { start: 0.06, end: 0.08 },
  }),
  // T62 涂抹笔刷：从当前图层已提交 tile 快照取样，按笔触方向拖动像素（湿边衰减）。
  // 只读 store 快照，不读 live/合成层 → 图层隔离不被破坏；undo 由 engine 的 tile before/after 负责。
  brush({
    id: 'smudge', name: '涂抹', nameEn: 'Smudge', category: 'tool',
    tags: ['工具', '涂抹'],
    size: { base: 64, min: 2, max: 512, pressureCurve: [0.55, 0.75, 0.9, 1, 1] },
    spacing: { ratio: 0.035, minPx: 0.5 },
    hardness: { base: 0.7, pressureFactor: 0 },
    opacity: { base: 1, min: 0.9, pressureCurve: [0.9, 0.95, 1, 1, 1] },
    flow: { base: 0.55, pressureCurve: [0.6, 0.8, 0.9, 1, 1] },
    dynamics: { speedSizeFactor: 0, speedOpacityFactor: 0, tiltSizeFactor: 0, tiltOpacityFactor: 0, tiltAngleJitter: 0 },
    smoothing: { stabilizer: 0.25, predictionMs: 0 },
    engine: { strokeMode: 'smudge', blendMode: 'normal', eraser: false, smudge: true },
    smudge: { enabled: true, strength: 0.65, flow: 0.55, softness: 0.5, drag: 0.45 },
    taper: { start: 0, end: 0 },
  }),
];

const out = {
  schemaVersion: '0.2.0',
  note: 'T43 手感调参版：10 种笔刷默认参数（Procreate 常见观感对标）。曲线 unit：x=[0,.25,.5,.75,1]。新增 texture.roll（纹理滚动）与 tip.followStroke（椭圆笔尖跟随笔画）。',
  units: {
    size: 'px（画布坐标系，直径）',
    angle: 'deg',
    opacityFlow: '0–1',
    curve: 'y 对应 x=[0,0.25,0.5,0.75,1]',
  },
  brushes,
};

fs.writeFileSync(OUT, JSON.stringify(out, null, 2) + '\n', 'utf8');
console.log('written:', path.relative(process.cwd(), OUT).replace(/\\/g, '/'));
console.log('brushes:', brushes.map((b) => `${b.id}(size ${b.size.base}, spacing ${b.spacing.ratio})`).join(', '));
