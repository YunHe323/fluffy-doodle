# 路演 demo 现状审计：现有 demo、AI 面板与可演示资产

> 项目一 · 路演 demo v2 · **t1 交付物**
> 作者：demo-director｜日期：2026-11-07（Asia/Shanghai）｜任务：t1
> 审计对象：当前 v2 产品（`v2/app`、`v2/engine`、`v2/library`、`v2/psd`、`v2/serve.mjs`）
> 证据口径：**代码行号 + 本次实测探针 + 仓库内既有 QA/证据 JSON**；凡属推断标【推断】，**未标者均可由行号或实测数据直接核对**。
> 本次审计**未发起任何付费真实调用**（探针拦截 `POST /api/ai/{chat,image,test}`，实测 0 次外发）。
>
> 与同批文档的分工：本文只做「现在有什么、能不能演、差多远、风险在哪」；Qwen 能力接线与差异化论证见
> [`06-技术/路演demo_多模态能力.md`](路演demo_多模态能力.md)、[`06-技术/路演demo_差异化矩阵.md`](路演demo_差异化矩阵.md)，本文引用但不重复。

---

## 0. 一页结论

| # | 结论 | 证据锚点 | 对 demo v2 的含义 |
|---|---|---|---|
| 1 | **产品本体（画布/图层/选区/变换/证据/PSD/素材库）是真能演的**，且多数有独立 QA 通过记录 | §2.1 表；`test-tools/mask-compare/save-psd/present` 结果全绿 | 舞台地基不用重建，重点在"挑哪些演" |
| 2 | **AI 的"语义内容"在 Mock 下全是模板/渐变占位** | `mock-ai.mjs:103-122`（10 条观察模板 / 6 条方向）、`mock-ai.mjs:274-333`（候选=确定性 SVG 渐变） | 现场必须至少一次真实调用，否则 AI 看起来像"随机文案机" |
| 3 | **素材库里"AI 已读过"是预置档案，不是 AI 读的** | `app.js:4543-4591` `curateSampleAsset` 手写 L1/L2/L4 | 台词必须改口径，否则被追问即穿 |
| 4 | **12 步演示 = 54 秒功能巡检，且不含招牌能力 mask** | `app.js:5178-5193`；实测总时长 54.0s / 自动播放 54.5s；探针 E：演示落层 `masked:false` | 不能"改改 12 步"当路演，必须重写分镜 |
| 5 | **真实 key 就绪时，12 步自动播放会在第 9 步被"真实调用确认"弹窗卡死** | `app.js:2762-2770` 自动开真实 → `app.js:2883-2913` 确认框；探针 A 组实测：第 9/10/11 步全空转 | **最高优先级阻断项**，不修不能上台 |
| 6 | **真实链路延迟 8.7–21.3s（视觉）/ 16–20s（生图）/ 51s（编辑），且无缓存回放** | §5 R2/R3；`serve.mjs:304-312` 只写不读 | 分镜只能"提交→继续讲→回来揭晓"，不能"点完等结果" |
| 7 | **一键演示的收尾画面自相矛盾**（Mock 文案 + 待确认弹窗同屏 + 变换工具条残留） | `index.html:561` 硬编码；实测截图 §5 R1/R13 | 结尾是记忆点，现在是最脆的一帧 |

**一句话**：v2 的**编辑器与证据链已经够上台**；**AI 部分现在是"流程真的、内容假的、延迟长的、切真实会卡"**。demo v2 的工程量主要在"真实度控制 + 节奏编排 + 一个能看的作品"，不在重写产品。

---

## 1. 审计方法与证据口径

### 1.1 代码精读范围

| 文件 | 规模 | 本次关注 |
|---|---|---|
| `v2/app/js/app.js` | 5,697 行 | DEMO_STEPS、AI 面板、对话/行动、落层、证据、素材库、模型接入 |
| `v2/app/index.html` | 47KB | AI 三 tab、演示条/结束卡、按钮入口全集 |
| `v2/app/core/mock-ai.mjs` | 338 行 | Mock 的真实产出形态（文案库 / SVG 占位） |
| `v2/app/core/*.mjs` | — | provider / 证据 schema / chat-actions / editor-ops |
| `v2/serve.mjs` | 685 行 | 本地服务、AI 代理、请求校验、图片下载与缓存、限额 |
| `v2/engine`、`v2/library`、`v2/psd` | — | 分辨率/present 策略、L0–L6、PSD 保真 |

### 1.2 本次实测探针（4 组，均可复现）

| 探针 | 目的 | 关键设置 | 结果文件 |
|---|---|---|---|
| **A/B**（`probe-demo2.mjs`） | 真实 key 就绪时的演示行为 + 纯 Mock 全自动播放计时 | Edge headless（`--use-angle=d3d11`），1920×1080；A=空 profile，B=预置 `mozheng.ai.settings.v1` 且 `allowReal:false` | `%TEMP%\inkproof-audit\probe-demo2.json` |
| **C**（`probe-demo3.mjs`） | 12 步演示是否真的走 mask；再用手动框选复现 mask 并测框外像素差 | 同上；只走 Mock | 同上目录 `probe-demo3.json` |
| **D**（`probe-demo.mjs`） | 逐步 DOM 状态、Mock 候选像素统计、证据包耗时、网络外发检查 | 同上 | 同上目录 `probe-demo.json` |
| **E**（`probe-demo5.mjs`） | 把结论精确到步序（0-based index）：第 8 步的选区真伪、第 11 步的 L6 参数 | 同上 | 同上目录 `probe-demo5.json` |

服务端用仓库自带 `v2/serve.mjs`（本次复用已在 4200 端口运行的实例；`GET /v2/app/index.html` → 200）。

### 1.3 引用的既有证据（并核对时效）

| 证据文件 | 时间 | 结论 | 备注 |
|---|---|---|---|
| `v2/app/test-demo-result.json` | 2026-11-07 | 12 步全 PASS、总时长 54,000ms、三档分辨率无溢出 | 与本次实测一致 |
| `v2/app/test-mask-compare-result.json` | — | `outsideDiff:0`、`masked:true`、`selection_alpha`、落层后 `transformActive:true` | mask 能力的最强证据 |
| `v2/app/test-save-psd-result.json` | — | 保存 12,473B / PSD 200,898B（头 `8BPS`）/ 0 long task | 专业交付可演 |
| `v2/psd/results/fidelity.md` | 2026-11-06 | 6 样本、结构 100%、像素 100% | 但样本是**结构模拟**，非真实 Procreate 导出 |
| `v2/qa/tools/qwen-real-e2e-results.json` | 2026-11-07 | 视觉 21,288ms / 1,271 tokens / 证据 12 项校验全过 | 单次样本 |
| `v2/app/test-qwen-real-result.json` | 2026-11-07 05:24Z | analyze 8,730ms → directions 6,640ms → generate 20,090ms；3 次真实调用合计 35,425ms | 与 21.3s 同链路差异 2.4×，见 R2 |
| `v2/qa/tools/qwen-image-edit-app-results.json` | 2026-11-07 | 编辑 51,113ms、2,416×1,728、6.6MB | 只能异步 |
| `v2/qa/tools/asset-real-read-results.json` | 2026-11-07 | 素材真实重读 22,225ms、L2=5 / L4=4 | 单张 |
| `v2/qa/tools/qwen-chat-real-results.json` | 2026-11-07 | 对话 2,689ms，回答确实描述"当前选区是一片纯黑" | 真实接地感最好的入口 |
| `v2/qa/tools/T117-mask-qa-result.json` | **2026-11-07T15:09Z（最新）** | **48 项检查 33 过 15 败**；4096² mask 写入 11,420/13,518ms、e2e 23,253ms、最长 longtask 16,904ms | 与 `路演demo_差异化矩阵.md:397-398` 记的"7.3–9.7s / 14.7s / 18 项"不是同一次 run，以本文件为准 |

> **口径诚实**：真实调用全部是单次样本，不构成 P50/P95；本次审计没有复跑真实链路（避免付费）。

---

## 2. ① 能力三分类：能演 / 只在 Mock 成立 / 没露出

### 2.1 可现场演示且稳定（有独立 QA 证据）

| 能力 | 入口 | 代码/证据 | 现场稳定度 |
|---|---|---|---|
| 画笔 / 模拟压感 / 橡皮 / 涂抹 / 撤销重做 | 顶栏工具 | `app.js:1180-1247`；`test-tools-result.json`（含选区约束、结构 undo）全绿 | 高 |
| 矩形/椭圆/套索/魔棒选区 | 选择工具 | `app.js:1429-1516`；探针 C 手动框选得到 `engineHasSelection:true` | 高 |
| 变换框（拖/缩/旋、Enter 提交） | 落层后自动进入 | `app.js:1577-1679`；`test-mask-compare` `transformActive:true` | 高 |
| 图层/组/蒙版/剪贴/16 混合模式 | 右侧图层面板 | `app.js:1735-2041` | 高 |
| 非破坏调整层（参数可重开） | 更多 → 图像调整 | `app.js:2495-2597`；`test-adjust-layer-result.json` | 高（**边界用例有坑，见 R7**） |
| 结构化文字（双层、可二次编辑） | T 工具 | `app.js:391-475`；`test-text-edit-result.json`（`kind:'text'`、undo/redo 同步） | 高 |
| 画布 resize / 裁剪 | 更多 → 画布尺寸 | `app.js:2520-2562`；`test-canvas-resize-result.json` | 高（历史会清空，UI 已提示） |
| 网格/三分线/自定义参考线/对称/吸附 | 更多 → 视图 | `app.js:1265-1342`、`guides.mjs`；`test-guides/test-symmetry` | 高 |
| `.mozheng` 保存/加载/自动保存 | 更多 → 项目 | `app.js:2098-2224`；`test-save-psd-result.json`（12,473B、往返像素 ±1） | 高 |
| PSD 导入/导出 | 更多 → 文件 | `app.js:2263-2400`；`psd/results/fidelity.md` 6/6 样本 100% | 高（**仅 8-bit RGB 栅格，文字/智能对象不可编辑**） |
| 证据包（哈希链 + 图层 sha + AI 清单 + 画布 PNG） | 更多 → 导出证据包 | `app.js:4140-4197`；探针 D：**12 事件 / 3 图层 / 443KB / 149ms** | 很高（近乎无延迟，适合现场） |
| 第三方校验脚本 | `v2/qa/tools/verify-evidence*.mjs` | `verify-evidence-test-results.json` | 高（可用于"篡改即失败"桥段） |
| 素材库 CRUD / 搜索 / 标签 / 色板 / 区域定位 | 左侧素材库 | `app.js:4592-4930`；`test-library-result.json` 18 项全绿 | 高 |
| 批量重读 review 闭环（采用/保留 Mock/重试/停止） | 素材库 → AI 批量重读 | `app.js:5000-5117`；`test-asset-batch-result.json` | 高（**Mock 批量**稳定；真实批量未测，见 R9） |
| 自由对话 + 长期记忆 + 画像 | AI 面板底部 | `app.js:3467-3633`；`test-ai-panel-v3-result.json`（6 条历史/画像持久化） | 高 |
| 对话 → 行动建议 chips（只预填，不自动执行） | AI 回复下方 | `app.js:3425-3466`、`core/chat-actions.mjs`；`test-chat-actions-result.json` | 高 |
| 模型接入 / Mock 兜底 / 密钥不进前端 | 顶栏徽章 → 模型 | `app.js:2655-3093`；`test-ai-provider`、T117 `H4` 无明文密钥 | 高 |
| PSD/PNG/JSON 导出、无外部网络（Mock） | 更多 → 导出 | 探针 D：`networkExternal: []`、`network_requests:0` | 高 |

### 2.2 只在 Mock 下成立（内容层面"看着像 AI"）

| 表面现象 | 真实情况 | 代码证据 | 现场后果 |
|---|---|---|---|
| "AI 观察"给出 2–4 条像模像样的判断 | 从 **10 条固定模板**里按种子挑，锚点来自随机 bbox；同一输入必然得到同一批句子 | `mock-ai.mjs:9-10`（确定性声明）、`103-114`、`166-185` | 连点两次会看到同一批句子；评委追问"它看到什么"会露 |
| "AI 方向"给出 2–3 个方向 | **6 条固定方向**（`DIRECTION_BANK`） | `mock-ai.mjs:115-122`、`234-253` | 和画面内容无关，却写"依据 L1.palette" |
| "AI 局部方案"候选图 | **确定性 SVG 渐变 + 圆 + 虚线框**，778 字节 | `mock-ai.mjs:274-333`；探针 D 实测 `bytes:778, distinctColors:24` | 落到画布上是一块**绿色/紫色渐变色块**（实测截图见 R4） |
| 素材库"AI 已读 · 3 区域 · 3 观察" | `curateSampleAsset` **手写** L1/L2/L4 | `app.js:4543-4591` | 这是"预置档案"，不是 AI 读出来的 |
| 对话回答"按你的风格给建议…" | 模板句 + 输入摘要（选区尺寸/素材数/画像关键词） | `test-ai-panel-v3-result.json` `chat.last`；`mock-ai.mjs` | 能圆场，但撑不住"它真理解我的画"这个高点 |
| 语音输入 | 浏览器 `SpeechRecognition` | `app.js:3634-3654` | 【推断】国内现场大概率失败（Chrome 的实现依赖境外服务；见 R11） |

> 注意区分：**流程、记录、证据链在 Mock 下是真的成立的**（L1/L2/L4/L5/L6 都真实写入、哈希链真实计算）；**不成立的只有"AI 语义内容"**。这条边界必须写进台词规范。

### 2.3 AI 面板现状（观察 / 生成 / 记录 三主入口）

| 区域 | 内容 | 代码 |
|---|---|---|
| **观察**（默认 tab） | 上下文条（模型/模式/范围/成本/实时层）→ 五步进度（选区/观察/方向/候选/落层）→ 意图输入 → 观察卡（确认/否决/定位）→ 方向卡 → 候选卡（落层/画布预览/对比原图）→ 会话日志 → 对话（长期记忆 + 画像 + 上下文 chips + 行动 chips） | `index.html:315`；`app.js:3714-3820`、`3467-3633` |
| **生成** | 图像工作台：prompt + 输入范围（选区/整张画布/当前图层）+ 素材参考（≤3 张）+ 生成 2 张 / 按描述改这张图 + 结果卡（落层/预览/存回素材库） | `index.html:316`；`app.js:3870-3917`、`3964-4015` |
| **记录** | 子页：档案（L1/L2/L4/L5/L6 列表）/ 证据（事件、链头、AI 调用清单） | `index.html:317`、`325-335`；`app.js:3860-3869`、`4102-4138`、`4079-4095` |
| **模型**（隐藏 tab，入口=顶栏 provider 徽章） | 提供商预设、baseUrl/model、允许真实/需确认/隐私模式、Key 状态、连通测试 | `index.html:318`；`app.js:4026-4078`、`2746-2824` |
| **固定上下文条**（`#aiPinnedStatus`） | 模型 · 真实/Mock · 选区尺寸 · 素材库/引用/档案数 · 成本口径 · 最近延迟 | `app.js:3823-3838` |
| 底部状态栏 | 当前层 · 工具 · 模型 · 协作/存证 | `app.js:3839-3847` |

> 面板里**唯一常驻的"真伪标识"就是 pinned 条的"真实/Mock"**（`app.js:3834`）与成本口径（`app.js:3837`）；路演如需 A/B/C/D 四级真实度，这里是最自然的落点。

### 2.4 demo 没露出（能力有，12 步里看不到）

| 能力 | 为什么值得露 | 现状 | 证据 |
|---|---|---|---|
| **选区 mask 局部落层**（招牌） | 差异化最强的"框外一个像素不动" | 12 步第 8 步只画了一个 overlay 矩形，**没有建立真实选区**；落层 `masked:false / mask_policy:'none'` | 探针 E：index 7（第 8 步）`engineHasSelection:false`；index 10（第 11 步）`masked:false`、`mask_policy:"none"` |
| 候选原位预览 / 对比滑杆 | "AI 不直接改原画"最直观的一屏 | 演示里直接 `applyCandidate(0)`，跳过预览与对比 | `app.js:3277-3293`、`3320-3338`；演示 `app.js:5189` |
| 落层后变换（拖动/缩放/旋转） | "生成物是可继续编辑的图层"的证明 | 演示直接进第 12 步证据包 | `app.js:3339-3376`（`enterImageTransformUI`） |
| 非破坏调整层 | "可继续改"的第二层证据 | 未出现 | `app.js:2495-2597` |
| 结构化文字二次编辑 | 专业创作者刚需 | 未出现 | `test-text-edit-result.json` |
| PSD 导入/导出 | 打进专业工作流 | 未出现 | `test-save-psd-result.json`；`psd/results/fidelity.md` |
| 素材批量重读 review（采用/保留/重试） | "AI 的主张可被否决" | 未出现 | `app.js:5000-5117` |
| **存证模式（attest / zero_generation）** | "能证明没用 AI"——最反直觉的一击 | 未出现；演示停在 `mode:collab`、`zero_generation:false` | 探针 D `evidence.attest`；`app.js:4279-4305` |
| 图像工作台"按描述改这张图"（编辑） | 51s 慢，但 2K 成品最惊艳 | 未出现 | `app.js:3964-4015`；`qwen-image-edit-app-results.json` |
| 素材真实读（图文并茂重读） | 把"AI 真看了"落到像素 | 演示只用预置档案 | `asset-real-read-results.json`（22.2s） |
| 素材引用进生成（最多 3 张） | "记得你的素材" | 演示**只被动带上 1 张**（第 7 步 `insertAssetLayer` 顺带写了 `state.aiReference`），从未演示"选 3 张 + 引用栏确认 + 参考进生成" | `app.js:4880`（插入即写引用）、`app.js:3918-3929`（多选）、`generate` payload `app.js:3254` |
| AI 画布标注层 / 观察定位 / 手绘标注 | "AI 指着画说话" | 未出现 | `app.js:3655-3713`、`test-multimodal-result.json` |
| 画布 resize / 参考线 / 对称 | 专业习惯 | 未出现 | `test-canvas-resize-result.json`、`test-guides-result.json` |

---

## 3. ② 现有 12 步演示与"路演级展示"的差距（教学 vs 展示）

### 3.1 12 步清单与实测事实

| 步 | 标题 | 屏幕上的实际动作 | 真实度 | 实测事实（探针 D/E） |
|---|---|---|---|---|
| 1 | 打开示例作品 | `wipeCanvas` + **画 3 笔**（3 个 brush preset，模拟压感） | 本地真实 | 画布 1200×800；**"示例作品"就是三条笔画**（`app.js:5194-5217`） |
| 2 | 打开素材库 | 打开 sheet，首次自动建 3 张示例素材 | 本地真实（**档案是预置**） | 建档 579ms；3 张：水彩纸/人物线稿/雾中山谷 |
| 3 | 选一张素材 | 选中"雾中山谷-示例.jpg" | 同上 | — |
| 4 | AI 读懂整体 | 显示 L1 摘要/主体/情绪/色板 | **预置文本** | `curateSampleAsset` 手写 |
| 5 | AI 读懂区域 | 高亮 3 个 L2 区域框 | **预置** | 同上 |
| 6 | 确认一条观察 | 真写 L5 决策（`api.confirm`） | 本地真实 | 库计数 +1，档案回写 |
| 7 | 插入为图层 | 素材成为独立图层 | 本地真实 | 图层 1→2 |
| 8 | 框选卡住的地方 | `state.selection={620,160,420,320}` + 画 overlay | **假选区** | index 7：`engineHasSelection:false`、`selManagerHas:false` |
| 9 | 让 AI 看看 | `runAnalyze`（Mock） | **模板文案** | 观察 2 条；Mock latency 0ms |
| 10 | 确认观察 + 选方向 | `confirmObservation` + `runDirections`（Mock） | **模板方向** | 方向 2 条；同链路 Mock 5ms（探针 C） |
| 11 | 方案落为新图层 | `runGenerate` + `applyCandidate(0)` | **SVG 渐变占位** | 2 候选；落层 248ms；index 10：`masked:false`、`mask_policy:"none"`；**画布上出现一块绿色渐变** |
| 12 | 导出证据包 | 打开 `archiveModal` + `openEvidence` | 本地真实 | 149ms / 12 事件 / 443KB |

- 机制：`DEMO_STEPS`（`app.js:5178-5191`）、步长 `4400 + (文案≥40字 ? 400 : 0)`（`app.js:5192-5193`）→ 理论 54,000ms，**实测自动播放 54,481ms**。
- 演示基础设施（**可复用**）：聚光灯 `positionSpotlight`（`app.js:5341-5358`）、`demoScrim` 点击接管、`pauseDemo/endDemo/takeoverDemo/exitDemo`（`app.js:5266-5340`）、暂停时 `engine.pauseHistory()`（`app.js:5230`）、退出恢复快照与记录。

### 3.2 差距表（教学 → 展示）

| 维度 | 现在（教学型） | 路演级要求（8–10 分钟） | 差距 | 处置 |
|---|---|---|---|---|
| **时长** | 54s 全自动 | 480–600s | **差 9–11 倍**；一段表演就要 12 步的全部长度 | 重写分镜：12 步降级为"工具箱"备查，不作为主脚本 |
| **结构** | 功能巡检（打开→看→确认→插入→框→观察→方向→生成→证据） | 单主角、单冲突、单逆转的一条故事线 | 现在是"产品说明书"，不是"人的故事" | 需要一个真实作品 × 一个真实卡点 |
| **叙事主体** | 系统自述（"这一步在做什么"） | 创作者的第一人称困境与决定 | 旁白在解释 UI，不在讲人 | 重写台词：拆成"人物/冲突/证据"三幕 |
| **画面质量** | 空白画布 + 3 笔画 + 程序化山谷 + 渐变块 | 一进场就是能压住全场的作品 | **最大的观感硬伤**（见 R4） | 必须换"路演级作品"（见 §4 缺口） |
| **AI 真实度** | 100% Mock（模板 + 渐变） | 至少 1 次真实、可举证 | 现在被问"它真看了吗"答不上 | 引入 A/B/C/D 四级真实度（同批文档已定），现场至少 1 次 A 级 |
| **证据用法** | 打开证据面板就结束 | 现场校验 → 改 1 字符 → 失败 | 最有说服力的一击没做 | 接 `verify-evidence.mjs` 做"篡改即红" |
| **节奏** | 每步 4.4s 匀速、自动跳 | 有快慢、有停顿、有"等待即叙事" | 匀速 = 无高潮 | 分镜给"等待段"配台词（21s 视觉/20s 生图/51s 编辑） |
| **控制权** | 自动播放 + 遮罩，靠"接管"退出 | 主持人手里要有"随时停/随时切" | 自动播放与真实调用确认**互斥**（R1） | 演示必须改"手动驱动 + 一键兜底" |
| **复现性** | 依赖 localStorage 状态（见 R8） | 同一台机器两次演完全一致 | 无 demo 模式开关 | 增加"路演模式"引导（§7 决策点） |

### 3.3 可留用的部分（不要推倒重来）

1. **步骤卡 + 聚光灯骨架**：`#demoNarr`（`index.html:530-539`）+ `positionSpotlight`，改成"分镜卡"可直接用。
2. **暂停/接管/退出恢复**：`pauseDemo/takeoverDemo/exitDemo` 已处理历史暂停与快照恢复，现场兜底靠它。
3. **结尾"接管画布"**：`endDemo` → `btnDemoEndTry`（`app.js:5437`）是很好的收束动作，只是文案与内容要换。
4. **步骤时长可配**：`demoStepDuration` 已是函数，可改成数据驱动（每步自定义秒数）。

---

## 4. ③ 可复用的演示资产

| 资产 | 位置 | 现状 | 路演可用性 | 需要的加工 |
|---|---|---|---|---|
| 程序化示例画作 ×3 | `app.js:4405-4531`（`sampleArtA/B/C`，Canvas 2D 绘制） | 可用；A=雾中山谷 1600×1200、B=人物线稿 1200×1600、C=水彩纸 1600×1200 | 中：像"设计素材"，不像"创作者作品" | 只做**兜底素材**；主作品必须另备 |
| 预置素材档案（L1/L2/L4） | `app.js:4543-4591` | 手写 3 套（山谷/线稿/水彩纸），各有 3 区域 + 2–3 观察 | 高（流程演示够用） | 文案升级；台词标注"预置档案" |
| **真实 Qwen 生成图缓存** | `%TEMP%\mozheng-ai-images\`（12 个文件；其中 2 个是 68/70 字节的坏图，**可用 10 张**，1.0–6.6MB；如 `b8790a18….png` 6.6MB = 编辑 2K 成品） | 真实调用产物，带 sha256 文件名 | **很高**：现成的"B 级预置样本" | ①搬进仓库受控目录；②补 `request_id/model/at` 元数据；③**做成可回放**（当前只写不读，见 R3） |
| 真实调用证据 JSON | `v2/qa/tools/qwen-real-e2e-results.json`、`qwen-real-evidence.json`、`qwen-image-edit-app-results.json`、`asset-real-read-results.json`、`qwen-chat-real-results.json` | 完整（latency/usage/requestId/sha256） | 高：可做"数据卡"背板 | 摘成 1 页"真实调用台账" |
| 三档分辨率 UI 截图 | `v2/app/ui-*.png`（100+ 张，1366/1536/1920） | 全绿 | 高：备用录屏/PPT | 挑 8–12 张做"过程墙" |
| PSD 样本 + 保真报告 | `v2/psd/results/samples/*.psd`（6 组 source/roundtrip）、`fidelity.md` | 6/6 100% | 高 | 加一份**真实 Procreate/PS 导出**样本（当前是结构模拟） |
| L0–L6 档案 schema | `v2/library/library-schema.mjs:1-174`、`06-技术/数据模型_schema.json` | L0/L1/L2/L4/L5 已实现；**L3（跨素材关系）只有枚举定义**（`core/archive-schema.mjs:10`），无任何写入/消费代码 | 高：讲"档案结构"时要避开 L3 | 出一张一页图；台词不要承诺"跨素材关系推理" |
| 第三方校验脚本 | `v2/qa/tools/verify-evidence.mjs`、`-integration.mjs` | 可用 | **很高**：现场"篡改即失败" | 包成一条命令/一个 bat |
| 自动化测试与演示脚本 | `v2/app/test-demo.mjs`、`v2/qa/tools/harness.mjs`、`T117-mask-qa.mjs` | 可用（Playwright + msedge headless） | 高：可做"演出前自检" | 收敛成一个 `preflight` 脚本 |
| **缺口 1：路演级作品** | — | **不存在** | — | 需要 1 张真实插画（带未完成区）作为主角；建议由创作者提供并授权 |
| **缺口 2：缓存回放能力** | — | 服务端只写缓存不读（`serve.mjs:304-312`） | — | 加 `image cache hit` 分支，命中时 `latency≈0` 且证据记 `cached_sample` |
| **缺口 3：分镜/台词资产** | — | 只有 12 步的说明文案 | — | 本文 §5 的 8 个瞬间 → 拆成 8–10 分钟台词 |

---

## 5. ④ 候选"路演必须露出的 8 个瞬间"

> 选型标准：①**只有我们能做**（差异）②**屏幕上一眼能看懂**（无需解释）③**有可量化证据**（不怕追问）④**现场可失败可降级**。
> 与 [`路演demo_差异化矩阵.md`](路演demo_差异化矩阵.md) §7.1 的 M1–M3 对齐：M1 在这里拆成 S1/S3/S4 三个瞬间，M2→S5，M3→S6/S7。

| # | 瞬间 | 一句话台词 | 现场动作 | 屏幕证据 | 用时 | 真实度策略 | 失败降级 |
|---|---|---|---|---|---|---|---|
| **S1** | **它读得懂这块** | "我不告诉它这是什么，它得自己看出来" | 框选一块"卡住"的区域 → 让 AI 看看 | 观察 2–3 条 + **bbox 在画布上圈出来**；面板显示 provider/model/延迟 | 15–25s | **A 级真实**（`qwen-real-e2e` 21.3s；调优到 ≤8s 更佳） | 切 B 预置（同选区）并显示"预置样本" |
| **S2** | **它说得清我为什么卡** | "它没夸我，它指出这里平" | 追问一句"这里为什么显得平？" | 对话气泡 2.7s 返回、回答里带具体区域与明度判断 | 8–12s | **A 级真实**（`qwen-chat-real` 2,689ms） | 输入框旁给 Mock 标注 |
| **S3** | **它只在我框的地方动手** | "框外一个像素都不许动" | 复制一块 → 生成 → **对比滑杆**拉来回 | `outsideDiff=0`（可现场跑像素比对脚本） | 20–40s | A 级真实生图（20.1s）或 B 级缓存 | 落 Mock 但**必须标 Mock**；不建议演 |
| **S4** | **结果是一层，不是一张图** | "这不是贴图，是一层" | 落新图层 → 拖动/缩放 → Enter → Ctrl+Z | 图层面板计数 +1；变换框；`transformActive:true`；Ctrl+Z 一步回退（`test-qwen-real` `undo.delta:-1`） | 15–20s | 本地真实（不依赖模型） | 无（纯本地，最稳） |
| **S5** | **它记得我做过的决定** | "它记得的不是我的风格，是我的选择" | 素材库 → 确认一条观察 → 回画布提问 → AI 回指 | L5 决策 +1；对话上下文条显示"素材/档案/画像"；payload 可展开 | 25–30s | 本地真实（档案）+ 可选 A 级真实重读（22.2s） | 预置档案先撑住，真实读失败标 Mock |
| **S6** | **所有事都能被复核** | "这不是我说的，是链说的" | 导出证据包 → **改 1 个字符** → 校验失败 | 12 事件 / 链头哈希 / 图层 sha / AI 调用 real vs mock；`verify` 由 ok:true → false | 20–25s | 本地真实（149ms，零风险） | 无（最稳的一段） |
| **S7** | **它也能证明"我没用 AI"** | "这一张，AI 一个像素都没碰" | 切存证模式 → 导出 → 看 `zero_generation:true` | 模式徽章切换；证据 `attest.zero_generation` 翻转 | 10–15s | 本地真实 | 无 |
| **S8** | **成品能出这个门** | "它今天是工具，不是玩具" | 导出 PSD → 打开 → 图层结构完整 | `8BPS` 文件 / 6 样本 100% 保真表 / 图层名与蒙版 | 15–20s | 本地真实 | 只演已验证样本 |

**合计**：8 个瞬间 ≈ 130–190s 的"事实密度"，其余 5–7 分钟由**故事、等待段讲解、Q&A 缓冲、备选（B1 模型无关 / B2 PSD 往返）**填满。

**依赖前置修复（不做则对应瞬间不能按 A 级演）**：

| 瞬间 | 前置依赖 | 来源 |
|---|---|---|
| S1 | **bbox 坐标系契约**：`locateObservation`/`renderAiCanvasOverlay` 把观察的 `anchor.value` 直接当画布坐标用（`app.js:3655-3663`、`3664-3706`），而 analyze 只发选区裁切图（`app.js:3108`）——真实模型返回的坐标口径没有约定，可能"指错地方" | 本次核对；同文档 §0-4、§3.2 |
| S1/S2 | **流式输出**：结构化分析固定 `stream:false`（`ai-provider.mjs:303`）、对话也固定 `stream:false`（`ai-provider.mjs:360`），8–21s 空等无法变成"AI 在想" | 同文档 §0-1 |
| S1 | 观察结果 ≤ 8s：需要缩短裁切边长 / 精简 schema / 关思考 | `app.js:2845`（1568）、同文档 §4.2 |
| S3 | **缓存回放**（否则每次都 20s 且计费） | `serve.mjs:304-312`（只写不读） |
| S3 | 生图输出面积 ≤1024²（上游本可 2K，被本地校验钉死） | `serve.mjs:274` |
| S7/S8 | 无（纯本地） | — |

**建议的主线顺序**（叙事因果）：S1 → S2 → S3 → S4（"我卡住了 → 它看懂 → 它只在框里动手 → 结果成了我的图层"），中段插入 S5（"因为它记得我"），收尾 S6 → S7 → S8（"每一步都可举证 → 甚至能证明我没用它 → 成品能交付"）。

**明确不建议上舞台的**（与差异化矩阵 §7.3 一致，本次审计追加证据）：4096² + mask（T117 实测 11.4–13.5s 写入、e2e 23.3s、longtask 16.9s）、调整层"仅作用选区"的边界用例（T117 15 项失败未收口）、真实批量重读、复杂 PSD 可编辑、**以及任何 Mock 候选落层画面**。

---

## 6. ⑤ 风险清单（延迟 / 成本 / 失败 / 分辨率 / 浏览器）

等级：**阻断**=不解决不能上台；**高**=现场会翻车；**中**=影响观感/可信度；**低**=可接受。

| ID | 风险 | 触发条件 | 实测/代码证据 | 等级 | 现场缓解 |
|---|---|---|---|---|---|
| **R1** | **真实调用确认弹窗与演示自动播放互斥**——第 9 步弹"真实模型发送确认"，9/10/11 步全部空转，画面停在弹窗上但演示仍宣报"完成" | 机器上服务端配了真实 key，且浏览器 localStorage **没有**已保存的 AI 偏好 | `app.js:2762-2770`（无偏好即 `allowReal=true`）→ `app.js:2883-2913`（弹确认）→ `aiRealEligible()` true（`app.js:2687-2690`）。探针 A 组：`confirm:true` 自第 9 步起持续，`obs/dir/cand=0`，54.3s 到"演示完成" | **阻断** | 演示前写入 `mozheng.ai.settings.v1` 且 `allowReal:false`；或加"路演模式"把真实调用改成显式手动触发 |
| **R2** | **真实链路延迟与波动**：视觉 8.7s→21.3s（同一代码两次实测差 2.4×）、生图 16.4–20.1s、编辑 51.1s | 现场网络正常但上游排队 | `qwen-real-e2e-results.json`（`:24` `ms:21337`；内层 `latencyMs:21288`）；`test-qwen-real-result.json` analyze 8,730ms / generate 20,090ms；`qwen-image-edit-app-results.json` 编辑 51,113ms | 高 | 只演 1 次视觉 + 1 次生图；编辑走"提交→继续讲→回来揭晓"；所有等待段预写台词 |
| **R3** | **没有缓存回放**：服务端把真实图写到 `%TEMP%\mozheng-ai-images`，但**只写不读**，每次都重新提交并计费 | 想"预生成一次、现场秒出" | `serve.mjs:304-312`（写文件 + 返回 dataURL，无命中分支）；`serve.mjs:424-503` 全路径都在调上游 | 高 | 要么加缓存命中分支，要么用前端"预置样本"注入（B 级） |
| **R4** | **Mock 候选视觉灾难**：SVG 渐变块落到画布上 | 任何在 Mock 下点"落为新图层" | `mock-ai.mjs:274-333`；探针 D：778B、24 色；本次实测截图（`%TEMP%\inkproof-audit\shots\step-11.png`，未入库）：画布上出现绿紫渐变矩形 | 高（观感） | **禁止**在台上落 Mock 候选；Mock 只演"观察/对话/证据" |
| **R5** | **素材库"AI 已读"是预置**，被追问即穿 | 主持人说"AI 已经读过这些素材" | `app.js:4543-4591` 手写 L1/L2/L4 | 中高 | 改口径："这是**已建档**的素材"；或现场点一次真实读（22.2s，标 A 级） |
| **R6** | **演示不含 mask**：招牌能力没露，且演示落层是矩形贴图 | 直接用 12 步 | 探针 E：index 7（第 8 步）`engineHasSelection:false`；index 10（第 11 步）`masked:false`、`mask_policy:"none"` | 高（与差异化冲突） | 分镜里单独设计 S3，用**手动框选**（实测 `masked:true`、`outsideChangedPixels:0`） |
| **R7** | **T117 调整层蒙版 QA 未收口**：48 检查 33 过 **15 败**（取消勾选 mask 残留、undo/redo mask 不恢复、像素回滚不完全）；4096² mask 写入 11.4–13.5s | 演"调整层仅作用选区"或大图 | `T117-mask-qa-result.json`：`pass:false`；`D1/D2/D3/D4`、`E-u2..E-c6`、`G2/G3` 失败 | 高（若演） | 不演该边界用例；`START_HERE.md:100-108` 的"已知限制"需补这一条 |
| **R8** | **现场机器状态不可复现**：是否 Mock、素材库是否为空、演示前画布内容，都取决于 localStorage / IndexedDB | 换机器、清缓存、换浏览器 profile | `app.js:221-232`（本地恢复）、`app.js:2763-2770`（偏好判断）；探针 A/B 两组同机不同 profile 结果完全不同 | 高 | 演出机固定 profile + 预检脚本；或加 `?demo=1` 一次性设定 |
| **R9** | **真实批量重读未验证**：批量 UI 只在 Mock 批量下测过；真实单张 22.2s，串行 10 张 ≈ 4 分钟且计费 | 演"AI 批量读我的库" | `test-asset-batch-result.json`（Mock）；`asset-real-read-results.json`（22,225ms/张）；`serve.mjs:70` `perMinute:10` | 中高 | 只演单张真实 + Mock 批量；不演"10 张一起读" |
| **R10** | **分辨率口径混乱**：默认画布 1200×800；生图裁切上限 1024、分析 1568；>2048² 切 `full` 呈现；4096² mask 极慢 | 换大画布/作品尺寸大 | `app.js:2844-2857`；`test-present-result.json`（limit 4,194,304px）；T117 `G2/G3` | 中 | 路演作品固定 ≤2048²；主持人不要说"支持 4K" |
| **R11** | **浏览器/语音**：引擎依赖 CanvasKit（WebGL2/WASM），只在 Edge/Chrome 验证；语音是浏览器 Web Speech（【推断】国内大概率不可用） | 现场用 Safari/旧版浏览器；演语音 | `index.html` 引 `v2/engine/vendor/canvaskit.js`；`app.js:3634`；`test-demo` 三档分辨率仅在 msedge headless 验证 | 中 | 固定 Edge/Chrome + 预演；语音不进主链路 |
| **R12** | **成本口径与护栏**：`limits.perMinute:10` 只有定义、没有本地计数/拒绝；单场真实预算约 **¥1.5**（视觉 ¥0.035 + 生图 2 张 ¥0.36 + 编辑 2K ¥0.52 + 对话/语音 <¥0.1），无硬上限 | 连点重试、反复生成 | `serve.mjs:70`（仅赋值）；全文件 grep `perMinute` 仅命中定义与上游 429 文案映射（`:206`）；单张价见 `app.js:3363`（¥0.18/张口径）与 `路演demo_多模态能力.md` §4.4 | 中 | 台词侧"每张约 ¥0.18"；现场最多 3 次真实调用；如要硬护栏需实现 |
| **R15** | **失败路径**：失败会写 L6 `status=error` 并可读，但**演示没有"回退到上一步"的编排**（只能靠 Mock 重跑） | 上游超时/429/坏图 | 失败不计费：`serve.mjs:573/579/589/595/609` 均返回 `billed:false`；前端记录 `app.js:3162`；Mock 兜底 `serve.mjs:400-403`（对话）、`:563-569`（图片） | 中 | 预先写好"失败→切 Mock→继续"的口播；演练一次断网 |
| **R13** | **结束卡文案硬编码"AI 为本地 Mock · 无网络请求"** | 真实模式下结束 | `index.html:561`；探针 A 组截图（`%TEMP%\inkproof-audit\shots\A-after-autoplay.png`）：待确认弹窗 + "演示完成 12/12" + 该行文案同屏 | 中高（可信度） | 改成按实际 provider/网络请求渲染；否则真实模式自相矛盾 |
| **R14** | **收尾帧的视觉残留**：变换/形状选项条覆盖画布顶部；证据面板滚动位置停在"事件 12"；结束卡压在弹窗之上 | 走完 12 步 | 仓库内 `v2/app/ui-demo-end-1920.png`（结束帧）+ 本次探针截图 `step-11.png` / `A-after-autoplay.png` | 中 | 收尾前 `Escape` 清工具态；结束卡 z-index 与滚动位置修正 |

---

## 7. 结论与给 captain 的决策点

1. **demo v2 不是"改进 12 步"，而是"新写一条 8–10 分钟主线"**。12 步保留为"功能备查/自检"，不进入舞台主脚本。
2. **上台前必须清的两个阻断项**：R1（真实调用确认弹窗卡死自动播放）、R8（现场状态不可复现）。两者都属于"演示模式"工程，改动小、收益最大。
3. **至少 3 个瞬间必须是 A 级真实**（S1 观察 / S2 对话 / S3 生图）。否则"AI 真读了"这句台词不成立；Mock 只允许出现在 S6/S7 这类**不依赖模型质量**的证据段。
4. **需要一个"路演级作品"资产**（真实插画 + 一处真实未完成区）。这是当前最大缺口——现有"示例作品"是 3 条笔画（`app.js:5194-5217`），素材库是程序化画布（`app.js:4405-4531`）。
5. **需要"缓存回放"能力**（R3）。把已有的 10 张可用真实产物变成可秒出的 B 级预置样本，是"低风险高观感"的唯一路径；不做，就只能接受 20–51s 的现场空等。

---

## 附录 A：探针复现与原始结果

### A.1 环境

- Node v24.21.0 / Windows 10-11 / Edge（`channel:'msedge'`, headless, `--enable-gpu --use-angle=d3d11 --ignore-gpu-blocklist`）
- 服务：仓库自带 `v2/serve.mjs`（本次实例 4200 端口，`/v2/app/index.html` 200）
- Playwright：`v2/qa/node_modules/playwright-core`（仓库内自带，无需安装）

### A.2 关键探针片段（探针 E：把结论钉到步序）

```js
// 步序为 0-based：index 7 = 第 8 步「框选」；index 10 = 第 11 步「落层」
await page.click('#btnDemo'); await page.waitForTimeout(400);
for (let i = 0; i < 7; i++) { await page.click('#btnDemoNext'); await page.waitForTimeout(900); }
const atStep7 = await page.evaluate(() => {
  const A = window.__V2_APP__;
  return { stepIndex: A.t82.state().step, stateSelection: A.state.selection,
           engineHasSelection: A.engine.hasSelection(), selManagerHas: !!A.t64.selectionManager.hasSelection };
});
// => { stepIndex: 7, stateSelection: {620,160,420,320}, engineHasSelection: false, selManagerHas: false }
// 再连点 3 次到 index 10，读 L6：masked:false / mask_policy:"none"
// 对照：鼠标手动框选后（探针 C）engineHasSelection:true，落层 masked:true / selection_alpha，框外 diff=0
```

### A.3 原始结果（摘录）

| 键 | 值 |
|---|---|
| `bootMs` | 833（headless，Mock） |
| `engine` | `{width:1200, height:800, layers:2, presentStrategy:"dirty"}` |
| `sampleLibraryMs` | `{ms:579, count:3}` |
| 12 步理论总时长 | `54000` ms |
| 自动播放（B 组，纯 Mock） | **54,481 ms**，`endReached:true`，无弹窗、无错误、0 付费请求 |
| 自动播放（A 组，真实 key 就绪） | 54,307 ms；`confirm:true` 自第 9 步起；`obs=0 dir=0 cand=0 layers=2`（第 7 步后不再增长） |
| 演示 index 7（第 8 步） | `stateSelection:{620,160,420,320}`；`engineHasSelection:false`；`selManagerHas:false` |
| 演示 index 10（第 11 步） | `layers:3`、`genCount:1`；L6 `{masked:false, mask_policy:"none", local_patch:true, selection:[620,160,420,320]}` |
| `mockCandidate` | `{mime:"data:image/svg+xml", bytes:778, lumaMin:56, lumaMax:143, distinctColors:24}` |
| `evidence` | `{ms:149, events:12, layers:3, bytesApprox:"443KB", ai:{calls:3, real_calls:0, mock_calls:3}, attest:{mode:"collab", zero_generation:false}}` |
| 手动框选后（Mock 全链路） | `analyze 31ms / dir 5ms / gen 9ms / apply 248ms`；L6 `{masked:true, mask_policy:"selection_alpha"}` |
| 像素比对（手动 mask 路径） | `insideChangedPixels:92160, outsideChangedPixels:0, outsideMaxDelta:0` |
| 外发网络请求 | Mock 全程 `0`（`networkExternal: []`） |

### A.4 复现命令

```powershell
# 1) 启动仓库服务（若未运行）
node v2/serve.mjs
# 2) 运行探针（脚本内已固定 http://127.0.0.1:4200/v2/app/index.html）
node "%TEMP%\inkproof-audit\probe-demo.mjs"
node "%TEMP%\inkproof-audit\probe-demo2.mjs"
node "%TEMP%\inkproof-audit\probe-demo3.mjs"
node "%TEMP%\inkproof-audit\probe-demo5.mjs"
```

> 探针安全约束：仅在 `POST /api/ai/{chat,image,test}` 上 `route.abort()`（防止付费）；`GET /api/ai/config` 放行以保留真实配置状态。

---

## 附录 B：引用文件清单

| 类别 | 路径 |
|---|---|
| 主控 | `v2/app/js/app.js`（DEMO_STEPS 5178-5193；demoDraw 5194-5217；演示控制 5218-5358；AI 面板 3714-3820；观察/方向/生成/落层 3095-3376；对话 3425-3633；证据 4140-4224；素材库 4404-4930；批量重读 5000-5117） |
| 页面 | `v2/app/index.html`（AI tabs 314-320；演示条 540-548；结束卡 550-561） |
| Mock | `v2/app/core/mock-ai.mjs`（模板 103-122；观察 166-185；SVG 占位 274-333） |
| 服务 | `v2/serve.mjs`（限额定义 70；请求校验 270-284；图片下载与缓存 285-312；DashScope 生图 424-503；编辑 507-555） |
| 证据 | `v2/qa/tools/qwen-real-e2e-results.json`、`qwen-real-evidence.json`、`qwen-image-edit-app-results.json`、`asset-real-read-results.json`、`qwen-chat-real-results.json`、`T117-mask-qa-result.json` |
| 自测 | `v2/app/test-demo-result.json`、`test-mask-compare-result.json`、`test-save-psd-result.json`、`test-present-result.json`、`test-library-result.json`、`test-ai-panel-v3-result.json`、`test-chat-actions-result.json`、`test-tools-result.json`、`test-text-edit-result.json`、`test-adjust-layer-result.json`、`test-canvas-resize-result.json` |
| PSD | `v2/psd/results/fidelity.md`、`v2/psd/results/samples/`、`v2/psd/vendor/ag-psd/` |
| 引擎/库 | `v2/engine/`（present 策略）、`v2/library/library-schema.mjs`、`v2/library/api.mjs` |
| 同批路演文档 | `06-技术/路演demo_多模态能力.md`、`06-技术/路演demo_差异化矩阵.md` |
| 交付说明 | `START_HERE.md`（能力清单 52-82；已知限制 98-108；T110-T116 记录 132-182） |
