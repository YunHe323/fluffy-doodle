# spike/webgl · 零依赖 WebGL2 tile 渲染器（T29）

> 独立 spike，**不接入 product/**；单文件、无第三方依赖、无 GPL 代码。

## 运行

```powershell
cd C:\Users\xiao1\Desktop\项目一\spike\webgl
python -m http.server 8091
# 浏览器打开 http://127.0.0.1:8091/  （也可直接双击 index.html / file://）
```

推荐 Chrome/Edge 现代版本。若在无 GPU 的无头环境跑，会落到 SwiftShader 软件渲染（`environment.gpuRenderer` 会如实记录）。

## 能做什么

- 256² tile 稀疏分配的 WebGL2 画布（默认 2048²，可跑 4096²）
- 2 笔刷（硬/软）+ 橡皮；笔刷尺寸；压感（手绘板压力 / 鼠标速度模拟）
- 3 图层：新建固定 3 层（背景/线稿/上色），可见性 + 不透明度
- undo/redo：tile patch（GPU `blitFramebuffer` 快照，无 readPixels 停顿），上限 50 步
- 缩放（滚轮，指针为中心）/ 平移（中键或 Shift+左键）/ 适应窗口
- 内置 bench：`开始跑测` → B1/B2/B3/B6，输出 `mozheng.bench.v1` JSON（页面内可复制/下载）
- `window.BenchAdapter`：符合 `bench/README.md §3` 契约，供 T26 的 `bench/index.html` 驱动

## 文件

- `index.html` — 全部代码（渲染器 / UI / bench / adapter）
- `results/webgl2-tile.json` — 本机实测结果（软件 GPU，见评估报告 §3 的解读与警告）
- `评估报告.md` — 架构、实测数据、风险、与 Klecks/CanvasKit 对比计划

## 已知限制

纹理笔刷 / 混合模式 / 图层组与蒙版 / PSD / 30 分钟长跑 / 真实 GPU + 手绘板复测 未做；详见 `评估报告.md §5`。
