/**
 * v2/brushes/src/brush-controller.js · T43 手感版
 *
 * 分工（T41/T44 引擎接口）：
 * - BrushController 负责输入预处理：稳定化(EMA) → 速度估计 → **贝塞尔路径平滑 + 弧长间距重采样**
 *   → 散射 → 收笔追尾/收锋 → 通过 engine.beginStroke/appendPoint/endStroke 提交；
 * - createProviderFromPreset() 负责每个 stamp 的 radiusFor/paintFor/stampFor（压力/速度/倾斜/
 *   硬度/纹理/椭圆笔尖/擦除），由 engine.setBrushProvider(provider) 注入；笔画事务、tile patch、undo 全由 engine 负责。
 *
 * T43 相对 T36 的手感改动（详见 README §9 / 手感报告.md）：
 * 1. **贝塞尔路径平滑**（参考 Klecks MIT 的 BezierLine 思路，自行实现）：输入点先做 EMA 稳定化，再用
 *    「过点相切 + 1/4 距离控制点」的三次贝塞尔连接相邻点，按弧长以间距采样 stamp。快速大转角不再出现
 *    折线拐点/断点；间距在相邻段之间插值，避免疏密突变。
 * 2. 速度估计：引擎 ctx.velocity 按「重采样点」计算，段内 dt=0 → 速度恒为 0（速度动态失效）。
 *    改为 controller 用原始 pointer 事件估计速度，再 noteInputSpeed() 注入 provider；鼠标权重 0.35。
 * 3. T44 实时预览兼容：provider 暴露 eraser/isEraser()（引擎用 live layer + DstOut 做橡皮实时预览）。
 * 4. 纹理与 tile 坐标一致：live 画在整张画布坐标、tile 提交画在 tile 局部坐标；provider 在 isTile 时把
 *    shader 局部矩阵加上 tile 偏移，纹理颗粒在「实时/提交」两套 canvas 下同一位置（否则提交后纹理跳变）。
 * 5. 纹理滚动：texture.roll > 0 时按笔画累计距离/方向平移纹理采样（stationary 仍是默认 0）。
 * 6. 椭圆笔尖：tip.shape='ellipse' 用 rotate+scale 绘制；tip.followStroke 时可随笔画方向。
 * 7. 收笔收锋：engine.provider.end(ctx) 无 canvas，无法重绘；改为在 endStroke 前对
 *    engine.currentStroke.records 的尾部 stamp 缩放 radius（+taperAlpha）——只操作本笔 records，
 *    不改 engine 文件；README 记为「待引擎正式接口替代」的临时方案。
 * 8. 稳定化：EMA 位置跟随 + 收笔「追尾」把 smoothed 补到真实笔尖（否则尾端短一截）；起笔压感不再恒为 1。
 * 9. 散射：每 dab 透明度按 1/√count 归一；抖动按当前半径；每 dab 角度/亮度用确定性 hash（实时/提交一致）。
 *
 * 已知限制：见 README §6。
 *
 * T52：可选路径引擎 `pathEngine: 'perfect-freehand' | 'bezier'`（默认 bezier 回退）。
 * - perfect-freehand 1.2.3（MIT，vendor/perfect-freehand.js）的 getStroke(points, opts) 生成压感轮廓，
 *   由 provider 在 live canvas（每次重绘整笔，清空后画）与 tile canvas（每个受影响 tile 只画一次，
 *   世界坐标→tile 局部坐标平移）上填充；收笔收锋由 start/end taper 原生提供，不再依赖 records 临时代偿。
 * - 仅对「轮廓模式」笔刷（默认 hard-round / pencil / ink-liner）启用；橡皮保留 stamp 模式（live 白 mask）。
 */
import { getStroke as perfectFreehandGetStroke } from '../vendor/perfect-freehand.js';
import { createMousePressureSimulator, normalizeSimulatedPressure } from './mouse-pressure.js';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;

/** 5 点压力曲线求值（x = [0,.25,.5,.75,1]） */
export function curveAt(curve, t) {
  if (!curve || curve.length !== 5) return clamp(t, 0, 1);
  const x = clamp(t, 0, 1) * 4;
  const i = Math.min(3, Math.floor(x));
  return lerp(curve[i], curve[i + 1], x - i);
}

/** 稳定的 per-stamp 随机数（同一 index 在「实时 / 提交重放」两次绘制中相同） */
function hash01(n, seed = 0) {
  let h = (Math.floor(n) | 0) * 374761393 + (seed | 0) * 668265263;
  h = (h ^ (h >>> 13)) >>> 0;
  h = Math.imul(h, 1274126177) >>> 0;
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

function seededRandom(seed) {
  let s = seed >>> 0 || 1;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function norm2(dx, dy) {
  const d = Math.hypot(dx, dy);
  return d > 1e-6 ? { x: dx / d, y: dy / d } : { x: 1, y: 0 };
}

/** 加载 1 张图（PNG）为 CanvasKit Image；失败返回 null → 笔刷降级为无纹理 */
export async function loadTexture(CK, url) {
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const buf = await res.arrayBuffer();
    return CK.MakeImageFromEncoded(new Uint8Array(buf));
  } catch (e) {
    console.warn('[brushes] texture load failed:', url, e && e.message);
    return null;
  }
}

/** 按 manifest 预载 textures（灰度图 + alpha mask），返回 { assetId: {image, mask} } */
export async function loadTextures(CK, manifest, baseUrl) {
  const out = {};
  for (const asset of manifest.assets) {
    const image = await loadTexture(CK, `${baseUrl}${asset.file}`);
    const mask = asset.maskFile ? await loadTexture(CK, `${baseUrl}${asset.maskFile}`) : null;
    if (image) out[asset.id] = { image, mask };
  }
  return out;
}

const TILE = 256;

/**
 * 创建笔刷预设对应的 StrokePaintProvider（engine 注入用，无需子类化 Stroke）。
 * @param {object} preset presets/defaults.json 中的一项
 * @param {{textures?:Record<string,{image:any,mask:any}>, color?:{r:number,g:number,b:number}, tileSize?:number}} [opts]
 */
export function createProviderFromPreset(preset, opts = {}) {
  if (!preset || !preset.size) throw new Error('createProviderFromPreset: 需要笔刷预设');
  const textures = opts.textures || {};
  const tileSize = opts.tileSize || TILE;
  const colorRef = { value: { ...(opts.color || { r: 31, g: 35, b: 40 }) } };
  const paints = new Map();
  const masks = new Map();
  const shaders = new Map();
  const colorFilters = new Map();
  const MAX_SHADERS = 512;

  /** T52 路径引擎：'perfect-freehand' 用压感轮廓填充；'bezier' 走 T43 stamp 管线 */
  const pathEngine = opts.pathEngine || preset.pathEngine || 'bezier';
  const isEraser = () => !!(preset.engine && preset.engine.eraser);
  const useOutline = pathEngine === 'perfect-freehand' && !isEraser();
  /** T62 涂抹模式：取当前图层已提交像素，按笔触方向拖动（不改 engine，只读 store 快照） */
  const smudgeOn = !!(preset.engine && preset.engine.smudge) && !isEraser();
  const engineRef = opts.engine || null;
  const SMUDGE_DEFAULTS = { strength: 0.65, flow: 0.55, softness: 0.5, drag: 0.45 };
  const smudgeParams = () => ({ ...SMUDGE_DEFAULTS, ...(preset.smudge || {}) });
  const smudgeLayerId = () => (state.smudge && state.smudge.layerId) || null;
  /** 取样快照缓存：layer tile image（笔画开始前的已提交内容；live 与 commit 共用同一份，保证一致） */
  function smudgeSampleFor(key) {
    const sm = state.smudge;
    if (!sm) return null;
    if (sm.samples.has(key)) return sm.samples.get(key);
    let img = null;
    try {
      const st = engineRef && engineRef.store;
      const layerId = sm.layerId;
      if (st && layerId) {
        const t = st.get(layerId, key);
        img = t ? t.image : null;
      }
    } catch (e) { img = null; }
    sm.samples.set(key, img);
    return img;
  }
  /** 预抓取样快照（end 时调，此时 tile 尚未被本次笔画写入 → live/commit 完全一致） */
  function smudgeCaptureAround(wx, wy, r) {
    const sm = state.smudge;
    if (!sm) return;
    const ts = tileSize;
    const x0 = Math.floor((wx - r) / ts), x1 = Math.floor((wx + r) / ts);
    const y0 = Math.floor((wy - r) / ts), y1 = Math.floor((wy + r) / ts);
    for (let ty = y0; ty <= y1; ty += 1) {
      for (let tx = x0; tx <= x1; tx += 1) smudgeSampleFor(`${tx},${ty}`);
    }
  }
  /** T62/T69：创建「笔画中间态」暂存 surface（当前图层已提交内容副本），涂抹取样=读它、并把结果写回它（反馈），
   *  这样颜色能沿笔触连续被拖动；提交时把最终暂存图按 tile 落回，保证 live / commit 同一结果。
   *  T69：默认按「笔触 bbox + 余量」创建小区域（engine.snapshotRegion），不再整画布 6.4MB；
   *       笔画扩大时按需增长（重放旧暂存图 + 从 snapshotRegion 补底）。`opts.smudgeFullCanvas` 可回到整画布版做 A/B。 */
  const smudgeFullCanvas = !!opts.smudgeFullCanvas;
  function smudgeEnsureStageFull(ctx) {
    const sm = state.smudge;
    if (!sm) return null;
    if (sm.stage) return sm.stage;
    const CK = ctx.CK;
    const e = engineRef;
    const st = e && e.store;
    if (!st || !e.width || !e.height) return null;
    const t0 = performance.now();
    let surface = null;
    try { surface = CK.MakeSurface(e.width, e.height); } catch (err) { surface = null; }
    if (!surface) return null;
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    let copied = 0;
    try {
      for (const key of st.listTiles(sm.layerId)) {
        const t = st.get(sm.layerId, key);
        if (!t || !t.image) continue;
        const { tx, ty } = st.keyXY(key);
        try { c.drawImage(t.image, tx * tileSize, ty * tileSize); copied += 1; } catch (err) { /* ignore */ }
      }
    } catch (err) { /* ignore */ }
    try { surface.flush(); } catch (err) { /* ignore */ }
    let image = null;
    try { image = surface.makeImageSnapshot(); } catch (err) { image = null; }
    sm.stage = {
      surface, canvas: c, image, x: 0, y: 0, w: e.width, h: e.height,
      tilesCopied: copied, bytes: e.width * e.height * 4, initMs: performance.now() - t0, grows: 0,
    };
    return sm.stage;
  }
  function smudgeRegionFor(wx, wy, r, e) {
    const pad = Math.max(320, r * 6);
    const x0 = Math.max(0, Math.floor(wx - pad));
    const y0 = Math.max(0, Math.floor(wy - pad));
    const x1 = Math.min(e.width, Math.ceil(wx + pad));
    const y1 = Math.min(e.height, Math.ceil(wy + pad));
    return { x: x0, y: y0, w: Math.max(1, x1 - x0), h: Math.max(1, y1 - y0) };
  }
  function smudgeMakeStageFromRegion(ctx, region) {
    const sm = state.smudge;
    const CK = ctx.CK;
    const e = engineRef;
    const st = e && e.store;
    if (!sm || !st) return null;
    const t0 = performance.now();
    let base = null;
    try { base = st.snapshotRegion(sm.layerId, region); } catch (err) { base = null; }
    let surface = null;
    try { surface = CK.MakeSurface(region.w, region.h); } catch (err) { surface = null; }
    if (!surface) { try { base && base.delete(); } catch (err) { /* ignore */ } return null; }
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    if (base) { try { c.drawImage(base, 0, 0); } catch (err) { /* ignore */ } try { base.delete(); } catch (err) { /* ignore */ } }
    try { surface.flush(); } catch (err) { /* ignore */ }
    let image = null;
    try { image = surface.makeImageSnapshot(); } catch (err) { image = null; }
    const prev = sm.stage;
    sm.stage = {
      surface, canvas: c, image, x: region.x, y: region.y, w: region.w, h: region.h,
      bytes: region.w * region.h * 4,
      initMs: (prev ? prev.initMs : 0) + (performance.now() - t0),
      grows: (prev ? (prev.grows || 0) + 1 : 0),
    };
    if (prev) {
      try { prev.image && prev.image.delete(); } catch (err) { /* ignore */ }
      try { prev.surface && prev.surface.delete(); } catch (err) { /* ignore */ }
    }
    return sm.stage;
  }
  function smudgeEnsureStage(ctx, wx, wy, r) {
    const sm = state.smudge;
    if (!sm) return null;
    if (sm.stage) return sm.stage;
    if (smudgeFullCanvas) return smudgeEnsureStageFull(ctx);
    const e = engineRef;
    if (!e || !e.width || !e.height) return null;
    return smudgeMakeStageFromRegion(ctx, smudgeRegionFor(wx, wy, r, e));
  }
  /** T69：笔画变长时扩展区域暂存（旧暂存图叠到新区域快照上，重叠区保持一致） */
  function smudgeGrowStage(ctx, need) {
    const sm = state.smudge;
    if (!sm) return null;
    const stage = sm.stage;
    if (!stage) return null;
    if (need.x >= stage.x && need.y >= stage.y && need.x + need.w <= stage.x + stage.w && need.y + need.h <= stage.y + stage.h) return stage;
    if (smudgeFullCanvas) return stage;
    const e = engineRef;
    const st = e && e.store;
    if (!st) return stage;
    const CK = ctx.CK;
    const pad = Math.max(320, need.w * 1.5);
    const x0 = Math.max(0, Math.floor(Math.min(stage.x, need.x) - pad));
    const y0 = Math.max(0, Math.floor(Math.min(stage.y, need.y) - pad));
    const x1 = Math.min(e.width, Math.ceil(Math.max(stage.x + stage.w, need.x + need.w) + pad));
    const y1 = Math.min(e.height, Math.ceil(Math.max(stage.y + stage.h, need.y + need.h) + pad));
    const t0 = performance.now();
    let base = null;
    try { base = st.snapshotRegion(sm.layerId, { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }); } catch (err) { base = null; }
    let surface = null;
    try { surface = CK.MakeSurface(x1 - x0, y1 - y0); } catch (err) { surface = null; }
    if (!surface) { try { base && base.delete(); } catch (err) { /* ignore */ } return stage; }
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    if (base) { try { c.drawImage(base, 0, 0); } catch (err) { /* ignore */ } try { base.delete(); } catch (err) { /* ignore */ } }
    try { if (stage.image) c.drawImage(stage.image, stage.x - x0, stage.y - y0); } catch (err) { /* ignore */ }
    try { surface.flush(); } catch (err) { /* ignore */ }
    let image = null;
    try { image = surface.makeImageSnapshot(); } catch (err) { image = null; }
    const prevImage = stage.image, prevSurface = stage.surface;
    sm.stage = {
      surface, canvas: c, image, x: x0, y: y0, w: x1 - x0, h: y1 - y0,
      bytes: (x1 - x0) * (y1 - y0) * 4,
      initMs: (stage.initMs || 0) + (performance.now() - t0),
      grows: (stage.grows || 0) + 1,
    };
    try { prevImage && prevImage.delete(); } catch (err) { /* ignore */ }
    try { prevSurface && prevSurface.delete(); } catch (err) { /* ignore */ }
    return sm.stage;
  }
  function smudgeDisposeStage() {
    const sm = state.smudge;
    if (!sm || !sm.stage) return;
    try { sm.stage.image && sm.stage.image.delete(); } catch (err) { /* ignore */ }
    try { sm.stage.surface && sm.stage.surface.delete(); } catch (err) { /* ignore */ }
    sm.stage = null;
  }
  /** 把「源矩形」的图层像素按 alpha 画到目标 canvas（源=当前图层快照；避免读 live/合成层破坏图层隔离） */
  function drawSampledRegion(ctx, canvas, srcRect, dstCx, dstCy, alpha) {
    const CK = ctx.CK;
    const st = engineRef && engineRef.store;
    if (!st || alpha <= 0.004) return;
    const ts = tileSize;
    const paint = new CK.Paint();
    paint.setAntiAlias(true);
    paint.setAlphaf(clamp(alpha, 0, 1));
    const tx0 = Math.floor(srcRect.x / ts), tx1 = Math.floor((srcRect.x + srcRect.w - 0.001) / ts);
    const ty0 = Math.floor(srcRect.y / ts), ty1 = Math.floor((srcRect.y + srcRect.h - 0.001) / ts);
    const dstX0 = dstCx - srcRect.w / 2;
    const dstY0 = dstCy - srcRect.h / 2;
    for (let ty = ty0; ty <= ty1; ty += 1) {
      for (let tx = tx0; tx <= tx1; tx += 1) {
        const img = smudgeSampleFor(`${tx},${ty}`);
        if (!img) continue;
        const ix0 = Math.max(srcRect.x, tx * ts), iy0 = Math.max(srcRect.y, ty * ts);
        const ix1 = Math.min(srcRect.x + srcRect.w, (tx + 1) * ts);
        const iy1 = Math.min(srcRect.y + srcRect.h, (ty + 1) * ts);
        const iw = ix1 - ix0, ih = iy1 - iy0;
        if (iw <= 0.5 || ih <= 0.5) continue;
        let dx = dstX0 + (ix0 - srcRect.x);
        let dy = dstY0 + (iy0 - srcRect.y);
        if (ctx.isTile) {
          dx -= (ctx.tileX || 0) * ts;
          dy -= (ctx.tileY || 0) * ts;
        }
        try {
          canvas.drawImageRect(img, CK.XYWHRect(ix0 - tx * ts, iy0 - ty * ts, iw, ih), CK.XYWHRect(dx, dy, iw, ih), paint);
        } catch (e) { /* ignore */ }
      }
    }
    try { paint.delete(); } catch (e) { /* ignore */ }
  }
  /** 从单张 CK.Image（世界坐标）取 srcRect 画到目标 canvas 的 (dstCx,dstCy) */
  function drawImageRegion(ctx, img, srcRect, dstCx, dstCy, alpha, targetCanvas) {
    if (!img || alpha <= 0.004) return;
    const CK = ctx.CK;
    const paint = new CK.Paint();
    paint.setAntiAlias(true);
    paint.setAlphaf(clamp(alpha, 0, 1));
    const dstX0 = dstCx - srcRect.w / 2;
    const dstY0 = dstCy - srcRect.h / 2;
    try {
      targetCanvas.drawImageRect(img, CK.XYWHRect(srcRect.x, srcRect.y, srcRect.w, srcRect.h), CK.XYWHRect(dstX0, dstY0, srcRect.w, srcRect.h), paint);
    } catch (e) { /* ignore */ }
    try { paint.delete(); } catch (e) { /* ignore */ }
  }
  /** T62：一次涂抹 stamp —— 取暂存图（含本笔此前拖动结果）→ 按笔触方向把像素拖到当前位置；
   *  live 阶段把结果写回暂存图（反馈，使颜色沿笔画连续移动）；提交阶段每 tile 落一次最终暂存图。 */
  function drawSmudgeStamp(ctx) {
    const sm = state.smudge;
    if (!sm || !ctx.canvas) return;
    const p = smudgeParams();
    const r = Math.max(1.5, ctx.radius);
    const drag = clamp(Number(p.drag) || 0, 0, 1.5);
    const soft = clamp(Number(p.softness) || 0, 0, 1);
    const pressure = clamp(ctx.pressure == null ? 0.5 : ctx.pressure, 0, 1);
    const a = clamp(Number(p.strength) * Number(p.flow) * (0.45 + 0.55 * pressure), 0, 1);

    // ---- 提交阶段：每个 tile 只把最终暂存图对应区域落一次（T69：暂存图可能是小区域，需按交集裁） ----
    if (ctx.isTile) {
      const stage = sm.stage;
      if (!stage || !stage.image) return;
      if (!sm.tilesCommitted) sm.tilesCommitted = new Set();
      const key = `${ctx.tileX || 0},${ctx.tileY || 0}`;
      if (sm.tilesCommitted.has(key)) return;
      sm.tilesCommitted.add(key);
      const CK = ctx.CK;
      const ts = tileSize;
      const tx = ctx.tileX || 0, ty = ctx.tileY || 0;
      const ix0 = Math.max(tx * ts, stage.x), iy0 = Math.max(ty * ts, stage.y);
      const ix1 = Math.min((tx + 1) * ts, stage.x + stage.w), iy1 = Math.min((ty + 1) * ts, stage.y + stage.h);
      const paint = new CK.Paint();
      try {
        ctx.canvas.clear(CK.TRANSPARENT);
        if (ix1 > ix0 && iy1 > iy0) {
          ctx.canvas.drawImageRect(
            stage.image,
            CK.XYWHRect(ix0 - stage.x, iy0 - stage.y, ix1 - ix0, iy1 - iy0),
            CK.XYWHRect(ix0 - tx * ts, iy0 - ty * ts, ix1 - ix0, iy1 - iy0),
            paint,
          );
        }
      } catch (e) { /* ignore */ }
      try { paint.delete(); } catch (e) { /* ignore */ }
      return;
    }

    // ---- live 阶段：取样自暂存图，画到 live canvas，并把同样内容写回暂存图 ----
    const dir = sm.dirs.get(ctx.index) || sm.lastDir || { x: 1, y: 0 };
    // 每 stamp 的像素位移固定为几 px（不是 ×半径）：配合暂存图反馈 → 颜色被连续拖动，
    // 若位移过大（×半径）会复制出周期性的「条纹」而不是连续涂抹。
    const shiftPx = clamp(drag * 8, 0, 24);
    const srcCx = ctx.worldX - dir.x * shiftPx;
    const srcCy = ctx.worldY - dir.y * shiftPx;
    const srcRect = { x: srcCx - r, y: srcCy - r, w: r * 2, h: r * 2 };
    const dstRect = { x: ctx.worldX - r, y: ctx.worldY - r, w: r * 2, h: r * 2 };
    const rs = r * (0.45 + 0.25 * (1 - soft));
    const srcRect2 = { x: srcCx - rs, y: srcCy - rs, w: rs * 2, h: rs * 2 };
    const need = {
      x: Math.floor(Math.min(srcRect.x, dstRect.x, srcRect2.x)),
      y: Math.floor(Math.min(srcRect.y, dstRect.y, srcRect2.y)),
      w: Math.ceil(Math.max(srcRect.x + srcRect.w, dstRect.x + dstRect.w, srcRect2.x + srcRect2.w) - Math.min(srcRect.x, dstRect.x, srcRect2.x)),
      h: Math.ceil(Math.max(srcRect.y + srcRect.h, dstRect.y + dstRect.h, srcRect2.y + srcRect2.h) - Math.min(srcRect.y, dstRect.y, srcRect2.y)),
    };
    let stage = smudgeEnsureStage(ctx, ctx.worldX, ctx.worldY, r);
    if (stage) stage = smudgeGrowStage(ctx, need);
    sm.stamps = (sm.stamps || 0) + 1;
    if (stage && stage.image) {
      sm.stageBytes = stage.bytes;
      sm.stageRegion = [stage.x, stage.y, stage.w, stage.h];
      const local = (rect) => ({ x: rect.x - stage.x, y: rect.y - stage.y, w: rect.w, h: rect.h });
      const lx = ctx.worldX - stage.x, ly = ctx.worldY - stage.y;
      // 主取样：画到 live + 写回暂存（反馈）
      drawImageRegion(ctx, stage.image, local(srcRect), ctx.worldX, ctx.worldY, a, ctx.canvas);
      drawImageRegion(ctx, stage.image, local(srcRect), lx, ly, a, stage.canvas);
      if (soft > 0.02) {
        drawImageRegion(ctx, stage.image, local(srcRect2), ctx.worldX, ctx.worldY, a * soft * 0.9, ctx.canvas);
        drawImageRegion(ctx, stage.image, local(srcRect2), lx, ly, a * soft * 0.9, stage.canvas);
      }
      try { stage.surface.flush(); } catch (e) { /* ignore */ }
      try { stage.image.delete(); } catch (e) { /* ignore */ }
      try { stage.image = stage.surface.makeImageSnapshot(); } catch (e) { stage.image = null; }
      return;
    }
    // 降级：无暂存 surface 时，用 tile 快照取样（只拖动一层，颜色不会沿笔画连续传播）
    smudgeCaptureAround(srcCx, srcCy, r);
    drawSampledRegion(ctx, ctx.canvas, srcRect, ctx.worldX, ctx.worldY, a);
    if (soft > 0.02) {
      drawSampledRegion(ctx, ctx.canvas, srcRect2, ctx.worldX, ctx.worldY, a * soft * 0.9);
    }
  }

  /** 一次笔触内的临时状态（begin 重置） */
  const state = {
    lastX: 0, lastY: 0, lastIdx: -1, hasPrev: false,
    dirX: 1, dirY: 0,
    inputSpeed: 0, // px/ms（controller 注入）
    pointsRef: null,   // engine Stroke.points（同一数组引用，随 append 增长）
    tilesDrawn: new Set(), // 轮廓模式：提交阶段每个 tile 只画一次
    finished: false,       // provider.end 已调用（提交阶段 → getStroke last:true，应用收笔 taper）
  };
  const tiltNorm = (ctx) => clamp(Math.hypot(ctx.tiltX || 0, ctx.tiltY || 0) / 60, 0, 1);
  const speedWeight = (ctx) => (ctx.pointerType === 'pen' ? 1 : 0.35);
  const speedNormOf = (ctx) => clamp((Number.isFinite(ctx.speed) ? ctx.speed : state.inputSpeed) / 2.4, 0, 1);

  /* ---------- 纹理 shader（含 tile 偏移 & 滚动） ---------- */
  function shaderFor(ctx, assetId) {
    const CK = ctx.CK;
    const entry = textures[assetId];
    const img = entry && (entry.mask || entry.image);
    if (!img) return null;
    const tex = preset.texture || {};
    const texScale = 1 / clamp(Number(tex.scale) || 1, 0.25, 8); // 1 = 1 纹素/画布像素
    const roll = clamp(Number(tex.roll) || 0, 0, 2);
    let ox = 0, oy = 0;
    if (roll > 0) {
      const span = 256 / texScale; // 纹理画布周期，量化+取模保证缓存有界
      ox = ((Math.round(((ctx.rollX || 0) * roll) / 8) * 8) % span + span) % span;
      oy = ((Math.round(((ctx.rollY || 0) * roll) / 8) * 8) % span + span) % span;
    }
    // tile 重放：tile 局部坐标 + tile 偏移 = 画布坐标，纹理必须与 live 一致
    const txOff = ctx.isTile ? (ctx.tileX || 0) * tileSize : 0;
    const tyOff = ctx.isTile ? (ctx.tileY || 0) * tileSize : 0;
    const key = `${assetId}|${Math.round(ox)},${Math.round(oy)}|${txOff},${tyOff}|${texScale.toFixed(3)}`;
    const hit = shaders.get(key);
    if (hit) return hit;
    if (shaders.size >= MAX_SHADERS) {
      for (const s of shaders.values()) { try { s && s.delete(); } catch (e) { /* ignore */ } }
      shaders.clear();
    }
    let shader = null;
    try {
      const m = [
        texScale, 0, texScale * (txOff - ox),
        0, texScale, texScale * (tyOff - oy),
        0, 0, 1,
      ];
      shader = img.makeShaderOptions(CK.TileMode.Repeat, CK.TileMode.Repeat, CK.FilterMode.Linear, CK.MipmapMode.None, m);
    } catch (e) { console.warn('[brushes] makeShader failed', e && e.message); }
    shaders.set(key, shader);
    return shader;
  }

  function colorFilterFor(ctx) {
    const CK = ctx.CK;
    const c = colorRef.value;
    const key = `${c.r},${c.g},${c.b}`;
    const hit = colorFilters.get(key);
    if (hit !== undefined) return hit;
    let cf = null;
    try {
      // mask 纹理：RGB=白、alpha=颗粒；Modulate 让颗粒按笔迹颜色着色
      cf = CK.ColorFilter.MakeBlend(CK.Color(c.r, c.g, c.b, 1), CK.BlendMode.Modulate);
    } catch (e) { /* 老版本无 MakeBlend → 降级 */ }
    colorFilters.set(key, cf);
    return cf;
  }

  /* ---------- 每 stamp 半径（engine append 时调用一次，结果存入 record） ---------- */
  function radiusFor(ctx) {
    const p = preset;
    // 轮廓模式：engine 用 radius 计算受影响 tile；返回「最大半宽 + 平滑余量」，保证 tile 覆盖完整轮廓
    if (useOutline) return Math.max(0.5, (Number(p.size.base) || 32) * 0.62);
    // T62 涂抹：半径 = size/2 × 压力曲线（沿用 T54 压力）；同时记录每个 record 的笔触方向供 stamp 取样偏移
    if (smudgeOn) {
      const pressure = clamp(ctx.pressure == null ? 0.5 : ctx.pressure, 0, 1);
      const base = (Number(p.size.base) || 48) * 0.5 * curveAt(p.size.pressureCurve, pressure);
      const floorScale = clamp(Number(p.size.floorScale) || 0, 0, 0.9);
      const r = Math.max(base, (Number(p.size.base) || 48) * 0.5 * floorScale, 1.5);
      const sm = state.smudge;
      if (sm) {
        if (sm.lastIdx >= 0 && ctx.index > sm.lastIdx) {
          const dx = ctx.worldX - sm.lastX;
          const dy = ctx.worldY - sm.lastY;
          const d = Math.hypot(dx, dy);
          if (d > 0.15) sm.lastDir = { x: dx / d, y: dy / d };
        }
        if (ctx.index > sm.lastIdx) {
          sm.dirs.set(ctx.index, sm.lastDir);
          sm.lastIdx = ctx.index;
          sm.lastX = ctx.worldX;
          sm.lastY = ctx.worldY;
        }
        sm.maxRadius = Math.max(sm.maxRadius || 0, r);
      }
      return r;
    }
    const dyn = p.dynamics || {};
    const tip = p.tip || {};
    const pressure = clamp(ctx.pressure == null ? 0.5 : ctx.pressure, 0, 1);
    const tilt = tiltNorm(ctx);
    const spd = speedNormOf(ctx);

    // 方向（纹理滚动 / 椭圆笔尖跟随）；只在「新 record」时更新，避免 radiusFor 兼容调用污染状态
    if (ctx.index > state.lastIdx) {
      if (state.hasPrev) {
        const dx = ctx.worldX - state.lastX;
        const dy = ctx.worldY - state.lastY;
        const d = Math.hypot(dx, dy);
        if (d > 0.05) { state.dirX = dx / d; state.dirY = dy / d; }
      }
      state.lastX = ctx.worldX;
      state.lastY = ctx.worldY;
      state.lastIdx = ctx.index;
      state.hasPrev = true;
    }
    ctx.speed = state.inputSpeed;
    ctx.speedNorm = spd;
    ctx.rollX = state.dirX * (ctx.distance || 0);
    ctx.rollY = state.dirY * (ctx.distance || 0);
    // 椭圆笔尖角度
    let ang = Number(tip.angleDeg) || 0;
    if (tip.followStroke) ang += (Math.atan2(state.dirY, state.dirX) * 180) / Math.PI;
    if (dyn.tiltAngleJitter) ang += (ctx.tiltX || 0) * dyn.tiltAngleJitter * 0.8;
    const scatter = p.scatter || {};
    if (scatter.angleJitter) ang += (hash01(ctx.index * 7 + 3, 11) - 0.5) * 2 * scatter.angleJitter * 60;
    ctx.stampAngle = ang;

    let r = (Number(p.size.base) || 32) * 0.5 * curveAt(p.size.pressureCurve, pressure);
    // T59：高速段宽度下限（防止模拟压感把快速笔画压成发丝，导致密度 CV 爆高；保留慢/快粗细差）
    const floorScale = clamp(Number(p.size.floorScale) || 0, 0, 0.9);
    if (floorScale > 0) r = Math.max(r, (Number(p.size.base) || 32) * 0.5 * floorScale);
    if (dyn.tiltSizeFactor) r *= clamp(1 + dyn.tiltSizeFactor * tilt * 0.75, 0.1, 2.5);
    if (dyn.speedSizeFactor) {
      const w = speedWeight(ctx);
      r *= clamp(1 + dyn.speedSizeFactor * (spd - 0.35) * w * 1.6, 0.1, 2.6);
    }
    // 起笔收锋：按累计距离渐入（engine ctx.distance 为真实路径长度）
    const taperStart = clamp(Number((p.taper || {}).start) || 0, 0, 1);
    if (taperStart > 0) {
      const len = Math.max(6, (Number(p.size.base) || 32) * taperStart * 2.6);
      const f = clamp((ctx.distance || 0) / len, 0.12, 1);
      r *= 0.12 + 0.88 * f;
    }
    // T59：半径沿轨迹做「距离域」平滑（窗口 = radiusSmooth × size.base px），
    // 抑制速度抖动引起的线宽 ripple；慢/快笔画之间的整体粗细差保留（跨笔画不平均）。
    const smoothWin = clamp(Number(p.smoothing && p.smoothing.radiusSmooth) || 0, 0, 2);
    if (smoothWin > 0) {
      const winPx = Math.max(4, (Number(p.size.base) || 32) * smoothWin);
      const dist = Math.max(0, (ctx.distance || 0) - (state.smoothDist || 0));
      const k = state.smoothRadius ? clamp(dist / winPx, 0.04, 1) : 1;
      r = state.smoothRadius ? state.smoothRadius + (r - state.smoothRadius) * k : r;
      state.smoothRadius = r;
      state.smoothDist = ctx.distance || 0;
    } else {
      state.smoothRadius = r;
      state.smoothDist = ctx.distance || 0;
    }
    return Math.max(0.35, r);
  }

  /* ---------- 每 stamp paint ---------- */
  function paintFor(ctx) {
    // T62 涂抹：像素拖动在 stampFor 内完成，不需要统一 paint
    if (smudgeOn) return null;
    const CK = ctx.CK;
    const dyn = preset.dynamics || {};
    const pressure = clamp(ctx.pressure == null ? 0.5 : ctx.pressure, 0, 1);
    const tilt = tiltNorm(ctx);
    const spd = ctx.speedNorm != null ? ctx.speedNorm : speedNormOf(ctx);
    const eraser = isEraser();

    const key = eraser ? 'eraser' : 'brush';
    let paint = paints.get(key);
    if (!paint) {
      paint = new CK.Paint();
      paint.setAntiAlias(true);
      paint.setStyle(CK.PaintStyle.Fill);
      paints.set(key, paint);
    }

    if (eraser) {
      paint.setBlendMode(CK.BlendMode.Clear);
      paint.setShader(null);
      paint.setColorFilter(null);
      paint.setMaskFilter(null);
      paint.setAlphaf(1);
      return paint;
    }

    paint.setBlendMode(CK.BlendMode.SrcOver);

    // ---- 不透明度 / 流量：单 dab alpha（重叠累积由 SrcOver 自然形成） ----
    const op = preset.opacity || { base: 1, min: 0, pressureCurve: [0, 0.25, 0.5, 0.75, 1] };
    const fl = preset.flow || { base: 1, pressureCurve: [0, 0.25, 0.5, 0.75, 1] };
    let alpha = clamp(Number(op.base) * curveAt(op.pressureCurve, pressure), 0, 1);
    alpha = Math.max(Number(op.min) || 0, alpha);
    const flowVal = clamp((Number(fl.base) || 1) * curveAt(fl.pressureCurve, pressure), 0.02, 1);
    alpha *= Math.pow(flowVal, 0.6);
    if (dyn.speedOpacityFactor) {
      const w = speedWeight(ctx);
      alpha *= clamp(1 + dyn.speedOpacityFactor * (spd - 0.35) * w * 1.6, 0.1, 2.4);
    }
    if (dyn.tiltOpacityFactor) alpha *= clamp(1 + dyn.tiltOpacityFactor * tilt * 0.7, 0.1, 2.2);
    const scatter = preset.scatter || {};
    const dabCount = Math.max(1, Math.floor(scatter.count) || 1);
    if (dabCount > 1) alpha /= Math.sqrt(dabCount);
    if (ctx.taperAlpha != null) alpha *= ctx.taperAlpha;
    const cd = preset.colorDynamics || {};
    if (cd.valueJitter) alpha *= 1 - cd.valueJitter * 0.45 * hash01(ctx.index * 31 + 7, 23);
    alpha = clamp(alpha, 0, 0.995);

    // ---- 颜色/纹理 ----
    const assetId = preset.texture && preset.texture.assetId;
    // 极小 dab（短点/细线）时纹理 alpha-mask 会把笔迹打散成噪点 → 退化为实心（保证点可见）
    const tooSmallForTexture = (ctx.radius || 1) < 3.2;
    const shader = assetId && !tooSmallForTexture ? shaderFor(ctx, assetId) : null;
    paint.setShader(null);
    paint.setColorFilter(null);
    if (shader) {
      paint.setShader(shader);
      const cf = colorFilterFor(ctx);
      if (cf) paint.setColorFilter(cf);
      paint.setAlphaf(alpha);
    } else {
      const shade = cd.valueJitter ? 1 - cd.valueJitter * 0.6 * hash01(ctx.index * 31 + 7, 23) : 1;
      paint.setColor(CK.Color(
        clamp(colorRef.value.r * shade, 0, 255),
        clamp(colorRef.value.g * shade, 0, 255),
        clamp(colorRef.value.b * shade, 0, 255),
        alpha,
      ));
    }

    // ---- 硬度 → 边缘 blur（device 空间；live/tile 均为 1:1 坐标，表现一致） ----
    const hardness = clamp(Number((preset.hardness || {}).base ?? 1) + Number((preset.hardness || {}).pressureFactor || 0) * (pressure - 0.5), 0, 1);
    const sigma = Math.max(0, 1 - hardness) * ctx.radius * 0.85;
    if (sigma > 0.6) {
      const mk = sigma.toFixed(2);
      let mask = masks.get(mk);
      if (!mask) {
        mask = CK.MaskFilter.MakeBlur(CK.BlurStyle.Normal, sigma, false);
        masks.set(mk, mask);
      }
      paint.setMaskFilter(mask);
    } else {
      paint.setMaskFilter(null);
    }
    return paint;
  }

  /* ---------- T52 轮廓模式：perfect-freehand getStroke → 路径填充 ---------- */
  function drawOutline(ctx) {
    const CK = ctx.CK;
    const pts = state.pointsRef;
    if (!pts || pts.length === 0 || !ctx.canvas) return;
    const isLive = ctx.isTile !== true;
    if (isLive) {
      // live canvas 只承载本笔实时预览：节流重绘（每 ~3 点或移动 >10px 才清空重画），控制 O(n²) 开销
      const last = pts[pts.length - 1];
      const since = pts.length - (state.liveCount || 0);
      const dist = state.livePoint ? Math.hypot(last.x - state.livePoint.x, last.y - state.livePoint.y) : 1e9;
      if (since < 3 && dist < 10) return;
      state.liveCount = pts.length;
      state.livePoint = { x: last.x, y: last.y };
      try { ctx.canvas.clear(CK.TRANSPARENT); } catch (e) { /* ignore */ }
    } else {
      // 提交阶段：同一 tile 会在 records 循环里被多次调用，只画一次完整轮廓（按 tile 裁剪）
      const key = `${ctx.tileX || 0},${ctx.tileY || 0}`;
      if (state.tilesDrawn.has(key)) return;
      state.tilesDrawn.add(key);
    }
    const pf = preset.perfectFreehand || {};
    // 宽度标定：PF 的 size 语义与我们的 size.base（直径）不同（thinning 会放大高压力宽度），
    // 用 sizeScale 归一到与 bezier 相近的中压力线宽；pf.size 可显式覆盖。
    const sizeScale = Number(pf.sizeScale) || 0.62;
    const size = Number(pf.size) || ((Number(preset.size.base) || 32) * sizeScale);
    const input = new Array(pts.length);
    for (let i = 0; i < pts.length; i += 1) {
      const p = pts[i];
      input[i] = [p.x, p.y, clamp(p.pressure == null ? 0.5 : p.pressure, 0, 1)];
    }
    const taper = preset.taper || {};
    const smooth = preset.smoothing || {};
    const options = {
      size,
      thinning: pf.thinning != null ? pf.thinning : 0.6,
      smoothing: pf.smoothing != null ? pf.smoothing : 0.55,
      streamline: pf.streamline != null ? pf.streamline : clamp((Number(smooth.stabilizer) || 0.2) * 0.9, 0, 0.85),
      simulatePressure: false,
      easing: (t) => t,
      start: { cap: true, taper: clamp(Number(taper.start) || 0, 0, 1) * size },
      end: { cap: true, taper: clamp(Number(taper.end) || 0, 0, 1) * size },
      last: state.finished === true && !isLive,
    };
    let outline = [];
    try { outline = perfectFreehandGetStroke(input, options); } catch (e) { outline = []; }
    const paint = ctx.paint;
    if (!paint) return;
    if (!outline || outline.length < 3) {
      // 退化（单点等）：画一个圆点，保证落笔可见
      ctx.canvas.drawCircle(ctx.x, ctx.y, Math.max(0.5, size * 0.25), paint);
      return;
    }
    const offX = ctx.isTile ? -(ctx.tileX || 0) * tileSize : 0;
    const offY = ctx.isTile ? -(ctx.tileY || 0) * tileSize : 0;
    // CanvasKit 0.42：Path 不可变，需用 PathBuilder 构造后 detach()
    let path = null;
    let builder = null;
    try {
      builder = new CK.PathBuilder();
      builder.moveTo(outline[0][0] + offX, outline[0][1] + offY);
      for (let i = 1; i < outline.length; i += 1) builder.lineTo(outline[i][0] + offX, outline[i][1] + offY);
      builder.close();
      path = builder.detach();
      builder = null;
      // 轮廓是「一次填充」：alpha 不再按 stamp 叠加，取 opacity.base + flow 的小修正
      const op = preset.opacity || {};
      const fl = preset.flow || {};
      paint.setAlphaf(clamp((Number(op.base) || 1) * (0.85 + 0.15 * clamp(Number(fl.base) || 1, 0, 1)), 0.02, 1));
      ctx.canvas.drawPath(path, paint);
    } catch (e) {
      console.warn('[brushes] outline draw failed:', e && e.message);
    } finally {
      try { builder && builder.delete(); } catch (e) { /* ignore */ }
      try { path && path.delete(); } catch (e) { /* ignore */ }
    }
  }

  /* ---------- stamp 绘制（涂抹 / 椭圆笔尖 / 圆笔尖 / 轮廓填充） ---------- */
  function stampFor(ctx) {
    if (smudgeOn) { drawSmudgeStamp(ctx); return; }
    if (!ctx.paint || !ctx.canvas) return;
    if (useOutline) { drawOutline(ctx); return; }
    const tip = preset.tip || {};
    const roundness = Number(tip.roundness);
    if (tip.shape === 'ellipse' && roundness < 0.97) {
      const ang = Number(ctx.stampAngle) || 0;
      ctx.canvas.save();
      ctx.canvas.translate(ctx.x, ctx.y);
      ctx.canvas.rotate(ang, 0, 0);
      ctx.canvas.scale(1, clamp(roundness, 0.15, 1));
      ctx.canvas.drawCircle(0, 0, ctx.radius, ctx.paint);
      ctx.canvas.restore();
    } else {
      ctx.canvas.drawCircle(ctx.x, ctx.y, ctx.radius, ctx.paint);
    }
  }

  return {
    id: `t36-${preset.id || 'preset'}`,
    name: preset.name || 'T36 preset',
    preset,
    eraser: isEraser(),
    isEraser() { return isEraser(); },
    pathEngine,       // T52：'bezier' | 'perfect-freehand'
    outline: useOutline,
    /** 由 BrushController 注入原始输入速度（px/ms） */
    noteInputSpeed(v) { state.inputSpeed = Number.isFinite(v) ? clamp(v, 0, 8) : 0; },
    begin(ctx) {
      smudgeDisposeStage(); // 释放上一笔的暂存 surface
      state.lastIdx = -1; state.hasPrev = false; state.inputSpeed = 0;
      state.dirX = 1; state.dirY = 0; state.lastX = 0; state.lastY = 0;
      state.smoothRadius = 0; state.smoothDist = 0;
      state.pointsRef = ctx && Array.isArray(ctx.points) ? ctx.points : null;
      state.tilesDrawn = new Set();
      state.finished = false;
      state.liveCount = 0;
      state.livePoint = null;
      // T62 涂抹：重置取样缓存/方向表（layerId 由 engine strokeCtx 提供，保证只取当前图层）
      state.smudge = smudgeOn ? {
        layerId: ctx && ctx.layerId, lastIdx: -1, lastX: 0, lastY: 0,
        lastDir: { x: 1, y: 0 }, dirs: new Map(), samples: new Map(), maxRadius: 0,
        stage: null, tilesCommitted: new Set(),
      } : null;
    },
    radiusFor,
    paintFor,
    stampFor,
    smudge: smudgeOn,
    isSmudge() { return smudgeOn; },
    end(ctx) {
      state.finished = true;
      // T62：提交写 tile 前预抓取样快照（此刻 tile 仍是笔画前内容）→ live / commit 完全一致
      const sm = state.smudge;
      if (sm && ctx && Array.isArray(ctx.points) && ctx.points.length) {
        let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
        for (const pt of ctx.points) {
          if (!pt) continue;
          x0 = Math.min(x0, pt.x); y0 = Math.min(y0, pt.y);
          x1 = Math.max(x1, pt.x); y1 = Math.max(y1, pt.y);
        }
        const p = smudgeParams();
        const margin = (sm.maxRadius || 48) * (1.2 + clamp(Number(p.drag) || 0, 0, 1.5)) + 8;
        const ts = tileSize;
        const tx0 = Math.floor((x0 - margin) / ts), tx1 = Math.floor((x1 + margin) / ts);
        const ty0 = Math.floor((y0 - margin) / ts), ty1 = Math.floor((y1 + margin) / ts);
        for (let ty = ty0; ty <= ty1; ty += 1) {
          for (let tx = tx0; tx <= tx1; tx += 1) smudgeSampleFor(`${tx},${ty}`);
        }
      }
    },
    cancel(ctx) {
      void ctx;
      smudgeDisposeStage();
      state.pointsRef = null;
      state.tilesDrawn = new Set();
      state.finished = false;
      state.smudge = null;
    },
    setColor(rgb) { colorRef.value = { r: rgb.r, g: rgb.g, b: rgb.b }; },
    getColor() { return { ...colorRef.value }; },
    getStats() { const sm = state.smudge; return { paints: paints.size, masks: masks.size, shaders: shaders.size, colorFilters: colorFilters.size, smudge: sm ? { stamps: sm.stamps || 0, stageBytes: sm.stageBytes || 0, stageRegion: sm.stageRegion || null, stageInitMs: sm.stage ? Math.round((sm.stage.initMs || 0) * 100) / 100 : 0, stageGrows: sm.stage ? (sm.stage.grows || 0) : 0, fullCanvas: smudgeFullCanvas } : null }; },
    dispose() {
      for (const p of paints.values()) { try { p.delete(); } catch (e) { /* ignore */ } }
      for (const m of masks.values()) { try { m.delete(); } catch (e) { /* ignore */ } }
      for (const s of shaders.values()) { try { s && s.delete(); } catch (e) { /* ignore */ } }
      for (const c of colorFilters.values()) { try { c && c.delete(); } catch (e) { /* ignore */ } }
      paints.clear(); masks.clear(); shaders.clear(); colorFilters.clear();
    },
  };
}

/** T62 内置涂抹预设（app/demo 无需先加载 presets 即可 setMode('smudge')） */
export const SMUDGE_PRESET = Object.freeze({
  id: 'smudge', name: '涂抹', nameEn: 'Smudge', category: 'tool',
  engine: { strokeMode: 'smudge', blendMode: 'normal', eraser: false, smudge: true },
  size: { base: 64, min: 2, max: 512, pressureCurve: [0.55, 0.75, 0.9, 1, 1] },
  spacing: { ratio: 0.035, minPx: 0.5 },
  tip: { shape: 'circle', roundness: 1, angleDeg: 0 },
  hardness: { base: 0.7, pressureFactor: 0 },
  opacity: { base: 1, min: 0.9, pressureCurve: [0.9, 0.95, 1, 1, 1] },
  flow: { base: 0.55, pressureCurve: [0.6, 0.8, 0.9, 1, 1] },
  smudge: { strength: 0.65, flow: 0.55, softness: 0.5, drag: 0.45 },
  texture: { assetId: null, scale: 1, pressureScale: 0, rotationDeg: 0, rotationJitter: 0, roll: 0, blendMode: 'multiply', contrast: 1, brightness: 0 },
  colorDynamics: { hueJitter: 0, satJitter: 0, lightJitter: 0, backgroundBlend: 0 },
  scatter: { count: 1, radiusScale: 0, angleJitter: 0 },
  dynamics: { speedSizeFactor: 0, tiltSizeFactor: 0, tiltAngleJitter: 0, speedOpacityFactor: 0, velocityEmaMs: 45 },
  smoothing: { stabilizer: 0.25, velocityEma: 0.5, radiusSmooth: 0 },
  taper: { start: 0, end: 0, pressure: 0 },
  performance: { maxDabsPerPoint: 8, useSoftDabCpu: false },
  pathEngine: 'bezier',
});

/**
 * 笔刷控制器：
 * 原始 pointer → 速度 EMA/压感模拟 → 位置 EMA 稳定化 → 贝塞尔路径 + 弧长间距重采样 → 散射 → engine。
 * 贝塞尔平滑思路参考 Klecks（MIT）的 BezierLine：相邻点间用「点相切方向 + 1/4 弦长控制点」的三次贝塞尔，
 * 控制点由前后点方向决定，因此转折处 G1 连续；stamp 沿曲线按弧长分布（间距在段间插值）。
 * 本实现为自研代码（未复制 Klecks 源码），仅借鉴算法思路。
 */
export class BrushController {
  /**
   * @param {any} engine v2 Engine（已 init）
   * @param {any} preset
   * @param {{textures?:any, color?:{r:number,g:number,b:number}}} opts
   */
  constructor(engine, preset, opts = {}) {
    this.engine = engine;
    this.preset = JSON.parse(JSON.stringify(preset));
    this.opts = opts || {};
    /** T52：路径引擎 'bezier'（T43 stamp 管线）| 'perfect-freehand'（压感轮廓填充） */
    this.pathEngine = this.opts.pathEngine || this.preset.pathEngine || 'bezier';
    this.provider = createProviderFromPreset(this.preset, { textures: this.opts.textures, color: this.opts.color, pathEngine: this.pathEngine, engine: this.engine, smudgeFullCanvas: this.opts.smudgeFullCanvas });
    engine.setBrushProvider(this.provider);
    /** T62 工具模式：'brush' | 'smudge'（app 顶栏涂抹按钮接 setMode；默认 brush 行为不变） */
    this._mode = 'brush';
    this._brushPreset = null;
    this._smudgePreset = this.opts.smudgePreset ? JSON.parse(JSON.stringify(this.opts.smudgePreset)) : null;
    this.lastRaw = null;
    this.smoothed = null;
    this.lastSpeed = 0;      // px/ms（EMA）
    this.strokeSeed = 1;
    this.rng = seededRandom(1);
    this.pointCount = 0;
    this.totalDistance = 0;
    /** 贝塞尔路径点队列（最多 8；每个点带 dir 相切方向） */
    this.path = [];
    /** 上一段遗留的「下一个 stamp 距离」 */
    this.pendingDot = 0;
    this.lastSpacing = null;
    /** T52 轮廓模式：上一轮廓点（用于线性加密） */
    this._lastOutlinePoint = null;
    /** T54 鼠标模拟压感配置（app 通过 setSimulatedPressure 修改） */
    this.simulatedPressure = normalizeSimulatedPressure(this.opts.simulatedPressure);
    /** attachBrushInput 注入的输入句柄（用于运行时更新模拟压感配置） */
    this._inputHandle = null;
    this._colorSynced = this.opts.color ? { ...this.opts.color } : null;
  }

  get brushSpec() {
    return { type: this.preset.engine && this.preset.engine.eraser ? 'eraser' : 'brush', sizePx: this.preset.size.base, opacity: this.preset.opacity.base };
  }

  _disposeProvider(p) {
    if (p && typeof p.dispose === 'function') { try { p.dispose(); } catch (e) { /* ignore */ } }
  }

  setPreset(preset) {
    this.preset = JSON.parse(JSON.stringify(preset));
    if (!this.opts.pathEngine) this.pathEngine = this.preset.pathEngine || 'bezier';
    const old = this.engine.getBrushProvider ? this.engine.getBrushProvider() : null;
    this.provider = createProviderFromPreset(this.preset, { textures: this.opts.textures, color: this.opts.color, pathEngine: this.pathEngine, engine: this.engine, smudgeFullCanvas: this.opts.smudgeFullCanvas });
    this.engine.setBrushProvider(this.provider);
    if (old && old !== this.provider) this._disposeProvider(old);
  }

  /**
   * T62：切换工具模式 —— 'smudge' 涂抹（拉像素）/ 'brush' 恢复画笔（app/demo 用）。
   * 只暴露此接口；涂抹 provider 内部只读当前图层已提交 tile 快照，不改 engine。
   * @param {'brush'|'smudge'} mode
   * @param {object} [smudgePreset] 可选自定义涂抹预设（缺省用内置 SMUDGE_PRESET）
   */
  setMode(mode, smudgePreset) {
    const m = mode === 'smudge' ? 'smudge' : 'brush';
    if (m === 'smudge') {
      if (this._mode !== 'smudge') this._brushPreset = JSON.parse(JSON.stringify(this.preset));
      if (smudgePreset) this._smudgePreset = JSON.parse(JSON.stringify(smudgePreset));
      this._mode = 'smudge';
      this.setPreset(this._smudgePreset || SMUDGE_PRESET);
      return this._mode;
    }
    this._mode = 'brush';
    if (this._brushPreset) this.setPreset(this._brushPreset);
    return this._mode;
  }

  getMode() { return this._mode || 'brush'; }
  isSmudge() { return this._mode === 'smudge'; }

  /**
   * T52：切换路径引擎（'bezier' 回退 / 'perfect-freehand' 轮廓），重建 provider
   */
  setPathEngine(name) {
    const next = name === 'perfect-freehand' ? 'perfect-freehand' : 'bezier';
    if (next === this.pathEngine && this.provider && this.provider.pathEngine === next) return next;
    this.pathEngine = next;
    this.opts.pathEngine = next;
    const old = this.engine.getBrushProvider ? this.engine.getBrushProvider() : null;
    this.provider = createProviderFromPreset(this.preset, { textures: this.opts.textures, color: this.opts.color, pathEngine: this.pathEngine, engine: this.engine, smudgeFullCanvas: this.opts.smudgeFullCanvas });
    this.engine.setBrushProvider(this.provider);
    if (old && old !== this.provider) this._disposeProvider(old);
    return this.pathEngine;
  }

  /** 当前是否走 perfect-freehand 轮廓路径（橡皮始终走 stamp 模式） */
  _outlineMode() {
    const p = this.preset;
    return this.pathEngine === 'perfect-freehand' && !(p.engine && p.engine.eraser);
  }

  /**
   * T54：鼠标模拟压感配置（app 面板由 demo-builder T55 接）。
   * @param {{enabled?:boolean, strength?:number, curve?:'linear'|'soft'|'strong', smoothingMs?:number}} opts
   * @returns 归一化后的完整配置
   */
  setSimulatedPressure(opts = {}) {
    this.simulatedPressure = normalizeSimulatedPressure({ ...this.simulatedPressure, ...(opts || {}) });
    if (this._inputHandle && typeof this._inputHandle.setSimulatedPressure === 'function') {
      try { this._inputHandle.setSimulatedPressure(this.simulatedPressure); } catch (e) { /* ignore */ }
    }
    return this.getSimulatedPressure();
  }

  /** T54：读取当前模拟压感配置 */
  getSimulatedPressure() {
    return { ...this.simulatedPressure };
  }

  setColor(rgb) {
    this.opts.color = rgb;
    this._colorSynced = { ...rgb };
    if (this.provider && typeof this.provider.setColor === 'function') this.provider.setColor(rgb);
  }

  setParam(path, value) {
    const parts = path.split('.');
    let o = this.preset;
    for (let i = 0; i < parts.length - 1; i += 1) o = o && o[parts[i]];
    if (o) o[parts[parts.length - 1]] = value;
    if (this.provider) this.provider.preset = this.preset;
  }

  /* ------------------------- 输入 ------------------------- */

  begin(p) {
    const engine = this.engine;
    if (!engine || !engine.ready) throw new Error('engine not ready');
    if (engine.currentStroke) engine.cancelStroke();
    if (this.opts.color && (!this._colorSynced || this._colorSynced.r !== this.opts.color.r || this._colorSynced.g !== this.opts.color.g || this._colorSynced.b !== this.opts.color.b)) {
      this.setColor(this.opts.color);
    }
    this.strokeSeed = (Date.now() % 1e9) + 1;
    this.rng = seededRandom(this.strokeSeed);
    this.pointCount = 0;
    this.totalDistance = 0;
    this.lastSpeed = 0;
    this.path = [];
    this.pendingDot = 0;
    this.lastSpacing = null;
    const pressure = p.pressure == null ? 0.5 : clamp(p.pressure, 0, 1);
    this.lastRaw = { ...p, pressure };
    this.smoothed = { x: p.x, y: p.y, pressure, tiltX: p.tiltX || 0, tiltY: p.tiltY || 0, timestamp: p.timestamp || performance.now(), pointerType: p.pointerType || 'mouse' };
    if (this.provider && typeof this.provider.noteInputSpeed === 'function') this.provider.noteInputSpeed(0);
    engine.beginStroke(this.smoothed, this.brushSpec);
    if (this._outlineMode()) {
      this._lastOutlinePoint = { ...this.smoothed };
      engine.requestFrame();
      return true;
    }
    // 起笔点直接入路径：否则 EMA 稳定化会让「落笔点 → 第一条贝塞尔」之间断开（起笔处孤立小点）
    this._addPathPoint(this.smoothed);
    engine.requestFrame();
    return true;
  }

  append(p) {
    if (!this.engine || !this.engine.currentStroke) return;
    const preset = this.preset;
    // ---- 原始输入速度（px/ms）EMA ----
    const rawTs = p.timestamp || performance.now();
    if (this.lastRaw) {
      const dt = Math.max(0.5, rawTs - (this.lastRaw.timestamp || rawTs));
      const dd = Math.hypot(p.x - this.lastRaw.x, p.y - this.lastRaw.y);
      if (dd > 0.05 && dt > 0.1) {
        const inst = dd / dt;
        this.lastSpeed = lerp(this.lastSpeed, clamp(inst, 0, 8), 0.3);
      }
    }
    if (this.provider && typeof this.provider.noteInputSpeed === 'function') this.provider.noteInputSpeed(this.lastSpeed);

    // ---- 位置 EMA 稳定化（stab 越大越平滑；T43 标定：stab=0.5 → 每事件跟手 0.27，约 3~4 事件滞后） ----
    const stab = clamp(Number((preset.smoothing || {}).stabilizer) || 0, 0, 1);
    const follow = stab > 0 ? clamp(1 / (1 + stab * 5.5), 0.08, 1) : 1;
    this.smoothed = {
      x: lerp(this.smoothed.x, p.x, follow),
      y: lerp(this.smoothed.y, p.y, follow),
      pressure: p.pressure == null ? this.smoothed.pressure : clamp(p.pressure, 0, 1),
      tiltX: p.tiltX || 0,
      tiltY: p.tiltY || 0,
      timestamp: rawTs,
      pointerType: p.pointerType || this.smoothed.pointerType || 'mouse',
    };
    this.lastRaw = { ...p, pressure: this.smoothed.pressure, timestamp: rawTs };
    if (this._outlineMode()) {
      // perfect-freehand 轮廓模式：把平滑点按 ~2–4px 间距线性加密后再交给 engine，
      // 避免指针事件稀疏时轮廓的起收锋被量化成「长箭头」（PF 轮廓顶点按输入点分布）
      this._appendOutline(this.smoothed);
      return;
    }
    this._addPathPoint(this.smoothed);
  }

  /** 轮廓模式：从上一轮廓点插值加密到 p，再 append 到 engine */
  _appendOutline(p) {
    const preset = this.preset;
    const last = this._lastOutlinePoint || { x: p.x, y: p.y, pressure: p.pressure == null ? 0.5 : p.pressure, tiltX: 0, tiltY: 0, timestamp: p.timestamp, pointerType: p.pointerType || 'mouse' };
    const sizeBase = Number(preset.size.base) || 32;
    const step = Math.max(3, sizeBase * 0.12);
    const dx = p.x - last.x, dy = p.y - last.y;
    const dist = Math.hypot(dx, dy);
    const n = Math.min(64, Math.floor(dist / step));
    for (let i = 1; i <= n; i += 1) {
      const t = i / (n + 1);
      this.engine.appendPoint({
        x: lerp(last.x, p.x, t),
        y: lerp(last.y, p.y, t),
        pressure: lerp(last.pressure, p.pressure == null ? 0.5 : p.pressure, t),
        tiltX: lerp(last.tiltX || 0, p.tiltX || 0, t),
        tiltY: lerp(last.tiltY || 0, p.tiltY || 0, t),
        timestamp: last.timestamp + (p.timestamp - last.timestamp) * t,
        pointerType: p.pointerType || last.pointerType || 'mouse',
      }, { flush: false });
    }
    this.engine.appendPoint({
      x: p.x, y: p.y,
      pressure: p.pressure == null ? 0.5 : p.pressure,
      tiltX: p.tiltX || 0, tiltY: p.tiltY || 0,
      timestamp: p.timestamp || performance.now(),
      pointerType: p.pointerType || 'mouse',
    }, { flush: false });
    this._lastOutlinePoint = {
      x: p.x, y: p.y,
      pressure: p.pressure == null ? 0.5 : p.pressure,
      tiltX: p.tiltX || 0, tiltY: p.tiltY || 0,
      timestamp: p.timestamp || performance.now(),
      pointerType: p.pointerType || 'mouse',
    };
    this.engine.requestFrame();
  }

  /** 估算某点的笔尖半径（用于间距；与 provider.radiusFor 同公式，忽略 taperEnd） */
  _radiusAt(point) {
    const preset = this.preset;
    const dyn = preset.dynamics || {};
    const pressure = clamp(point.pressure == null ? 0.5 : point.pressure, 0, 1);
    const tilt = clamp(Math.hypot(point.tiltX || 0, point.tiltY || 0) / 60, 0, 1);
    let r = (Number(preset.size.base) || 32) * 0.5 * curveAt(preset.size.pressureCurve, pressure);
    if (dyn.tiltSizeFactor) r *= clamp(1 + dyn.tiltSizeFactor * tilt * 0.75, 0.1, 2.5);
    if (dyn.speedSizeFactor) {
      const norm = clamp(this.lastSpeed / 2.4, 0, 1);
      const w = (point.pointerType === 'pen') ? 1 : 0.35;
      r *= clamp(1 + dyn.speedSizeFactor * (norm - 0.35) * w * 1.6, 0.1, 2.6);
    }
    const taperStart = clamp(Number((preset.taper || {}).start) || 0, 0, 1);
    if (taperStart > 0) {
      const len = Math.max(6, (Number(preset.size.base) || 32) * taperStart * 2.6);
      const f = clamp(this.totalDistance / len, 0.12, 1);
      r *= 0.12 + 0.88 * f;
    }
    return Math.max(0.35, r);
  }

  _spacingAt(point) {
    const sp = this.preset.spacing || { ratio: 0.1, minPx: 0.5 };
    const ratio = clamp(Number(sp.ratio) || 0.1, 0.01, 1.5);
    const minPx = clamp(Number(sp.minPx) || 0.5, 0.1, 8);
    return Math.max(minPx, this._radiusAt(point) * 2 * ratio);
  }

  /** 添加一个平滑后的路径点；凑够 3 点后用贝塞尔补齐中间那一段 */
  _addPathPoint(pt) {
    const arr = this.path;
    const last = arr[arr.length - 1];
    if (last && Math.hypot(last.x - pt.x, last.y - pt.y) < 0.01) return;
    const point = {
      x: pt.x, y: pt.y,
      pressure: clamp(pt.pressure == null ? 0.5 : pt.pressure, 0, 1),
      tiltX: pt.tiltX || 0, tiltY: pt.tiltY || 0,
      timestamp: pt.timestamp || performance.now(),
      pointerType: pt.pointerType || 'mouse',
    };
    arr.push(point);
    if (arr.length > 8) arr.shift();
    const n = arr.length;
    if (n < 2) return;
    if (n === 2) {
      arr[0].dir = norm2(point.x - arr[0].x, point.y - arr[0].y);
      point.dir = arr[0].dir;
      const sp = this._spacingAt(point);
      this.lastSpacing = sp;
      this.pendingDot = sp;
      return;
    }
    // 中间点相切方向 = (后点 - 前点) 归一化 → 贝塞尔在点处 G1 连续
    const a = arr[n - 3], b = arr[n - 2], c = arr[n - 1];
    b.dir = norm2(c.x - a.x, c.y - a.y);
    this._emitSegment(a, b);
  }

  /** 生成 a→b 的三次贝塞尔并按弧长间距 emit stamps；间距在段间线性过渡 */
  _emitSegment(a, b) {
    const dx = b.x - a.x, dy = b.y - a.y;
    const len = Math.hypot(dx, dy);
    if (!(len > 0.01)) return;
    const fallback = norm2(dx, dy);
    const aDir = a.dir || fallback;
    const bDir = b.dir || fallback;
    // 控制点：沿相切方向 1/4 弦长（Catmull-Rom 风格，Klecks BezierLine 同思路）
    const p2 = { x: a.x + aDir.x * len / 4, y: a.y + aDir.y * len / 4 };
    const p3 = { x: b.x - bDir.x * len / 4, y: b.y - bDir.y * len / 4 };
    const res = Math.max(10, Math.min(80, Math.ceil(len / 3)));
    const pts = new Array(res + 1);
    for (let i = 0; i <= res; i += 1) {
      const t = i / res, it = 1 - t;
      const w0 = it * it * it, w1 = 3 * it * it * t, w2 = 3 * it * t * t, w3 = t * t * t;
      pts[i] = {
        x: w0 * a.x + w1 * p2.x + w2 * p3.x + w3 * b.x,
        y: w0 * a.y + w1 * p2.y + w2 * p3.y + w3 * b.y,
      };
    }
    // 弧长表
    const cum = new Array(res + 1);
    cum[0] = 0;
    for (let i = 1; i <= res; i += 1) cum[i] = cum[i - 1] + Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
    const total = cum[res];
    if (!(total > 0.01)) return;
    const spB = this._spacingAt(b);
    const spA = this.lastSpacing == null ? spB : this.lastSpacing;
    const maxStamps = clamp(Number((this.preset.performance || {}).maxStampsPerFrame) || 2048, 32, 8192);
    let d = this.pendingDot;
    let guard = 0;
    let idx = 1;
    while (d <= total && guard < maxStamps) {
      guard += 1;
      // 定位弧长 d 所在的折线段
      while (idx < res && cum[idx] < d) idx += 1;
      const segLen = cum[idx] - cum[idx - 1] || 1;
      const tSeg = clamp((d - cum[idx - 1]) / segLen, 0, 1);
      const x = lerp(pts[idx - 1].x, pts[idx].x, tSeg);
      const y = lerp(pts[idx - 1].y, pts[idx].y, tSeg);
      const t = d / total;
      const tiltX = lerp(a.tiltX, b.tiltX, t);
      const tiltY = lerp(a.tiltY, b.tiltY, t);
      this._emit({
        x, y,
        pressure: lerp(a.pressure, b.pressure, t),
        tiltX, tiltY,
        timestamp: lerp(a.timestamp, b.timestamp, t),
        pointerType: b.pointerType,
        distance: this.totalDistance + d,
      });
      const spacing = lerp(spA, spB, clamp(t, 0, 1));
      d += spacing;
    }
    this.pendingDot = guard >= maxStamps ? 0 : Math.max(0, d - total);
    this.lastSpacing = spB;
    this.totalDistance += total;
    this.engine.requestFrame();
  }

  _emit(p) {
    const preset = this.preset;
    this.pointCount += 1;
    const scatter = preset.scatter || { count: 1, positionJitter: 0 };
    const count = clamp(Math.floor(scatter.count) || 1, 1, 16);
    const base = { x: p.x, y: p.y, pressure: p.pressure, tiltX: p.tiltX, tiltY: p.tiltY, timestamp: p.timestamp, pointerType: p.pointerType };
    const radius = this._radiusAt(p);
    const jitterAmp = clamp(Number(scatter.positionJitter) || 0, 0, 1) * radius;
    for (let i = 0; i < count; i += 1) {
      const jitter = i === 0 || jitterAmp <= 0 ? { x: 0, y: 0 } : {
        x: (this.rng() - 0.5) * 2 * jitterAmp,
        y: (this.rng() - 0.5) * 2 * jitterAmp,
      };
      this.engine.appendPoint({ ...base, x: p.x + jitter.x, y: p.y + jitter.y }, { flush: false });
    }
  }

  /** 收笔追尾：把稳定化落后的 smoothed 补到真实笔尖，然后补画最后一段 */
  _flushTail() {
    const raw = this.lastRaw;
    if (!raw || !this.engine || !this.engine.currentStroke) return;
    const last = this.path[this.path.length - 1];
    if (last && Math.hypot(raw.x - last.x, raw.y - last.y) > 0.8) {
      this._addPathPoint({
        x: raw.x, y: raw.y,
        pressure: raw.pressure == null ? last.pressure : raw.pressure,
        tiltX: raw.tiltX || 0, tiltY: raw.tiltY || 0,
        timestamp: raw.timestamp || performance.now(),
        pointerType: raw.pointerType || 'mouse',
      });
    }
    // 补齐最后一段（最后一个点之后不会再触发 _emitSegment）
    const arr = this.path;
    if (arr.length >= 2) {
      const a = arr[arr.length - 2], b = arr[arr.length - 1];
      const fb = norm2(b.x - a.x, b.y - a.y);
      if (!a.dir) a.dir = fb;
      if (!b.dir) b.dir = norm2(b.x - (arr.length >= 3 ? arr[arr.length - 3].x : a.x), b.y - (arr.length >= 3 ? arr[arr.length - 3].y : a.y));
      this._emitSegment(a, b);
    }
  }

  /**
   * 收笔收锋（临时方案）：engine 的 provider.end(ctx) 不提供 canvas，无法重绘；
   * 这里在 endStroke() 之前缩放本笔 records 尾部 stamp 的 radius（+taperAlpha），
   * 只操作 engine.currentStroke.records（本笔临时对象），不改 engine 源码。
   */
  _applyEndTaper() {
    const taper = (this.preset && this.preset.taper) || {};
    const end = clamp(Number(taper.end) || 0, 0, 1);
    if (end <= 0) return 0;
    const stroke = this.engine && this.engine.currentStroke;
    const recs = stroke && stroke.records;
    if (!Array.isArray(recs) || recs.length < 3) return 0;
    const total = recs[recs.length - 1].distance || 0;
    const len = Math.max(8, (Number(this.preset.size.base) || 32) * end * 2.4);
    if (total < len * 0.8) return 0;
    let touched = 0;
    for (const rec of recs) {
      const dist = rec.distance || 0;
      if (dist < total - len) continue;
      const t = clamp((total - dist) / len, 0, 1);
      const f = 0.1 + 0.9 * Math.sqrt(t);
      rec.radius = Math.max(0.3, (rec.radius || 1) * f);
      rec.taperAlpha = 0.35 + 0.65 * t;
      touched += 1;
    }
    return touched;
  }

  end() {
    if (!this.engine || !this.engine.currentStroke) return null;
    if (this._outlineMode()) {
      // 轮廓模式：补最后一笔尖点（确保轮廓覆盖松手位置）；收笔 taper 由 perfect-freehand end.taper 原生处理
      const raw = this.lastRaw;
      const last = this._lastOutlinePoint;
      if (raw && (!last || Math.hypot(raw.x - last.x, raw.y - last.y) > 0.3)) {
        this._appendOutline({
          x: raw.x, y: raw.y,
          pressure: raw.pressure == null ? 0.5 : raw.pressure,
          tiltX: raw.tiltX || 0, tiltY: raw.tiltY || 0,
          timestamp: raw.timestamp || performance.now(),
          pointerType: raw.pointerType || 'mouse',
        });
      }
      return this.engine.endStroke();
    }
    this._flushTail();
    this._applyEndTaper();
    return this.engine.endStroke();
  }

  cancel() {
    if (this.engine && this.engine.currentStroke) this.engine.cancelStroke();
  }

  undo() { return this.engine.undo(); }
  redo() { return this.engine.redo(); }

  /** 调试快照（真实浏览器诊断用） */
  getDebugInfo() {
    let recs = null;
    try { recs = this.engine.currentStroke ? this.engine.currentStroke.records.length : 0; } catch (e) { recs = 'err'; }
    return {
      preset: this.preset.id,
      provider: this.provider && this.provider.id,
      pathEngine: this.pathEngine,
      outline: this._outlineMode(),
      mode: this.getMode(),
      smudge: this.isSmudge(),
      eraser: !!(this.preset.engine && this.preset.engine.eraser),
      pointCount: this.pointCount,
      totalDistance: Math.round(this.totalDistance * 10) / 10,
      speed: Math.round(this.lastSpeed * 100) / 100,
      pathPoints: this.path.length,
      records: recs,
      providerStats: this.provider && typeof this.provider.getStats === 'function' ? this.provider.getStats() : null,
    };
  }
}

/** 输入接入：Pointer Events + coalesced + 鼠标模拟压感（T54：速度+加速度+方向变化，可配置） */
export function attachBrushInput(controller, canvas) {
  let active = false;
  const sim = createMousePressureSimulator(controller.getSimulatedPressure ? controller.getSimulatedPressure() : {});
  /** 供测试/调试读取的压力轨迹（每事件一条；非生产路径不依赖） */
  controller._pressureTrace = [];
  /** T54：app/demo 运行时更新模拟压感参数 */
  controller._inputHandle = {
    setSimulatedPressure(opts) { sim.setOptions(opts); },
    getSimulatedPressure() { return sim.getConfig(); },
  };

  function toPoint(e) {
    const rect = canvas.getBoundingClientRect();
    const sx = canvas.width / Math.max(1, rect.width);
    const sy = canvas.height / Math.max(1, rect.height);
    const pointerType = e.pointerType || 'mouse';
    let pressure = e.pressure;
    if (pointerType === 'pen') {
      // 有真实手绘板：真实压力优先，不经过模拟器
      if (!(pressure > 0 && pressure <= 1)) pressure = 0.5;
      pressure = clamp(pressure, 0.02, 1);
    } else {
      pressure = 0.5; // 占位，down/move 里由模拟器覆盖
    }
    return {
      x: (e.clientX - rect.left) * sx,
      y: (e.clientY - rect.top) * sy,
      pressure,
      tiltX: e.tiltX || 0,
      tiltY: e.tiltY || 0,
      timestamp: e.timeStamp || performance.now(),
      pointerType,
    };
  }
  function applySimulated(p) {
    if (p.pointerType === 'pen') {
      // 真实压感优先；仅记录轨迹（source=pen）便于回归
      if (controller._pressureTrace && controller._pressureTrace.length < 5000) {
        controller._pressureTrace.push({ t: p.timestamp, pressure: p.pressure, speed: 0, source: 'pen' });
      }
      return p;
    }
    const r = sim.update(p);
    p.pressure = r.pressure;
    if (controller._pressureTrace && controller._pressureTrace.length < 5000) {
      controller._pressureTrace.push({ t: p.timestamp, pressure: r.pressure, speed: Math.round(r.speed * 100) / 100, source: 'sim' });
    }
    return p;
  }
  function down(e) {
    if (active || (e.button != null && e.button !== 0)) return;
    e.preventDefault();
    active = true;
    try { canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId); } catch (err) { /* synthetic events may throw */ }
    const p = toPoint(e);
    sim.reset(p.timestamp);
    controller.begin(applySimulated(p));
  }
  function move(e) {
    if (!active) return;
    e.preventDefault();
    const events = typeof e.getCoalescedEvents === 'function' ? e.getCoalescedEvents() : null;
    const list = events && events.length ? events : [e];
    for (const ev of list) {
      controller.append(applySimulated(toPoint(ev)));
    }
  }
  function up(e) {
    if (!active) return;
    active = false;
    try { canvas.releasePointerCapture && canvas.releasePointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    controller.end();
  }
  function cancel() { if (active) { active = false; controller.cancel(); } }
  canvas.addEventListener('pointerdown', down);
  canvas.addEventListener('pointermove', move);
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', cancel);
  canvas.style.touchAction = 'none';
  return () => {
    canvas.removeEventListener('pointerdown', down);
    canvas.removeEventListener('pointermove', move);
    canvas.removeEventListener('pointerup', up);
    canvas.removeEventListener('pointercancel', cancel);
    controller._inputHandle = null;
  };
}
