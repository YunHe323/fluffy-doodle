// v2/app/test-pressure-panel.mjs — T55 模拟压感面板回归（headless Chrome + CDP）
// 覆盖：面板存在/1366×768 不溢出/开关与参数持久化/切笔刷与橡皮不丢/（T54 就绪后）同速度线宽度指标
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT_HTTP = 8104;
const PORT_CDP = 9416;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const python = spawn('python', ['-m', 'http.server', String(PORT_HTTP), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
await sleep(900);
const profile = path.join(os.tmpdir(), 'simptest-' + Date.now());
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist',
  '--window-size=1366,768', '--hide-scrollbars',
  `--remote-debugging-port=${PORT_CDP}`, `--user-data-dir=${profile}`,
  `http://127.0.0.1:${PORT_HTTP}/v2/app/index.html`,
], { stdio: 'ignore' });
let target = null;
for (let i = 0; i < 240 && !target; i++) {
  try { const r = await fetch(`http://127.0.0.1:${PORT_CDP}/json/list`); target = (await r.json()).find((t) => t.type === 'page' && t.url.startsWith('http')); } catch (e) {}
  if (!target) await sleep(200);
}
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map(); const errors = [];
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); return; } if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text); if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push(m.params.args.map((a) => a.value || a.description).join(' ')); };
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
async function ev(expression) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true });
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1200));
  return r.result?.result?.value;
}
const out = { schema: 'mozheng.app.pressure-panel-test.v1', cases: {} };
async function widthStats() {
  return ev(`(async () => {
    const e = window.__V2_APP__.engine; e.compositor.compositeAll(e.store);
    const url = await e.getCompositeDataUrl();
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    const widths = [];
    for (let x = 260; x < c.width - 60; x += 4) {
      let count = 0;
      for (let y = 120; y < Math.min(c.height, 700); y += 1) {
        const i = (y * c.width + x) * 4;
        if (d[i + 3] > 0 && d[i] < 220) count += 1;
      }
      if (count > 0) widths.push(count);
    }
    if (!widths.length) return { count: 0, median: 0, mean: 0, cv: 0 };
    widths.sort((a, b) => a - b);
    const mean = widths.reduce((s, v) => s + v, 0) / widths.length;
    const variance = widths.reduce((s, v) => s + (v - mean) * (v - mean), 0) / widths.length;
    return { count: widths.length, median: widths[Math.floor(widths.length / 2)], mean: +mean.toFixed(2), cv: +(Math.sqrt(variance) / mean).toFixed(3) };
  })()`);
}
try {
  await send('Runtime.enable'); await send('Page.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: 1366, height: 768, deviceScaleFactor: 1, mobile: false });
  for (let i = 0; i < 600; i++) { if (await ev('!!window.__V2_APP_READY__').catch(() => false)) break; await sleep(200); }
  out.ready = await ev('!!window.__V2_APP_READY__');
  out.defaults = await ev(`(() => ({ cfg: window.__V2_APP__.state.simPressure, smoothing: document.getElementById('simPressureSmoothing').value, smoothingLabel: document.getElementById('simPressureSmoothingVal').textContent }))()`);
  out.cases.defaults = out.defaults.cfg && out.defaults.cfg.smoothingMs === 65 && out.defaults.cfg.startPressure === 0.3 && out.defaults.cfg.catchUp === true && out.defaults.cfg.speedTauMs === 50 && out.defaults.smoothing === '65' && out.defaults.smoothingLabel === '65ms';
  // 迁移：旧 key 旧默认 -> 新默认
  await ev(`(() => { localStorage.removeItem('mozheng.v2.simPressure.v2'); localStorage.setItem('mozheng.v2.simPressure.v1', JSON.stringify({ enabled: true, strength: 1, curve: 'soft', smoothingMs: 45 })); })()`);
  await send('Page.reload');
  for (let i = 0; i < 600; i++) { if (await ev('!!window.__V2_APP_READY__').catch(() => false)) break; await sleep(200); }
  await sleep(300);
  out.migrateDefault = await ev(`(() => ({ v2: JSON.parse(localStorage.getItem('mozheng.v2.simPressure.v2') || 'null'), cfg: window.__V2_APP__.state.simPressure }))()`);
  out.cases.migrateDefault = !!out.migrateDefault.v2 && out.migrateDefault.v2.smoothingMs === 65 && out.migrateDefault.v2.startPressure === 0.3 && out.migrateDefault.v2.catchUp === true && out.migrateDefault.v2.speedTauMs === 50;
  // 迁移：旧 key 自定义值 -> 保留自定义 + 补齐新字段
  await ev(`(() => { localStorage.removeItem('mozheng.v2.simPressure.v2'); localStorage.setItem('mozheng.v2.simPressure.v1', JSON.stringify({ enabled: false, strength: 1.6, curve: 'strong', smoothingMs: 70 })); })()`);
  await send('Page.reload');
  for (let i = 0; i < 600; i++) { if (await ev('!!window.__V2_APP_READY__').catch(() => false)) break; await sleep(200); }
  await sleep(300);
  out.migrateCustom = await ev(`(() => ({ v2: JSON.parse(localStorage.getItem('mozheng.v2.simPressure.v2') || 'null'), checked: document.getElementById('simPressureEnabled').checked }))()`);
  out.cases.migrateCustom = !!out.migrateCustom.v2 && out.migrateCustom.v2.enabled === false && out.migrateCustom.v2.strength === 1.6 && out.migrateCustom.v2.curve === 'strong' && out.migrateCustom.v2.smoothingMs === 70 && out.migrateCustom.v2.startPressure === 0.3;
  // 恢复默认，供后续 UI 测试
  await ev(`(() => { localStorage.removeItem('mozheng.v2.simPressure.v1'); localStorage.removeItem('mozheng.v2.simPressure.v2'); })()`);
  await send('Page.reload');
  for (let i = 0; i < 600; i++) { if (await ev('!!window.__V2_APP_READY__').catch(() => false)) break; await sleep(200); }
  await sleep(300);

  out.ui = await ev(`(() => {
    const p = document.getElementById('simPressurePanel');
    const panelRect = p ? p.getBoundingClientRect() : null;
    return {
      panel: !!p, enabled: !!document.getElementById('simPressureEnabled'), strength: !!document.getElementById('simPressureStrength'),
      curve: !!document.getElementById('simPressureCurve'), smoothing: !!document.getElementById('simPressureSmoothing'),
      docScrollWidth: document.documentElement.scrollWidth, innerWidth: window.innerWidth,
      docScrollHeight: document.documentElement.scrollHeight, innerHeight: window.innerHeight,
      panelHeight: panelRect ? Math.round(panelRect.height) : 0,
      sidebarScrollable: (() => { const s = document.getElementById('sidebar'); return s ? s.scrollHeight > s.clientHeight : null; })(),
      supported: typeof window.__V2_APP__.controller.setSimulatedPressure === 'function',
    };
  })()`);
  out.cases.uiPresent = out.ui.panel && out.ui.enabled && out.ui.strength && out.ui.curve && out.ui.smoothing;
  out.cases.noHorizontalOverflow = out.ui.docScrollWidth <= out.ui.innerWidth;
  out.cases.noPageVerticalOverflow = out.ui.docScrollHeight <= out.ui.innerHeight + 2;
  // 调参并持久化
  out.uiSet = await ev(`(() => {
    const en = document.getElementById('simPressureEnabled'); en.checked = false; en.dispatchEvent(new Event('change', { bubbles: true }));
    const st = document.getElementById('simPressureStrength'); st.value = '1.6'; st.dispatchEvent(new Event('input', { bubbles: true }));
    const cv = document.getElementById('simPressureCurve'); cv.value = 'strong'; cv.dispatchEvent(new Event('change', { bubbles: true }));
    const sm = document.getElementById('simPressureSmoothing'); sm.value = '65'; sm.dispatchEvent(new Event('input', { bubbles: true }));
    return JSON.parse(localStorage.getItem('mozheng.v2.simPressure.v2') || 'null');
  })()`);
  out.cases.persistWrite = !!out.uiSet && out.uiSet.enabled === false && out.uiSet.curve === 'strong' && out.uiSet.strength === 1.6 && out.uiSet.smoothingMs === 65;
  // 切笔刷/橡皮后 localStorage 不丢 + UI 保持
  out.afterToolSwitch = await ev(`(async () => {
    document.querySelectorAll('#brushGrid .brush-chip')[8].click();
    document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'e', bubbles: true }));
    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'e' }));
    await new Promise(r => setTimeout(r, 200));
    return { ls: JSON.parse(localStorage.getItem('mozheng.v2.simPressure.v2') || 'null'), provider: window.__V2_APP__.engine.getBrushProvider().id, enabledChecked: document.getElementById('simPressureEnabled').checked };
  })()`);
  out.cases.survivesSwitch = !!out.afterToolSwitch.ls && out.afterToolSwitch.ls.curve === 'strong' && out.afterToolSwitch.provider === 't36-eraser';
  // 刷新持久化
  await send('Page.reload');
  for (let i = 0; i < 600; i++) { if (await ev('!!window.__V2_APP_READY__').catch(() => false)) break; await sleep(200); }
  await sleep(400);
  out.afterReload = await ev(`(() => ({ ls: JSON.parse(localStorage.getItem('mozheng.v2.simPressure.v2') || 'null'), checked: document.getElementById('simPressureEnabled').checked, strength: document.getElementById('simPressureStrength').value, curve: document.getElementById('simPressureCurve').value, smoothing: document.getElementById('simPressureSmoothing').value }))()`);
  out.cases.persistReload = !!out.afterReload.ls && out.afterReload.ls.curve === 'strong' && out.afterReload.checked === false && out.afterReload.curve === 'strong';
  // T54 就绪：用真实 pointer（走模拟器）画同样的“先快后慢”线，开/关对比宽度 CV
  if (out.ui.supported) {
    await ev(`(() => {
      const st = JSON.parse(localStorage.getItem('mozheng.v2.simPressure.v2') || 'null') || { enabled: true, strength: 1, curve: 'soft', smoothingMs: 45 };
      st.enabled = false; localStorage.setItem('mozheng.v2.simPressure.v2', JSON.stringify(st));
      window.__V2_APP__.controller.setSimulatedPressure(st);
    })()`);
    const drawPointer = async () => {
      const rect = await ev(`(() => { const r = document.getElementById('mainCanvas').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
      const sx = (docX) => rect.x + rect.w * (docX / 1200);
      const sy = (docY) => rect.y + rect.h * (docY / 800);
      await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: sx(160), y: sy(320), button: 'left', clickCount: 1 });
      let x = 160;
      for (let i = 1; i <= 48; i += 1) {
        x += 15;
        await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: sx(x), y: sy(320), button: 'left', buttons: 1 });
        const wait = i < 16 ? 4 : (i < 32 ? 22 : 55); // 先快 → 后慢
        await sleep(wait);
      }
      await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: sx(x), y: sy(320), button: 'left', clickCount: 1 });
      await sleep(400);
    };
    // off
    await drawPointer();
    out.widthOff = await widthStats();
    await ev('window.__V2_APP__.engine.undo()');
    // on（强度 2 / strong / 平滑 45）
    await ev(`(() => {
      const st = { enabled: true, strength: 2, curve: 'strong', smoothingMs: 45 };
      localStorage.setItem('mozheng.v2.simPressure.v2', JSON.stringify(st));
      window.__V2_APP__.controller.setSimulatedPressure(st);
    })()`);
    await drawPointer();
    out.widthOn = await widthStats();
    out.cases.pressureEffect = out.widthOn.cv > out.widthOff.cv + 0.03 || out.widthOn.median > out.widthOff.median * 1.2;
  } else {
    out.widthOn = null; out.widthOff = null;
    out.cases.pressureEffect = null;
    out.pending = 'T54 controller.setSimulatedPressure 未就绪，面板/持久化已验证；宽度指标待 T54 完成后补跑';
  }
  out.errors = errors.slice(0, 8);
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'pressure-panel-1366.png'), Buffer.from(shot.result.data, 'base64'));
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e.stack || e); out.errors = errors.slice(0, 8);
  console.log(JSON.stringify(out, null, 2));
} finally {
  try { ws.close(); } catch (e) {}
  chrome.kill(); python.kill(); await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
  fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'test-pressure-panel-result.json'), JSON.stringify(out, null, 2), 'utf8');
  process.exit(0);
}
