#!/usr/bin/env node
/**
 * 端口卫生自检 —— 2026-11-08 整改轮新增（零依赖 · 只读 · 不修改任何被测文件）
 *
 * 背景：P0-1 的代码修复只影响**新启动**的 v2/serve.mjs 实例。
 * 实测曾出现「磁盘上已修复、但 4201 端口仍是 01:10 启动的旧实例」，
 * 该旧实例把内存里的旧路由继续对外提供，GET /v2/.ai-config.json 仍返回 200。
 * 因此除了改代码，还必须在**运行期**对每个本地端口做一次黑盒复核。
 *
 * 本脚本做什么：
 *   1. 扫描可配置的本地端口范围（默认 4200–4210），找出正在监听的 HTTP 服务；
 *   2. 用 /health 识别哪些是 v2/serve.mjs 实例（记录 pid / port）；
 *   3. 对任何能提供 /v2/app/index.html 的服务，逐一请求敏感路径；
 *   4. 只要出现 200 且响应体里疑似含密钥/令牌内容，即判 FAIL（退出码 1）；
 *   5. 输出 JSON 证据到 v2/qa/tools/port-hygiene-result.json。
 *
 * 本脚本不做什么：
 *   - 不启动、不停止任何服务（避免替用户做破坏性操作）；
 *   - 不打印任何密钥明文，只输出布尔判定与字节数；
 *   - 不扫描非本地地址，只访问 127.0.0.1。
 *
 * 运行：node v2/qa/tools/port-hygiene.mjs
 *       node v2/qa/tools/port-hygiene.mjs --ports 4200-4210,8182
 *       node v2/qa/tools/port-hygiene.mjs --json /path/to/result.json
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function argValue(flag, fallback) {
  const i = process.argv.indexOf(flag);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}
function parsePorts(spec) {
  const set = new Set();
  for (const part of String(spec).split(',')) {
    const m = part.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
    if (!m) continue;
    const a = Number(m[1]);
    const b = m[2] ? Number(m[2]) : a;
    for (let p = Math.min(a, b); p <= Math.max(a, b); p += 1) {
      if (p > 0 && p < 65536) set.add(p);
    }
  }
  return [...set].sort((x, y) => x - y);
}

const PORTS = parsePorts(argValue('--ports', '4200-4210'));
const OUT_JSON = path.resolve(argValue('--json', path.join(__dirname, 'port-hygiene-result.json')));

// 敏感路径：与 v2/serve.mjs 的 blockedStaticPath() 白名单互为对照
const SENSITIVE_PATHS = [
  '/v2/.ai-config.json',
  '/.ai-config.json',
  '/v2/.ai-token',
  '/.ai-token',
  '/v2/.runtime-port',
  '/v2/.env',
  '/backups/',
  '/submission/',
  '/stage.zip',
  '/阶段成果_墨证v2_2026-11-07.zip',
];

// 判定「响应体疑似含真实凭据」：只看形态，不输出内容
function looksLikeCredential(body) {
  if (!body) return false;
  if (/"(?:apiKey|secretKey|secretId|access_token|token)"\s*:\s*"[^"\s]{12,}"/i.test(body)) return true;
  if (/\bsk-[A-Za-z0-9_-]{20,}\b/.test(body)) return true;
  if (/^\s*[A-Za-z0-9_\-]{32,}\s*$/.test(body) && !body.includes(' ')) return true; // .ai-token 类纯令牌文件
  return false;
}

async function probe(port, urlPath, timeoutMs = 1200) {
  const url = `http://127.0.0.1:${port}${urlPath}`;
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(timeoutMs), redirect: 'manual' });
    let body = '';
    try { body = await res.text(); } catch (e) { /* ignore */ }
    return { status: res.status, bytes: Buffer.byteLength(body), credentialLike: looksLikeCredential(body) };
  } catch (e) {
    return { status: 0, bytes: 0, credentialLike: false, error: String(e && e.message || e).slice(0, 120) };
  }
}

const out = {
  schema: 'mozheng.qa.port-hygiene.v1',
  startedAt: new Date().toISOString(),
  env: { node: process.version, platform: process.platform, portsScanned: PORTS, host: '127.0.0.1' },
  scope: '只读探测：不启停服务、不输出密钥明文、不扫描非本地地址',
  ports: [],
  checks: [],
  leaks: [],
  notes: [],
  pass: false,
};

function addCheck(id, title, pass, actual) {
  out.checks.push({ id, title, pass: !!pass, actual });
}

for (const port of PORTS) {
  const health = await probe(port, '/health', 900);
  const entry = { port, reachable: health.status > 0, health, isServeInstance: false, appServed: false, probes: [] };
  // /health 由 v2/serve.mjs 返回 {ok:true,port,pid}；probe 不返回 body，这里单独取一次
  if (health.status === 200) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/health`, { signal: AbortSignal.timeout(900) });
      const t = await r.text();
      entry.isServeInstance = /"ok"\s*:\s*true/i.test(t) && /"pid"/i.test(t);
      if (entry.isServeInstance) {
        try { const j = JSON.parse(t); entry.pid = j.pid; entry.reportedPort = j.port; } catch (e) { /* ignore */ }
      }
    } catch (e) { /* ignore */ }
  }

  const app = await probe(port, '/v2/app/index.html', 1200);
  entry.appServed = app.status === 200;

  if (entry.reachable) {
    for (const p of SENSITIVE_PATHS) {
      const r = await probe(port, p, 1200);
      const leaked = r.status === 200 && (r.credentialLike || /\.(?:json|token|env|zip)$|backups|submission/i.test(p));
      const row = { path: p, ...r, verdict: r.status === 0 ? 'UNREACHABLE' : (leaked ? 'LEAK' : (r.status === 200 ? 'OPEN-BUT-INNOCUOUS' : 'BLOCKED')) };
      entry.probes.push(row);
      if (leaked) {
        out.leaks.push({ port, pid: entry.pid || null, path: p, status: r.status, bytes: r.bytes, credentialLike: r.credentialLike });
      }
    }
  }
  out.ports.push(entry);
}

const live = out.ports.filter((p) => p.reachable);
const appPorts = live.filter((p) => p.appServed);
addCheck('H1', '扫描完成：记录所有可达端口', live.length >= 0, { scanned: PORTS.length, reachable: live.map((p) => p.port) });
addCheck('H2', '所有提供 /v2/app/index.html 的本地服务都阻断敏感静态路径',
  out.leaks.length === 0,
  { appPorts: appPorts.map((p) => p.port), leaks: out.leaks.map((l) => `${l.port}${l.path}=${l.status}`) });
addCheck('H3', '当前可达的 v2/serve.mjs 实例均通过 H2',
  live.filter((p) => p.isServeInstance).every((p) => !out.leaks.some((l) => l.port === p.port)),
  { serveInstances: live.filter((p) => p.isServeInstance).map((p) => ({ port: p.port, pid: p.pid || null })) });

if (out.leaks.length) {
  out.notes.push('存在敏感路径可读端口：请勿只依赖磁盘上的代码修复，必须停止旧实例并重新启动 v2/serve.mjs（Node 不会热更新已载入内存的模块）。');
}
if (!live.length) {
  out.notes.push('没有任何可达端口：此时无法证明运行期安全，属「未启动」而非「已通过运行期验证」。');
}
out.pass = out.checks.every((c) => c.pass) && out.leaks.length === 0;
out.finishedAt = new Date().toISOString();

fs.mkdirSync(path.dirname(OUT_JSON), { recursive: true });
fs.writeFileSync(OUT_JSON, JSON.stringify(out, null, 2) + '\n', 'utf8');

console.log(`[port-hygiene] 扫描端口 ${PORTS.length} 个，可达 ${live.length} 个：${live.map((p) => p.port).join(', ') || '（无）'}`);
for (const p of live) {
  const blocked = p.probes.filter((r) => r.verdict === 'BLOCKED').length;
  console.log(`  port=${p.port}${p.pid ? ` pid=${p.pid}` : ''} serve=${p.isServeInstance} app=${p.appServed} 阻断 ${blocked}/${p.probes.length}`);
}
if (out.leaks.length) {
  for (const l of out.leaks) console.log(`  [LEAK] port=${l.port} ${l.path} -> ${l.status} (${l.bytes}B, credentialLike=${l.credentialLike})`);
}
console.log(`[port-hygiene] pass=${out.pass} leaks=${out.leaks.length} 结果=${OUT_JSON}`);
process.exit(out.pass ? 0 : 1);
