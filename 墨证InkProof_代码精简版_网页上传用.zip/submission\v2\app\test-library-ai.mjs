// v2/app/test-library-ai.mjs —— 素材库 × AI：多参考素材进入生成 / 结果存回素材库
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8157;
const out = { schema: 'mozheng.app.library-ai.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  fs.writeFileSync(ROOT + '\\v2\\app\\test-library-ai-result.json', JSON.stringify(out, null, 2), 'utf8');
  process.exit(code);
};
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1200);
  await page.evaluate(() => { const a = window.__V2_APP__; a.t96.setToggles({ allowReal: false, privacyMode: true }); a.state.selection = { x: 320, y: 240, width: 360, height: 260 }; a.openPopover('popAI'); a.switchAiTab('image'); });
  await page.waitForFunction(() => document.querySelectorAll('#aiImageBody [data-ref-pick]').length > 0, null, { timeout: 15000 });
  const beforeAssets = await page.evaluate(() => (window.__V2_APP__.state.library.assets || []).length);
  await page.locator('#aiImageBody [data-ref-pick]').first().click();
  await page.waitForTimeout(300);
  out.cases.refs = await page.evaluate(() => ({ refs: (window.__V2_APP__.state.aiWorkshopRefs || []).map((r) => r.fileName), chips: document.querySelectorAll('#aiImageBody .ai-ref-chip').length }));
  await page.fill('#aiImagePrompt', '参考这张素材的冷雾氛围，生成一张新图');
  await page.click('#btnImgGenerate');
  await page.waitForTimeout(1500);
  out.cases.gen = await page.evaluate(() => { const a = window.__V2_APP__; return { candidates: (a.state.candidates || []).length, cards: document.querySelectorAll('#aiImageBody .cand-card').length, saveBtns: document.querySelectorAll('[data-img-save]').length, refs: (a.state.aiLastCall && a.state.aiLastCall.refs) || null }; });
  if (out.cases.gen.saveBtns) {
    await page.click('[data-img-save="0"]');
    await page.waitForTimeout(1500);
  }
  out.cases.save = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const assets = a.state.library.assets || [];
    const ai = assets.filter((x) => (x.tags || []).includes('AI生成'));
    return { count: assets.length, aiCount: ai.length, aiName: ai[0] && ai[0].fileName, provenance: ai[0] && ai[0].provenance, tags: ai[0] && ai[0].tags };
  });
  out.cases.beforeAssets = beforeAssets;
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-library-ai-1920.png' });
  out.cases.refsOk = out.cases.refs.refs.length === 1 && out.cases.refs.chips >= 1;
  out.cases.genOk = out.cases.gen.candidates >= 1 && out.cases.gen.cards >= 1 && out.cases.gen.saveBtns >= 1;
  out.cases.saveOk = out.cases.save.aiCount >= 1 && out.cases.save.count > beforeAssets && out.cases.save.provenance && out.cases.save.provenance.source === 'ai-generated';
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.refsOk && out.cases.genOk && out.cases.saveOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  await finish(3);
}
