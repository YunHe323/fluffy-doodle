# CanvasKit P1/P2 前置复测报告（T34）

> 归属：`06-技术/三路线选型对比.md` §7 前置复测项｜执行：tech-architect｜日期：2026-11-06
> 数据：`bench/results/canvaskit-p1p2.json`（`mozheng.bench.v1`）｜工具：`bench/p1p2.html`
> 结论：**P1（20 层全满）与 P2（80 步满栈 undo）在 CanvasKit 上均通过**；P3（真实手绘板）仍**阻塞待硬件**。
> 约束：只改 `bench/`；只读 `spike/canvaskit/vendor/`，未修改其实现。

---

## 0. 结论

| 项 | 阈值（选型文档 §7） | 实测 | 判定 |
|---|---|---|---|
| **P1 · 2048²×20 层全满** | fps P95 ≥55；内存 ≤800MB | **fps P95 147.06**；延迟 P50/P95 **6.5/6.7ms**；估算内存 **464MB**；0 掉帧 | ✅ 通过 |
| **P1 · 4096²×8 层全满** | fps P95 ≥45；内存 ≤800MB | **fps P95 147.06**；延迟 P50/P95 **6.5/6.6ms**；估算内存 **704MB**；0 掉帧 | ✅ 通过 |
| **P2 · 80 步满栈 undo** | undo P95 ≤100ms；历史内存≤400MB；正确性 | **undo P95 1.8ms**（P50 0.5，max 62.6）；历史估算 **0.1MB**；全撤后空白校验通过 | ✅ 通过 |
| **P3 · 真实手绘板** | 盲评 ≥4/5、压感/倾斜可用 | 无设备 | ⏳ 阻塞（待硬件） |

→ **R2 CanvasKit 满足进入 M4 的 P1/P2 前提**；P3 不阻塞 M4 设计，但**阻塞「Procreate 级手感」对画师承诺**（承诺 v0.2 工期前需补）。

---

## 1. 环境（必须随数据引用）

| 项 | 值 |
|---|---|
| 机器 | 本机 Windows；**真实 GPU**：`ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 Laptop GPU Direct3D11 vs_5_0 ps_5_0)` |
| 浏览器 | **Headless Chrome 156.0.0.0**（`--headless=new`） |
| 刷新率 | 实测 **144.9Hz**（1 帧≈6.9ms） |
| DPR | 1 |
| 指针 | `synthetic`（程序生成压感序列）；**鼠标/无压感硬件** |
| 被测 | `canvaskit-wasm@0.42.0`，GPU 路径：`GetWebGLContext + MakeWebGLContext + MakeOnScreenGLSurface(WebGL2)` |
| 数据 | `bench/results/canvaskit-p1p2.json`（3 个 case：P1×2 + P2） |

> 延迟为「输入→帧提交」**代理指标**；144Hz 下 6.5–6.8ms ≈ 一帧内完成，**无法分辨**引擎真实开销（与 T26 主 bench 同口径）。不做真实感知延迟承诺。

---

## 2. 方法

### P1 · 20 层全满（`runP1`）

1. CanvasKit GPU 主 surface：`CK.GetWebGLContext(canvas)` → `MakeWebGLContext` → `MakeOnScreenGLSurface(WebGL2)`。
2. **每层 = 全尺寸 GPU 图像**：`MakeRenderTarget(gr, w, h)` 绘制 220 个确定性大圆（覆盖整层）→ `makeImageSnapshot()` 得 GPU 纹理，删除 surface；共 20 层（2048²）/ 8 层（4096²）。
3. 预热：120 帧 rAF + **3 次完整合成**（把纹理上传/管线编译排除在测量外）。
4. 测量 3 秒：每帧 `clear → drawImage × layers → 顶层画一笔 → flush`；延迟=下帧 rAF 时间戳 − 点时间戳。
5. 内存估算：`estTotalMemMB = 图层纹理(w×h×4×layers) + 主 surface(w×h×4) + WASM 堆(HEAPU8.length)`；**不含** GPU 驱动/缓存额外开销。

### P2 · 80 步满栈 undo（`runP2`）

1. 2048² 主 surface；**真实 80 笔**：每笔 `PictureRecorder` 记录 25 个 stamp → `SkPicture`，共 80 个。
2. 逐笔 undo：弹出 Picture + `delete` → `clear + 重放剩余 Picture + flush`，逐步计时（共 80 步）。
3. 正确性抽查 3 个检查点（undo 20/60/80 步）：记录剩余 Picture 数；**全撤后快照 PNG 与空白参考对比（差异 <10% 判 pass）**。
4. 历史内存估算：80 笔 ×25 stamp ×64B ≈ 0.1MB（Picture 为**指令记录**，不含整层位图）；作为对照：若采用整层快照 undo，80×2048²×4B ≈ **1.28GB** —— 本实现不采用该方案。

> 说明：P2 的 `undoMaxMs 62.6ms` 出现在**正确性检查点的快照编码**（3 次），不是 undo 本身；P50/P95 只反映 undo 步。

---

## 3. 结果（`bench/results/canvaskit-p1p2.json`）

| case | 延迟 P50/P95/max (ms) | fps P50/P95 | maxFrame (ms) | 掉帧 | JS heap (MB) | 图层/历史估算 (MB) | 总估算 (MB) |
|---|---|---|---|---|---|---|---|
| **P1-2048²×20L** | **6.5 / 6.7 / 6.8** | **144.93 / 147.06** | 7.3 | 0 | 2.7 | 320 | **464** |
| **P1-4096²×8L** | **6.5 / 6.6 / 6.7** | **144.93 / 147.06** | 7.2 | 0 | 4.2 | 512 | **704** |
| **P2-undo80** | —（undo P50/P95 = **0.5 / 1.8**，max 62.6⁺） | — | — | — | 5.5 | 0.1 | — |

⁺ = 检查点快照编码开销，见 §2。

**硬门槛**（JSON `verdict.hardFail = []`）：
- P1-2048：fps ✅（147.06 ≥55）、内存 ✅（464MB ≤800MB）
- P1-4096：fps ✅（147.06 ≥45）、内存 ✅（704MB ≤800MB，**余量仅约 96MB**）
- P2：undo ✅（1.8ms ≤100ms）、历史内存 ✅（0.1MB ≤400MB）、正确性 ✅

---

## 4. 与阈值/选型文档的对应

- 选型文档 §7 P1 目标「B1 fps P95 ≥55 / B3 ≥45、内存 ≤800MB」：本次以**全满图层**重测，2048²×20 与 4096²×8 均通过。
- §7 P2 目标「单步 P95 ≤100ms、历史内存 ≤400MB」：通过（Picture 方案，非整层快照）。
- **P3 真实手绘板**：用户暂无设备，**阻塞**；文档与选型表已标「待硬件」。

## 5. 风险与回退

| 风险 | 状态 | 处理 |
|---|---|---|
| 4096²×8 估算内存 **704MB**，距 800MB 余量仅 ~96MB | 需在 M4 关注 | 实现时用 tile 位图/压缩/按需分配；若 P1 复测（真实像素覆盖、非图像叠层）超 800MB → 按 §7 回退条款：先优化，2 周不达标切 R3 |
| 内存为**估算**（图像+主 surface+WASM 堆），不含驱动/缓存 | 已知 | 进入 M4 前用 Chrome tracing/显存查询补实测（附加复测项） |
| 延迟口径 144Hz 一帧 ≈6.9ms，6.5–6.8ms 无法分辨引擎开销 | 已知 | 与 T26 主 bench 同口径；真实手感需 P3 |
| P2 内容为「笔画 Picture」而非 20 层全满下的 undo | spike 范围 | 若需更严：在全满图层下重复 P2（v0.2 前可补） |

> **回退结论**：P1/P2 通过，**不需要**触发「切 R3 / 限撤销 / 调范围」；P3 待硬件，不阻塞 M4 引擎实现，但阻塞画师手感承诺。

---

## 6. 文件与复现

| 文件 | 说明 |
|---|---|
| `bench/p1p2.html` | P1/P2 测量页（零依赖；`?case=p1-2048\|p1-4096\|p2` 单跑，默认 all） |
| `bench/results/canvaskit-p1p2.json` | 统一 `mozheng.bench.v1` 结果（3 case + environment + verdict） |
| `bench/results/canvaskit-p1p2.md` | 本报告 |
| `bench/README.md` | 已补 P1/P2 用例说明（§12） |

```powershell
# 静态服务器（仓库根目录）
python -m http.server 8899 --bind 127.0.0.1
# 单跑（Chrome 打开）
# http://127.0.0.1:8899/bench/p1p2.html?case=p1-2048
# http://127.0.0.1:8899/bench/p1p2.html?case=p1-4096
# http://127.0.0.1:8899/bench/p1p2.html?case=p2
# 无头自动化：Chrome --headless=new --remote-debugging-port=9333 + CDP 轮询 window.__P1P2_RESULT__
```

> 复现注意：本页用 `GetWebGLContext + MakeWebGLContext` 的 GPU 路径；若环境无 WebGL2/GPU，请记录降级情况，不可与真实 GPU 数据混比。
