// v2/app/test-roadshow-auto.mjs — T120 「自动演示」按钮端到端验证（Mock 模式，不花钱）
// 路径：打开应用 → 点「路演」→ 开始 → 点「▶ 自动演示」→ 等待六拍全部自动完成。
// 断言：六拍 done 全 true、按钮文案切换过、日志出现「自动演示开始/完成」、0 pageerror。
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = Number(process.env.SERVE_PORT || 4212);
const RESULT = path.join(ROOT, 'v2', 'app', 'test-roadshow-auto-result.json');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = { schema: 'mozheng.app.roadshow-auto.v1', port: PORT, cases: {}, pass: {}, errors: [], pageErrors: [] };
let browser = null, finished = false;
const finish = (code) => {
  if (finished) return; finished = true;
  out.timestamp = new Date().toISOString();
  try { fs.writeFileSync(RESULT, JSON.stringify(out, null, 2), 'utf8'); } catch (e) {}
  try { if (browser) browser.close(); } catch (e) {}
  const passN = Object.values(out.pass).filter(Boolean).length, allN = Object.keys(out.pass).length;
  console.log('[RS-AUTO] pass=' + passN + '/' + allN, 'failed=' + Object.entries(out.pass).filter(([, v]) => !v).map(([k]) => k).join(','));
  process.exit(code);
};
setTimeout(() => { out.fatal = 'HARD_TIMEOUT_300s'; finish(3); }, 300000);

try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();
  page.on('pageerror', (e) => out.pageErrors.push(String(e).slice(0, 300)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
  await sleep(1200);

  // Mock 模式（不花 key 钱、快）
  await page.evaluate(() => window.__V2_APP__.t96.setToggles({ allowReal: false, privacyMode: true }));

  // 打开路演 → 开始
  await page.click('#btnRoadshow');
  await page.waitForSelector('#roadshowBrief.show', { timeout: 8000 });
  await sleep(600);
  await page.click('#btnRoadshowStart');
  await page.waitForFunction(() => document.getElementById('roadshowBar') && !document.getElementById('roadshowBar').hidden, null, { timeout: 20000 });
  out.cases.entered = true;

  // 自动演示按钮存在
  const btn = await page.$('#btnRoadshowAuto');
  out.pass.autoBtnExists = !!btn;
  out.cases.btnText0 = btn ? (await btn.textContent()).trim() : null;

  // 点自动演示
  await page.click('#btnRoadshowAuto');
  await sleep(800);
  out.cases.btnTextRunning = (await page.$eval('#btnRoadshowAuto', (b) => b.textContent)).trim();
  out.pass.btnSwitchesToStop = /停止/.test(out.cases.btnTextRunning);

  // 等六拍完成（Mock 全程 <90s；轮询 ROADSHOW.done）
  await page.waitForFunction(() => {
    const d = window.__V2_APP__ && window.__V2_APP__.roadshowDebug ? window.__V2_APP__.roadshowDebug() : null;
    return d && d.doneCount >= 6 && !d.busy && !d.auto;
  }, null, { timeout: 150000 }).catch(() => {});
  const dbg = await page.evaluate(() => window.__V2_APP__.roadshowDebug());
  out.cases.final = dbg;
  out.pass.allSixDone = dbg.doneCount >= 6;
  out.pass.autoEnded = dbg.auto === false;
  out.pass.btnBackToPlay = /自动演示/.test((await page.$eval('#btnRoadshowAuto', (b) => b.textContent)) || '') && !/停止/.test(await page.$eval('#btnRoadshowAuto', (b) => b.textContent));
  out.pass.noPageErrors = out.pageErrors.length === 0;
  out.pass.noConsoleErrors = out.errors.length === 0;

  await page.screenshot({ path: path.join(ROOT, 'v2', 'app', 'rs-auto-done.png') });
  out.shot = 'v2/app/rs-auto-done.png';
  finish(0);
} catch (e) {
  out.fatal = String(e && e.stack || e).slice(0, 700);
  finish(2);
}
