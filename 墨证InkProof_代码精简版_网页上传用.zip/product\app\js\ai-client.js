// product/app/js/ai-client.js
// AI 客户端抽象层：统一接口 analyzeCanvas / suggestDirections / generateCandidate。
// 默认本地 MockAI（离线、确定性、不调用真实模型）；HttpAIProvider 按 CONTRACT.md 预留真实服务接入。
// 约束：候选结果只返回给 UI 预览，绝不直接写用户画布（D1）。
import { state, emit, uid, clamp, sleep, DOC_W, DOC_H } from './state.js';
import { getCompositeCanvas, getCompositeDataUrl } from './canvas.js';

export const MOCK_MODEL = 'mock-ai@0.1.0';

/* ======================= 本地 MockAI ======================= */
function mulberry32(seed) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hex(n) { return n.toString(16).padStart(2, '0'); }
function round2(v) { return Math.round(v * 100) / 100; }

/** 从当前合成画布采样选区平均色与调色板（本地，不联网） */
function sampleSelection(rect) {
  const src = getCompositeCanvas();
  const x = clamp(Math.floor(rect.x), 0, DOC_W - 1);
  const y = clamp(Math.floor(rect.y), 0, DOC_H - 1);
  const w = clamp(Math.floor(rect.width || rect.w || DOC_W), 1, DOC_W - x);
  const h = clamp(Math.floor(rect.height || rect.h || DOC_H), 1, DOC_H - y);
  const ctx = src.getContext('2d');
  const data = ctx.getImageData(x, y, w, h).data;
  const step = Math.max(4, Math.floor(Math.min(w, h) / 24)) * 4;
  let r = 0, g = 0, b = 0, n = 0;
  const buckets = new Map();
  for (let i = 0; i < data.length; i += step) {
    r += data[i]; g += data[i + 1]; b += data[i + 2]; n += 1;
    const key = `${data[i] >> 5}-${data[i + 1] >> 5}-${data[i + 2] >> 5}`;
    const cur = buckets.get(key) || { r: 0, g: 0, b: 0, c: 0 };
    cur.r += data[i]; cur.g += data[i + 1]; cur.b += data[i + 2]; cur.c += 1;
    buckets.set(key, cur);
  }
  if (!n) return { avg: '#2f4e5f', palette: ['#2f4e5f', '#94a3b8'], warm: false, luma: 90 };
  r = Math.round(r / n); g = Math.round(g / n); b = Math.round(b / n);
  const avg = '#' + hex(r) + hex(g) + hex(b);
  const palette = [...buckets.values()]
    .sort((p, q) => q.c - p.c)
    .slice(0, 3)
    .map((v) => '#' + hex(Math.round(v.r / v.c)) + hex(Math.round(v.g / v.c)) + hex(Math.round(v.b / v.c)));
  const luma = 0.299 * r + 0.587 * g + 0.114 * b;
  return { avg: avg.toLowerCase(), palette, warm: r > b + 12, luma };
}

const MEDIUM_BANK = [
  { kind: 'digital_painting', detail: '厚涂，局部保留草稿线' },
  { kind: 'digital_painting', detail: '偏水彩的透明叠色' },
  { kind: 'ink', detail: '线稿为主，少量薄涂' }
];
const MOOD_BANK = ['安静', '克制', '清冷', '温和'];
const SCENE_BANK = ['未完成的夜景山谷速写', '以冷调为主的氛围练习', '带雾气的山湖习作'];
const THEMES = [
  '你圈出的这一块，明度变化集中在边缘，笔触从「铺」变成了「收」。',
  '这里的色相偏冷，和画面右上的光源方向一致，但对比度略低。',
  '这块区域的笔触密度比周围高，可能是你反复调整过的地方。',
  '区域里的暗部处理比较齐，和周围的松散笔触形成反差。'
];

export class MockAI {
  constructor(options = {}) {
    this.model = options.model || MOCK_MODEL;
    this.latency = options.latency || { analyze: 900, directions: 500, generate: 900 };
  }

  /** 画布理解：返回 CONTRACT §2.2 形状（L1 子集 + L2 + L4） */
  async analyzeCanvas(input = {}) {
    await sleep(this.latency.analyze);
    const sel = normalizeSelection(input.selection);
    const sample = sampleSelection(sel);
    const rng = mulberry32(hashSeed(JSON.stringify([sel.x, sel.y, sel.width, sel.height, input.context?.mode || 'collab'])));
    const regionCount = 2 + (rng() > 0.6 ? 1 : 0);
    const regions = [];
    for (let i = 0; i < regionCount; i += 1) {
      const rw = Math.round(sel.width * (0.25 + rng() * 0.4));
      const rh = Math.round(sel.height * (0.25 + rng() * 0.4));
      const rx = Math.round(sel.x + rng() * Math.max(1, sel.width - rw));
      const ry = Math.round(sel.y + rng() * Math.max(1, sel.height - rh));
      regions.push({
        id: `L2-mock-${String(i + 1).padStart(3, '0')}`,
        label: ['边缘与过渡', '主体结构', '暗部层次'][i % 3],
        confidence: round2(0.6 + rng() * 0.3),
        bbox: [clamp(rx, 0, DOC_W), clamp(ry, 0, DOC_H), rw, rh],
        importance: round2(0.5 + rng() * 0.4),
        anchor: { type: 'bbox', value: [clamp(rx, 0, DOC_W), clamp(ry, 0, DOC_H), rw, rh] }
      });
    }
    const obsCount = 2 + Math.floor(rng() * 2); // 2–3（UI 会再补 1 条 observed）
    const observations = [];
    for (let i = 0; i < obsCount; i += 1) {
      const region = regions[i % regions.length];
      observations.push({
        id: `L4-mock-${String(i + 1).padStart(3, '0')}`,
        layer: 'L4',
        kind: 'observation',
        source: 'inferred',
        author: 'ai',
        confidence: round2(0.5 + rng() * 0.42),
        text: THEMES[(i + Math.floor(rng() * 4)) % THEMES.length],
        anchor: { type: 'bbox', value: [...region.bbox] },
        evidenceRefs: [region.id],
        modelVersion: this.model
      });
    }
    const confidence = round2(observations.reduce((s, o) => s + o.confidence, 0) / Math.max(1, observations.length));
    return {
      model: this.model,
      seed: hashSeed(JSON.stringify(sel)).toString(16),
      global: {
        summary: `${SCENE_BANK[Math.floor(rng() * SCENE_BANK.length)]}（主色 ${sample.avg}）`,
        subject: sample.warm ? ['建筑', '暖光区域'] : ['山体', '雾气'],
        medium: MEDIUM_BANK[Math.floor(rng() * MEDIUM_BANK.length)],
        palette: sample.palette.map((h, i) => ({ hex: h, weight: round2(0.5 - i * 0.12) })),
        mood: [MOOD_BANK[Math.floor(rng() * MOOD_BANK.length)], MOOD_BANK[Math.floor(rng() * MOOD_BANK.length)]]
      },
      regions,
      observations,
      confidence,
      _local: sample // 本地 UI 用（不写入档案）
    };
  }

  /** 2 个方向候选（引用观察/档案字段） */
  async suggestDirections(input = {}) {
    await sleep(this.latency.directions);
    const analysis = input.analysis || null;
    const obs = analysis?.observations || [];
    const region = analysis?.regions?.[0];
    const palette = analysis?.global?.palette?.[0]?.hex || '#2f4e5f';
    return {
      model: this.model,
      directions: [
        {
          id: 'dir-mock-01',
          title: '把过渡做清楚，但保住软边',
          why: `依据 ${obs[0]?.id || 'L4 观察'}：边缘笔触在变紧；同时参考 L2 区域「${region?.label || '边缘与过渡'}」，避免做成硬切。`,
          confidence: 0.68,
          tags: ['edge', 'texture']
        },
        {
          id: 'dir-mock-02',
          title: '拉开冷暖，压暗近景',
          why: `依据 L1 色板 ${palette}：整体偏冷；近景再压一档能把视线推到右上光源。`,
          confidence: 0.61,
          tags: ['light', 'palette']
        }
      ]
    };
  }

  /** 本地模拟生成：对选区做 canvas 滤镜 + 色块，返回 2 个候选（PNG dataURL） */
  async generateCandidate(input = {}) {
    await sleep(this.latency.generate);
    const sel = normalizeSelection(input.selection);
    const pad = 14;
    const rect = {
      x: clamp(Math.floor(sel.x - pad), 0, DOC_W),
      y: clamp(Math.floor(sel.y - pad), 0, DOC_H),
      w: 0,
      h: 0
    };
    rect.w = clamp(Math.ceil(sel.width + pad * 2), 1, DOC_W - rect.x);
    rect.h = clamp(Math.ceil(sel.height + pad * 2), 1, DOC_H - rect.y);
    const composite = getCompositeCanvas();
    const plans = PLANS[input.directionId] || PLANS['dir-mock-01'];
    const candidates = plans.slice(0, clamp(Number(input.count) || 2, 1, 3)).map((plan, i) => {
      const cv = document.createElement('canvas');
      cv.width = rect.w;
      cv.height = rect.h;
      const ctx = cv.getContext('2d');
      ctx.filter = plan.filter;
      ctx.drawImage(composite, rect.x, rect.y, rect.w, rect.h, 0, 0, rect.w, rect.h);
      ctx.filter = 'none';
      if (plan.overlay) paintOverlay(ctx, rect.w, rect.h, plan.overlay);
      // 羽化（与落层一致的软边）
      const mask = document.createElement('canvas');
      mask.width = rect.w;
      mask.height = rect.h;
      const mctx = mask.getContext('2d');
      mctx.filter = 'blur(10px)';
      mctx.fillStyle = '#fff';
      mctx.fillRect(5, 5, Math.max(1, rect.w - 10), Math.max(1, rect.h - 10));
      ctx.globalCompositeOperation = 'destination-in';
      ctx.drawImage(mask, 0, 0);
      ctx.globalCompositeOperation = 'source-over';
      return {
        id: `cand-mock-${String(i + 1).padStart(2, '0')}`,
        label: plan.label,
        why: plan.why,
        imageDataUrl: cv.toDataURL('image/png'),
        width: rect.w,
        height: rect.h,
        rect,
        directionId: input.directionId || 'dir-mock-01',
        model: this.model
      };
    });
    return { candidates, credits: 0, model: this.model };
  }
}

const PLANS = {
  'dir-mock-01': [
    { label: '方案 A · 提亮边界', filter: 'contrast(1.2) saturate(1.12) brightness(1.07)', overlay: 'warm', why: '在选区内加强边缘的明度过渡，保留软边' },
    { label: '方案 B · 柔化过渡', filter: 'contrast(1.08) saturate(0.96) brightness(1.09)', overlay: 'mist', why: '降低对比、加一层雾感，让边界不硬' }
  ],
  'dir-mock-02': [
    { label: '方案 A · 冷暖分离', filter: 'saturate(1.32) contrast(1.1) brightness(1.02) hue-rotate(8deg)', overlay: 'cool', why: '远景压冷、近景提亮，建立前后两级' },
    { label: '方案 B · 压暗近景', filter: 'saturate(0.94) contrast(1.2) brightness(0.9)', overlay: 'vignette', why: '近景整体压暗，让视线集中到亮部' }
  ]
};

function paintOverlay(ctx, w, h, kind) {
  ctx.save();
  if (kind === 'warm') {
    const g = ctx.createLinearGradient(w, 0, 0, h);
    g.addColorStop(0, 'rgba(255,186,110,.28)');
    g.addColorStop(1, 'rgba(255,170,90,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  } else if (kind === 'cool') {
    const g = ctx.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, 'rgba(56,130,190,.22)');
    g.addColorStop(1, 'rgba(20,60,90,.08)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  } else if (kind === 'mist') {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, 'rgba(200,225,235,0)');
    g.addColorStop(0.55, 'rgba(200,225,235,.18)');
    g.addColorStop(1, 'rgba(200,225,235,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  } else if (kind === 'vignette') {
    const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.2, w / 2, h / 2, Math.max(w, h) * 0.7);
    g.addColorStop(0, 'rgba(0,0,0,0)');
    g.addColorStop(1, 'rgba(0,8,14,.4)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }
  ctx.restore();
}

function normalizeSelection(sel) {
  if (!sel) return { x: DOC_W * 0.26, y: DOC_H * 0.38, width: DOC_W * 0.42, height: DOC_H * 0.34 };
  if (sel.mode === 'rect' && sel.rect) {
    return { x: sel.rect.x, y: sel.rect.y, width: sel.rect.width, height: sel.rect.height };
  }
  return { x: sel.x ?? 0, y: sel.y ?? 0, width: sel.width ?? sel.w ?? DOC_W, height: sel.height ?? sel.h ?? DOC_H };
}
function hashSeed(str) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i += 1) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}

/* ======================= HTTP Provider（接入真实服务时使用） ======================= */
/**
 * 按 CONTRACT.md §2 调用本地服务的 provider。默认不启用。
 * 用法：const ai = new HttpAIProvider(); ai.analyzeCanvas(input) → 与服务端 mock 同构。
 */
export class HttpAIProvider {
  constructor({ baseUrl = '', timeoutMs = 15000 } = {}) {
    this.baseUrl = baseUrl;
    this.timeoutMs = timeoutMs;
    this.model = 'server-provider';
  }
  async post(path, body) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const resp = await fetch(`${this.baseUrl}${path}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal
      });
      const json = await resp.json().catch(() => null);
      if (!resp.ok || !json || json.ok === false) {
        throw new Error(json?.message || `本地服务返回 ${resp.status}`);
      }
      return json.result;
    } finally {
      clearTimeout(timer);
    }
  }
  async analyzeCanvas(input) { return this.post('/api/ai/analyze', input); }
  async suggestDirections(input) { return this.post('/api/ai/directions', input); }
  async generateCandidate(input) { return this.post('/api/ai/generate', input); }
}

/** 组装 analyze 请求（CONTRACT §2.2） */
export function buildAnalyzeInput({ selection, context = {}, canvas } = {}) {
  return {
    canvas: canvas || {
      dataUrl: getCompositeDataUrl(),
      width: DOC_W,
      height: DOC_H,
      layerCount: state.layers.length,
      activeLayerId: state.activeLayerId
    },
    selection: selection ? {
      mode: 'rect',
      rect: {
        x: Math.round(selection.x),
        y: Math.round(selection.y),
        width: Math.round(selection.w ?? selection.width),
        height: Math.round(selection.h ?? selection.height)
      }
    } : undefined,
    context: {
      mode: state.mode === 'attest' ? 'attest' : 'collab',
      aiRole: state.aiRole,
      archiveSummary: context.archiveSummary || null,
      userNote: context.userNote || ''
    }
  };
}

/** 默认客户端：本地 MockAI（无网络、无 key 也能全功能使用） */
export function createAIClient() {
  return new MockAI();
}
