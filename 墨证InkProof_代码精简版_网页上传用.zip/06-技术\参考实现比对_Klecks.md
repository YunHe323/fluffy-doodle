# 参考实现比对：Klecks / CanvasKit / Skia / ag-psd / Procreate / product v0.1

> 作者：tech-architect｜版本：**v1.0（T47 合并扩展；T46 初稿并入同一文件）**｜日期：2026-11-06
> 目的：满足用户硬要求——**交付前必须多次对比检验成熟项目/开源实现**；本文给出模块级「参考实现怎么做 / 我们怎么做 / 差异 / 借鉴与否 / 许可边界」。
> 配套：`06-技术/成熟项目对比检验方案.md`（可执行协议：模块矩阵/指标/阈值/3 轮重复/交付闸门）；证据：`06-技术/对比检验证据/`。
> 许可边界：**MIT 可参考并按 MIT 保留声明**；**GPL/NOASSERTION 只读算法/思路，不复制代码**；Procreate 专有，只参考公开行为。

---

## 0. 对象、版本、许可

| 对象 | 版本/路径 | 许可 | 在本文中的角色 |
|---|---|---|---|
| **Klecks** | `spike/klecks/vendor/klecks`（MIT 源码；dist 可本地启动） | **MIT** | present/undo/脏区/输入平滑/笔刷的成熟参考实现 |
| **CanvasKit / Skia** | `v2/engine/vendor`（`canvaskit-wasm@0.42.0`） | **BSD-3** | GPU surface/flush/present 语义 |
| **ag-psd** | `v2/psd/vendor/ag-psd`（28.3.1） | **MIT**（bundle 内含 pako/base64-js MIT；pdf.js Apache-2.0 注记） | PSD 图层/组/蒙版/混合结构 |
| **Procreate** | 公开文档/交互规范（T27 对标） | 专有 | 行为目标（连续笔迹、稳定、无闪白），非代码来源 |
| **product v0.1** | `product/app/js/canvas.js`（v0.1 冻结） | 本项目 | Canvas2D 基线 present/undo 对照 |
| **我们的 v2** | `v2/engine` + `v2/layers` + `v2/psd` | 本项目（CanvasKit BSD-3 / ag-psd MIT） | 被检验对象 |

---

## 1. 检验方法（与 T47 方案一致）

- 同一机器、同一浏览器、同一输入场景；每项 **≥3 轮**（每轮重开页面/会话），记录轮内/轮间波动。
- 指标：帧非空率、帧稳定时间、bandTop/bandBottom（已有内容/新内容 ink）、断点率、粗细跳变、undo 完整性、延迟 P50/P95、PSD 保真、内存。
- 证据：截图/JSON 归档 `06_技术` 下 `对比检验证据/`；不达标项建修复任务（owner 见 T48 GATE）。
- 当前证据：T47 先跑「present/帧稳定」3 轮（本文 §3）；其余模块按 T48 harness 跑（`v2/qa/compare/`，qa-engineer 负责），结果回填本文与 GATE。

---

## 2. 模块级比对

### 2.1 present / 实时预览（含上屏）

| | 内容 |
|---|---|
| **Klecks 怎么做** | 绘制发生在**图层 canvas（Canvas2D）**；`requestRender` 每帧做 `renderCanvas()`（全量合成可见图层）。GPU 路径 `GpuCompositeCanvas.present()` 用 `blitFramebuffer(FBO → canvas)` **显式上屏**；不存在「默认 framebuffer 跨帧保留」假设。参考：`klecks/canvas/kl-canvas.ts`、`klecks/image-operations/gpu-composite-canvas.ts`（present 在 L360–373）。 |
| **我们怎么做** | T44：当前笔触写离屏 live layer；每帧 `_drawComposite` 全量合成（clear→图层→live→flush）。T46：`endStroke/undo/redo/cancel/结构变化` 走 `presentFull()`，之后补 2–3 帧 burst；`compositeDirtySafe` 标 deprecated、内部全量。 |
| **差异** | Klecks 2D canvas 没有 WebGL 默认 framebuffer 问题，`renderCanvas` 天然全量；我们 WebGL on-screen surface 必须显式全量 present（T44 只修 live，T46 才修 present）。 |
| **借鉴与否** | **借鉴「显式全量 present + 显式 present 调用」纪律**（不复制代码）；不借鉴其 Canvas2D 架构。 |
| **T49 落地** | ✅ 改写为 v2「保留全帧 RenderTarget + 整帧 blit + burst」：`engine.js presentSurface/presentFull/_blitRetained/presentDirty`；测试 `leverage.mjs`、`present-stability.mjs`。 |
| **许可** | MIT：可参考/复制需保留版权与许可；本文仅参考思路，未复制代码；NOTICES §Klecks 已登记。 |

### 2.2 undo / redo

| | 内容 |
|---|---|
| **Klecks 怎么做** | 256² tile diff + `composed` 状态（`history.types.ts`、`kl-history.ts`、`push-helpers/canvas-to-layer-tiles.ts`）；undo/redo 更新 composed，重放受影响 tile 到图层 canvas，再触发完整渲染；有 memoryEstimate、validate、temp history。 |
| **我们怎么做** | `v2/engine`：tile patch before/after 快照栈（80 步/200MB）；undo/redo 应用 patch → T46 全量 present。`v2/layers`：同类 patch + 图像 undo（变换）。 |
| **差异** | Klecks 有 composed/多类型 history（图层属性/选择等）、temp undo、内存估算与校验；我们目前以像素 patch 为主，结构操作 undo 待补（M4.5）。 |
| **借鉴与否** | 借鉴 tile diff + composed、内存上限/校验、undo 后完整重绘；不复制其 TS 代码。 |
| **T49 落地** | ✅ 改写为 v2 `undo.js`：`pause/resume/replaceTop/validate/listeners/memoryEstimate` + engine 包装；测试 `leverage.mjs`。 |
| **许可** | MIT；如需移植算法，文件头注明来源与 MIT 声明；NOTICES §Klecks 已登记。 |

### 2.3 脏区合成

| | 内容 |
|---|---|
| **Klecks 怎么做** | tile 级变更用于 history 与局部 canvas 写回；呈现层仍以完整 `renderCanvas` 为主。 |
| **我们怎么做** | T46 明确：可见 surface 上**不做**局部脏区绘制（会画在已清空的 framebuffer 上）；`compositeDirty` 仅作内部工具，present 一律全量。 |
| **差异** | Klecks 无 GPU 默认 framebuffer 约束；我们做局部更新需先保留上一帧全量纹理并 blit 回来。 |
| **借鉴与否** | 借鉴 tile 变更边界；**暂不借鉴可见 surface 局部更新**，M4.5 评估「全帧纹理 + blit」方案。 |
| **许可** | MIT（参考）；无代码复制。 |

### 2.4 输入平滑与延迟

| | 内容 |
|---|---|
| **Klecks 怎么做** | `LineSmoothing`（`events/line-smoothing.ts`）：move 时 `x = mix(x, lastX, smoothing)`（smoothing 0–1），80ms 后以 35ms 间隔「追赶」真实输入；压力同样 mix。 |
| **我们怎么做** | `v2/engine/src/input.js`：Pointer Events + coalesced 点全量提交、速度模拟压感；笔刷稳定化/动态在 T36（provider/controller）处理；目前**无 Klecks 式 mix+追赶**。 |
| **差异** | Klecks 的平滑是输入链元素，简单可解释；我们依赖 T36 笔刷参数，缺少统一的低延迟平滑层。 |
| **借鉴与否** | **可借鉴（MIT）** mix + 定时追赶思路，作为 T36 稳定器参考；需保留 MIT 声明。 |
| **T49 落地** | ✅ 已移植为 `v2/engine/src/line-smoothing.js` + `input.js` 接入；`engine.setInputSmoothing(0..1)`；测试 `leverage.mjs`。 |
| **许可** | MIT；算法借鉴需注明来源/许可；NOTICES §Klecks 已登记。 |

### 2.5 笔刷连续性与纹理

| | 内容 |
|---|---|
| **Klecks 怎么做** | 成熟笔刷引擎：stamp + spacing + 多种笔刷/纹理；实时画在图层 canvas，不依赖 framebuffer。 |
| **我们怎么做** | T36：10 种笔刷预设 + 参数 JSON + 动态（压力/速度/倾斜/稳定化）+ 自制 tileable 纹理 + provider 注入（T41）；实时预览 live layer（T44/T45）。 |
| **差异** | Klecks 笔刷数量/纹理/长期打磨更成熟；我们参数化更现代、但连续性与纹理质量需 T48 对比数据确认（断点率/粗细跳变）。 |
| **借鉴与否** | 借鉴 spacing/interpolation/纹理采样思路；不复制资产（Klecks 纹理许可需单独确认，优先用自制 CC0）。 |
| **许可** | MIT（代码/思路）；资产需逐项核对，未使用 Klecks 资产。 |

### 2.6 图层 / 组 / 蒙版 / 混合

| | 内容 |
|---|---|
| **Klecks 怎么做** | 图层 canvas + `LayerCompositor` + `getClippingGroups`：clipping group 合成、`destination-atop` 等；组/混合/alpha 成熟。 |
| **我们怎么做** | T37：1 级组（组透明度隔离）、图层蒙版（启停/删除/应用）、剪贴、16 混合、图层操作；T45 live 预览蒙版正确。 |
| **差异** | Klecks 支持嵌套 clipping group；我们仅 1 级组、组蒙版/组剪贴未做（T37 已知限制）。 |
| **借鉴与否** | 借鉴 clipping group 的合成顺序/隔离语义；不复制代码。 |
| **许可** | MIT。 |

### 2.7 PSD 往返

| | 内容 |
|---|---|
| **Klecks 怎么做** | 应用内 PSD 导入导出（`kl-canvas-to-psd-blob`），与自身图层模型耦合。 |
| **我们怎么做** | T39：ag-psd（MIT）导入/导出；6 样本往返结构 100%、像素 100%、蒙版 6/6；不支持项 fidelity_report（文字层占位）。 |
| **差异** | Klecks 是应用内导出、无独立保真矩阵；我们的保真矩阵/降级报告更完整；文字层不可编辑。 |
| **借鉴与否** | 借鉴 PSD 图层映射/导出结构；不复制代码（Klecks 的 PSD 逻辑 MIT，但我们的 ag-psd 方案更独立）。 |
| **许可** | ag-psd MIT（+pako/base64-js MIT；pdf.js 注记）；Klecks MIT 仅参考。 |

### 2.8 内存 / 帧稳定

| | 内容 |
|---|---|
| **Klecks 怎么做** | 纯 Canvas2D 图层 canvas，桌面浏览器内存压力小；无 WASM 堆/GPU surface 跨帧问题；无公开内存数据。 |
| **我们怎么做** | CanvasKit WASM 堆 128MiB；4096²×8 全满分项 704MiB（T38），余量 96MiB/12%；T46 present 全量约 12.5ms（2048²，QA）；T47 3 轮帧稳数据见 §3。 |
| **差异** | 我们引入 GPU/WASM 内存与 present 成本；需 tracing/真机补测（驱动/缓存不可观测）。 |
| **借鉴与否** | 借鉴「内存上限/降内存预案」；不引入 Canvas2D 回退（R0 仅备选）。 |
| **许可** | — |

---

## 3. 3 轮重复证据（present / 帧稳定，本轮 T47 实跑）

**场景**：`v2/engine/demo.html`（2048²），headless Chrome 156 + RTX 4060/D3D11；两笔（y=400/800）→ end → 采样 0/16/50/200ms；undo → 同采样；再 undo 回基线。测试：`v2/engine/test/present-stability.mjs`；证据：`06-技术/对比检验证据/present-stability-r{1,2,3}.json` + `present-stability-3round-summary.json`。

| 轮次 | 结果 | afterEnd totals（0/16/50/200ms） | afterUndo totals | baseline | ref（单笔） |
|---|---|---|---|---|---|
| R1 | ✓ | 3500 / 3500 / 3500 / 3500 | 2557 / 2557 / 2557 / 2557 | 1596 | 2557 |
| R2 | ✓ | 同上 | 同上 | 1596 | 2557 |
| R3 | ✓ | 同上 | 同上 | 1596 | 2557 |

- **轮内波动：0%**；**轮间波动：0%**（totals 完全一致）；`undo` 与参考帧 grid diff = 0；再 undo 回到基线。
- 结论：present 全量确定性帧在 3 轮中稳定复现；**满足 T47 的 3 轮一致性要求**。
- 说明：ink 计数包含画布边框/页面固定像素（baseline 1596），因此用「相对参考帧」判定而非绝对值。

---

## 4. 与 T48 对比 harness 的对接

- T48（qa-engineer）建对照组 harness：同一脚本、同一场景分别跑 **我们（app/brushes/engine）vs Klecks（MIT dist）**，每项 3 轮，输出 JSON + GATE。
- 阈值以 QA harness 已有门槛为准（`v2/qa/browser-smoke.mjs`）：
  - 第一笔 `visibleAtMs ≤ 250ms` 且稳定；`bandTop ≥ refTop × 0.6`；
  - 拖动中：`bandTop ≥ refTop × 0.6`（已有内容保留）+ `bandBottom ≥ refBottom × 0.6`（新笔迹可见）；
  - pointerup 后稳定（3 轮采样一致）；
  - undo：`bandTop ≥ refTop × 0.6` 且 `bandBottom ≤ refBottom × 0.4`（撤销掉第二笔）；
  - 对比 Klecks 同场景结果：**我们不得低于参考实现的稳定/连续水平**；差距项建修复任务。
- T48 输出 schema 建议：`mozheng.compare.v1 { impl, page, scenario, round, metrics{ink,bandTop,bandBottom,stableMs}, pass, screenshots[], createdAt }`；GATE 汇总 `GATE.md`。
- 当前状态：T48 第一轮运行中；本文 §3 是「我们」的 3 轮证据，Klecks 对照结果待 T48 回填。

---

## 5. 已知差异清单（需 Lead 决策是否接受）

| # | 差异 | 现状 | 处理 |
|---|---|---|---|
| 1 | present 全量合成 2048² ~12.5ms | 已接受（QA 建议） | 4096²/脏区优化 M4.5 |
| 2 | 我们笔刷数量/长期打磨 < Klecks | T36 10 笔刷已交付 | 以 T48 数据评估，差距项开修复任务 |
| 3 | 组仅 1 级；组蒙版/组剪贴未做 | T37 已知限制 | T37/M4.5 后续 |
| 4 | 文字层 PSD 不可编辑 | T39 记录 fidelity_report | M4.4/M4.5 评估 |
| 5 | Procreate 对照仅公开行为，无真实样本 | 用户后续可提供真实 PSD | T48 用现有 6 样本；Procreate 行为由 T27 对标 |
| 6 | 4096²×8 含驱动内存未验证（疑 >800MB） | T38 分项 704MiB、驱动不可观测 | M4.5 真机 tracing |

---

## 6. 许可边界（红线）

- **Klecks（MIT）**：可参考/复制代码，需保留版权与 MIT 许可声明、NOTICES 登记；不得使用 Kleki 品牌/Logo。
- **CanvasKit/Skia（BSD-3）**：保留 LICENSE 与 Skia third_party 许可。
- **ag-psd（MIT）**：保留 MIT + pako/base64-js MIT + pdf.js Apache-2.0 注记。
- **Procreate（专有）**：只参考公开行为，不复制代码/资产。
- **Krita / libmypaint / Drawpile / darkly 等 GPL/NOASSERTION**：**只读算法/思路，不复制/移植代码**。
- 本文只做比对；**未把 Klecks 代码复制进 `v2/`**。

---

## 7. 结论与下一步

1. T44/T46 的 present 修复方向与 Klecks 的「全量呈现 + 显式 present」一致；3 轮证据稳定。
2. 可借鉴项（MIT）：LineSmoothing mix+追赶、tile diff+composed、clipping group 合成语义、内存上限/校验；需注明来源与许可。
3. 不适用项：Klecks 的 Canvas2D 架构、应用内 PSD 导出；我们保留 CanvasKit + ag-psd 方案。
4. T48 回填后：把「我们 vs Klecks」的模块级差异/差距项写入本文 §4 与 GATE，并对不达标项建修复任务。
5. 交付前按 `06-技术/成熟项目对比检验方案.md` 闸门执行（3 轮 + 证据 + 差异清单）。

---

## 8. 变更记录

| 版本 | 日期 | 变更 |
|---|---|---|
| 0.1（T46 初稿） | 2026-11-06 | 对象/许可矩阵、模块对比初稿、T46 修复结论、T47 扩展计划 |
| **1.0（T47 合并扩展）** | 2026-11-06 | 扩为模块级（present/undo/脏区/输入平滑/笔刷连续/图层蒙版/PSD/内存，每项 Klecks怎么做/我们怎么做/差异/借鉴/许可）；并入 3 轮 present 帧稳证据（3500/2557/1596，波动 0%）；补 T48 harness 阈值与 schema、已知差异清单、许可红线；与 T46 同一文件合并 |
| **1.1（T49 落地）** | 2026-11-06 | present/整帧 blit、tile undo 增强、LineSmoothing 从「借鉴」升级为「已移植/改写」；链接 `06-技术/开源杠杆清单.md`；工期重估 20–30 人日 |
