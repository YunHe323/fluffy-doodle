# AI 图像工作台 + 真实图像编辑 + 文字工具 + AI 画布标注层 + 档案 schema · 独立 QA 报告（T104）

> 执行：qa-engineer（独立 QA｜只读 app，不改源码；只写 `v2/qa/tools/`）｜环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、独立端口、0 残留
> 服务：Lead 提供的 4200（新代理含 `/api/ai/image` task=edit 的 DashScope multimodal 同步适配）；未打印/未提交 key。

## 结论

**可交付（Deliverable）——P0/P1 = 0，P2 = 2（记录性，不阻塞）。**
6 项验证全部通过：图像工作台 Mock 链路（连跑 2 次稳定）、文字工具 + L6 `text_inserted`、多模态标注/对齐/AI 定位/语音/**AI 画布标注层**、档案 schema（L6_KINDS/ai_role）、真实编辑证据核对、10 项回归 + 0 console error。

## 1. 图像工作台（Mock，连跑 2 次）

| 项 | 结果 |
|---|---|
| `test-image-workshop.mjs` | **PASS ×2（稳定）**，0 error |
| 生成 | candidates=**2**、cards=**2**（Mock），meta task=generate |
| 画布预览 | `candidatePreviewCanvas` alphaPixels=**1001**（>100） |
| 落层 + 自动变换 | layers 2→**3**、`transformActive=true`、tool=transform、undo=1 |
| 编辑模式 | candidates=1、**task=edit**（Mock） |

## 2. 文字工具 + L6 text_inserted

| 项 | 结果 |
|---|---|
| `test-text.mjs` | **PASS**，0 error |
| 点击画布 | 出现 `.text-composer` + `#tcText`，tool=text |
| 提交 | 图层 2→**3**、undo=1、层名 `文字 · 雾中山谷`、composer 关闭 |
| **L6 记录** | `text_inserted` 记录 **textRecord=1**（不再被 schema 拒收） |

## 3. 多模态 / AI 画布标注层

| 项 | 结果 |
|---|---|
| `test-multimodal.mjs` | **PASS**，0 error |
| 标注 | mode/dirty/ink/bar/annotatedCrop=true；完成后 ink 保留、bar 收起 |
| 坐标对齐 | `align.main/annotation/preview` 三层 rect 一致 `(212.5,66,993×662)`、**alignOk=true** |
| AI 定位 | 按钮存在且点击后 selection 移动 |
| 语音入口 | `#btnAiVoice` 存在、SpeechRecognition 可用、标注按钮存在 |
| **AI 画布标注层** | 橙色框 alphaPixels=**5001**（>500）、label 存在、按钮可切换（`aiOverlayVisible`） |

## 4. 档案 schema 回归（独立静态 + 运行时双重校验）

- **静态**：直接 `import v2/app/core/archive-schema.mjs` 构造 6 类 L6 记录并 `validateArchiveRecord`：`text_inserted`、`pixel_paste`、`asset_inserted`、`reference_added`（ai_role=null）+ `generation`（ai_role=tool+output_asset_id/cost_cny/credits）、`critique`（ai_role=assistant）——**全部 valid=true，0 error**。
- **运行时**：真实操作后 app 记录：`pixel_paste`（ai_role=null，复制粘贴已产生，图层 2→3）、`asset_inserted`（ai_role=assistant，素材插入，图层 3→4）；页面内逐条 `validateArchiveRecord` 全部通过（badCount=0）。
- 结论：`L6_KINDS` 与 `ai_role` 修复生效，`asset_inserted`/`pixel_paste`/`text_inserted` 等不再被拒收。

## 5. 真实证据核对（未重复花钱）

`v2/qa/tools/qwen-image-edit-app-results.json`：

| 项 | 值 | 核对 |
|---|---|---|
| provider / modelVersion | qwen / **qwen-image-3.0-pro** | ✅ |
| mock / billed | **false** / true | ✅ |
| latency | **51113 ms（≈51s）** | ✅ |
| 候选 bytes / sha256 | 6,597,953 B（≈6.6MB）/ `b8790a18…` | ✅ |
| 落层 | layers 3、**transformActive=true**、tool=transform、undo=1 | ✅ |

`v2/app/qwen-image-edit-real.png` 实际文件：**可正常解析为 2048×2048 PNG**（5,161,996 B，sha256 `a7e9514d…`）。
> ⚠️ **P2-1（证据包装）**：该文件与证据 JSON 中候选 **不是同一字节**（JSON 候选 6.6MB/sha `b8790a18…`；文件 5.16MB/sha `a7e9514d…`），且实际为 PNG 而非说明中的 JPEG、JSON 未引用该文件名。两者各自可打开/有效，但若作为“证据文件”归档建议重生成（见建议）。

## 6. 一次最小真实编辑（QA 独立发起，经本地代理）

| 项 | 值 |
|---|---|
| 请求 | `POST /api/ai/image`，`task=edit`，512×512 源图 + 中文 prompt，`x-ai-confirm:true` |
| 结果 | **200 · mode=real · model=qwen-image-3.0-pro** · candidates=1 · billed=true |
| 耗时 | **47.3 s** |
| 产物 | 2048×2048 PNG，2,967,228 B，sha256 `45c2ebe1…`，usage `qima_input_2k→qima_output_2k` |
| 结论 | 代理 task=edit 的 DashScope multimodal 同步适配**独立验证可用**（仅此 1 次真实调用，约 ¥0.2 量级） |

## 7. 回归（10 项，0 console error）

| 测试 | 结果 |
|---|---|
| test-app | PASS（0 error） |
| test-ui | PASS（p1Checks/interactions 全 true，0 error） |
| test-interaction-sequences | **9/9 PASS**（0 error） |
| test-library | PASS（19/19，scrim=true） |
| test-demo | PASS |
| test-ai-provider | PASS（16/16） |
| test-image-pan | PASS |
| test-editor-basics | PASS |
| test-chat | PASS |
| test-canvas-size | PASS |

密钥安全：DOM/localStorage/sessionStorage/已加载 JS/静态源码均无 key；config GET 仅 `hasKey/keyLast4`；T99 token 注入正常。
残留：Edge 测试进程 **0**、测试端口 **0**。

## 8. 截图

`v2/app/ui-image-workshop-1920.png`、`ui-text-tool-1920.png`、`ui-multimodal-1920.png`；回归截图见 `ui-*.png`。

## 9. 问题清单

| # | 级别 | 问题 | owner | 建议 |
|---|---|---|---|---|
| 1 | **P2** | `qwen-image-edit-real.png` 与证据 JSON 候选不一致（格式 PNG≠JPEG、大小 5.16MB≠6.6MB、sha256 不同、JSON 未引用该文件） | lead | 从候选 dataURL 原样落盘，并在 results JSON 记录文件名+sha256+尺寸；或注明该图来源（重编码/截图） |
| 2 | P2（测试覆盖） | `test-text.mjs` 收集了 `textRecord` 但未纳入 pass 断言（本次 QA 独立断言=1 通过） | demo-builder/lead | 将 `textRecord>=1` 加入 pass 条件，防止回归漏检 |

> 无 P0/P1；以上 2 个 P2 均不影响功能交付。

## 10. 产物与证据

- `v2/qa/tools/t104-verify-results.json`（schema/records 独立校验）
- `v2/qa/tools/t104-verify-real-edit.json`（QA 最小真实编辑调用数据）
- `v2/qa/tools/t104-key-results.json`（密钥运行时检查）
- 各测试结果 JSON：`v2/app/test-image-workshop-result.json`、`test-text-result.json`、`test-multimodal-result.json` 等
- 归档：`v2/qa/tools/archive/baseline-image-workshop/`
