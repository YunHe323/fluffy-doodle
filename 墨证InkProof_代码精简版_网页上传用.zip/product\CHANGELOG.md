# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [Unreleased]

Nothing yet. Planned work after v0.1.0 will be listed here first (see the roadmap in `README.md`).

---

## [v0.1.0] - 2026-11-?? (pending release)

First public release of the local-first product. Release date and version tag are pending final packaging.

### Added

- **Canvas**: hard/soft brush, eraser, color, size, undo/redo (≥50 steps), zoom & pan, image import.
- **Layers**: add/delete/rename/reorder/hide/opacity; AI candidate layers are editable and removable.
- **Archive**: mock AI reverse-parses imported images into L0 original, L1 global, L2 regions, L4 observations; user confirm/reject/edit produces L5 decision records; L6 derivation events for every AI action.
- **Stuck moment**: zero-text region selection → 2–4 observations + 2 directions + simulated candidates → applied as a new editable layer (move/hide/delete/undo).
- **Evidence package**: append-only SHA-256 event hash chain, manifest, JSON + canvas PNG export, scoped “zero generation” statement in attestation mode; AI events cannot be hidden.
- **Attestation mode**: disables all AI in v0.1; evidence states zero generation for the mode scope.
- **Local persistence**: IndexedDB storage; autosave; refresh/restart does not lose work; project export/import as JSON.
- **Mock AI**: offline, deterministic, no API key required; clearly labeled in the UI; provider interface reserved (not implemented in v0.1).
- **Onboarding**: 3-step skippable guide; built-in sample project; **one-click demo** (8-step automated walkthrough on the real UI, 2.5–3 minutes, pause/prev/next/exit, user takeover, cleanup, `prefers-reduced-motion` support).
- **Local service**: zero-dependency Node 22+ HTTP service (`server/server.mjs`), binds to `127.0.0.1` only, default port `4173` with automatic fallback; `start.bat` / `start.sh` launchers.
- **Docs**: README (English + Chinese), getting started, architecture, privacy.

### Changed

- None (first release).

### Fixed

- None (first release).

### Security

- No telemetry, no analytics, no silent external network requests in mock mode.
- API keys are not part of v0.1; the reserved provider configuration keeps keys local only (`config/provider.json`, gitignored) and never returns them to the browser.
- Local service binds to `127.0.0.1` and does not persist artwork, archives, or evidence.

### Notes

- License: MIT placeholder; copyright line and final license to be confirmed before public release.
- Research and design documents are kept outside this repository.
- Not in v0.1: accounts, payments, cloud sync, collaboration, PSD import/export, L3 relationship archive, real model quality, automatic semantic layer decomposition.

---

## Version links (placeholder URLs — update after the repository is public)

- [Unreleased]: https://github.com/<YOUR_ACCOUNT>/mozheng/compare/v0.1.0...HEAD
- [v0.1.0]: https://github.com/<YOUR_ACCOUNT>/mozheng/releases/tag/v0.1.0
