# spike/canvaskit/ · CanvasKit / Skia WASM spike（T26 · R2 路线）

> 状态：**✅ 已完成（2026-11-06）**——vendor 已解包、adapter 已实现、统一 bench 已跑、评估报告已出。
> 结果：`bench/results/canvaskit.json`（B1–B7 + B9-60s）｜报告：`spike/canvaskit/评估报告.md`
> vendor：`canvaskit-wasm@0.42.0`（来自 `spike/_vendor/canvaskit-wasm-0.42.0.tgz`），零外网本地加载。
> 许可：CanvasKit / Skia = **BSD-3-Clause**（见 §3）。不引入任何 GPL 代码。
> 关联：`bench/README.md`（统一测量页与 JSON 格式）、`06-技术/画布引擎v2_预研.md` §3.2（R2 评估）。

---

## 0. 目录规划

```
spike/canvaskit/
├─ README.md              ← 本文件（离线获取/vendor/接入/测量步骤）
├─ adapter.js             ← BenchAdapter 脚手架（本任务提供；vendor 到位后填 TODO）
├─ vendor/                ← 解包后的 canvaskit.js / canvaskit.wasm / LICENSE / package.json（待放）
├─ index.html             ← vendor 到位后的最小测试页（待写）
└─ 评估报告.md            ← 测量完成后写（架构/数据/对比/结论）
```

---

## 1. 离线获取（用户在可联网机器上执行一次）

两种方式任选其一：

**A. npm pack（推荐，产物即 tgz）**

```bash
# 在任意可联网机器、任意空目录
npm pack canvaskit-wasm@0.42.0          # 2026-11-06 查询 npm registry 的最新版本为 0.42.0；以实际下载为准
# 得到 canvaskit-wasm-0.42.0.tgz
```

**B. 从 npm 包页手动下载**

<https://www.npmjs.com/package/canvaskit-wasm> → 右侧 “Download tarball” 或在版本页下载 tgz。

拿到后放到：

```
spike/_vendor/canvaskit-wasm-<version>.tgz
```

> 若同时拿到了 Klecks 包（zip），同样放 `spike/_vendor/`（T25 使用）；本目录不处理 Klecks。

---

## 2. 解包与 vendor（Windows PowerShell / macOS·Linux bash）

### 2.1 解包

```powershell
# Windows（仓库根目录执行）
New-Item -ItemType Directory -Force spike\_vendor\canvaskit-unpack | Out-Null
tar -xzf spike\_vendor\canvaskit-wasm-0.42.0.tgz -C spike\_vendor\canvaskit-unpack
Get-ChildItem spike\_vendor\canvaskit-unpack -Recurse -Filter "canvaskit.*"
```

```bash
# macOS / Linux（仓库根目录执行）
mkdir -p spike/_vendor/canvaskit-unpack
tar -xzf spike/_vendor/canvaskit-wasm-0.42.0.tgz -C spike/_vendor/canvaskit-unpack
find spike/_vendor/canvaskit-unpack -name "canvaskit.*" -maxdepth 4
```

npm tgz 解包后通常是 `package/` 目录。**不同版本的目录布局可能不同**（一般在 `package/` 根或 `package/build/`），以 `find`/`Get-ChildItem` 的实际结果为准。

### 2.2 放到 vendor（本目录）

```powershell
New-Item -ItemType Directory -Force spike\canvaskit\vendor | Out-Null
$src = "spike\_vendor\canvaskit-unpack\package"
Copy-Item "$src\canvaskit.js" spike\canvaskit\vendor\ -Force
Copy-Item "$src\canvaskit.wasm" spike\canvaskit\vendor\ -Force
Copy-Item "$src\LICENSE" spike\canvaskit\vendor\LICENSE -Force
Copy-Item "$src\package.json" spike\canvaskit\vendor\package.json -Force
# 若实际布局在 build/ 下：把 $src 改为 "spike\_vendor\canvaskit-unpack\package\build"
```

```bash
cp "$src/canvaskit.js" "$src/canvaskit.wasm" spike/canvaskit/vendor/
cp "$src/LICENSE" spike/canvaskit/vendor/LICENSE
cp "$src/package.json" spike/canvaskit/vendor/package.json
```

### 2.3 登记版本与哈希（必须）

```powershell
Get-FileHash spike\canvaskit\vendor\canvaskit.wasm -Algorithm SHA256
Get-FileHash spike\canvaskit\vendor\canvaskit.js -Algorithm SHA256
```

回填下表（接入时由 T26 完成）：

| 项 | 值 |
|---|---|
| 包名/版本 | **`canvaskit-wasm@0.42.0`**（`vendor/package.json`） |
| 来源 | 离线 tgz：`spike/_vendor/canvaskit-wasm-0.42.0.tgz`（用户提供；Lead 已校验可解包） |
| 解包实际路径 | tgz 内为 `package/bin/canvaskit.js|wasm`（**本版本不是 `build/`**），已拷入 `vendor/` |
| canvaskit.wasm 大小 / SHA-256 | **7,317,345 B** / `25ebed8e60158c5854f8dc807b936daca21354f8bfb6a2231266b0a93812f301` |
| canvaskit.js 大小 / SHA-256 | **120,877 B** / `443777592179808354031cf411d8d43cac9f6b98d1227123c5c22d401b0fbf7f` |
| LICENSE | **BSD-3 全文已在 `vendor/LICENSE`**（不得删除） |
| 压缩后大小（实测） | gzip: wasm 2,960,611 B + js 37,516 B；brotli: wasm 2,275,862 B + js 32,993 B |

---

## 3. 许可登记（BSD-3）

1. `vendor/LICENSE` 必须保留（BSD-3 全文）+ 版权声明。
2. 在仓库的第三方清单中登记（`product/THIRD_PARTY_NOTICES.md` §B；**由 Lead/负责许可的流程审核后合并**，本 spike 目录不直接改 `product/`）：
   - 组件：CanvasKit（Skia 的 WASM 构建）
   - SPDX：`BSD-3-Clause`
   - 版本/哈希：按 §2.3 回填
   - 义务：保留版权/许可/免责声明；**Skia 内含 third_party 组件，发布时需随包附其许可**（spike 阶段先把 `vendor/package.json` 与 `LICENSE` 留档）。
3. 禁止：从 GPL/许可不明项目复制代码（Krita、libmypaint、Drawpile、darkly）；Skia/CanvasKit 本身是 BSD-3，可安全使用。

---

## 4. Vendor 到位后的接入步骤（T26 执行清单）

- [ ] 按 §2 解包、拷贝、登记哈希；确认 `vendor/canvaskit.js` + `vendor/canvaskit.wasm` 存在。
- [ ] 先跑最小验证：`spike/canvaskit/index.html`（待写）加载 `vendor/`，屏幕出现底色/一个圆 → 证明 API 与 locateFile 正确。
- [ ] 填充 `adapter.js` 的 TODO（详见文件内注释）：
  - CanvasKit init + surface 创建（注意 WebGL context 与 `locateFile`）；
  - **256² tile** 图层存储与合成（normal / multiply 至少两种混合）；
  - 硬/软两种 stamp 笔刷 + 压感半径/透明度映射（鼠标时速度模拟）；
  - undo：tile patch 或 snapshot（必须记录单步耗时）；
  - `setBlendMode(mode)`（B5 需要）。
- [ ] 用统一页面测量：静态服务器 → `bench/index.html` → Adapter URL 填 `../spike/canvaskit/adapter.js` → 勾选 B1–B7（B9 可选）→ 导出 JSON 存 `bench/results/canvaskit.json`。
- [ ] 收集系统数据：包体（raw wasm bytes、gzip/brotli 传输后大小）、WASM 内存（初始化后/20 层后）、首屏分段（下载/实例化/首帧）。
- [ ] 写 `spike/canvaskit/评估报告.md`：架构、实测数字、与 Klecks（T25）与 WebGL2（T29）可比表格、风险与结论；**必须标注当前为鼠标/无压感硬件，延迟数字不作最终结论**。

---

## 5. Adapter 脚手架说明（`adapter.js`）

- 已提供 `adapter.js` 脚手架：实现 `window.BenchAdapter`，按 bench/README.md §3 的契约导出；CanvasKit 未到位时 init 会抛出带指引的错误。
- **它是未验证脚手架**：真实 API（surface 创建、blend、snapshot、undo）以 vendor 版本为准；接入时先替换 vendor 加载与 init，再逐项实现 TODO，不要直接用于选型数据。
- 加载方式（页面内）：`bench/index.html` 的 “Adapter 脚本 URL” 填 `../spike/canvaskit/adapter.js`（相对 bench/ 的路径）。

---

## 6. 测量口径与环境标注（必须）

- 当前用户环境：**鼠标、无压感硬件** → 压感用「移动速度反比」模拟（bench §4.5），结果 JSON `environment.pointerType` 会记录 `mouse-simulated-pressure`。
- 报告必须写：**「软件/无压感硬件，延迟为代理指标，不作为最终结论」**；有手绘板时需补测并单独标注。
- 延迟为「输入→帧提交」代理值（浏览器无法观测真实扫描out），两条路线必须同机同浏览器同 case 比较。
- 必记环境：GPU renderer、刷新率、DPR、浏览器版本、`canvaskit-wasm` 版本。

---

## 7. 风险与未知

| 风险 | 影响 | 对策 |
|---|---|---|
| npm 包目录布局随版本变化 | vendor 拷贝路径错 | §2 用 `find/Get-ChildItem` 实际定位；README 记录实际路径 |
| CanvasKit API 版本差异（surface/blend/snapshot） | 接入返工 | 先最小 hello world；adapter TODO 逐项验证 |
| WASM 内存/包体超预期 | R2 被淘汰 | 实测后按 bench 硬门槛判定；不达标退回 R1/R3 |
| 无压感硬件 | 延迟结论偏乐观/不可比 | 报告标注；有条件补手绘板 |
| Skia third_party 许可遗漏 | 开源合规风险 | 保留 vendor LICENSE；发布前按 NOTICES §D 收集 |

---

## 8. 状态

| 步骤 | 状态 |
|---|---|
| 离线获取指引（本文件） | ✅ 完成 |
| vendor 解包/登记（版本/SHA/BSD-3） | ✅ 完成 |
| API/GPU 探针（`index.html`） | ✅ 完成（`MakeWebGLCanvasSurface` + 真实 GPU RTX 4060 / ANGLE D3D11） |
| 专项测量（`measure.html`：冷启动/WASM 堆/快照） | ✅ 完成 |
| adapter 实现（tile 索引/4 笔刷/混合/undo） | ✅ 完成（spike 级；见评估报告 §2） |
| 统一 bench 测量（B1–B7 + B9-60s） | ✅ 完成 → `bench/results/canvaskit.json` |
| 评估报告 + 对比 | ✅ `spike/canvaskit/评估报告.md`（含与 T29/Klecks 对比及口径警示） |
| 20 层全满 / 80 步满栈 undo / PSD / 真实手绘板 复测 | ⏳ 下一轮（不在本 spike 范围） |

---

## 9. 已完成结果（2026-11-06）

- **统一 bench JSON**：`bench/results/canvaskit.json`（B1–B7 + B9 60s 近似）。
- **评估报告**：`spike/canvaskit/评估报告.md`（环境/架构/包体/冷启动/实测/对比/风险/复现）。
- **关键数字（真实 GPU：RTX 4060 Laptop / D3D11，144.9Hz，synthetic pointer，无压感硬件）**：
  - B1 2048²×20：延迟 P50/P95 **6.5 / 6.6ms**（帧提交代理），**≈145fps**，无掉帧；
  - B3 4096²×8：6.5 / 6.7ms，≈145fps；
  - 包体：wasm 7.32MB → gzip **2.96MB** / brotli **2.28MB**；WASM 堆预分配 **128MiB**；
  - 4096² 冷启动 init **86ms**（本地 HTTP、无网络）；4096² PNG 合成导出 **983ms ⚠**（导出需异步/Worker）。
- **口径警示**：延迟是「输入→帧提交」代理（144Hz 下 1 帧≈6.9ms）；鼠标/无压感硬件；与 T29 的 SwiftShader/自建跑测器数字**不可直接比较**。
