/**
 * v2/psd · PSD 导出（v2 图层模型 → ag-psd → PSD/PSB buffer）
 *
 * - 图层：名字/可见性/不透明度/16 混合模式/剪贴/蒙版（全尺寸透明画布）
 * - 组：children 递归（ag-psd 自动写 section divider）
 * - 合成图/缩略图不生成（由调用方或后续任务按需补齐；PSD 不依赖合成图也可读）
 */
import { INTERNAL_TO_PSD, createCanvas } from './model.js';

export function exportPsd(doc, agPsd = window.agPsd) {
  if (!agPsd) throw new Error('exportPsd: ag-psd 未加载');
  const psd = {
    width: doc.width,
    height: doc.height,
    bitsPerChannel: 8,
    colorMode: 3, // RGB
    children: (doc.children || []).map((node) => toPsdNode(node, doc)),
  };
  const buffer = agPsd.writePsd(psd, {
    generateThumbnail: false,
    noBackground: true,
    trimImageData: false,
  });
  return toArrayBuffer(buffer);
}

function toPsdNode(node, doc) {
  if (node.type === 'group') {
    return {
      name: node.name,
      hidden: !node.visible,
      opacity: node.opacity,
      blendMode: 'pass through',
      opened: false,
      children: (node.children || []).map((c) => toPsdNode(c, doc)),
    };
  }
  const layer = {
    name: node.name,
    hidden: !node.visible,
    opacity: node.opacity,
    blendMode: INTERNAL_TO_PSD[node.blendMode] || 'normal',
    clipping: node.clip || undefined,
    top: 0,
    left: 0,
    bottom: doc.height,
    right: doc.width,
  };
  if (node.canvas) layer.canvas = ensureCanvas(node.canvas, doc.width, doc.height);
  if (node.mask) {
    layer.mask = {
      top: 0,
      left: 0,
      bottom: doc.height,
      right: doc.width,
      defaultColor: 0,
      canvas: ensureCanvas(node.mask, doc.width, doc.height),
    };
  }
  return layer;
}

function ensureCanvas(canvas, width, height) {
  if (canvas.width === width && canvas.height === height) return canvas;
  const c = createCanvas(width, height);
  c.getContext('2d').drawImage(canvas, 0, 0);
  return c;
}

function toArrayBuffer(buffer) {
  if (buffer instanceof ArrayBuffer) return buffer;
  if (buffer && buffer.buffer) {
    const start = buffer.byteOffset || 0;
    const len = buffer.byteLength || buffer.length || buffer.buffer.byteLength;
    return buffer.buffer.slice(start, start + len);
  }
  throw new Error('exportPsd: 不支持的 buffer 类型');
}
