// product/app/js/canvas.js
// 画布引擎：图层树 / 笔刷 / 橡皮 / 框选 / 撤销 / 覆盖层（选区、锚点、候选预览）/ 合成。
// 设计约束：AI 永不直接改用户已有像素；AI 结果只能通过 createAiLayerFromProposal 落为新图层（D1）。
import {
  state, emit, on, DOC_W, DOC_H, uid, nowIso, clamp, fmtDateTime,
  hexToRgba, normalizeRect, bboxArray, canvasToBlob, showCanvasToast, setStatusHint
} from './state.js';

let mainCanvas = null;
let overlayCanvas = null;
let mainCtx = null;
let overlayCtx = null;
let scratch = null;
let scratchCtx = null;
let rafPending = false;
let toastHost = null;

/* ---------------- 初始化 ---------------- */
export function initCanvas() {
  mainCanvas = document.getElementById('mainCanvas');
  overlayCanvas = document.getElementById('overlayCanvas');
  toastHost = document.getElementById('canvasToast');
  mainCtx = mainCanvas.getContext('2d');
  overlayCtx = overlayCanvas.getContext('2d');
  scratch = document.createElement('canvas');
  scratch.width = DOC_W;
  scratch.height = DOC_H;
  scratchCtx = scratch.getContext('2d');

  mainCanvas.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('pointermove', onPointerMove, { passive: false });
  window.addEventListener('pointerup', onPointerUp);
  window.addEventListener('pointercancel', onPointerUp);
  window.addEventListener('resize', relayout);
  if (window.ResizeObserver) new ResizeObserver(relayout).observe(document.getElementById('canvasWrap'));
  relayout();
  updateUndoButtons();
}

function relayout() {
  const wrap = document.getElementById('canvasWrap');
  if (!wrap) return;
  const pad = 22;
  const availW = Math.max(160, wrap.clientWidth - pad * 2);
  const availH = Math.max(120, wrap.clientHeight - pad * 2);
  const scale = Math.max(0.1, Math.min(availW / DOC_W, availH / DOC_H));
  const cssW = Math.round(DOC_W * scale);
  const cssH = Math.round(DOC_H * scale);
  for (const c of [mainCanvas, overlayCanvas]) {
    if (!c) continue;
    c.style.width = cssW + 'px';
    c.style.height = cssH + 'px';
  }
  const zoom = document.getElementById('statusZoom');
  if (zoom) zoom.textContent = Math.round(scale * 100) + '%';
}

/* ---------------- 图层模型 ---------------- */
export function makeLayer(name, kind = 'user', opts = {}) {
  const canvas = document.createElement('canvas');
  canvas.width = DOC_W;
  canvas.height = DOC_H;
  return {
    id: opts.id || uid('layer'),
    name,
    kind, // 'base' | 'user' | 'ai'
    canvas,
    ctx: canvas.getContext('2d'),
    visible: opts.visible !== false,
    opacity: opts.opacity ?? 1,
    offset: opts.offset ? { ...opts.offset } : { x: 0, y: 0 },
    bbox: opts.bbox || null,
    aiMeta: opts.aiMeta || null,
    createdAt: opts.createdAt || nowIso()
  };
}
export function activeLayer() {
  return state.layers.find((l) => l.id === state.activeLayerId) || null;
}
export function findLayer(id) {
  return state.layers.find((l) => l.id === id) || null;
}
export function addLayerToDoc(layer, { select = true, persist = true } = {}) {
  state.layers.push(layer);
  if (select) state.activeLayerId = layer.id;
  emit('layers:changed');
  emit('persist:project');
  if (persist) emit('persist:layer', layer.id);
  return layer;
}

/* ---------------- 渲染 ---------------- */
export function renderComposite(targetCtx) {
  targetCtx.clearRect(0, 0, DOC_W, DOC_H);
  for (const layer of state.layers) {
    if (!layer.visible || layer.opacity <= 0) continue;
    targetCtx.globalAlpha = layer.opacity;
    targetCtx.drawImage(layer.canvas, layer.offset.x, layer.offset.y);
  }
  targetCtx.globalAlpha = 1;
}
export function renderCanvas() {
  if (!mainCtx) return;
  renderComposite(mainCtx);
}
export function getCompositeCanvas() {
  renderComposite(scratchCtx);
  return scratch;
}
export function getCompositeDataUrl(maxSide = 1536) {
  const src = getCompositeCanvas();
  if (Math.max(DOC_W, DOC_H) <= maxSide) return src.toDataURL('image/png');
  const scale = maxSide / Math.max(DOC_W, DOC_H);
  const cv = document.createElement('canvas');
  cv.width = Math.round(DOC_W * scale);
  cv.height = Math.round(DOC_H * scale);
  cv.getContext('2d').drawImage(src, 0, 0, cv.width, cv.height);
  return cv.toDataURL('image/png');
}

export function renderLayerThumb(thumb, layer) {
  const ctx = thumb.getContext('2d');
  ctx.clearRect(0, 0, thumb.width, thumb.height);
  ctx.fillStyle = '#10161f';
  ctx.fillRect(0, 0, thumb.width, thumb.height);
  const s = Math.min(thumb.width / DOC_W, thumb.height / DOC_H);
  const w = DOC_W * s;
  const h = DOC_H * s;
  ctx.save();
  ctx.beginPath();
  ctx.rect((thumb.width - w) / 2, (thumb.height - h) / 2, w, h);
  ctx.clip();
  ctx.globalAlpha = layer.visible ? layer.opacity : 0.18;
  ctx.drawImage(layer.canvas, (thumb.width - w) / 2 + layer.offset.x * s, (thumb.height - h) / 2 + layer.offset.y * s, w, h);
  ctx.restore();
}

export function renderAll() {
  renderCanvas();
  renderOverlay();
  emit('canvas:changed');
}

/* ---------------- 覆盖层：选区 / 锚点 / 候选预览 ---------------- */
export function requestRender() {
  if (rafPending) return;
  rafPending = true;
  requestAnimationFrame(() => {
    rafPending = false;
    renderCanvas();
    renderOverlay();
  });
}

function roundRectPath(ctx, x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

const SOURCE_STYLE = {
  observed: { color: '#94a3b8', label: '可见', dash: [] },
  inferred: { color: '#f0a83c', label: 'AI 推断', dash: [8, 5] },
  'user-confirmed': { color: '#34d399', label: '你确认', dash: [] },
  rejected: { color: '#f87171', label: '已否决', dash: [4, 4] }
};

function drawSelectionRect(ctx, rect) {
  const { x, y, w, h } = rect;
  ctx.save();
  ctx.fillStyle = 'rgba(3,7,12,.18)';
  ctx.fillRect(0, 0, DOC_W, y);
  ctx.fillRect(0, y + h, DOC_W, DOC_H - y - h);
  ctx.fillRect(0, y, x, h);
  ctx.fillRect(x + w, y, DOC_W - x - w, h);
  ctx.setLineDash([10, 6]);
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = '#38bdf8';
  ctx.strokeRect(x, y, w, h);
  ctx.setLineDash([]);
  ctx.fillStyle = '#38bdf8';
  for (const [cx, cy] of [[x, y], [x + w, y], [x, y + h], [x + w, y + h]]) {
    ctx.fillRect(cx - 2.5, cy - 2.5, 5, 5);
  }
  const label = '指认区域';
  ctx.font = '600 15px "Microsoft YaHei", "Segoe UI", sans-serif';
  const tw = ctx.measureText(label).width;
  const ly = Math.max(0, y - 28);
  ctx.fillStyle = 'rgba(8,20,34,.92)';
  roundRectPath(ctx, x, ly, tw + 20, 24, 6);
  ctx.fill();
  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = '#7dd3fc';
  ctx.fillText(label, x + 10, ly + 17);
  ctx.restore();
}

function drawAnchor(ctx, obs) {
  const rect = obs.anchorRect;
  if (!rect) return;
  const style = SOURCE_STYLE[obs.source] || SOURCE_STYLE.observed;
  ctx.save();
  ctx.fillStyle = hexToRgba(style.color, 0.1);
  ctx.fillRect(rect.x, rect.y, rect.w, rect.h);
  ctx.strokeStyle = style.color;
  ctx.lineWidth = obs.source === 'user-confirmed' ? 3 : 2.5;
  ctx.setLineDash(style.dash);
  ctx.strokeRect(rect.x, rect.y, rect.w, rect.h);
  ctx.setLineDash([]);
  if (obs.source === 'user-confirmed') {
    ctx.lineWidth = 1;
    ctx.strokeRect(rect.x + 5, rect.y + 5, Math.max(0, rect.w - 10), Math.max(0, rect.h - 10));
  }
  const label = `${obs.id} · ${style.label}`;
  ctx.font = '600 13px "Microsoft YaHei", "Segoe UI", sans-serif';
  const tw = ctx.measureText(label).width;
  const ly = Math.max(4, rect.y - 26);
  ctx.fillStyle = 'rgba(6,14,24,.92)';
  roundRectPath(ctx, rect.x, ly, tw + 16, 22, 5);
  ctx.fill();
  ctx.strokeStyle = style.color;
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = style.color;
  ctx.fillText(label, rect.x + 8, ly + 16);
  ctx.restore();
}

const imageCache = new Map();
function getImage(src) {
  if (imageCache.has(src)) return imageCache.get(src);
  const img = new Image();
  img.onload = () => requestRender();
  img.src = src;
  imageCache.set(src, img);
  return img;
}
export function clearPreviewImageCache() { imageCache.clear(); }

function drawPreview(ctx, proposal) {
  if (!proposal || !proposal.rect) return;
  const img = getImage(proposal.imageDataUrl);
  const { x, y, w, h } = proposal.rect;
  ctx.save();
  if (img.complete && img.naturalWidth > 0) {
    ctx.globalAlpha = 0.96;
    ctx.drawImage(img, x, y, w, h);
    ctx.globalAlpha = 1;
  } else {
    ctx.fillStyle = 'rgba(96,165,250,.14)';
    ctx.fillRect(x, y, w, h);
  }
  ctx.setLineDash([9, 6]);
  ctx.strokeStyle = '#60a5fa';
  ctx.lineWidth = 2.5;
  ctx.strokeRect(x, y, w, h);
  ctx.setLineDash([]);
  const label = '预览 · 模拟生成（未落盘）';
  ctx.font = '600 14px "Microsoft YaHei", "Segoe UI", sans-serif';
  const tw = ctx.measureText(label).width;
  const ly = Math.max(4, y - 28);
  ctx.fillStyle = 'rgba(8,20,34,.94)';
  roundRectPath(ctx, x, ly, tw + 20, 24, 6);
  ctx.fill();
  ctx.strokeStyle = '#60a5fa';
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = '#bfdbfe';
  ctx.fillText(label, x + 10, ly + 17);
  ctx.restore();
}

export function renderOverlay() {
  if (!overlayCtx) return;
  overlayCtx.clearRect(0, 0, DOC_W, DOC_H);
  if (state.selection && !state.previewProposalId) drawSelectionRect(overlayCtx, state.selection);
  const obsId = state.highlightObsId || state.hoverObsId;
  if (obsId) {
    const obs = state.observations.find((o) => o.id === obsId);
    if (obs) drawAnchor(overlayCtx, obs);
  }
  if (state.previewProposalId) {
    const p = state.proposals.find((x) => x.id === state.previewProposalId);
    if (p) drawPreview(overlayCtx, p);
  }
}

/* ---------------- 笔刷 / 橡皮 ---------------- */
function stampHard(ctx, p, color, size) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(p.x, p.y, Math.max(0.6, size / 2), 0, Math.PI * 2);
  ctx.fill();
}
function stampSoft(ctx, p, color, size) {
  const r = Math.max(2, size / 2);
  const g = ctx.createRadialGradient(p.x, p.y, Math.max(0.5, r * 0.12), p.x, p.y, r);
  g.addColorStop(0, hexToRgba(color, 0.95));
  g.addColorStop(0.5, hexToRgba(color, 0.5));
  g.addColorStop(1, hexToRgba(color, 0));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
  ctx.fill();
}
function drawSegment(ctx, a, b, tool, color, size) {
  if (tool === 'brush-soft') {
    const dist = Math.hypot(b.x - a.x, b.y - a.y);
    const spacing = Math.max(1.5, size * 0.16);
    const steps = Math.max(1, Math.ceil(dist / spacing));
    for (let i = 1; i <= steps; i += 1) {
      stampSoft(ctx, { x: a.x + (b.x - a.x) * i / steps, y: a.y + (b.y - a.y) * i / steps }, color, size);
    }
    return;
  }
  ctx.strokeStyle = tool === 'eraser' ? '#000' : color;
  ctx.lineWidth = size;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(b.x, b.y);
  ctx.stroke();
  if (Math.hypot(b.x - a.x, b.y - a.y) < 0.6) stampHard(ctx, b, tool === 'eraser' ? '#000' : color, size);
}

function beginStroke(p) {
  const layer = activeLayer();
  if (!layer) { setStatusHint('没有可用图层'); return; }
  const tool = state.tool;
  layer.ctx.globalCompositeOperation = tool === 'eraser' ? 'destination-out' : 'source-over';
  state.stroke = {
    layerId: layer.id,
    before: layer.ctx.getImageData(0, 0, DOC_W, DOC_H),
    points: [p],
    tool,
    color: state.color,
    size: state.size,
    dirty: { x0: p.x, y0: p.y, x1: p.x, y1: p.y },
    startedAt: performance.now()
  };
  if (tool === 'brush-soft') stampSoft(layer.ctx, p, state.color, state.size);
  else stampHard(layer.ctx, p, tool === 'eraser' ? '#000' : state.color, state.size);
  requestRender();
}
function continueStroke(p) {
  const s = state.stroke;
  if (!s) return;
  const layer = findLayer(s.layerId);
  if (!layer) return;
  const last = s.points[s.points.length - 1];
  if (Math.hypot(p.x - last.x, p.y - last.y) < 1) return;
  drawSegment(layer.ctx, last, p, s.tool, s.color, s.size);
  s.points.push(p);
  s.dirty.x0 = Math.min(s.dirty.x0, p.x);
  s.dirty.y0 = Math.min(s.dirty.y0, p.y);
  s.dirty.x1 = Math.max(s.dirty.x1, p.x);
  s.dirty.y1 = Math.max(s.dirty.y1, p.y);
  requestRender();
}
function endStroke() {
  const s = state.stroke;
  if (!s) return;
  state.stroke = null;
  const layer = findLayer(s.layerId);
  if (!layer) return;
  layer.ctx.globalCompositeOperation = 'source-over';
  const pad = Math.ceil(s.size / 2) + 3;
  const x = clamp(Math.floor(s.dirty.x0 - pad), 0, DOC_W);
  const y = clamp(Math.floor(s.dirty.y0 - pad), 0, DOC_H);
  const x1 = clamp(Math.ceil(s.dirty.x1 + pad), 0, DOC_W);
  const y1 = clamp(Math.ceil(s.dirty.y1 + pad), 0, DOC_H);
  const w = x1 - x;
  const h = y1 - y;
  if (w > 0 && h > 0 && s.points.length > 0) {
    const tmp = document.createElement('canvas');
    tmp.width = DOC_W;
    tmp.height = DOC_H;
    const tctx = tmp.getContext('2d');
    tctx.putImageData(s.before, 0, 0);
    const beforeRect = tctx.getImageData(x, y, w, h);
    pushHistory(makePixelHistoryEntry(s.layerId, { x, y, w, h }, beforeRect, s.tool));
    state.strokeCount += 1;
    emit('log', {
      type: 'stroke',
      actor: 'user',
      payload: { layer_id: s.layerId, tool: s.tool, points: s.points.length, bbox: [x, y, w, h], duration_ms: Math.round(performance.now() - s.startedAt) }
    });
    markLayerDirty(s.layerId);
  }
  setStatusHint(`已落笔 · 第 ${state.strokeCount} 笔 · 可 Ctrl+Z 撤销`);
  renderAll();
}

/* ---------------- 撤销 / 重做 ---------------- */
export function pushHistory(entry) {
  state.undoStack.push(entry);
  if (state.undoStack.length > 60) state.undoStack.shift();
  state.redoStack.length = 0;
  updateUndoButtons();
}
export function makePixelHistoryEntry(layerId, rect, beforeImageData, label) {
  return {
    label: label || '绘制',
    undo() {
      const layer = findLayer(layerId);
      if (!layer) return;
      const cur = layer.ctx.getImageData(rect.x, rect.y, rect.w, rect.h);
      layer.ctx.putImageData(beforeImageData, rect.x, rect.y);
      beforeImageData = cur;
    },
    redo() { this.undo(); }
  };
}
export function makeActionHistory(undoFn, redoFn, label) {
  return { label: label || '操作', undo: undoFn, redo: redoFn };
}
export function undoAction() {
  const entry = state.undoStack.pop();
  if (!entry) return;
  try { entry.undo(); } catch (e) { console.warn('undo failed', e); }
  state.redoStack.push(entry);
  renderAll();
  updateUndoButtons();
  markProjectDirty();
  emit('persist:layer', state.activeLayerId);
  setStatusHint('已撤销');
}
export function redoAction() {
  const entry = state.redoStack.pop();
  if (!entry) return;
  try { entry.redo(); } catch (e) { console.warn('redo failed', e); }
  state.undoStack.push(entry);
  renderAll();
  updateUndoButtons();
  markProjectDirty();
  emit('persist:layer', state.activeLayerId);
  setStatusHint('已重做');
}
export function updateUndoButtons() {
  const u = document.getElementById('btnUndo');
  const r = document.getElementById('btnRedo');
  if (u) u.disabled = state.undoStack.length === 0;
  if (r) r.disabled = state.redoStack.length === 0;
}

/* ---------------- 指针交互 ---------------- */
function pointerPos(e) {
  const rect = mainCanvas.getBoundingClientRect();
  return {
    x: clamp((e.clientX - rect.left) / rect.width * DOC_W, 0, DOC_W),
    y: clamp((e.clientY - rect.top) / rect.height * DOC_H, 0, DOC_H)
  };
}
function onPointerDown(e) {
  if (e.button !== 0 && e.pointerType === 'mouse') return;
  e.preventDefault();
  const p = pointerPos(e);
  if (state.tool === 'select') beginSelection(p);
  else if (state.tool === 'move') beginLayerMove(p);
  else beginStroke(p);
}
function onPointerMove(e) {
  const p = pointerPos(e);
  if (state.stroke) continueStroke(p);
  else if (state.drag && state.drag.type === 'selection') updateSelectionDrag(p);
  else if (state.drag && state.drag.type === 'layer-move') updateLayerMove(p);
}
function onPointerUp() {
  if (state.stroke) endStroke();
  else if (state.drag) {
    if (state.drag.type === 'selection') endSelectionDrag();
    else if (state.drag.type === 'layer-move') endLayerMove();
    else state.drag = null;
  }
}

/* 框选指认 */
function beginSelection(p) {
  state.drag = { type: 'selection', start: p, current: p };
  renderOverlay();
}
function updateSelectionDrag(p) {
  const d = state.drag;
  if (!d || d.type !== 'selection') return;
  d.current = p;
  state.selection = normalizeRect(d.start, d.current);
  renderOverlay();
  setStatusHint(`指认区域 ${Math.round(state.selection.w)} × ${Math.round(state.selection.h)} · 点「让 AI 看看」`);
}
function endSelectionDrag() {
  const d = state.drag;
  state.drag = null;
  if (!d || d.type !== 'selection') return;
  const rect = normalizeRect(d.start, d.current);
  if (rect.w < 16 || rect.h < 16) {
    state.selection = null;
    renderOverlay();
    setStatusHint('框选区域太小，已取消');
    return;
  }
  state.selection = rect;
  emit('selection:changed', state.selection);
  emit('log', {
    type: 'selection_set',
    actor: 'user',
    payload: { selection: { mode: 'rect', rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.w), height: Math.round(rect.h) } } }
  });
  markProjectDirty();
  renderOverlay();
  showCanvasToast('已指认区域 · 点「让 AI 看看」（K）', 2600);
  setStatusHint(`已指认 ${Math.round(rect.w)} × ${Math.round(rect.h)} 的区域`);
}

/* 移动 AI 图层 */
function beginLayerMove(p) {
  const layer = activeLayer();
  if (!layer) { setStatusHint('请先在图层列表选中一个图层'); return; }
  if (layer.kind !== 'ai') { setStatusHint('「移动」工具用于 AI 图层'); return; }
  state.drag = {
    type: 'layer-move', layerId: layer.id, start: p,
    origin: { ...layer.offset }, before: { ...layer.offset }
  };
}
function updateLayerMove(p) {
  const d = state.drag;
  if (!d || d.type !== 'layer-move') return;
  const layer = findLayer(d.layerId);
  if (!layer) return;
  layer.offset = { x: d.origin.x + (p.x - d.start.x), y: d.origin.y + (p.y - d.start.y) };
  requestRender();
}
function endLayerMove() {
  const d = state.drag;
  state.drag = null;
  if (!d || d.type !== 'layer-move') return;
  const layer = findLayer(d.layerId);
  if (!layer) return;
  const before = { ...d.before };
  const after = { ...layer.offset };
  if (before.x === after.x && before.y === after.y) return;
  pushHistory(makeActionHistory(
    () => { const l = findLayer(d.layerId); if (l) { l.offset = { ...before }; renderAll(); } },
    () => { const l = findLayer(d.layerId); if (l) { l.offset = { ...after }; renderAll(); } },
    '移动图层'
  ));
  emit('log', { type: 'ai_layer_moved', actor: 'user', payload: { layer_id: d.layerId, from: before, to: after } });
  renderAll();
  markLayerDirty(d.layerId);
}

/* ---------------- 工具 / 颜色 ---------------- */
export const TOOL_META = {
  'brush-hard': { cursor: 'crosshair', hint: '硬笔：画轮廓/线稿（Ctrl+Z 撤销）' },
  'brush-soft': { cursor: 'crosshair', hint: '软笔：画雾、光影与过渡' },
  'eraser': { cursor: 'cell', hint: '橡皮：擦除当前图层像素' },
  'select': { cursor: 'crosshair', hint: '框选：在画布上圈出「卡住」的区域' },
  'move': { cursor: 'grab', hint: '移动：拖动选中的 AI 图层' }
};
export function setTool(tool) {
  if (!TOOL_META[tool]) return;
  if (state.stroke) endStroke();
  state.tool = tool;
  document.querySelectorAll('[data-tool]').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.tool === tool);
  });
  if (mainCanvas) mainCanvas.style.cursor = TOOL_META[tool].cursor;
  setStatusHint(TOOL_META[tool].hint);
  emit('tool:changed', tool);
}
export function setColor(color) {
  state.color = color;
  const input = document.getElementById('colorInput');
  if (input) input.value = color;
  document.querySelectorAll('.swatch').forEach((s) => s.classList.toggle('active', s.dataset.color && s.dataset.color.toLowerCase() === color.toLowerCase()));
}
export function setSize(size) {
  state.size = size;
  const range = document.getElementById('sizeRange');
  const label = document.getElementById('sizeVal');
  if (range) range.value = size;
  if (label) label.textContent = size + ' px';
}

/* ---------------- AI 图层落盘（D1：只在用户确认后写新图层） ---------------- */
function loadImageEl(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('候选图像加载失败'));
    img.src = src;
  });
}
/** 与 demo 一致的羽化合成：候选只落在选区矩形内，并做 10px 软边 */
export async function createAiLayerFromProposal(proposal, directionTitle) {
  const img = await loadImageEl(proposal.imageDataUrl);
  const rect = proposal.rect;
  const name = 'AI · ' + (directionTitle ? String(directionTitle).slice(0, 8) : '方案') + ' · ' + fmtDateTime(new Date()).slice(5);
  const layer = makeLayer(name, 'ai', {
    bbox: { ...rect },
    aiMeta: {
      proposalId: proposal.id,
      directionId: proposal.directionId,
      generationId: proposal.generationId || null,
      model: proposal.model || null
    }
  });
  // 1) 画候选到区域小画布
  const region = document.createElement('canvas');
  region.width = Math.max(1, Math.round(rect.w));
  region.height = Math.max(1, Math.round(rect.h));
  const rctx = region.getContext('2d');
  rctx.drawImage(img, 0, 0, region.width, region.height);
  // 2) 羽化蒙版（blur + destination-in）
  const mask = document.createElement('canvas');
  mask.width = region.width;
  mask.height = region.height;
  const mctx = mask.getContext('2d');
  mctx.filter = 'blur(10px)';
  mctx.fillStyle = '#fff';
  mctx.fillRect(5, 5, Math.max(1, region.width - 10), Math.max(1, region.height - 10));
  rctx.globalCompositeOperation = 'destination-in';
  rctx.drawImage(mask, 0, 0);
  rctx.globalCompositeOperation = 'source-over';
  // 3) 合成到新图层（原图层像素不变）
  layer.ctx.drawImage(region, rect.x, rect.y);
  return layer;
}

/** 落层高亮脉冲（尊重 prefers-reduced-motion） */
export function pulseRect(rect) {
  if (!rect || !overlayCtx) return;
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const start = performance.now();
  const step = (now) => {
    const t = Math.min(1, (now - start) / 750);
    renderOverlay();
    overlayCtx.save();
    overlayCtx.strokeStyle = 'rgba(96,165,250,' + (0.85 * (1 - t)).toFixed(3) + ')';
    overlayCtx.lineWidth = 3 + 10 * t;
    overlayCtx.strokeRect(rect.x - 2, rect.y - 2, rect.w + 4, rect.h + 4);
    overlayCtx.restore();
    if (t < 1) requestAnimationFrame(step);
    else renderOverlay();
  };
  requestAnimationFrame(step);
}

/* ---------------- 持久化标记 / 序列化 ---------------- */
export function markLayerDirty(layerId) {
  if (!layerId) return;
  state.dirtyLayers.add(layerId);
  emit('persist:layer', layerId);
}
export function markProjectDirty() {
  emit('persist:project');
}
export async function serializeLayer(layer, order = 0) {
  const blob = await canvasToBlob(layer.canvas);
  return {
    id: layer.id,
    projectId: state.projectId,
    name: layer.name,
    kind: layer.kind,
    visible: layer.visible,
    opacity: layer.opacity,
    offset: { ...layer.offset },
    bbox: layer.bbox,
    aiMeta: layer.aiMeta,
    order,
    createdAt: layer.createdAt,
    blob
  };
}
export async function deserializeLayer(rec) {
  const layer = makeLayer(rec.name, rec.kind, {
    id: rec.id,
    visible: rec.visible,
    opacity: rec.opacity,
    offset: rec.offset,
    bbox: rec.bbox,
    aiMeta: rec.aiMeta,
    createdAt: rec.createdAt
  });
  if (rec.blob) {
    const bitmap = await createImageBitmap(rec.blob);
    layer.ctx.drawImage(bitmap, 0, 0, DOC_W, DOC_H);
    if (bitmap.close) bitmap.close();
  }
  return layer;
}
