// v2/app/test-roadshow.mjs — 路演模式（Roadshow）端到端验证
// headless Edge（msedge）+ 自带 python http.server（独立端口 8188，跑完关闭）
// 断言：入口 / brief 模态 / 1600² 预置项目 / 成稿层 / 素材 ≥3 / 昨天 L6 ≥6 / 6 拍控制台 /
//       真实选区 / 真实开关已显式写入 / 预置样本落层（[预置] + cached_sample）/ 选区 mask 落层框外 0 像素变化 /
//       证据包 PNG 字节哈希可复核 / 退出恢复 / 0 console error & pageerror
// 产物：v2/app/ui-roadshow-1920.png、v2/app/test-roadshow-result.json
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8188;
const RESULT = path.join(ROOT, 'v2', 'app', 'test-roadshow-result.json');
const SHOT = path.join(ROOT, 'v2', 'app', 'ui-roadshow-1920.png');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = { schema: 'mozheng.app.roadshow-test.v1', port: PORT, cases: {}, pass: {}, errors: [], pageErrors: [], consoleErrors: [], aiApiConsole: [] };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
let browser = null;
let context = null;
let finished = false;
const finish = (code) => {
  if (finished) return;
  finished = true;
  out.timestamp = new Date().toISOString();
  try { fs.writeFileSync(RESULT, JSON.stringify(out, null, 2), 'utf8'); } catch (e) { /* ignore */ }
  try { if (browser) browser.close(); } catch (e) { /* ignore */ }
  try { py.kill(); } catch (e) { /* ignore */ }
  try { fs.rmSync(path.join(ROOT, 'v2', 'app', '.roadshow-profile'), { recursive: true, force: true }); } catch (e) { /* ignore */ }
  console.log(JSON.stringify(out, null, 2));
  process.exit(code);
};
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_300s'; finish(3); }, 300000);

try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  context = await browser.newContext({ viewport: { width: 1920, height: 1080 }, acceptDownloads: true });
  const page = await context.newPage();
  page.on('pageerror', (e) => out.pageErrors.push(String(e)));
  page.on('console', (m) => {
    if (m.type() !== 'error') return;
    const loc = (m.location && m.location() && m.location().url) || '';
    // python 静态服务器没有 /api/ai/* 代理：启动时配置探测的 404 属于预期（App 内部已降级 Mock），单独记录
    if (/\/api\/ai\//.test(loc) || /\/api\/ai\//.test(m.text())) { out.aiApiConsole.push(m.text() + (loc ? ' @ ' + loc : '')); return; }
    out.consoleErrors.push(m.text() + (loc ? ' @ ' + loc : ''));
  });

  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
  await page.waitForTimeout(700);
  const saved = await page.evaluate(() => ({
    aiRaw: (() => { try { return localStorage.getItem('mozheng.ai.settings.v1'); } catch (e) { return null; } })(),
    label: (document.getElementById('projectLabel') || {}).textContent || '',
    records: (window.__V2_APP__.state.records || []).length,
  }));
  out.saved = { aiRaw: saved.aiRaw, label: saved.label, records: saved.records };

  // 1) 入口
  out.cases.entry = await page.evaluate(() => {
    const b = document.getElementById('btnRoadshow');
    return b ? { exists: true, text: b.textContent.replace(/\s+/g, ' ').trim(), visible: b.offsetParent !== null, title: b.title } : { exists: false };
  });
  out.pass.entry = !!(out.cases.entry.exists && out.cases.entry.visible && /路演/.test(out.cases.entry.text || ''));

  // 2) brief 模态
  await page.click('#btnRoadshow');
  await page.waitForFunction("document.getElementById('roadshowBrief') && document.getElementById('roadshowBrief').classList.contains('show')", null, { timeout: 10000 });
  await page.waitForTimeout(250);
  out.cases.brief = await page.evaluate(() => {
    const m = document.getElementById('roadshowBrief');
    const txt = (m.textContent || '').replace(/\s+/g, ' ');
    return {
      shown: m.classList.contains('show') || getComputedStyle(m).display !== 'none',
      text: txt.slice(0, 900),
      hasProject: /《呼吸》/.test(txt),
      hasFog: /冷雾/.test(txt),
      hasRetain: /笔触/.test(txt),
      hasDeadline: /10:00/.test(txt),
      hasLocal: /本地项目/.test(txt),
      hasNoUpload: /素材不上传/.test(txt),
      startBtn: !!document.getElementById('btnRoadshowStart'),
      exitBtn: !!document.getElementById('btnRoadshowExitBrief'),
      assetsText: (document.getElementById('roadshowBriefAssets') || {}).textContent || '',
    };
  });
  out.pass.brief = !!(out.cases.brief.shown && out.cases.brief.hasProject && out.cases.brief.hasFog && out.cases.brief.hasRetain && out.cases.brief.hasDeadline && out.cases.brief.hasLocal && out.cases.brief.hasNoUpload && out.cases.brief.startBtn && out.cases.brief.exitBtn);

  // 3) 开始路演 → 预置项目
  await page.click('#btnRoadshowStart');
  await page.waitForFunction('(() => { const t = window.__V2_APP__ && window.__V2_APP__.t122; if (!t) return false; const s = t.state(); return s.prepared === true || !!s.error; })()', null, { timeout: 180000 });
  await page.waitForTimeout(600);
  out.cases.project = await page.evaluate(() => {
    const app = window.__V2_APP__;
    const t = app.t122;
    const s = t.state();
    const bar = document.getElementById('roadshowBar');
    const cv = document.getElementById('mainCanvas').getBoundingClientRect();
    const br = bar.getBoundingClientRect();
    return {
      active: s.active, prepared: s.prepared, error: s.error,
      canvas: s.canvas,
      docSize: (document.getElementById('docSize') || {}).textContent,
      layers: s.layers,
      libCount: s.libCount,
      lib: s.lib,
      l6Preset: s.l6Preset, l6Total: s.l6Total,
      selection: s.selection, engineHasSelection: s.engineHasSelection,
      sample: s.sample,
      badge: s.badge,
      aiSettings: s.aiSettings,
      step: s.step,
      bar: bar ? { hidden: bar.hidden, visible: getComputedStyle(bar).display !== 'none', left: Math.round(br.left), right: Math.round(br.right), top: Math.round(br.top), width: Math.round(br.width) } : null,
      canvasRect: { left: Math.round(cv.left), right: Math.round(cv.right), cx: Math.round(cv.left + cv.width / 2), cy: Math.round(cv.top + cv.height / 2) },
      timer: (document.getElementById('roadshowTimer') || {}).textContent || '',
      pips: document.querySelectorAll('#roadshowPips [data-rs-step]').length,
      steps: t.steps(),
      stepTitle: (document.getElementById('roadshowStepTitle') || {}).textContent || '',
      stepNo: (document.getElementById('roadshowStepNo') || {}).textContent || '',
      l6PresetRecords: app.state.records.filter((r) => r.layer === 'L6' && r.params && r.params.preset_sample).map((r) => ({ id: r.id, kind: r.kind, model: r.model && r.model.model, note: String(r.note || '').slice(0, 60), created_at: r.created_at })),
      libraryAssets: (app.state.library.assets || []).map((a) => ({ id: a.id, fileName: a.fileName, tags: (a.tags || []).slice(0, 6), l5: (a.L5 || []).map((d) => ({ kind: d.kind, note: d.note, tags: d.tags, preset: !!d.preset })) })),
    };
  });
  const pj = out.cases.project;
  const layerNames = (pj.layers || []).map((l) => l.name);
  const libAssets = pj.libraryAssets || [];
  const editAsset = libAssets.find((a) => a.id === pj.lib.edit) || null;
  out.cases.library = { count: libAssets.length, names: libAssets.map((a) => a.fileName), editL5: editAsset ? editAsset.l5 : null };
  out.pass.project = !!(
    pj.active && pj.prepared && !pj.error &&
    pj.canvas && pj.canvas.width === 1600 && pj.canvas.height === 1600 &&
    /1600\s*×\s*1600/.test(pj.docSize || '') &&
    layerNames.includes('成稿 · 山谷') &&
    libAssets.length >= 3 &&
    pj.l6Preset >= 6 &&
    pj.selection && pj.selection.width > 0 && pj.selection.height > 0 &&
    pj.engineHasSelection === true &&
    ['实时', '预置样本', 'Mock'].includes(pj.badge && pj.badge.label) &&
    pj.aiSettings && pj.aiSettings.requireConfirm === false &&
    pj.pips === 6 && (pj.steps || []).length === 6 && pj.stepNo === '01 / 06' &&
    /^\d{2}:\d{2}$/.test(pj.timer || '') &&
    pj.bar && pj.bar.visible && !pj.bar.hidden &&
    pj.canvasRect.cx < pj.bar.left
  );
  out.pass.libraryL5 = !!(editAsset && editAsset.l5 && editAsset.l5.some((d) => d.kind === 'confirm' && /冷灰蓝/.test(d.note || '')) && editAsset.l5.some((d) => d.kind === 'reject' && /赛博朋克紫/.test(d.note || '')) && editAsset.l5.every((d) => d.preset === true));

  // 4) 第 1 拍：执行本步 → 打开素材库 + 选中冷雾实验（L5 决策可见）
  await page.click('#btnRoadshowExec');
  await page.waitForFunction("document.getElementById('librarySheet') && document.getElementById('librarySheet').hidden === false", null, { timeout: 40000 });
  await page.waitForTimeout(700);
  out.cases.step1 = await page.evaluate(() => {
    const t = window.__V2_APP__.t122;
    const s = t.state();
    const d = document.getElementById('libDetail');
    const txt = d ? d.textContent.replace(/\s+/g, ' ') : '';
    return {
      step: s.step,
      libraryOpen: !document.getElementById('librarySheet').hidden,
      selectedId: window.__V2_APP__.state.library.selectedId,
      editId: s.lib.edit,
      l5Visible: /L5/.test(txt) && /(冷灰蓝|赛博朋克紫|冷雾)/.test(txt),
      detailSnippet: txt.slice(0, 260),
      log: (document.getElementById('roadshowLog') || {}).textContent || '',
    };
  });
  out.pass.step1 = !!(out.cases.step1.libraryOpen && out.cases.step1.selectedId && out.cases.step1.selectedId === out.cases.step1.editId && out.cases.step1.l5Visible);

  // 5) 第 2 拍：框选雾带 + 打开 AI 对话（真实选区写进引擎）
  await page.evaluate(() => { try { window.__V2_APP__.t71.closeLibrarySheet(); } catch (e) {} });
  await page.waitForTimeout(300);
  await page.click('#btnRoadshowNext');
  await page.waitForTimeout(250);
  out.cases.step2Before = await page.evaluate(() => ({ step: window.__V2_APP__.t122.state().step, title: document.getElementById('roadshowStepTitle').textContent }));
  await page.click('#btnRoadshowExec');
  await page.waitForTimeout(900);
  out.cases.step2 = await page.evaluate(async () => {
    const app = window.__V2_APP__;
    const t = app.t122;
    const s = t.state();
    const pop = document.getElementById('popAI');
    const cs = pop ? getComputedStyle(pop) : null;
    const pr = pop ? pop.getBoundingClientRect() : null;
    // 合成图里批注文字区域的实际像素（验证文字层真的参与合成）
    let notePixels = null;
    try {
      const url = await app.engine.getCompositeDataUrl();
      const img = new Image(); img.src = url; await img.decode();
      const cv = document.createElement('canvas'); cv.width = img.width; cv.height = img.height;
      const g = cv.getContext('2d', { willReadFrequently: true });
      g.drawImage(img, 0, 0);
      const read = (x, y) => { const d = g.getImageData(x, y, 1, 1).data; return [d[0], d[1], d[2], d[3]]; };
      const nl = (app.engine.layers || []).find((x) => x.id === s.noteLayerId);
      let b = null; try { b = app.engine.getLayerContentBounds(nl.id); } catch (e) { b = null; }
      notePixels = { note: b, inside: b ? read(b.x + 20, b.y + 20) : null, outside: read(30, 30) };
    } catch (e) { notePixels = { error: String(e && e.message || e) }; }
    return {
      step: s.step,
      engineHasSelection: s.engineHasSelection,
      selection: s.selection,
      popoverOpen: !!pop && pop.classList.contains('open'),
      popover: pop ? { display: cs.display, visibility: cs.visibility, opacity: cs.opacity, position: cs.position, maxHeight: cs.maxHeight, inline: pop.getAttribute('style'), left: Math.round(pr.left), top: Math.round(pr.top), width: Math.round(pr.width), height: Math.round(pr.height) } : null,
      anchor: (() => { const a = document.getElementById('btnAiPanel'); if (!a) return null; const r = a.getBoundingClientRect(); return { left: Math.round(r.left), bottom: Math.round(r.bottom), top: Math.round(r.top), h: Math.round(r.height) }; })(),
      innerH: window.innerHeight,
      targets: ['#canvasWrap', '#popAI'].map((sel) => { const el = document.querySelector(sel); if (!el) return { sel, missing: true }; const r = el.getBoundingClientRect(); return { sel, left: Math.round(r.left), top: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) }; }),
      noteLayer: (() => { const l = (app.engine.layers || []).find((x) => x.id === s.noteLayerId); if (!l) return null; let b = null; try { b = app.engine.getLayerContentBounds(l.id); } catch (e) { b = 'err'; } return { id: l.id, name: l.name, opacity: l.opacity, visible: l.visible, bounds: b }; })(),
      notePixels,
      layerOrder: (app.engine.layers || []).map((l) => l.name),
      target: (document.getElementById('roadshowTarget') || {}).textContent || '',
      toolOptionsHidden: getComputedStyle(document.getElementById('toolOptions')).display === 'none',
      selectionChipHidden: document.getElementById('selectionAiChip').hidden !== false,
    };
  });
  out.pass.step2 = !!(out.cases.step2.step === 1 && out.cases.step2.engineHasSelection && out.cases.step2.selection && out.cases.step2.popoverOpen && (out.cases.step2.selection.width > 0));

  // 6) 第 3 拍：让 AI 看看（无 key 静态服务器 → Mock；真实路径走同一段代码）
  //    同时断言：L5 用户决策真的进了 analyze 的上下文，并写进 L6（l5_refs / memory_used）
  await page.evaluate(() => window.__V2_APP__.t122.goto(2));
  await page.waitForTimeout(300);
  await page.click('#btnRoadshowExec');
  await page.waitForFunction('!!window.__V2_APP__.state.analysis', null, { timeout: 60000 });
  await page.waitForTimeout(400);
  out.cases.step3 = await page.evaluate(() => {
    const app = window.__V2_APP__;
    const s = app.t122.state();
    const l6 = app.state.records.filter((r) => r.layer === 'L6' && r.params && r.params.task === 'analyze').slice(-1)[0];
    return {
      step: s.step,
      observations: ((app.state.analysis && app.state.analysis.observations) || []).length,
      lastCall: app.state.aiLastCall ? { mock: app.state.aiLastCall.mock, model: app.state.aiLastCall.model, latencyMs: app.state.aiLastCall.latencyMs } : null,
      l6: l6 ? { l5_refs: l6.params.l5_refs, memory_used: l6.params.memory_used, model: l6.model } : null,
      badge: s.badge,
      panelMode: (document.querySelector('#aiBody') || {}).textContent ? 'body' : '',
    };
  });
  out.pass.step3 = !!(out.cases.step3.observations > 0 && out.cases.step3.lastCall && out.cases.step3.lastCall.mock === true && out.cases.step3.l6 && Array.isArray(out.cases.step3.l6.l5_refs) && out.cases.step3.l6.l5_refs.length >= 1 && out.cases.step3.l6.memory_used === true);

  // 7) 第 4 拍：确认 2 条 / 否决 1 条 → L5 写回
  await page.evaluate(() => window.__V2_APP__.t122.goto(3));
  await page.waitForTimeout(300);
  await page.click('#btnRoadshowExec');
  await page.waitForTimeout(800);
  out.cases.step4 = await page.evaluate(() => {
    const app = window.__V2_APP__;
    const s = app.t122.state();
    const l5 = app.state.records.filter((r) => r.layer === 'L5');
    const obs = ((app.state.analysis && app.state.analysis.observations) || []).slice(0, 3).map((o) => ({ id: o.id, source: (app.state.records.find((r) => r.id === o.id) || {}).source }));
    return {
      step: s.step,
      decisions: s.decisions,
      l5Ids: s.l5Ids,
      confirmed: l5.filter((r) => r.kind === 'keep').length,
      rejected: l5.filter((r) => r.kind === 'reject_ai').length,
      obsSources: obs.map((o) => o.source),
      log: (document.getElementById('roadshowLog') || {}).textContent || '',
    };
  });
  out.pass.step4 = !!(out.cases.step4.decisions && out.cases.step4.decisions.length >= 2 && out.cases.step4.confirmed >= 2 && out.cases.step4.rejected >= 1 && out.cases.step4.obsSources.includes('user-confirmed'));

  // 8) 第 5 拍：预置样本落层（[预置] + cached_sample，不冒充 real_model）
  await page.evaluate(() => window.__V2_APP__.t122.goto(4));
  await page.waitForTimeout(350);
  await page.click('#btnRoadshowExec');
  await page.waitForFunction('!!window.__V2_APP__.t122.state().editLayerId', null, { timeout: 90000 });
  await page.waitForTimeout(500);
  out.cases.step5 = await page.evaluate(() => {
    const app = window.__V2_APP__;
    const t = app.t122;
    const s = t.state();
    const cached = app.state.records.filter((r) => r.layer === 'L6' && r.params && r.params.cached_sample);
    const rec = cached[cached.length - 1] || null;
    const layer = (s.layers || []).find((l) => l.id === s.editLayerId) || null;
    const range = document.getElementById('rsCompareRange');
    return {
      layerName: layer ? layer.name : null,
      appliedPreset: s.appliedPreset,
      badge: s.badge,
      cachedCount: cached.length,
      cachedRecord: rec ? { id: rec.id, kind: rec.kind, model: rec.model, cost_cny: rec.cost_cny, credits: rec.credits, params: { cached_sample: rec.params.cached_sample, fallback: rec.params.fallback_composite, source_sha256: rec.params.source_sha256, source: rec.params.source } } : null,
      hasCompare: !!range,
      compareValue: range ? range.value : null,
      layerOpacity: (() => { const l = (app.engine.layers || []).find((x) => x.id === s.editLayerId); return l ? l.opacity : null; })(),
      sampleSha: s.sample && s.sample.sha256,
      layerCount: (s.layers || []).length,
    };
  });
  const c5 = out.cases.step5;
  out.pass.step5 = !!(
    c5.appliedPreset && c5.layerName && /\[预置/.test(c5.layerName) &&
    c5.cachedCount >= 1 && c5.cachedRecord &&
    c5.cachedRecord.params.cached_sample === true &&
    c5.cachedRecord.params.source_sha256 && c5.cachedRecord.params.source_sha256.length === 64 &&
    c5.cachedRecord.model && c5.cachedRecord.model.provider === 'qwen' &&
    c5.cachedRecord.cost_cny === 0 && c5.cachedRecord.credits === 0 &&
    c5.hasCompare
  );
  // 对比比例滑杆真的改图层不透明度
  out.cases.compare = await page.evaluate(async () => {
    const range = document.getElementById('rsCompareRange');
    if (!range) return { ok: false };
    range.value = '55';
    range.dispatchEvent(new Event('input', { bubbles: true }));
    await new Promise((r) => setTimeout(r, 120));
    const s = window.__V2_APP__.t122.state();
    const l = (window.__V2_APP__.engine.layers || []).find((x) => x.id === s.editLayerId);
    const label = document.getElementById('rsCompareVal');
    return { ok: !!l && Math.abs(l.opacity - 0.55) < 0.001 && label && label.textContent === '55%', opacity: l ? l.opacity : null, label: label ? label.textContent : null };
  });
  out.pass.compare = !!out.cases.compare.ok;
  await page.evaluate(() => {
    const range = document.getElementById('rsCompareRange');
    if (range) { range.value = '100'; range.dispatchEvent(new Event('input', { bubbles: true })); }
    const s = window.__V2_APP__.t122.state();
    const l = (window.__V2_APP__.engine.layers || []).find((x) => x.id === s.editLayerId);
    if (l) window.__V2_APP__.engine.setLayerOpacity(l.id, 1);
  });

  // 截图：第 5 拍落层后的交付画面（画布 + 控制台 + 预置徽章 + 对比比例）
  await page.evaluate(() => { try { window.__V2_APP__.t122.goto(4); } catch (e) {} });
  await page.waitForTimeout(500);
  await page.screenshot({ path: SHOT, fullPage: false });
  out.shot = SHOT;

  // 7) 选区 mask 落层：框外 0 像素变化（真实 selectionManager mask，不是假选区）
  out.cases.mask = await page.evaluate(async () => {
    const app = window.__V2_APP__;
    const t = app.t122;
    t.applySelection();
    await new Promise((r) => setTimeout(r, 200));
    const s0 = t.state();
    const before = await app.engine.getCompositeDataUrl();
    const c = document.createElement('canvas'); c.width = 240; c.height = 180;
    const g = c.getContext('2d');
    const grad = g.createLinearGradient(0, 0, 240, 180);
    grad.addColorStop(0, '#ff3b30'); grad.addColorStop(1, '#007aff');
    g.fillStyle = grad; g.fillRect(0, 0, 240, 180);
    app.state.candidates = [{ id: 'cand-roadshow-mask-test', label: 'mask-test', imageDataUrl: c.toDataURL('image/png'), sha256: null, bytes: null, width: 240, height: 180 }];
    app.state.aiLastCall = { provider: 'mock', model: 'mock-ai@0.1.0', mock: true, latencyMs: 0 };
    await app.applyCandidate(0);
    await new Promise((r) => setTimeout(r, 300));
    const after = await app.engine.getCompositeDataUrl();
    const gens = app.state.records.filter((r) => r.layer === 'L6' && r.kind === 'generation' && r.params && r.params.candidate_id === 'cand-roadshow-mask-test');
    const rec = gens[gens.length - 1] || null;
    const load = async (u) => { const i = new Image(); i.src = u; await i.decode(); return i; };
    const i1 = await load(before), i2 = await load(after);
    const W = app.engine.width, H = app.engine.height;
    const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const ctx = cv.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(i1, 0, 0); ctx.getImageData(0, 0, 1, 1);
    const d1 = ctx.getImageData(0, 0, W, H).data;
    ctx.clearRect(0, 0, W, H); ctx.drawImage(i2, 0, 0);
    const d2 = ctx.getImageData(0, 0, W, H).data;
    const sel = s0.selection;
    let outside = 0, inside = 0, sampled = 0;
    for (let y = 0; y < H; y += 2) {
      for (let x = 0; x < W; x += 2) {
        sampled += 1;
        const i = (y * W + x) * 4;
        const diff = Math.abs(d1[i] - d2[i]) + Math.abs(d1[i + 1] - d2[i + 1]) + Math.abs(d1[i + 2] - d2[i + 2]) + Math.abs(d1[i + 3] - d2[i + 3]);
        if (diff <= 6) continue;
        const inSel = x >= sel.x && x < sel.x + sel.width && y >= sel.y && y < sel.y + sel.height;
        if (inSel) inside += 1; else outside += 1;
      }
    }
    return {
      selection: sel,
      engineHasSelection: s0.engineHasSelection,
      masked: rec && rec.params ? rec.params.masked : null,
      maskPolicy: rec && rec.params ? rec.params.mask_policy : null,
      insideChanged: inside, outsideChanged: outside, sampled,
      layerName: (app.engine.layers.find((l) => l.id === app.engine.activeLayerId) || {}).name,
    };
  });
  const mk = out.cases.mask;
  out.pass.mask = !!(mk.masked === true && mk.maskPolicy === 'selection_alpha' && mk.outsideChanged === 0 && mk.insideChanged > 0);

  // 8) 第 6 拍：证据包 + 包内复核（PNG 字节哈希）
  await page.evaluate(() => window.__V2_APP__.t122.goto(5));
  await page.waitForTimeout(300);
  await page.click('#btnRoadshowExec');
  await page.waitForFunction('!!window.__V2_APP__.t122.state().verify', null, { timeout: 180000 });
  await page.waitForTimeout(500);
  out.cases.evidence = await page.evaluate(async () => {
    const app = window.__V2_APP__;
    const t = app.t122;
    const s = t.state();
    const pkg = app.state.evidence;
    const verify = t.verifyEvidence();
    const modal = document.getElementById('evidenceModal');
    return {
      verify: s.verify,
      reVerify: await verify,
      modalOpen: !!modal && (modal.classList.contains('show') || getComputedStyle(modal).display !== 'none'),
      evidence: s.evidence,
      packageCanvas: pkg ? pkg.project.canvas : null,
      layers: pkg ? pkg.manifest.layers.map((l) => ({ name: l.name, tile_count: l.tile_count, png_sha256: l.png_sha256 })) : [],
      hashPolicy: pkg ? pkg.manifest.hash_policy : null,
      canvasPngBytes: pkg && pkg.canvas_png_data_url ? Math.round(pkg.canvas_png_data_url.length * 0.75) : 0,
      modalshow: modal ? modal.className : null,
    };
  });
  const ev = out.cases.evidence;
  out.pass.evidence = !!(
    ev.verify && ev.verify.ok === true &&
    ev.reVerify && ev.reVerify.ok === true &&
    ev.evidence && ev.evidence.canvas && ev.evidence.canvas.png_sha256 && /^[0-9a-f]{64}$/.test(ev.evidence.canvas.png_sha256) &&
    ev.evidence.canvas.sha256 && ev.evidence.canvas.sha256 !== ev.evidence.canvas.png_sha256 &&
    ev.layers.length >= 3 && ev.layers.every((l) => l.png_sha256 === null || /^[0-9a-f]{64}$/.test(l.png_sha256)) &&
    ev.layers.some((l) => l.png_sha256) &&
    ev.verify.checks && ev.verify.checks.canvasPngBytes === true && ev.verify.checks.chain === true && ev.verify.checks.canvasDataUrl === true &&
    ev.verify.checks.layerPngBytes === true && ev.verify.checks.aiCalls === true
  );

  // 9) 退出：恢复 UI / AI 设置 / 档案
  await page.evaluate(() => { try { window.__V2_APP__.t122.exit(); } catch (e) {} });
  await page.waitForTimeout(800);
  out.cases.exit = await page.evaluate(() => {
    const t = window.__V2_APP__.t122;
    const s = t.state();
    const recs = window.__V2_APP__.state.records || [];
    return {
      active: s.active,
      barHidden: document.getElementById('roadshowBar').hidden,
      bodyClass: document.body.classList.contains('roadshow-running'),
      label: (document.getElementById('projectLabel') || {}).textContent || '',
      records: recs.length,
      presetRecords: recs.filter((r) => r.layer === 'L6' && r.params && r.params.preset_sample).length,
      aiRaw: (() => { try { return localStorage.getItem('mozheng.ai.settings.v1'); } catch (e) { return null; } })(),
      prepared: s.prepared,
    };
  });
  out.pass.exit = !!(
    out.cases.exit.active === false &&
    out.cases.exit.barHidden === true &&
    out.cases.exit.bodyClass === false &&
    out.cases.exit.prepared === false &&
    out.cases.exit.presetRecords === 0 &&
    Math.abs(out.cases.exit.records - out.saved.records) <= 1 &&
    out.cases.exit.aiRaw === out.saved.aiRaw &&
    out.cases.exit.label === out.saved.label
  );

  // 10) 错误：0 console error / 0 pageerror（/api/ai/* 无代理的 404 单独记录、不算 App 错误）
  out.errors = out.consoleErrors.slice(0, 20);
  out.pass.noErrors = out.pageErrors.length === 0 && out.consoleErrors.length === 0;

  out.allPass = Object.values(out.pass).every(Boolean);
  out.summary = Object.entries(out.pass).map(([k, v]) => k + '=' + (v ? 'pass' : 'FAIL')).join(' · ');
  finish(out.allPass ? 0 : 1);
} catch (e) {
  out.fatal = String((e && (e.stack || e.message)) || e);
  out.errors = out.consoleErrors.slice(0, 20);
  out.pageErrors = out.pageErrors.slice(0, 20);
  finish(2);
} finally {
  clearTimeout(hard);
}
