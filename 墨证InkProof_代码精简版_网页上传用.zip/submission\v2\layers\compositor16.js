/**
 * v2/layers · 16 混合模式映射（CanvasKit BlendMode）
 * Procreate 风格 16 种：normal/dissolve → SrcOver（dissolve 用抖动近似，暂以 SrcOver 表示）；
 * 其余映射到 Skia 对应 BlendMode。
 */
export const BLEND_MODES = [
  'normal', 'dissolve',
  'darken', 'multiply', 'color-burn',
  'lighten', 'screen', 'color-dodge',
  'overlay', 'soft-light', 'hard-light',
  'difference', 'exclusion',
  'hue', 'saturation', 'color', 'luminosity',
];

const MAP = {
  normal: 'SrcOver',
  dissolve: 'SrcOver',
  darken: 'Darken',
  multiply: 'Multiply',
  'color-burn': 'ColorBurn',
  lighten: 'Lighten',
  screen: 'Screen',
  'color-dodge': 'ColorDodge',
  overlay: 'Overlay',
  'soft-light': 'SoftLight',
  'hard-light': 'HardLight',
  difference: 'Difference',
  exclusion: 'Exclusion',
  hue: 'Hue',
  saturation: 'Saturation',
  color: 'Color',
  luminosity: 'Luminosity',
};

export function blendOf(CK, name) {
  const key = MAP[name] || 'SrcOver';
  return CK.BlendMode[key] || CK.BlendMode.SrcOver;
}

export function blendLabel(name) {
  return BLEND_MODES.includes(name) ? name : 'normal';
}
