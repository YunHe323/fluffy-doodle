/**
 * v2/library · API（T70，给 app/T71 UI）
 *
 * 用法：
 *   const api = await createLibrary();           // 打开 IndexedDB（持久）
 *   await api.importFiles(fileList, { onProgress });
 *   const list = await api.search({ text, tags, color, minWidth });
 *   await api.confirm(assetId); await api.reject(assetId); await api.markUsed(assetId);
 *   const prefs = await api.preferences();
 *
 * 约束：零第三方依赖（IndexedDB / crypto.subtle / Canvas）；mock 反解复用 v2/app/core/mock-ai.mjs。
 */
import { LibraryStore, sha256Hex } from './store.mjs';
import { loadImage, makeThumbnail, analyzeImage } from './analyze.mjs';
import { validateAsset, LIBRARY_SCHEMA, MOCK_MODEL } from './library-schema.mjs';
import { confirmAsset, rejectAsset, recordUse, getPreferences, resetPreferences } from './preferences.mjs';

export { LibraryStore, sha256Hex, LIBRARY_SCHEMA, MOCK_MODEL };
export { confirmAsset, rejectAsset, recordUse, getPreferences, resetPreferences };

async function dataUrlToArrayBuffer(dataUrl) {
  const res = await fetch(dataUrl);
  return res.arrayBuffer();
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error || new Error('FileReader 失败'));
    reader.readAsDataURL(file);
  });
}

export class LibraryAPI {
  constructor(opts = {}) {
    this.dbName = opts.dbName;
    this.store = new LibraryStore({ dbName: opts.dbName });
    this.ready = false;
    this._importing = false;
  }

  async init() {
    await this.store.open();
    this.ready = true;
    return this;
  }

  _assertReady() { if (!this.ready) throw new Error('LibraryAPI 未 init'); }

  /**
   * 批量导入 dataURL 项 [{name,dataUrl,mime}]；sha256 去重；缩略图 + mock 反解写库。
   * @returns {{imported:any[], duplicates:{name:string,id:string}[], errors:{name?:string,error:string}[], total:number}}
   */
  async importDataUrls(items, opts = {}) {
    this._assertReady();
    const list = Array.isArray(items) ? items : [];
    if (this._importing) throw new Error('已有导入任务进行中');
    this._importing = true;
    const imported = [];
    const duplicates = [];
    const errors = [];
    try {
      for (let i = 0; i < list.length; i += 1) {
        const item = list[i] || {};
        const name = item.name || `image-${i + 1}.png`;
        try {
          if (!item.dataUrl) throw new Error('缺少 dataUrl');
          const buffer = await dataUrlToArrayBuffer(item.dataUrl);
          const sha = await sha256Hex(buffer);
          const existing = await this.store.getBySha(sha);
          if (existing) {
            duplicates.push({ name, id: existing.id });
          } else {
            const image = await loadImage(item.dataUrl);
            const thumb = makeThumbnail(image);
            const asset = analyzeImage({
              image,
              dataUrl: item.dataUrl,
              width: image.width,
              height: image.height,
              fileName: name,
              mime: item.mime || 'image/png',
              bytes: buffer.byteLength,
              sha256: sha,
              context: opts.context || {},
            });
            const check = validateAsset(asset);
            if (!check.ok) throw new Error('资产校验失败: ' + check.errors.slice(0, 3).join('; '));
            await this.store.put(asset);
            await this.store.putThumbnail(asset.id, thumb);
            // T74：保存原图 Blob（sha 去重已保证 id 唯一；mime/bytes/宽高随 L0）
            const blob = item.blob || new Blob([buffer], { type: item.mime || 'image/png' });
            await this.store.putOriginal(asset.id, {
              blob, mime: item.mime || blob.type || 'image/png',
              bytes: buffer.byteLength, width: image.width, height: image.height, sha256: sha,
            });
            imported.push(asset);
          }
        } catch (e) {
          errors.push({ name, error: String((e && e.message) || e) });
        }
        if (typeof opts.onProgress === 'function') {
          opts.onProgress({ index: i, total: list.length, imported: imported.length, duplicates: duplicates.length, errors: errors.length });
        }
      }
    } finally {
      this._importing = false;
    }
    return { imported, duplicates, errors, total: list.length };
  }

  /** 批量导入文件（拖入/选择） */
  async importFiles(files, opts = {}) {
    const list = [];
    for (const file of Array.from(files || [])) {
      const dataUrl = await readFileAsDataUrl(file);
      list.push({ name: file.name, dataUrl, mime: file.type || 'image/png', blob: file });
    }
    return this.importDataUrls(list, opts);
  }

  async list() { this._assertReady(); return this.store.all(); }
  async get(id) { this._assertReady(); return this.store.get(id); }
  async getThumbnail(id) { this._assertReady(); return this.store.getThumbnail(id); }

  /**
   * T74：取原图。返回 { id, blob, mime, bytes, width, height, ... }；
   * opts.objectUrl=true → 附带 url（调用方 URL.revokeObjectURL）；opts.imageBitmap=true → 附带 imageBitmap（调用方 close）。
   * 旧库无原图时回退缩略图：{ fallback:true, dataUrl, width, height }。
   */
  async getOriginal(id, opts = {}) {
    this._assertReady();
    const rec = await this.store.getOriginal(id);
    if (!rec || !rec.blob) {
      const thumb = await this.store.getThumbnail(id);
      if (!thumb) return null;
      return { id, fallback: true, blob: null, dataUrl: thumb.dataUrl, width: thumb.width, height: thumb.height };
    }
    const out = {
      id, blob: rec.blob, mime: rec.mime || rec.blob.type || 'image/png',
      bytes: rec.bytes || rec.blob.size, width: rec.width || null, height: rec.height || null,
    };
    if (opts.objectUrl) out.url = URL.createObjectURL(rec.blob);
    if (opts.imageBitmap) {
      try { out.imageBitmap = await createImageBitmap(rec.blob); } catch (e) { out.imageBitmapError = String((e && e.message) || e); }
    }
    return out;
  }

  /** 取资产；withOriginal=true 时附原图信息（不默认解码，避免大图开销） */
  async getAsset(id, opts = {}) {
    this._assertReady();
    const asset = await this.store.get(id);
    if (!asset) return null;
    if (opts.withOriginal) {
      const original = await this.getOriginal(id);
      return { ...asset, original };
    }
    return asset;
  }
  async search(filter = {}) { this._assertReady(); return this.store.search(filter); }

  async updateTags(id, tags) {
    this._assertReady();
    const asset = await this.store.get(id);
    if (!asset) return null;
    asset.tags = [...new Set((Array.isArray(tags) ? tags : []).map(String).filter(Boolean))].slice(0, 32);
    asset.updatedAt = new Date().toISOString();
    await this.store.put(asset);
    return asset;
  }

  async delete(id) { this._assertReady(); return this.store.delete(id); }

  async confirm(id, opts = {}) { this._assertReady(); return confirmAsset(this.store, id, opts); }
  async reject(id, opts = {}) { this._assertReady(); return rejectAsset(this.store, id, opts); }
  async markUsed(id, opts = {}) { this._assertReady(); return recordUse(this.store, id, opts); }
  async preferences() { this._assertReady(); return getPreferences(this.store); }
  async resetPreferences() { this._assertReady(); return resetPreferences(this.store); }

  async stats() {
    this._assertReady();
    const assets = await this.store.all();
    const bySource = { observed: 0, inferred: 0, 'user-confirmed': 0 };
    let l2 = 0, l4 = 0, l5 = 0;
    for (const a of assets) {
      for (const s of a.source || []) if (bySource[s] != null) bySource[s] += 1;
      l2 += (a.L2 || []).length;
      l4 += (a.L4 || []).length;
      l5 += (a.L5 || []).length;
    }
    return {
      total: assets.length,
      bySource,
      layers: { L2: l2, L4: l4, L5: l5 },
      topTags: [...new Set(assets.flatMap((a) => a.tags || []))].slice(0, 12),
      storage: {
        originals: await this.store.countOriginals(),
        originalBytes: await this.store.originalBytes(),
      },
      modelVersion: MOCK_MODEL,
      schema: LIBRARY_SCHEMA,
    };
  }

  async close() { this.store.close(); this.ready = false; }

  /** 删除整个测试/本地库（谨慎） */
  async destroy() {
    this.store.close();
    this.ready = false;
    await LibraryStore.deleteDatabase(this.dbName || undefined);
  }
}

export async function createLibrary(opts = {}) {
  const api = new LibraryAPI(opts);
  await api.init();
  return api;
}
