/**
 * v2/psd · 测试集（6 个程序生成的 PSD 样本）
 *
 * 来源与许可：全部由本项目在浏览器内用 ag-psd 程序生成（合成数据），
 * 许可 CC0-1.0（本项目生成，可自由使用）；Procreate 仅模拟其导出结构，
 * 不包含任何 Procreate 资产/真实文件（Procreate 未参与）。
 */
import { createCanvas } from './model.js';

const SIZE = 256;

function canvas(draw) {
  const c = createCanvas(SIZE, SIZE);
  const ctx = c.getContext('2d');
  if (draw) draw(ctx, SIZE);
  return c;
}

function solid(color, alpha = 1) {
  return canvas((ctx, s) => {
    ctx.globalAlpha = alpha;
    ctx.fillStyle = color;
    ctx.fillRect(0, 0, s, s);
    ctx.globalAlpha = 1;
  });
}

function shapes(colors) {
  return canvas((ctx, s) => {
    ctx.globalAlpha = 0.9;
    colors.forEach((color, i) => {
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(s * (0.3 + 0.18 * i), s * (0.4 + 0.12 * (i % 2)), s * 0.14, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
  });
}

function maskCircle() {
  return canvas((ctx, s) => {
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(s / 2, s / 2, s * 0.35, 0, Math.PI * 2);
    ctx.fill();
  });
}

function textCanvasUnused() { return null; }

/** @returns {Array<{id,name,description,provenance,license,expectedFeatures,psd}>} */
export function buildSampleDefs() {
  const samples = [];

  samples.push({
    id: '01-pure-raster',
    name: '纯栅格',
    description: '2 个栅格层（纯色底 + 形状）',
    provenance: '本项目程序生成（合成样例）',
    license: 'CC0-1.0',
    expectedFeatures: ['raster'],
    psd: {
      width: SIZE, height: SIZE,
      children: [
        { name: '背景', canvas: solid('#f5f0e8') },
        { name: '形状', canvas: shapes(['#e05a4e', '#2f6db3', '#e9b949']) },
      ],
    },
  });

  samples.push({
    id: '02-multi-group',
    name: '多图层组',
    description: '一个组（2 子层）+ 组外 1 层',
    provenance: '本项目程序生成（合成样例）',
    license: 'CC0-1.0',
    expectedFeatures: ['group'],
    psd: {
      width: SIZE, height: SIZE,
      children: [
        { name: '底层', canvas: solid('#dfe8f2') },
        {
          name: '图层组 A',
          children: [
            { name: '组内-红', canvas: shapes(['#c0392b']) },
            { name: '组内-蓝', canvas: shapes(['#2980b9']) },
          ],
        },
        { name: '顶层', canvas: shapes(['#27ae60']) },
      ],
    },
  });

  samples.push({
    id: '03-mask',
    name: '图层蒙版',
    description: '一个图层带白色圆形蒙版',
    provenance: '本项目程序生成（合成样例）',
    license: 'CC0-1.0',
    expectedFeatures: ['mask'],
    psd: {
      width: SIZE, height: SIZE,
      children: [
        { name: '背景', canvas: solid('#f2f2f2') },
        {
          name: '带蒙版',
          canvas: solid('#d35400'),
          mask: { canvas: maskCircle(), top: 0, left: 0, bottom: SIZE, right: SIZE, defaultColor: 0 },
        },
      ],
    },
  });

  samples.push({
    id: '04-blend',
    name: '混合模式',
    description: '4 个层分别 multiply / screen / overlay / soft light',
    provenance: '本项目程序生成（合成样例）',
    license: 'CC0-1.0',
    expectedFeatures: ['blend'],
    psd: {
      width: SIZE, height: SIZE,
      children: [
        { name: '底', canvas: solid('#8a8f98') },
        { name: 'multiply', canvas: shapes(['#e74c3c']), blendMode: 'multiply', opacity: 0.9 },
        { name: 'screen', canvas: shapes(['#3498db']), blendMode: 'screen', opacity: 0.8 },
        { name: 'overlay', canvas: shapes(['#f1c40f']), blendMode: 'overlay', opacity: 0.7 },
        { name: 'soft light', canvas: shapes(['#9b59b6']), blendMode: 'soft light', opacity: 0.6 },
      ],
    },
  });

  samples.push({
    id: '05-procreate-style',
    name: 'Procreate 风格导出（结构模拟）',
    description: '组 + 剪贴层 + 蒙版 + 不透明度 0.62 + multiply（模拟 Procreate 导出结构，非真实 Procreate 文件）',
    provenance: '本项目程序生成（模拟 Procreate 导出结构；Procreate 未参与）',
    license: 'CC0-1.0',
    expectedFeatures: ['group', 'clip', 'mask', 'opacity'],
    psd: {
      width: SIZE, height: SIZE,
      children: [
        { name: 'Background', canvas: solid('#efe7d8') },
        {
          name: 'Procreate 图层组',
          opacity: 0.62,
          children: [
            { name: '底色', canvas: shapes(['#b5651d']) },
            { name: '剪贴亮部', canvas: shapes(['#ffd28a']), clipping: true },
            {
              name: '蒙版层',
              canvas: solid('#7a4b2a'),
              mask: { canvas: maskCircle(), top: 0, left: 0, bottom: SIZE, right: SIZE, defaultColor: 0 },
              blendMode: 'multiply',
              opacity: 0.8,
            },
          ],
        },
        { name: '签名', canvas: shapes(['#2b2b2b']) },
      ],
    },
  });

  samples.push({
    id: '06-unsupported-text',
    name: '含不支持对象（文字层）',
    description: '文字层 + 普通栅格层；导入应生成 fidelity_report 而不是静默丢弃',
    provenance: '本项目程序生成（合成样例）',
    license: 'CC0-1.0',
    expectedFeatures: ['text-unsupported'],
    psd: {
      width: SIZE, height: SIZE,
      children: [
        { name: '背景', canvas: solid('#ffffff') },
        {
          name: '文字层',
          text: {
            text: 'Mozheng PSD',
            transform: [1, 0, 0, 1, 30, 60],
            style: { font: { name: 'ArialMT' }, fontSize: 28, fillColor: { r: 0, g: 0, b: 0 } },
          },
        },
        { name: '栅格层', canvas: shapes(['#16a085']) },
      ],
    },
  });

  return samples;
}

/** 生成 PSD 二进制的测试集（需要 window.agPsd） */
export function buildSampleBuffers(agPsd = window.agPsd) {
  if (!agPsd) throw new Error('buildSampleBuffers: ag-psd 未加载');
  return buildSampleDefs().map((s) => ({
    ...s,
    buffer: agPsd.writePsd(s.psd, { generateThumbnail: false, noBackground: true, trimImageData: false }),
  }));
}
