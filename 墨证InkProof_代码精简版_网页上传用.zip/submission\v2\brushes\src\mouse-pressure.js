/**
 * v2/brushes/src/mouse-pressure.js · T54 鼠标模拟压感（无手绘板也能看到粗细变化）
 *
 * 输入：pointer 事件点 {x, y, timestamp, pointerType}
 * 输出：模拟 pressure ∈ [0.08, 1]
 *
 * 模型（鼠标/触摸；pen 永远用真实 pressure，不经过本模块）：
 *   speed(px/ms) → 归一化 s = clamp(speed / speedRef, 0, 1)
 *   shape(s, curve)：linear = s；soft = smoothstep(s)；strong = min(1, s*1.35)（更快变细）
 *   base = 1 - strength * shape(s)
 *   加速度：加速时略细（-0.06 * strength * max(0, aNorm)），减速时略粗（+0.10 * strength * max(0, -aNorm)）
 *   方向变化：急转弯略细（-0.08 * strength * turnNorm，模拟抬笔/换向）
 *   起笔缓入：前 warmupMs 内乘 0.35→1 的包络
 *   平滑：EMA，时间常数 smoothingMs（用事件时间戳 dt 计算，与帧率无关）
 *
 * 参数（T54 接口，app 面板由 demo-builder T55 接）：
 *   { enabled?: boolean, strength?: number(0–2), curve?: 'linear'|'soft'|'strong', smoothingMs?: number(0–300) }
 */
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const smoothstep = (t) => t * t * (3 - 2 * t);

export const DEFAULT_SIMULATED_PRESSURE = Object.freeze({
  enabled: true,
  strength: 1.0,
  curve: 'soft',
  smoothingMs: 45,
  // 以下为内部可调项（不暴露给 app，避免面板复杂；T59 用来做 before/after 对照）
  speedRef: 2.2,      // px/ms → s=1
  warmupMs: 90,       // 起笔缓入时长
  minPressure: 0.08,
  startPressure: 0.55, // 起笔第一点目标压力（**默认保持 T54 已发布行为**；T59 可选值 0.30）
  catchUp: false,      // 快速起笔追赶（**默认关**；T59 可选开）
  speedTauMs: 0,       // 速度时间常数（**默认 0=瞬时**，保持 T54 行为；T59 可选 120ms）
  slowSmoothingMs: 0,  // T80：慢速段（s<0.75）额外压感平滑（默认 0=关；opt-in 拉 S1 均匀度用）
});

export function normalizeSimulatedPressure(opts = {}) {
  const base = { ...DEFAULT_SIMULATED_PRESSURE, ...(opts || {}) };
  const curve = ['linear', 'soft', 'strong'].includes(base.curve) ? base.curve : 'soft';
  return {
    enabled: base.enabled !== false,
    strength: clamp(Number(base.strength) || 0, 0, 2),
    curve,
    smoothingMs: clamp(Number(base.smoothingMs) || 0, 0, 300),
    speedRef: clamp(Number(base.speedRef) || DEFAULT_SIMULATED_PRESSURE.speedRef, 0.3, 10),
    warmupMs: clamp(Number(base.warmupMs) || 0, 0, 600),
    minPressure: clamp(Number(base.minPressure) || 0.08, 0.02, 0.8),
    startPressure: clamp(Number(base.startPressure) || 0.55, 0.05, 1),
    catchUp: base.catchUp === true,
    speedTauMs: clamp(Number(base.speedTauMs) || 0, 0, 600),
    slowSmoothingMs: clamp(Number(base.slowSmoothingMs) || 0, 0, 400),
  };
}

function shapeOf(s, curve) {
  const t = clamp(s, 0, 1);
  if (curve === 'linear') return t;
  if (curve === 'strong') return Math.min(1, t * 1.35);
  return smoothstep(t); // soft
}

/**
 * 创建鼠标压感模拟器。纯 JS、无 DOM 依赖，便于单测/对照页面复用。
 * @param {object} [opts]
 */
export function createMousePressureSimulator(opts = {}) {
  let cfg = normalizeSimulatedPressure(opts);
  let state = null;

  function reset(now) {
    state = {
      last: null,
      lastSpeed: 0,
      speedEma: null,
      pressure: 0.5,
      hasPressure: false,
      startTs: Number.isFinite(now) ? now : null,
      lastTs: Number.isFinite(now) ? now : null,
    };
  }
  reset(undefined);

  function ensureStarted(ts) {
    if (state.startTs == null && Number.isFinite(ts)) state.startTs = ts;
  }

  /**
   * 更新并返回模拟压力。
   * @param {{x:number,y:number,timestamp:number}} p
   * @returns {{pressure:number, speed:number, accel:number, turn:number, s:number}}
   */
  function update(p) {
    const now = Number.isFinite(p.timestamp) ? p.timestamp : performance.now();
    ensureStarted(now);
    // ---- 速度 / 加速度 / 方向变化 ----
    let speed = state.lastSpeed;
    let accel = 0;
    let turn = 0;
    if (state.last) {
      const dx = p.x - state.last.x;
      const dy = p.y - state.last.y;
      const dt = Math.max(1, now - state.last.timestamp);
      const dist = Math.hypot(dx, dy);
      speed = clamp(dist / dt, 0, 20);
      const prevSpeed = state.lastSpeed;
      accel = clamp((speed - prevSpeed) / dt, -30, 30);
      if (dist > 0.01) {
        const dir = { x: dx / dist, y: dy / dist };
        if (state.lastDir) {
          const dot = clamp(dir.x * state.lastDir.x + dir.y * state.lastDir.y, -1, 1);
          turn = Math.acos(dot) / (Math.PI / 2); // 0..1（90°=1）
        }
        state.lastDir = dir;
      }
      state.lastSpeed = speed;
    } else {
      speed = 0;
      state.lastDir = null;
    }
    state.last = { x: p.x, y: p.y, timestamp: now };
    // T59：速度做 dt 归一的时间 EMA（默认 120ms），抑制事件时间戳抖动被 dt 除法放大成速度噪声 → 线宽 ripple；
    // 真实慢/快笔画的速度差异跨几百 ms，仍会被跟随（保留 T54 慢粗快细）。
    if (state.speedEma == null || !cfg.enabled) {
      state.speedEma = speed;
    } else {
      const dt = clamp(now - (state.lastTs == null ? now : state.lastTs), 1, 200);
      const a = cfg.speedTauMs > 0 ? 1 - Math.exp(-dt / cfg.speedTauMs) : 1;
      state.speedEma = lerp(state.speedEma, speed, clamp(a, 0.05, 1));
    }

    // ---- 意图压感 ----
    const s = clamp(state.speedEma / cfg.speedRef, 0, 1);
    let target;
    if (!cfg.enabled) {
      target = 0.5; // 关闭：中性常量（不做速度映射）
    } else if (!state.hasPressure) {
      // 起笔第一点：用低压力起步（细），再由缓入包络/速度目标抬升 → 起笔细、无「胖头」，
      // 也避免快速笔画的第一个 stamp 明显比后续粗（T59：S1/S2 密度 CV 主因）。
      target = cfg.startPressure;
    } else {
      const aNorm = clamp(accel / 12, -1, 1);
      target = 1 - cfg.strength * shapeOf(s, cfg.curve);
      target -= 0.06 * cfg.strength * Math.max(0, aNorm);   // 加速 → 更细
      target += 0.10 * cfg.strength * Math.max(0, -aNorm);  // 减速 → 更粗
      target -= 0.08 * cfg.strength * clamp(turn, 0, 1);    // 急转弯 → 略细
    }
    target = clamp(target, cfg.minPressure, 1);

    // ---- 起笔缓入（0.35 → 1；仅启用模拟压感时） ----
    const elapsed = now - (state.startTs == null ? now : state.startTs);
    if (cfg.enabled && cfg.warmupMs > 0 && elapsed < cfg.warmupMs) {
      const f = 0.35 + 0.65 * clamp(elapsed / cfg.warmupMs, 0, 1);
      target *= f;
    }

    // ---- 时间常数 EMA（与事件率无关；T80：慢速段可用额外平滑压 S1 线宽波动） ----
    let smoothed = target;
    if (state.hasPressure) {
      const dt = clamp(now - (state.lastTs == null ? now : state.lastTs), 1, 120);
      const effSmoothing = (cfg.slowSmoothingMs > 0 && s < 0.75) ? cfg.slowSmoothingMs : cfg.smoothingMs;
      if (effSmoothing <= 0) {
        smoothed = target;
      } else {
        let alpha = 1 - Math.exp(-dt / effSmoothing);
        // T59 起笔追赶：速度已明确为快速笔画时快速收敛到稳态目标，
        // 避免「以中压落下 → 前几帧偏粗」造成整条快速线密度不均（S1/S2 thicknessCV 主因之一）。
        // 慢速笔画 s 小 → 几乎不追赶，保留起笔缓入观感。
        const gap = Math.abs(target - state.pressure);
        if (cfg.catchUp && gap > 0.12) {
          const catchUp = (1 - Math.exp(-dt / 16)) * clamp(s * 0.9, 0, 0.9);
          alpha = Math.max(alpha, catchUp);
        }
        // T69：高速饱和段（s→1，目标最低压）快速收紧，避免 opt-in 平滑滞后让快速直线偏粗/前段不均
        if (cfg.catchUp && target < state.pressure && s > 0.8) {
          const sat = clamp((s - 0.8) / 0.2, 0, 1) * (1 - Math.exp(-dt / 22));
          alpha = Math.max(alpha, sat);
        }
        smoothed = lerp(state.pressure, target, clamp(alpha, 0, 1));
      }
    }
    state.pressure = clamp(smoothed, cfg.minPressure, 1);
    state.lastTs = now;
    state.hasPressure = true;
    return { pressure: state.pressure, speed, accel, turn, s };
  }

  return {
    reset,
    update,
    getConfig() { return { ...cfg }; },
    setOptions(next) {
      cfg = normalizeSimulatedPressure({ ...cfg, ...(next || {}) });
      return { ...cfg };
    },
  };
}
