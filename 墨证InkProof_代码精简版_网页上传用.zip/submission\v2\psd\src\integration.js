/**
 * v2/psd · 与 T37 LayerSystem 集成：导入文档 → 引擎可显示/编辑
 *
 * - 组 → LayerSystem 1 级组；图层 → 栅格层（tile 由 replaceLayerFromImage 写入）
 * - 混合/不透明度/可见性/剪贴/蒙版同步
 * - 已知限制：LayerSystem 仅 1 级组、组蒙版/组剪贴不支持（导入时扁平化 1 级以上的组内层）
 */
import { internalBlendForLayers } from './model.js';

export function applyDocumentToLayerSystem(doc, layerSystem) {
  const ls = layerSystem;
  const CK = ls.CK;
  const created = [];

  function addLayerNode(node, groupId) {
    const meta = ls.addLayer({ name: node.name, group: groupId });
    created.push(meta.id);
    try { ls.setLayerBlend(meta.id, internalBlendForLayers(node.blendMode)); } catch (e) { /* ignore */ }
    ls.setLayerOpacity(meta.id, node.opacity == null ? 1 : node.opacity);
    ls.setLayerVisible(meta.id, node.visible !== false);
    if (node.clip) ls.setLayerClip(meta.id, true);
    if (node.canvas) {
      const img = CK.MakeImageFromCanvasImageSource(node.canvas);
      ls.replaceLayerFromImage(meta.id, img);
      try { img.delete(); } catch (e) { /* ignore */ }
    }
    if (node.mask) {
      ls.addMask(meta.id);
      writeMaskFromCanvas(ls, meta.id, node.mask);
    }
    return meta;
  }

  function walk(nodes, groupId) {
    for (const node of nodes) {
      if (node.type === 'group') {
        const g = ls.addGroup(node.name);
        // 组本身的不透明度/可见性：LayerSystem 组只有 opacity/visible，可设置
        if (g) { g.opacity = node.opacity == null ? 1 : node.opacity; g.visible = node.visible !== false; }
        walk(node.children || [], g ? g.id : null);
      } else {
        addLayerNode(node, groupId);
      }
    }
  }

  walk(doc.children || [], null);
  ls.composite();
  return { layers: created.length, groups: ls.listGroups().length };
}

/** 把蒙版 canvas 写入 LayerSystem.maskStore（内部 API；T37 暂无公开 setter） */
export function writeMaskFromCanvas(ls, layerId, canvas) {
  const CK = ls.CK;
  const T = ls.tileSize;
  const img = CK.MakeImageFromCanvasImageSource(canvas);
  for (let ty = 0; ty < ls.tilesH; ty += 1) {
    for (let tx = 0; tx < ls.tilesW; tx += 1) {
      const key = `${tx},${ty}`;
      const tile = ls.maskStore.ensureTile(layerId, key);
      const c = tile.surface.getCanvas();
      c.clear(CK.TRANSPARENT);
      c.drawImage(img, -tx * T, -ty * T);
      tile.surface.flush();
      tile.image = tile.surface.makeImageSnapshot();
    }
  }
  try { img.delete(); } catch (e) { /* ignore */ }
  const layer = ls.getLayer(layerId);
  if (layer) layer.mask = { enabled: true, exists: true };
}
