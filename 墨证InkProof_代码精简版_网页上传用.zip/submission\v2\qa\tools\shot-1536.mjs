// v2/qa/tools/shot-1536.mjs —— 按用户实际屏幕（1536×864 逻辑 / 125% 缩放）检查路演布局
import { chromium } from '../node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
const ctx = await b.newContext({ viewport: { width: 1536, height: 864 }, deviceScaleFactor: 1.25 });
const p = await ctx.newPage();
const errors = [];
p.on('pageerror', (e) => errors.push(String(e.message || e).slice(0, 200)));
p.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) errors.push(m.text().slice(0, 200)); });
await p.goto('http://127.0.0.1:4200/v2/app/index.html', { waitUntil: 'domcontentloaded' });
await p.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
await sleep(900);
await p.click('#btnRoadshow'); await sleep(300);
await p.click('#btnRoadshowStart');
await p.waitForFunction('(() => { const t = window.__V2_APP__ && window.__V2_APP__.t122; return !!(t && t.state().prepared); })()', null, { timeout: 60000 });
await sleep(800);
const info = await p.evaluate(() => {
  const q = (s) => document.querySelector(s);
  const rect = (s) => { const e = q(s); if (!e) return null; const r = e.getBoundingClientRect(); return { left: Math.round(r.left), top: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height), right: Math.round(r.right), bottom: Math.round(r.bottom) }; };
  return {
    inner: [innerWidth, innerHeight], dpr: devicePixelRatio,
    scroll: [document.documentElement.scrollWidth, document.documentElement.scrollHeight],
    btnRoadshow: rect('#btnRoadshow'),
    bar: rect('#roadshowBar'),
    canvas: rect('#canvasWrap'),
    topbar: rect('#topbar') || rect('.topbar'),
    badge: (q('#roadshowBadge') || {}).textContent,
    overflowX: document.documentElement.scrollWidth > innerWidth + 1,
  };
});
await p.screenshot({ path: ROOT + '\\v2\\app\\ui-roadshow-1536x864.png' });
// 打开 AI 面板看左侧布局
await p.evaluate(() => { try { window.__V2_APP__.t122.goto(1); } catch (e) {} });
await sleep(300);
await p.click('#btnRoadshowExec');
await sleep(1200);
const panel = await p.evaluate(() => { const e = document.getElementById('popAI'); if (!e) return null; const r = e.getBoundingClientRect(); return { left: Math.round(r.left), top: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height), right: Math.round(r.right) }; });
await p.screenshot({ path: ROOT + '\\v2\\app\\ui-roadshow-1536x864-panel.png' });
console.log(JSON.stringify({ info, panel, errors }, null, 2));
await b.close();
