// v2/qa/tools/skill-runtime-test.mjs —— Skill Runtime 单元测试（无浏览器/无网络）
import { SkillRuntime } from '../../app/core/skills/runtime.mjs';
import { BUILTIN_SKILLS } from '../../app/core/skills/builtin.mjs';

const out = { schema: 'mozheng.skill-runtime-test.v1', cases: {}, pass: false, errors: [] };
const analysis = {
  global: { summary: '冷灰蓝山谷，雾带分三层', subject: ['山', '雾'], medium: { kind: 'digital' }, palette: ['#334455'], mood: ['安静'] },
  regions: [{ id: 'L2-ai-1', label: '远山', bbox: [0, 0, 200, 120], confidence: 0.8 }],
  observations: [{ id: 'L4-ai-1', kind: 'observation', text: '远山边缘偏软', anchor: { type: 'bbox', value: [0, 0, 200, 120] }, confidence: 0.7 }],
  confidence: 0.75,
};
const fakeProvider = {
  async analyze(input) { out.cases.lastPayload = { width: input.width, height: input.height, userIntent: input.userIntent, mode: input.mode, hasImage: !!input.image }; return { ...analysis, meta: { provider: 'fake', model: 'fake-vision', latencyMs: 1, usage: { total_tokens: 10 } } }; },
  async directions(input) { return { directions: [{ id: 'd1', title: '保持雾带', why: '安静', confidence: 0.7, tags: ['留白'] }, { id: 'd2', title: '拉开明暗', why: '主体更清楚', confidence: 0.7, tags: ['光影'] }], meta: { provider: 'fake', model: 'fake-vision', latencyMs: 1 } }; },
  async generate(input) { return { candidates: [{ id: 'g1', label: 'A', imageDataUrl: 'data:image/png;base64,xx', sha256: 'x' }, { id: 'g2', label: 'B', imageDataUrl: 'data:image/png;base64,yy', sha256: 'y' }], meta: { provider: 'fake', model: 'fake-image', latencyMs: 1 } }; },
  async editImage(input) { return { candidates: [{ id: 'c1', label: 'A', imageDataUrl: 'data:image/png;base64,xx', sha256: 'x' }], meta: { provider: 'fake', model: 'fake-image', latencyMs: 1 } }; },
};
try {
  const rt = new SkillRuntime();
  for (const s of BUILTIN_SKILLS) rt.register(s);
  out.cases.skills = rt.list().map((s) => s.id).sort();
  const expectedSkills = ['asset.decompose', 'canvas.directions', 'canvas.observe', 'image.edit', 'image.generate'];
  const r1 = await rt.run('asset.decompose', { image: 'data:image/jpeg;base64,xx', width: 1200, height: 800, fileName: 'test.jpg' }, { provider: fakeProvider });
  out.cases.asset = { ok: r1.ok, observations: r1.result.observations.length, regions: r1.result.regions.length, skill: r1.skill, meta: r1.meta, payload: out.cases.lastPayload, log: r1.log };
  const r2 = await rt.run('canvas.observe', { image: 'data:image/jpeg;base64,xx', width: 100, height: 100, selection: { x: 0, y: 0, width: 50, height: 50 }, userIntent: '更冷' }, { provider: fakeProvider });
  out.cases.canvas = { ok: r2.ok, observations: r2.result.observations.length, skill: r2.skill };
  const r3 = await rt.run('canvas.directions', { image: 'data:image/jpeg;base64,xx', width: 100, height: 100, observationIds: ['L4-1'] }, { provider: fakeProvider });
  out.cases.directions = { ok: r3.ok, count: r3.result.directions.length, skill: r3.skill };
  const r4 = await rt.run('image.generate', { prompt: '生成候选', image: 'data:image/jpeg;base64,xx' }, { provider: fakeProvider });
  out.cases.generate = { ok: r4.ok, candidates: r4.result.candidates.length, skill: r4.skill };
  const r5 = await rt.run('image.edit', { prompt: '水彩', image: 'data:image/jpeg;base64,xx' }, { provider: fakeProvider });
  out.cases.edit = { ok: r5.ok, candidates: r5.result.candidates.length, skill: r5.skill };
  let threw = null;
  try { await rt.run('not.exist', {}, { provider: fakeProvider }); } catch (e) { threw = e.message; }
  out.cases.unknownThrows = !!threw;
  out.cases.logs = rt.logs.length;
  const skillsOk = JSON.stringify(out.cases.skills) === JSON.stringify(expectedSkills);
  out.pass = skillsOk && out.cases.asset.ok && out.cases.canvas.ok && out.cases.directions.ok && out.cases.generate.ok && out.cases.edit.ok && out.cases.unknownThrows && out.cases.logs >= 5;
} catch (e) { out.errors.push(String(e && e.stack || e)); }
console.log(JSON.stringify(out, null, 2));
process.exit(out.pass ? 0 : 1);
