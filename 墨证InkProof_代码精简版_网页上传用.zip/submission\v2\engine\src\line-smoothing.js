/**
 * v2 engine · 输入平滑（LineSmoothing）
 *
 * MIT 许可，移植/改写自 Klecks：
 *   https://github.com/bitbof/klecks
 *   spike/klecks/vendor/klecks/src/app/script/klecks/events/line-smoothing.ts
 *   Copyright (c) 2026 bitbof (bitbof.com) — MIT License
 *
 * 算法（Klecks 原实现）：
 *  - move 时将新输入与上一次平滑位置按 smoothing 系数混合（mix）；
 *  - 停止输入约 catchUpDelayMs 后，以 catchUpIntervalMs 周期继续把“平滑位置”向真实输入“追赶”，
 *    避免大 smoothing 下笔迹落后于指针。
 *
 * 本移植为纯 JS、无 DOM 依赖；由 input.js 在指针事件链中调用。
 * 许可义务：保留本版权头与 MIT 声明；分发时随包附 MIT 文本（见 v2/engine/vendor/THIRD_PARTY_NOTICES.md）。
 */

const clamp01 = (v) => Math.max(0, Math.min(1, v));
const mix = (a, b, t) => a + (b - a) * t;

export class LineSmoothing {
  /**
   * @param {{smoothing?:number, catchUpDelayMs?:number, catchUpIntervalMs?:number}} [opts]
   */
  constructor(opts = {}) {
    this.smoothing = clamp01(Number(opts.smoothing) || 0);
    this.catchUpDelayMs = opts.catchUpDelayMs == null ? 80 : Math.max(0, Number(opts.catchUpDelayMs));
    this.catchUpIntervalMs = opts.catchUpIntervalMs == null ? 35 : Math.max(1, Number(opts.catchUpIntervalMs));
    /** @type {{x:number,y:number,pressure:number}|null} */
    this._lastMixed = null;
    /** @type {{x:number,y:number,pressure:number}|null} */
    this._input = null;
    this._delayTimer = null;
    this._intervalTimer = null;
    /** @type {((p:{x:number,y:number,pressure:number}) => void)|null} */
    this._onCatchUp = null;
  }

  /** 订阅“追赶”回调（由 input.js 接入 engine.appendPoint） */
  onCatchUp(cb) { this._onCatchUp = cb; return this; }

  /** 笔触开始：记录起点；返回原 point（起点不做平滑） */
  begin(p) {
    this.stop();
    this._lastMixed = { x: p.x, y: p.y, pressure: p.pressure == null ? 0.5 : p.pressure };
    return p;
  }

  /** 处理一个 move 点：返回平滑后的 point；同时安排“追赶”定时器 */
  push(p) {
    if (!this._lastMixed) this._lastMixed = { x: p.x, y: p.y, pressure: p.pressure == null ? 0.5 : p.pressure };
    const s = this.smoothing;
    if (s <= 0) {
      this._lastMixed = { x: p.x, y: p.y, pressure: p.pressure == null ? 0.5 : p.pressure };
      return p;
    }
    const pressure = p.pressure == null ? 0.5 : p.pressure;
    const mixed = {
      x: mix(p.x, this._lastMixed.x, s),
      y: mix(p.y, this._lastMixed.y, s),
      pressure: mix(pressure, this._lastMixed.pressure, s),
    };
    this._lastMixed = mixed;
    this._input = { x: p.x, y: p.y, pressure };
    const out = Object.assign({}, p, { x: mixed.x, y: mixed.y, pressure: mixed.pressure });
    this._schedule();
    return out;
  }

  /** 停止（抬笔/取消）：清定时器与状态，不再产生追赶点 */
  stop() {
    if (this._delayTimer) { clearTimeout(this._delayTimer); this._delayTimer = null; }
    if (this._intervalTimer) { clearInterval(this._intervalTimer); this._intervalTimer = null; }
    this._input = null;
  }

  /** 立即把当前平滑位置再向真实输入推进一步（测试/工具用） */
  step() {
    if (!this._input || !this._lastMixed) return null;
    const s = this.smoothing;
    const out = {
      x: mix(s > 0 ? this._input.x : this._lastMixed.x, this._lastMixed.x, s),
      y: mix(s > 0 ? this._input.y : this._lastMixed.y, this._lastMixed.y, s),
      pressure: mix(s > 0 ? this._input.pressure : this._lastMixed.pressure, this._lastMixed.pressure, s),
    };
    this._lastMixed = out;
    return out;
  }

  _schedule() {
    if (this._delayTimer) { clearTimeout(this._delayTimer); this._delayTimer = null; }
    if (this._intervalTimer) { clearInterval(this._intervalTimer); this._intervalTimer = null; }
    if (this.smoothing <= 0 || !this._input) return;
    this._delayTimer = setTimeout(() => {
      this._delayTimer = null;
      this._intervalTimer = setInterval(() => {
        if (!this._input || !this._lastMixed || !this._onCatchUp) return;
        const s = this.smoothing;
        const next = {
          x: mix(this._input.x, this._lastMixed.x, s),
          y: mix(this._input.y, this._lastMixed.y, s),
          pressure: mix(this._input.pressure, this._lastMixed.pressure, s),
        };
        this._lastMixed = next;
        this._onCatchUp(next);
        // 足够接近真实输入时停止追赶（避免无限定时器）
        const dx = this._input.x - next.x;
        const dy = this._input.y - next.y;
        if (Math.hypot(dx, dy) < 0.5) {
          if (this._intervalTimer) { clearInterval(this._intervalTimer); this._intervalTimer = null; }
        }
      }, this.catchUpIntervalMs);
    }, this.catchUpDelayMs);
  }
}
