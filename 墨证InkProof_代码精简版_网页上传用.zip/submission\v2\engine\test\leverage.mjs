#!/usr/bin/env node
// v2/engine/test/leverage.mjs —— T49 开源复用落地回归（零依赖 CDP）
// 验证：Klecks 风格 present（保留帧 + 整帧 blit）性能/模式；tile undo 增强（pause/replaceTop/listeners）；
//       LineSmoothing（MIT 移植）平滑与追赶。
// 用法：node v2/engine/test/leverage.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

async function evaluate(expression, awaitPromise = true) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise, returnByValue: true, timeout: 120000 });
  if (r.result && r.result.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1000));
  return r.result && r.result.result && r.result.result.value;
}

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const eng = window.__V2__;
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const checks = {};
  const median = (a) => { const s = [...a].sort((x, y) => x - y); return s.length ? Math.round(s[Math.floor(s.length / 2)] * 100) / 100 : null; };

  // ---- 1) present：保留帧 + 整帧 blit（Klecks GpuCompositeCanvas.present / renderCanvas 思路） ----
  eng.beginStroke({ x: 300, y: 400, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
  for (let i = 1; i < 30; i += 1) eng.appendPoint({ x: 300 + i * 13, y: 400, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
  eng.endStroke();
  await raf(); await raf();
  const fullTimes = [];
  for (let i = 0; i < 5; i += 1) { const s = performance.now(); eng.presentFull(); fullTimes.push(performance.now() - s); }
  const blitTimes = [];
  for (let i = 0; i < 5; i += 1) { const s = performance.now(); eng._blitRetained(); blitTimes.push(performance.now() - s); }
  const stats = eng.getStats();
  const afterPresent = await eng.getCompositeDataUrl();
  const img = new Image(); img.src = afterPresent; await img.decode();
  const cv = document.createElement('canvas'); cv.width = img.width; cv.height = img.height;
  const cx = cv.getContext('2d'); cx.drawImage(img, 0, 0);
  const data = cx.getImageData(0, 0, cv.width, cv.height).data;
  let ink = 0; for (let i = 0; i < data.length; i += 4) if (data[i] < 220 || data[i + 1] < 220 || data[i + 2] < 220) ink += 1;
  checks.presentRetainedSurface = !!eng.presentSurface && stats.presentSurfaceMB > 0;
  checks.presentFullFrameInk = ink > 0;
  checks.presentFullMedianMs = median(fullTimes);
  checks.presentBlitMedianMs = median(blitTimes);
  checks.presentModesWork = stats.lastPresentMode === 'full' || stats.lastPresentMode === 'blit' || stats.lastPresentMode === 'burst';
  const perf = { presentFullMedianMs: checks.presentFullMedianMs, presentBlitMedianMs: checks.presentBlitMedianMs, presentSurfaceMB: stats.presentSurfaceMB, memoryEstimateMB: stats.memoryEstimateMB };

  // ---- 2) undo：Klecks KlHistory 风格能力（pause / replaceTop / listeners / validate） ----
  const { UndoManager } = await import('/v2/engine/src/undo.js');
  const fakeStore = {};
  const um = new UndoManager(fakeStore, 4, 64 * 1024 * 1024);
  let listenerCalls = 0;
  const off = um.addListener(() => { listenerCalls += 1; });
  const mkEntry = (layerId, key) => ({ layerId, patches: [{ key, before: {}, after: {} }] });
  checks.undoValidateRejectsBad = um.validate({ patches: [] }) === false && um.validate(mkEntry('layer-1', '1,1')) === true;
  um.push(mkEntry('layer-1', '1,1'));
  checks.undoPushListener = listenerCalls > 0 && um.canUndo() === true;
  um.pause();
  const pausedPush = um.push(mkEntry('layer-1', '2,1'));
  checks.undoPauseSuppressesPush = pausedPush === false && um.depth() === 1;
  um.resume();
  um.push(mkEntry('layer-1', '2,1'));
  const beforeReplace = um.depth();
  um.replaceTop(mkEntry('layer-1', '3,1'));
  checks.undoReplaceTop = um.depth() === beforeReplace && um.undoStack[um.depth() - 1].patches[0].key === '3,1';
  const popped = um.popUndo();
  checks.undoPopAndRedo = !!popped && um.canRedo() && !!um.popRedo() && um.memoryEstimate() > 0;
  off();
  checks.undoListenerOff = typeof off === 'function';
  checks.undoEngineWrappers = typeof eng.pauseHistory === 'function' && typeof eng.resumeHistory === 'function' && typeof eng.replaceTopHistory === 'function';

  // ---- 3) LineSmoothing（MIT 移植）：平滑降低抖动 + 追赶回调 ----
  const { LineSmoothing } = await import('/v2/engine/src/line-smoothing.js');
  const raw = [];
  for (let i = 0; i < 12; i += 1) raw.push({ x: 100 + i * 10, y: 200 + (i % 2 === 0 ? 18 : -18), pressure: 0.5, timestamp: i });
  const plain = new LineSmoothing({ smoothing: 0 });
  plain.begin(raw[0]);
  const plainOut = raw.slice(1).map((p) => plain.push(p));
  const rawDev = Math.max(...raw.slice(1).map((p) => Math.abs(p.y - 200)));
  const plainDev = Math.max(...plainOut.map((p) => Math.abs(p.y - 200)));
  checks.smoothingPassthrough = rawDev === plainDev;

  const sm = new LineSmoothing({ smoothing: 0.7, catchUpDelayMs: 40, catchUpIntervalMs: 20 });
  sm.begin(raw[0]);
  let catchUps = 0;
  sm.onCatchUp(() => { catchUps += 1; });
  const smoothOut = raw.slice(1).map((p) => sm.push(p));
  const smoothDev = Math.max(...smoothOut.map((p) => Math.abs(p.y - 200)));
  checks.smoothingReducesJitter = smoothDev < rawDev;
  await new Promise((r) => setTimeout(r, 160));
  sm.stop();
  const catchUpsAtStop = catchUps;
  await new Promise((r) => setTimeout(r, 80));
  checks.smoothingCatchUp = catchUpsAtStop > 0 && catchUps === catchUpsAtStop;
  checks.engineSmoothingApi = eng.setInputSmoothing(0.5) === 0.5 && eng.getInputSmoothing() === 0.5;
  eng.setInputSmoothing(0);

  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  return { ok: checks.ok, checks, perf, environment: { browser: (navigator.userAgent.match(/Chrome\\/[\\d.]+/) || [])[0] || '', headless: /HeadlessChrome/.test(navigator.userAgent) } };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1200)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
