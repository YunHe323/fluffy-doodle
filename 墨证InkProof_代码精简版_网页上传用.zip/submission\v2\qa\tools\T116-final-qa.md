# T116 最终独立 QA：结构化文字层 + 原子 undo

> 执行：qa-engineer（独立 QA｜task-130）｜日期：2026-11-07 22:5x｜只写 `v2/qa/tools/`；**未改 app**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、小批次（日志 `archive/baseline-t116-final/logs/`）；测试用独立 python 服务（Lead 的 4200 当前已停止，不影响本轮）。

## 结论

**可交付（Deliverable）——P0/P1/P2 = 0。**
新/更新测试 `test-text-edit`、`test-adjust-layer`、`test-editor-ui` 等 9 项全 PASS、0 console error；**12 项独立焦点核验全 PASS**；QA 首轮发现的 **P1（键盘 undo/redo 不同步 textLayers）与 P2（replaceLayerFromDataUrl 委托 null info TypeError）已由 Lead 修复，并独立复核通过**；旧档 fallback、新写入无 meta.text、调整层原子 undo、保存/加载/再编辑、badge、L6 schema、密钥均确认；证据 mtime 未变、无付费调用、残留 0。

## 1. 新/更新测试（修复后复跑，全部 PASS）

| 测试 | 结果 | 关键证据 |
|---|---|---|
| `test-text-edit.mjs` | **PASS** | `create.kind=text`；双击预填「初始文字」/56；编辑→「修改后的文字\n第二行」kind=text；**Ctrl+Z 后 `stateText=engineText=初始文字`、Ctrl+Y 后两者=修改后的文字**；persist/再编辑预填正确 |
| `test-adjust-layer.mjs` | **PASS** | 创建 adjust 层；update 0.35；**undo→0.22、redo→0.35**（参数+像素同步）；serialize/load 保留 adjust 0.35 |
| 回归 7 项 | **PASS** | test-editor-ui、test-app、test-ui、test-canvas-resize、test-library、test-chat-actions、test-ai-provider（0 error） |

## 2. 独立焦点核验（12/12 PASS）

| # | 检查 | 结果 |
|---|---|---|
| 1 | **结构化文字层** | 新建层 `kind='text'`、`layer.text{content:'初始文字',fontSize:56,color,fontFamily,x,y,width,height}`、textLayers=1、JSON 含 `"kind":"text"`+内容 ✅ |
| 2 | **文字 badge** | 图层面板文本含「文字」✅ |
| 3 | **新写入不再产生 meta.text** | 新文档 JSON 中 `"meta":{…"text"…}` = **false** ✅ |
| 4 | **双击预填** | 预填「初始文字」、字号 56 ✅ |
| 5 | **编辑后像素与 text 一致** | layer.text.content=「修改后的文字\n第二行」、state.textLayers 同步、合成像素 diff=**14,649**（确实变化）✅ |
| 6 | **原子 undo / redo（键盘 Ctrl+Z/Ctrl+Y）** | undo：engine.text=「初始文字」、`state.textLayers`=「初始文字」、像素 diff=**0**；redo：两者=「修改后的文字」、像素 diff=**0** ✅ |
| 7 | **保存/加载/再编辑** | serialize→loadProjectText 后 kind=text、textLayers=1、内容保留、双击预填正确、JSON 含 kind/text ✅ |
| 8 | **旧档 fallback（仅 meta.text）** | 构造旧档（删 kind/text、写入 meta.text=「旧档文字」）→ 加载后 textLayers=1、内容/预填均为「旧档文字」✅ |
| 9 | **调整层 update 原子 undo/redo** | brightness 0.22→0.35；undo→**0.22 + 像素 diff=2,407**；redo→0.35 ✅（create 路径不受影响） |
| 10 | **replaceLayerFromDataUrl 委托无回归** | 独立干净页复核：`ok=true`、steps **1→2**、kind 保持 `raster`、像素 URL 变化、**0 抛错/0 console error** ✅（全流程探针中曾因跨用例历史读数出现 steps 异常，已用独立干净页排除） |
| 11 | **L6 schema** | text_inserted/text_edited/adjust_layer 记录共 4 条，`validateArchiveRecord` **bad=0**、全部 records bad=0 ✅ |
| 12 | **密钥 / console** | DOM/LS/SS/已加载 JS 无 key；全程 **0 console error** ✅ |

### 2.1 Lead 修复复核

| 问题 | 修复 | QA 复核 |
|---|---|---|
| **P1** 键盘 Ctrl+Z/Ctrl+Y 未 sync textLayers | app.js Ctrl+Z/Y 分支增加 `syncTextLayersFromEngine()`；test-text-edit 新增断言（L58-73） | 键盘 undo：`stateText=engineText=初始文字`；redo：两者=修改后；像素 diff=0 ✅ |
| **P2** `replaceLayerFromDataUrl` 委托 null info → TypeError | `replaceLayerFromDataUrlWithInfo` 入口 `info = info && typeof info==='object' ? info : {}`（engine.js:1853） | 独立干净页：委托调用 ok=true、steps 1→2、kind=raster、无抛错 ✅ |

## 3. 真实证据 / 费用（无新增付费调用）

| 证据 | 核对 |
|---|---|
| `asset-real-read-results.json`（mtime 17:12 未变） | pass=true；22,955ms；real / L2=5 / L4=4 |
| `qwen-real-e2e-results.json`（mtime 16:53 未变） | pass=true；21,337ms；obs=2、regions=2、mock=false |
| 本轮真实请求 | **0**（纯本地 UI/引擎操作） |

## 4. 密钥 / 残留 / 服务

- 密钥：无 DOM/LS/SS/已加载 JS 泄漏；未打印 key。
- 残留：**Edge 0、测试端口 0**。
- 服务：本轮全部测试使用独立 python http.server；Lead 的 4200 当前已停止（`.runtime-port` 残留 4200，不影响本轮与 QA 结论；下轮启动时会重写）。

## 5. 问题清单

| # | 级别 | 内容 | 状态 |
|---|---|---|---|
| 1 | ~~P1~~ | 键盘 undo/redo 未同步 textLayers | **已修复并复核** ✅ |
| 2 | ~~P2~~ | replaceLayerFromDataUrl 委托 null info TypeError | **已修复并复核** ✅ |
| — | — | P0 / P1 / P2 | **均无** |
| 说明 | — | Brooks R1「调整服务抽取」列为下一轮 | 不阻塞本轮（Lead 已记录） |

## 6. 产物与归档

- `v2/qa/tools/T116-final-qa.md`（本报告）
- `v2/qa/tools/archive/baseline-t116-final/`：`logs/`（9 项测试 + 修复后复跑日志）、各 result JSON、`focus-results.json`（12 项焦点核验）、真实证据 JSON、README
- GATE：`v2/qa/tools/GATE-pw.md`「T116 最终独立 QA」行
