# product/CONTRACT.md · app ↔ server 接口契约（v0.1.1）

> 作者：tech-architect（T18）｜日期：2026-11-06｜状态：**生效，前端可按此开发**
> 适用：`product/app/`（T17 前端）↔ `product/server/server.mjs`（本地服务）
> 原则：**本地优先、零依赖、mock 优先**。没有 API Key / 断网时，全部能力可用（mock）。
> 变更规则：本文件由 tech 维护；**任何破坏性变更必须先改本文件并通知前端**；只增字段不算破坏性变更（前端应忽略未知字段）。

---

## 0. 运行方式与基址

```bash
node server/server.mjs          # 或 npm start
# 输出示例：ProjectOne local server → http://127.0.0.1:4173
```

- 只监听 **127.0.0.1**（不对外网开放），默认端口 **4173**；被占用时自动 `+1`（4174、4175 … 最多 +10）。
- **前端一律使用同源相对路径调用**：`fetch('/api/health')`。不要硬编码端口（换端口后同源仍然成立）。
- 静态资源挂载：
  | 路径 | 来源 | 说明 |
  |---|---|---|
  | `/` `/css/*` `/js/*` `/assets/*` | `product/app/` | 前端产物；`GET /` → `app/index.html` |
  | `/core/*` | `product/core/` | **只读**共享纯逻辑（ESM）：`hash-chain.mjs`、`archive-schema.mjs`、`mock-ai.mjs` |
  | `/api/*` | `server.mjs` | 见下 |
- SPA 回退：无扩展名的 GET（如 `/canvas`）且文件不存在 → 返回 `app/index.html`。
- 缓存：API 响应 `Cache-Control: no-store`；静态资源开发期 `max-age=0`（避免改完刷不出来）。

### 0.1 CORS（仅本地开发用）

服务默认同源，无需 CORS。为方便前端用别的方式起 dev server，服务对**本机来源**放行：

- 允许 `Origin` 匹配 `http://127.0.0.1:<任意端口>` 或 `http://localhost:<任意端口>`；
- 其它 Origin 一律不返回 CORS 头（浏览器会拦截）。
- `OPTIONS /api/*` → `204`（预检）。
- 允许请求头：`Content-Type`；暴露响应头：`X-Request-Id`。

### 0.2 通用约定

- 编码：UTF-8，`Content-Type: application/json; charset=utf-8`。
- 每个响应带 `X-Request-Id`（也可从响应体 `requestId` 读取），用于排查。
- 请求体上限 **8 MB**（画布 dataURL 建议先缩到长边 ≤1536 再上传；mock 不解析像素）。
- 只接受 `Content-Type: application/json` 的 POST/PUT（否则 `415`）。
- 服务端**不把任何画布/请求体写入磁盘、不记录图像内容**（隐私约定，见 §6）。

### 0.3 开源性约束（用户已确认，成品将开源）

1. **无遥测、无静默网络请求**：服务启动与运行期间**不向任何外部域名发请求**（无统计上报、无更新检查、无 CDN 探测）；mock 模式**完全离线可用**。真实 provider 为预留位，v0.1 不实现网络调用。
2. **密钥与配置**：`config/provider.example.json` 示例留空；真实配置写 `config/provider.json`（**已加入 `.gitignore`**，由用户自行创建/维护）；代码中不硬编码任何 key；`apiKey` 不落日志、不回传前端。
3. **依赖与许可**：`package.json` **零第三方运行时依赖**；测试仅用 Node 内置 `node:test` / `node:assert`。若未来引入测试/工具依赖，必须在 README 注明其许可证。

---

## 1. 统一响应格式

### 1.1 成功

```json
{ "ok": true, "requestId": "r_9f2c4e1a", "mode": "mock", "model": "mock-ai@0.1.0",
  "latencyMs": 0, "serverTime": "2026-11-06T20:10:00.000Z", "result": { } }
```

- `ok`：恒为 `true`。
- `mode`：`"mock"`（默认）| `"provider"`（未来真实 AI，当前未实现）。
- `model`：本次实际使用的模型标识（mock 为 `mock-ai@0.1.0`）。
- `latencyMs`：服务端处理耗时（mock 下通常 0–5ms；**不要**用它做性能承诺）。
- `result`：各接口自己的载荷（见 §2）。
- **`GET /api/health` 例外**：成功体是扁平的（见 §2.1），没有 `result` 包裹。

### 1.2 失败（统一错误格式）

```json
{ "ok": false, "requestId": "r_9f2c4e1a", "code": "BAD_REQUEST",
  "message": "canvas.dataUrl 不是合法图片 dataURL", "detail": [ { "path": "canvas.dataUrl", "error": "invalid_data_url" } ] }
```

| HTTP | `code` | 触发 |
|---|---|---|
| 400 | `BAD_REQUEST` | 参数校验失败（字段缺失/类型错/越界/JSON 非法） |
| 400 | `CONFIG_INVALID` | `PUT /api/config` 配置值非法 |
| 404 | `NOT_FOUND` | 未知 API 路由 / 静态文件不存在且非 SPA 回退 |
| 405 | `METHOD_NOT_ALLOWED` | 路径存在但方法不对（响应头带 `Allow`） |
| 413 | `PAYLOAD_TOO_LARGE` | 请求体 > 8MB |
| 415 | `UNSUPPORTED_MEDIA_TYPE` | POST/PUT 不是 `application/json` |
| 500 | `INTERNAL` | 未捕获异常（message 脱敏，不回堆栈） |
| 501 | `NOT_IMPLEMENTED` | 已切到 `provider` 模式但真实网络调用未实现（预留） |

> 前端处理建议：`if (!resp.ok || json.ok === false) → 显示 json.message；` 网络失败（fetch reject）单独提示"本地服务未启动"。

---

## 2. 接口

### 2.1 `GET /api/health` — 健康检查

**请求**：无。

**成功 200（扁平）**

```json
{
  "ok": true,
  "version": "0.1.0",
  "mode": "mock",
  "provider": "mock",
  "network": "none",
  "telemetry": false,
  "core": { "archiveSchema": "0.2.0", "hashChain": "0.1.0", "mockAi": "0.1.0" },
  "serverTime": "2026-11-06T20:10:00.000Z",
  "uptimeSec": 12
}
```

- 前端启动时先打一次；失败 → 显示"本地服务未启动，请双击 start.bat"。
- `mode` 只有 `"mock"` / `"provider"` 两种；`provider` 目前会返回 `501`（除 health/config 外），见 §5。

---

### 2.2 `POST /api/ai/analyze` — 画布选区理解（档案反解，mock）

输入"当前画布快照 + 选区"，返回观察与区域（对应架构的 **L1/L2/L4** 结构）。

**请求**

```json
{
  "canvas": {
    "dataUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUg...",
    "width": 1280, "height": 800,
    "layerCount": 3,
    "activeLayerId": "layer_2"
  },
  "selection": { "mode": "rect", "rect": { "x": 420, "y": 180, "width": 260, "height": 220 } },
  "context": {
    "mode": "collab",
    "aiRole": "assistant",
    "userNote": "袖口这里有点闷",
    "archiveSummary": { "palette": ["#2e3a48", "#c9a66b"], "mood": ["安静"] }
  }
}
```

| 字段 | 必填 | 规则 |
|---|---|---|
| `canvas.dataUrl` | ✅ | `^data:image/(png\|jpeg\|webp\|svg\+xml);base64,` 且总长 ≤ 8MB |
| `canvas.width/height` | ✅ | 数字 1–8192（建议整数；服务端四舍五入） |
| `canvas.layerCount` | — | 整数 0–200 |
| `selection` | — | 缺省 = 全画布。`mode:"rect"` + `rect{x,y,width,height}`（数字，服务端取整，须在画布内）；或 `mode:"mask"` + `maskDataUrl`（同上格式） |
| `context.mode` | — | `"collab"` \| `"attest"`，默认 `collab` |
| `context.aiRole` | — | `"tool"` \| `"assistant"` \| `"collaborator"`，默认 `assistant` |
| `context.userNote` | — | 字符串 ≤ 500 字 |
| `context.archiveSummary` | — | 任意 JSON（mock 只用于混淆种子，不校验内部结构） |

**成功 200**

```json
{
  "ok": true, "requestId": "r_9f2c4e1a", "mode": "mock", "model": "mock-ai@0.1.0", "latencyMs": 2,
  "serverTime": "2026-11-06T20:10:00.000Z",
  "result": {
    "global": {
      "summary": "画布以冷灰蓝为主调的未完成人物速写",
      "subject": ["人物", "衣物褶皱"],
      "medium": { "kind": "digital_painting", "detail": "厚涂，局部保留草稿线" },
      "palette": [{ "hex": "#2e3a48", "weight": 0.42 }, { "hex": "#c9a66b", "weight": 0.18 }],
      "mood": ["安静", "克制"]
    },
    "regions": [
      { "id": "L2-mock-001", "label": "袖口褶皱", "confidence": 0.78,
        "bbox": [430, 190, 180, 160], "importance": 0.8,
        "anchor": { "type": "bbox", "value": [430, 190, 180, 160] } }
    ],
    "observations": [
      { "id": "L4-mock-001", "layer": "L4", "kind": "observation", "source": "inferred",
        "author": "ai", "confidence": 0.62, "text": "袖口边缘那笔没收干净，反而像是有意的呼吸感。",
        "anchor": { "type": "bbox", "value": [430, 190, 180, 160] },
        "evidenceRefs": ["L2-mock-001"], "modelVersion": "mock-ai@0.1.0" }
    ],
    "confidence": 0.71
  }
}
```

- `observations`：**2–4 条**；每条 `layer` 固定 `"L4"`、`source` 固定 `"inferred"`、`author` 固定 `"ai"`、必须带 `evidenceRefs`（非空）。
- `regions`：**1–3 个**；`id` 以 `L2-` 开头；`anchor.type` 为 `bbox`。
- `result.seed`：mock 确定性种子（调试/断言用；前端可忽略）。
- 所有 `anchor.value` 均为 `[x, y, w, h]`（画布像素坐标，整数）。
- mock **确定性**：相同输入（请求体规范化后）→ 相同输出（含 id 与文案顺序）。

---

### 2.3 `POST /api/ai/directions` — 给出 2–3 个方向候选

**请求**：与 `analyze` 相同，另加：

| 字段 | 必填 | 规则 |
|---|---|---|
| `observationIds` | — | 字符串数组（≤10，引用上一次 analyze 的 observation id） |
| `count` | — | 整数 2–3，默认 2 |

**成功 200**

```json
{
  "ok": true, "requestId": "r_5c1d9e2b", "mode": "mock", "model": "mock-ai@0.1.0", "latencyMs": 1,
  "serverTime": "2026-11-06T20:10:01.000Z",
  "result": {
    "directions": [
      { "id": "dir-mock-01", "title": "让光更冷一点", "why": "当前暗部偏暖，与冷调环境冲突（依据 L1.palette）",
        "confidence": 0.66, "tags": ["light", "palette"] },
      { "id": "dir-mock-02", "title": "保留粗糙笔触，只补结构", "why": "L4 观察提到边缘笔触是有意保留的",
        "confidence": 0.61, "tags": ["texture", "structure"] }
    ]
  }
}
```

- `directions` 长度 = 请求的 `count`（2–3），字段均必填；`id` 以 `dir-` 开头。
- 用户否决方向后，前端把 `directionId` 与原因记入本地 L5；下一轮可把"排除项"放进 `context.userNote`（v0.1 不做结构化负约束）。

---

### 2.4 `POST /api/ai/generate` — 模拟生成候选（可合成到画布）

**请求**：与 `directions` 相同，另加：

| 字段 | 必填 | 规则 |
|---|---|---|
| `directionId` | ✅ | 来自 directions 的 id |
| `count` | — | 整数 1–3，默认 2 |
| `size` | — | `{width,height}`，默认取选区尺寸（夹在 256–2048） |

**成功 200**

```json
{
  "ok": true, "requestId": "r_7a3b0c4d", "mode": "mock", "model": "mock-ai@0.1.0", "latencyMs": 3,
  "serverTime": "2026-11-06T20:10:02.000Z",
  "result": {
    "candidates": [
      { "id": "cand-mock-01", "label": "冷调方案 A",
        "why": "按「让光更冷一点」调整了选区内的明度分布",
        "imageDataUrl": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0i...",
        "width": 260, "height": 220 },
      { "id": "cand-mock-02", "label": "冷调方案 B",
        "why": "保留笔触纹理的变体",
        "imageDataUrl": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0i...",
        "width": 260, "height": 220 }
    ],
    "credits": 0
  }
}
```

- mock 候选是**确定性 SVG 占位图**（`data:image/svg+xml;base64,...`），尺寸 = 请求的 size；前端用 `<img>` / `drawImage` 合成即可，不需要解码像素。
- `credits`：mock 恒为 `0`（本地版不计费）。真实 provider 接入后按 `06-技术/技术架构.md` §8.3 的展示积分口径返回。
- 前端**不得**把候选直接写入用户图层：必须经用户"应用"动作落为新图层（对齐 D1）。

---

### 2.5 `GET /api/config` / `PUT /api/config` — Provider 配置

**GET 200**

```json
{
  "ok": true, "requestId": "r_a1b2c3d4",
  "config": {
    "provider": "mock",
    "baseUrl": "",
    "model": "",
    "apiKeySet": false,
    "updatedAt": "2026-11-06T20:00:00.000Z",
    "source": "default"
  }
}
```

> `source`：`default`（内置默认）| `file`（启动时读自 `config/provider.json`）| `memory`（本次进程内 PUT 修改）。
> `updatedAt` 为最近一次配置加载/修改时间（ISO 8601）。

**PUT 请求**（部分更新，未传字段保持不变）

```json
{ "provider": "openai-compatible", "baseUrl": "https://api.example.com/v1", "model": "example-image-model", "apiKey": "sk-..." }
```

| 字段 | 规则 |
|---|---|
| `provider` | `"mock"` \| `"openai-compatible"`（预留） |
| `baseUrl` | http(s) URL，≤ 500 字符；`provider=mock` 时忽略 |
| `model` | 字符串 ≤ 120 字符 |
| `apiKey` | 字符串 ≤ 500 字符；**只进不出**：GET 永不返回明文，只返回 `apiKeySet:boolean` |
| 其它字段 | 忽略（不报错） |

**PUT 成功 200**：同 GET 形状（含 `apiKeySet:true`）。

- 配置**只在内存中生效**（进程退出即失效）；`PUT /api/config` **不写盘**。API Key **不写代码、不记日志、不回传**。
- 启动时（若存在）读取 `config/provider.json`（**已 gitignore**，由用户创建）；`PUT` 的修改优先于文件，直到进程重启。
- `config/provider.example.json` 提供示例（`apiKey` 留空），供用户复制为 `config/provider.json`；**不要**把真实 key 提交进仓库。
- `provider` 切到非 mock 后：本文接口返回 `501 NOT_IMPLEMENTED`，直到真实 provider 实现（预留位在 `server/ai-proxy.mjs`；**v0.1 不发起任何网络请求**）。

---

## 3. 前端可依赖的共享模块（`/core/*`）

前端可通过静态挂载直接 import 纯逻辑（浏览器 ESM）：

```js
import { createEvent, verifyChain, checkpointHash } from '/core/hash-chain.mjs';
import { validateArchiveRecord, SCHEMA_VERSION } from '/core/archive-schema.mjs';
import { mockAnalyze, mockDirections, mockGenerate } from '/core/mock-ai.mjs';
```

| 模块 | 导出（约定） | 用途 |
|---|---|---|
| `hash-chain.mjs` | `sha256Hex(text)`, `canonicalJson(obj)`, `createEvent(prev, event)`, `verifyChain(events)`, `checkpointHash(events)` | 证据链（本地 IndexedDB 事件） |
| `archive-schema.mjs` | `SCHEMA_VERSION="0.2.0"`, `validateArchiveRecord(record)`, `validateMany(records)`, `SOURCES`, `MODES`, `AI_ROLES` | 档案记录校验（对齐 `06-技术/数据模型_schema.json` v0.2.0） |
| `mock-ai.mjs` | `mockAnalyze(input)`, `mockDirections(input)`, `mockGenerate(input)`, `MOCK_MODEL` | 与服务端同一套 mock（同一输入同一输出） |

> 服务端 `/api/ai/*` 的 mock 与 `/core/mock-ai.mjs` **必须一致**：前端离线降级时可直接本地调用，不必依赖服务。
> `hash-chain.mjs` 使用 WebCrypto（`crypto.subtle`），接口为**异步**（需 `await`）；Node 22+ 与现代浏览器行为一致。
> `archive-schema.mjs` 为同步纯函数；`validateArchiveRecord(record)` 返回 `{ok, errors[]}`，`assertArchiveRecord` 不合法时抛 `ArchiveSchemaError`。

---

## 4. 与 `06-技术/技术架构.md` v0.2 的对应关系

| 架构概念 | 本契约落点 |
|---|---|
| 反解管线（L1/L2/L4） | `POST /api/ai/analyze` 的 `result.global`（L1 子集）/`regions`（L2）/`observations`（L4） |
| 方向候选（2–4 个） | `POST /api/ai/directions` 的 `directions` |
| 局部生成候选 | `POST /api/ai/generate` 的 `candidates`（mock 占位图） |
| `mode` / `ai_role` 留痕 | 请求 `context.mode` / `context.aiRole`；响应回显在 `meta`（`mode` 字段） |
| 积分（展示积分） | 本地 mock 恒 0；真实 provider 预留 `result.credits` |
| 存证模式零生成 | 本地版由前端状态机保证（不调用 generate）；服务端不额外拦截（无真实生成） |
| 证据链 | 前端用 `/core/hash-chain.mjs` 在本地（IndexedDB）计算；**服务端不存用户画布与证据** |

**与架构文档的差异（v0.1 有意简化）**：
1. 服务端无数据库：档案与事件全部在前端 IndexedDB，服务端无状态。
2. 不做真实 provider：`ai-proxy.mjs` 仅留接口与 TODO。
3. 不做配额/账号/审核：本地单人使用，`credits` 仅占位。
4. 不做 PSD：只处理位图 dataURL。
5. 反解只返回 L1 子集 + L2 + L4，不含 L3/L5/L6（L5/L6 由前端动作产生）。

---

## 5. 模式与降级

| 场景 | 行为 |
|---|---|
| 默认（无配置） | `mode:"mock"`，所有 `/api/ai/*` 正常返回，零网络请求 |
| `PUT /api/config` 切 `openai-compatible` | `/api/*` 除 health/config 外 → `501 NOT_IMPLEMENTED`；前端提示"真实 AI 未接入，已回退 mock"并可 PUT 回 `mock` |
| 服务未启动 | 前端 fetch reject；提示双击 `start.bat`；**画布与档案功能应仍可用**（前端核心不依赖服务） |
| 端口冲突 | 服务自动 +1；前端同源不受影响；启动脚本打印实际地址 |

---

## 6. 安全与隐私约定（实现必须遵守）

1. 只绑定 `127.0.0.1`，不绑定 `0.0.0.0`。
2. 静态文件只允许 `product/app/` 与 `product/core/` 下；**拒绝路径穿越**（`..`、绝对路径、编码绕过、空字节）。
3. 请求体只解析到内存，**不落盘、不写日志**；日志只允许：方法、路径（不含 query 中的敏感值）、状态码、耗时、requestId。
4. `apiKey` 只进不出、不落盘；GET config 只回 `apiKeySet`。
5. 不执行请求体中的任何内容；SVG 候选只在 `<img>`/canvas 中使用，不插入 DOM 作为可执行节点。
6. 不设远程监听、不设反向代理；v0.1 无鉴权（本地单用户），但**端口只对本机暴露**。
7. **无遥测、无静默网络请求**：服务启动与运行期间不向任何外部域名发请求（无统计、无更新检查、无 CDN 探测）；mock 模式完全离线可用。真实 provider 为预留位（`server/ai-proxy.mjs` 只抛 `NotImplemented`）。
8. **密钥与配置**：真实配置写 `product/config/provider.json`（**已 gitignore**）；`config/provider.example.json` 的 `apiKey` 留空；代码不硬编码任何 key。
9. **零第三方运行时依赖**：`package.json` 的 `dependencies` 为空；测试仅用 Node 内置 `node:test` / `node:assert`。若后续引入工具依赖，必须在 README 注明许可证。

---

## 7. 示例：前端最小调用序列

```js
const health = await fetch('/api/health').then(r => r.json());

const analyze = await fetch('/api/ai/analyze', {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    canvas: { dataUrl: compositeDataUrl, width: doc.width, height: doc.height, layerCount: layers.length },
    selection: { mode: 'rect', rect: { x: 420, y: 180, width: 260, height: 220 } },
    context: { mode: app.mode, aiRole: app.aiRole }
  })
}).then(r => r.json());

const dirs = await fetch('/api/ai/directions', { method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ ...analyzeReq, observationIds: analyze.result.observations.map(o => o.id), count: 2 }) }).then(r => r.json());

const gen = await fetch('/api/ai/generate', { method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ ...dirsReq, directionId: dirs.result.directions[0].id, count: 2 }) }).then(r => r.json());
// gen.result.candidates[i].imageDataUrl → 预览 → 用户点"应用"才落层
```

---

## 8. 版本

| 版本 | 日期 | 变更 |
|---|---|---|
| 0.1.0 | 2026-11-06 | 首版：health/analyze/directions/generate/config + 统一错误 + 共享 core 模块挂载 + 安全约定 |
| 0.1.1 | 2026-11-06 | 并入开源约束：无遥测/无静默外联（health 增 `network`/`telemetry`）、`config/provider.json` + gitignore、零第三方运行时依赖；补 hash-chain 异步说明 |
