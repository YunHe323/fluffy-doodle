# product/app · 开发说明（v0.1 内部里程碑 · 已冻结）

> 墨证 InkProof 前端 v0.1：本地优先、零依赖、无构建步骤的 ESM Web 应用。
> 状态：**v0.1 冻结点**（不对外发布；后续 Canvas Engine v2 在 `spike/klecks/` 重新评估画布引擎）。
> 依据：`product/CONTRACT.md` v0.1.0、`00-产品化计划.md`、`05-交互/产品v0.1设计系统.md` §11。

---

## 1. 启动

```bash
cd product
node server/server.mjs          # 默认 127.0.0.1:4173；被占用自动 +1
PORT=4199 node server/server.mjs  # 指定端口（Windows PowerShell：$env:PORT="4199"; node server/server.mjs）
```

浏览器打开服务打印的地址（推荐 Chrome / Edge 最近大版本；已验证 **1366×768** 与 **1920×1080**）。
- `product/app/` 由服务挂载在 `/`；`/core/*` 为共享纯逻辑（hash-chain / archive-schema / mock-ai）。
- 无构建：改 JS/CSS 后直接刷新即可（服务端 `max-age=0`）。
- 无第三方运行时依赖；Offline Mock AI 全程零网络请求（只有一次同源 `GET /api/health` 探测，失败也不影响使用）。

---

## 2. 模块结构

```
app/
├─ index.html          # 单页壳（顶栏 / 工具栏 / 画布 / 图层 / AI 面板 / 弹层 / 演示控制条）
├─ css/
│  ├─ tokens.css       # 设计 token（复制自 05-交互/design-tokens.css，只改颜色/字号引用）
│  └─ app.css          # 组件与布局样式（全部使用 token 变量）
└─ js/
   ├─ main.js          # 启动编排：DB 初始化 → 画布/图层 → 档案 → 证据 → UI → 载入项目 → 演示注册；自动保存
   ├─ state.js         # 全局 state、事件总线、工具函数、动作注册表（解耦模块调用）
   ├─ canvas.js        # 画布引擎：图层树/合成/笔刷/橡皮/框选/移动 AI 层/撤销/覆盖层/序列化
   ├─ layers.js        # 图层面板 UI 与图层操作（增删/显隐/排序/透明度/折叠）
   ├─ archive.js       # 七层档案 L0/L1/L2/L4/L5 + 最小 L6：记录工厂、确认/否决、档案弹层
   ├─ evidence.js      # 事件哈希链（SHA-256）、L6 记录、manifest、证据包导出（JSON+PNG）、零生成声明
   ├─ ai-client.js     # AI 抽象：LocalMockAI（analyzeCanvas / suggestDirections / generateCandidate）+ HttpAIProvider（预留）
   ├─ ui.js            # AI 面板、文件/模式/关于/引导绑定、状态栏、快捷键、动作
   ├─ demo.js          # 一键演示（8 步真实驱动 UI + 聚光/旁白/接管/结束页）
   ├─ db.js            # IndexedDB：projects/layers/archive_records/events/generations/meta；项目 JSON 导入导出
   ├─ example.js       # 内置示例作品（canvas 代码绘制，无外部图片）
   └─ icons.js         # 内联 SVG 图标（Lucide 风格，ISC；本文件为内联子集，无外部依赖）
```

### 数据流（单向、事件驱动）

```
用户操作 → canvas/layers/ui 更新 state → emit('canvas:changed' | 'layers:changed' | 'log' | 'persist:*')
        → main.flushSave（防抖 600–700ms）→ IndexedDB
        → evidence.logEvent（异步队列）→ SHA-256 哈希链事件 → IndexedDB
AI 请求（默认 LocalMockAI，异步）→ 候选只在预览层 → 用户点「保留为新图层」→ 写新图层 + L5 + L6（D1）
```

---

## 3. IndexedDB 数据模型

DB：`inkproof` v1（`state.js` / `db.js`）

| Object store | 内容 | key |
|---|---|---|
| `projects` | 项目元数据：name/mode/aiRole/activeLayerId/layerOrder/strokeCount/selection/modeStartedAt/时间戳 | `id` |
| `layers` | 图层位图（PNG Blob）+ 名称/kind/visible/opacity/offset/bbox/aiMeta/order | `id`（index `projectId`） |
| `archive_records` | 七层档案记录（L0/L1/L2/L4/L5；L6 在 generations） | `key = asset_id:id`（index `projectId`） |
| `events` | 哈希链事件（seq/type/payload/createdAt/actor/mode/aiRole/prev_hash/hash） | `key = projectId:seq` |
| `generations` | L6 派生记录（critique/generation/mode_change/role_change） | `key = projectId:id` |
| `meta` | `lastProjectId`、`onboardingDone` 等 | `key` |

- **刷新不丢**：画布/图层位图、档案、事件链、L6、当前项目 id 均落库；启动时恢复最近项目。
- **项目 JSON 导出/导入**：顶栏「导出 ▾ → 导出项目 JSON / 导入项目 JSON」；导出含项目、图层 dataURL、档案、事件链、L6；导入会覆盖本地数据（有确认）。
- 索引与存储均为浏览器本地；无后端数据库、无云同步。

### 档案记录（对齐 `product/core/archive-schema.mjs` v0.2.0）

`L0`（原件，含 sha256/consent）→ `L1`（全局：subject/scene/medium/palette/mood…）→ `L2`（区域 bbox/label/crop_path/importance）
→ `L4`（观察 text/kind/evidence_refs/锚点）→ `L5`（用户决策 keep / reject_ai / accept_ai / delete；confirm 生成 user-confirmed 新版本）
→ `L6`（critique / generation / mode_change：model{provider,model}、params、input_refs、accepted、cost_cny=0、credits=0、assertions）。
每条记录含 `source`（observed/inferred/user-confirmed）、`confidence`、`anchor`、`model_version`、`created_at`、`schema_version`。
运行期对每条记录调用 core 校验模块（不可用时降级为不校验，并在档案弹层标注）。

### 证据链

- 事件链：`/core/hash-chain.mjs` 的 `createEvent`（SHA-256 + canonicalJson + prev_hash）；本地加载失败时降级为同构本地实现并标注。
- 证据包：`buildEvidencePackage()` → `timeline`（全部链上事件）+ `archive_records` + `generations`（AI 事件不可隐藏）
  + `canvas/layers` 的 SHA-256 与字节数 + `manifest`（hashing/files/chain head/checkpoint/verified）+ `no_generation_attestation`
  + `c2pa_like` 断言草稿 + 固定 README 声明。
- 存证模式：`zero_generation = true`（scope 自进入存证模式起；`ai_events_in_scope` 不含 mode_change 元记录）；
  协作模式：`zero_generation = false`，历史 AI 事件仍完整保留。
- 哈希降级：WebCrypto 不可用时降级 FNV-1a-64 并在 `manifest.hashing` 如实记录（不等价 SHA-256）。

---

## 4. AI 适配层（mock 边界）

```js
// ai-client.js 统一接口
client.analyzeCanvas(input)      // CONTRACT §2.2 形状：{ global, regions, observations, confidence, model }
client.suggestDirections(input)  // CONTRACT §2.3 形状：{ directions: [...] }
client.generateCandidate(input)  // CONTRACT §2.4 形状：{ candidates:[{imageDataUrl,width,height}], credits:0 }
```

- **默认 `MockAI`（本地、离线、确定性增强）**：观察文案为预置模板 + 选区真实采样（平均色/调色板/明暗），
  候选由 **canvas 滤镜 + 色块 + 羽化** 在本机生成 PNG dataURL。不调用任何真实模型、无网络请求。
- `HttpAIProvider` 已按 CONTRACT 实现 `fetch('/api/ai/*')`（含统一错误处理），但**默认不启用**；接真实服务时把
  `createAIClient()` 的返回换成 `HttpAIProvider` 即可，UI/证据字段无需改动。
- 与契约差异（有意）：本地 MockAI 的候选是 canvas 滤镜结果而非服务端 mock 的 SVG 占位图（本地体验更好，
  接口与字段一致；服务端 provider 接入后即为契约实现）。`/core/mock-ai.mjs` 仍可用于服务端/对照测试。
- Mock 边界：界面顶栏常驻「本地 Mock AI · 零网络请求」；AI 面板角标 `MOCK`；演示全程标注「模拟演示 · AI 为 Mock」；
  证据包里 `app.mock_ai: true`、`generations[].model.provider = 'local'`。

---

## 5. 一键演示（Demo Tour，§11）

- 入口：顶栏「演示」（`Shift+D`）、首次引导「看一遍演示」。
- 8 步自动播放：示例项目 → 框选 → 让 AI 看看（观察逐条出现）→ 确认/否决 → 方向/候选/落层 → 证据包 → 存证模式 → 结束卡。
- 每步**页面级聚光 + 旁白卡**；控制条（720×56、距底 44px）：上一步 / 暂停·继续 / 下一步 / `n / 8` / 进度条 / 退出（Esc）。
- 键盘：`←` 上一步、`→` / `Enter` 下一步、`空格` 暂停继续、`Esc` 退出；其它按键或点击界面 = **接管**（toast「已切换为手动操作」）。
- 数据隔离：演示运行在临时 `demo project`，`state.persistencePaused = true` 时不写用户项目/档案/事件链；
  结束卡「自己试试」= 保留示例场景为新项目，「回到我的作品」= 恢复进入前项目。
- `prefers-reduced-motion`：关闭脉冲/逐条动画、演示默认手动步进（按 → 继续），聚光无过渡。

---

## 6. 已实现 / 已知限制（v0.1 冻结）

已实现：画布绘画（硬/软笔、橡皮、颜色、粗细、撤销重做）、图层（增删/显隐/排序/透明度/折叠）、导入图片、加载示例、
框选指认、Mock AI 观察（锚点/置信度/三态/确认否决/撤销）、2 方向、2 模拟方案、画布预览、落为可编辑 AI 图层（拖动/隐藏/删除/撤销）、
档案弹层（L0/L1/L2/L4/L5/L6 分页）、证据包（JSON+PNG+哈希链+manifest+零生成）、存证模式、项目导入导出、关于/首次引导、一键演示。

已知限制（不在 v0.1 范围）：无真实 AI provider（接口预留）、无 PSD、无缩放/旋转视图、无拖拽排序图层、无触屏/移动端、
无 L3 关系层、无自动语义分层、无签名/第三方时间戳；Safari/Firefox 未验证；L6 只在档案弹层展示、未做独立时间线视图。
画布引擎能力（笔刷手感/压感/高性能）不在本版目标内——v2 将基于 `spike/klecks/` 的评估结论重建。

---

## 7. 自测记录（v0.1 冻结点）

使用 headless Chrome + CDP 驱动真实 UI（`http://127.0.0.1:4199/`）：

- 启动：`/api/health` ok（mock）；ESM 全部加载成功；0 console error。
- 画布：3 图层示例渲染；CDP 真实鼠标画一笔 → `strokeCount=1`、undo 可用；**刷新后** projectId/图层/笔触/事件保留。
- AI：4 条观察（含 observed + inferred + 低置信）、2 方向、2 候选、预览、落层（AI 图层 4 层）、确认/否决写入 L4/L5。
- 证据包：`files=5`、`chain.verified=true`、`generations=3`、存证模式 `zero_generation=true`、`ai_events_in_scope=0`、SHA-256 64 hex。
- 演示：8 步自动走完；暂停/上一步/下一步/接管/结束卡正常；演示事件不写入用户项目。
- 分辨率：1366×768 顶栏 48px、无横向滚动、画布自适应、聚光/旁白/控制条不遮挡；1920×1080 正常；均 0 console error。

---

## 8. 素材与许可

- 示例作品：本项目代码绘制（自制素材，无外部图片），随项目以 MIT 发布。
- 图标：Lucide 风格 SVG 路径内联于 `icons.js`；**Lucide 为 ISC License**（https://github.com/lucide-icons/lucide）。
- 字体：仅系统字体栈，不加载外部字体。
- 设计 token：复制自 `05-交互/design-tokens.css`。
- 本应用无第三方运行时依赖；`package.json` 中 `dependencies` 为空。

> 冻结说明：v0.1 作为内部里程碑保留，不再加新功能；主线转入 `00-画布引擎v2计划.md` 与 `spike/klecks/`。
