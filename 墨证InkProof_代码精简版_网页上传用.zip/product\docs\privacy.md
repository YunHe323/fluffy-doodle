# Privacy

Mozheng is a **local-first** tool. This page explains, in plain language, what the app does with your data. It is a product description, not a legal privacy policy.

**TL;DR**

- Your artwork, archives, and evidence stay in **your browser** (IndexedDB).
- **No accounts, no telemetry, no analytics.**
- **Mock mode makes no external network requests.** Only the local service at `127.0.0.1` is contacted.
- Real AI providers are **not implemented in v0.1**. If they are added later, keys will stay local and features will be explicit opt-in.
- You can export a project JSON as a backup, and delete everything by clearing the site data.

---

## 1. Where your data lives

| Data | Storage | Notes |
|---|---|---|
| Projects, layers, layer bitmaps | Your browser's **IndexedDB** | Not uploaded to any server |
| L0 original images | IndexedDB (Blob) | Import happens locally; nothing is uploaded |
| Archive records (L0/L1/L2/L4/L5/L6) | IndexedDB | Includes source/confidence/model metadata |
| Events (evidence hash chain) | IndexedDB | Append-only; used to build evidence packages |
| Generations (AI calls) | IndexedDB | Mock calls only in v0.1 |
| Settings | IndexedDB | UI prefs, onboarding state; **no API keys** |

Clearing site data for the app deletes all of the above. Export a project JSON first if you want a backup.

---

## 2. Network behavior

- **Mock mode (default):** the app loads static files from the local service and calls `/api/health`, `/api/ai/*` on `127.0.0.1`. It makes **no external network requests**.
- **No telemetry:** no analytics SDKs, no crash-reporting uploads, no usage beacons, no remote fonts/icons.
- **No accounts:** there is nothing to sign in to and no server-side profile.
- **Provider mode (reserved, not implemented in v0.1):** if a future version supports a real model provider, it will be **opt-in**, clearly disclosed in the UI, and documented before release. Keys will be stored locally (`config/provider.json`, gitignored) and will never be committed to the repository, returned to the browser, or written to logs.
- The local service binds to `127.0.0.1` only; it is not reachable from your network.

You can verify this yourself: open DevTools → Network, run the whole workflow, and check that no external domains are contacted.

---

## 3. What the evidence package proves (and does not prove)

The exported evidence package records:

- the timeline of actions inside Mozheng;
- which layer pixel data existed at export time (SHA-256 fingerprints);
- which AI events occurred, with the mock model id;
- in attestation mode, a **scoped** “zero generation” statement (from entering the mode to export).

It **does not** prove:

- that you never used AI in other tools;
- that the timestamp is trustworthy to a third party (no trusted timestamp or C2PA signature in v0.1);
- legal authorship, ownership, or copyright;
- authenticity of files after they leave your machine.

Do not present the package as “proof of originality” or “legal proof”. It is a record of your process inside this tool.

---

## 4. Sharing and exports

- **Export Project** produces a JSON file containing your project data (including layer bitmaps). Treat it like your artwork: share only with people you trust.
- **Export Evidence Package** produces a JSON file plus a canvas PNG. These files are created locally by your browser; the app does not upload them.
- Exported files are outside the app's control. Deleting data inside the app does not delete copies you exported or shared.

---

## 5. Sample assets and third-party materials

- The built-in sample project and mock candidate images are **programmatically generated / self-made** for this project.
- Icons derived from **Lucide** are used under the ISC license; attribution is kept in [`docs/architecture.md`](architecture.md#third-party-assets).
- No external/CDN fonts are loaded; system fonts only.
- Do not add images with unclear provenance to the repository or the sample project.

---

## 6. Deleting your data

- **Within the app:** delete a project (removes its layers, archive records, events and generations).
- **Everything:** open your browser's developer tools → Application → Storage → Clear site data for `http://127.0.0.1:4173` (or the port you used). This removes all Mozheng data from that browser profile.
- There is no server-side backup or account to delete.

---

## 7. Security reports

Please report security or privacy issues **privately** to the maintainers instead of opening a public issue. Include reproduction steps and the affected version (`/api/health` → `version`). Contact: `<MAINTAINER CONTACT TO BE FILLED>`.

---

## 8. Changes to this document

This document reflects the v0.1 implementation. Any feature that changes data handling (e.g. real model providers, cloud sync) must update this document and the README **before** shipping, and must be disabled by default until the user explicitly enables it.
