// v2/app/test-eraser.mjs — 橡皮/画笔工具切换回归（headless Chrome + CDP 真实输入）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const PORT_HTTP = 8103;
const PORT_CDP = 9415;
const python = spawn('python', ['-m', 'http.server', String(PORT_HTTP), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
await sleep(900);
const profile = path.join(os.tmpdir(), 'erasertest-' + Date.now());
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist',
  '--window-size=1500,950', '--hide-scrollbars',
  `--remote-debugging-port=${PORT_CDP}`, `--user-data-dir=${profile}`,
  `http://127.0.0.1:${PORT_HTTP}/v2/app/index.html?debug=1`,
], { stdio: 'ignore' });
let target = null;
for (let i = 0; i < 200 && !target; i++) {
  try { const r = await fetch(`http://127.0.0.1:${PORT_CDP}/json/list`); target = (await r.json()).find((t) => t.type === 'page' && t.url.startsWith('http')); } catch (e) {}
  if (!target) await sleep(200);
}
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map(); const errors = [];
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); return; } if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text); if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push(m.params.args.map((a) => a.value || a.description).join(' ')); };
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
async function ev(expression) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true });
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1200));
  return r.result?.result?.value;
}
async function key(k, code, vk) {
  await send('Input.dispatchKeyEvent', { type: 'keyDown', key: k, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk });
  await send('Input.dispatchKeyEvent', { type: 'keyUp', key: k, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk });
  await sleep(250);
}
const provider = () => ev('window.__V2_APP__.engine.getBrushProvider().id');
const brushStatus = () => ev('document.getElementById("brushStatus").textContent');
async function darkCount() {
  return ev(`(async () => { const e = window.__V2_APP__.engine; e.compositor.compositeAll(e.store); const url = await e.getCompositeDataUrl(); const img = new Image(); img.src = url; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const ctx = c.getContext('2d'); ctx.drawImage(img,0,0); const d = ctx.getImageData(0,0,c.width,c.height).data; let dark=0; for (let i=0;i<d.length;i+=4) if (d[i+3]>0 && d[i]<235) dark++; return dark; })()`);
}
const out = { schema: 'mozheng.app.eraser-test.v1', cases: [] };
try {
  await send('Runtime.enable'); await send('Page.enable');
  for (let i = 0; i < 600; i++) { if (await ev('!!window.__V2_APP_READY__').catch(() => false)) break; await sleep(200); }
  out.ready = await ev('!!window.__V2_APP_READY__');
  // 先画一条硬笔画笔横线（直接走 controller，验证像素基线）
  out.baseline = await ev(`(async () => {
    const { controller, engine } = window.__V2_APP__;
    controller.setPreset(window.__V2_APP__.state ? window.__V2_APP__.state.activePresetId && window.__V2_APP__.state.activePresetId !== 'eraser' ? controller.preset : null : controller.preset);
    controller.begin({ x: 200, y: 420, pressure: 0.8, timestamp: performance.now() });
    for (let i = 1; i <= 40; i++) controller.append({ x: 200 + i * 20, y: 420, pressure: 0.8, timestamp: performance.now() + i * 16 });
    controller.end();
    return { provider: engine.getBrushProvider().id, undo: engine.getStats().undoDepth };
  })()`);
  out.darkBefore = await darkCount();
  // 1) 按 E：应切到 eraser provider
  await key('e', 'KeyE', 69);
  out.afterE = { provider: await provider(), status: await brushStatus() };
  // 2) 用鼠标在横线上方竖直擦一笔（真实 CDP pointer）
  const rect = await ev(`(() => { const r = document.getElementById('mainCanvas').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
  const cx = rect.x + rect.w * 0.55;
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: cx, y: rect.y + rect.h * 0.28, button: 'left', clickCount: 1 });
  for (let i = 1; i <= 16; i++) await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: cx, y: rect.y + rect.h * (0.28 + 0.28 * i / 16), button: 'left', buttons: 1 });
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: cx, y: rect.y + rect.h * 0.56, button: 'left', clickCount: 1 });
  await sleep(500);
  out.darkAfterErase = await darkCount();
  out.afterErase = { provider: await provider(), undo: await ev('window.__V2_APP__.engine.getStats().undoDepth') };
  // 3) 按 B：恢复上次画笔
  await key('b', 'KeyB', 66);
  out.afterB = { provider: await provider(), status: await brushStatus() };
  // 4) 选水彩 → E → B：应恢复水彩
  await ev(`document.querySelectorAll('#brushGrid .brush-chip')[8].click()`);
  await sleep(300);
  out.watercolor = { provider: await provider() };
  await key('e', 'KeyE', 69);
  out.watercolorE = { provider: await provider() };
  await key('b', 'KeyB', 66);
  out.watercolorBack = { provider: await provider() };
  out.pass = {
    eraserSwitches: out.afterE.provider === 't36-eraser',
    brushRestores: out.afterB.provider === 't36-hard-round',
    eraserVisible: out.darkAfterErase < out.darkBefore,
    watercolorRestores: out.watercolorBack.provider === 't36-watercolor' && out.watercolorE.provider === 't36-eraser',
  };
  out.errors = errors.slice(0, 8);
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'eraser-test-screenshot.png'), Buffer.from(shot.result.data, 'base64'));
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e.stack || e); out.errors = errors.slice(0, 8);
  console.log(JSON.stringify(out, null, 2));
} finally {
  try { ws.close(); } catch (e) {}
  chrome.kill(); python.kill(); await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
  fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'test-eraser-result.json'), JSON.stringify(out, null, 2), 'utf8');
  process.exit(0);
}
