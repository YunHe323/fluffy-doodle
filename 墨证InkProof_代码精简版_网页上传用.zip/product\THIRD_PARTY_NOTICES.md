# THIRD_PARTY_NOTICES.md

> 项目一 / Mozheng InkProof · 第三方组件与许可声明（草案）
> 维护：tech-architect｜创建：2026-11-06｜最近核对：2026-11-06
> 适用：`product/` 仓库与 v0.1 内部里程碑；v2 画布引擎开始引入第三方代码时**必须**在本文件登记后才可合并。
> 相关：`06-技术/画布引擎v2_预研.md`（选型与许可红线）、`LICENSE`（项目许可，当前为占位，发布前最终确认）。
>
> ⚠️ 本文件是**草案**，不构成法律意见。GPL/许可不明组件的最终判断需法务确认；本文件给出的是工程执行红线。

---

## A. 当前分发代码（v0.1，已冻结为内部里程碑）

v0.1 运行时**零第三方依赖**（`product/package.json` 的 `dependencies` 为空），以下为随产品分发的第三方资产：

| 组件/资产 | 许可 | 状态 | 义务 / 说明 |
|---|---|---|---|
| 内联 SVG 图标（Lucide 风格路径子集） | **ISC** | 已在产品中（`product/app/js/icons.js` 内联，无外部依赖） | 保留 Lucide 的 ISC 许可文本与版权声明（见 <https://lucide.dev/license>）；本项目使用其路径子集，如有修改需注明 |
| 字体 | **系统字体**（不打包） | 未分发 | 不随产品分发字体文件，无需许可声明；不得改为打包商业字体 |
| 示例作品/截图 | **自制/程序生成** | `product/docs/screenshots/` 等 | 无第三方版权；如后续加入第三方图片必须单独登记 |
| `product/reference/demo-v1.html`（内部参考快照） | 自制 | **不在发布包/不随开源仓库发布** | 仅内部参考，不对外分发 |
| 运行时依赖 | 无 | `dependencies: {}` | 保持零第三方运行时依赖（代码审查保证） |

> 说明：v0.1 冻结、不对外发布；开源仓库 `mozheng` 暂缓发布。发布前需复核本表。

---

## B. v2 画布引擎评估中/计划引入的第三方组件（尚未合并）

> 当前状态：**仅评估，未进入 `product/` 代码**。任何一项进入代码前，必须：①确认 SPDX；②保留许可全文；③在 §H 记录版本与来源；④Lead 审核。
> 版本号在引入时锁定并回填；下表 SPDX 状态来自 2026-11-06 的仓库抓取。

| 组件 | 来源 | SPDX | 计划用途 | 引入义务 | 备注 |
|---|---|---|---|---|---|
| **Klecks** | <https://github.com/bitbof/klecks> | **MIT** | 路线 R1 基座 / R2-R3 参考（TypeScript 网页绘画应用，Kleki.com 内核） | 保留版权声明与 MIT 全文；若分发修改版需注明修改 | README 明示：MIT 版权归 bitbof；**Kleki 名称与品牌不在授权内**，不得使用 Kleki 品牌/Logo；仓库内图标为 public domain（Logo 除外） |
| **Skia / CanvasKit** | <https://github.com/google/skia> | **BSD-3-Clause** | 路线 R2 渲染内核（WASM） | 保留版权/许可/免责声明；**必须随包附 Skia 的 `third_party/` 全部许可**（WASM 构建内含多个第三方库，清单以集成版本为准） | CanvasKit 是 Skia 的官方 WASM 构建；构建产物体积/内存以 spike 实测为准 |
| **perfect-freehand** | <https://github.com/steveruizok/perfect-freehand> | **MIT** | 笔迹轮廓/平滑（可选） | 保留版权声明与 MIT 全文 | 压感自由线轮廓生成；也可自研替代 |
| **PixiJS** | <https://github.com/pixijs/pixijs> | **MIT** | 可选 WebGL 2D 渲染基座（若不走 CanvasKit 且不自研底层） | 保留版权声明与 MIT 全文 | 与「自研 tile 渲染」二选一，避免双渲染栈 |
| **ag-psd** | <https://github.com/Agamnentzar/ag-psd> | **MIT（+ Apache-2.0 片段注记）** | PSD 导入/导出 | 保留 MIT 全文；**同时保留 LICENSE 中关于 CMYK→RGB 系数来自 pdf.js（Apache-2.0）的注记与声明** | GitHub 许可检测显示 `NOASSERTION` 是因为 LICENSE 末尾附加了第三方注记，实际正文为 MIT；详见仓库 LICENSE |
| **lcms2（Little-CMS）** | <https://github.com/mm2/Little-CMS> | **MIT** | ICC 色彩转换（若做 P3/ICC 管理） | 保留版权声明与 MIT 全文 | WASM 构建由本项目自行完成时，同样适用 MIT |

### B.1 许可全文与版本管理

- 许可全文在引入时放入 `product/third_party/<组件>/LICENSE`（或第三方要求的位置），并在本节表格回填 `<版本>, <commit/tag>`。
- 每次升级依赖：更新版本号 → 重新核对 SPDX → 重新引入许可全文 → 在本文件 §H 记录。
- `package.json` 中不得出现 GPL/AGPL/LGPL（含 `GPL-3.0-or-later` 等）依赖；CI 检查见 §E。

---

## C. 仅阅读/参考（不得复制代码，不得作为依赖）

| 项目 | 来源 | 许可状态 | 允许 | 禁止 |
|---|---|---|---|---|
| **Krita** | <https://github.com/KDE/krita> | **GPL-3.0** | 阅读文档、论文、交互行为；理解算法思想 | 复制/移植/链接任何源码或资源；不得出现在依赖树与仓库文件中 |
| **MyPaint / libmypaint** | <https://github.com/mypaint/libmypaint> | **NOASSERTION**（GitHub 标注 Other；项目文档为 GPL/LGPL 混合） | 阅读公开算法说明（brush engine 文档等） | 复制/移植/链接代码；不得把笔刷引擎实现搬入本项目 |
| **Drawpile** | <https://github.com/drawpile/Drawpile> | **GPL-3.0** | 阅读协作/笔刷算法思路 | 复制/移植/链接代码 |
| **darkly** | <https://github.com/darkly-art/darkly> | **NOASSERTION**（仓库未声明标准许可） | 仅阅读公开实现思路（Rust/Svelte/WASM/WebGPU 编辑器） | 复制任何代码或素材；无许可默认「保留所有权利」 |

**GPL 红线（工程执行口径）**

1. 本项目目标许可为 **MIT**（`LICENSE` 占位，发布前最终确认）。**只要 GPL/LGPL/NOASSERTION 代码进入仓库**，整个分发物可能被要求按 GPL 释放——**禁止**。包括：复制片段、逐行改写、翻译移植、WASM 编译 GPL 源码后分发。
2. 参考 ≠ 复制：允许阅读公开文档/论文/产品行为并**独立实现**（clean-room，见 §E 流程）；代码审查时需能说明「算法来源是文档/公开描述，而不是某份 GPL 源码」。
3. 许可不明（`NOASSERTION`）= 默认保留所有权利，按「不可复制」处理。
4. Procreate 的笔刷/素材/文件**不可**提取或再分发；Procreate 官方文档仅作为产品行为参考。

---

## D. 随包分发 Skia/CanvasKit 时的额外义务（若选 R2）

若 v2 选择 CanvasKit/Skia（BSD-3）：

1. 保留 `LICENSE`（BSD-3 全文）与版权声明。
2. **收集并随包附上 Skia 构建所含 third_party 组件的许可**（以 spike 时锁定的 Skia 版本为准；常见含 libpng/libjpeg-turbo/freetype 等，实际清单以构建版本为准）。
3. 发布物（含 zip/单文件/WASM）内附 `THIRD_PARTY_NOTICES.md` 的对应章节；不得删除许可文件。
4. 本文件 §B 表格回填 Skia 版本/commit 与 third_party 清单路径。

---

## E. 引入第三方代码的流程（PR checklist）

1. **确认许可**：SPDX ID + LICENSE 全文（不接受「看起来是 MIT」）。
2. **分类**：可直接依赖（MIT/BSD/Apache-2.0 等宽松） / 参考-only（GPL/NOASSERTION/不明） / 禁止。
3. **更新本文件**：新增 §B 条目（版本、用途、义务、来源）或 §C 条目。
4. **保留声明**：代码/资源放到约定目录并保留原始版权头；不删除许可文件。
5. **审查**：
   - [ ] 无 GPL/LGPL/AGPL/NOASSERTION 依赖进入 `package.json` 或仓库文件
   - [ ] 许可证全文已保留（路径：\_\_\_\_）
   - [ ] `THIRD_PARTY_NOTICES.md` 已更新并回填版本
   - [ ] 若为算法参考：已记录「参考来源 = 文档/论文，代码为独立实现」
   - [ ] Lead 审核通过
6. **CI 建议（v2 起）**：加一个零依赖脚本，扫描仓库内 GPL/AGPL/LGPL 头与 `package.json` 依赖许可；发现即失败（与 `node --test` 同跑）。

**Clean-room 记录建议**（参考 GPL 项目时）：

```text
算法/交互需求来源：<官方文档/论文/产品行为，URL>
参考项目：<Krita 文档章节 / libmypaint 论文式说明>（不引用源码行号）
独立实现者：<name>；审阅者：<name>
实现文件：product/app/... 或 spike/...
声明：未复制、未移植参考项目源码。
```

---

## F. 许可文本位置

| 组件 | 许可文本 |
|---|---|
| Lucide（ISC） | <https://lucide.dev/license> |
| Klecks（MIT） | <https://github.com/bitbof/klecks/blob/main/LICENSE> |
| Skia（BSD-3） | <https://github.com/google/skia/blob/main/LICENSE> |
| perfect-freehand（MIT） | <https://github.com/steveruizok/perfect-freehand/blob/main/LICENSE> |
| PixiJS（MIT） | <https://github.com/pixijs/pixijs/blob/dev/LICENSE> |
| ag-psd（MIT + pdf.js 注记） | <https://github.com/Agamnentzar/ag-psd/blob/master/LICENSE> |
| lcms2（MIT） | <https://github.com/mm2/Little-CMS/blob/master/LICENSE> |
| Krita（GPL-3.0） | <https://github.com/KDE/krita/blob/master/LICENSE>（仅参考） |
| libmypaint（NOASSERTION） | <https://github.com/mypaint/libmypaint>（仅参考） |
| Drawpile（GPL-3.0） | <https://github.com/drawpile/Drawpile/blob/main/LICENSE>（仅参考） |
| darkly（NOASSERTION） | <https://github.com/darkly-art/darkly>（仅参考） |

> 引入依赖时请把**完整文本**复制到 `product/third_party/<组件>/LICENSE`；上表仅作索引，不替代全文。

---

## G. 项目自身许可

- 当前 `product/LICENSE` 为 **MIT 占位**，版权人字段待填写；最终开源源码仓库前由 Lead/用户确认。
- 无论项目许可最终为何，**本文件中的第三方义务必须履行**（第三方许可不能因本项目许可变更而豁免）。

---

## H. 核对记录

| 日期 | 动作 | 结果 |
|---|---|---|
| 2026-11-06 | 通过 GitHub API 核对 10 个仓库的许可状态（klecks / perfect-freehand / skia / pixijs / ag-psd / Little-CMS / krita / libmypaint / Drawpile / darkly） | 与 §B/§C 表一致；ag-psd 需注意 MIT+Apache-2.0 注记；libmypaint 与 darkly 为 NOASSERTION |
| 2026-11-06 | 核对 v0.1 现有第三方资产（图标 ISC、系统字体、自制截图） | 仅 Lucide 风格图标需保留 ISC 声明 |
| 2026-11-06 | 创建本草案（T24） | 待 v2 spike 选型后回填具体版本与 third_party 清单 |

---

## I. 联系与报告

- 许可问题/疑似许可冲突：请在仓库 issue 中标注 `license`（开源仓库发布后），或直接联系维护者。
- 安全/隐私问题：见 `product/docs/privacy.md`。
