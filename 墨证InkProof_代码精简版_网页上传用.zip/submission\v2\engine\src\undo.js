/**
 * v2 engine · 撤销/重做（tile patch before/after 快照，默认 80 步 / 200MB 上限）
 *
 * T49：架构参考 Klecks（MIT）的 KlHistory（spike/klecks/vendor/klecks/src/app/script/klecks/history/kl-history.ts），
 * 采用其「tile diff + composed/状态栈 + pause/resume + replaceTop + listeners（canUndo/Redo 变化）」设计，
 * clean-room 改写为 v2 的 tile patch 模型；未复制 Klecks 代码。
 * 每笔 = 一个 UndoEntry（含受影响 tile 的 patch）；内存：每 patch 两份 256² RGBA 快照。
 */
export const MAX_UNDO_STEPS = 80;
export const MAX_HISTORY_BYTES = 200 * 1024 * 1024;

export class UndoManager {
  constructor(store, maxSteps = MAX_UNDO_STEPS, maxBytes = MAX_HISTORY_BYTES) {
    this.store = store;
    this.maxSteps = maxSteps;
    this.maxBytes = maxBytes;
    this.undoStack = [];
    this.redoStack = [];
    this.bytes = 0;
    /** Klecks `pauseStack`：复合操作期间抑制生成多个 undo 步 */
    this.paused = 0;
    /** @type {Array<(state:{canUndo:boolean,canRedo:boolean,depth:number}) => void>} */
    this.listeners = [];
    // T89：自动回收（默认开；可关）；回收时通过 onEvict 回调释放图片引用
    this.autoEvict = true;
    this.onEvict = null;
    this.evictedSteps = 0;
  }

  _entryBytes(entry) {
    if (!entry) return 0;
    if (entry.kind === 'image') return 2 * 4096 * 4096 * 4; // 估算上限（整层前后快照）
    if (entry.kind === 'structure') return 0; // 结构快照为图像引用/元数据，M4.5 做引用计数
    return (entry.patches ? entry.patches.length : 0) * 256 * 256 * 4 * 2;
  }

  /** 结构校验（对应 Klecks validateHistoryEntry 的基本约束） */
  validate(entry) {
    if (!entry) return false;
    if (entry.kind === 'image') return typeof entry.layerId === 'string' && !!entry.before && !!entry.after;
    if (entry.kind === 'structure') return !!entry.before && !!entry.after;
    return typeof entry.layerId === 'string' && Array.isArray(entry.patches)
      && entry.patches.every((p) => p && typeof p.key === 'string' && p.before && p.after);
  }

  _notify() {
    const state = { canUndo: this.canUndo(), canRedo: this.canRedo(), depth: this.depth() };
    for (const fn of this.listeners) {
      try { fn(state); } catch (e) { /* ignore listener errors */ }
    }
  }

  addListener(fn) {
    if (typeof fn === 'function') this.listeners.push(fn);
    return () => this.removeListener(fn);
  }

  removeListener(fn) {
    const i = this.listeners.indexOf(fn);
    if (i >= 0) this.listeners.splice(i, 1);
  }

  pause() { this.paused += 1; return this.paused; }
  resume() { this.paused = Math.max(0, this.paused - 1); return this.paused; }
  isPaused() { return this.paused > 0; }

  push(entry) {
    if (this.paused > 0) return false;
    if (!this.validate(entry)) return false;
    if (entry.kind !== 'image' && entry.kind !== 'structure' && (!entry.patches || entry.patches.length === 0)) return false;
    this.undoStack.push(entry);
    this.bytes += this._entryBytes(entry);
    this.redoStack.length = 0;
    this._evict();
    this._notify();
    return true;
  }

  /** 替换栈顶（Klecks replaceTop）：用于同一复合操作内的再次变化，避免多步 undo */
  replaceTop(entry) {
    if (!this.validate(entry)) return false;
    if (this.undoStack.length === 0) return this.push(entry);
    const old = this.undoStack[this.undoStack.length - 1];
    this.bytes -= this._entryBytes(old);
    this.undoStack[this.undoStack.length - 1] = entry;
    this.bytes += this._entryBytes(entry);
    this._evict();
    this._notify();
    return true;
  }

  /** 合并栈顶 count 个条目为一个（用于对称笔迹等复合操作） */
  mergeTop(count, mergeFn) {
    const n = Math.max(2, Math.floor(Number(count) || 2));
    if (this.undoStack.length < n || typeof mergeFn !== 'function') return false;
    const entries = this.undoStack.slice(-n);
    let merged = null;
    try { merged = mergeFn(entries.slice()); } catch (e) { merged = null; }
    if (!this.validate(merged)) return false;
    let freed = 0;
    for (const e of entries) freed += this._entryBytes(e);
    this.undoStack.splice(this.undoStack.length - n, n);
    this.bytes -= freed;
    return this.push(merged);
  }

  _evict() {
    if (!this.autoEvict) return;
    while (this.undoStack.length > this.maxSteps) {
      const dropped = this.undoStack.shift();
      this.bytes -= this._entryBytes(dropped);
      this._freeEntry(dropped);
    }
    while (this.bytes > this.maxBytes && this.undoStack.length > 1) {
      const dropped = this.undoStack.shift();
      this.bytes -= this._entryBytes(dropped);
      this._freeEntry(dropped);
    }
  }

  _freeEntry(entry) {
    // M4.1 暂不主动删除快照：before/after 可能仍被当前 tile.image 或后续 patch 引用，
    // 误删会导致合成崩溃/黑屏。M4.5 做引用计数后再释放（见 v2实现计划.md §6 风险 2）。
    // T89：entry 被移出历史后，交给 engine 做图片引用检查，仅释放不再被引用的 image
    if (!entry || !this.onEvict) return;
    this.evictedSteps += 1;
    try { this.onEvict(entry); } catch (e) { /* ignore */ }
  }

  /** T89：运行时调整历史预算/自动回收（auto=false 可回退到旧行为） */
  setLimits(opts = {}) {
    if (Number.isFinite(opts.maxSteps) && opts.maxSteps > 0) this.maxSteps = Math.floor(opts.maxSteps);
    if (Number.isFinite(opts.maxBytes) && opts.maxBytes > 0) this.maxBytes = Math.floor(opts.maxBytes);
    if (typeof opts.auto === 'boolean') this.autoEvict = opts.auto;
    this._evict();
    this._notify();
    return { maxSteps: this.maxSteps, maxBytes: this.maxBytes, auto: this.autoEvict };
  }

  canUndo() { return this.undoStack.length > 0; }
  canRedo() { return this.redoStack.length > 0; }
  depth() { return this.undoStack.length; }
  redoDepth() { return this.redoStack.length; }
  memoryEstimate() { return this.bytes; }

  /** @returns {any|null} 被撤销的 entry（调用方负责应用 patch） */
  popUndo() {
    const entry = this.undoStack.pop();
    if (!entry) return null;
    this.bytes -= this._entryBytes(entry);
    this.redoStack.push(entry);
    this._notify();
    return entry;
  }

  /** @returns {any|null} 被重做的 entry（调用方负责应用 patch） */
  popRedo() {
    const entry = this.redoStack.pop();
    if (!entry) return null;
    this.bytes += this._entryBytes(entry);
    this.undoStack.push(entry);
    this._notify();
    return entry;
  }

  clear() {
    this._freeEntry({ patches: [] });
    for (const e of this.undoStack) this._freeEntry(e);
    for (const e of this.redoStack) this._freeEntry(e);
    this.undoStack = [];
    this.redoStack = [];
    this.bytes = 0;
    this._notify();
  }
}
