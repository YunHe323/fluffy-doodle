// product/test/config.test.mjs
// config/provider.json 的加载规则（存在则读、非法不崩、密钥不对外）。
import test from 'node:test';
import assert from 'node:assert/strict';
import { promises as fs } from 'node:fs';
import os from 'node:os';
import path from 'node:path';

import { loadConfigFromFile, getRuntimeConfig } from '../server/server.mjs';
import { publicConfig } from '../server/ai-proxy.mjs';

async function withTmpDir(fn) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'po-config-'));
  try {
    return await fn(dir);
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
}

test('provider.json 不存在：返回 absent，不崩', async () => {
  await withTmpDir(async (dir) => {
    const result = await loadConfigFromFile(path.join(dir, 'missing.json'));
    assert.deepEqual(result, { loaded: false, reason: 'absent' });
  });
});

test('provider.json 合法：加载进内存，公开视图不含 apiKey', async () => {
  await withTmpDir(async (dir) => {
    const file = path.join(dir, 'provider.json');
    await fs.writeFile(file, JSON.stringify({
      provider: 'openai-compatible',
      baseUrl: 'https://api.example.invalid/v1',
      model: 'example-model',
      apiKey: 'sk-test-should-never-leak',
    }), 'utf8');

    const result = await loadConfigFromFile(file);
    assert.deepEqual(result, { loaded: true });

    const config = getRuntimeConfig();
    assert.equal(config.provider, 'openai-compatible');
    assert.equal(config.apiKey, 'sk-test-should-never-leak');

    const pub = publicConfig(config, 'file', new Date().toISOString());
    assert.equal(pub.apiKeySet, true);
    assert.equal(pub.apiKey, undefined);
    assert.ok(!JSON.stringify(pub).includes('sk-test-should-never-leak'));

    // 恢复 mock，避免影响同进程后续测试
    const mockFile = path.join(dir, 'mock.json');
    await fs.writeFile(mockFile, JSON.stringify({ provider: 'mock', baseUrl: '', model: '', apiKey: '' }), 'utf8');
    await loadConfigFromFile(mockFile);
  });
});

test('provider.json 非法 JSON：unreadable，不崩', async () => {
  await withTmpDir(async (dir) => {
    const file = path.join(dir, 'broken.json');
    await fs.writeFile(file, '{ not json', 'utf8');
    const result = await loadConfigFromFile(file);
    assert.deepEqual(result, { loaded: false, reason: 'unreadable' });
  });
});

test('provider.json 字段非法：invalid_config + 错误明细', async () => {
  await withTmpDir(async (dir) => {
    const file = path.join(dir, 'bad.json');
    await fs.writeFile(file, JSON.stringify({ provider: 'definitely-not-a-provider' }), 'utf8');
    const result = await loadConfigFromFile(file);
    assert.equal(result.loaded, false);
    assert.equal(result.reason, 'invalid_config');
    assert.ok(Array.isArray(result.errors) && result.errors.length > 0);
  });
});
