// v2/app/test-async-export.mjs — T78 异步导出/压缩保存（Playwright/msedge，硬超时）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8116;
const out = { schema: 'mozheng.app.async-export-test.v1', cases: {}, errors: [] };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
let browser = null;
const finish = (code = 0) => { try { fs.writeFileSync(ROOT + '\\v2\\app\\test-async-export-result.json', JSON.stringify(out, null, 2), 'utf8'); } catch (e) {} process.exit(code); };
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_240s'; finish(3); }, 240000);

try {
  await new Promise((r) => setTimeout(r, 800));
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const context = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  const load = async () => {
    await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
    await page.waitForTimeout(400);
  };
  await load();
  const box = await page.locator('#mainCanvas').boundingBox();
  // 画一笔 + 预热导出
  await page.evaluate(() => { const a = window.__V2_APP__; a.engine.setActiveLayer(a.engine.getLayers()[0].id); a.engine.setLayerLocked(a.engine.getLayers()[0].id, false); a.setTool('brush'); });
  await page.mouse.move(box.x + box.width * 0.3, box.y + box.height * 0.35);
  await page.mouse.down();
  for (let i = 1; i <= 8; i++) await page.mouse.move(box.x + box.width * (0.3 + i * 0.02), box.y + box.height * (0.35 + i * 0.02));
  await page.mouse.up();
  await page.waitForTimeout(300);
  out.cases.warm = await page.evaluate(async () => { const t = window.__V2_APP__.t78; const t0 = performance.now(); const ok = await t.warmUp(); return { ok, ms: Math.round(performance.now() - t0) }; });

  // 异步 PNG：进度 + 像素与同步一致 + longtask
  out.cases.png = await page.evaluate(async () => {
    const app = window.__V2_APP__; const t = app.t78;
    window.__PROG__ = []; window.__LT__ = [];
    try { window.__LT_OBS__ = new PerformanceObserver((l) => window.__LT__.push(...l.getEntries().map((e) => e.duration))); window.__LT_OBS__.observe({ entryTypes: ['longtask'] }); } catch (e) {}
    const blob = await t.exportPngBlob({ onProgress: (p) => window.__PROG__.push(p) });
    await new Promise((r) => setTimeout(r, 300));
    try { window.__LT_OBS__.disconnect(); } catch (e) {}
    const syncUrl = await app.engine.getCompositeDataUrl();
    const decode = async (url) => { const img = new Image(); img.src = url; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; c.getContext('2d').drawImage(img, 0, 0); return c.getContext('2d').getImageData(0, 0, c.width, c.height).data; };
    const asyncData = await decode(URL.createObjectURL(blob));
    const syncData = await decode(syncUrl);
    let diff = 0;
    for (let i = 0; i < asyncData.length; i += 4) if (asyncData[i] !== syncData[i] || asyncData[i + 1] !== syncData[i + 1] || asyncData[i + 2] !== syncData[i + 2] || asyncData[i + 3] !== syncData[i + 3]) diff += 1;
    const phases = [...new Set(window.__PROG__.map((p) => p.phase))];
    return { bytes: blob.size, phases, diff, longTasks: window.__LT__.length, maxLong: window.__LT__.length ? Math.max(...window.__LT__) : 0 };
  });

  // 取消
  out.cases.cancel = await page.evaluate(async () => {
    const t = window.__V2_APP__.t78;
    let err = null;
    const p = t.exportPngBlob({ onProgress: () => {} });
    setTimeout(() => { try { t.cancelExport(); } catch (e) {} }, 15);
    try { await p; } catch (e) { err = { name: e.name, message: e.message }; }
    await new Promise((r) => setTimeout(r, 250));
    const blob = await t.exportPngBlob({}); // 取消后可再次导出
    return { err, canExportAgain: blob.size > 100, taskActive: t.getAsyncTask().active };
  });

  // v2 gzip 保存/打开 + 像素一致 + v1 兼容
  out.cases.save = await page.evaluate(async () => {
    const app = window.__V2_APP__; const t = app.t78;
    const decode = async (url) => { const img = new Image(); img.src = url; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; c.getContext('2d').drawImage(img, 0, 0); return c.getContext('2d').getImageData(0, 0, c.width, c.height).data; };
    const diff = (a, b) => { let n = 0; for (let i = 0; i < a.length; i += 4) if (a[i] !== b[i] || a[i + 1] !== b[i + 1] || a[i + 2] !== b[i + 2] || a[i + 3] !== b[i + 3]) n += 1; return n; };
    const beforeUrl = await app.engine.getCompositeDataUrl();
    const v1Text = app.engine.serializeDoc();
    const v1TextLayers = JSON.parse(v1Text).doc.layers.length;
    const sizes = await t.getFileSizes();
    const saved = await t.saveProjectBlob();
    const docBefore = app.engine.getDoc();
    // 改画布后再回读 v2
    app.engine.addLayer({ name: '临时层' }); app.engine.presentFull(); await new Promise((r) => setTimeout(r, 120));
    await t.loadProjectData(saved.blob);
    const afterUrl = await app.engine.getCompositeDataUrl();
    const docAfter = app.engine.getDoc();
    // v1 文本 / v1 Blob 兼容（Blob 路径与 v2 同通道）
    const directTextDoc = await app.engine.deserializeDocAuto(v1Text);
    const directTextInfo = { layers: directTextDoc.layers.length, ids: directTextDoc.layers.map((l) => l.id) };
    const directBlobDoc = await app.engine.deserializeDocAuto(new Blob([v1Text], { type: 'application/json' }));
    const directBlobInfo = { layers: directBlobDoc.layers.length, ids: directBlobDoc.layers.map((l) => l.id) };
    const v1Doc = await t.loadProjectText(v1Text);
    const v1Blob = new Blob([v1Text], { type: 'application/json' });
    const v1Doc2 = await t.loadProjectData(v1Blob);
    // gzip 解压后的 JSON 应与 v1 文本一致
    const savedBuf = await saved.blob.arrayBuffer();
    let savedJson = null;
    try { savedJson = await new Response(new Blob([savedBuf]).stream().pipeThrough(new DecompressionStream('gzip'))).text(); } catch (e) {}
    const jsonEqual = savedJson === v1Text;
    // v2 ↔ v1 回读像素一致（压缩不改变像素）
    await t.loadProjectData(v1Blob);
    const v1Info = { layers: app.engine.getLayers().length, ids: app.engine.getLayers().map((l) => l.id), counts: app.engine.getLayers().map((l) => app.engine.store.count(l.id)) };
    const v1Png = await app.engine.getCompositeDataUrl();
    await t.loadProjectData(saved.blob);
    const v2Info = { layers: app.engine.getLayers().length, ids: app.engine.getLayers().map((l) => l.id), counts: app.engine.getLayers().map((l) => app.engine.store.count(l.id)) };
    const v2Png = await app.engine.getCompositeDataUrl();
    const pixelDiffV2V1 = diff(await decode(v1Png), await decode(v2Png));
    const pixelDiffBefore = diff(await decode(beforeUrl), await decode(v2Png));
    return { sizes, saved, jsonEqual, directTextInfo, directBlobInfo, v1Info, v2Info, pixelDiffBefore, pixelDiffV2V1, sameV2V1: pixelDiffV2V1 === 0, layers: [docBefore.layers.length, docAfter.layers.length], v1TextLayers, v1Layers: [v1Doc.layers.length, v1Doc2.layers.length], compressedRatio: sizes.v2 / sizes.v1 };
  });

  // IDB 自动保存为压缩版 + 刷新恢复
  await page.evaluate(async () => { const app = window.__V2_APP__; app.engine.addLayer({ name: '自动保存层' }); app.engine.presentFull(); app.t61.commitDocUI(); await new Promise((r) => setTimeout(r, 1900)); });
  out.cases.autosave = await page.evaluate(async () => { const r = await window.__V2_APP__.t78.getAutosaveRecord(); return { hasBlob: !!(r && r.blob), compressed: !!(r && r.compressed), bytes: r ? (r.bytes || (r.blob && r.blob.size) || 0) : 0 }; });
  await page.reload();
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(600);
  out.cases.reload = await page.evaluate(() => ({ layers: window.__V2_APP__.engine.getLayers().length, status: document.getElementById('projectStatus') ? document.getElementById('projectStatus').textContent : '' }));

  // Worker 不可用 → fallback
  out.cases.workerFallback = await page.evaluate(async () => {
    const orig = window.Worker;
    try {
      Object.defineProperty(window, 'Worker', { value: undefined, configurable: true });
      const e = window.__V2_APP__.engine;
      e._releaseExportWorker && e._releaseExportWorker();
      e._exportWorker = null; e._exportWarmed = false;
      const prog = [];
      const blob = await e.exportPNGAsync({ onProgress: (p) => prog.push(p.phase) });
      return { ok: blob.size > 100, phases: [...new Set(prog)] };
    } finally {
      try { Object.defineProperty(window, 'Worker', { value: orig, configurable: true }); } catch (e) {}
    }
  });
  // CompressionStream 不可用 → v1 回退
  out.cases.compressionFallback = await page.evaluate(async () => {
    const orig = window.CompressionStream;
    try {
      Object.defineProperty(window, 'CompressionStream', { value: undefined, configurable: true });
      const r = await window.__V2_APP__.t78.saveProjectBlob();
      return { compressed: r.compressed, bytes: r.bytes, magic: await (async () => { const b = new Uint8Array(await r.blob.slice(0, 2).arrayBuffer()); return [b[0], b[1]]; })() };
    } finally { try { Object.defineProperty(window, 'CompressionStream', { value: orig, configurable: true }); } catch (e) {} }
  });

  // 三档截图（进度条可见）
  const shots = {};
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await page.setViewportSize({ width: w, height: h });
    await load();
    await page.evaluate(() => { const t = window.__V2_APP__.t78; t.showAsyncTask('导出 PNG', () => {}); t.updateAsyncTask({ phase: 'read', done: 11, total: 20 }); });
    await page.waitForTimeout(250);
    await page.screenshot({ path: ROOT + '\\v2\\app\\ui-export-' + w + '.png' });
    shots[w] = await page.evaluate(() => ({ overX: document.documentElement.scrollWidth > innerWidth + 1, overY: document.documentElement.scrollHeight > innerHeight + 1, taskVisible: !document.getElementById('asyncTask').hidden }));
    await page.evaluate(() => window.__V2_APP__.t78.hideAsyncTask());
  }
  out.cases.screenshots = shots;
  out.errors = errors.slice(0, 12);
  out.pass = {
    warm: out.cases.warm.ok,
    pngProgress: out.cases.png.phases.includes('read') && out.cases.png.phases.includes('encode') && out.cases.png.phases.includes('done') && out.cases.png.bytes > 1000,
    pngPixels: out.cases.png.diff === 0,
    longTasks: out.cases.png.longTasks <= 1,
    cancel: out.cases.cancel.err && out.cases.cancel.err.name === 'AbortError' && out.cases.cancel.canExportAgain && !out.cases.cancel.taskActive,
    gzipSave: out.cases.save.saved.compressed && out.cases.save.sizes.v2 < out.cases.save.sizes.v1 && out.cases.save.pixelDiffV2V1 === 0 && out.cases.save.layers[0] === out.cases.save.layers[1],
    v1Compat: out.cases.save.v1TextLayers === 2 && out.cases.save.v1Layers[1] === 2,
    autosaveCompressed: out.cases.autosave.hasBlob && out.cases.autosave.compressed && out.cases.autosave.bytes > 100,
    reloadRestore: out.cases.reload.layers >= 2 && out.cases.reload.status.includes('恢复'),
    workerFallback: out.cases.workerFallback.ok && out.cases.workerFallback.phases.includes('fallback'),
    compressionFallback: out.cases.compressionFallback.compressed === false && out.cases.compressionFallback.magic[0] !== 0x1f,
    screenshots: Object.values(shots).every((v) => !v.overX && !v.overY && v.taskVisible),
  };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  out.errors = errors ? errors.slice(0, 12) : [];
  console.log(JSON.stringify(out, null, 2));
} finally {
  clearTimeout(hard);
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  finish(0);
}
