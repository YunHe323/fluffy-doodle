# GitHub 开源采用清单（T50）

> 调研日期：**2026-11-06**（Asia/Shanghai）· owner：intel-scout · 状态：扫描稿（供 tech-architect 复核建任务）
> 数据来源：`api.github.com`（stars / pushed_at / license / repo size）、`registry.npmjs.org`（version / license / unpackedSize / dependencies / last-week downloads）、`pypi.org`（Python 版本 / 依赖数）、`raw.githubusercontent.com`（LICENSE 原文核验）。
> 口径：版本=发布 tag（npm `latest` / PyPI / GitHub release）；stars 与 pushed_at 为 2026-11-06 快照；周下载=最近 7 天（api.npmjs.org）；`unpacked`=npm 包解压后体积；`repo`=GitHub 仓库体积（KB）。
> **人日为估算（±50%），不是承诺**，需 tech-architect 按实际代码量复核；**本次未安装/未下载任何包，未改任何代码**。

---

## 0. 结论速览

- **值得立即采用（低风险高收益）**：perfect-freehand、playwright-core、Comlink、ag-psd（已用，补许可动作）。
- **值得做原型（服务端/后端，不进前端）**：SAM、rembg、diffusers、Real-ESRGAN。
- **只参考、不采用代码**：tldraw（自定义许可）、ComfyUI（GPL-3.0）、Excalidraw 整包（体积/依赖不划算）。
- **许可红线上没有灰色地带**：MIT/BSD/Apache-2.0 可移植（保留版权/通知）；GPL/AGPL 不嵌入；tldraw 非标准许可不采用代码。
- **与 T49 已产出的 [`06-技术/开源杠杆清单.md`](开源杠杆清单.md) 不重复**：T49 已写清 Klecks/CanvasKit/ag-psd 的**已落地**复用与人日节省；本清单负责"候选池 + 版本/许可/活跃度核验 + Top 5"，二者是"已采用台账"与"候选清单"的关系。T49 的原则「**不引入运行时第三方依赖**（CanvasKit/ag-psd 除外，已 vendor）」继续有效：本清单中 **Comlink 属运行时依赖，采用前须 Lead/tech-architect 批准**；SAM/rembg/diffusers/Real-ESRGAN 属服务端/独立服务，不受该原则限制。

---

## 1. 许可红线（执行规则）

| 类别 | 项目 | 允许动作 | 必须动作 | 禁止动作 |
|---|---|---|---|---|
| **MIT / BSD-3 / ISC** | perfect-freehand, excalidraw, fabric, konva, ag-psd, UPNG, UTIF, vite, fflate, culori, bezier-js, idb, rembg, Klecks | 移植、嵌入、修改、商用 | 保留版权声明与许可全文；写入 `THIRD_PARTY_NOTICES`；BSD-3 不得用作者名背书 | 移除版权头；用作者名做推广 |
| **Apache-2.0** | playwright-core, puppeteer-core, comlink, diffusers, SAM | 移植、嵌入、修改、商用 | 保留 LICENSE + **NOTICE**（如有）；修改文件注明；专利授权条款随附 | 移除 NOTICE；暗示作者背书 |
| **GPL-3.0** | **ComfyUI** | 阅读代码/文档、参考架构 | 若真的要用：独立进程/服务 + HTTP 调用，并先做法务确认 | **不复制、不修改、不链接进产品**；不随产品分发 |
| **自定义/非标准** | **tldraw**（npm `SEE LICENSE IN LICENSE.md`；GitHub `NOASSERTION`） | 阅读思路、看交互 | — | **不采用任何代码**：其许可明确"不得用于生产环境、不得禁用 License Key、不得作为独立产品分发"（生产需商业授权） |

**额外易踩的坑（已在各项风险列注明）**：
1. **库许可 ≠ 素材/权重的许可**：ag-psd 仓库内图片/笔刷文件不在 MIT 范围；diffusers 是 Apache-2.0，但它加载的模型权重（SDXL/FLUX 等）各有独立条款；rembg 会下载的 u2net/isnet 等权重需逐个核验。
2. **传递依赖也要查**：Excalidraw 的 31 个依赖（pako/roughjs/pica 等）多为 MIT，但引入即增加审计面。
3. **GitHub 自动识别可能误报**：Konva、ag-psd 的 GitHub license 字段为 `NOASSERTION/Other`，但**仓库 LICENSE 原文是标准 MIT**（已读原文核验）；以 LICENSE 原文为准。

---

## 2. 模块扫描（逐项）

### 2.1 画布 / 笔迹

| 项目 | 仓库 / 版本 | 许可 | 活跃度 | 体积 | 依赖 | 可复用模块 | 接入人日 | 风险 | 建议 |
|---|---|---|---|---|---|---|---|---|---|
| **perfect-freehand** | [steveruizok/perfect-freehand](https://github.com/steveruizok/perfect-freehand) · npm **1.2.3** | **MIT** | 5,804★；最近提交 **2026-04-13**；周下载 **422.9 万** | unpacked **112 KB**（27 文件） | **0** | `getStroke(points, opts)`：压感笔迹**轮廓**生成；pressure/size/thinning/smoothing/streamline/taper 参数；输入点平滑 | **0.5–1.5** | 只生成轮廓，不负责渲染/合批/擦除；2026-04 后无提交（API 稳定但维护低频）；需自己做压感映射与 Canvas 填充 | **采用**（对应 T52） |
| **Excalidraw** | [excalidraw/excalidraw](https://github.com/excalidraw/excalidraw) · npm `@excalidraw/excalidraw` **0.18.1** | **MIT** | 135,238★；最近提交 **2026-11-06**；周下载 131.9 万 | unpacked **44.6 MB**（1,029 文件） | **31 个**（clsx、pako、pica、roughjs、jotai、perfect-freehand…） | 交互范式（工具切换/选择/撤销栈）、元素模型与历史记录设计、协作/持久化思路、UI 参考 | 整包 3–5；仅参考 **0.5–1** | 包体/依赖重、风格与产品不一致；嵌入后升级/安全审计成本高；MIT 需署名 | **仅参考，不整包引入** |
| **tldraw** | [tldraw/tldraw](https://github.com/tldraw/tldraw) · npm `@tldraw/tldraw` **5.6.0** | **自定义（tldraw license）** | 51,300★；最近提交 2026-11-06 | unpacked 106 KB（12 文件）；repo **1.6 GB** | 1（`tldraw` 元包） | 交互/画布架构思路可读 | 参考 0.5（不写码） | **生产环境需商业授权；禁止禁用 License Key；禁止独立分发**；法务风险最高 | **不采用代码（红线）** |
| **fabric.js** | [fabricjs/fabric.js](https://github.com/fabricjs/fabric.js) · npm `fabric` **7.4.0** | **MIT** | 31,547★；最近提交 2026-11-05；周下载 132.0 万 | unpacked **21.2 MB**（2,410 文件） | **0**（运行时） | 对象模型/图层/选择变换/滤镜/序列化（canvas JSON） | 2–4（若替换场景图） | 与我们"直接绘 stamp"的路径不同；引入对象系统=架构改造；体积大 | **备选**（仅在需要对象化编辑阶段评估） |
| **konva** | [konvajs/konva](https://github.com/konvajs/konva) · npm `konva` **10.9.1** | **MIT**（README/LICENSE 原文核验；GitHub 识别为 Other 属误报） | 14,918★；最近提交 2026-11-05；周下载 **400.0 万** | unpacked **1.8 MB**（129 文件） | **0** | 场景图/图层/命中检测/事件/性能分层 | 1.5–3（若替换） | 与 stamp 直绘路径有重叠；迁移会动渲染核心（接口变更需先报 Lead） | **备选**（当前不换） |

### 2.2 自动化测试

| 项目 | 仓库 / 版本 | 许可 | 活跃度 | 体积 | 依赖 | 可复用模块 | 接入人日 | 风险 | 建议 |
|---|---|---|---|---|---|---|---|---|---|
| **playwright-core** | [microsoft/playwright](https://github.com/microsoft/playwright) · npm `playwright-core` **1.65.0** | **Apache-2.0** | 99,447★；最近提交 **2026-11-06**；周下载 **1.83 亿** | unpacked **13.3 MB**（116 文件） | **0** | 浏览器自动化：headless、自动等待、截图、超时、并行、tracing；`channel:'msedge'` 可复用本机 Edge（无需下载浏览器） | **0.5–1.5** | Apache NOTICE；只放 devDependencies；本机 Edge 版本与 Playwright 兼容性需锁定 | **采用**（对应 T51） |
| **puppeteer-core** | [puppeteer/puppeteer](https://github.com/puppeteer/puppeteer) · npm `puppeteer-core` **25.16.0** | **Apache-2.0** | 95,805★；最近提交 2026-11-06；周下载 3,233.6 万 | unpacked **5.8 MB**（927 文件） | **7**（ws、chromium-bidi、devtools-protocol、@puppeteer/browsers…） | CDP 直连、截图、多页控制 | 1–2 | 依赖比 Playwright 多；API 更底层；能力与 Playwright 重叠 | **备选**（Playwright 优先，够用即不引入） |

### 2.3 PSD / 图像

| 项目 | 仓库 / 版本 | 许可 | 活跃度 | 体积 | 依赖 | 可复用模块 | 接入人日 | 风险 | 建议 |
|---|---|---|---|---|---|---|---|---|---|
| **ag-psd**（已用） | [Agamnentzar/ag-psd](https://github.com/Agamnentzar/ag-psd) · npm **34.1.0**；**项目当前 vendor 版本 28.3.1**（见 T49 清单） | **MIT**（LICENSE 原文核验；注意仓库内图片/笔刷文件不在 MIT 范围；CMYK 系数来自 pdf.js，**Apache-2.0**） | 740★；最近提交 2026-10-28；周下载 51.7 万 | unpacked **17.2 MB**（3,673 文件） | **2**（pako、base64-js） | PSD 读/写：图层、文字、混合模式、合成预览 | 已用；补许可 **0.5** | 包体大（建议按需子路径引入）；PSD 特性覆盖有限；**NOTICE 需含 pako/base64-js/pdf.js-Apache**；**vendor 28.3.1 → 34.1.0 升级需单独评估（不要在 T39 稳定后擅自升级）** | **维持采用 + 补合规动作** |
| **UPNG.js** | [photopea/UPNG.js](https://github.com/photopea/UPNG.js) · npm `upng-js` **2.1.0** | **MIT** | 2,222★；最近提交 **2023-07-28（停更 3 年+）**；周下载 53.6 万 | npm 未报 unpackedSize（旧发布）；repo 112 KB | **1**（pako） | PNG 编解码/量化/无损压缩（Worker 内导出可用） | 0.5–1 | 停更；纯 JS 速度慢；PNG 变体/元数据需自测 | **按需采用**（导出编码场景，优先级低于浏览器原生编码） |
| **UTIF.js** | [photopea/UTIF.js](https://github.com/photopea/UTIF.js) · npm `utif` **3.1.0** | **MIT** | 503★；最近提交 2026-05-04；周下载 191.3 万 | unpacked **62.5 KB**（4 文件） | **1**（pako） | TIFF 解码（扫描稿/摄影素材导入） | 0.5–1 | 功能窄、TIFF 变体多；仅解码 | **按需采用**（导入格式扩展时） |

### 2.4 Worker / 构建

| 项目 | 仓库 / 版本 | 许可 | 活跃度 | 体积 | 依赖 | 可复用模块 | 接入人日 | 风险 | 建议 |
|---|---|---|---|---|---|---|---|---|---|
| **Comlink** | [GoogleChromeLabs/comlink](https://github.com/GoogleChromeLabs/comlink) · npm **4.4.2** | **Apache-2.0** | 12,806★；最近提交 **2026-11-05**；周下载 408.1 万 | unpacked **246 KB**（82 文件） | **0** | Worker RPC（proxy 化 postMessage）；把反解/编码/解码搬离主线程 | **1–2** | Apache NOTICE；结构化克隆限制（不能传函数/类实例）；调试链路变长 | **采用**（Worker 化优先；本项为推荐，无对应任务号） |
| **Vite** | [vitejs/vite](https://github.com/vitejs/vite) · npm `vite` **8.3.6** | **MIT** | 83,776★；最近提交 2026-11-06；周下载 **2.58 亿** | unpacked **2.3 MB**（37 文件） | 5（postcss、rolldown、picomatch、tinyglobby、lightningcss） | dev server/HMR/构建；现代打包 | 2–4（迁移成本） | 构建链变更风险；浏览器 target/插件生态需配置；当前无强需求 | **备选**（不急于迁移） |

### 2.5 AI 侧（只做备选 / 接口预留；不进前端、不嵌产品）

| 项目 | 仓库 / 版本 | 许可 | 活跃度 | 体积 | 依赖 | 可复用模块 | 接入人日 | 风险 | 建议 |
|---|---|---|---|---|---|---|---|---|---|
| **diffusers** | [huggingface/diffusers](https://github.com/huggingface/diffusers) · PyPI **0.42.1**（2026-10-27） | **Apache-2.0** | 34,880★；最近提交 2026-11-06 | PyPI 依赖元数据 **91 项**（含 extras）；repo 112.7 MB | Python ≥3.11 | 推理管线/调度器/量化/本地服务原型；作为"反解/生成"后端候选 | 原型 3–5；仅接口预留 0.5 | **模型权重许可 ≠ 库许可**；Python 依赖重；GPU 成本/延迟 | **备选**（服务端原型；不在前端/产品内嵌） |
| **ComfyUI** | [comfyanonymous/ComfyUI](https://github.com/comfyanonymous/ComfyUI) · release **v0.44.0**（2026-11-04） | **GPL-3.0** | 145,370★；最近提交 2026-11-06 | repo 103.6 MB | 独立 Python 服务 | 节点/工作流编排**思路**、模型管线参考 | 参考 0.5–1 | **GPL 传染性**；嵌入=产品整体需 GPL 兼容（不可接受） | **只参考，不嵌入**（红线） |
| **Real-ESRGAN** | [xinntao/Real-ESRGAN](https://github.com/xinntao/Real-ESRGAN) · release **v0.3.0**（2022-09-20） | **BSD-3-Clause** | 37,386★；最近提交 **2024-08-06（停更约 2 年）** | repo 5.4 MB | Python + PyTorch + BasicSR(Apache-2.0) | 超分（素材修复/导出增强） | 1–2（独立服务） | 停更；依赖旧版 PyTorch/CUDA；**权重许可需核实** | **按需**（后处理可选） |
| **SAM（segment-anything）** | [facebookresearch/segment-anything](https://github.com/facebookresearch/segment-anything) · **无 release/tag（按 commit 锁定）** | **Apache-2.0** | 55,100★；最近提交 **2024-09-18（停更约 2 年）** | repo 18.3 MB | Python + PyTorch | **区域分割**：点/框提示出 mask → L2 区域档案自动锚定；抠图/图层分解 | **2–4（PoC 服务）** | 仓库停更；权重许可需核实（官方 checkpoint 需逐个确认）；推理重/GPU 成本；建议后续评估更新的分割模型 | **原型采用**（L2 区域锚定 PoC） |
| **rembg** | [danielgatis/rembg](https://github.com/danielgatis/rembg) · PyPI **2.0.87** | **MIT** | 25,360★；最近提交 **2026-11-06**；0 open issues | repo 87.5 MB；依赖元数据 31 项 | Python ≥3.11,<4 | 抠图/前景分离（图层分解 PoC）；批量素材预处理 | 1–2 | **内置模型权重许可逐个不同**（u2net/isnet 等）；CPU 推理慢；质量依模型 | **原型采用**（图层分解 PoC） |

### 2.6 其他高价值（颜色/几何/压缩/存储）

| 项目 | 仓库 / 版本 | 许可 | 活跃度 | 体积 | 依赖 | 可复用模块 | 接入人日 | 风险 | 建议 |
|---|---|---|---|---|---|---|---|---|---|
| **bezier-js** | [pomax/bezierjs](https://github.com/pomax/bezierjs) · npm **6.1.4** | MIT | 1,873★；最近提交 2024-08-04；周下载 175.7 万 | unpacked 116 KB | 0 | 贝塞尔求值/分割/投影/包围盒（笔刷几何、路径简化） | 0.5 | 维护低频；仅几何工具 | **按需采用** |
| **fflate** | [101arrowz/fflate](https://github.com/101arrowz/fflate) · npm **0.8.3** | MIT | 3,081★；最近提交 2026-05-16；周下载 **1.52 亿** | unpacked 778 KB | 0 | 压缩/解压（证据包 zip、素材归档） | 0.5–1 | 与 UPNG/pako 功能重叠，选一个即可 | **按需采用** |
| **culori** | [Evercoder/culori](https://github.com/Evercoder/culori) · npm **4.0.2** | MIT | 1,251★；最近提交 2026-11-04；周下载 616.8 万 | unpacked 1.06 MB | 0 | 色彩空间转换/取色/对比度（色板、调色） | 0.5 | 体积略大；纯前端 | **按需采用** |
| **idb** | [jakearchibald/idb](https://github.com/jakearchibald/idb) · npm **8.0.4** | **ISC** | 7,434★；最近提交 2026-10-06；周下载 **3,590.3 万** | unpacked 80.6 KB | 0 | IndexedDB Promise 封装（本地档案/素材库存储、离线） | 0.5–1 | 无重大风险；注意浏览器存储配额 | **按需采用**（本地优先档案存储候选） |

> 已用项目补充：**Klecks**（[bitbof/klecks](https://github.com/bitbof/klecks)，MIT，390★，2026-10-20）由 T49 单独负责移植，本清单不重复调研、不重复排期。

---

## 3. Top 5 采用建议（可直接建任务）

| 优先级 | 项目（版本/许可） | 落到模块 / owner | 能省什么（估算） | 接入人日 | 必须的许可动作 | 主要风险 |
|---|---|---|---|---|---|---|
| **P0** | **perfect-freehand 1.2.3（MIT）** | 笔迹/画布 → `v2/brushes`（**T52**，owner：`brush-engineer`） | 自研"贝塞尔插值 + 带压感轮廓 + taper/streamline"约 **3–5 人日**，且质量调参风险转移给成熟库（T49 认可 2–3 pd） | 0.5–1.5 | vendor 保留 MIT 头；写入 `THIRD_PARTY_NOTICES` | 维护低频；仅轮廓不渲染 |
| **P0** | **playwright-core 1.65.0（Apache-2.0）** | QA 自动化 → **T51**，owner：`qa-engineer` | 替代手写 CDP harness 的反复修 bug 与维护约 **3–5 人日**（含截图/等待/超时/并行/Edge channel；T49 认可 1–2 pd） | 0.5–1.5 | 保留 LICENSE+NOTICE；仅 devDependencies | 本机 Edge 版本兼容 |
| **P1** | **ag-psd 34.1.0（MIT，已用）→ 补合规 + 瘦身** | 素材导入 / 图像模块 → 与 **T49/T39** 对齐（owner：`tech-architect`） | 已省自研 PSD 解析 **10+ 人日**（T49 计 3–4 pd）；本次动作：补 NOTICE（pako/base64-js/pdf.js Apache）、按需子路径引入（**17.2 MB unpacked** 可显著缩减）；vendor 28.3.1 暂不升级 | 0.5 | MIT 版权头 + pdf.js Apache NOTICE | 包体大；PSD 特性覆盖有限；升级风险 |
| **P1** | **SAM（Apache-2.0，commit 锁定）** | AI/区域分割 → `tech-architect`（服务端 PoC，不进前端） | 自研分割/训练约 **5–8 人日**；为 L2 区域档案提供"区域自动锚定"PoC | 2–4（PoC 服务） | Apache NOTICE；**权重许可单独核实** | 仓库 2024-09 停更；GPU 成本 |
| **P2** | **Comlink 4.4.2（Apache-2.0）** | 前端/WASM 管线 → `tech-architect`（**运行时依赖：采用前须批准**） | 自研 Worker RPC/序列化协议约 **1–2 人日**，并为反解/编码解码搬离主线程铺路 | 1–2 | Apache NOTICE | 违反 T49「不引入运行时依赖」现原则，需决策；结构化克隆限制 |

**不排进 Top 5 的理由**：
- Excalidraw / fabric / konva：能力有重叠但会动渲染核心（风险 > 收益），且当前 stamp 直绘路径已可工作；进入"对象化编辑"阶段再评估。
- ComfyUI：GPL-3.0，只读思路。
- Real-ESRGAN / rembg / diffusers：属于"能力备选"，MVP 阶段用 API 更划算；做本地化/成本优化时再上。
- UPNG/UTIF/fflate/culori/idb/bezier-js：小工具，按需接入（每项 ≤1 人日）。

---

## 4. 不采用清单（明确写死，防止后人误引）

| 项目 | 不采用的原因 |
|---|---|
| **tldraw**（所有包） | 自定义许可：**不得用于生产环境**（无商业授权时）、不得禁用 License Key、不得作为独立产品分发；生产需付费授权 → **不采用任何代码**，仅可阅读交互思路 |
| **ComfyUI** | **GPL-3.0**：复制/修改/链接进产品会触发传染性；只能"独立服务 + HTTP"并需法务确认 → **不嵌入、不随产品分发** |
| **Excalidraw 整包** | MIT 但 unpacked **44.6 MB / 31 个依赖 / 1,029 文件**，且其交互范式（白板+协作）与我们的绘画画布不同 → 只参考交互与元素模型，不整包引入 |
| **fabric / konva 替换现渲染** | 两者都是 MIT 的成熟场景图库，但替换会触及渲染核心（接口变更需先报 Lead），当前收益不足 → 保留备选，不立即替换 |

---

## 5. 与 T49 / T51 / T52 的对接（避免重复调研）

| 任务 | 关系 | 本清单提供什么 |
|---|---|---|
| **T49 Klecks 移植** | 已用（MIT，[bitbof/klecks](https://github.com/bitbof/klecks)，390★，2026-10-20）；T49 已落地 present/整帧 blit、tile undo 增强、LineSmoothing，共省 4.5–7 人日 | 本清单不重复调研 Klecks；T49 的已采用台账见 [`开源杠杆清单.md`](开源杠杆清单.md)，本清单只负责候选池与许可红线统一要求 |
| **T51 Playwright-core 迁移** | 本清单 **P0** 项 | 版本 1.65.0 / Apache-2.0 / 0 依赖 / Edge channel / 许可动作均已核；直接执行，无需再调研 |
| **T52 perfect-freehand 集成** | 本清单 **P0** 项 | 版本 1.2.3 / MIT / 112 KB / 0 依赖 / 4,229,581 周下载 / 参数清单均已核；直接执行 |
| 未来的 Worker 化 / 区域分割 PoC | 本清单 P2/P1 项 | Comlink、SAM 的版本与风险已核，可直接建任务 |

---

## 6. 数据快照（2026-11-06，供复核）

**npm 包（registry.npmjs.org `latest` + api.npmjs.org last-week）**

| 包 | 版本 | 许可 | unpacked | 文件数 | 运行时依赖数 | 周下载 |
|---|---|---|---|---|---|---|
| perfect-freehand | 1.2.3 | MIT | 112,085 B | 27 | 0 | 4,229,581 |
| @excalidraw/excalidraw | 0.18.1 | MIT | 46,802,783 B | 1,029 | 31 | 1,319,046 |
| @tldraw/tldraw | 5.6.0 | SEE LICENSE IN LICENSE.md | 108,439 B | 12 | 1 | 217,934 |
| fabric | 7.4.0 | MIT | 22,222,881 B | 2,410 | 0 | 1,320,034 |
| konva | 10.9.1 | MIT | 1,910,939 B | 129 | 0 | 3,999,691 |
| playwright-core | 1.65.0 | Apache-2.0 | 13,969,978 B | 116 | 0 | 182,744,290 |
| puppeteer-core | 25.16.0 | Apache-2.0 | 6,125,330 B | 927 | 7 | 32,335,618 |
| ag-psd | 34.1.0 | MIT | 18,054,547 B | 3,673 | 2 | 517,295 |
| upng-js | 2.1.0 | MIT | (未报) | — | 1 | 536,006 |
| utif | 3.1.0 | MIT | 63,999 B | 4 | 1 | 1,912,816 |
| comlink | 4.4.2 | Apache-2.0 | 252,242 B | 82 | 0 | 4,081,231 |
| vite | 8.3.6 | MIT | 2,377,714 B | 37 | 5 | 257,763,016 |
| bezier-js | 6.1.4 | MIT | 119,160 B | 8 | 0 | 1,756,879 |
| fflate | 0.8.3 | MIT | 796,742 B | 17 | 0 | 151,660,913 |
| culori | 4.0.2 | MIT | 1,108,305 B | 168 | 0 | 6,167,797 |
| idb | 8.0.4 | ISC | 82,588 B | 13 | 0 | 35,903,202 |

**GitHub 仓库（api.github.com/repos）**

| 仓库 | Stars | 最近提交 | License(API) | Repo size |
|---|---|---|---|---|
| steveruizok/perfect-freehand | 5,804 | 2026-04-13 | MIT | 2,366 KB |
| excalidraw/excalidraw | 135,238 | 2026-11-06 | MIT | 109,133 KB |
| tldraw/tldraw | 51,300 | 2026-11-06 | NOASSERTION(Other) | 1,628,636 KB |
| fabricjs/fabric.js | 31,547 | 2026-11-05 | MIT | 262,365 KB |
| konvajs/konva | 14,918 | 2026-11-05 | NOASSERTION(Other) → **LICENSE 原文 MIT** | 24,280 KB |
| microsoft/playwright | 99,447 | 2026-11-06 | Apache-2.0 | 247,164 KB |
| puppeteer/puppeteer | 95,805 | 2026-11-06 | Apache-2.0 | 1,609,087 KB |
| Agamnentzar/ag-psd | 740 | 2026-10-28 | NOASSERTION(Other) → **LICENSE 原文 MIT** | 43,004 KB |
| photopea/UPNG.js | 2,222 | **2023-07-28** | MIT | 112 KB |
| photopea/UTIF.js | 503 | 2026-05-04 | MIT | 682 KB |
| GoogleChromeLabs/comlink | 12,806 | 2026-11-05 | Apache-2.0 | 2,152 KB |
| vitejs/vite | 83,776 | 2026-11-06 | MIT | 77,495 KB |
| huggingface/diffusers | 34,880 | 2026-11-06 | Apache-2.0 | 115,368 KB |
| comfyanonymous/ComfyUI | 145,370 | 2026-11-06 | **GPL-3.0** | 106,072 KB |
| xinntao/Real-ESRGAN | 37,386 | **2024-08-06** | BSD-3-Clause | 5,514 KB |
| facebookresearch/segment-anything | 55,100 | **2024-09-18** | Apache-2.0 | 18,751 KB |
| danielgatis/rembg | 25,360 | 2026-11-06 | MIT | 89,581 KB |
| pomax/bezierjs | 1,873 | 2024-08-04 | MIT | 3,824 KB |
| 101arrowz/fflate | 3,081 | 2026-05-16 | MIT | 4,030 KB |
| Evercoder/culori | 1,251 | 2026-11-04 | MIT | 6,349 KB |
| jakearchibald/idb | 7,434 | 2026-10-06 | ISC | 536 KB |
| bitbof/klecks | 390 | 2026-10-20 | MIT | 8,021 KB |

**Python（PyPI + GitHub release）**：diffusers **0.42.1**（2026-10-27，Apache-2.0，requires Python ≥3.11，依赖元数据 91 项）；rembg **2.0.87**（MIT，Python ≥3.11,<4，依赖元数据 31 项）；ComfyUI release **v0.44.0**（2026-11-04）；Real-ESRGAN release **v0.3.0**（2022-09-20）；SAM **无 release/tag**（需按 commit 锁定）。

---

## 7. 复核方法（tech 可复跑）

```powershell
# npm 元数据
Invoke-RestMethod "https://registry.npmjs.org/perfect-freehand/latest" | ConvertTo-Json -Depth 3
# npm 周下载
Invoke-RestMethod "https://api.npmjs.org/downloads/point/last-week/perfect-freehand"
# GitHub 仓库（stars/许可/最近提交）
Invoke-RestMethod "https://api.github.com/repos/steveruizok/perfect-freehand" -Headers @{'User-Agent'='x'}
# 许可原文（核验 API 误报，如 konva/ag-psd）
Invoke-RestMethod "https://raw.githubusercontent.com/konvajs/konva/master/LICENSE"
# Python
Invoke-RestMethod "https://pypi.org/pypi/diffusers/json"
```

**注意**：
1. `api.github.com` 未认证限流 60 次/小时，批量扫描时注意；
2. npm 的 `latest` 是发布 tag，不代表主分支 HEAD；**移植/引入以发布版为准**；
3. 任何"许可原文"以仓库 LICENSE 文件为准，GitHub 自动识别（`NOASSERTION`/`Other`）可能误报；
4. 引入任何包前，先更新 `THIRD_PARTY_NOTICES.md`（含：名称、版本、许可、来源 URL、版权声明、是否修改）。
