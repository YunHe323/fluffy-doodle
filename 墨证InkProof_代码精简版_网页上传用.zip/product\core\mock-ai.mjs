// product/core/mock-ai.mjs
// 确定性 Mock AI：零依赖、跨运行时（浏览器 + Node 22+）、无任何网络调用。
// 同一输入 → 同一输出（用于离线开发、单测与前端降级）。
// 形状对齐：product/CONTRACT.md §2.2–2.4；档案字段对齐 06-技术/数据模型_schema.json v0.2.0（L1/L2/L4）。

export const MOCK_MODEL = 'mock-ai@0.1.0';
export const MOCK_VERSION = '0.1.0';

// ---------- 确定性随机 ----------

function fnv1a(str, seed) {
  let h = seed >>> 0;
  for (let i = 0; i < str.length; i += 1) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

function digestOf(str) {
  const h1 = fnv1a(str, 0x811c9dc5);
  const h2 = fnv1a(str, 0x9e3779b9);
  const h3 = fnv1a(`#${h1}:${h2}`, 0x85ebca6b);
  return `${h1.toString(16).padStart(8, '0')}${h2.toString(16).padStart(8, '0')}${h3.toString(16).padStart(8, '0')}`;
}

function mulberry32(seed) {
  let a = seed >>> 0;
  return function rng() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeRng(material) {
  const digest = digestOf(material);
  const seed = parseInt(digest.slice(0, 8), 16) ^ parseInt(digest.slice(8, 16), 16);
  return { digest, rng: mulberry32(seed) };
}

const pick = (rng, arr) => arr[Math.floor(rng() * arr.length) % arr.length];
const round2 = (n) => Math.round(n * 100) / 100;
const clampInt = (n, min, max) => Math.max(min, Math.min(max, Math.round(n)));

// ---------- 输入规范化 ----------

function normalizeSelection(selection, canvas) {
  const W = canvas.width;
  const H = canvas.height;
  if (!selection || typeof selection !== 'object') {
    return { x: 0, y: 0, width: W, height: H };
  }
  if (selection.mode === 'rect' && selection.rect && typeof selection.rect === 'object') {
    const r = selection.rect;
    const x = clampInt(Number(r.x) || 0, 0, Math.max(0, W - 1));
    const y = clampInt(Number(r.y) || 0, 0, Math.max(0, H - 1));
    const width = clampInt(Number(r.width) || W, 1, Math.max(1, W - x));
    const height = clampInt(Number(r.height) || H, 1, Math.max(1, H - y));
    return { x, y, width, height };
  }
  if (selection.mode === 'mask' && typeof selection.maskDataUrl === 'string') {
    // mock 不解析像素：仅在种子中加入掩码摘要，锚点仍用全画布
    return { x: 0, y: 0, width: W, height: H, maskDigest: digestOf(selection.maskDataUrl) };
  }
  return { x: 0, y: 0, width: W, height: H };
}

function normalizeInput(input, { needDirection = false } = {}) {
  if (!input || typeof input !== 'object') throw new TypeError('mock-ai: 输入必须是对象');
  const canvas = input.canvas;
  if (!canvas || typeof canvas !== 'object') throw new TypeError('mock-ai: 缺少 canvas');
  const dataUrl = typeof canvas.dataUrl === 'string' ? canvas.dataUrl : '';
  const width = clampInt(Number(canvas.width) || 1024, 1, 8192);
  const height = clampInt(Number(canvas.height) || 768, 1, 8192);
  const context = input.context && typeof input.context === 'object' ? input.context : {};
  const selection = normalizeSelection(input.selection, { width, height });
  const material = [
    'mock-ai.v1',
    dataUrl,
    `${width}x${height}`,
    `${selection.x},${selection.y},${selection.width},${selection.height}`,
    selection.maskDigest ? `mask:${selection.maskDigest}` : 'mask:none',
    `mode:${typeof context.mode === 'string' ? context.mode : 'collab'}`,
    `role:${typeof context.aiRole === 'string' ? context.aiRole : 'assistant'}`,
    `note:${typeof context.userNote === 'string' ? context.userNote.slice(0, 500) : ''}`,
    needDirection ? `direction:${input.directionId ?? ''}` : '',
    `count:${Number(input.count) || 0}`,
    `size:${input.size ? `${input.size.width}x${input.size.height}` : ''}`,
    `obs:${Array.isArray(input.observationIds) ? input.observationIds.slice(0, 10).join(',') : ''}`,
  ].join('|');
  return { canvas: { dataUrl, width, height }, selection, context, material };
}

// ---------- 文本素材库（固定，保证确定性） ----------

const REGION_LABELS = [
  '袖口褶皱', '面部结构', '冷调阴影', '背景留白', '笔触交界', '高光区',
  '主体轮廓', '色块过渡', '画面下缘', '负空间区域',
];
const OBSERVATION_TEMPLATES = [
  '这里的笔触有明显的停顿，和画面其他部分的流畅不协调，可能是下意识犹豫留下的。',
  '这块颜色的明度比周围低半档，看起来像被刻意压暗，能稳住整体重心。',
  '边缘的处理没收干净，反而留下了一点呼吸感；如果补完可能变精致，但也会少一点活性。',
  '这个区域的细节密度明显高于画面其他部分，视线会第一时间被吸过去。',
  '阴影里混了一点偏暖的色，和整体冷调形成了很小的冲突，但不算错。',
  '构图上这里留白偏少，主体有点贴边，往外让两像素可能会更舒服。',
  '轮廓线有一段断开了，可能是未完成，也可能是有意的透气处理。',
  '这一块的结构转折偏软，体积感被压平了；如果加一道更硬的转折会更立体。',
  '色彩温度在这里跳了一下，暖色比例突然升高，需要确认是不是有意为之。',
  '笔刷方向与周围不一致，形成了轻微的纹理冲突，可以保留作为趣味点。',
];
const DIRECTION_BANK = [
  { title: '让光更冷一点', why: '当前暗部偏暖，与冷调环境冲突（依据 L1.palette）', tags: ['light', 'palette'] },
  { title: '保留粗糙笔触，只补结构', why: '观察提到边缘笔触是有意保留的，先补体积再谈干净', tags: ['texture', 'structure'] },
  { title: '把主体往外让一点', why: '选区贴着画布边缘，构图上负空间不足', tags: ['composition'] },
  { title: '提高一块区域的对比度', why: '细节密度最高的区域缺少明度对比，视线落不住', tags: ['value'] },
  { title: '统一笔刷方向', why: '相邻区域笔刷方向冲突，纹理上会显得琐碎', tags: ['texture'] },
  { title: '加一笔暖色高光', why: '冷调画面缺少暖色锚点，加一点能提亮整体', tags: ['color', 'accent'] },
];
const MOOD_BANK = ['安静', '克制', '怀旧', '松弛', '紧张', '温柔', '清冷', '潮湿'];
const SUBJECT_BANK = ['人物', '衣物褶皱', '街道', '光斑', '静物', '手', '侧脸轮廓', '背景'];
const MEDIUM_BANK = [
  { kind: 'digital_painting', detail: '厚涂，局部保留草稿线' },
  { kind: 'watercolor', detail: '湿画法晕染，纸纹可见' },
  { kind: 'pencil', detail: '铅笔排线，明暗过渡柔和' },
  { kind: 'mixed', detail: '线稿 + 色块叠涂' },
];
const PALETTE_BANK = ['#2e3a48', '#c9a66b', '#7a8fa6', '#8a6f5c', '#d9d2c5', '#3f5a54', '#b46a55', '#5b4b63'];
const SUMMARY_BANK = [
  '画布以冷灰蓝为主调的未完成人物速写',
  '偏暖色块与冷色阴影交错的半成品插画',
  '笔触松弛的日常速写，细节集中在中部',
  '以留白和轻线条为主的草稿阶段画面',
];

// ---------- 输出构造 ----------

function makeRegions(rng, selection) {
  const count = 1 + Math.floor(rng() * 3); // 1–3
  const regions = [];
  for (let i = 0; i < count; i += 1) {
    const ratioW = 0.25 + rng() * 0.45;
    const ratioH = 0.25 + rng() * 0.45;
    const w = clampInt(selection.width * ratioW, 8, selection.width);
    const h = clampInt(selection.height * ratioH, 8, selection.height);
    const maxX = selection.x + selection.width - w;
    const maxY = selection.y + selection.height - h;
    const x = clampInt(selection.x + rng() * Math.max(1, selection.width - w), selection.x, Math.max(selection.x, maxX));
    const y = clampInt(selection.y + rng() * Math.max(1, selection.height - h), selection.y, Math.max(selection.y, maxY));
    const id = `L2-mock-${String(i + 1).padStart(3, '0')}`;
    regions.push({
      id,
      label: pick(rng, REGION_LABELS),
      confidence: round2(0.55 + rng() * 0.4),
      bbox: [x, y, w, h],
      importance: round2(0.45 + rng() * 0.5),
      anchor: { type: 'bbox', value: [x, y, w, h] },
    });
  }
  return regions;
}

function makeObservations(rng, regions) {
  const count = 2 + Math.floor(rng() * 3); // 2–4
  const observations = [];
  for (let i = 0; i < count; i += 1) {
    const region = regions[i % regions.length];
    observations.push({
      id: `L4-mock-${String(i + 1).padStart(3, '0')}`,
      layer: 'L4',
      kind: rng() > 0.82 ? 'association' : 'observation',
      source: 'inferred',
      author: 'ai',
      confidence: round2(0.5 + rng() * 0.45),
      text: pick(rng, OBSERVATION_TEMPLATES),
      anchor: { type: 'bbox', value: [...region.bbox] },
      evidenceRefs: [region.id],
      modelVersion: MOCK_MODEL,
    });
  }
  return observations;
}

function makeGlobal(rng) {
  const palette = [];
  const used = new Set();
  const count = 2 + Math.floor(rng() * 2); // 2–3
  while (palette.length < count) {
    const hex = pick(rng, PALETTE_BANK);
    if (used.has(hex)) continue;
    used.add(hex);
    palette.push({ hex, weight: round2(0.15 + rng() * 0.4) });
  }
  const medium = pick(rng, MEDIUM_BANK);
  return {
    summary: pick(rng, SUMMARY_BANK),
    subject: [pick(rng, SUBJECT_BANK), pick(rng, SUBJECT_BANK)].filter((v, i, a) => a.indexOf(v) === i),
    medium: { kind: medium.kind, detail: medium.detail },
    palette,
    mood: [pick(rng, MOOD_BANK), pick(rng, MOOD_BANK)].filter((v, i, a) => a.indexOf(v) === i),
  };
}

// ---------- 公开 API ----------

/**
 * 选区理解（mock 反解）：返回 L1 子集 + L2 + L4。
 * @param {object} input 见 CONTRACT.md §2.2
 */
export function mockAnalyze(input) {
  const { selection, material } = normalizeInput(input);
  const { rng, digest } = makeRng(material);
  const regions = makeRegions(rng, selection);
  const observations = makeObservations(rng, regions);
  const global = makeGlobal(rng);
  const confidence = round2(observations.reduce((s, o) => s + o.confidence, 0) / observations.length);
  return {
    model: MOCK_MODEL,
    seed: digest,
    global,
    regions,
    observations,
    confidence,
  };
}

/**
 * 方向候选（2–3 个）。
 * @param {object} input 见 CONTRACT.md §2.3
 */
export function mockDirections(input) {
  const { material } = normalizeInput(input);
  const { rng } = makeRng(`${material}|directions`);
  const requested = Number.isInteger(input?.count) ? input.count : 2;
  const count = clampInt(requested, 2, 3);
  const pool = [...DIRECTION_BANK];
  const directions = [];
  for (let i = 0; i < count && pool.length > 0; i += 1) {
    const idx = Math.floor(rng() * pool.length) % pool.length;
    const item = pool.splice(idx, 1)[0];
    directions.push({
      id: `dir-mock-${String(i + 1).padStart(2, '0')}`,
      title: item.title,
      why: item.why,
      confidence: round2(0.55 + rng() * 0.35),
      tags: item.tags,
    });
  }
  return { directions };
}

// ---------- SVG 占位候选 ----------

const B64_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function utf8ToBase64(str) {
  const bytes = new TextEncoder().encode(str);
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i];
    const b1 = i + 1 < bytes.length ? bytes[i + 1] : undefined;
    const b2 = i + 2 < bytes.length ? bytes[i + 2] : undefined;
    out += B64_ALPHABET[b0 >> 2];
    out += B64_ALPHABET[((b0 & 3) << 4) | ((b1 ?? 0) >> 4)];
    out += b1 === undefined ? '=' : B64_ALPHABET[((b1 & 15) << 2) | ((b2 ?? 0) >> 6)];
    out += b2 === undefined ? '=' : B64_ALPHABET[b2 & 63];
  }
  return out;
}

function svgPlaceholder({ width, height, seedHex, index }) {
  const a = parseInt(seedHex.slice(0, 6), 16);
  const b = parseInt(seedHex.slice(6, 12), 16);
  const hueA = a % 360;
  const hueB = b % 360;
  const cx = 20 + (a % Math.max(1, Math.round(width * 0.6)));
  const cy = 20 + (b % Math.max(1, Math.round(height * 0.6)));
  const r = Math.max(12, Math.round(Math.min(width, height) * 0.18));
  const rot = (a + index * 37) % 360;
  return [
    `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`,
    `<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">`,
    `<stop offset="0" stop-color="hsl(${hueA} 38% 42%)"/><stop offset="1" stop-color="hsl(${hueB} 32% 24%)"/>`,
    `</linearGradient></defs>`,
    `<rect width="${width}" height="${height}" fill="url(#g)"/>`,
    `<circle cx="${cx}" cy="${cy}" r="${r}" fill="hsl(${(hueA + 40) % 360} 45% 62%)" opacity="0.55"/>`,
    `<rect x="${Math.round(width * 0.12)}" y="${Math.round(height * 0.12)}" width="${Math.round(width * 0.76)}" height="${Math.round(height * 0.76)}" fill="none" stroke="hsl(${hueB} 30% 82%)" stroke-width="2" stroke-dasharray="6 6" opacity="0.5" transform="rotate(${rot % 4 === 0 ? 0 : 0} ${width / 2} ${height / 2})"/>`,
    `</svg>`,
  ].join('');
}

/**
 * 模拟生成候选：确定性 SVG dataURL（可直接用于 <img>/drawImage）。
 * @param {object} input 见 CONTRACT.md §2.4
 */
export function mockGenerate(input) {
  if (!input || typeof input !== 'object') throw new TypeError('mock-ai: 输入必须是对象');
  if (typeof input.directionId !== 'string' || input.directionId.length === 0) {
    throw new TypeError('mock-ai: generate 需要 directionId');
  }
  const { selection, material } = normalizeInput(input, { needDirection: true });
  const { rng, digest } = makeRng(`${material}|generate`);
  const requested = Number.isInteger(input?.count) ? input.count : 2;
  const count = clampInt(requested, 1, 3);
  const size = input?.size && typeof input.size === 'object'
    ? {
      width: clampInt(Number(input.size.width) || selection.width, 256, 2048),
      height: clampInt(Number(input.size.height) || selection.height, 256, 2048),
    }
    : { width: clampInt(selection.width, 256, 2048), height: clampInt(selection.height, 256, 2048) };
  const labels = ['方案 A', '方案 B', '方案 C'];
  const candidates = [];
  for (let i = 0; i < count; i += 1) {
    const localSeed = digestOf(`${digest}|cand|${i}`);
    const svg = svgPlaceholder({ width: size.width, height: size.height, seedHex: localSeed, index: i });
    candidates.push({
      id: `cand-mock-${String(i + 1).padStart(2, '0')}`,
      label: `${labels[i] ?? `方案 ${i + 1}`} · ${pick(rng, ['冷调', '暖调', '保留笔触', '加对比', '轻结构'])}`,
      why: pick(rng, [
        '在选区内重新分配了明度，保留原有笔触走向',
        '只动了边缘附近的色温，结构没碰',
        '加强了主要转折的对比，其他区域保持原样',
      ]),
      imageDataUrl: `data:image/svg+xml;base64,${utf8ToBase64(svg)}`,
      width: size.width,
      height: size.height,
    });
  }
  return { candidates, credits: 0 };
}

/** 默认配置（与 server 的 GET /api/config 一致；mock 模式） */
export function mockConfig() {
  return { provider: 'mock', baseUrl: '', model: '', apiKeySet: false };
}
