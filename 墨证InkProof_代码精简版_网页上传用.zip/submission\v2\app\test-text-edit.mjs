// v2/app/test-text-edit.mjs —— 文字二次编辑 + 笔刷光标轮廓
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8161;
const out = { schema: 'mozheng.app.text-edit.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-text-edit-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  const before = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.click('#btnToolText');
  const box = await page.locator('#mainCanvas').boundingBox();
  await page.mouse.click(box.x + box.width * 0.35, box.y + box.height * 0.35);
  await page.waitForTimeout(250);
  await page.fill('#tcText', '初始文字');
  await page.fill('#tcSize', '56');
  await page.click('#tcOk');
  await page.waitForTimeout(700);
  out.cases.create = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const layers = a.engine.getLayers();
    const l = layers.find((x) => x.kind === 'text') || layers[layers.length - 1];
    return { layers: layers.length, textMeta: a.state.textLayers.size, names: layers.map((x) => x.name), kind: l.kind, topText: l.text && (l.text.content || l.text.text) };
  });
  // 双击文字图层打开二次编辑
  out.cases.open = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    const rows = [...document.querySelectorAll('#layerList .layer-row:not(.group-row)')];
    const meta = [...a.state.textLayers.values()][0];
    const row = rows.find((r) => r.dataset.layerId === (meta && meta.layerId));
    if (!row) return { ok: false, reason: 'row-not-found' };
    row.dispatchEvent(new MouseEvent('dblclick', { bubbles: true }));
    await new Promise((r) => setTimeout(r, 250));
    const ta = document.getElementById('tcText');
    return { ok: !!ta, prefill: ta ? ta.value : '', size: (document.getElementById('tcSize') || {}).value };
  });
  await page.fill('#tcText', '修改后的文字\n第二行');
  await page.click('#tcOk');
  await page.waitForTimeout(900);
  out.cases.edit = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const meta = [...a.state.textLayers.values()][0] || {};
    const layers = a.engine.getLayers();
    const l = layers.find((x) => x.kind === 'text') || layers[layers.length - 1];
    return { layers: layers.length, text: meta.text, updated: !!meta.updatedAt, kind: l.kind, topText: l.text && (l.text.content || l.text.text), editedRecords: a.state.records.filter((r) => r.kind === 'text_edited').length, names: layers.map((x) => x.name) };
  });
  // 键盘 Ctrl+Z / Ctrl+Y 也必须同步 state.textLayers（QA T116 P1）
  await page.keyboard.press('Control+z');
  await page.waitForTimeout(300);
  out.cases.keyboardUndo = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const meta = [...a.state.textLayers.values()][0] || {};
    const ls = a.engine.getLayers(); const l = ls.find((x) => x.kind === 'text') || ls[ls.length - 1];
    return { stateText: meta.content || meta.text || '', engineText: l.text && (l.text.content || l.text.text) };
  });
  await page.keyboard.press('Control+y');
  await page.waitForTimeout(300);
  out.cases.keyboardRedo = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const meta = [...a.state.textLayers.values()][0] || {};
    const ls = a.engine.getLayers(); const l = ls.find((x) => x.kind === 'text') || ls[ls.length - 1];
    return { stateText: meta.content || meta.text || '', engineText: l.text && (l.text.content || l.text.text) };
  });
  // 原子 undo：像素与 text 结构一起回滚，redo 一起恢复
  out.cases.undo = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    const get = () => { const ls = a.engine.getLayers(); const l = ls.find((x) => x.kind === 'text') || ls[ls.length - 1]; return { kind: l.kind, text: l.text && (l.text.content || l.text.text), layers: ls.length }; };
    a.engine.undo(); await new Promise((r) => setTimeout(r, 200));
    const afterUndo = get();
    a.engine.redo(); await new Promise((r) => setTimeout(r, 200));
    return { afterUndo, afterRedo: get() };
  });
  // v2doc 持久化：保存/加载后文字 metadata 仍可识别
  out.cases.persist = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    const json = a.engine.serializeDoc();
    await a.t61.loadProjectText(json);
    await new Promise((r) => setTimeout(r, 500));
    const meta = [...a.state.textLayers.values()][0] || {};
    const rows = [...document.querySelectorAll('#layerList .layer-row:not(.group-row)')];
    const row = rows.find((r) => r.dataset.layerId === meta.layerId);
    if (row) row.dispatchEvent(new MouseEvent('dblclick', { bubbles: true }));
    await new Promise((r) => setTimeout(r, 250));
    const ta = document.getElementById('tcText');
    const prefilled = ta ? ta.value : '';
    if (document.getElementById('tcCancel')) document.getElementById('tcCancel').click();
    return { metaCount: a.state.textLayers.size, text: meta.text, prefilled, hasMetaInDoc: json.includes('"kind":"text"') && json.includes('"text"') && json.includes('修改后的文字') };
  });
  // 笔刷光标
  await page.click('#btnToolBrush');
  await page.mouse.move(box.x + box.width * 0.5, box.y + box.height * 0.5);
  await page.waitForTimeout(250);
  out.cases.cursor = await page.evaluate(() => {
    const c = document.getElementById('brushCursorCanvas');
    const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    let alpha = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 8) { alpha += 1; if (alpha > 500) break; }
    return { alpha, hasCanvas: !!c };
  });
  out.cases.before = before;
  out.cases.createOk = out.cases.create.layers === before + 1 && out.cases.create.textMeta >= 1 && out.cases.create.kind === 'text' && out.cases.create.topText === '初始文字';
  out.cases.openOk = out.cases.open.ok && out.cases.open.prefill === '初始文字';
  out.cases.editOk = out.cases.edit.layers === out.cases.create.layers && out.cases.edit.text.includes('修改后的文字') && out.cases.edit.editedRecords >= 1 && out.cases.edit.kind === 'text' && out.cases.edit.topText.includes('修改后的文字');
  out.cases.undoOk = out.cases.undo.afterUndo.kind === 'text' && out.cases.undo.afterUndo.text === '初始文字' && out.cases.undo.afterRedo.text.includes('修改后的文字');
  out.cases.keyboardOk = out.cases.keyboardUndo.stateText === '初始文字' && out.cases.keyboardUndo.engineText === '初始文字' && out.cases.keyboardRedo.stateText.includes('修改后的文字') && out.cases.keyboardRedo.engineText.includes('修改后的文字');
  out.cases.persistOk = out.cases.persist.metaCount >= 1 && out.cases.persist.prefilled.includes('修改后的文字') && out.cases.persist.hasMetaInDoc;
  out.cases.cursorOk = out.cases.cursor.hasCanvas && out.cases.cursor.alpha > 100;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.createOk && out.cases.openOk && out.cases.editOk && out.cases.undoOk && out.cases.keyboardOk && out.cases.persistOk && out.cases.cursorOk && out.cases.noErrors;
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-text-edit-1920.png' });
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
