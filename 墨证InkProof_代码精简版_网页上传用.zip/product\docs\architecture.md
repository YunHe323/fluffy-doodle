# Architecture

Mozheng is a **local-first, zero-dependency** web application. It runs a small local Node service for static files and mock AI endpoints, while all user data lives in the browser.

> This document is a product-repo summary. Detailed internal design and research documents are kept **outside** this repository. The app ↔ server interface is defined in [`CONTRACT.md`](../CONTRACT.md) — **current contract: v0.1.1**.

---

## High-level shape

```
┌──────────────────────────── Browser (localhost) ────────────────────────────┐
│                                                                              │
│  app/  (vanilla ES modules, no framework/build)                              │
│   ├─ canvas / layers / tools                                                 │
│   ├─ archive UI (L0/L1/L2/L4/L5/L6 cards)                                    │
│   ├─ stuck panel (mock analyze → directions → candidates → apply layer)      │
│   ├─ evidence UI (event timeline, manifest, export)                          │
│   ├─ onboarding + one-click demo + sample project                            │
│   └─ state.js / IndexedDB persistence                                        │
│                                                                              │
│  core/  (pure ESM, shared with Node)                                         │
│   ├─ hash-chain.mjs      (SHA-256 append-only event chain)                   │
│   ├─ archive-schema.mjs  (L0–L6 record validation)                           │
│   └─ mock-ai.mjs         (deterministic mock observations/directions/images) │
│                                                                              │
│  IndexedDB (per browser profile)                                              │
│   projects · layers · assets · archive_records · events · generations · settings │
└───────────────────────────────────┬──────────────────────────────────────────┘
                                    │ fetch('/api/*') — same origin, localhost only
┌───────────────────────────────────┴──────────────────────────────────────────┐
│  server/  (Node 22+, zero dependencies, stateless)                            │
│   ├─ server.mjs    static files + /api/health, /api/ai/*, /api/config        │
│   └─ ai-proxy.mjs  mock implementation; provider hook reserved (v0.2)         │
│                                                                              │
│  Binds 127.0.0.1 only · no user data persisted · no image/body logging        │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## Module boundaries

| Layer | Owns | Must not |
|---|---|---|
| `app/` | Rendering, interaction, local state, IndexedDB, export/import UI, onboarding/demo | Persist data on the server; import `server/*` directly |
| `core/` | Pure logic reusable in browser and Node: hashing, schema validation, deterministic mock | Touch DOM, network, filesystem, or browser-only APIs |
| `server/` | Static file serving, `/api/*` contract, mock AI, provider config guard | Store artworks/archives/evidence; log request bodies; bind to public interfaces |
| `test/` | `node --test` unit tests for `core/` and server helpers | Require a browser or network |

**Offline fallback:** if the local service is unavailable, the frontend can call the same deterministic mock logic from `core/mock-ai.mjs`, so canvas/archive/demo remain usable. Real provider calls are not implemented in v0.1.

---

## Data model (summary)

All persistent data lives in IndexedDB. Logical stores:

| Store | Purpose |
|---|---|
| `projects` | Project metadata: size, mode (`collab` / `attest`), active layer, timestamps |
| `layers` | Layer order, name, kind (`base` / `user` / `ai`), visibility, opacity, PNG bitmap Blob |
| `assets` | L0 originals: sha256, mime, size, dimensions, blob, import time, consent flags |
| `archive_records` | L0/L1/L2/L4/L5/L6 records with `anchor`, `source`, `confidence`, `author`, `model_version`, `supersedes` |
| `events` | Append-only evidence chain: `seq`, `ts`, `kind`, `mode`, `detail`, `prev_hash`, `hash` |
| `generations` | One record per AI call: model/provider/version, params, input refs, output layer, accepted |
| `settings` | UI prefs, onboarding completion, last project; never secrets or user profiles |

Project export (`inkproof.project` JSON) includes project metadata, layer bitmaps as data URLs, assets, archive records, events, and generations. Evidence export (`inkproof.evidence` JSON) includes the full event chain, AI events, mode timeline, canvas PNG hash, and manifest with limitations. Both carry a `schema_version`.

---

## Evidence chain

- Every user/AI action appends an event; the hash is computed over `prev_hash + seq + ts + kind + mode + detail` (see `core/hash-chain.mjs`).
- `manifest.hash_chain.valid` reflects verification at export time; events cannot be edited or selectively hidden in the UI.
- **Zero generation claim** is scoped: it is true only if attestation mode is active and no generation/observation AI calls occurred after entering that mode. Prior AI events remain in the export.
- **Limitations (by design):** local clock only, no third-party timestamp or C2PA signature in v0.1; the package does not prove that no AI was used in other tools, and it is not legal advice.

---

## AI boundary

| Mode | Behavior |
|---|---|
| `mock` (default) | Deterministic local responses; no API key; no external network; clearly labeled in UI; evidence records `mock-ai@0.1.0` |
| `provider` (reserved) | Interface + config shape only in v0.1; real calls return `501`; keys stay local (`config/provider.json`, gitignored) and are never sent to the browser/logs/repo |

Mock determinism is a test requirement: the same normalized input must yield the same output. Mock responses must never be presented as real model output.

---

## Privacy & security boundaries

- Service binds to `127.0.0.1` only.
- No telemetry/analytics; mock mode makes no external requests.
- Request bodies are parsed in memory only; the server does not persist artwork or evidence.
- Path traversal is rejected; static serving is limited to `app/` and `core/`.
- No account system in v0.1; data stays in the user's browser profile.

See [privacy.md](privacy.md) and [`CONTRACT.md`](../CONTRACT.md) §6 for details.

---

## Third-party assets

Mozheng aims to keep assets self-made or permissively licensed:

| Asset | License | Notes |
|---|---|---|
| Icons (Lucide-derived) | **ISC** | If reused/derived, keep attribution in this file |
| Fonts | System fonts only | No external/CDN fonts |
| Sample artwork | **Self-made / programmatically generated** | No third-party image is bundled without attribution |
| Mock candidate images | Generated SVG in `core/mock-ai.mjs` | Deterministic, no external source |

If you add an asset, record its source and license here and in your PR. Assets with unclear provenance are not accepted.

---

## Extension points (future, not v0.1)

- Provider interface for real models (config + proxy), including key handling and failure fallback.
- PSD import/export and richer layer fidelity.
- L3 relationship archive, evidence ZIP with layer PNGs + verification helper.
- Optional encrypted cloud sync and desktop shell.

See `README.md` → Roadmap and `docs/privacy.md` for constraints any extension must respect.
