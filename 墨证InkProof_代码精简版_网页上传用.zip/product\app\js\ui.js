// product/app/js/ui.js
// 界面层：AI 面板（观察/方向/候选/预览）、图谱弹层、关于、首次引导、全局按钮与快捷键绑定、状态栏。
import {
  state, emit, on, $, uid, nowIso, clamp, escapeHtml, toast, setStatusHint,
  showCanvasToast, setSaveState, bboxArray, call, fmtTime
} from './state.js';
import { ICON_SVG, applyIcons, srcIconHtml } from './icons.js';
import {
  setTool, setColor, setSize, renderAll, renderOverlay, createAiLayerFromProposal,
  pulseRect, pushHistory, makeActionHistory, markLayerDirty, renderLayerThumb, findLayer
} from './canvas.js';
import { renderLayerList } from './layers.js';
import {
  openArchiveModal, recordAnalyzeResult, confirmObservation, rejectObservation, revertObservation, recordAcceptAi
} from './archive.js';
import {
  recordCritique, recordGeneration, markGenerationAccepted, recordModeChangeL6,
  recordRoleChangeL6, openEvidenceModal, downloadEvidenceJson, downloadEvidencePng,
  downloadEvidenceBoth, updateHashPill, evidenceStats
} from './evidence.js';
import { createAIClient, buildAnalyzeInput } from './ai-client.js';

const ai = createAIClient();
let aiClientInfo = '本地 MockAI';

const SWATCHES = ['#e8d7a8', '#f2b880', '#e26d5c', '#7fb7a3', '#5b8fb9', '#2f6f8f', '#c9b6e4', '#f5f0e6', '#94a3b8', '#ffffff'];

/* ============================ 初始化 ============================ */
export function initUI() {
  applyIcons();
  buildSwatches();
  bindToolbar();
  bindTopbar();
  bindModals();
  bindKeyboard();
  bindOnboarding();
  on('events:changed', updateStatusBar);
  on('archive:changed', updateStatusBar);
  on('canvas:changed', updateStatusBar);
  on('layers:changed', updateStatusBar);
  on('selection:changed', () => { if (state.observations.length) renderAiPanel(); });
  on('demo:changed', () => { /* demo 模块自行更新控制条 */ });
  on('save:changed', (d) => setSaveState(d.kind, d.text));
  renderAiPanel();
  updateStatusBar();
  updateHashPill();
}

function buildSwatches() {
  const host = $('swatches');
  if (!host) return;
  host.innerHTML = '';
  SWATCHES.forEach((color, i) => {
    const b = document.createElement('button');
    b.className = 'swatch' + (i === 0 ? ' active' : '');
    b.style.background = color;
    b.dataset.color = color;
    b.title = color;
    b.addEventListener('click', () => setColor(color));
    host.append(b);
  });
}

function bindToolbar() {
  document.querySelectorAll('[data-tool]').forEach((btn) => {
    btn.addEventListener('click', () => setTool(btn.dataset.tool));
  });
  $('colorInput').addEventListener('input', () => setColor($('colorInput').value));
  $('sizeRange').addEventListener('input', () => setSize(Number($('sizeRange').value)));
  $('btnUndo').addEventListener('click', () => call('canvas.undo'));
  $('btnRedo').addEventListener('click', () => call('canvas.redo'));
  $('btnAskAi').addEventListener('click', () => askAi());
  $('btnIgnoreArchive').addEventListener('click', () => setIgnoreArchive(!state.ignoreArchive));
}

function bindTopbar() {
  $('btnLoadExample').addEventListener('click', () => call('app.loadExample'));
  $('btnImportImage').addEventListener('click', () => $('fileInput').click());
  $('fileInput').addEventListener('change', (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (file) call('app.importImage', file);
  });
  $('btnArchive').addEventListener('click', openArchiveModal);
  $('btnEvidence').addEventListener('click', openEvidenceModal);
  $('btnAbout').addEventListener('click', openAbout);
  // 顶栏「导入 / 导出」下拉 + 左右栏折叠（UX 预检：顶栏收纳）
  document.querySelectorAll('.menu-wrap').forEach((wrap) => {
    const trigger = wrap.querySelector('.icon-btn');
    if (!trigger) return;
    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      document.querySelectorAll('.menu-wrap.open').forEach((w) => { if (w !== wrap) w.classList.remove('open'); });
      wrap.classList.toggle('open');
    });
    wrap.querySelectorAll('.menu-pop button').forEach((b) => b.addEventListener('click', () => wrap.classList.remove('open')));
  });
  document.addEventListener('click', () => document.querySelectorAll('.menu-wrap.open').forEach((w) => w.classList.remove('open')));
  const tb = $('btnToggleToolbar');
  if (tb) tb.addEventListener('click', () => { document.querySelector('.toolbar')?.classList.toggle('collapsed'); window.dispatchEvent(new Event('resize')); });
  const sb = $('btnToggleSidebar');
  if (sb) sb.addEventListener('click', () => { document.querySelector('.sidebar')?.classList.toggle('collapsed'); window.dispatchEvent(new Event('resize')); });
  $('btnExportProject').addEventListener('click', () => call('app.exportProject'));
  $('btnImportProject').addEventListener('click', () => $('projectFileInput').click());
  $('projectFileInput').addEventListener('change', (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (file) call('app.importProject', file);
  });
  document.querySelectorAll('.mode-opt').forEach((btn) => {
    btn.addEventListener('click', () => setMode(btn.dataset.mode));
  });
  // 关于面板里的数据操作
  $('btnAboutExport').addEventListener('click', () => call('app.exportProject'));
  $('btnAboutImport').addEventListener('click', () => $('projectFileInput').click());
  $('btnClearLocal').addEventListener('click', () => {
    if (confirm('确定清空本机所有项目、档案与事件？此操作不可恢复。建议先「导出项目」。')) call('app.clearLocalData');
  });
}

function bindModals() {
  document.querySelectorAll('[data-close]').forEach((btn) => {
    btn.addEventListener('click', () => { const m = $(btn.dataset.close); if (m) m.classList.remove('open'); });
  });
  ['archiveModal', 'evidenceModal', 'aboutModal'].forEach((id) => {
    const mask = $(id);
    if (mask) mask.addEventListener('click', (e) => { if (e.target === mask) mask.classList.remove('open'); });
  });
  $('btnDownloadJson').addEventListener('click', downloadEvidenceJson);
  $('btnDownloadPng').addEventListener('click', downloadEvidencePng);
  $('btnExportBoth').addEventListener('click', downloadEvidenceBoth);
}

function bindKeyboard() {
  window.addEventListener('keydown', (e) => {
    const tag = (e.target && e.target.tagName) || '';
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    const openModal = document.querySelector('.modal-mask.open');
    if (e.key === 'Escape') {
      if (openModal) { openModal.classList.remove('open'); return; }
      if (state.previewProposalId) { cancelPreview(); return; }
      if (state.selection) { state.selection = null; renderOverlay(); setStatusHint('已清除指认区域'); return; }
      return;
    }
    if (openModal) return;
    const k = e.key.toLowerCase();
    if ((e.ctrlKey || e.metaKey) && k === 'z') { e.preventDefault(); if (e.shiftKey) call('canvas.redo'); else call('canvas.undo'); return; }
    if ((e.ctrlKey || e.metaKey) && k === 'y') { e.preventDefault(); call('canvas.redo'); return; }
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (k === 'k') { e.preventDefault(); askAi(); return; }
    if (k === 'b') setTool('brush-hard');
    else if (k === 'n') setTool('brush-soft');
    else if (k === 'e') setTool('eraser');
    else if (k === 'r') setTool('select');
    else if (k === 'm') setTool('move');
  });
}

/* ============================ 状态栏 ============================ */
export function updateStatusBar() {
  const set = (id, text) => { const el = $(id); if (el) el.textContent = text; };
  set('statusLayers', '图层 ' + state.layers.length);
  set('statusStrokes', '笔触 ' + state.strokeCount);
  set('statusEvents', '事件 ' + state.events.length);
  set('statusAiState', state.mode === 'attest' ? 'AI 已关闭（存证模式）' : state.aiBusy ? 'AI 工作中（Mock）' : `AI 事件 ${state.generations.length}`);
  set('decisionCount', String(state.decisions.length));
  const modeText = state.mode === 'attest' ? '存证模式 · AI 已关闭 · 证据包零生成' : '协作模式 · AI 可参与局部方案';
  set('statusModeText', modeText);
  const aiStatus = $('aiStatus');
  if (aiStatus) aiStatus.textContent = state.aiBusy ? '模拟分析中…' : state.aiReview ? '已返回（Mock）' : state.mode === 'attest' ? '存证模式 · 已禁用' : '待指认';
  const ask = $('btnAskAi');
  if (ask) ask.disabled = state.mode === 'attest';
  const docName = $('docName');
  if (docName) docName.textContent = '作品' + (state.projectName || '');
  const projectLabel = $('projectLabel');
  if (projectLabel) projectLabel.textContent = state.projectName || '未命名作品';
}

/* ============================ 模式 ============================ */
export function setMode(mode) {
  if (mode !== 'collab' && mode !== 'attest') return;
  if (state.mode === mode) return;
  const from = state.mode;
  state.mode = mode;
  state.modeStartedAt = nowIso();
  cancelPreview(true);
  recordModeChangeL6(from, mode);
  emit('log', { type: 'mode_change', actor: 'user', payload: { from, to: mode } });
  document.querySelectorAll('.mode-opt').forEach((btn) => btn.classList.toggle('active', btn.dataset.mode === mode));
  renderAiPanel();
  renderOverlay();
  updateStatusBar();
  emit('persist:project');
  toast(mode === 'attest' ? '已进入存证模式 · AI 已禁用，证据包将输出零生成声明' : '已切回协作模式 · 可继续「让 AI 看看」', 'ok', 3200);
  setStatusHint(mode === 'attest' ? '存证模式 · AI 已禁用 · 画布照常可用' : '协作模式 · AI 可参与局部方案');
}

/* ============================ AI：让 AI 看看 ============================ */
function defaultSelection() {
  return { x: 1200 * 0.26, y: 800 * 0.38, w: 1200 * 0.42, h: 800 * 0.34 };
}
function selectionForClient() {
  const s = state.selection || defaultSelection();
  return { mode: 'rect', rect: { x: Math.round(s.x), y: Math.round(s.y), width: Math.round(s.w), height: Math.round(s.h) } };
}

export async function askAi() {
  if (state.mode === 'attest') { toast('存证模式已禁用 AI · 切回「协作模式」后再试', 'warn'); return; }
  if (state.aiBusy) return;
  cancelPreview(true);
  if (!state.selection) { state.selection = defaultSelection(); toast('没有框选，AI 默认看画面中部（先框选更准）', 'warn'); }
  state.aiBusy = true;
  state.aiReview = null;
  state.observations = [];
  state.directions = [];
  state.proposals = [];
  state.observationsReveal = null;
  state.selectedDirectionId = null;
  state.committedProposalId = null;
  state.highlightObsId = null;
  renderAiPanel();
  updateStatusBar();
  setStatusHint('AI 正在读你的画与档案（Mock）…');
  const reqLog = { selection: selectionForClient(), context: { mode: state.mode, aiRole: state.aiRole, ignoreArchive: state.ignoreArchive } };
  emit('log', { type: 'ai_review_requested', actor: 'user', payload: reqLog });
  const t0 = performance.now();
  const input = buildAnalyzeInput({ selection: state.selection, context: {} });
  let analyze;
  let dirs;
  try {
    analyze = await ai.analyzeCanvas(input);
    dirs = await ai.suggestDirections({ ...input, observationIds: analyze.observations.map((o) => o.id), analysis: analyze });
  } catch (e) {
    state.aiBusy = false;
    renderAiPanel();
    toast('AI 请求失败（本地 Mock 错误）：' + e.message, 'warn', 3600);
    console.error(e);
    return;
  }
  const latency = Math.round(performance.now() - t0);
  const created = recordAnalyzeResult(analyze, state.selection);
  // 展示用观察：1 条 observed（来自 L1 采样）+ analyze 的 inferred 观察
  const l1 = created.l1;
  const observedObs = {
    id: 'obs-observed',
    recordId: l1.id,
    source: 'observed',
    originalSource: 'observed',
    confidence: null,
    text: `画面主色为 ${analyze.global.palette?.[0]?.hex || '#2f4e5f'}，整体偏${analyze.global.mood?.[0] || '安静'}；构图以水平雾带分层。`,
    anchorRect: { x: state.selection.x, y: state.selection.y, w: state.selection.w, h: state.selection.h },
    evidenceRefs: ['L1'],
    decision: null
  };
  const inferredObs = created.observations.map((rec, i) => ({
    id: 'obs-' + rec.id,
    recordId: rec.id,
    source: 'inferred',
    originalSource: 'inferred',
    confidence: rec.confidence,
    text: rec.text,
    anchorRect: anchorRectFromValue(rec.anchor.value),
    evidenceRefs: rec.evidence_refs || [],
    decision: null,
    displayIndex: i + 1
  }));
  state.observations = [observedObs, ...inferredObs];
  state.directions = dirs.directions || [];
  state.aiReview = { analyze, directions: state.directions, model: analyze.model, latencyMs: latency };
  state.aiBusy = false;
  recordCritique({ request: input, result: analyze, latencyMs: latency, selection: state.selection, analysisObsIds: analyze.observations.map((o) => o.id) });
  emit('log', {
    type: 'ai_observations_shown',
    actor: 'ai',
    payload: { count: state.observations.length, directions: state.directions.length, latency_ms: latency, model: analyze.model, mock: true }
  });
  renderAiPanel();
  renderOverlay();
  updateStatusBar();
  setStatusHint('观察已返回（本地 Mock）· 点击观察卡可在画布高亮锚点');
  showCanvasToast('AI 观察已返回（本地 Mock，不联网）· 点击卡片看画布锚点', 3200);
  return state.aiReview;
}

function anchorRectFromValue(value) {
  if (!Array.isArray(value) || value.length < 4) return null;
  return { x: clamp(value[0], 0, 1200), y: clamp(value[1], 0, 800), w: Math.max(1, value[2]), h: Math.max(1, value[3]) };
}

export function decideObservation(obsId, action) {
  const obs = state.observations.find((o) => o.id === obsId);
  if (!obs) return;
  const record = state.archive.find((r) => r.id === obs.recordId);
  if (!record) return;
  if (action === 'confirm') {
    if (obs.decision === 'confirmed') return;
    obs.decision = 'confirmed';
    obs.source = 'user-confirmed';
    confirmObservation(record, obs);
    emit('log', { type: 'archive_confirmed', actor: 'user', payload: { record_id: record.id, layer: 'L4' } });
  } else {
    if (obs.decision === 'rejected') return;
    obs.decision = 'rejected';
    obs.source = 'rejected';
    rejectObservation(record, obs);
    emit('log', { type: 'archive_rejected', actor: 'user', payload: { record_id: record.id, layer: 'L4' } });
  }
  renderAiPanel();
  renderOverlay();
  updateStatusBar();
}

export function revertObservationDecision(obsId) {
  const obs = state.observations.find((o) => o.id === obsId);
  if (!obs || !obs.decision) return;
  const record = state.archive.find((r) => r.id === obs.recordId);
  const prev = obs.decision;
  if (record) revertObservation(record, obs, prev);
  obs.decision = null;
  obs.source = obs.originalSource;
  emit('log', { type: 'archive_decision_reverted', actor: 'user', payload: { record_id: obs.recordId, decision: prev } });
  renderAiPanel();
  renderOverlay();
  updateStatusBar();
}

export function selectDirection(id) {
  if (state.aiBusy) return;
  state.selectedDirectionId = id;
  state.proposals = [];
  state.previewProposalId = null;
  state.committedProposalId = null;
  emit('log', { type: 'ai_direction_selected', actor: 'user', payload: { direction_id: id } });
  renderAiPanel();
  renderOverlay();
}

export async function generateProposals() {
  if (!state.selectedDirectionId || state.aiBusy) return;
  const direction = state.directions.find((d) => d.id === state.selectedDirectionId);
  state.generating = true;
  state.aiBusy = true;
  state.proposals = [];
  state.previewProposalId = null;
  renderAiPanel();
  updateStatusBar();
  setStatusHint('正在生成模拟方案（本地 canvas 滤镜）…');
  emit('log', { type: 'candidate_requested', actor: 'user', payload: { direction_id: state.selectedDirectionId, count: 2 } });
  const t0 = performance.now();
  let result;
  try {
    result = await ai.generateCandidate({ ...buildAnalyzeInput({ selection: state.selection }), directionId: state.selectedDirectionId, count: 2 });
  } catch (e) {
    state.generating = false;
    state.aiBusy = false;
    renderAiPanel();
    toast('候选生成失败：' + e.message, 'warn');
    return;
  }
  const latency = Math.round(performance.now() - t0);
  state.proposals = (result.candidates || []).map((c) => {
    const proposal = { ...c, directionId: state.selectedDirectionId, model: result.model || 'mock-ai@0.1.0' };
    const gen = recordGeneration({ proposal, direction, latencyMs: latency / Math.max(1, (result.candidates || []).length), inputRefs: state.archive.filter((r) => r.layer === 'L4').slice(-3).map((r) => r.id) });
    proposal.generationId = gen.id;
    return proposal;
  });
  state.generating = false;
  state.aiBusy = false;
  emit('log', { type: 'candidate_shown', actor: 'ai', payload: { count: state.proposals.length, latency_ms: latency, mock: true } });
  renderAiPanel();
  updateStatusBar();
  setStatusHint('模拟方案已生成 · 点击方案在画布预览');
  showCanvasToast('2 个模拟方案已生成（本地 canvas 滤镜）· 点击卡片预览', 3000);
}

export function previewProposal(id) {
  if (state.mode === 'attest') return;
  const p = state.proposals.find((x) => x.id === id);
  if (!p) return;
  state.previewProposalId = id;
  emit('log', { type: 'candidate_previewed', actor: 'user', payload: { proposal_id: id } });
  renderAiPanel();
  renderOverlay();
  setStatusHint('正在预览模拟方案 · 点「保留为新图层」落盘，或「放弃预览」');
  showCanvasToast('画布上为预览（虚线框），像素尚未落盘', 2800);
}
export function cancelPreview(silent = false) {
  if (!state.previewProposalId) return;
  const id = state.previewProposalId;
  state.previewProposalId = null;
  if (!silent) emit('log', { type: 'candidate_preview_cancelled', actor: 'user', payload: { proposal_id: id } });
  renderAiPanel();
  renderOverlay();
  if (!silent) setStatusHint('已放弃预览 · 画布像素未改变');
}

export async function acceptProposal() {
  if (state.mode === 'attest') { toast('存证模式下不能落 AI 图层', 'warn'); return; }
  const proposal = state.proposals.find((x) => x.id === state.previewProposalId);
  if (!proposal) return;
  const direction = state.directions.find((d) => d.id === proposal.directionId);
  const layer = await createAiLayerFromProposal(proposal, direction?.title);
  state.layers.push(layer);
  state.activeLayerId = layer.id;
  pushHistory(makeActionHistory(
    () => { state.layers = state.layers.filter((l) => l.id !== layer.id); renderAll(); emit('layers:changed'); },
    () => { state.layers.push(layer); state.activeLayerId = layer.id; renderAll(); emit('layers:changed'); },
    '落盘 AI 图层'
  ));
  markGenerationAccepted(proposal.generationId, layer);
  recordAcceptAi(layer, proposal, direction?.title);
  emit('log', {
    type: 'ai_layer_committed',
    actor: 'user',
    payload: { layer_id: layer.id, layer_name: layer.name, proposal_id: proposal.id, direction_id: proposal.directionId, generation_id: proposal.generationId }
  });
  state.committedProposalId = proposal.id;
  state.previewProposalId = null;
  setTool('move');
  renderAll();
  renderLayerList();
  renderAiPanel();
  pulseRect(proposal.rect);
  toast('已落为新图层「' + layer.name + '」· 可拖动/隐藏/删除，Ctrl+Z 可撤销', 'ok', 3400);
  setStatusHint('AI 图层已落盘 · 用「移动」工具可拖动它');
  showCanvasToast('已落为新图层 · 可用「移动」工具拖动，或 Ctrl+Z 撤销', 3200);
  return layer;
}

export function setIgnoreArchive(on) {
  state.ignoreArchive = !!on;
  const btn = $('btnIgnoreArchive');
  if (btn) btn.classList.toggle('active-ignore', state.ignoreArchive);
  renderAiPanel();
  toast(state.ignoreArchive ? '本次请求将不参考你的档案（通用模式）' : '已恢复参考你的档案');
}

/* ============================ AI 面板渲染 ============================ */
function sourceBadge(source) {
  const map = { observed: '可见', inferred: 'AI 推断', 'user-confirmed': '你确认', rejected: '已否决' };
  return `<span class="src-badge ${source}">${srcIconHtml(source)} ${map[source] || source}</span>`;
}
function confidenceMarkup(obs) {
  if (obs.confidence == null) return '<span class="conf">— 无置信度（可见事实）</span>';
  const pct = Math.round(obs.confidence * 100);
  const on = obs.confidence >= 0.8 ? 3 : obs.confidence >= 0.5 ? 2 : 1;
  const dots = [0, 1, 2].map((i) => (i < on ? '●' : '○')).join('');
  return `<span class="conf ${obs.confidence < 0.5 ? 'low' : ''}" title="Mock AI 自评置信度，不是准确率">${dots} ${pct}%${obs.confidence < 0.5 ? ' · 待确认' : ''}</span>`;
}
function observationCardHtml(obs) {
  const chips = (obs.evidenceRefs || []).map((r) => `<span class="chip">${escapeHtml(String(r))}</span>`).join('');
  let actions;
  if (obs.decision === 'confirmed') {
    actions = `<div class="obs-state-line">✓ 已确认 · 已写入档案（L4 user-confirmed + L5 决策）</div>
      <div class="card-actions"><button class="mini" data-obs-revert="${obs.id}">撤销这条决定</button></div>`;
  } else if (obs.decision === 'rejected') {
    actions = `<div class="obs-state-line">✕ 已否决 · 已写入 L5 决策记录，后续生成排除这条</div>
      <div class="card-actions"><button class="mini" data-obs-revert="${obs.id}">撤销否决</button></div>`;
  } else {
    actions = `<div class="card-actions">
        <button class="mini ok" data-obs-confirm="${obs.id}">✓ 确认</button>
        <button class="mini no" data-obs-reject="${obs.id}">✕ 不对</button>
        <span class="obs-hint">点击卡片在画布看锚点</span>
      </div>`;
  }
  return `<div class="obs-card" data-source="${obs.source}" data-obs-id="${obs.id}">
    <div class="obs-top">${sourceBadge(obs.source)}${confidenceMarkup(obs)}
      <span style="margin-left:auto;font-size:10px;color:#5f7692">${escapeHtml(obs.displayIndex ? 'L4-' + obs.displayIndex : 'L1')}</span>
    </div>
    <div class="obs-text">${escapeHtml(obs.text)}</div>
    <div class="chips">${chips}</div>
    ${actions}
  </div>`;
}
function directionCardHtml(d, i) {
  const active = state.selectedDirectionId === d.id;
  return `<div class="dir-card ${active ? 'active' : ''}" data-dir-id="${d.id}">
    <div class="check">✓</div>
    <div class="dir-tag">方向 ${i + 1} · ${(d.tags || []).join(' / ') || 'aligned'}</div>
    <h3>${escapeHtml(d.title)}</h3>
    <p>${escapeHtml(d.why || '')}</p>
    <div class="why">置信度 ${Math.round((d.confidence || 0.6) * 100)}% · 依据来自观察与档案字段</div>
  </div>`;
}
function proposalZoneHtml() {
  if (state.mode === 'attest') return '';
  if (!state.selectedDirectionId) return '<div class="gen-note" style="margin-top:10px">↑ 选一个方向后，才会生成图片（本地 Mock）。</div>';
  if (state.generating) {
    return `<div class="progress-wrap">
      <div class="progress-label"><span>正在用 canvas 滤镜生成 2 个模拟方案…</span><span>Mock</span></div>
      <div class="progress"><i></i></div></div>`;
  }
  if (!state.proposals.length) {
    return `<button class="btn primary big" id="btnGenProposals">根据方向生成 2 个模拟方案</button>
      <div class="gen-note">模拟方式：canvas 滤镜 + 色块，不调用图像模型、不产生网络请求。</div>`;
  }
  const preview = state.proposals.find((p) => p.id === state.previewProposalId);
  const cards = state.proposals.map((p) => {
    const committed = state.committedProposalId === p.id;
    return `<div class="prop-card ${preview && preview.id === p.id ? 'active' : ''}" data-prop-id="${p.id}">
      <img class="prop-thumb" src="${p.imageDataUrl}" alt="${escapeHtml(p.label)}">
      <div class="prop-info">
        <div class="prop-badge">${committed ? '✓ 已落盘为 AI 图层' : '模拟生成 · 未调用模型'}</div>
        <div class="t">${escapeHtml(p.label)}</div>
        <div class="s">${escapeHtml(p.why || '')}</div>
      </div>
    </div>`;
  }).join('');
  const bar = preview ? `<div class="preview-bar">
      <div class="pt">画布上正在预览「${escapeHtml(preview.label)}」· 虚线框内为模拟方案，尚未落盘</div>
      <div class="pr">
        <button class="btn primary" id="btnAcceptProposal">保留为新图层</button>
        <button class="btn" id="btnCancelPreview">放弃预览</button>
      </div></div>` : '';
  return `<div class="prop-grid">${cards}</div>${bar}
    <div class="gen-note">点击方案在画布预览；接受后落为独立 AI 图层（可拖动 / 隐藏 / 删除 / 撤销）。</div>`;
}

export function renderAiPanel() {
  const el = $('aiBody');
  if (!el) return;
  const prevScroll = el.scrollTop;
  const restore = () => { el.scrollTop = prevScroll; };

  if (state.mode === 'attest') {
    el.innerHTML = `<div class="ai-disabled">
        <div class="shield">⛨</div>
        <h3>存证模式 · AI 已关闭</h3>
        <p>当前作品不调用任何 AI 观察与生成。画布、图层、撤销照常可用；导出的证据包会带上<br><b>zero_generation + 零生成声明</b>。</p>
      </div>
      <div class="ai-note">想恢复 AI 协作：点顶栏「协作模式」。</div>`;
    restore();
    updateStatusBar();
    return;
  }
  if (state.aiBusy && !state.observations.length) {
    el.innerHTML = `<div class="progress-wrap">
        <div class="progress-label"><span>AI 正在读你的画与档案…</span><span>Mock</span></div>
        <div class="progress"><i></i></div></div>
      <div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div>
      <div class="gen-note">本地 Mock AI：不调用真实模型、不上传画布、无网络请求。</div>`;
    restore();
    return;
  }
  if (!state.observations.length) {
    const selText = state.selection
      ? `当前指认区域：${bboxArray(state.selection).join(' × ')}（宽 × 高）`
      : '尚未框选：AI 将默认看画面中部';
    el.innerHTML = `<div class="ai-intro">
        <ol>
          <li><span class="n">1</span>用「框选」在画布上圈出卡住的地方（零文字）</li>
          <li><span class="n">2</span>点下面按钮，AI 基于你的档案给 2–4 条观察 + 2 个方向</li>
          <li><span class="n">3</span>选方向 → 生成模拟方案 → 接受后落为新图层</li>
        </ol>
      </div>
      <div class="gen-note" style="margin:-2px 0 9px">${selText}</div>
      <button class="btn primary big" id="btnAskAiPanel">让 AI 看看</button>
      <label class="switch"><input type="checkbox" id="chkIgnoreArchive" ${state.ignoreArchive ? 'checked' : ''}> 本次不参考我的档案（D4 · 跳出既有偏好）</label>
      <div class="ai-note">⚠️ AI 客户端：<b>${escapeHtml(aiClientInfo)}</b>（确定性 mock 规则 + canvas 滤镜）；观察卡上的锚点、置信度、来源标记为真实交互数据结构。</div>`;
    bindPanelOnce(el);
    restore();
    updateStatusBar();
    return;
  }
  const allObs = state.observations;
  const reveal = Number.isInteger(state.observationsReveal) ? clamp(state.observationsReveal, 0, allObs.length) : allObs.length;
  const visObs = allObs.slice(0, reveal);
  const lowCount = visObs.filter((o) => o.confidence != null && o.confidence < 0.5).length;
  const rejectedConstraints = state.decisions.filter((d) => d.kind === 'reject_ai').length;
  const ctxLine = state.aiReview
    ? `指认 ${Math.round(state.aiReview.analyze ? (state.selection?.w || 0) : 0)}×${Math.round(state.selection?.h || 0)} · 参考档案 ${state.ignoreArchive ? '0（本次不参考）' : state.archive.length} 条 · 模型 ${escapeHtml(state.aiReview.model)} · ${state.aiReview.latencyMs}ms（本地 Mock）`
    : '';
  el.innerHTML = `
    ${state.ignoreArchive ? '<div class="statement warn" style="margin-bottom:9px">本次请求未参考你的档案（通用模式），以下基于通用审美。</div>' : ''}
    <div class="src-legend">三态用「图标 + 文字 + 边框形状」区分，不只靠颜色：实线 = 可见事实 · 虚线 = AI 推断（不是事实） · 双线 = 你确认。</div>
    <div class="gen-note" style="margin:0 0 8px">${ctxLine}</div>
    <div class="obs-list">${visObs.map(observationCardHtml).join('')}${reveal < allObs.length ? '<div class="skeleton" style="height:44px"></div>' : ''}</div>
    ${lowCount ? `<div class="statement warn" style="margin:0 0 10px">AI 对其中的 ${lowCount} 条没有把握，已标「待确认」；低置信不作为生成硬约束。</div>` : ''}
    <div class="section-title">方向候选 <span>选一个方向 → 生成模拟方案</span></div>
    <div class="dir-list">${state.directions.map(directionCardHtml).join('')}</div>
    ${proposalZoneHtml()}
    <div class="ai-note">${rejectedConstraints ? `已排除 ${rejectedConstraints} 条你否决过的约束 · ` : ''}观察与方向来自本地 Mock（${escapeHtml(state.aiReview?.model || 'mock-ai@0.1.0')}），方案来自 canvas 滤镜。</div>`;
  bindPanelOnce(el);
  restore();
  updateStatusBar();
}

// 面板事件一次性委托（避免每次重渲染重复绑定）
let panelBound = false;
function bindPanelOnce(el) {
  if (panelBound) return;
  panelBound = true;
  el.addEventListener('click', (e) => {
    const t = e.target.closest('[data-obs-confirm],[data-obs-reject],[data-obs-revert],[data-dir-id],[data-prop-id],#btnGenProposals,#btnAcceptProposal,#btnCancelPreview,#btnAskAiPanel');
    if (!t) {
      const card = e.target.closest('.obs-card');
      if (card) {
        const id = card.dataset.obsId;
        state.highlightObsId = state.highlightObsId === id ? null : id;
        renderAiPanel();
        renderOverlay();
      }
      return;
    }
    e.stopPropagation();
    if (t.dataset.obsConfirm) decideObservation(t.dataset.obsConfirm, 'confirm');
    else if (t.dataset.obsReject) decideObservation(t.dataset.obsReject, 'reject');
    else if (t.dataset.obsRevert) revertObservationDecision(t.dataset.obsRevert);
    else if (t.dataset.dirId) selectDirection(t.dataset.dirId);
    else if (t.dataset.propId) previewProposal(t.dataset.propId);
    else if (t.id === 'btnGenProposals') generateProposals();
    else if (t.id === 'btnAcceptProposal') acceptProposal();
    else if (t.id === 'btnCancelPreview') cancelPreview();
    else if (t.id === 'btnAskAiPanel') askAi();
  });
  el.addEventListener('change', (e) => {
    if (e.target && e.target.id === 'chkIgnoreArchive') setIgnoreArchive(e.target.checked);
  });
  el.addEventListener('mouseover', (e) => {
    const card = e.target.closest('.obs-card');
    if (card) { state.hoverObsId = card.dataset.obsId; renderOverlay(); }
  });
  el.addEventListener('mouseout', (e) => {
    const card = e.target.closest('.obs-card');
    if (card) { state.hoverObsId = null; renderOverlay(); }
  });
}

/* ============================ 关于 / 引导 ============================ */
export async function openAbout() {
  $('aboutModal').classList.add('open');
  const { listProjects } = await import('./db.js');
  let projects = 1;
  try { projects = (await listProjects()).length || 1; } catch (e) { /* ignore */ }
  const set = (id, v) => { const el = $(id); if (el) el.textContent = String(v); };
  const stats = evidenceStats();
  set('aboutProjects', projects);
  set('aboutLayers', state.layers.length);
  set('aboutArchive', stats.archive);
  set('aboutEvents', stats.events);
  set('aboutHash', state.hashBackend);
  set('aboutAi', aiClientInfo);
}

function bindOnboarding() {
  $('btnOnbStart').addEventListener('click', () => dismissOnboarding(false));
  $('btnOnbExample').addEventListener('click', async () => {
    dismissOnboarding(false);
    await call('app.loadExample');
  });
  const demoBtn = $('btnOnbDemo');
  if (demoBtn) {
    demoBtn.addEventListener('click', async () => {
      dismissOnboarding(false);
      try { await call('app.startDemo'); } catch (e) { console.warn(e); }
    });
  }
}
export function showOnboarding() { $('onboarding').classList.add('open'); }
export function hideOnboarding() { $('onboarding').classList.remove('open'); }
async function dismissOnboarding() {
  hideOnboarding();
  try {
    const { saveMeta } = await import('./db.js');
    await saveMeta('onboardingDone', true);
  } catch (e) { /* ignore */ }
}

/** 供演示脚本控制观察卡逐条出现 */
export function revealObservations(count) {
  state.observationsReveal = count;
  renderAiPanel();
}
export function flashLayerRow(layerId) {
  const row = document.querySelector(`.layer-row[data-id="${layerId}"]`);
  if (!row) return;
  row.classList.add('demo-flash');
  setTimeout(() => row.classList.remove('demo-flash'), 1600);
}
export function setAiClientInfo(text) { aiClientInfo = text; }
export function getAiClient() { return ai; }
