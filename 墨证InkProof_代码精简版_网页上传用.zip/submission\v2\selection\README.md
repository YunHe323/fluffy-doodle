# v2 selection · 选区与变换（T37）

> 依赖 T35 `v2/engine` 与 T37 `v2/layers`（只读复用，**未修改 engine/layers 实现**）。
> 演示：`v2/selection/demo.html`｜测试：`v2/layers/test/t37-smoke.mjs selection`｜结果：`v2/layers/results/selection-smoke.json`

## T63 完整能力与接口（app T64）

- 形状：矩形 `rect`、椭圆 `ellipse`、自由套索 `lasso`、魔棒 `wandAt`；布尔 `mode='add'|'subtract'|'intersect'|'replace'`；羽化 `setFeather(0–50)`；蚂蚁线自动。
- 变换：`beginTransform(layerId)` / `updateTransform` / `commitTransform`（1 步 undo）/ `cancelTransform`；`getTransformHandles()` 返回 8 缩放手柄 + rotate；`hitTestHandle`；`dragHandle(id,x,y,{snap:true})`（旋转 15° 吸附）；有选区时只变换选区内像素。
- 约束引擎：`engine.setSelectionImage(sm.getMaskImage())`；`sm.clear()` 同步 `engine.clearSelection()`。
- 测试：`test/selection.mjs`；接口细节见 `06-技术/T63_选区变换与结构undo.md`。

## 目录

```
v2/selection/
├─ demo.html        # 矩形/套索/魔棒 + 布尔 + 羽化 + 蚂蚁线 + 约束绘制 + 变换
└─ selection.js     # SelectionManager：选区掩码/布尔/羽化/蚂蚁线/约束/变换
```

## 运行

```powershell
node v2/serve.mjs          # 或 python -m http.server 8899 --bind 127.0.0.1
# http://127.0.0.1:4200/v2/selection/demo.html
```

## 选区模型

- 掩码：全分辨率（2048²）离屏 2D canvas（alpha 通道，255=选中）。
- 工具：
  - 矩形 `rect(x0,y0,x1,y1,mode,feather)`
  - 套索 `lasso(points,mode,feather)`
  - 魔棒 `wandAt(x,y,mode,tolerance)`：从当前合成图取样，在 512² 降采样上 flood fill，再放大到全分辨率
- 布尔：`mode = add | subtract | intersect`（Canvas2D `source-over/destination-out/destination-in`）
- 羽化：`setFeather(px)` 0–50，生成掩码时 blur
- 蚂蚁线：独立覆盖层（1024²，CSS 拉伸到画布），虚线每 120ms 动画；矩形/套索画轮廓，魔棒暂无轮廓（见限制）
- 约束绘制：`LayerSystem.setSelectionImage(CKImage)`；笔触提交的每个受影响 tile 用 `DstIn` 与掩码相乘 → 选区外像素不落盘。实测：选区外画整笔，合成无变化（`constrained=true`）。
- 变换：
  - `beginTransform(layerId,{useSelection})` → 捕获整层 before 图像
  - `updateTransform({x,y,scaleX,scaleY,rotate,flipH,flipV})`（rotate 为**角度**，CanvasKit `rotate(deg,rx,ry)`）
  - `commitTransform()`：有选区时只变换选区内像素，选区外保留原图；写入图层并 push **1 个 image undo**
  - `cancelTransform()`；`ls.undo()` 可撤销变换
  - 预览：`setTransformPreview({x,y,scaleX,scaleY,rotate})` 在覆盖层画蓝色包围框

## 接口（SelectionManager）

| 方法 | 说明 |
|---|---|
| `rect/lasso/wandAt/selectAll` | 创建/追加选区（mode 决定布尔） |
| `clear` | 清空选区并通知 LayerSystem |
| `setFeather(px)` | 羽化 0–50 |
| `hasSelection` | 是否有非空选区 |
| `getMaskImage()` | 返回 CanvasKit Image（alpha 掩码） |
| `beginTransform/updateTransform/commitTransform/cancelTransform` | 变换（提交=1 步 undo） |
| `setTransformPreview(preview)` | 覆盖层包围框预览 |
| `dispose()` | 停止蚂蚁线定时器 |

## 冒烟结果（2026-11-06，Headless Chrome + RTX 4060/D3D11）

`results/selection-smoke.json`：`ok=true`；矩形选区 `hasSelection=true`；**选区外整笔绘制 `constrained=true`（合成无变化）**；选区内绘制生效；变换 `undoDepth 6 → undo 后 5`；魔棒选区成功；PNG 192,899B；内存估算 198.5MB。

```powershell
node v2/layers/test/t37-smoke.mjs selection http://127.0.0.1:8899/v2/selection/demo.html 9333
```

## 已知限制 / 差异

1. **魔棒**：512² 降采样 flood fill（精度/性能折中）；全分辨率边缘未做 refine。
2. **蚂蚁线**：魔棒无轮廓（仅提示有选区）；套索/矩形为轮廓虚线。
3. **变换**：按钮式（方向/缩放/旋转/翻转）+ 包围框预览，**无自由变换手柄/斜切**；旋转以画布中心为轴；每步 undo 为整层图像快照（2048² ≈16MB/步，history 增长快；M4.5 优化）。
4. 选区约束只作用于**笔触提交**；实时绘制阶段不做 clip（选区存在时看不到落笔预览，松手后生效）。
5. 选区不参与导出/PSD（M4.4 再说）；无选区反选/存储/通道面板。
6. 羽化在 2D 侧 blur，超大羽化半径性能一般。

## P0 交互卡对应

- T37 任务卡要求：矩形/套索/魔棒、布尔、羽化、蚂蚁线、约束绘制/擦除/变换；变换移动/缩放/旋转/翻转、包围盒、提交=1 步 undo。本实现覆盖上述主路径；差异见上（无自由手柄、魔棒/蚂蚁线近似）。
- 与 v2 规格的逐条对照（C1–C8 图层、B1–B2 选区/变换）在 M4.3 验收时由 Lead 复核。

## 许可 / 范围

- 本目录自制代码；CanvasKit 经 `v2/engine/vendor` 引用（BSD-3）。
- 写入范围：`v2/selection/`；未改 `v2/engine/`、`v2/layers/`、`product/`。
