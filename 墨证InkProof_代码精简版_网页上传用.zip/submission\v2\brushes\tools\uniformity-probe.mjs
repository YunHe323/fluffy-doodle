/**
 * v2/brushes/tools/uniformity-probe.mjs · T59 均匀度诊断
 * 复刻 QA T51 harness 的 S1/S2 场景与 thicknessCV 口径（12 段密度 CV），
 * 在真实浏览器（默认 headless + 真实 GPU）里画同样的笔迹，对比多组参数，定位不均来源。
 *
 * 用法（项目根目录，先 node v2/serve.mjs）：
 *   node v2/brushes/tools/uniformity-probe.mjs [--headed]
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
const OUT = path.join(ROOT, 'v2', 'brushes', 'samples', 'uniformity');
fs.mkdirSync(OUT, { recursive: true });
const CDP_PORT = Number((process.argv.find((a) => a.startsWith('--cdp=')) || '').split('=')[1] || 9590);
const HEADLESS = !process.argv.includes('--headed');
function resolveBase() {
  if (process.env.INKPROOF_BASE) return process.env.INKPROOF_BASE;
  try {
    const port = fs.readFileSync(path.join(ROOT, 'v2', '.runtime-port'), 'utf8').trim();
    if (/^\d+$/.test(port)) return 'http://127.0.0.1:' + port;
  } catch (e) { /* ignore */ }
  return 'http://127.0.0.1:4200';
}
const URL_ARG = `${resolveBase()}/v2/brushes/demo.html`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const EDGE = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
].find((p) => fs.existsSync(p));

// 与 QA harness 完全一致（v2/qa/tools/harness.mjs）
const S1 = (() => { const a = []; for (let i = 0; i <= 40; i += 1) { const t = i / 40; a.push([0.12 + 0.76 * t, 0.5 + 0.28 * Math.sin(t * Math.PI * 2)]); } return a; })();
const S2 = [[0.10, 0.50], [0.20, 0.24], [0.30, 0.20], [0.44, 0.38], [0.56, 0.62], [0.70, 0.78], [0.84, 0.72], [0.92, 0.50]];
const SEGMENTS = 12;

const STATS_FN = `window.__UNIFORM__ = {
  async load(src) { const img = new Image(); img.src = src; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const x = c.getContext('2d'); x.drawImage(img, 0, 0);
    return { w: c.width, h: c.height, d: x.getImageData(0, 0, c.width, c.height).data }; },
  async stats(curUrl, refUrl, points) {
    const cur = await this.load(curUrl); const ref = refUrl ? await this.load(refUrl) : null;
    const W = cur.w, H = cur.h; const points2 = points || [];
    let ink = 0;
    const seg = new Array(${SEGMENTS}).fill(0);
    const samples = new Array(${SEGMENTS}).fill(0);
    const centers = [];
    for (let s = 0; s < ${SEGMENTS}; s += 1) {
      if (!points2.length) { centers.push(null); continue; }
      const t = (s + 0.5) / ${SEGMENTS};
      const fi = Math.min(points2.length - 1, t * (points2.length - 1));
      const i0 = Math.floor(fi), i1 = Math.min(points2.length - 1, i0 + 1), f = fi - i0;
      const px = points2[i0][0] + (points2[i1][0] - points2[i0][0]) * f;
      const py = points2[i0][1] + (points2[i1][1] - points2[i0][1]) * f;
      const r = Math.max(8, Math.min(44, Math.round(Math.min(W, H) * 0.05)));
      centers.push({ x: Math.round(px * W), y: Math.round(py * H), r });
    }
    const STEP = 2;
    for (let y = 0; y < H; y += STEP) for (let x = 0; x < W; x += STEP) {
      const i = (y * W + x) * 4;
      const bg = cur.d[i] < 34 && cur.d[i + 1] < 36 && cur.d[i + 2] < 42;
      let isInk;
      if (ref && ref.w === W && ref.h === H) isInk = !bg && (Math.abs(cur.d[i] - ref.d[i]) > 24 || Math.abs(cur.d[i + 1] - ref.d[i + 1]) > 24 || Math.abs(cur.d[i + 2] - ref.d[i + 2]) > 24);
      else isInk = !bg && cur.d[i + 3] > 8 && cur.d[i] < 200;
      if (!isInk) continue;
      ink += 1;
      for (let s = 0; s < ${SEGMENTS}; s += 1) { const c0 = centers[s]; if (!c0) continue; samples[s] += 1; if (Math.abs(x - c0.x) <= c0.r && Math.abs(y - c0.y) <= c0.r) seg[s] += 1; }
    }
    const dens = seg.map((v, s) => (samples[s] ? v / samples[s] : 0));
    const covered = dens.filter((v) => v > 0.01).length;
    const mean = dens.reduce((a, b) => a + b, 0) / dens.length;
    const sd = Math.sqrt(dens.reduce((a, b) => a + (b - mean) * (b - mean), 0) / dens.length);
    return { ink, breakpoints: ${SEGMENTS} - covered, thicknessCV: mean > 0 ? Math.round((sd / mean) * 1000) / 1000 : null, dens: dens.map((v) => Math.round(v * 1000) / 1000) };
  }
}; 'ok'`;

let ws = null; let msgId = 0; const pending = new Map();
const send = (method, params = {}) => new Promise((resolve) => { const id = ++msgId; pending.set(id, resolve); ws.send(JSON.stringify({ id, method, params })); });
async function ev(expression, timeoutMs = 60000) {
  const r = await Promise.race([send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true }), sleep(timeoutMs).then(() => ({ __t: true }))]);
  if (r.__t) throw new Error('timeout');
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1200));
  return r.result?.result?.value;
}

const profile = path.join(os.tmpdir(), 'uni-' + Date.now());
const args = ['--remote-debugging-port=' + CDP_PORT, '--user-data-dir=' + profile, '--no-first-run', '--no-default-browser-check'];
if (HEADLESS) args.push('--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1400,1000');
else args.push('--window-size=1400,1000', '--window-position=-3000,-3000', '--start-minimized');
args.push(URL_ARG);
const browser = spawn(EDGE, args, { stdio: 'ignore' });
const report = { schema: 'inkproof.uniformity-probe.v1', url: URL_ARG, headless: HEADLESS, cases: [], ok: false };

try {
  let target = null;
  for (let i = 0; i < 400 && !target; i += 1) {
    try { const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json(); target = list.find((t) => t.type === 'page' && /^https?:/.test(t.url)); } catch (e) { /* wait */ }
    if (!target) await sleep(150);
  }
  if (!target) throw new Error('no target');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { const r = pending.get(m.id); pending.delete(m.id); r(m); } };
  await send('Runtime.enable');
  const t0 = Date.now();
  while (Date.now() - t0 < 90000) { if (await ev('!!window.__BRUSH_READY__').catch(() => false)) break; await sleep(250); }
  await ev(STATS_FN);
  const rect = await ev(`(() => { const r = document.getElementById('stage').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
  const W = 1600, H = 1000;
  const grabBlank = async () => {
    await ev(`(() => { const e = window.__V2__; let g = 0; while (e.canUndo() && g < 400) { e.undo(); g += 1; } e.compositor.compositeAll(e.store); return g; })()`);
    await sleep(200);
    return ev(`window.__V2__.getCompositeDataUrl()`);
  };
  const toClient = (u, v) => ({ x: Math.round(rect.x + rect.w * u), y: Math.round(rect.y + rect.h * v) });
  const REAL_TS = process.argv.includes('--real-ts');
  const drawPath = async (norm, stepMs) => {
    // 默认用 CDP timestamp 固定事件时间戳 → 速度估计可复现；--real-ts 模拟 QA Playwright 的真实 sleep 时序
    const baseSec = Date.now() / 1000;
    const p0 = toClient(norm[0][0], norm[0][1]);
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: p0.x, y: p0.y, button: 'left', buttons: 1, clickCount: 1, pointerType: 'mouse', ...(REAL_TS ? {} : { timestamp: baseSec }) });
    for (let i = 1; i < norm.length; i += 1) {
      const p = toClient(norm[i][0], norm[i][1]);
      await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: p.x, y: p.y, button: 'left', buttons: 1, pointerType: 'mouse', ...(REAL_TS ? {} : { timestamp: baseSec + (i * stepMs) / 1000 }) });
      await sleep(REAL_TS ? stepMs : 2);
    }
    const pe = toClient(norm[norm.length - 1][0], norm[norm.length - 1][1]);
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: pe.x, y: pe.y, button: 'left', buttons: 0, clickCount: 1, pointerType: 'mouse', ...(REAL_TS ? {} : { timestamp: baseSec + (norm.length * stepMs) / 1000 }) });
    await sleep(300);
    await ev(`window.__V2__.compositor.compositeAll(window.__V2__.store)`);
    return ev(`window.__V2__.getCompositeDataUrl()`);
  };
  const applyCase = async (c) => {
    // 重置：笔刷 0（hard-round）、默认参数（setPreset 会重建 provider，保留 simulatedPressure 配置）
    await ev(`document.querySelectorAll('.brushBtn')[0].click()`);
    await sleep(120);
    await ev(`(() => { const c = window.__BRUSH_DEMO__.controller; c.setPreset(window.__BRUSH_DEMO__.presets.brushes[0]); return true; })()`);
    if (c.simulated) await ev(`window.__BRUSH_DEMO__.controller.setSimulatedPressure(${JSON.stringify(c.simulated)})`);
    if (c.pressureCurve) await ev(`window.__BRUSH_DEMO__.controller.setParam('size.pressureCurve', ${JSON.stringify(c.pressureCurve)})`);
    if (c.floorScale != null) await ev(`window.__BRUSH_DEMO__.controller.setParam('size.floorScale', ${c.floorScale})`);
    if (c.radiusSmooth != null) await ev(`window.__BRUSH_DEMO__.controller.setParam('smoothing.radiusSmooth', ${c.radiusSmooth})`);
    if (c.spacingRatio != null) await ev(`window.__BRUSH_DEMO__.controller.setParam('spacing.ratio', ${c.spacingRatio})`);
    if (c.sizeBase != null) await ev(`window.__BRUSH_DEMO__.controller.setParam('size.base', ${c.sizeBase})`);
    await sleep(120);
  };
  const blank = await grabBlank();
  const cases = [
    { id: 'sm45', label: 'T54 默认 smoothingMs 45（T59 起笔修正后）', simulated: { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 45 } },
    { id: 'sm65', label: 'smoothingMs 65', simulated: { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 65 } },
    { id: 'sm85', label: 'smoothingMs 85', simulated: { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 85 } },
    { id: 'sm65-floor0.2', label: 'smoothingMs 65 + floorScale 0.20', simulated: { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 65 }, floorScale: 0.20 },
    { id: 't54-off', label: '关闭模拟压感（参考）', simulated: { enabled: false } },
  ];
  const REPEATS = Number((process.argv.find((a) => a.startsWith('--repeats=')) || '').split('=')[1] || 2);
  const radiusProbe = `(() => { const c = window.__BRUSH_DEMO__.controller; const CK = window.__V2__.CK;
    const out = {};
    for (const pr of [0.1, 0.2, 0.35, 0.5, 0.8]) {
      const ctx = { CK, pressure: pr, worldX: 100, worldY: 100, index: 5, distance: 100, tiltX: 0, tiltY: 0, brush: c.brushSpec, pointerType: 'mouse' };
      try { out[pr] = Math.round(c.provider.radiusFor(ctx) * 10) / 10; } catch (e) { out[pr] = String(e.message); }
    }
    return { curve: c.preset.size.pressureCurve, floor: c.preset.size.floorScale, rs: (c.preset.smoothing || {}).radiusSmooth, radii: out }; })()`;
  for (const c of cases) {
    await applyCase(c);
    const entry = { id: c.id, label: c.label, S1runs: [], S2runs: [] };
    if (c.debug) entry.radiusProbe = await ev(radiusProbe);
    for (let rep = 0; rep < REPEATS; rep += 1) {
      for (const [scen, norm, stepMs] of [['S1', S1, 12], ['S2', S2, 3]]) {
        const blankUrl = await grabBlank();
        const url = await drawPath(norm, stepMs);
        const st = await ev(`window.__UNIFORM__.stats(${JSON.stringify(url)}, ${JSON.stringify(blankUrl)}, ${JSON.stringify(norm)})`);
        (scen === 'S1' ? entry.S1runs : entry.S2runs).push({ ink: st.ink, breakpoints: st.breakpoints, thicknessCV: st.thicknessCV, dens: st.dens });
        if (rep === 0 && c.id === 'baseline') {
          fs.writeFileSync(path.join(OUT, `baseline-${scen}.png`), Buffer.from(url.split(',')[1], 'base64'));
        }
      }
    }
    const med = (arr, key) => { const v = arr.map((x) => x[key]).filter((x) => x != null).sort((a, b) => a - b); return v.length ? v[Math.floor(v.length / 2)] : null; };
    entry.S1 = { cv: med(entry.S1runs, 'thicknessCV'), bp: med(entry.S1runs, 'breakpoints'), ink: med(entry.S1runs, 'ink') };
    entry.S2 = { cv: med(entry.S2runs, 'thicknessCV'), bp: med(entry.S2runs, 'breakpoints'), ink: med(entry.S2runs, 'ink') };
    report.cases.push(entry);
    console.log(c.id, JSON.stringify(entry.radiusProbe || {}), '| S1 CV', entry.S1.cv, 'bp', entry.S1.bp, 'ink', entry.S1.ink, '| S2 CV', entry.S2.cv, 'bp', entry.S2.bp, 'ink', entry.S2.ink);
    if (entry.S1runs[0] && entry.S1runs[0].dens) console.log('   S1 dens', JSON.stringify(entry.S1runs[0].dens));
  }
  report.ok = true;
  fs.writeFileSync(path.join(OUT, 'probe.json'), JSON.stringify(report, null, 2));
} catch (e) {
  report.fatal = String(e && e.stack || e);
  console.log(JSON.stringify({ ok: false, fatal: report.fatal }, null, 2));
  try { fs.writeFileSync(path.join(OUT, 'probe.json'), JSON.stringify(report, null, 2)); } catch (err) { /* ignore */ }
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  try { browser.kill(); } catch (e) { /* ignore */ }
  await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  process.exit(report.ok ? 0 : 1);
}
