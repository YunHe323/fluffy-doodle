// spike/canvaskit/adapter.js
// ---------------------------------------------------------------------
// CanvasKit (Skia WASM 0.42.0, BSD-3-Clause) · BenchAdapter 实现（T26 / R2）
// 契约：bench/README.md §3；结果格式：mozheng.bench.v1
//
// 实现摘要（spike 级，可丢弃）：
// - 渲染：CanvasKit MakeWebGLCanvasSurface（GPU/WebGL2；失败回退 CPU MakeCanvasSurface）
// - 图层：每个图层 = 有序 SkPicture 列表（retained picture），按 layer blend 合成；
//         每笔 = 一个 Picture（矢量 stamp 记录），undo = 弹出 Picture（无需整层快照）
// - tile：256² tile 索引（决定脏区/合成范围；稀疏层不分配 tile 纹理）；
//         脏 tile 合成：只 clip 重绘受影响 tile（tile 数过多时退回全量）
// - 笔刷：硬边 / 软边（blur mask）/ 铅笔 / 纹理（确定性散点），压感映射半径与透明度
// - 混合：normal(SrcOver) / multiply / screen / overlay / soft-light（saveLayer 图层级混合）
// - 输入：beginStroke → 记录 Picture + 直接画到屏上（即时反馈）；endStroke → 入层 + 脏 tile 合成
//
// 许可：CanvasKit / Skia 为 BSD-3-Clause（vendor/LICENSE）；本项目自制代码。
// 已知简化（见评估报告）：每笔一次合成（非帧内 tile 增量）；无 PSD；无湿边/双笔刷；B6 只 undo 实际存在的笔画。
// ---------------------------------------------------------------------
(function () {
  'use strict';

  const script = document.currentScript;
  const BASE = (script && script.src ? script.src : location.href).replace(/adapter\.js(?:[?#].*)?$/, '');
  const VENDOR_JS = `${BASE}vendor/canvaskit.js`;
  const VENDOR_VERSION = '0.42.0';
  const TILE = 256;

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const el = document.createElement('script');
      el.src = src;
      el.onload = () => resolve();
      el.onerror = () => reject(new Error(`无法加载 ${src}`));
      document.head.appendChild(el);
    });
  }

  async function ensureCanvasKit() {
    if (window.CanvasKit) return window.CanvasKit;
    if (!window.CanvasKitInit) {
      try {
        await loadScript(VENDOR_JS);
      } catch (e) {
        throw new Error(
          `CanvasKit vendor 未就位：找不到 ${VENDOR_JS}。请把 canvaskit.js / canvaskit.wasm 放到 spike/canvaskit/vendor/（见 README §2）。`
        );
      }
    }
    if (typeof window.CanvasKitInit !== 'function') {
      throw new Error('vendor/canvaskit.js 已加载但未提供 CanvasKitInit()，请检查文件是否完整。');
    }
    return window.CanvasKitInit({ locateFile: (file) => `${BASE}vendor/${file}` });
  }

  function bytesToBase64(bytes) {
    let out = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      const slice = bytes.subarray(i, i + chunk);
      let s = '';
      for (let j = 0; j < slice.length; j += 1) s += String.fromCharCode(slice[j]);
      out += btoa(s);
    }
    return out;
  }

  const BLEND_KEY = { normal: 'SrcOver', multiply: 'Multiply', screen: 'Screen', overlay: 'Overlay', 'soft-light': 'SoftLight' };

  window.BenchAdapter = {
    id: 'canvaskit',
    version: `canvaskit-wasm@${VENDOR_VERSION}+spike`,
    license: 'BSD-3-Clause',

    /** @param {{canvas:HTMLCanvasElement,width:number,height:number,layers:number,brush?:{type:string,sizePx:number}}} config */
    async init(config) {
      const CK = await ensureCanvasKit();
      this._CK = CK;
      this._canvas = config.canvas;
      this._width = config.width;
      this._height = config.height;
      this._tilesW = Math.ceil(this._width / TILE);
      this._tilesH = Math.ceil(this._height / TILE);
      this._brush = config.brush || { type: 'soft-round', sizePx: 32 };
      this._layerCount = Math.max(1, config.layers || 1);
      this._layers = Array.from({ length: this._layerCount }, () => ({ pictures: [], blend: 'normal', tiles: new Map() }));
      this._active = this._layerCount - 1;
      this._history = [];
      this._dirtyTiles = new Set();
      this._maskCache = new Map();
      this._flushScheduled = false;

      let surface = null;
      let path = null;
      try {
        surface = CK.MakeWebGLCanvasSurface(this._canvas, undefined, { majorVersion: 2, antialias: 1 });
        path = surface ? 'MakeWebGLCanvasSurface(WebGL2)' : null;
      } catch (e) { path = null; }
      if (!surface) {
        surface = CK.MakeCanvasSurface(this._canvas);
        path = surface ? 'MakeCanvasSurface(CPU)' : null;
      }
      if (!surface) throw new Error('CanvasKit: surface 创建失败（检查 canvas/WebGL 上下文）');
      this._surface = surface;
      this._ckCanvas = surface.getCanvas();
      this._rendererPath = path;

      this._paint = new CK.Paint();
      this._paint.setAntiAlias(true);
      this._paint.setStyle(CK.PaintStyle.Fill);
      this._layerPaint = new CK.Paint();

      this._fullComposite();
      this._surface.flush();
      this._ckCanvas.clear(CK.WHITE);
      this._surface.flush();
    },

    // ---------- 内部：图元/合成 ----------
    _tileRange(x0, y0, x1, y1) {
      const tx0 = Math.max(0, Math.floor(x0 / TILE));
      const ty0 = Math.max(0, Math.floor(y0 / TILE));
      const tx1 = Math.min(this._tilesW - 1, Math.floor(x1 / TILE));
      const ty1 = Math.min(this._tilesH - 1, Math.floor(y1 / TILE));
      const keys = [];
      for (let ty = ty0; ty <= ty1; ty += 1) for (let tx = tx0; tx <= tx1; tx += 1) keys.push(`${tx},${ty}`);
      return keys;
    },

    _tileRect(key) {
      const [tx, ty] = key.split(',').map(Number);
      return [tx * TILE, ty * TILE, TILE, TILE];
    },

    _blurFilter(sigma) {
      const key = sigma.toFixed(2);
      let filter = this._maskCache.get(key);
      if (!filter) {
        filter = this._CK.MaskFilter.MakeBlur(this._CK.BlurStyle.Normal, Math.max(0.5, sigma), true);
        this._maskCache.set(key, filter);
      }
      return filter;
    },

    _drawStamp(canvas, p) {
      const CK = this._CK;
      const paint = this._paint;
      const base = this._brush.sizePx || 32;
      const pressure = p.pressure == null ? 0.5 : p.pressure;
      const r = Math.max(0.5, base * 0.5 * (0.25 + pressure * 0.75));
      const type = this._brush.type || 'soft-round';
      paint.setBlendMode(CK.BlendMode.SrcOver);
      paint.setColor(CK.Color(31, 35, 40, 0.85));
      paint.setMaskFilter(type === 'soft-round' || type === 'texture' ? this._blurFilter(r * 0.35) : null);
      canvas.drawCircle(p.x, p.y, r, paint);
      if (type === 'pencil') {
        paint.setMaskFilter(null);
        paint.setColor(CK.Color(31, 35, 40, 0.75));
        canvas.drawCircle(p.x, p.y, Math.max(0.6, r * 0.35), paint);
      } else if (type === 'texture') {
        // 确定性散点（不依赖随机，保证同输入同输出）
        const seed = ((Math.round(p.x) * 73856093) ^ (Math.round(p.y) * 19349663)) >>> 0;
        for (let i = 0; i < 4; i += 1) {
          const a = (((seed >> (i * 3)) & 7) / 7) * Math.PI * 2;
          const d = r * 0.7 * ((((seed >> (i * 5)) & 15) / 15));
          const rr = Math.max(0.8, r * 0.14);
          canvas.drawCircle(p.x + Math.cos(a) * d, p.y + Math.sin(a) * d, rr, paint);
        }
      }
      return r;
    },

    _fullComposite() {
      const CK = this._CK;
      const c = this._ckCanvas;
      c.clear(CK.WHITE);
      for (const layer of this._layers) {
        if (layer.pictures.length === 0) continue;
        const blend = CK.BlendMode[BLEND_KEY[layer.blend] || 'SrcOver'];
        if (blend !== CK.BlendMode.SrcOver) {
          this._layerPaint.setBlendMode(blend);
          c.saveLayer(this._layerPaint);
        } else {
          c.save();
        }
        for (const pic of layer.pictures) c.drawPicture(pic);
        c.restore();
      }
      this._dirtyTiles.clear();
    },

    _compositeDirty() {
      if (this._dirtyTiles.size === 0) return;
      const CK = this._CK;
      const c = this._ckCanvas;
      const totalTiles = this._tilesW * this._tilesH;
      const dirty = [...this._dirtyTiles];
      this._dirtyTiles.clear();
      if (dirty.length > Math.max(8, totalTiles * 0.5)) {
        this._fullComposite();
        return;
      }
      for (const key of dirty) {
        c.save();
        c.clipRect(this._tileRect(key), CK.ClipOp.Intersect, false);
        c.clear(CK.WHITE);
        for (const layer of this._layers) {
          const bucket = layer.tiles.get(key);
          if (!bucket || bucket.length === 0) continue;
          const blend = CK.BlendMode[BLEND_KEY[layer.blend] || 'SrcOver'];
          if (blend !== CK.BlendMode.SrcOver) {
            this._layerPaint.setBlendMode(blend);
            c.saveLayer(this._layerPaint);
          } else {
            c.save();
          }
          for (const pic of bucket) c.drawPicture(pic);
          c.restore();
        }
        c.restore();
      }
    },

    _scheduleFlush() {
      if (this._flushScheduled) return;
      this._flushScheduled = true;
      requestAnimationFrame(() => {
        this._flushScheduled = false;
        try { this._surface.flush(); } catch (e) { /* ignore */ }
      });
    },

    // ---------- BenchAdapter 契约 ----------
    beginStroke(p) {
      const CK = this._CK;
      this._recorder = new CK.PictureRecorder();
      this._recCanvas = this._recorder.beginRecording([0, 0, this._width, this._height]);
      this._strokeTiles = new Set();
      this._lastPoint = p;
      this._stamp(p);
    },

    moveStroke(p) {
      this._lastPoint = p;
      this._stamp(p);
    },

    _stamp(p) {
      const r = this._drawStamp(this._recCanvas, p); // 记录到本笔 Picture
      this._drawStamp(this._ckCanvas, p);            // 即时反馈（当前屏）
      this._scheduleFlush();
      for (const key of this._tileRange(p.x - r, p.y - r, p.x + r, p.y + r)) this._strokeTiles.add(key);
      for (const key of this._strokeTiles) this._dirtyTiles.add(key);
    },

    endStroke() {
      let pic = null;
      try { pic = this._recorder.finishRecordingAsPicture(); } catch (e) { pic = null; }
      this._recorder = null;
      this._recCanvas = null;
      if (!pic) return;
      const layer = this._layers[this._active];
      layer.pictures.push(pic);
      const keys = [...this._strokeTiles];
      for (const key of keys) {
        let bucket = layer.tiles.get(key);
        if (!bucket) { bucket = []; layer.tiles.set(key, bucket); }
        bucket.push(pic);
      }
      this._history.push({ layer: this._active, pic, keys });
      for (const key of keys) this._dirtyTiles.add(key);
      this._compositeDirty();
      this._surface.flush();
    },

    async undo(steps) {
      let removed = 0;
      for (let i = 0; i < steps; i += 1) {
        const h = this._history.pop();
        if (!h) break;
        removed += 1;
        const layer = this._layers[h.layer];
        const idx = layer.pictures.lastIndexOf(h.pic);
        if (idx >= 0) layer.pictures.splice(idx, 1);
        for (const key of h.keys) {
          const bucket = layer.tiles.get(key);
          if (!bucket) continue;
          const j2 = bucket.lastIndexOf(h.pic);
          if (j2 >= 0) bucket.splice(j2, 1);
          if (bucket.length === 0) layer.tiles.delete(key);
          this._dirtyTiles.add(key);
        }
        try { h.pic.delete(); } catch (e) { /* ignore */ }
      }
      if (removed === 0) return;
      this._compositeDirty();
      this._surface.flush();
    },

    setBlendMode(mode) {
      const normalized = Object.prototype.hasOwnProperty.call(BLEND_KEY, mode) ? mode : 'normal';
      this._layers[this._active].blend = normalized;
      this._fullComposite();
      this._surface.flush();
    },

    async getCompositeDataUrl() {
      const img = this._surface.makeImageSnapshot();
      const bytes = img.encodeToBytes();
      try { img.delete(); } catch (e) { /* ignore */ }
      if (!bytes) throw new Error('CanvasKit: snapshot 编码失败');
      return `data:image/png;base64,${bytesToBase64(bytes)}`;
    },

    getStats() {
      const pictures = this._layers.reduce((s, l) => s + l.pictures.length, 0);
      const buckets = this._layers.reduce((s, l) => s + l.tiles.size, 0);
      return {
        rendererPath: this._rendererPath,
        vendor: `canvaskit-wasm@${VENDOR_VERSION}`,
        license: 'BSD-3-Clause',
        tileSize: TILE,
        layers: this._layerCount,
        pictures,
        tileBuckets: buckets,
        tilesW: this._tilesW,
        tilesH: this._tilesH,
        wasmHeapBytes: this._CK && this._CK.HEAPU8 ? this._CK.HEAPU8.length : null,
      };
    },

    dispose() {
      try {
        for (const layer of this._layers) {
          for (const pic of layer.pictures) { try { pic.delete(); } catch (e) { /* ignore */ } }
          layer.pictures = [];
          layer.tiles.clear();
        }
        this._history = [];
        for (const filter of this._maskCache.values()) { try { filter.delete(); } catch (e) { /* ignore */ } }
        this._maskCache.clear();
        this._paint && this._paint.delete();
        this._layerPaint && this._layerPaint.delete();
        this._surface && this._surface.delete && this._surface.delete();
      } catch (e) { /* ignore */ }
      this._surface = null;
      this._ckCanvas = null;
      this._CK = null;
    },
  };
})();
