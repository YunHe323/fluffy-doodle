/**
 * v2/layers · 图层体系（T37）
 *
 * 在 T35 Engine 之上构建（只读复用 engine 的 CK/gr/store/主 surface，不改 engine）：
 * - 图层树：1 级组（组透明度隔离）+ 图层元数据（可见/不透明度/混合/锁定/Alpha Lock）
 * - 16 种混合模式（compositor16.js）
 * - 图层蒙版：独立灰度/alpha 通道，可启停/删除/应用（应用=烘焙进图层）；编辑走笔刷管线
 * - 剪贴蒙版：以「下方图层 alpha」为剪贴基准（DstIn）
 * - 图层操作：新建/删除/复制/排序/合并/拼合/组
 * - undo：笔触 tile patch + 变换/结构操作的整层图像快照（1 步 undo）
 *
 * 约定：本模块独立维护图层元数据与合成；Engine 的 compositor 仅作为主 surface 提供者
 * （本模块直接绘制到 engine.compositor.canvas）。demo 中不要同时使用 engine 的绘制/undo。
 */
import { TileStore, TILE } from '../engine/src/tile-store.js';
import { Stroke } from '../engine/src/stroke.js';
import { blendOf, BLEND_MODES } from './compositor16.js';
import { createDoc, normalizeDoc } from '../engine/src/v2doc.js';

const MAX_TILE_BUDGET_MB = 800;

let idSeq = 0;
const nextId = (p) => `${p}-${Date.now().toString(36)}-${(idSeq += 1)}`;

export class LayerSystem {
  /** @param {any} engine T35 Engine 实例（已 init） */
  constructor(engine) {
    this.engine = engine;
    this.CK = engine.CK;
    this.gr = engine.gr;
    this.width = engine.width;
    this.height = engine.height;
    this.tileSize = TILE;
    this.tilesW = Math.ceil(this.width / TILE);
    this.tilesH = Math.ceil(this.height / TILE);
    this.canvas = engine.opts.canvas;
    this.mainCanvas = engine.compositor.canvas;
    this.surface = engine.compositor.surface;
    // T45：离屏 live layer（当前笔触/蒙版笔触的确定性预览来源，不依赖 on-screen framebuffer 跨帧保留）
    this.liveSurface = this.CK.MakeRenderTarget(this.gr, this.width, this.height);
    this.liveCanvas = this.liveSurface ? this.liveSurface.getCanvas() : null;
    if (this.liveCanvas) this.liveCanvas.clear(this.CK.TRANSPARENT);
    this._liveMaskPaint = new this.CK.Paint();
    this._liveMaskPaint.setAntiAlias(true);
    this._liveMaskPaint.setStyle(this.CK.PaintStyle.Fill);
    this._liveMaskPaint.setColor(this.CK.Color(255, 255, 255, 1));
    /** 图层像素存储（按 layerId） */
    this.store = engine.store;
    /** 蒙版像素存储（按 layerId） */
    this.maskStore = new TileStore(this.CK, this.gr, this.width, this.height);

    /** @type {Array<any>} 扁平顺序 = 合成顺序（下→上） */
    this.layers = [];
    /** @type {Array<any>} */
    this.groups = [];
    this.activeLayerId = null;
    /** 'layer' | 'mask' */
    this.activeTarget = 'layer';
    this.selectionImage = null; // CanvasKit Image（alpha 选区掩码）
    this.brush = { type: 'soft', sizePx: 64 };
    this.currentStroke = null;
    this.currentMaskStroke = null;
    this.undoStack = [];
    this.redoStack = [];
    this.historyBytes = 0;
    this.lastCompositeMs = 0;
    this._paintPool = null;

    this._undoReady = false;
    this._inStructure = false;
    this._detachedImages = [];
    this.addLayer({ name: '图层 1' });
    this.addLayer({ name: '图层 2' });
    this.activeLayerId = this.layers[this.layers.length - 1].id;
    this.composite();
    this._undoReady = true;
  }

  // ---------- 图层/组 ----------
  addGroup(name = '组') {
    return this._withStructureUndo(() => {
      const g = { id: nextId('group'), name, visible: true, opacity: 1, collapsed: false, clip: false, mask: { exists: false, enabled: true } };
      this.groups.push(g);
      this.composite();
      return g;
    });
  }

  setActiveGroup(id) { if (this.groups.some((g) => g.id === id)) this.activeGroupId = id; return this.activeGroupId; }
  getActiveGroup() { return this.activeGroupId; }

  addGroupMask(groupId) {
    return this._withStructureUndo(() => {
      const group = this.groups.find((g) => g.id === groupId);
      if (!group) return null;
      group.mask = { exists: true, enabled: true };
      this.maskStore.ensureLayer(groupId);
      this.composite();
      return group.mask;
    });
  }

  removeGroupMask(groupId) {
    return this._withStructureUndo(() => {
      const group = this.groups.find((g) => g.id === groupId);
      if (!group) return false;
      this._detachLayerTiles(this.maskStore, groupId);
      group.mask = { exists: false, enabled: true };
      this.composite();
      return true;
    });
  }

  setGroupMaskEnabled(groupId, enabled) {
    return this._withStructureUndo(() => {
      const group = this.groups.find((g) => g.id === groupId);
      if (!group || !group.mask || !group.mask.exists) return false;
      group.mask.enabled = !!enabled;
      this.composite();
      return true;
    });
  }

  setGroupClip(groupId, clip) {
    return this._withStructureUndo(() => {
      const group = this.groups.find((g) => g.id === groupId);
      if (!group) return false;
      group.clip = !!clip;
      this.composite();
      return true;
    });
  }

  applyGroupMask(groupId) {
    return this._withStructureUndo(() => {
      const group = this.groups.find((g) => g.id === groupId);
      if (!group || !group.mask || !group.mask.exists) return false;
      const members = this.layers.filter((l) => l.group === groupId);
      const maskImg = this._renderMaskToImage(groupId);
      for (const layer of members) {
        for (const key of this.store.listTiles(layer.id)) this._applyMaskToTile(this.store, layer.id, key, maskImg);
      }
      maskImg.delete();
      this._detachLayerTiles(this.maskStore, groupId);
      group.mask = { exists: false, enabled: true };
      this.composite();
      return true;
    });
  }

  addLayer(opts = {}) {
    return this._withStructureUndo(() => {
      const layer = {
        id: opts.id || nextId('layer'),
        name: opts.name || `图层 ${this.layers.length + 1}`,
        group: opts.group || null,
        visible: true,
        opacity: 1,
        blend: 'normal',
        locked: false,
        alphaLock: false,
        clip: false,
        mask: { enabled: false, exists: false },
      };
      this.layers.push(layer);
      this.activeLayerId = layer.id;
      this.composite();
      return layer;
    });
  }

  getLayer(id) { return this.layers.find((l) => l.id === id) || null; }
  activeLayer() { return this.getLayer(this.activeLayerId); }
  listLayers() { return this.layers.map((l) => ({ ...l, mask: { ...l.mask } })); }
  listGroups() { return this.groups.map((g) => ({ ...g })); }

  deleteLayer(id) {
    return this._withStructureUndo(() => this._deleteLayerRaw(id));
  }

  _deleteLayerRaw(id) {
    const layer = this.getLayer(id);
    if (!layer) return false;
    this._detachLayerTiles(this.store, id);
    this._detachLayerTiles(this.maskStore, id);
    this.layers = this.layers.filter((l) => l.id !== id);
    if (this.activeLayerId === id) this.activeLayerId = this.layers.length ? this.layers[this.layers.length - 1].id : null;
    this.composite();
    return true;
  }

  duplicateLayer(id) {
    return this._withStructureUndo(() => this._duplicateLayerRaw(id));
  }

  _duplicateLayerRaw(id) {
    const src = this.getLayer(id);
    if (!src) return null;
    const copy = { ...src, id: nextId('layer'), name: `${src.name} 副本`, mask: { ...src.mask } };
    // 像素复制：逐 tile 快照
    for (const key of this.store.listTiles(id)) {
      const t = this.store.get(id, key);
      if (t) this.store.ensureTile(copy.id, key).image = t.image;
    }
    if (src.mask.exists) {
      for (const key of this.maskStore.listTiles(id)) {
        const t = this.maskStore.get(id, key);
        if (t) this.maskStore.ensureTile(copy.id, key).image = t.image;
      }
    }
    const idx = this.layers.findIndex((l) => l.id === id);
    this.layers.splice(idx + 1, 0, copy);
    this.activeLayerId = copy.id;
    this.composite();
    return copy;
  }

  moveLayer(id, dir) {
    return this._withStructureUndo(() => {
      const idx = this.layers.findIndex((l) => l.id === id);
      const target = idx + dir;
      if (idx < 0 || target < 0 || target >= this.layers.length) return false;
      [this.layers[idx], this.layers[target]] = [this.layers[target], this.layers[idx]];
      this.composite();
      return true;
    });
  }

  mergeDown(id) {
    return this._withStructureUndo(() => this._mergeDownRaw(id));
  }

  _mergeDownRaw(id) {
    const idx = this.layers.findIndex((l) => l.id === id);
    if (idx <= 0) return false;
    const upper = this.layers[idx];
    const lower = this.layers[idx - 1];
    const img = this.renderLayerToImage(upper.id, true);
    // 以 normal 方式把 upper 的合成像叠到 lower 上（简化：忽略 upper 的 blend）
    for (let ty = 0; ty < this.tilesH; ty += 1) {
      for (let tx = 0; tx < this.tilesW; tx += 1) {
        const key = `${tx},${ty}`;
        const surface = this.CK.MakeRenderTarget(this.gr, TILE, TILE);
        const c = surface.getCanvas();
        c.clear(this.CK.TRANSPARENT);
        const lt = this.store.get(lower.id, key);
        if (lt) c.drawImage(lt.image, 0, 0);
        const paint = this._paint();
        paint.setBlendMode(this.CK.BlendMode.SrcOver);
        c.drawImage(img, -tx * TILE, -ty * TILE, paint);
        surface.flush();
        const tile = this.store.ensureTile(lower.id, key);
        tile.image = surface.makeImageSnapshot();
        surface.delete();
      }
    }
    img.delete();
    this._deleteLayerRaw(id);
    this.composite();
    return true;
  }

  flattenAll() {
    return this._withStructureUndo(() => this._flattenAllRaw());
  }

  _flattenAllRaw() {
    const img = this._renderAllToImage();
    for (const l of [...this.layers]) this._detachLayerTiles(this.store, l.id);
    for (const layerId of [...this.maskStore.layers.keys()]) this._detachLayerTiles(this.maskStore, layerId);
    this.layers = [];
    this.groups = [];
    const layer = { id: nextId('layer'), name: '拼合图层', group: null, visible: true, opacity: 1, blend: 'normal', locked: false, alphaLock: false, clip: false, mask: { enabled: false, exists: false } };
    this.layers.push(layer);
    this.activeLayerId = layer.id;
    this.replaceLayerFromImage(layer.id, img);
    img.delete();
    this.composite();
    return layer;
  }

  // ---------- 元数据 ----------
  setLayerVisible(id, visible) { const l = this.getLayer(id); if (!l) return; l.visible = !!visible; this.composite(); }
  setLayerOpacity(id, opacity) { const l = this.getLayer(id); if (!l) return; l.opacity = Math.max(0, Math.min(1, Number(opacity))); this.composite(); }
  setLayerBlend(id, blend) {
    const l = this.getLayer(id);
    if (!l) return false;
    l.blend = BLEND_MODES.includes(blend) ? blend : 'normal';
    this.composite();
    return true;
  }
  setLayerClip(id, clip) { const l = this.getLayer(id); if (!l) return; l.clip = !!clip; this.composite(); }
  setLayerLocked(id, locked) { const l = this.getLayer(id); if (l) l.locked = !!locked; }
  setLayerAlphaLock(id, alphaLock) { const l = this.getLayer(id); if (l) l.alphaLock = !!alphaLock; return !!alphaLock; }
  getLayerAlphaLock(id) { const l = this.getLayer(id); return !!(l && l.alphaLock); }
  setActiveLayer(id) { if (this.getLayer(id)) this.activeLayerId = id; }
  setActiveTarget(target) {
    this.activeTarget = target === 'mask' ? 'mask' : target === 'group-mask' ? 'group-mask' : 'layer';
  }

  // ---------- 蒙版 ----------
  addMask(id) {
    const l = this.getLayer(id);
    if (!l) return false;
    l.mask = { enabled: true, exists: true };
    this.maskStore.ensureLayer(id);
    this.composite();
    return true;
  }
  setMaskEnabled(id, enabled) { const l = this.getLayer(id); if (!l) return; l.mask.enabled = !!enabled; this.composite(); }
  deleteMask(id) {
    const l = this.getLayer(id);
    if (!l) return;
    this._dropStoreLayer(this.maskStore, id);
    l.mask = { enabled: false, exists: false };
    this.composite();
  }
  /** 把蒙版烘焙进图层像素（保留 alpha 关系后删除蒙版） */
  applyMask(id) {
    const l = this.getLayer(id);
    if (!l || !l.mask.exists) return false;
    const maskImg = this._renderMaskToImage(id);
    for (const key of this.store.listTiles(id)) {
      this._applyMaskToTile(this.store, id, key, maskImg);
    }
    maskImg.delete();
    this._dropStoreLayer(this.maskStore, id);
    l.mask = { enabled: false, exists: false };
    this.composite();
    return true;
  }

  // ---------- 画笔（与 T35 输入管线对接） ----------
  setBrush(brush) {
    if (!brush) return;
    if (brush.type) this.brush.type = brush.type;
    if (brush.sizePx) this.brush.sizePx = brush.sizePx;
  }

  beginStroke(p) {
    const layer = this.activeLayer();
    if (!layer) return;
    if (this.activeTarget === 'group-mask') {
      const group = this.groups.find((g) => g.id === this.activeGroupId);
      if (group && group.mask && group.mask.exists) {
        this.currentMaskStroke = { groupId: group.id, points: [p], affected: new Set() };
        this._maskStamp(p, true);
        this.requestFrame();
        return;
      }
    }
    if (this.activeTarget === 'mask' && layer.mask.exists) {
      this.currentMaskStroke = { layerId: layer.id, points: [p], affected: new Set() };
      this._maskStamp(p, true);
      this.requestFrame();
      return;
    }
    this._clearLiveSurface();
    this.currentStroke = new Stroke(this.CK, this.store, layer.id, this.brush, p);
    this.currentStroke.stampTo(this.liveCanvas);
    this.requestFrame();
  }

  appendPoint(p) {
    if (this.currentMaskStroke) {
      this.currentMaskStroke.points.push(p);
      this._maskStamp(p, true);
      this.requestFrame();
      return;
    }
    if (!this.currentStroke) return;
    this.currentStroke.append(p);
    this.currentStroke.stampTo(this.liveCanvas);
    this.requestFrame();
  }

  endStroke() {
    if (this.currentMaskStroke) return this._finishMaskStroke();
    if (!this.currentStroke) return null;
    this._clearLiveSurface();
    const stroke = this.currentStroke;
    this.currentStroke = null;
    const { entry, dirtyKeys } = stroke.commit();
    stroke.dispose();
    let patches = entry.patches;
    if (this.selectionImage && patches.length) {
      patches = patches.map((pt) => this._constrainPatch(this.store, entry.layerId, pt));
    }
    const strokeLayer = this.getLayer(entry.layerId);
    if (strokeLayer && strokeLayer.alphaLock && patches.length) {
      patches = patches.map((pt) => this._alphaLockPatch(this.store, entry.layerId, pt));
    }
    const entry2 = { kind: 'paint', storeKind: 'layer', layerId: entry.layerId, patches };
    this._pushUndo(entry2);
    this.compositeDirtySafe(dirtyKeys);
    return entry2;
  }

  cancelStroke() {
    this._clearLiveSurface();
    if (this.currentStroke) { this.currentStroke.dispose(); this.currentStroke = null; }
    if (this.currentMaskStroke) { this.currentMaskStroke = null; }
    this.composite();
  }

  _maskStamp(p, drawLive) {
    const state = this.currentMaskStroke;
    const r = Math.max(0.5, this.brush.sizePx * 0.5 * (0.25 + (p.pressure == null ? 0.5 : p.pressure) * 0.75));
    if (drawLive && this.liveCanvas) {
      const paint = this._liveMaskPaint;
      paint.setMaskFilter(this.brush.type === 'soft' ? this._maskBlur(r * 0.35) : null);
      this.liveCanvas.drawCircle(p.x, p.y, r, paint);
    }
    const tx0 = Math.max(0, Math.floor((p.x - r) / TILE));
    const ty0 = Math.max(0, Math.floor((p.y - r) / TILE));
    const tx1 = Math.min(this.tilesW - 1, Math.floor((p.x + r) / TILE));
    const ty1 = Math.min(this.tilesH - 1, Math.floor((p.y + r) / TILE));
    for (let ty = ty0; ty <= ty1; ty += 1) {
      for (let tx = tx0; tx <= tx1; tx += 1) state.affected.add(`${tx},${ty}`);
    }
  }

  _finishMaskStroke() {
    this._clearLiveSurface();
    const state = this.currentMaskStroke;
    this.currentMaskStroke = null;
    const targetId = state.groupId || state.layerId;
    const storeKind = state.groupId ? 'group-mask' : 'mask';
    const patches = [];
    for (const key of [...state.affected]) {
      const tile = this.maskStore.ensureTile(targetId, key);
      const before = tile.image;
      const { tx, ty } = this.maskStore.keyXY(key);
      const c = tile.surface.getCanvas();
      for (const p of state.points) {
        const r = Math.max(0.5, this.brush.sizePx * 0.5 * (0.25 + (p.pressure == null ? 0.5 : p.pressure) * 0.75));
        const paint = this._paint();
        paint.setAntiAlias(true);
        paint.setStyle(this.CK.PaintStyle.Fill);
        paint.setColor(this.CK.Color(255, 255, 255, 1));
        if (this.brush.type === 'soft') paint.setMaskFilter(this._maskBlur(r * 0.35));
        c.drawCircle(p.x - tx * TILE, p.y - ty * TILE, r, paint);
      }
      tile.surface.flush();
      const after = tile.surface.makeImageSnapshot();
      tile.image = after;
      patches.push({ key, before, after });
    }
    this._pushUndo({ kind: 'paint', storeKind, layerId: targetId, patches });
    this.compositeDirtySafe([...state.affected]);
    return { kind: 'mask', layerId: targetId, patches };
  }

  // ---------- 选区约束 ----------
  setSelectionImage(img) { this.selectionImage = img || null; }
  clearSelection() { this.selectionImage = null; }

  _alphaLockPatch(store, layerId, patch) {
    if (!patch || !patch.after || !patch.before) return patch;
    const tile = store.get(layerId, patch.key);
    if (!tile) return patch;
    const c = tile.surface.getCanvas();
    const paint = this._paint();
    paint.setBlendMode(this.CK.BlendMode.DstIn);
    c.drawImage(patch.before, 0, 0, paint);
    tile.surface.flush();
    tile.image = tile.surface.makeImageSnapshot();
    return { key: patch.key, before: patch.before, after: tile.image };
  }

  /** T65：显式释放历史/结构快照中不再被当前 tile 引用的 image */
  releaseHistorySnapshots() {
    const live = new Set();
    for (const store of [this.store, this.maskStore]) {
      for (const map of store.layers.values()) for (const tile of map.values()) live.add(tile.image);
    }
    const images = new Set();
    const collect = (entry) => {
      if (!entry) return;
      if (entry.kind === 'structure') {
        for (const side of ['before', 'after']) {
          const snap = entry[side];
          if (!snap) continue;
          for (const tiles of [snap.tiles, snap.masks]) {
            if (!tiles) continue;
            for (const t of Object.values(tiles)) for (const img of Object.values(t)) if (img) images.add(img);
          }
        }
      } else if (entry.kind === 'image') {
        if (entry.before) images.add(entry.before);
        if (entry.after) images.add(entry.after);
      } else if (entry.patches) {
        for (const pt of entry.patches) { if (pt.before) images.add(pt.before); if (pt.after) images.add(pt.after); }
      }
    };
    for (const e of [...this.undoStack, ...this.redoStack]) collect(e);
    for (const img of images) { if (!live.has(img)) { try { img.delete(); } catch (err) { /* ignore */ } } }
    for (const img of this._detachedImages) { if (!live.has(img)) { try { img.delete(); } catch (err) { /* ignore */ } } }
    this._detachedImages.length = 0;
    this.undoStack = [];
    this.redoStack = [];
    return true;
  }

  _constrainPatch(store, layerId, patch) {
    const tile = store.ensureTile(layerId, patch.key);
    const { tx, ty } = store.keyXY(patch.key);
    const surface = this.CK.MakeRenderTarget(this.gr, TILE, TILE);
    const c = surface.getCanvas();
    c.clear(this.CK.TRANSPARENT);
    c.drawImage(patch.after, 0, 0);
    const paint = this._paint();
    paint.setBlendMode(this.CK.BlendMode.DstIn);
    c.drawImage(this.selectionImage, -tx * TILE, -ty * TILE, paint);
    surface.flush();
    const img = surface.makeImageSnapshot();
    surface.delete();
    tile.image = img;
    return { key: patch.key, before: patch.before, after: img };
  }

  _applyMaskToTile(store, layerId, key, maskImage) {
    const tile = store.ensureTile(layerId, key);
    const { tx, ty } = store.keyXY(key);
    const surface = this.CK.MakeRenderTarget(this.gr, TILE, TILE);
    const c = surface.getCanvas();
    c.clear(this.CK.TRANSPARENT);
    c.drawImage(tile.image, 0, 0);
    const paint = this._paint();
    paint.setBlendMode(this.CK.BlendMode.DstIn);
    c.drawImage(maskImage, -tx * TILE, -ty * TILE, paint);
    surface.flush();
    tile.image = surface.makeImageSnapshot();
    surface.delete();
  }

  // ---------- 合成 ----------
  composite() {
    const t0 = performance.now();
    this._drawAll(this.mainCanvas);
    this.surface.flush();
    this.lastCompositeMs = Math.round((performance.now() - t0) * 100) / 100;
  }

  /** 把全部图层画到给定 canvas（主 surface 或离屏 surface）
   *  live：{ layerId, mode:'paint'|'mask-union', image }（T45 确定性实时预览）
   */
  _drawAll(c, live = null) {
    c.clear(this.CK.WHITE);
    let i = 0;
    while (i < this.layers.length) {
      const layer = this.layers[i];
      if (layer.group) {
        const group = this.groups.find((g) => g.id === layer.group);
        const visible = !group || group.visible;
        if (!visible) {
          while (i < this.layers.length && this.layers[i].group === layer.group) i += 1;
          continue;
        }
        const groupStart = i;
        const paint = this._paint();
        paint.setBlendMode(this.CK.BlendMode.SrcOver);
        paint.setAlphaf(group ? (group.opacity == null ? 1 : group.opacity) : 1);
        c.saveLayer(paint);
        const members = [];
        while (i < this.layers.length && this.layers[i].group === layer.group) { members.push(this.layers[i]); i += 1; }
        for (const m of members) this._drawLayer(c, m, live);
        if (group && group.mask && group.mask.enabled && group.mask.exists) {
          const mp = this._paint();
          mp.setBlendMode(this.CK.BlendMode.DstIn);
          this._drawTiles(c, this.maskStore, group.id, mp);
        }
        if (group && group.clip) {
          const base = groupStart > 0 ? this.layers[groupStart - 1] : null;
          if (base && !base.group) {
            const cp = this._paint();
            cp.setBlendMode(this.CK.BlendMode.DstIn);
            this._drawTiles(c, this.store, base.id, cp);
          }
        }
        if (group && live && live.groupId === group.id && live.image) {
          c.save();
          for (const m of members) this._drawLayer(c, m, null);
          const lp = this._paint();
          lp.setBlendMode(this.CK.BlendMode.DstIn);
          c.drawImage(live.image, 0, 0, lp);
          c.restore();
        }
        c.restore();
      } else {
        this._drawLayer(c, layer, live);
        i += 1;
      }
    }
  }

  compositeDirtySafe(dirtyKeys) {
    if (!dirtyKeys || dirtyKeys.length === 0) return this.composite();
    const total = this.tilesW * this.tilesH;
    if (dirtyKeys.length > total * 0.5) return this.composite();
    const t0 = performance.now();
    const c = this.mainCanvas;
    for (const key of dirtyKeys) {
      const { tx, ty } = this.store.keyXY(key);
      c.save();
      c.clipRect([tx * TILE, ty * TILE, TILE, TILE], this.CK.ClipOp.Intersect, false);
      c.clear(this.CK.WHITE);
      for (const layer of this.layers) {
        if (!layer.visible) continue;
        this._drawLayerTile(c, layer, key);
      }
      c.restore();
    }
    this.surface.flush();
    this.lastCompositeMs = Math.round((performance.now() - t0) * 100) / 100;
  }

  _drawLayer(c, layer, live = null) {
    if (!layer.visible || layer.opacity <= 0) return;
    const blend = blendOf(this.CK, layer.blend);
    const needsLayer = blend !== this.CK.BlendMode.SrcOver || layer.opacity < 1 || (layer.mask && layer.mask.enabled) || layer.clip;
    if (needsLayer) {
      const paint = this._paint();
      paint.setBlendMode(blend);
      paint.setAlphaf(layer.opacity);
      c.saveLayer(paint);
    } else {
      c.save();
    }
    this._drawTiles(c, this.store, layer.id);
    if (layer.mask && layer.mask.enabled && layer.mask.exists) {
      const paint = this._paint();
      paint.setBlendMode(this.CK.BlendMode.DstIn);
      this._drawTiles(c, this.maskStore, layer.id, paint);
    }
    if (layer.clip) {
      const idx = this.layers.indexOf(layer);
      const base = idx > 0 ? this.layers[idx - 1] : null;
      if (base) {
        const paint = this._paint();
        paint.setBlendMode(this.CK.BlendMode.DstIn);
        this._drawTiles(c, this.store, base.id, paint);
      }
    }
    if (live && live.layerId === layer.id && live.image) {
      if (live.mode === 'paint') {
        // 普通笔触：在图层隔离内叠加到本层内容上
        c.drawImage(live.image, 0, 0);
      } else if (live.mode === 'mask-union') {
        // 蒙版笔触：现有蒙版已把内容 DstIn 遮掉；再补一次「本层内容 + live mask DstIn」→ 露出被新蒙版覆盖处
        c.save();
        this._drawTiles(c, this.store, layer.id);
        const mp = this._paint();
        mp.setBlendMode(this.CK.BlendMode.DstIn);
        c.drawImage(live.image, 0, 0, mp);
        c.restore();
      }
    }
    c.restore();
  }

  _drawLayerTile(c, layer, key) {
    if (!layer.visible) return;
    const blend = blendOf(this.CK, layer.blend);
    const needsLayer = blend !== this.CK.BlendMode.SrcOver || layer.opacity < 1 || (layer.mask && layer.mask.enabled) || layer.clip;
    if (needsLayer) {
      const paint = this._paint();
      paint.setBlendMode(blend);
      paint.setAlphaf(layer.opacity);
      c.saveLayer(paint);
    } else c.save();
    const t = this.store.get(layer.id, key);
    if (t) {
      const { tx, ty } = this.store.keyXY(key);
      c.drawImage(t.image, tx * TILE, ty * TILE);
    }
    c.restore();
  }

  _drawTiles(c, store, layerId, paint) {
    for (const key of store.listTiles(layerId)) {
      const t = store.get(layerId, key);
      if (!t) continue;
      const { tx, ty } = store.keyXY(key);
      if (paint) c.drawImage(t.image, tx * TILE, ty * TILE, paint);
      else c.drawImage(t.image, tx * TILE, ty * TILE);
    }
  }

  // ---------- 图层图像（变换/合并用） ----------
  renderLayerToImage(layerId, includeMask = true) {
    const layer = this.getLayer(layerId);
    const surface = this.CK.MakeRenderTarget(this.gr, this.width, this.height);
    const c = surface.getCanvas();
    c.clear(this.CK.TRANSPARENT);
    if (layer) {
      this._drawTiles(c, this.store, layerId);
      if (includeMask && layer.mask && layer.mask.enabled && layer.mask.exists) {
        const paint = this._paint();
        paint.setBlendMode(this.CK.BlendMode.DstIn);
        this._drawTiles(c, this.maskStore, layerId, paint);
      }
    }
    surface.flush();
    const img = surface.makeImageSnapshot();
    surface.delete();
    return img;
  }

  _renderMaskToImage(layerId) {
    const surface = this.CK.MakeRenderTarget(this.gr, this.width, this.height);
    const c = surface.getCanvas();
    c.clear(this.CK.TRANSPARENT);
    this._drawTiles(c, this.maskStore, layerId);
    surface.flush();
    const img = surface.makeImageSnapshot();
    surface.delete();
    return img;
  }

  _renderAllToImage() {
    const surface = this.CK.MakeRenderTarget(this.gr, this.width, this.height);
    const c = surface.getCanvas();
    c.clear(this.CK.WHITE);
    for (const layer of this.layers) if (layer.visible) this._drawLayer(c, layer);
    surface.flush();
    const img = surface.makeImageSnapshot();
    surface.delete();
    return img;
  }

  replaceLayerFromImage(layerId, image) {
    for (let ty = 0; ty < this.tilesH; ty += 1) {
      for (let tx = 0; tx < this.tilesW; tx += 1) {
        const key = `${tx},${ty}`;
        const surface = this.CK.MakeRenderTarget(this.gr, TILE, TILE);
        const c = surface.getCanvas();
        c.clear(this.CK.TRANSPARENT);
        const paint = this._paint();
        paint.setBlendMode(this.CK.BlendMode.SrcOver);
        c.drawImage(image, -tx * TILE, -ty * TILE, paint);
        surface.flush();
        const tile = this.store.ensureTile(layerId, key);
        tile.image = surface.makeImageSnapshot();
        surface.delete();
      }
    }
  }

  // ---------- undo/redo ----------
  _pushUndo(entry) {
    this.undoStack.push(entry);
    this.redoStack = [];
    this.historyBytes += this._entryBytes(entry);
    while (this.undoStack.length > 80) this.undoStack.shift();
  }
  _entryBytes(entry) {
    if (entry.kind === 'paint') return entry.patches.length * TILE * TILE * 4 * 2;
    return this.width * this.height * 4 * 2;
  }
  canUndo() { return this.undoStack.length > 0; }
  canRedo() { return this.redoStack.length > 0; }
  undo() {
    const entry = this.undoStack.pop();
    if (!entry) return false;
    this._applyEntry(entry, 'before');
    this.redoStack.push(entry);
    return true;
  }
  redo() {
    const entry = this.redoStack.pop();
    if (!entry) return false;
    this._applyEntry(entry, 'after');
    this.undoStack.push(entry);
    return true;
  }
  // ---------- T63：结构操作 undo（与笔触同一栈） ----------
  _detachLayerTiles(store, layerId) {
    const map = store.layers.get(layerId);
    if (!map) return;
    for (const tile of map.values()) this._detachedImages.push(tile.image);
    map.clear();
    store.layers.delete(layerId);
  }

  _snapshotImages(store) {
    const out = {};
    for (const [layerId, map] of store.layers.entries()) {
      const tiles = {};
      for (const [key, tile] of map.entries()) tiles[key] = tile.image;
      if (Object.keys(tiles).length) out[layerId] = tiles;
    }
    return out;
  }

  _snapshotStructure() {
    return { doc: this.getDoc(), tiles: this._snapshotImages(this.store), masks: this._snapshotImages(this.maskStore) };
  }

  _restoreStructure(snapshot) {
    for (const map of this.store.layers.values()) map.clear();
    this.store.layers.clear();
    for (const map of this.maskStore.layers.values()) map.clear();
    this.maskStore.layers.clear();
    const d = normalizeDoc(snapshot.doc);
    this.layers = d.layers.map((l) => ({
      ...l, alphaLock: false,
      mask: { exists: !!(l.mask && l.mask.exists), enabled: !!(l.mask && l.mask.exists && l.mask.enabled !== false) },
    }));
    this.groups = d.groups.map((g) => ({ ...g, clip: !!g.clip, mask: { exists: !!(g.mask && g.mask.exists), enabled: !(g.mask && g.mask.enabled === false) } }));
    for (const g of this.groups) if (g.mask.exists) this.maskStore.ensureLayer(g.id);
    this.activeLayerId = d.activeLayerId;
    for (const [layerId, tiles] of Object.entries(snapshot.tiles || {})) {
      for (const [key, img] of Object.entries(tiles)) this.store.applyImage(layerId, key, img);
    }
    for (const [layerId, tiles] of Object.entries(snapshot.masks || {})) {
      for (const [key, img] of Object.entries(tiles)) this.maskStore.applyImage(layerId, key, img);
    }
    for (const l of this.layers) if (l.mask.exists) this.maskStore.ensureLayer(l.id);
    this.composite();
  }

  _withStructureUndo(fn) {
    if (!this._undoReady || this._inStructure) return fn();
    this._inStructure = true;
    try {
      const before = this._snapshotStructure();
      const result = fn();
      const after = this._snapshotStructure();
      this._pushUndo({ kind: 'structure', before, after });
      return result;
    } finally {
      this._inStructure = false;
    }
  }

  _applyEntry(entry, side) {
    this._clearLiveSurface();
    if (entry.kind === 'paint') {
      const store = (entry.storeKind === 'mask' || entry.storeKind === 'group-mask') ? this.maskStore : this.store;
      const dirty = [];
      for (const patch of entry.patches) {
        store.applyImage(entry.layerId, patch.key, patch[side]);
        dirty.push(patch.key);
      }
      this.compositeDirtySafe(dirty);
    } else if (entry.kind === 'image') {
      this.replaceLayerFromImage(entry.layerId, entry[side]);
      this.composite();
    } else if (entry.kind === 'structure') {
      this._restoreStructure(entry[side]);
    }
  }

  // ---------- 像素/统计 ----------
  // ---------- T60：V2Doc 适配（与 engine / PSD 共用统一模型） ----------
  getDoc() {
    const layers = this.layers.map((l) => ({
      id: l.id, name: l.name, visible: l.visible !== false,
      opacity: l.opacity == null ? 1 : l.opacity, blend: l.blend,
      locked: !!l.locked, alphaLock: !!l.alphaLock, clip: !!l.clip, group: l.group || null,
      mask: { exists: !!(l.mask && l.mask.exists), enabled: l.mask && l.mask.exists ? l.mask.enabled !== false : false },
    }));
    const groups = this.groups.map((g) => ({
      ...g,
      clip: !!g.clip,
      mask: { exists: !!(g.mask && g.mask.exists), enabled: g.mask && g.mask.exists ? g.mask.enabled !== false : true },
    }));
    return createDoc({ width: this.width, height: this.height, layers, groups, activeLayerId: this.activeLayerId });
  }

  applyDoc(doc) {
    const d = normalizeDoc(doc);
    if (d.width !== this.width || d.height !== this.height) throw new Error('doc 尺寸与 LayerSystem 不一致');
    this.layers = d.layers.map((l) => ({
      ...l,
      alphaLock: !!l.alphaLock,
      mask: { exists: !!(l.mask && l.mask.exists), enabled: !!(l.mask && l.mask.exists && l.mask.enabled !== false) },
    }));
    this.groups = d.groups.map((g) => ({ ...g, clip: !!g.clip, mask: { exists: !!(g.mask && g.mask.exists), enabled: !(g.mask && g.mask.enabled === false) } }));
    for (const g of this.groups) if (g.mask.exists) this.maskStore.ensureLayer(g.id);
    this.activeLayerId = d.activeLayerId;
    for (const l of this.layers) if (l.mask.exists) this.maskStore.ensureLayer(l.id);
    this.composite();
    return d;
  }

  async getCompositeDataUrl() {
    // 离屏全量合成后快照（含当前 live 笔触/蒙版预览）
    const surface = this.CK.MakeRenderTarget(this.gr, this.width, this.height);
    const c = surface.getCanvas();
    const info = this._liveInfo();
    const liveImg = info ? this.liveSurface.makeImageSnapshot() : null;
    this._drawAll(c, info ? { ...info, image: liveImg } : null);
    if (liveImg) { /* 快照在 flush 后释放 */ }
    surface.flush();
    const img = surface.makeImageSnapshot();
    const bytes = img.encodeToBytes();
    try { img.delete(); } catch (e) { /* ignore */ }
    try { surface.delete(); } catch (e) { /* ignore */ }
    if (liveImg) { try { liveImg.delete(); } catch (e) { /* ignore */ } }
    if (!bytes) throw new Error('合成图编码失败');
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    return `data:image/png;base64,${btoa(binary)}`;
  }

  getStats() {
    const tilesByLayer = {};
    for (const l of this.layers) tilesByLayer[l.id] = this.store.count(l.id);
    const tileBytes = this.store.memoryBytes() + this.maskStore.memoryBytes();
    const wasm = this.CK && this.CK.HEAPU8 ? this.CK.HEAPU8.length : 0;
    const mem = Math.round((tileBytes + this.historyBytes + wasm) / 1048576 * 10) / 10;
    return {
      width: this.width, height: this.height, tileSize: TILE,
      layers: this.layers.length, groups: this.groups.length,
      activeLayerId: this.activeLayerId, activeTarget: this.activeTarget,
      tileCount: this.store.allKeys().length + this.maskStore.allKeys().length,
      tilesByLayer, undoDepth: this.undoStack.length, redoDepth: this.redoStack.length,
      historyBytes: this.historyBytes, memoryEstimateMB: mem,
      memoryBudgetMB: MAX_TILE_BUDGET_MB, overBudget: mem > MAX_TILE_BUDGET_MB,
      lastCompositeMs: this.lastCompositeMs,
      hasSelection: !!this.selectionImage,
    };
  }

  // ---------- 内部工具 ----------
  _paint() {
    const p = new this.CK.Paint();
    p.setAntiAlias(true);
    p.setStyle(this.CK.PaintStyle.Fill);
    p.setBlendMode(this.CK.BlendMode.SrcOver);
    return p;
  }
  _maskBlur(sigma) {
    if (!this._maskBlurCache) this._maskBlurCache = new Map();
    const key = sigma.toFixed(2);
    let m = this._maskBlurCache.get(key);
    if (!m) { m = this.CK.MaskFilter.MakeBlur(this.CK.BlurStyle.Normal, Math.max(0.5, sigma), true); this._maskBlurCache.set(key, m); }
    return m;
  }
  _dropStoreLayer(store, layerId) {
    const map = store.layers.get(layerId);
    if (map) {
      for (const t of map.values()) {
        try { t.image.delete(); } catch (e) { /* ignore */ }
        try { t.surface.delete(); } catch (e) { /* ignore */ }
      }
      map.clear();
      store.layers.delete(layerId);
    }
  }
  // ---------- T45：确定性实时预览 ----------
  _clearLiveSurface() {
    if (this.liveCanvas && this.CK) {
      try { this.liveCanvas.clear(this.CK.TRANSPARENT); } catch (e) { /* ignore */ }
    }
  }

  _liveInfo() {
    if (this.currentStroke) return { mode: 'paint', layerId: this.currentStroke.layerId };
    if (this.currentMaskStroke) {
      if (this.currentMaskStroke.groupId) return { mode: 'group-mask-union', groupId: this.currentMaskStroke.groupId };
      return { mode: 'mask-union', layerId: this.currentMaskStroke.layerId };
    }
    return null;
  }

  _renderLiveFrame() {
    const info = this._liveInfo();
    if (!info || !this.liveSurface) return;
    const t0 = performance.now();
    const liveImg = this.liveSurface.makeImageSnapshot();
    this._drawAll(this.mainCanvas, { ...info, image: liveImg });
    this.surface.flush();
    try { liveImg.delete(); } catch (e) { /* ignore */ }
    this.lastCompositeMs = Math.round((performance.now() - t0) * 100) / 100;
  }

  requestFrame() {
    if (this._flushScheduled) return;
    this._flushScheduled = true;
    requestAnimationFrame(() => {
      this._flushScheduled = false;
      if (!this._liveInfo()) return;
      try { this._renderLiveFrame(); } catch (e) { /* ignore */ }
    });
  }
}

export { TILE, BLEND_MODES };
