// v2/qa/tools/qwen-image-edit-app.mjs —— 真实 Qwen 图像编辑在 app 内跑通：生成→落层→可变换
import { chromium } from '../node_modules/playwright-core/index.mjs';
import fs from 'node:fs';
const OUT = 'v2/qa/tools/qwen-image-edit-app-results.json';
const res = { schema: 'mozheng.qa.qwen-image-edit-app.v1', cases: {}, errors: [], pass: false };
let browser = null;
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('mozheng.ai.settings.v1', JSON.stringify({ preset: 'qwen', allowReal: true, requireConfirm: false, privacyMode: false })); } catch (e) {} });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => res.errors.push(String(e.message || e).slice(0, 300)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) res.errors.push(m.text().slice(0, 300)); });
  await page.goto('http://127.0.0.1:4200/v2/app/index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(2200);
  res.cases.state = await page.evaluate(() => window.__V2_APP__.t96.getState());
  const before = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.evaluate(() => { const a = window.__V2_APP__; a.state.selection = { x: 360, y: 260, width: 420, height: 300 }; a.drawSelection(); a.openPopover('popAI'); a.switchAiTab('image'); });
  await page.waitForTimeout(400);
  await page.fill('#aiImagePrompt', 'Turn the selected area into a soft watercolor sketch, preserve the original composition and pencil lines.');
  const t0 = Date.now();
  await page.click('#btnImgEdit');
  await page.waitForFunction(() => { const a = window.__V2_APP__; return (a.state.candidates || []).length > 0 || (a.state.aiLastCall && a.state.aiLastCall.status === 'error'); }, null, { timeout: 180000 });
  await page.waitForTimeout(500);
  res.cases.edit = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const c = (a.state.candidates || [])[0] || {};
    return { candidates: (a.state.candidates || []).length, label: c.label, why: c.why, bytes: c.bytes, sha256: c.sha256, meta: a.state.aiLastCall, layers: a.engine.getLayers().length, cards: document.querySelectorAll('#aiImageBody .cand-card').length };
  });
  res.cases.ms = Date.now() - t0;
  await page.screenshot({ path: 'v2/app/ui-image-edit-real-1920.png' });
  if (res.cases.edit.candidates > 0) {
    await page.click('[data-img-apply="0"]');
    await page.waitForTimeout(900);
    res.cases.apply = await page.evaluate(() => { const a = window.__V2_APP__; return { layers: a.engine.getLayers().length, transformActive: !!a.state.transformActive, tool: a.state.tool, undo: a.engine.getStats().undoDepth }; });
    await page.screenshot({ path: 'v2/app/ui-image-edit-applied-1920.png' });
  }
  res.cases.before = before;
  res.pass = !!((res.cases.edit.meta && res.cases.edit.meta.mock === false && res.cases.edit.meta.provider === 'qwen') && res.cases.edit.candidates > 0 && res.cases.apply && res.cases.apply.layers === before + 1 && res.cases.apply.transformActive && res.errors.length === 0);
} catch (e) { res.fatal = String(e && e.stack || e); } finally { try { await browser.close(); } catch (e) {} }
await fs.promises.writeFile(OUT, JSON.stringify(res, null, 2), 'utf8');
console.log(JSON.stringify(res, null, 2));
process.exit(res.pass ? 0 : 1);
