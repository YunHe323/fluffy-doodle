// v2/brushes/build-samples.mjs
// T36 样例图生成（零依赖）：本地静态服务 + headless Chrome(硬件 GPU) + CDP。
// 产物：v2/brushes/samples/_sheet-raw.png（10 行原始样例，透明底）
// 之后由 Python 拼标签/裁切（见 v2/brushes/tools/make-sample-sheet.py）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const OUT_DIR = path.join(ROOT, 'v2', 'brushes', 'samples');
fs.mkdirSync(OUT_DIR, { recursive: true });
const PORT_HTTP = 8097;
const PORT_CDP = 9403;
const URL = `http://127.0.0.1:${PORT_HTTP}/v2/brushes/samples.html`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const python = spawn('python', ['-m', 'http.server', String(PORT_HTTP), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
await sleep(1000);
const profile = path.join(os.tmpdir(), 'inkproof-samples-' + Date.now());
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--no-first-run', '--no-default-browser-check',
  '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist',
  '--window-size=1400,1800', '--hide-scrollbars',
  `--remote-debugging-port=${PORT_CDP}`, `--user-data-dir=${profile}`, URL,
], { stdio: 'ignore' });

let target = null;
for (let i = 0; i < 200 && !target; i += 1) {
  try {
    const r = await fetch(`http://127.0.0.1:${PORT_CDP}/json/list`);
    target = (await r.json()).find((t) => t.type === 'page' && t.url.startsWith('http'));
  } catch (e) { /* retry */ }
  if (!target) await sleep(150);
}
if (!target) { console.log('FATAL no chrome target'); process.exit(1); }
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map(); const errors = [];
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); return; }
  if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text);
  if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push(m.params.args.map((a) => a.value || a.description).join(' '));
};
const send = (method, params = {}) => new Promise((resolve) => { const i = ++id; pending.set(i, resolve); ws.send(JSON.stringify({ id: i, method, params })); });
async function evaljs(expression) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true });
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1500));
  return r.result?.result?.value;
}

try {
  await send('Runtime.enable'); await send('Page.enable');
  let ready = false;
  for (let i = 0; i < 900; i += 1) {
    ready = await evaljs('!!window.__SAMPLES_READY__').catch(() => false);
    const err = await evaljs('window.__SAMPLES_ERROR__ || null').catch(() => null);
    if (err) throw new Error(err);
    if (ready) break;
    await sleep(300);
  }
  if (!ready) throw new Error('samples 超时：' + await evaljs('window.__SAMPLES_STATUS__ || document.title'));
  const texKeys = await evaljs('window.__TEXTURE_KEYS__ || null');
  console.log('texture keys:', JSON.stringify(texKeys));
  const sheet = await evaljs('window.__SHEET__');
  const info = await evaljs('window.__SAMPLES_INFO__ || null');
  const file = path.join(OUT_DIR, '_sheet-raw.png');
  fs.writeFileSync(file, Buffer.from(sheet.split(',')[1], 'base64'));
  fs.writeFileSync(path.join(OUT_DIR, 'samples-info.json'), JSON.stringify({ info, createdAt: new Date().toISOString() }, null, 2), 'utf8');
  console.log('sheet:', file, fs.statSync(file).size, 'bytes');
  console.log('rows:', JSON.stringify(info && info.rows));
  console.log('errors:', JSON.stringify(errors));
} catch (e) {
  console.log('FATAL', e.stack || e);
} finally {
  try { ws.close(); } catch (e) { /* ignore */ }
  chrome.kill(); python.kill();
  await sleep(500);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  process.exit(0);
}
