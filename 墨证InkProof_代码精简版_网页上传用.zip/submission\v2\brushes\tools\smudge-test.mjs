/**
 * v2/brushes/tools/smudge-test.mjs · T62 涂抹笔刷验收（headless，真实 GPU，不弹窗）
 *
 * 场景：demo.html 上先用硬边圆笔画两条粗线 → 切涂抹（controller.setMode('smudge')）纵向拖过
 *      → 检查像素被拖动、拖动中 live 可见、提交后一致、undo 完全恢复、切回画笔仍可画。
 * 产物：samples/smudge/{before,after,undo,live}.png + samples/smudge/metrics.json
 *
 * 运行（项目根目录，先 node v2/serve.mjs）：node v2/brushes/tools/smudge-test.mjs [--headed]
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
const OUT = path.join(ROOT, 'v2', 'brushes', 'samples', 'smudge');
fs.mkdirSync(OUT, { recursive: true });
const CDP_PORT = Number((process.argv.find((a) => a.startsWith('--cdp=')) || '').split('=')[1] || 9595);
const HEADLESS = !process.argv.includes('--headed');
function resolveBase() {
  if (process.env.INKPROOF_BASE) return process.env.INKPROOF_BASE;
  try {
    const port = fs.readFileSync(path.join(ROOT, 'v2', '.runtime-port'), 'utf8').trim();
    if (/^\d+$/.test(port)) return 'http://127.0.0.1:' + port;
  } catch (e) { /* ignore */ }
  return 'http://127.0.0.1:4200';
}
const URL_ARG = `${resolveBase()}/v2/brushes/demo.html`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const EDGE = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
].find((p) => fs.existsSync(p));

const PAGE_HELPERS = `
window.__SMUDGE__ = {
  engine: () => window.__V2__,
  ctrl: () => window.__BRUSH_DEMO__.controller,
  grab() {
    const e = window.__V2__;
    e.compositor.compositeAll(e.store);
    return e.getCompositeDataUrl();
  },
  async load(src) {
    const img = new Image(); img.src = src; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const x = c.getContext('2d'); x.drawImage(img, 0, 0);
    return { w: c.width, h: c.height, d: x.getImageData(0, 0, c.width, c.height).data };
  },
  async diff(aUrl, bUrl) {
    const a = await this.load(aUrl), b = await this.load(bUrl);
    const W = Math.min(a.w, b.w), H = Math.min(a.h, b.h);
    let diff = 0, whiteToInk = 0;
    let minX = W, minY = H, maxX = -1, maxY = -1;
    const white = (d, i) => d[i + 3] < 8 || (d[i] > 240 && d[i + 1] > 240 && d[i + 2] > 240);
    for (let y = 0; y < H; y += 1) for (let x = 0; x < W; x += 1) {
      const i = (y * W + x) * 4;
      if (Math.abs(a.d[i] - b.d[i]) > 24 || Math.abs(a.d[i + 1] - b.d[i + 1]) > 24 || Math.abs(a.d[i + 2] - b.d[i + 2]) > 24) {
        diff += 1;
        if (white(a.d, i) && !white(b.d, i)) whiteToInk += 1;
        if (x < minX) minX = x; if (y < minY) minY = y; if (x > maxX) maxX = x; if (y > maxY) maxY = y;
      }
    }
    return { diff, whiteToInk, bbox: maxX < 0 ? null : [minX, minY, maxX, maxY], w: W, h: H };
  },
  async ink(url) {
    const a = await this.load(url); let n = 0;
    for (let i = 0; i < a.d.length; i += 4) if (a.d[i + 3] > 8 && a.d[i] < 200) n += 1;
    return n;
  },
  setBrush(id) {
    const d = window.__BRUSH_DEMO__;
    const p = d.presets.brushes.find((b) => b.id === id);
    if (!p) return null;
    d.controller.setMode('brush');
    d.controller.setPreset(p);
    return d.controller.preset.id;
  },
  setMode(mode) { return window.__BRUSH_DEMO__.controller.setMode(mode); },
  setParam(k, v) { return window.__BRUSH_DEMO__.controller.setParam(k, v); },
  resetBlank() {
    const e = window.__V2__; let g = 0;
    while (e.canUndo() && g < 400) { e.undo(); g += 1; }
    e.compositor.compositeAll(e.store);
    return g;
  },
  radiusFor() { return window.__BRUSH_DEMO__.controller.preset.size.base; },
}; 'ok'`;

let ws = null; let msgId = 0; const pending = new Map();
const send = (method, params = {}) => new Promise((resolve) => { const id = ++msgId; pending.set(id, resolve); ws.send(JSON.stringify({ id, method, params })); });
async function ev(expression, timeoutMs = 60000) {
  const r = await Promise.race([send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true }), sleep(timeoutMs).then(() => ({ __t: true }))]);
  if (r.__t) throw new Error('evaluate timeout');
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1500));
  return r.result?.result?.value;
}
async function shot() {
  const r = await send('Page.captureScreenshot', { format: 'png' });
  return 'data:image/png;base64,' + r.result.data;
}

const report = { schema: 'inkproof.smudge-test.v1', headless: HEADLESS, url: URL_ARG, ok: false, checks: {}, metrics: {} };
const profile = path.join(os.tmpdir(), 'smudge-' + Date.now());
const args = ['--remote-debugging-port=' + CDP_PORT, '--user-data-dir=' + profile, '--no-first-run', '--no-default-browser-check'];
if (HEADLESS) args.push('--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1400,1000');
else args.push('--window-size=1400,1000', '--window-position=-3000,-3000', '--start-minimized');
args.push(URL_ARG);
const browser = spawn(EDGE, args, { stdio: 'ignore' });

try {
  let target = null;
  for (let i = 0; i < 400 && !target; i += 1) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json();
      target = list.find((t) => t.type === 'page' && /^https?:/.test(t.url));
    } catch (e) { /* wait */ }
    if (!target) await sleep(150);
  }
  if (!target) throw new Error('no target');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { const r = pending.get(m.id); pending.delete(m.id); r(m); } };
  await send('Runtime.enable');
  await send('Page.enable');
  const errs = [];
  ws.addEventListener('message', (e) => {
    const m = JSON.parse(e.data);
    if (m.method === 'Runtime.exceptionThrown') errs.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text || 'exception');
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errs.push((m.params.args || []).map((a) => a.value || a.description || '').join(' ').slice(0, 200));
  });
  let ready = false;
  for (let i = 0; i < 300 && !ready; i += 1) { ready = await ev('!!window.__BRUSH_READY__').catch(() => false); if (!ready) await sleep(200); }
  if (!ready) throw new Error('demo not ready');
  await ev(PAGE_HELPERS);
  const rect = await ev(`(() => { const r = document.getElementById('stage').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
  const toClient = (u, v) => ({ x: Math.round(rect.x + rect.w * u), y: Math.round(rect.y + rect.h * v) });
  const move = async (u, v, buttons = 1) => { const p = toClient(u, v); await send('Input.dispatchMouseEvent', { type: buttons ? 'mouseMoved' : 'mouseMoved', x: p.x, y: p.y, button: 'left', buttons, pointerType: 'mouse' }); };
  const down = async (u, v) => { const p = toClient(u, v); await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: p.x, y: p.y, button: 'left', buttons: 1, clickCount: 1, pointerType: 'mouse' }); };
  const up = async (u, v) => { const p = toClient(u, v); await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: p.x, y: p.y, button: 'left', buttons: 0, clickCount: 1, pointerType: 'mouse' }); };
  const stroke = async (pts, stepMs = 8, onMid = null, midAt = 0.5) => {
    await down(pts[0][0], pts[0][1]); await sleep(30);
    for (let i = 1; i < pts.length; i += 1) {
      await move(pts[i][0], pts[i][1]); await sleep(stepMs);
      if (onMid && i >= Math.floor(pts.length * midAt)) { await onMid(); onMid = null; }
    }
    await up(pts[pts.length - 1][0], pts[pts.length - 1][1]); await sleep(320);
  };

  // 1) 清空 + 用硬边圆笔画两条粗线
  await ev(`window.__SMUDGE__.resetBlank()`);
  await ev(`window.__SMUDGE__.setBrush('hard-round')`);
  await ev(`window.__SMUDGE__.setParam('size.base', 56)`);
  await ev(`window.__SMUDGE__.setParam('taper.start', 0)`);
  await ev(`window.__SMUDGE__.setParam('taper.end', 0)`);
  await stroke([[0.20, 0.40], [0.35, 0.40], [0.50, 0.40], [0.65, 0.40], [0.80, 0.40]]);
  await stroke([[0.20, 0.58], [0.35, 0.58], [0.50, 0.58], [0.65, 0.58], [0.80, 0.58]]);
  await sleep(200);
  const before = await ev(`window.__SMUDGE__.grab()`);
  fs.writeFileSync(path.join(OUT, 'before.png'), Buffer.from(before.split(',')[1], 'base64'));
  report.metrics.beforeInk = await ev(`window.__SMUDGE__.ink(${JSON.stringify(before)})`);
  const liveShotBefore = await shot();

  // 2) 切涂抹，纵向拖过两条线，拖动中抓 live 截图
  const mode = await ev(`window.__SMUDGE__.setMode('smudge')`);
  await ev(`window.__SMUDGE__.setParam('size.base', 80)`);
  report.metrics.mode = mode;
  const smudgePts = [];
  for (let i = 0; i <= 16; i += 1) { const t = i / 16; smudgePts.push([0.5, 0.30 + 0.42 * t]); }
  let liveShot = null;
  await stroke(smudgePts, 12, async () => { liveShot = await shot(); }, 0.45);
  const after = await ev(`window.__SMUDGE__.grab()`);
  fs.writeFileSync(path.join(OUT, 'after.png'), Buffer.from(after.split(',')[1], 'base64'));
  fs.writeFileSync(path.join(OUT, 'live.png'), Buffer.from((liveShot || 'data:image/png;base64,').split(',')[1], 'base64'));
  report.metrics.afterInk = await ev(`window.__SMUDGE__.ink(${JSON.stringify(after)})`);
  report.metrics.smudgeDiff = await ev(`window.__SMUDGE__.diff(${JSON.stringify(before)}, ${JSON.stringify(after)})`);
  report.metrics.liveVisible = liveShot ? await ev(`window.__SMUDGE__.diff(${JSON.stringify(liveShotBefore)}, ${JSON.stringify(liveShot)})`) : null;

  // 3) undo 撤销涂抹 → 应完全恢复 before
  const undoDepth = await ev(`(() => { const e = window.__V2__; const n = e.undoManager.undoStack ? e.undoManager.undoStack.length : null; e.undo(); e.compositor.compositeAll(e.store); return n; })()`);
  await sleep(250);
  const undoImg = await ev(`window.__SMUDGE__.grab()`);
  fs.writeFileSync(path.join(OUT, 'undo.png'), Buffer.from(undoImg.split(',')[1], 'base64'));
  report.metrics.undoDiff = await ev(`window.__SMUDGE__.diff(${JSON.stringify(before)}, ${JSON.stringify(undoImg)})`);
  report.metrics.undoDepth = undoDepth;

  // 4) 切回画笔仍可画
  await ev(`window.__SMUDGE__.setBrush('hard-round')`);
  await ev(`window.__SMUDGE__.setParam('size.base', 24)`);
  await stroke([[0.2, 0.78], [0.35, 0.80], [0.5, 0.78], [0.65, 0.80], [0.8, 0.78]]);
  await sleep(200);
  const post = await ev(`window.__SMUDGE__.grab()`);
  fs.writeFileSync(path.join(OUT, 'post-brush.png'), Buffer.from(post.split(',')[1], 'base64'));
  report.metrics.postBrushDiff = await ev(`window.__SMUDGE__.diff(${JSON.stringify(undoImg)}, ${JSON.stringify(post)})`);
  report.metrics.modeAfter = await ev(`window.__BRUSH_DEMO__.controller.getMode()`);

  report.checks = {
    drewBase: report.metrics.beforeInk > 5000,
    smudgeChangedPixels: (report.metrics.smudgeDiff?.diff || 0) > 2000,
    draggedPixels: (report.metrics.smudgeDiff?.whiteToInk || 0) > 300,
    liveVisibleMidDrag: (report.metrics.liveVisible?.diff || 0) > 500,
    undoRestores: (report.metrics.undoDiff?.diff || 0) < 50,
    modeSwitchBack: report.metrics.modeAfter === 'brush',
    brushStillWorks: (report.metrics.postBrushDiff?.diff || 0) > 500,
    noErrors: errs.length === 0,
  };
  report.errors = errs.slice(0, 10);
  report.ok = Object.values(report.checks).every(Boolean);
  console.log(JSON.stringify({ ok: report.ok, headless: HEADLESS, checks: report.checks, metrics: {
    beforeInk: report.metrics.beforeInk, afterInk: report.metrics.afterInk,
    smudgeDiff: report.metrics.smudgeDiff, liveVisible: report.metrics.liveVisible,
    undoDiff: report.metrics.undoDiff, postBrushDiff: report.metrics.postBrushDiff,
  }, errors: report.errors }, null, 2));
  fs.writeFileSync(path.join(OUT, 'metrics.json'), JSON.stringify(report, null, 2));
} catch (e) {
  report.fatal = String(e && e.stack || e);
  console.log(JSON.stringify({ ok: false, fatal: report.fatal }, null, 2));
  try { fs.writeFileSync(path.join(OUT, 'metrics.json'), JSON.stringify(report, null, 2)); } catch (err) { /* ignore */ }
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  try { browser.kill(); } catch (e) { /* ignore */ }
  await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  process.exit(report.ok ? 0 : 1);
}
