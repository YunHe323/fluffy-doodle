# V2Doc 统一文档/图层模型（T60）

> 项目一 · v2 画布引擎｜作者：tech-architect｜版本：**v1.0**｜日期：2026-11-06
> 给 **T61（demo-builder）** 的产品 UI 交接；配套实现：`v2/engine/src/v2doc.js`、`Engine`、`LayerSystem`、`v2/psd/src/v2doc-bridge.js`。
> 测试：`v2/engine/test/doc.mjs`、`v2/psd/test/v2doc-bridge.mjs`；结果 `v2/engine/results/doc.json`、`v2/psd/results/v2doc-bridge.json`。

---

## 0. 目标

把 engine 的基础图层（5 混合/无组/无蒙版）与 T37 LayerSystem 的完整图层能力（组/蒙版/剪贴/16 混合）统一为**一个文档模型**，Engine、LayerSystem、PSD 导入/导出共用；并支持项目保存/打开（`.mozheng` 单文件），加载后可继续编辑。

---

## 1. 数据模型（纯 JSON，无 CanvasKit 依赖）

```jsonc
{
  "schema": "mozheng.doc.v1",
  "version": 1,
  "width": 2048,
  "height": 2048,
  "activeLayerId": "layer-3",
  "groups": [
    { "id": "group-a", "name": "组 1", "visible": true, "opacity": 1, "collapsed": false,
      "clip": false, "mask": { "exists": false, "enabled": true } }
  ],
  "layers": [                       // 顺序 = 合成顺序（下 → 上）
    {
      "id": "layer-1", "name": "图层 1", "kind": "raster",
      "visible": true, "opacity": 1,
      "blend": "normal",            // 16 种之一（见 §2）
      "locked": false, "alphaLock": false, "clip": false,
      "group": null,                // 或 group id（仅 1 级组）
      "mask": { "exists": false, "enabled": true }
    }
  ]
}
```

- **组**：仅 1 级嵌套（T60 范围）；组内图层 `group=<groupId>`；组按 `layers` 连续段合成。
- **组蒙版**（T67）：`group.mask.exists/enabled`；maskStore 以 groupId 存；空白 tile = 隐藏（DstIn 透明），白色笔触 = 显示；可启用/禁用/删除/应用 + undo。
- **组剪贴**（T67）：`group.clip=true` 时组整体被其**下方图层 alpha** DstIn 裁切（最小语义）。
- **蒙版**：`exists=true` 才参与合成；`enabled=false` 暂停；蒙版像素存独立 `maskStore`（tile）。
- **剪贴**：`clip=true` 的图层用**其下方图层**的 alpha 做 DstIn（1 级）。
- **锁定**：`locked=true` 时 `beginStroke()` 返回 false，不产生笔触。
- **Alpha Lock**（T65）：`alphaLock=true` 时笔刷/擦除只作用于已有不透明像素 alpha 内；序列化保留；engine `setLayerAlphaLock(id,bool)`、LayerSystem 同名。
- 16 混合：`normal, dissolve, darken, multiply, color-burn, lighten, screen, color-dodge, overlay, soft-light, hard-light, difference, exclusion, hue, saturation, color, luminosity`（dissolve 以 SrcOver 近似）。

---

## 2. 接口

### Engine（`v2/engine/src/engine.js`）

| API | 说明 |
|---|---|
| `getDoc()` / `setDoc(doc)` | 读写 V2Doc（setDoc 仅元数据，尺寸需一致） |
| `addGroup(name)` / `getGroups()` | 1 级组 |
| `addLayer(opts)` / `setActiveLayer(id)` / `getLayers()` | 图层（opts 可含 `group`） |
| `setLayerVisible/opacity/blend/clip/locked(id, v)` | 16 混合名非法时回落 normal |
| `setLayerAlphaLock(id, bool)` | T65 Alpha Lock |
| `setActiveGroup(id)` / `setActiveTarget('group-mask')` | T67 组蒙版编辑目标 |
| `addGroupMask/removeGroupMask/setGroupMaskEnabled/applyGroupMask(groupId, ...)` | T67 组蒙版 |
| `setGroupClip(groupId, bool)` | T67 组剪贴 |
| `releaseHistorySnapshots()` | T65 显式释放历史/结构 detached image（保留当前 tile 引用） |
| `addMask(id)` / `removeMask(id)` / `setMaskEnabled(id, bool)` | 蒙版 |
| `setActiveTarget('layer' \| 'mask')` | 下一笔目标；蒙版笔触自动写 maskStore + undo |
| `serializeDoc()` | 返回 `.mozheng` JSON string（见 §3） |
| `deserializeDoc(json)` | 加载；清空 undo、还原 tile/doc、可继续编辑 |
| `undo()/redo()` | 图层/蒙版统一（entry.storeKind: `'layer'`/`'mask'`） |

### LayerSystem（`v2/layers/layer-system.js`）

| API | 说明 |
|---|---|
| `getDoc()` | 把当前图层/组/蒙版导出 V2Doc |
| `applyDoc(doc)` | 用 V2Doc 替换元数据并重合成（尺寸需一致；像素 tile 仍由 LayerSystem store 持有） |

### PSD（`v2/psd/src/v2doc-bridge.js`）

| API | 说明 |
|---|---|
| `psdDocToV2Doc(psdDoc)` | PSD 模型（ag-psd 导入后）→ V2Doc 结构（组/图层/混合/剪贴/蒙版） |
| `v2DocToPsdDoc(v2doc)` | V2Doc → PSD 模型结构（导出用；像素 canvas 由 exporter/上层补） |
| `compareStructure(v2doc, psdDoc)` | 结构对比（图层/组/蒙版数量） |

---

## 3. `.mozheng` 单文件格式（零依赖）

```jsonc
{
  "format": "mozheng",
  "version": 1,
  "doc": { /* §1 V2Doc */ },
  "tiles": {
    "layer-1": { "1,2": "<PNG base64>", "2,2": "<PNG base64>" }
  },
  "masks": {
    "layer-1": { "1,2": "<PNG base64>" }
  }
}
```

- **单文件**：UTF-8 JSON，扩展名 `.mozheng`；tile 为 256×256 PNG base64（仅非空 tile，稀疏）。
- **加载**：`deserializeDoc(json)` 校验 doc（schema/尺寸/id/blend/悬空 group），解码每 tile PNG → GPU image，写入新 TileStore；undo 清空；随后继续编辑。
- **限制（T60）**：tile 整块 PNG（未做 bbox 裁剪/压缩/TAR/流式）；4096² 大文档体积/导出 Worker 留 T61/M4.5；不兼容旧 PNG 快照恢复（旧 app 行为保留）。

---

## 4. 渲染与性能

- `Compositor.drawDocument(c, doc, store, maskStore, {live})`：组 saveLayer → 图层（内容 + 蒙版 DstIn + 剪贴 DstIn + live 预览）→ 整帧。
- present/live 沿用 T44/T46/T49：live surface 实时预览；present = 保留帧重建 + 整帧 blit（自适应 ≤2048² 开、>2048² 关）。
- 现有性能不回退：doc 测试 512² 全部通过；engine 2048² present-stability 保持（3500/2557）；smoke 147fps 级。

---

## 5. T61 交接清单

1. **保存/打开**：调用 `engine.serializeDoc()` 存 `.mozheng`（File System Access API/下载）；打开时 `await engine.deserializeDoc(json)`，再刷新 UI 图层树。
2. **图层树**：读 `engine.getDoc()`（groups + layers 顺序）；组/图层显示可见性、锁定、不透明度、混合、蒙版标记、剪贴标记。
3. **编辑操作**：新建组/图层、改可见/不透明/混合（16 项）/锁定/剪贴、加/删/启停蒙版、选活动层/目标（layer/mask）→ 调 engine API 后重绘 UI。
4. **PSD 导入**：`importPsd` → `psdDocToV2Doc` → `engine.setDoc(doc)` + 像素写入（可复用 `applyDocumentToLayerSystem` 或写 tile）；导出：`v2DocToPsdDoc` + exporter。
5. **UI 注意**：16 混合模式下拉；组仅 1 级（不提供无限嵌套）；蒙版模式需明显提示当前目标；`.mozheng` 加载后 undo 为空（预期）。
6. **未做（后续）**：组蒙版/组剪贴、嵌套组、图层样式/文字 PSD 可编辑、tile bbox 裁剪/压缩、4096² Worker 导出。

---

## 6. 变更记录

| 版本 | 日期 | 变更 |
|---|---|---|
| 1.0 | 2026-11-06 | T60：V2Doc 模型/API、`.mozheng` JSON 格式、Engine 图层能力（组/蒙版/剪贴/16 混合/锁定）、LayerSystem 适配、PSD 桥、测试与 T61 交接 |
