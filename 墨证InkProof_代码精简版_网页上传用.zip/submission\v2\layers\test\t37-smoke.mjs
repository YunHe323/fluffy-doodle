#!/usr/bin/env node
// v2/layers/test/t37-smoke.mjs —— T37 冒烟（零依赖 CDP）
// 用法：node v2/layers/test/t37-smoke.mjs <layers|selection> <pageUrl> [port]
import process from 'node:process';

const which = process.argv[2] || 'layers';
const pageUrl = process.argv[3] || `http://127.0.0.1:8899/v2/${which}/demo.html`;
const port = Number(process.argv[4] || 9333);
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes(`v2/${which}/demo.html`));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到页面', which); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const layerExpr = `new Promise(async (resolve) => {
  const t0 = Date.now();
  const wait = async (cond) => { while (!cond()) { if (Date.now() - t0 > 20000) throw new Error('timeout'); await new Promise((r) => setTimeout(r, 200)); } };
  try {
    await wait(() => window.__LAYERS_READY__);
    const ls = window.__LAYERS__;
    const out = { ready: true, steps: {} };
    const stroke = (x, y) => {
      ls.beginStroke({ x, y, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
      for (let i = 0; i < 30; i += 1) ls.appendPoint({ x: x + i * 6, y: y + Math.sin(i / 5) * 40, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
      ls.endStroke();
    };
    stroke(300, 500); stroke(320, 700);
    out.steps.strokes = ls.getStats();
    // 组 + 混合 + 不透明度
    ls.addGroup('G1');
    const g = ls.listGroups()[0];
    const l = ls.activeLayer();
    l.group = g.id;
    for (const m of ['normal','multiply','screen','overlay','soft-light','darken','color-dodge','hard-light','difference','hue','luminosity']) ls.setLayerBlend(l.id, m);
    ls.setLayerBlend(l.id, 'multiply');
    ls.setLayerOpacity(l.id, 0.8);
    ls.composite();
    out.steps.groupBlend = 'ok';
    // 蒙版：加 + 画 + 应用
    ls.addMask(l.id);
    ls.setActiveTarget('mask');
    stroke(400, 600);
    out.steps.maskTiles = ls.getStats().tileCount;
    ls.setActiveTarget('layer');
    ls.applyMask(l.id);
    out.steps.maskApplied = !ls.activeLayer().mask.exists;
    // 剪贴
    ls.addLayer({ name: 'clip layer' });
    ls.setLayerClip(ls.activeLayerId, true);
    ls.composite();
    out.steps.clip = 'ok';
    // 图层操作
    ls.duplicateLayer(ls.activeLayerId);
    ls.moveLayer(ls.activeLayerId, -1);
    ls.flattenAll();
    out.steps.flat = ls.getStats();
    // undo/redo：最后一笔来自 flatten 前（image undo 无）；用笔画测试
    stroke(500, 800);
    const beforeUndo = ls.getStats().undoDepth;
    ls.undo(); ls.redo();
    out.steps.undo = { before: beforeUndo, after: ls.getStats().undoDepth };
    const url = await ls.getCompositeDataUrl();
    out.steps.pngBytes = Math.round(url.length * 0.75);
    out.steps.pngOk = url.startsWith('data:image/png;base64,') && out.steps.pngBytes > 1000;
    out.steps.final = ls.getStats();
    out.ok = out.steps.pngOk && out.steps.strokes.tileCount > 0 && out.steps.maskApplied === true;
    resolve(out);
  } catch (e) { resolve({ ready: false, error: String(e && e.stack || e) }); }
})`;

const selExpr = `new Promise(async (resolve) => {
  const t0 = Date.now();
  const wait = async (cond) => { while (!cond()) { if (Date.now() - t0 > 20000) throw new Error('timeout'); await new Promise((r) => setTimeout(r, 200)); } };
  try {
    await wait(() => window.__SEL_READY__);
    const { ls, sel } = window.__SEL__;
    const out = { ready: true, steps: {} };
    const png = () => ls.getCompositeDataUrl();
    const stroke = (x, y) => {
      ls.beginStroke({ x, y, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
      for (let i = 0; i < 30; i += 1) ls.appendPoint({ x: x + i * 6, y: y + Math.sin(i / 5) * 40, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
      ls.endStroke();
    };
    // 无选区先画一笔
    stroke(300, 500);
    out.steps.base = ls.getStats();
    // 矩形选区（右下区域）
    sel.rect(1200, 1200, 1800, 1800, 'add');
    out.steps.rect = { hasSelection: sel.hasSelection };
    // 选区外画 → 应几乎不改变合成（约束生效）
    const pngBefore = await png();
    stroke(100, 100);
    const pngAfter = await png();
    out.steps.outside = { beforeBytes: Math.round(pngBefore.length * 0.75), afterBytes: Math.round(pngAfter.length * 0.75), constrained: Math.abs(pngAfter.length - pngBefore.length) / pngBefore.length < 0.02 };
    // 选区内画 → 应改变
    stroke(1300, 1300);
    out.steps.inside = ls.getStats();
    // 变换：开始/移动/提交/撤销
    sel.beginTransform(ls.activeLayerId, { useSelection: true });
    sel.updateTransform({ x: 40, y: 20, rotate: 15, scaleX: 0.9, scaleY: 0.9 });
    sel.commitTransform();
    const afterCommit = ls.getStats();
    out.steps.transform = { undoDepthAfterCommit: afterCommit.undoDepth };
    ls.undo();
    out.steps.undo = { undoDepthAfterUndo: ls.getStats().undoDepth };
    // 魔棒（在当前合成上取色）
    await sel.wandAt(1300, 1300, 'add');
    out.steps.wand = { hasSelection: sel.hasSelection };
    const url2 = await png();
    out.steps.pngBytes = Math.round(url2.length * 0.75);
    out.steps.pngOk = url2.startsWith('data:image/png;base64,') && out.steps.pngBytes > 1000;
    out.steps.final = ls.getStats();
    out.ok = out.steps.pngOk && out.steps.rect.hasSelection && out.steps.outside.constrained === true;
    resolve(out);
  } catch (e) { resolve({ ready: false, error: String(e && e.stack || e) }); }
})`;

const expression = which === 'layers' ? layerExpr : selExpr;
const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1200)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
ws.close();
process.exit(value.ok ? 0 : 1);
