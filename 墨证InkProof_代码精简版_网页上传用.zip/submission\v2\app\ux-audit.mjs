// v2/app/ux-audit.mjs — 前端体验审计（T120，2026-11-08）
// 目的：用真实浏览器打开应用，按「用户第一次进来会看到什么」的顺序截取关键界面，
//      并采集可量化信号（首屏耗时、console error、布局溢出、触控目标尺寸、对比度线索）。
// 产物：v2/qa/ux/ux-audit-{n}-{name}.png + v2/qa/ux/ux-audit-result.json
// 只读：不修改产品代码，不写入档案。
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = Number(process.env.SERVE_PORT || 4212);
const OUT = path.join(ROOT, 'v2', 'qa', 'ux');
fs.mkdirSync(OUT, { recursive: true });
const SHOT = (n, name) => path.join(OUT, `ux-audit-${n}-${name}.png`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const out = {
  schema: 'mozheng.qa.ux-audit.v1',
  port: PORT,
  timestamp: null,
  metrics: {},
  signals: [],
  consoleErrors: [],
  pageErrors: [],
  shots: [],
};
const signal = (id, severity, detail) => out.signals.push({ id, severity, detail });

let browser = null;
let finished = false;
const finish = (code) => {
  if (finished) return;
  finished = true;
  out.timestamp = new Date().toISOString();
  try { fs.writeFileSync(path.join(OUT, 'ux-audit-result.json'), JSON.stringify(out, null, 2), 'utf8'); } catch (e) { /* ignore */ }
  try { if (browser) browser.close(); } catch (e) { /* ignore */ }
  console.log('[UX-AUDIT] signals=' + out.signals.length +
    ' consoleErrors=' + out.consoleErrors.length +
    ' pageErrors=' + out.pageErrors.length);
  process.exit(code);
};
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_180s'; finish(3); }, 180000);

try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  const page = await context.newPage();
  page.on('pageerror', (e) => out.pageErrors.push(String(e).slice(0, 400)));
  page.on('console', (m) => { if (m.type() === 'error') out.consoleErrors.push(m.text().slice(0, 300)); });

  // ---- 1. 首屏加载 ----
  const t0 = Date.now();
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'load', timeout: 60000 });
  out.metrics.domContentLoadedMs = Date.now() - t0;
  await page.waitForFunction(() => !!(window.__APP_DEBUG__ || document.getElementById('app')), null, { timeout: 30000 }).catch(() => {});
  const t1 = Date.now();
  await sleep(2500);
  out.metrics.firstPaintSettledMs = Date.now() - t0;
  await page.screenshot({ path: SHOT(1, 'first-screen') });
  out.shots.push('ux-audit-1-first-screen.png');

  // 引擎就绪信号
  const ready = await page.evaluate(() => {
    const dbg = window.__APP_DEBUG__ ? window.__APP_DEBUG__() : null;
    return {
      hasDebug: !!window.__APP_DEBUG__,
      debug: dbg ? { engineReady: dbg.engineReady, canvas: dbg.canvasSize, layers: dbg.layers, mode: dbg.mode } : null,
      canvasCount: document.querySelectorAll('canvas').length,
      engineCanvasSize: (() => { const c = document.getElementById('engineCanvas') || document.querySelector('canvas'); return c ? { w: c.width, h: c.height, cw: c.clientWidth, ch: c.clientHeight } : null; })(),
    };
  });
  out.metrics.ready = ready;

  // ---- 2. 布局健康：横向溢出 / 元素超出视口 ----
  const layout = await page.evaluate(() => {
    const vw = document.documentElement.clientWidth, vh = document.documentElement.clientHeight;
    const overflowX = document.documentElement.scrollWidth - vw;
    const bad = [];
    document.querySelectorAll('body *').forEach((el) => {
      const r = el.getBoundingClientRect();
      if (!r.width && !r.height) return;
      if (r.right > vw + 2 || r.left < -2 || r.bottom > vh + 400) {
        const st = getComputedStyle(el);
        if (st.visibility === 'hidden' || st.display === 'none' || st.opacity === '0') return;
        if (el.closest('.modal-mask:not(.show)') || el.closest('[hidden]')) return;
        bad.push({ tag: el.tagName, id: el.id || null, cls: (el.className || '').toString().slice(0, 40), right: Math.round(r.right), bottom: Math.round(r.bottom), w: Math.round(r.width), h: Math.round(r.height) });
      }
    });
    return { vw, vh, overflowX, badCount: bad.length, bad: bad.slice(0, 15) };
  });
  out.metrics.layout = layout;
  if (layout.overflowX > 2) signal('LAYOUT-HOVERFLOW', 'P1', `横向溢出 ${layout.overflowX}px @1440x900`);
  if (layout.badCount > 0) signal('LAYOUT-OFFSCREEN', 'P2', `${layout.badCount} 个可见元素超出视口：${layout.bad.map((b) => b.id || b.cls).join(', ').slice(0, 200)}`);

  // ---- 3. 触控目标尺寸（<24px 的可点元素） ----
  const tiny = await page.evaluate(() => {
    const list = [];
    document.querySelectorAll('button, [role="button"], input[type=checkbox], .mode-opt').forEach((el) => {
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) return;
      const st = getComputedStyle(el);
      if (st.visibility === 'hidden' || st.display === 'none') return;
      if (el.closest('.modal-mask:not(.show)') || el.closest('[hidden]')) return;
      if (r.width < 24 || r.height < 24) list.push({ id: el.id || null, text: (el.textContent || '').trim().slice(0, 16), w: Math.round(r.width), h: Math.round(r.height) });
    });
    return list;
  });
  out.metrics.tinyTargets = tiny;
  if (tiny.length > 0) signal('TOUCH-TINY', 'P2', `${tiny.length} 个可点目标 <24px：${tiny.slice(0, 8).map((t) => `${t.id || t.text}(${t.w}x${t.h})`).join(', ')}`);

  // ---- 4. 空状态与首屏引导：新用户是否知道第一步做什么 ----
  const guide = await page.evaluate(() => {
    const txt = (document.body.innerText || '');
    return {
      hasOnboarding: /新手|引导|第一步|从这里开始|快速开始/.test(txt),
      hasHintAboutSelect: /框选|选区|拖出/.test(txt),
      statusText: (document.getElementById('statusAiState') || {}).textContent || null,
      aiStatus: (document.getElementById('aiStatus') || {}).textContent || null,
      visibleButtons: Array.from(document.querySelectorAll('button')).filter((b) => { const r = b.getBoundingClientRect(); return r.width && r.height && !b.closest('.modal-mask:not(.show)'); }).length,
    };
  });
  out.metrics.guide = guide;
  if (!guide.hasOnboarding) signal('ONBOARDING-MISSING', 'P1', '首屏无新手引导/第一步提示；可见按钮 ' + guide.visibleButtons + ' 个，新用户需要自己猜流程');

  // ---- 5. AI 面板：待命状态是否有清晰反馈 ----
  await page.evaluate(() => { const a = window.__V2_APP__; if (a) a.openPopover('popAI'); });
  await sleep(900);
  await page.screenshot({ path: SHOT(2, 'ai-panel-idle') });
  out.shots.push('ux-audit-2-ai-panel-idle.png');

  // ---- 6. 空白画布点「让 AI 看看」——应被预检拦截：不弹付费确认、给出引导 ----
  // 先手动收起引导卡（不走 qsClose，避免写入 localStorage 的「已dismiss」标记），
  // 再点按钮，验证预检会把引导卡请回来且不弹确认框。
  await page.evaluate(() => { const q = document.getElementById('quickStart'); if (q) q.hidden = true; });
  await sleep(300);
  const blankGuard = await page.evaluate(async () => {
    const b = document.getElementById('btnAskAi');
    if (!b) return { err: 'btnAskAi missing' };
    b.click();
    await new Promise((r) => setTimeout(r, 700));
    return {
      confirmShown: document.getElementById('aiConfirmModal').classList.contains('show'),
      toast: ((document.getElementById('toastWrap') || {}).innerText || '').trim(),
      quickStartReshown: !document.getElementById('quickStart').hidden,
      blank: window.__V2_APP__ ? window.__V2_APP__.quickStartBlank() : null,
    };
  });
  out.metrics.blankGuard = blankGuard;
  await page.screenshot({ path: SHOT(3, 'blank-canvas-guard') });
  out.shots.push('ux-audit-3-blank-canvas-guard.png');
  if (blankGuard.confirmShown) signal('GUARD-CONFIRM-LEAK', 'P1', '空白画布仍弹出付费确认框（预检未生效）');
  if (!blankGuard.toast) signal('GUARD-NO-TOAST', 'P1', '空白画布点击 AI 无任何提示');
  if (blankGuard.blank === true && !blankGuard.quickStartReshown) signal('GUARD-NO-QUICKSTART', 'P2', '空白画布被拦截但引导卡未重新出现');

  // ---- 6b. 等待计时器：用调试探针驱动一个 2.5s 的假等待，观察 aiStatus 是否带「已等待 Ns」 ----
  const waitTimer = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    if (!a || !a.debugWait) return { err: 'no debugWait' };
    a.debugWait.begin('读取选区…');
    await new Promise((r) => setTimeout(r, 2500));
    const mid = (document.getElementById('aiStatus') || {}).textContent || '';
    a.debugWait.end();
    await new Promise((r) => setTimeout(r, 200));
    return { mid, end: (document.getElementById('aiStatus') || {}).textContent || '' };
  });
  out.metrics.waitTimer = waitTimer;
  await page.screenshot({ path: SHOT(6, 'ai-wait-elapsed') });
  out.shots.push('ux-audit-6-ai-wait-elapsed.png');
  if (!/已等待/.test(waitTimer.mid || '')) signal('WAIT-NO-ELAPSED', 'P2', 'AI 等待期间状态未显示已等待秒数：' + (waitTimer.mid || ''));

  // ---- 7. 1280x800 与 1920x1080 两个常见分辨率 ----
  for (const vp of [{ w: 1280, h: 800, n: 4, name: 'viewport-1280' }, { w: 1920, h: 1080, n: 5, name: 'viewport-1920' }]) {
    await page.setViewportSize({ width: vp.w, height: vp.h });
    await sleep(900);
    await page.screenshot({ path: SHOT(vp.n, vp.name) });
    out.shots.push(`ux-audit-${vp.n}-${vp.name}.png`);
    const lo = await page.evaluate(() => ({ ox: document.documentElement.scrollWidth - document.documentElement.clientWidth, oy: document.documentElement.scrollHeight - document.documentElement.clientHeight }));
    out.metrics['layout_' + vp.w] = lo;
    if (lo.ox > 2) signal('LAYOUT-OVERFLOW-' + vp.w, 'P1', `${vp.w}px 宽时横向溢出 ${lo.ox}px`);
  }

  // ---- 8. 顶部/底部工具栏在小屏是否挤压 ----
  await page.setViewportSize({ width: 1440, height: 900 });
  await sleep(600);

  if (out.consoleErrors.length) signal('CONSOLE-ERRORS', 'P1', out.consoleErrors.slice(0, 5).join(' | ').slice(0, 400));
  if (out.pageErrors.length) signal('PAGE-ERRORS', 'P0', out.pageErrors.slice(0, 3).join(' | ').slice(0, 300));

  clearTimeout(hard);
  finish(0);
} catch (e) {
  out.fatal = String(e && e.stack || e).slice(0, 800);
  clearTimeout(hard);
  finish(2);
}
