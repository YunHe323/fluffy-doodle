/**
 * v2/psd · 保真比对（源 PSD 导入模型 vs 往返后模型）
 *
 * 结构：类型/名字/可见性/剪贴/混合/不透明度/蒙版存在性/子节点数
 * 像素：逐图层 canvas 比对（changedPct / meanAbsDiff；容差应对 canvas 预乘 alpha）
 * 输出：每样本 structurePass / pixelPassRate / maskPreserved / blendPreserved，
 *       以及节点级 rows 便于定位差异。
 */
const PIXEL_DIFF_THRESHOLD = 8;      // 单通道差值超过该值记为 changed
const CHANGED_PCT_PASS = 0.01;       // ≤1% 像素变化
const MEAN_ABS_PASS = 1.5;           // 平均绝对差 ≤1.5/255
const OPACITY_EPS = 2 / 255 + 1e-6;  // PSD 不透明度量化 1/255

export function compareDocuments(srcDoc, roundDoc, meta = {}) {
  const rows = [];
  const agg = { nodes: 0, structureMatched: 0, maskSource: 0, maskRoundtrip: 0, blendMatched: 0, opacityMaxDelta: 0, pixelLayers: 0, pixelPass: 0, changedPctSum: 0, meanAbsSum: 0 };
  walkPair(srcDoc.children || [], roundDoc.children || [], '', rows, agg);
  const nodes = agg.nodes;
  return {
    ...meta,
    structurePass: nodes > 0 && agg.structureMatched === nodes,
    structureMatchRate: nodes ? round(agg.structureMatched / nodes, 4) : 0,
    maskPreserved: agg.maskSource === 0 ? true : agg.maskRoundtrip === agg.maskSource,
    blendPreserved: nodes ? agg.blendMatched === nodes : false,
    opacityMaxDelta: round(agg.opacityMaxDelta, 4),
    pixelLayers: agg.pixelLayers,
    pixelPassRate: agg.pixelLayers ? round(agg.pixelPass / agg.pixelLayers, 4) : 1,
    meanAbsDiffAvg: agg.pixelLayers ? round(agg.meanAbsSum / agg.pixelLayers, 3) : 0,
    changedPctAvg: agg.pixelLayers ? round(agg.changedPctSum / agg.pixelLayers, 5) : 0,
    rows,
  };
}

function walkPair(srcNodes, roundNodes, path, rows, agg) {
  const len = Math.max(srcNodes.length, roundNodes.length);
  for (let i = 0; i < len; i += 1) {
    const src = srcNodes[i];
    const rt = roundNodes[i];
    const name = (src && src.name) || (rt && rt.name) || `#${i}`;
    const p = path ? `${path}/${name}` : name;
    if (!src || !rt) {
      agg.nodes += 1;
      rows.push({ path: p, kind: 'missing', structure: false });
      continue;
    }
    agg.nodes += 1;
    const typeMatch = src.type === rt.type;
    const nameMatch = src.name === rt.name;
    const visibleMatch = src.visible === rt.visible;
    const clipMatch = !!src.clip === !!rt.clip;
    const blendMatch = src.blendMode === rt.blendMode;
    const maskMatch = !!src.mask === !!rt.mask;
    const opacityDelta = Math.abs((src.opacity || 0) - (rt.opacity || 0));
    const childCountMatch = (src.children ? src.children.length : 0) === (rt.children ? rt.children.length : 0);
    const structure = typeMatch && nameMatch && visibleMatch && clipMatch && blendMatch && maskMatch && opacityDelta <= OPACITY_EPS && childCountMatch;
    if (structure) agg.structureMatched += 1;
    if (blendMatch) agg.blendMatched += 1;
    if (maskMatch && src.mask) agg.maskSource += 1;
    if (maskMatch && src.mask && rt.mask) {
      agg.maskRoundtrip += 1;
      const maskDiff = diffCanvases(src.mask, rt.mask);
      agg.changedPctSum += maskDiff.changedPct;
      agg.meanAbsSum += maskDiff.meanAbsDiff;
      agg.pixelLayers += 1;
      if (maskDiff.changedPct <= CHANGED_PCT_PASS && maskDiff.meanAbsDiff <= MEAN_ABS_PASS) agg.pixelPass += 1;
    }
    agg.opacityMaxDelta = Math.max(agg.opacityMaxDelta, opacityDelta);
    const row = {
      path: p,
      kind: src.type,
      structure,
      typeMatch, nameMatch, visibleMatch, clipMatch, blendMatch, maskMatch, opacityDelta: round(opacityDelta, 4),
      src: { name: src.name, blend: src.blendMode, opacity: round(src.opacity, 3), mask: !!src.mask },
      round: { name: rt.name, blend: rt.blendMode, opacity: round(opacityOf(rt), 3), mask: !!rt.mask },
    };
    if (src.type === 'layer' && src.canvas && rt.canvas) {
      const diff = diffCanvases(src.canvas, rt.canvas);
      row.pixels = diff;
      agg.pixelLayers += 1;
      agg.changedPctSum += diff.changedPct;
      agg.meanAbsSum += diff.meanAbsDiff;
      if (diff.changedPct <= CHANGED_PCT_PASS && diff.meanAbsDiff <= MEAN_ABS_PASS) agg.pixelPass += 1;
    }
    rows.push(row);
    if (src.children && rt.children) walkPair(src.children, rt.children, p, rows, agg);
  }
}

function opacityOf(node) { return node.opacity == null ? 1 : node.opacity; }

/** 两个 canvas 的像素差（RGBA，忽略双方都完全透明的像素） */
export function diffCanvases(a, b) {
  const w = Math.min(a.width, b.width);
  const h = Math.min(a.height, b.height);
  if (w <= 0 || h <= 0) return { changedPct: 0, meanAbsDiff: 0, pixels: 0 };
  const ca = document.createElement('canvas'); ca.width = w; ca.height = h;
  const cb = document.createElement('canvas'); cb.width = w; cb.height = h;
  ca.getContext('2d').drawImage(a, 0, 0);
  cb.getContext('2d').drawImage(b, 0, 0);
  const da = ca.getContext('2d').getImageData(0, 0, w, h).data;
  const db = cb.getContext('2d').getImageData(0, 0, w, h).data;
  let changed = 0;
  let visible = 0;
  let sumAbs = 0;
  for (let i = 0; i < da.length; i += 4) {
    const aAlpha = da[i + 3];
    const bAlpha = db[i + 3];
    if (aAlpha === 0 && bAlpha === 0) continue;
    visible += 1;
    let maxDiff = 0;
    let localSum = 0;
    for (let k = 0; k < 4; k += 1) {
      const d = Math.abs(da[i + k] - db[i + k]);
      if (d > maxDiff) maxDiff = d;
      localSum += d;
    }
    sumAbs += localSum;
    if (maxDiff > PIXEL_DIFF_THRESHOLD) changed += 1;
  }
  return {
    changedPct: visible ? round(changed / visible, 5) : 0,
    meanAbsDiff: visible ? round(sumAbs / (visible * 4), 3) : 0,
    pixels: visible,
  };
}

function round(n, digits) {
  const f = 10 ** digits;
  return Math.round(n * f) / f;
}
