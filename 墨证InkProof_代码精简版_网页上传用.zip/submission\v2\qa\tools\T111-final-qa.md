# T111 独立 QA：AI 面板收口 + 长对话记忆 + 首屏 quickstart

> 执行：qa-engineer（独立 QA｜task-122）｜日期：2026-11-07 21:0x｜只写 `v2/qa/tools/`；**未改 app**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、单浏览器串行、小批次（日志 `archive/baseline-t111-final/logs/`）；执行期内存约 3.7GB；用 python http.server 避免覆写 `.runtime-port`。

## 结论

**可交付（Deliverable）——P0/P1/P2 = 0（附 1 条流程提示，非产品缺陷）。**
2 个新测试 + 14 项回归全 PASS、0 console error；18 项独立焦点核验全 PASS；长对话/画像持久化、清空对话保留画像、quickstart 条件与记忆、pinned 滚动可见、记录子页、模型 badge 均确认；证据 mtime 未变、无付费调用、残留 0。

## 1. 新测试（PASS）

| 测试 | 关键证据 |
|---|---|
| `test-ai-panel-v3.mjs` | 3 primary tabs **观察/生成/记录**；pinned 含 模型·选区·档案·素材·成本（`¥0 · 不联网`）；记录子页 档案/证据 可切换；模型 badge → 模型面板（badge active）且可回观察；3 轮对话 Mock 记忆含画像「冷灰蓝、留白、颗粒」；reload 后 chat/profile 仍在；0 error |
| `test-quickstart-context.mjs` | quickstart 可见（2 动作）；点「画一笔」→ 隐藏/工具 brush/dismissed=1；reload 不再出现；AI 面板含「成本 Mock · ¥0 · 不联网 / 上下文」；0 error |

## 2. 独立焦点核验（QA 自建探针，18/18 PASS）

| 检查 | 结果 |
|---|---|
| 面板 3 tabs | labels `观察/生成/记录` ✅ |
| pinned 内容 | 本地 Mock/Mock · 选区 · 档案 0·素材 0 · ¥0·不联网 ✅ |
| **pinned 滚动可见** | pinned rect 滚动前后均 **140–175**（在面板 50–731 内、视口内），结构上位于滚动区 `#aiBody` 之外（flex:0 0 auto）✅ |
| 记录 tab 子页 | 档案 block/证据 none → 切换后 反向；子导航 2 个；active=证据 ✅ |
| 模型 badge | 点击后 模型面板 display=block、badge active、内含「模型控制台」；回到观察正常 ✅ |
| **对话 payload（Mock 回复反证）** | 回复含：选区 300×200、素材库 3 张、档案 0 条、**我记住的你是：风格「冷灰蓝、留白、颗粒」**、**结合画面和对话上下文**（images 已传）✅ |
| **记录字段** | L6 chat 记录 `context_flags{selection,canvas,library,archive 全 true}`、`images=2`、question 正确 ✅ |
| 会话上下文 chips | 4 个（选区图/整幅画布/素材库/档案·证据）✅ |
| **history 上限 30 / 消息 4000** | 服务端代码核验（python 直出 JS）：`input.history.slice(-30)` + `String(m.content).slice(0,4000)` 均存在 ✅（注：MockProvider 本地路径不截断，仅真实 provider 上限，不产生成本） |
| payload 代码字段 | app：`library`（assets≤10）`archive` `recent_events` `profile` `context_flags` `conversation_count` 均在 buildChatContext ✅ |
| **chat/profile 持久化** | localStorage 两键均存在；reload 后 aiChat=37、profile 保留 ✅ |
| **清空对话** | 点击清空 → aiChat=0、chat localStorage 删除、**画像保留**（state+LS）✅ |
| quickstart 条件 | 空画布+未 dismissed 显示「从这里开始」+2 动作（draw/example）✅ |
| quickstart 记忆 | 点 draw → 隐藏/brush/dismissed=1；reload 隐藏 ✅ |
| quickstart 示例 | 点 example → 隐藏、加载示例（layers=1、有墨）✅ |
| 底栏 statusContext | `图层 2 · 画笔 · Mock · 协作` → 切橡皮后 `图层 2 · 橡皮 · Mock · 协作` ✅ |
| 密钥 | DOM/localStorage/sessionStorage/已加载 JS 均无 key ✅ |
| console error | 全程 **0** ✅ |

## 3. 回归（14 项全 PASS，0 console error）

test-app、test-ui、test-library、test-image-workshop、test-multimodal、test-ux-p0、test-canvas-resize、test-text-edit、test-mask-compare、test-editor-ui、test-ai-provider、test-interaction（单跑 9/9）、test-asset-batch、test-chat（单跑）；连同 2 个新测试，共 **16 项全部 PASS，errors=0**。

## 4. 真实证据（无新增付费调用）

| 证据 | 核对 |
|---|---|
| `asset-real-read-results.json`（mtime 17:12 未变） | pass=true；22,955ms；real / L2=5 / L4=4 |
| `qwen-real-e2e-results.json`（mtime 16:53 未变） | pass=true；21,337ms；obs=2、regions=2、mock=false |
| 本轮真实请求 | **0**（python 离线页，AI 走 Mock；证据文件未更新） |

## 5. 密钥 / 残留 / 打包

- 密钥：无 DOM/LS/SS/已加载 JS 泄漏；未打印 key。
- 残留：Edge **0**、测试端口 **0**（8089 已清理）。
- 打包：`.runtime-port` 曾被其它 serve 实例覆写为 8162（本轮再次观察到），QA 已恢复为 **4200**；`http://127.0.0.1:4200/health` → **200** `{ok:true,port:4200,pid:30792}`。

## 6. 问题清单与提示

| # | 级别 | 内容 | 建议 |
|---|---|---|---|
| — | — | P0 / P1 / P2 | **均无** |
| 提示 1 | 流程 | `.runtime-port` 会被任意 serve.mjs 实例（含其它 agent 的 serve 实例）覆写（本轮又出现 8162） | QA 已恢复 4200；start.bat 启动前会删除重写，功能影响低；建议测试/临时 serve 启动后恢复该文件，或由 serve 仅在非测试环境写 |
| 提示 2 | 一致性 | `MockProvider.converse` 本地路径不截断 history（真实 provider 已 `slice(-30)`） | 本地 Mock 无成本/隐私风险；若追求语义一致可在 mock 中也截断（可选，不阻塞） |

## 7. 产物与归档

- `v2/qa/tools/T111-final-qa.md`（本报告）
- `v2/qa/tools/archive/baseline-t111-final/`：`logs/`（16 项测试全部日志）、各 result JSON、`focus-results.json`（18 项焦点核验）、真实证据 JSON、README
- GATE：`v2/qa/tools/GATE-pw.md`「T111 最终独立 QA」行
