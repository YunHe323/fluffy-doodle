// v2/app/test-shape-snap.mjs —— 形状工具网格吸附（L6 记录坐标）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8165;
const out = { schema: 'mozheng.app.shape-snap.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-shape-snap-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  const map = await page.evaluate(() => {
    const a = window.__V2_APP__;
    a.state.showGrid = true; a.state.showThirds = false; a.state.symmetryAxis = null;
    a.setTool('shape'); a.state.shapeType = 'rect';
    const r = document.getElementById('mainCanvas').getBoundingClientRect();
    return { left: r.left, top: r.top, width: r.width, height: r.height, ew: a.engine.width, eh: a.engine.height };
  });
  const toClient = (x, y) => [map.left + (x / map.ew) * map.width, map.top + (y / map.eh) * map.height];
  const [sx, sy] = toClient(242, 162);
  const [ex, ey] = toClient(322, 242);
  await page.mouse.move(sx, sy); await page.mouse.down();
  await page.mouse.move(ex, ey, { steps: 8 }); await page.mouse.up();
  await page.waitForTimeout(900);
  out.cases.record = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const r = a.state.records.filter((x) => x.kind === 'shape_inserted').slice(-1)[0];
    return r ? { x: r.params.x, y: r.params.y, width: r.params.width, height: r.params.height, ax: r.anchor.value } : null;
  });
  out.cases.grid = await page.evaluate(() => ({ showGrid: window.__V2_APP__.state.showGrid, snap: window.__V2_APP__.state.showGrid }));
  out.cases.snapGrid = await page.evaluate(() => { const a = window.__V2_APP__; a.state.showGrid = true; a.state.showThirds = false; return a.snapDocPoint({ x: 241, y: 159 }); });
  out.cases.snapThirds = await page.evaluate(() => { const a = window.__V2_APP__; a.state.showGrid = false; a.state.showThirds = true; const p = a.snapDocPoint({ x: 397, y: 269 }); return { x: p.x, y: p.y }; });
  out.cases.ok = !!out.cases.record && out.cases.record.x === 240 && out.cases.record.y === 160 && out.cases.record.ax[0] === 240 && out.cases.record.ax[1] === 160
    && out.cases.snapGrid.x === 240 && out.cases.snapGrid.y === 160
    && Math.abs(out.cases.snapThirds.x - 400) < 0.01 && Math.abs(out.cases.snapThirds.y - 800 / 3) < 0.01;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.ok && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
