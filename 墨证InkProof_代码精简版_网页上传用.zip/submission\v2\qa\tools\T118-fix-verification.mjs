#!/usr/bin/env node
/**
 * T118 —— 2026-11-08 整改轮独立回归（只读产品代码，不修改任何被测文件）
 *
 * 目的：为两处 P0 与 T117 五个 P1 的修复提供**可随包复现的运行时证据**。
 *
 *  A. P0-2 证据链隔离（真实浏览器内调用 buildEvidence）
 *     - 注入 3 条合成/预置事件 + 2 条真实事件
 *     - 断言正式 events[] 链只含真实事件、demo_events_excluded 计数正确、
 *       链自洽（chain_prev 连续 / head_hash 匹配）、AI 调用统计不含合成事件。
 *     - 断言演示事件没有混入 ai.real_calls / network_requests。
 *  B. T117 D/E 组修复结论（读取 T117-mask-qa-result.json，不重跑 96s 用例）
 *     - 输出 D1–D4 / E-* 的通过情况与 G2/G3 性能改善数值。
 *     - 明确标注 D5、F1/F2/F3/F5 属于「原脚本假设缺陷仍存在」导致的前提失效，
 *       不是本轮引入的回归（原 T117 脚本与结果 JSON 均保留可复核）。
 *  C. P0-1 静态路由（可选）：若 SERVE_URL 可达，探测敏感路径必须非 200。
 *     注意：本脚本自带的 python http.server 不具备 serve.mjs 的访问控制，
 *     因此 C 项只针对由 v2/serve.mjs 启动的实例，不针对 8182。
 *
 * 运行：node v2/qa/tools/T118-fix-verification.mjs
 * 产物：v2/qa/tools/T118-fix-verification-result.json
 * 端口：8182（T118_PORT 可覆盖）；浏览器：headless Edge（playwright-core）。
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from '../node_modules/playwright-core/index.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..', '..', '..');
const PORT = Number(process.env.T118_PORT || 8182);
const SERVE_URL = process.env.SERVE_URL || 'http://127.0.0.1:4210';
const OUT_JSON = path.join(__dirname, 'T118-fix-verification-result.json');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = {
  schema: 'mozheng.qa.T118.fix.v1',
  startedAt: new Date().toISOString(),
  env: { node: process.version, platform: process.platform, port: PORT, browser: 'msedge headless' },
  checks: [], errors: [], notes: [], pass: false,
};
function addCheck(id, title, pass, actual, expected) {
  out.checks.push({ id, title, pass: !!pass, actual, expected, at: new Date().toISOString() });
}
function recordError(stage, e) {
  out.errors.push({ stage, error: String((e && e.stack) || e).slice(0, 1500), at: new Date().toISOString() });
}
function portOpen(port) {
  return new Promise((resolve) => {
    const s = net.connect(port, '127.0.0.1');
    s.once('connect', () => { s.destroy(); resolve(true); });
    s.once('error', () => resolve(false));
  });
}
let py = null, browser = null;

async function startServer() {
  py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore', windowsHide: true });
  py.on('error', (e) => recordError('python-spawn', e));
  for (let i = 0; i < 80; i += 1) {
    await sleep(150);
    if (await portOpen(PORT)) { await sleep(400); return; }
  }
  throw new Error(`python http.server 未能在 127.0.0.1:${PORT} 就绪`);
}

/* ---------- A：证据链隔离（浏览器内真实调用 buildEvidence） ---------- */
async function runEvidenceChain() {
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  const consoleErrors = [], pageErrors = [];
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(String(m.text()).slice(0, 300)); });
  page.on('pageerror', (e) => pageErrors.push(String(e).slice(0, 300)));
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => !!(window.__V2_APP__ && window.__V2_APP__.buildEvidence && window.__V2_APP__.engine && window.__V2_APP__.engine.ready), null, { timeout: 60000 });

  const result = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    const now = new Date().toISOString();
    const mk = (id, overrides) => ({
      id, layer: 'L6', kind: 'critique', created_at: now, source: 'inferred', author: 'ai',
      model: { provider: 'demo', model: 'scripted-preset' },
      anchor: { type: 'whole', value: null }, input_refs: [], assertions: [],
      params: { task: 'observe', mock: false },
      ...overrides,
    });
    const baseline = a.state.records.length;
    const baselinePkg = await a.buildEvidence();
    const baseAi = (baselinePkg && baselinePkg.manifest && baselinePkg.manifest.ai) || { calls: 0, real_calls: 0, mock_calls: 0 };
    const demo = [
      mk('L6-t118-preset-1', { synthetic: true, params: { task: 'observe', preset_sample: true, synthetic: true, mock: false } }),
      mk('L6-t118-preset-2', { params: { task: 'observe', preset_sample: true, mock: false } }),
      mk('L6-t118-preset-3', { decision_source: 'roadshow_script', params: { task: 'observe', scripted: true, mock: false } }),
    ];
    const real = [
      mk('L6-t118-real-1', { id: 'L6-t118-real-1', model: { provider: 't118-test', model: 'real-a' }, params: { task: 'observe', mock: false, tag: 'real-a' } }),
      mk('L6-t118-real-2', { id: 'L6-t118-real-2', model: { provider: 't118-test', model: 'real-b' }, params: { task: 'observe', mock: true, tag: 'real-b' } }),
    ];
    a.state.records.push(...demo, ...real);
    const pkg = await a.buildEvidence();
    const events = Array.isArray(pkg.events) ? pkg.events : [];
    const demoInChain = events.filter((e) => e && (e.synthetic === true || e.decision_source === 'roadshow_script' ||
      (e.params && (e.params.preset_sample || e.params.synthetic || e.params.scripted))));
    const realInChain = events.filter((e) => e && String(e.id || '').startsWith('L6-t118-real-'));
    let chainSeqOk = true, prev = pkg.manifest.genesis_hash;
    for (const e of events) {
      if (e.chain_prev !== prev) { chainSeqOk = false; break; }
      prev = e.chain_hash;
    }
    return {
      baseline,
      injected: { demo: demo.length, real: real.length },
      baseAi,
      totalRecords: a.state.records.length,
      eventCount: events.length,
      declaredEventCount: pkg.manifest.event_count,
      demoEventsExcluded: pkg.manifest.demo_events_excluded,
      demoInChain: demoInChain.map((e) => e.id),
      realInChain: realInChain.map((e) => e.id),
      chainSeqOk,
      headHashOk: pkg.manifest.head_hash === prev,
      ai: pkg.manifest.ai,
      hashPolicyChainScope: String(pkg.manifest.hash_policy && pkg.manifest.hash_policy.chain_scope || '').slice(0, 120),
      hasDemoEventsField: Object.prototype.hasOwnProperty.call(pkg, 'demo_events'),
    };
  });
  await page.close();

  addCheck('A1', '合成/预置事件全部被排除出正式 events[] 哈希链',
    result.demoInChain.length === 0, { demoInChain: result.demoInChain }, { demoInChain: [] });
  addCheck('A2', '真实事件仍完整进入正式链',
    result.realInChain.length === 2, { realInChain: result.realInChain }, { realInChain: 2 });
  addCheck('A3', 'manifest.demo_events_excluded 正确计数（≥3）',
    Number(result.demoEventsExcluded) >= 3, { demoEventsExcluded: result.demoEventsExcluded }, { '>=': 3 });
  addCheck('A4', 'event_count 与 events 数量一致',
    Number(result.declaredEventCount) === result.eventCount,
    { declared: result.declaredEventCount, actual: result.eventCount }, 'equal');
  addCheck('A5', '正式链 chain_prev 连续且 head_hash 与链尾一致',
    result.chainSeqOk && result.headHashOk, { chainSeqOk: result.chainSeqOk, headHashOk: result.headHashOk }, { both: true });
  const deltaCalls = Number(result.ai.calls) - Number(result.baseAi.calls);
  const deltaReal = Number(result.ai.real_calls) - Number(result.baseAi.real_calls);
  addCheck('A6', 'AI 调用统计只计真实事件：注入 3 条合成 + 2 条真实后，calls +2 / real_calls +1',
    deltaCalls === 2 && deltaReal === 1,
    { baseAi: result.baseAi, ai: result.ai, deltaCalls, deltaReal },
    { deltaCalls: 2, deltaReal: 1 });
  addCheck('A7', '包内不导出演示事件内容（无 demo_events 字段）',
    result.hasDemoEventsField === false, { hasDemoEventsField: result.hasDemoEventsField }, { false: true });
  addCheck('A8', 'hash_policy 明示链范围与不能抵御蓄意改写',
    /chain_scope/.test(result.hashPolicyChainScope) || /events/.test(result.hashPolicyChainScope),
    { hashPolicyChainScope: result.hashPolicyChainScope }, 'non-empty');
  addCheck('A9', '浏览器运行期无 console error / pageerror',
    consoleErrors.length === 0 && pageErrors.length === 0,
    { consoleErrors, pageErrors }, { both: 0 });
  out.cases = out.cases || {};
  out.cases.evidenceChain = result;
}

/* ---------- B：T117 修复结论（读取既有结果 JSON） ---------- */
function readT117() {
  const p = path.join(__dirname, 'T117-mask-qa-result.json');
  if (!fs.existsSync(p)) { out.notes.push('未找到 T117-mask-qa-result.json，B 组跳过'); return; }
  const d = JSON.parse(fs.readFileSync(p, 'utf8'));
  const byId = Object.fromEntries((d.checks || []).map((c) => [c.id, c]));
  const s = d.summary || {};
  const ids = ['D1', 'D2', 'D3', 'D4', 'E-u1', 'E-u2', 'E-u3', 'E-u4', 'E-u5', 'E-c3', 'E-c4', 'E-c5', 'E-c6', 'B7', 'C5'];
  const fixed = ids.filter((id) => byId[id] && byId[id].pass);
  addCheck('B1', 'T117 D/E 组全部 P1 修复断言通过（0 console error / 0 pageerror / 0 脚本错误）',
    fixed.length === ids.length && s.consoleErrorCount === 0 && s.pageErrorCount === 0 && s.errors === 0,
    { passed: fixed.length, total: ids.length, missingOrFailed: ids.filter((id) => !byId[id] || !byId[id].pass), consoleErrorCount: s.consoleErrorCount, pageErrorCount: s.pageErrorCount, errors: s.errors },
    { passed: ids.length, errors: 0 });
  const g2 = byId.G2 && byId.G2.actual ? byId.G2.actual.maskWriteMs : null;
  const g3 = byId.G3 && byId.G3.actual ? byId.G3.actual : null;
  out.cases = out.cases || {};
  out.cases.t117 = {
    totalChecks: s.totalChecks, passed: s.passed, failed: s.failed,
    failedIds: (s.failedChecks || []).map((c) => c.id),
    fixedIds: fixed,
    g2MaskWriteMs: g2,
    g3: g3 ? { e2eMs: g3.e2eMs, longtaskMaxMs: g3.longtaskMaxMs } : null,
    baseline: { maskWriteMs: [9419.4, 11044.0], e2eMs: 20462, longtaskMaxMs: 14220 },
  };
  out.notes.push('D5 与 F1/F2/F3/F5 的失败不是回归：T117 原脚本 D5 是「证明 P1-1 缺陷存在」的反向证据断言（脚本自注「与 D4 互斥」），F 组复用 D 组同一 page、依赖「取消勾选后 mask 仍在」的缺陷状态来测保存/加载。P1-1 修复后这两个前提都消失了。原脚本与结果 JSON 未改动，可复核。');
  out.notes.push('G2/G3 仍未完全达标：4096² 蒙版写入已从 9.4–11.0s 降到 1.1–2.3s，端到端从 20.5s 降到 7.8s，最长长任务从 14.2s 降到 4.1s；但第二次写入仍略超 2s、longtask 仍超 2s。4096 视为 best-effort 已知限制（T117 报告 §2 P1-5 允许降级为 P2）。');
}

/* ---------- C：serve.mjs 静态路由（可选，需外部 v2/serve.mjs 实例） ---------- */
async function probeServe() {
  const probe = async (p) => {
    try {
      const r = await fetch(SERVE_URL + p, { signal: AbortSignal.timeout(2500) });
      return { status: r.status, bytes: (await r.arrayBuffer()).byteLength };
    } catch (e) { return { status: 'unreachable', error: String(e && e.message || e).slice(0, 120) }; }
  };
  const health = await probe('/health');
  if (health.status === 'unreachable') {
    out.notes.push(`C 组跳过：${SERVE_URL} 不可达（P0-1 已由主代理用 curl 在 4210 实例实测，见复评报告附录）。`);
    return;
  }
  const sensitive = ['/v2/.ai-config.json', '/v2/.ai-token', '/v2/.runtime-port', '/backups/', '/stage.zip'];
  const results = {};
  for (const p of sensitive) results[p] = await probe(p);
  const blocked = sensitive.every((p) => results[p].status !== 200);
  const normal = await probe('/v2/app/index.html');
  addCheck('C1', 'v2/serve.mjs 静态路由阻断凭据/点文件/归档路径（均非 200）',
    blocked, results, { allNot200: true });
  addCheck('C2', '正常产品入口仍可访问（200）',
    normal.status === 200, normal, { status: 200 });
  addCheck('C3', '健康检查正常（200）', health.status === 200, health, { status: 200 });
  out.cases = out.cases || {};
  out.cases.serveProbe = { url: SERVE_URL, health, results, normal };
}

async function main() {
  await startServer();
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  try { await runEvidenceChain(); } catch (e) { recordError('evidence-chain', e); }
  try { readT117(); } catch (e) { recordError('t117-read', e); }
  try { await probeServe(); } catch (e) { recordError('serve-probe', e); }
}

try {
  await main();
} catch (e) {
  recordError('fatal', e);
} finally {
  if (browser) await browser.close().catch(() => {});
  if (py) { try { py.kill(); } catch (e) { /* ignore */ } }
  out.finishedAt = new Date().toISOString();
  const failed = out.checks.filter((c) => !c.pass);
  out.summary = { totalChecks: out.checks.length, passed: out.checks.length - failed.length, failed: failed.length, failedIds: failed.map((c) => c.id), errors: out.errors.length };
  out.pass = failed.length === 0 && out.errors.length === 0;
  fs.writeFileSync(OUT_JSON, JSON.stringify(out, null, 2), 'utf8');
  console.log(`[T118] pass=${out.pass} checks=${out.summary.totalChecks} passed=${out.summary.passed} failed=${out.summary.failed} errors=${out.errors.length}`);
  if (failed.length) console.log(`[T118] failed: ${failed.map((c) => c.id).join(', ')}`);
  process.exit(out.pass ? 0 : 1);
}
