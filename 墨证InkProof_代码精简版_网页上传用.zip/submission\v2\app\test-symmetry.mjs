// v2/app/test-symmetry.mjs —— 对称笔迹重放（左右）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8164;
const out = { schema: 'mozheng.app.symmetry.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-symmetry-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
const countInk = async (page) => page.evaluate(async () => {
  const a = window.__V2_APP__;
  const url = await a.engine.getCompositeDataUrl();
  const img = new Image(); img.src = url; await img.decode();
  const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
  const g = c.getContext('2d'); g.drawImage(img, 0, 0);
  const d = g.getImageData(0, 0, c.width, c.height).data;
  let left = 0, right = 0;
  for (let y = 0; y < c.height; y += 2) for (let x = 0; x < c.width; x += 2) {
    const i = (y * c.width + x) * 4;
    if (d[i] < 240 || d[i + 1] < 240 || d[i + 2] < 240) { if (x < c.width / 2) left += 1; else right += 1; }
  }
  return { left, right, w: c.width, h: c.height };
});
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1200);
  await page.evaluate(() => { const a = window.__V2_APP__; a.setTool('brush'); a.state.symmetryAxis = 'x'; a.state.showGrid = false; a.state.showThirds = false; });
  await page.waitForTimeout(200);
  const steps0 = await page.evaluate(() => window.__V2_APP__.engine.getHistoryStats().steps);
  const before = await countInk(page);
  const box = await page.locator('#mainCanvas').boundingBox();
  await page.mouse.move(box.x + box.width * 0.3, box.y + box.height * 0.4);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width * 0.4, box.y + box.height * 0.5, { steps: 12 });
  await page.mouse.up();
  await page.waitForTimeout(1200);
  const after = await countInk(page);
  const steps1 = await page.evaluate(() => window.__V2_APP__.engine.getHistoryStats().steps);
  await page.evaluate(() => { window.__V2_APP__.engine.undo(); });
  await page.waitForTimeout(300);
  const undone = await countInk(page);
  out.cases.before = before;
  out.cases.after = after;
  out.cases.steps0 = steps0;
  out.cases.steps1 = steps1;
  out.cases.undoDelta = steps1 - steps0;
  out.cases.undone = undone;
  out.cases.leftInk = after.left - before.left;
  out.cases.rightInk = after.right - before.right;
  out.cases.symmetry = await page.evaluate(() => ({ axis: window.__V2_APP__.state.symmetryAxis, records: window.__V2_APP__.state.records.length }));
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-symmetry-1920.png' });
  out.cases.leftOk = out.cases.leftInk > 20;
  out.cases.rightOk = out.cases.rightInk > 20;
  out.cases.undoOk = out.cases.undoDelta === 1 && (undone.left + undone.right) <= (before.left + before.right) + 4;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.leftOk && out.cases.rightOk && out.cases.undoOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
