/**
 * v2/brushes/tools/mouse-pressure-ab.mjs
 * T54：同一组鼠标轨迹 → 模拟压感 on vs off 对照（默认 headless + 真实 GPU，不弹窗）。
 * 产物：samples/mouse-pressure-on.png / mouse-pressure-off.png / samples/mouse-pressure/mp-data.json
 *
 * 用法（项目根目录，先 node v2/serve.mjs）：
 *   node v2/brushes/tools/mouse-pressure-ab.mjs [--headed]
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
const SAMPLES = path.join(ROOT, 'v2', 'brushes', 'samples');
const OUT = path.join(SAMPLES, 'mouse-pressure');
fs.mkdirSync(OUT, { recursive: true });
const CDP_PORT = Number((process.argv.find((a) => a.startsWith('--cdp=')) || '').split('=')[1] || 9580);
const HEADLESS = !process.argv.includes('--headed');
function resolveBase() {
  if (process.env.INKPROOF_BASE) return process.env.INKPROOF_BASE;
  try {
    const port = fs.readFileSync(path.join(ROOT, 'v2', '.runtime-port'), 'utf8').trim();
    if (/^\d+$/.test(port)) return 'http://127.0.0.1:' + port;
  } catch (e) { /* ignore */ }
  return 'http://127.0.0.1:4200';
}
const URL_ARG = `${resolveBase()}/v2/brushes/tools/mouse-pressure-ab.html`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const EDGE = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
].find((p) => fs.existsSync(p));

const report = { schema: 'inkproof.mouse-pressure-ab.v1', url: URL_ARG, headless: HEADLESS, files: {}, ok: false };
let ws = null; let msgId = 0; const pending = new Map();
const send = (method, params = {}) => new Promise((resolve) => { const id = ++msgId; pending.set(id, resolve); ws.send(JSON.stringify({ id, method, params })); });
async function ev(expression, timeoutMs = 240000) {
  const r = await Promise.race([send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true }), sleep(timeoutMs).then(() => ({ __t: true }))]);
  if (r.__t) throw new Error('evaluate timeout');
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1500));
  return r.result?.result?.value;
}

const profile = path.join(os.tmpdir(), 'mpab-' + Date.now());
const args = ['--remote-debugging-port=' + CDP_PORT, '--user-data-dir=' + profile, '--no-first-run', '--no-default-browser-check'];
if (HEADLESS) args.push('--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1400,1000');
else args.push('--window-size=1400,1000', '--window-position=-3000,-3000', '--start-minimized');
args.push(URL_ARG);
const browser = spawn(EDGE, args, { stdio: 'ignore' });
try {
  let target = null;
  for (let i = 0; i < 400 && !target; i += 1) {
    try { const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json(); target = list.find((t) => t.type === 'page' && /^https?:/.test(t.url)); } catch (e) { /* wait */ }
    if (!target) await sleep(150);
  }
  if (!target) throw new Error('no target');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { const r = pending.get(m.id); pending.delete(m.id); r(m); } };
  await send('Runtime.enable');
  const t0 = Date.now();
  let ready = false;
  while (Date.now() - t0 < 90000) {
    const err = await ev('window.__MPAB_ERROR__ || null').catch(() => null);
    if (err) throw new Error('page error: ' + err);
    ready = await ev('!!window.__MPAB_READY__').catch(() => false);
    if (ready) break;
    await sleep(300);
  }
  if (!ready) throw new Error('mouse-pressure AB page not ready');
  report.ab = await ev('window.__runMPAB__()');
  for (const mode of ['on', 'off']) {
    const entry = report.ab.modes && report.ab.modes[mode];
    if (!entry || !entry.image) continue;
    const file = path.join(SAMPLES, `mouse-pressure-${mode}.png`);
    fs.writeFileSync(file, Buffer.from(entry.image.split(',')[1], 'base64'));
    report.files[mode] = path.relative(ROOT, file).replace(/\\/g, '/');
    delete entry.image;
  }
  report.ok = !!(report.files.on && report.files.off);
  fs.writeFileSync(path.join(OUT, 'mp-data.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ ok: report.ok, headless: HEADLESS, files: report.files, penTest: report.ab.penTest, modes: Object.fromEntries(Object.entries(report.ab.modes || {}).map(([k, v]) => [k, Object.fromEntries(Object.entries(v.strokes || {}).map(([sid, s]) => [sid, { min: s.min, max: s.max, mean: s.mean, tracePoints: s.tracePoints }]))])) }, null, 2));
} catch (e) {
  report.fatal = String(e && e.stack || e);
  fs.writeFileSync(path.join(OUT, 'mp-data.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ ok: false, fatal: report.fatal }, null, 2));
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  try { browser.kill(); } catch (e) { /* ignore */ }
  await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  process.exit(report.ok ? 0 : 1);
}
