// probe-about.mjs
import { spawn } from 'node:child_process';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一'; const PORT = 8125;
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const b = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
const page = await b.newPage({ viewport: { width: 1366, height: 768 } });
await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`); await page.waitForFunction('window.__V2_APP_READY__ === true'); await page.waitForTimeout(800);
await page.click('#btnMore'); await page.waitForTimeout(250); await page.click('#btnAbout'); await page.waitForTimeout(500);
const info = await page.evaluate(() => { const m = document.getElementById('aboutModal'); const cs = getComputedStyle(m); const r = m.getBoundingClientRect(); return { cls: m.className, display: cs.display, visibility: cs.visibility, z: cs.zIndex, rect: [r.x, r.y, r.width, r.height], present: (document.getElementById('aboutPresent') || {}).textContent, topAtCenter: (document.elementFromPoint(innerWidth / 2, innerHeight / 2) || {}).id || (document.elementFromPoint(innerWidth / 2, innerHeight / 2) || {}).className }; });
console.log(JSON.stringify(info, null, 2));
await page.screenshot({ path: ROOT + '\\v2\\app\\probe-about.png' });
await b.close(); py.kill(); process.exit(0);
