// product/test/fixtures.mjs
// 测试用档案记录夹具（对齐 06-技术/数据模型_schema.json v0.2.0）。
// 每个工厂函数返回新对象，避免测试间共享可变状态。

const SHA = '9f2c4e1a9f2c4e1a9f2c4e1a9f2c4e1a9f2c4e1a9f2c4e1a9f2c4e1a9f2c4e1a';

export function baseRecord(overrides = {}) {
  return {
    id: 'L1-a7',
    asset_id: 'a7',
    layer: 'L1',
    anchor: { type: 'whole', value: null, space: 'image_px' },
    source: 'inferred',
    confidence: 0.7,
    author: 'ai',
    mode: 'collab',
    ai_role: 'assistant',
    model_version: 'qwen3.8-flash@2026-11',
    created_at: '2026-11-06T18:00:00+08:00',
    updated_at: null,
    supersedes: null,
    provenance: { session_id: 's-20261106-01', generation_id: null, refs: [] },
    schema_version: '0.2.0',
    ...overrides,
  };
}

export function validL0(overrides = {}) {
  return baseRecord({
    id: 'L0-a7',
    layer: 'L0',
    anchor: { type: 'whole', value: null, space: 'image_px' },
    source: 'observed',
    author: 'user',
    confidence: null,
    ai_role: null,
    model_version: null,
    file_path: 'assets/a7/original.psd',
    sha256: SHA,
    format: 'psd',
    width: 2480,
    height: 3508,
    color_space: 'sRGB',
    imported_at: '2026-11-06T18:00:00+08:00',
    consent: { allow_training: false, allow_ai_processing: true, allow_display: false },
    ...overrides,
  });
}

export function validL1(overrides = {}) {
  return baseRecord({
    subject: ['少女', '街道'],
    scene: '雨夜城市街角',
    medium: { kind: 'digital_painting', detail: '数字厚涂' },
    palette: [{ hex: '#2e3a48', weight: 0.4 }, { hex: '#c9a66b', temperature: 'warm' }],
    ...overrides,
  });
}

export function validL2(overrides = {}) {
  return baseRecord({
    id: 'L2-a7-001',
    layer: 'L2',
    anchor: { type: 'bbox', value: [620, 880, 160, 80], space: 'image_px' },
    source: 'observed',
    label: '右手袖口',
    crop_path: 'assets/a7/crops/L2-a7-001.png',
    importance: 0.8,
    ...overrides,
  });
}

export function validL4(overrides = {}) {
  return baseRecord({
    id: 'L4-a7-014',
    layer: 'L4',
    anchor: { type: 'region', value: 'L2-a7-001', space: 'image_px' },
    text: '袖口边缘保留了一笔没收拾干净的笔触，与整体精细形成反差',
    kind: 'observation',
    evidence_refs: ['L2-a7-001'],
    ...overrides,
  });
}

export function validL5(overrides = {}) {
  return baseRecord({
    id: 'L5-a7-003',
    layer: 'L5',
    anchor: { type: 'region', value: 'L2-a7-001', space: 'image_px' },
    source: 'user-confirmed',
    author: 'user',
    confidence: null,
    kind: 'reject_ai',
    before_ref: 'L2-a7-001',
    after_ref: null,
    rationale: '这处粗糙是有意的，不要修',
    session_id: 's-20261106-01',
    generation_id: null,
    created_by: 'user',
    ...overrides,
  });
}

export function validL6Generation(overrides = {}) {
  return baseRecord({
    id: 'L6-a7-001',
    layer: 'L6',
    anchor: { type: 'bbox', value: [620, 880, 160, 80], space: 'image_px' },
    source: 'observed',
    confidence: null,
    kind: 'generation',
    model: { provider: 'aliyun-bailian', model: 'qwen-image-3.0', version: '2026-11', region: 'cn-mainland' },
    params: { prompt: '局部重绘：保留袖口粗糙笔触', size: [1024, 1024], seed: 123 },
    input_refs: ['L1-a7', 'L2-a7-001', 'L4-a7-014'],
    output_asset_id: 'a7-gen-01',
    output_layer_id: 'layer_9f8e7d',
    mask_ref: 'blobs/0f/0f1e2d3c.png',
    accepted: true,
    credits: 10,
    cost_cny: 0.61,
    latency_ms: 9400,
    assertions: [{ type: 'c2pa.created', value: { digitalSourceType: 'trainedAlgorithmicMedia' } }],
    ...overrides,
  });
}

export function validL6ModeChange(overrides = {}) {
  return baseRecord({
    id: 'L6-a7-002',
    layer: 'L6',
    anchor: { type: 'whole', value: null, space: 'image_px' },
    source: 'observed',
    confidence: null,
    kind: 'mode_change',
    model: { provider: 'none', model: 'n/a', version: null, region: 'local' },
    params: {},
    input_refs: [],
    assertions: [],
    from_mode: 'collab',
    to_mode: 'attest',
    from_role: 'assistant',
    to_role: 'tool',
    actor: 'user',
    ...overrides,
  });
}
