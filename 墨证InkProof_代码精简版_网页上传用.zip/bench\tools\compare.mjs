#!/usr/bin/env node
// bench/tools/compare.mjs
// 零依赖：读取两份 mozheng.bench.v1 结果 → 打印可复制的 markdown 对比表 + 硬门槛判定。
//
// 用法：
//   node bench/tools/compare.mjs bench/results/klecks.json bench/results/canvaskit.json
//   node bench/tools/compare.mjs a.json b.json --strict   # 任一路线硬门槛失败则 exit 1
//
// 约束：不联网、不写文件（只打印）；schema 见 bench/README.md §5。

import { readFileSync } from 'node:fs';
import process from 'node:process';

const args = process.argv.slice(2).filter((a) => !a.startsWith('--'));
const strict = process.argv.includes('--strict');
const WEIGHTS = { latency: 0.3, fps: 0.25, memory: 0.15, quality: 0.15, psd: 0.1, effort: 0.05 };

function die(msg) {
  console.error(`compare: ${msg}`);
  process.exit(2);
}

if (args.length < 2) die('需要两个结果 JSON 路径：<klecks.json> <canvaskit.json>');

function load(path) {
  try {
    const raw = readFileSync(path, 'utf8').replace(/^\uFEFF/, ''); // 兼容 Windows 工具写出的 UTF-8 BOM
    const json = JSON.parse(raw);
    if (json.schema !== 'mozheng.bench.v1') die(`${path}: schema 不是 mozheng.bench.v1（实际 ${json.schema}）`);
    if (!json.adapter || !json.adapter.id) die(`${path}: 缺少 adapter.id`);
    return json;
  } catch (e) {
    if (e.code === 'ENOENT') die(`找不到文件：${path}`);
    throw e;
  }
}

const A = load(args[0]);
const B = load(args[1]);

const rows = ['B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B9'];
const getCase = (r, id) => (r.cases || []).find((c) => c.id === id);

function fmt(v, suffix = '') {
  return typeof v === 'number' && Number.isFinite(v) ? `${v}${suffix}` : '-';
}

function lineFor(id) {
  const a = getCase(A, id);
  const b = getCase(B, id);
  const cell = (c, key) => (c && c.summary ? fmt(c.summary[key]) : '-');
  return `| ${id} | ${cell(a, 'latencyP50')} / ${cell(a, 'latencyP95')} | ${cell(b, 'latencyP50')} / ${cell(b, 'latencyP95')} | ` +
    `${cell(a, 'fpsP95')} | ${cell(b, 'fpsP95')} | ${cell(a, 'jsHeapMB')} | ${cell(b, 'jsHeapMB')} | ` +
    `${cell(a, 'undoP95')} | ${cell(b, 'undoP95')} |`;
}

function hardFailText(r) {
  const v = r.verdict || {};
  const fails = Array.isArray(v.hardFail) ? v.hardFail : [];
  return fails.length ? fails.join(', ') : '无';
}

function envNote(r) {
  const e = r.environment || {};
  const hw = e.hardware || {};
  const bits = [];
  if (e.gpuRenderer) bits.push(`GPU=${e.gpuRenderer}`);
  if (e.refreshHz) bits.push(`${e.refreshHz}Hz`);
  if (hw.pointerType) bits.push(`pointer=${hw.pointerType}${hw.pressureHardware ? '(压感硬件)' : '(压感模拟)'}`);
  else if (e.pointerType) bits.push(`pointer=${e.pointerType}`);
  return bits.join(' · ') || '-';
}

console.log(`# Canvas Engine Benchmark 对比（${new Date().toISOString().slice(0, 10)}）\n`);
console.log(`| | ${A.adapter.id}@${A.adapter.version || '?'} | ${B.adapter.id}@${B.adapter.version || '?'} |`);
console.log('|---|---|---|');
console.log(`| 许可 | ${A.adapter.license || '-'} | ${B.adapter.license || '-'} |`);
console.log(`| 环境 | ${envNote(A)} | ${envNote(B)} |`);
console.log(`| 硬门槛 | ${hardFailText(A)} | ${hardFailText(B)} |`);
console.log('');
console.log('## 分 case（延迟 P50/P95 ms；fps 为 P95；内存 MB；undo P95 ms）\n');
console.log(`| case | ${A.adapter.id} latency | ${B.adapter.id} latency | ${A.adapter.id} fps | ${B.adapter.id} fps | ${A.adapter.id} heap | ${B.adapter.id} heap | ${A.adapter.id} undo | ${B.adapter.id} undo |`);
console.log('|---|---|---|---|---|---|---|---|---|');
for (const id of rows) {
  const a = getCase(A, id);
  const b = getCase(B, id);
  if (!a && !b) continue;
  console.log(lineFor(id));
}
console.log('');
console.log('> 说明：延迟为「输入→帧提交」代理指标；鼠标环境压感为速度模拟，**不得**把延迟数字当最终结论。');
console.log('> 权重：' + Object.entries(WEIGHTS).map(([k, v]) => `${k} ${v}`).join('，') + '（quality/psd/effort 需人工补齐）。');

const fails = [
  ...((A.verdict && A.verdict.hardFail) || []).map((f) => `${A.adapter.id}: ${f}`),
  ...((B.verdict && B.verdict.hardFail) || []).map((f) => `${B.adapter.id}: ${f}`),
];
if (strict && fails.length) {
  console.error('\nstrict: 存在硬门槛失败：\n- ' + fails.join('\n- '));
  process.exit(1);
}
