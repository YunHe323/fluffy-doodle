#!/usr/bin/env node
// v2/qa/tools/verify-evidence-test.mjs —— 证据包复核器自测（零依赖）
// 构造合法/篡改证据包，验证 verifyEvidence 的判定；并输出结果 JSON。
import { promises as fsp } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { sha256Hex, canonicalJson, GENESIS_HASH } from '../../app/core/hash-chain.mjs';
import { verifyEvidence } from './verify-evidence.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const results = { schema: 'mozheng.qa.verify-evidence-test.v1', cases: {}, pass: false, errors: [] };

async function makePackage(tamper = null) {
  const records = [
    { id: 'L1-1', layer: 'L1', source: 'inferred', text: '冷灰蓝山谷', created_at: '2026-11-07T00:00:00.000Z' },
    { id: 'L6-1', layer: 'L6', kind: 'critique', model: { provider: 'moonshot', model: 'kimi-k3.1-pro', modelVersion: 'kimi-k3.1-pro' }, params: { task: 'analyze', status: 'ok', mock: false, latency_ms: 123, usage: { total_tokens: 200 } }, created_at: '2026-11-07T00:00:01.000Z' },
    { id: 'L4-1', layer: 'L4', source: 'inferred', text: '雾带分开远山与近水', created_at: '2026-11-07T00:00:02.000Z' },
  ];
  let prev = GENESIS_HASH;
  const events = [];
  for (const r of records) {
    const chain_hash = await sha256Hex(prev + canonicalJson(r));
    events.push({ ...r, chain_prev: prev, chain_hash });
    prev = chain_hash;
  }
  const canvas = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
  const pkg = {
    schema: 'inkproof.evidence.v1', generated_at: '2026-11-07T00:00:03.000Z',
    project: { canvas: { width: 1, height: 1, format: 'png', sha256: await sha256Hex(canvas) } },
    manifest: {
      event_count: events.length, head_hash: prev, genesis_hash: GENESIS_HASH,
      ai: { calls: 1, real_calls: 1, mock_calls: 0, providers: [{ provider: 'moonshot', model: 'kimi-k3.1-pro', calls: 1 }], total_tokens: 200, total_latency_ms: 123, network_requests: 1 },
      attest: { mode: 'collab', zero_generation: false },
      layers: [], refs_count: 0,
    },
    events, refs: [{ usage: 'ai_reference', asset_id: 'asset-1', sha256: 'a'.repeat(64) }], canvas_png_data_url: canvas,
  };
  if (tamper === 'event') pkg.events[2].text = '被篡改';
  if (tamper === 'head') pkg.manifest.head_hash = 'f'.repeat(64);
  if (tamper === 'canvas') pkg.canvas_png_data_url = canvas + 'x';
  if (tamper === 'aiCalls') pkg.manifest.ai.calls = 9;
  return pkg;
}

try {
  const good = await verifyEvidence(await makePackage());
  results.cases.valid = { ok: good.ok, checks: good.checks };
  for (const [name, tamper] of [['tamperEvent', 'event'], ['tamperHead', 'head'], ['tamperCanvas', 'canvas'], ['tamperAiCalls', 'aiCalls']]) {
    const r = await verifyEvidence(await makePackage(tamper));
    results.cases[name] = { ok: r.ok, expectedFail: !r.ok, errors: r.errors };
  }
  results.pass = results.cases.valid.ok === true
    && Object.entries(results.cases).filter(([k]) => k !== 'valid').every(([, v]) => v.ok === false && v.expectedFail === true);
  if (!results.pass) results.errors.push('存在未按预期判定的用例');
} catch (e) {
  results.errors.push(String(e && e.stack || e));
}
await fsp.writeFile(path.join(__dirname, 'verify-evidence-test-results.json'), JSON.stringify(results, null, 2), 'utf8');
console.log(JSON.stringify(results, null, 2));
process.exit(results.pass ? 0 : 1);
