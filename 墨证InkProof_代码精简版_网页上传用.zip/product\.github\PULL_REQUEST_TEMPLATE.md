# Pull Request

## Summary

<!-- What does this PR do, and why? -->

- 

## Linked issue

<!-- Fixes #123 / Relates to #123 -->

## Type of change

- [ ] Bug fix
- [ ] Feature (within v0.1 scope)
- [ ] Refactor / code quality (no behavior change)
- [ ] Documentation
- [ ] Tests
- [ ] Build / release tooling

## Scope check

- [ ] I opened/checked an issue first for non-trivial changes
- [ ] The change stays within v0.1 scope (or links a maintainer-approved decision)
- [ ] No new third-party runtime dependency
- [ ] No telemetry, analytics, or silent network requests added
- [ ] No API keys, secrets, personal artwork, or exported user data committed
- [ ] `CONTRACT.md` (app ↔ server) updated if API/data shapes changed — **current contract: v0.1.1**

## How this was tested

- [ ] `node --test` passes
- [ ] Manual check in Chrome/Edge (describe below)

<!-- Steps, browser/viewport, and expected results. -->

## UI changes

<!-- Screenshots or a short recording. If no UI change, write "none". -->

## Data / privacy impact

<!-- Does this touch IndexedDB, export/import, evidence chain, or provider config? Explain. -->

## Checklist

- [ ] I have read [CONTRIBUTING.md](../CONTRIBUTING.md) and follow the [Code of Conduct](../CODE_OF_CONDUCT.md)
- [ ] Documentation updated (README / docs) if behavior changed
- [ ] Comments explain non-obvious decisions
- [ ] I am licensing my contribution under the project license (see [LICENSE](../LICENSE))
- [ ] Third-party assets (if any) are permissively licensed and attributed
