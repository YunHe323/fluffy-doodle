# T109 最终独立 QA：画布尺寸/裁剪 + 历史清空 + 继续绘制 + mask 保留

> 执行：qa-engineer（独立 QA｜task-117）｜日期：2026-11-07 20:0x｜只写 `v2/qa/tools/`；**未改 app**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、单浏览器串行、小批次（每批 1–3 个，日志落盘 `archive/baseline-t109-final/logs/`）；执行时内存约 4.8–5.5GB。

## 结论

**可交付（Deliverable）——P0/P1/P2 = 0（另 1 条探针方法说明，非产品缺陷）。**
新测试 test-canvas-resize 全过；QA 独立完成 resize/crop 后保存-加载恢复、连续 resize、16×16 最小、4096 边界（含 4096×4096）、mask/组 mask 保留、L6 记录、密钥与 0 console error 核验；16 项回归全 PASS；真实证据无变化，**未新增付费调用**。

## 1. 新测试 `test-canvas-resize.mjs`（PASS）

| 阶段 | 数据 |
|---|---|
| 初始（画一笔） | 1200×800、layers=2、ink=5259、steps=1 |
| resize→800×600 | 800×600、canvas 元素同步、layers=2、ink=2745、**steps=0**、L6 `canvas_resized`=1 |
| resize 后继续画 | ink 2745→**4821**（+2076）、steps=1 ✅ BrushController 重建后正常 |
| 裁剪到选区（400×300） | 400×300、layers=2、ink=2076、**steps=0**、L6=2、裁后仍有墨 |
| modal | 「画布尺寸」1200/800；「裁剪画布」选中尺寸、锚点禁用 |
| console error | **0** |

## 2. 重点独立核验（QA 自建探针，12/12 PASS）

| # | 检查 | 结果 |
|---|---|---|
| 1 | resize 后保存 → `loadProjectText` 恢复 | 800×600、layers=3、**textLayers=1、meta.text="resize文字"** ✅ |
| 2 | 文字 meta 在 resize 后保留 | ✅（textLayers=1、meta 完整） |
| 3 | 图层 mask 保留 | ✅ exists+enabled、mask tiles 1→resize 后 12；resize 后**蒙版点采样白色（隐藏）、未蒙版内容点深色（可见）**，语义正确 |
| 4 | 组 mask 保留 | ✅ exists、group tiles 1→12；resize 后同样正确 |
| 5 | 保存 JSON 含 mask | ✅ `hasMaskJson=true`；load 后 layerMask/groupMask exists 均 true |
| 6 | 连续 resize 两次 | 1000×700 → 640×480，每次 **steps=0**、layers 保持、L6 逐次+1 ✅ |
| 7 | 最小 16×16 | 16×16、canvas 同步、layers=3、steps=0、无异常 ✅ |
| 8 | 最大 4096 | **4096×2048 成功**；**4096×4096 也成功**（执行期可用内存约 5GB，无 OOM）✅ |
| 9 | 裁剪 400×300 | 400×300、layers=3、steps=0、L6 记录 7（多次 resize/crop 累计）✅ |
| 10 | 裁剪后保存-加载 | 400×300、layers=3、textLayers=1 ✅ |
| 11 | 密钥 | config GET 仅 `hasKey/keyLast4`（configMasked=true），无泄漏 ✅ |
| 12 | console error | 全程 **0** ✅ |

> **探针方法说明（非产品缺陷）**：本轮通过 `engine.addMask/beginStroke(maskPaint)` 原语直连创建 mask 后，在 resize 前的单帧采样未立即体现隐藏（探针未走 app UI 的 present/commit 时序）；**resize 重建后语义正确**（masked=白、unmasked=深色），且 mask 结构/像素数据完整保留。若后续需 UI 级即时性断言，建议 owner 在真实 UI 路径补一条。

## 3. 回归（16 项全 PASS，0 console error）

test-app、test-ui、test-editor-basics、test-text-edit、test-symmetry、test-shape-snap、test-guides、test-mask-compare、test-editor-ui、test-ux-p0、test-ai-provider、**test-interaction-sequences（9/9，单跑）**、test-asset-batch、test-image-workshop、**test-chat（单跑）** —— 逐项小批次复跑，exit 0、errors 0；chat/interaction 单跑无浏览器关闭 flaky。

## 4. 真实证据核对（未新增付费调用）

| 证据 | 核对 |
|---|---|
| `asset-real-read-results.json`（17:12，mtime 未变） | pass=true；**22,955ms**；real / latency 22,225ms / **L2=5、L4=4** ✅ |
| `qwen-real-e2e-results.json`（16:53，mtime 未变） | pass=true；**21,337ms**；obs=2、regions=2、mock=false ✅ |
| 新增付费调用 | **0**（仅核对已有证据） |

## 5. 密钥 / 残留 / 稳定性

- 密钥：无 DOM/localStorage/已加载 JS 泄漏；config 脱敏；未打印 key。
- 残留：**Edge 0、测试端口 0**（4096 压力测试后仍为 0）。
- 稳定性：单浏览器串行、小批次；4096×4096 重负载下未 OOM、无 console error。

## 6. 问题清单

| # | 级别 | 问题 | 状态 |
|---|---|---|---|
| — | — | P0 / P1 / P2 | **均无** |
| 说明 | — | mask 探针直连 API 下 resize 前单帧采样未体现（UI 路径可能不同；resize 后语义正确） | 非产品缺陷，供 owner 参考 |

## 7. 产物与归档

- `v2/qa/tools/T109-final-qa.md`（本报告）
- `v2/qa/tools/archive/baseline-t109-final/`：`logs/`（全部原始输出）、各 result JSON、`focus-results.json`（12 项独立核验数据）、真实证据、README
- GATE：`v2/qa/tools/GATE-pw.md`「T109-F 最终独立 QA」行
