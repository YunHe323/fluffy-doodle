/**
 * v2/brushes/tools/real-browser-smoke.mjs
 * 真实浏览器笔刷冒烟（默认 headless=new + 真实 GPU，不弹窗）：
 *   - 打开 http 页面（默认 v2/brushes/demo.html）
 *   - 读取页面状态 / CanvasKit 初始化 / 元素命中测试
 *   - 用 CDP Input.dispatchMouseEvent 真实派发 pointer 事件：逐笔刷画线
 *   - 读回合成图统计墨迹像素、undoDepth/tileCount 变化
 *   - mouse 与 pen（force 压感）两种输入都测；截图 + JSON 报告
 *   - file:// 页面：采集「引擎未就绪 + 红色横幅」证据（预期不可绘）
 *
 * 团队规范：自动化一律 headless。只有显式 `--headed` 才开窗口，且窗口自动移到屏幕外
 * （--window-position=-3000,-3000 + --start-minimized），跑完 taskkill /T 杀进程树。
 *
 * 用法（项目根目录）：
 *   node v2/brushes/tools/real-browser-smoke.mjs [url] [cdpPort] [--headed]
 * 默认 url = http://127.0.0.1:4200/v2/brushes/demo.html
 * 依赖：本机 Edge 或 Chrome；零 npm 依赖（Node 内置 fetch/WebSocket）。
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
/** 本地服务端口：优先 INKPROOF_BASE，其次 v2/.runtime-port（serve.mjs 自动选端口），最后 4200 */
function resolveBase() {
  if (process.env.INKPROOF_BASE) return process.env.INKPROOF_BASE;
  try {
    const port = fs.readFileSync(path.join(ROOT, 'v2', '.runtime-port'), 'utf8').trim();
    if (/^\d+$/.test(port)) return 'http://127.0.0.1:' + port;
  } catch (e) { /* ignore */ }
  return 'http://127.0.0.1:4200';
}
const BASE = resolveBase();
const args = process.argv.slice(2).filter((a) => !a.startsWith('--'));
const flags = new Set(process.argv.slice(2).filter((a) => a.startsWith('--')));
const URL_ARG = args[0] || `${BASE}/v2/brushes/demo.html`;
const CDP_PORT = Number(args[1] || 9500);
/** 团队规范：默认 headless；--headed 才开窗（移出屏幕 + 最小化） */
const HEADLESS = !flags.has('--headed');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function findBrowser() {
  return [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  ].find((p) => fs.existsSync(p));
}

const EXE = findBrowser();
if (!EXE) { console.log(JSON.stringify({ ok: false, error: 'no Edge/Chrome found' })); process.exit(1); }

const profile = path.join(os.tmpdir(), 'brushsmoke-' + Date.now());
const outDir = path.join(ROOT, 'v2', 'brushes', 'samples');
fs.mkdirSync(outDir, { recursive: true });
const URL_SLUG = /\/v2\/([^/]+)\//.exec(URL_ARG)?.[1] || 'page';
const PROTO_SLUG = URL_ARG.startsWith('file:') ? 'file' : 'http';
const browserArgs = [
  '--remote-debugging-port=' + CDP_PORT,
  '--user-data-dir=' + profile,
  '--no-first-run', '--no-default-browser-check',
  '--disable-features=Translate',
];
if (HEADLESS) {
  browserArgs.push('--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1680,1050');
} else {
  // 非 headless 兜底：窗口移出屏幕 + 最小化，避免打扰用户
  browserArgs.push('--window-size=1680,1050', '--window-position=-3000,-3000', '--start-minimized');
}
browserArgs.push(URL_ARG);

const browser = spawn(EXE, browserArgs, { stdio: 'ignore' });
const report = {
  schema: 'inkproof.brush-smoke.v1',
  createdAt: new Date().toISOString(),
  browser: path.basename(EXE), headless: HEADLESS, url: URL_ARG,
  environment: { ua: null, gpu: null, platform: process.platform, dpr: null, innerSize: null },
  page: {}, canvas: {}, consoleErrors: [], runtimeExceptions: [],
  mouse: {}, pen: null, brushes: [], screenshot: null, ok: false,
};

let ws = null;
let msgId = 0;
const pending = new Map();
function send(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++msgId;
    pending.set(id, { resolve, reject });
    try { ws.send(JSON.stringify({ id, method, params })); } catch (e) { reject(e); }
  });
}
async function ev(expression, timeoutMs = 30000) {
  const r = await Promise.race([
    send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true }),
    sleep(timeoutMs).then(() => ({ __timeout: true })),
  ]);
  if (r.__timeout) throw new Error('evaluate timeout: ' + expression.slice(0, 120));
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1500));
  return r.result?.result?.value;
}
async function waitFor(expr, timeoutMs = 120000, tick = 200) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    const v = await ev(expr).catch(() => false);
    if (v) return true;
    await sleep(tick);
  }
  return false;
}
async function connect() {
  let target = null;
  for (let i = 0; i < 400 && !target; i += 1) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json();
      target = list.find((t) => t.type === 'page' && (/^https?:/.test(t.url) || (/^file:/.test(URL_ARG) && /^file:/.test(t.url))));
    } catch (e) { /* not up yet */ }
    if (!target) await sleep(150);
  }
  if (!target) throw new Error('CDP target not found on port ' + CDP_PORT);
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = reject; });
  ws.onmessage = (evt) => {
    let m;
    try { m = JSON.parse(evt.data); } catch (e) { return; }
    if (m.id && pending.has(m.id)) { pending.get(m.id).resolve(m); pending.delete(m.id); return; }
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') {
      if (report.consoleErrors.length < 30) report.consoleErrors.push(m.params.args.map((a) => a.value || a.description || '').join(' '));
    }
    if (m.method === 'Runtime.exceptionThrown') {
      if (report.runtimeExceptions.length < 30) {
        report.runtimeExceptions.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text);
      }
    }
  };
  await send('Runtime.enable');
  await send('Page.enable');
  await send('Log.enable').catch(() => { });
  return target;
}

const CANVAS_ID = 'stage';
const READY_EXPR = `!!window.__BRUSH_READY__ || !!window.__V2_APP_READY__ || !!window.__V2_READY__`;

/** 页面内安装：pointer 事件计数 + 合成图墨迹统计 + 截图墨迹统计（裁画布区域） */
const INSTRUMENT = `(() => {
  if (window.__SMOKE__) return window.__SMOKE__.ready;
  const smoke = { pointerdowns: 0, moves: 0, ups: 0, pressures: [], pointerTypes: [], last: null, ready: true };
  window.__SMOKE__ = smoke;
  for (const type of ['pointerdown', 'pointermove', 'pointerup']) {
    window.addEventListener(type, (e) => {
      if (type === 'pointerdown') { smoke.pointerdowns += 1; smoke.pressures.push(e.pressure); smoke.pointerTypes.push(e.pointerType || '?'); }
      if (type === 'pointermove') smoke.moves += 1;
      if (type === 'pointerup') smoke.ups += 1;
      smoke.last = { type, x: e.clientX, y: e.clientY, pressure: e.pressure, pointerType: e.pointerType };
    }, true);
  }
  window.__smokeInk__ = async () => {
    const demo = window.__BRUSH_DEMO__ || window.__V2_APP__;
    const e = window.__V2__ || (demo && demo.engine);
    if (!e) return { error: 'no engine' };
    e.compositor.compositeAll(e.store);
    const url = await e.getCompositeDataUrl();
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    let ink = 0, colored = 0;
    for (let i = 0; i < d.length; i += 4) {
      const r = d[i], g = d[i + 1], b = d[i + 2];
      if (r < 235 || g < 235 || b < 235) ink += 1;
      if (Math.abs(r - g) > 12 || Math.abs(g - b) > 12) colored += 1;
    }
    const stats = e.getStats();
    return { ink, colored, w: c.width, h: c.height, undoDepth: stats.undoDepth, tileCount: stats.tileCount, provider: stats.brushProvider };
  };
  window.__smokeShotInk__ = async (b64) => {
    if (!b64) return { error: 'empty screenshot' };
    const img = new Image(); img.src = 'data:image/png;base64,' + b64; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
    const stage = document.getElementById('stage') || document.querySelector('canvas');
    if (!stage) return { error: 'no canvas' };
    const r = stage.getBoundingClientRect();
    const s = img.width / window.innerWidth;
    const x = Math.max(0, Math.round(r.x * s)), y = Math.max(0, Math.round(r.y * s));
    const w = Math.max(1, Math.min(img.width - x, Math.round(r.width * s)));
    const h = Math.max(1, Math.min(img.height - y, Math.round(r.height * s)));
    const d = ctx.getImageData(x, y, w, h).data;
    let dark = 0;
    for (let i = 0; i < d.length; i += 4) if (d[i] < 235 || d[i + 1] < 235 || d[i + 2] < 235) dark += 1;
    return { dark, box: { x, y, w, h }, scale: s };
  };
  return true;
})()`;

async function dispatchDraw(x0, y0, x1, y1, opts = {}) {
  const steps = opts.steps || 18;
  const pointerType = opts.pointerType || 'mouse';
  const forces = opts.forces || null;
  const sleepMs = opts.sleepMs == null ? 10 : opts.sleepMs;
  await send('Input.dispatchMouseEvent', {
    type: 'mousePressed', x: x0, y: y0, button: 'left', buttons: 1, clickCount: 1,
    pointerType, force: forces ? forces[0] : (pointerType === 'pen' ? 0.7 : undefined),
  });
  for (let i = 1; i <= steps; i += 1) {
    const t = i / steps;
    await send('Input.dispatchMouseEvent', {
      type: 'mouseMoved', x: x0 + (x1 - x0) * t, y: y0 + (y1 - y0) * t,
      button: 'left', buttons: 1, pointerType,
      force: forces ? forces[0] + (forces[1] - forces[0]) * t : (pointerType === 'pen' ? 0.2 + 0.7 * t : undefined),
    });
    if (sleepMs) await sleep(sleepMs);
  }
  await send('Input.dispatchMouseEvent', {
    type: 'mouseReleased', x: x1, y: y1, button: 'left', buttons: 0, clickCount: 1,
    pointerType, force: forces ? forces[1] : undefined,
  });
}

async function canvasRect() {
  return ev(`(() => {
    const c = document.getElementById('${CANVAS_ID}') || document.querySelector('canvas');
    if (!c) return null;
    const r = c.getBoundingClientRect();
    const el = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2);
    return { id: c.id, x: r.x, y: r.y, w: r.width, h: r.height, wx: c.width, wy: c.height,
      hit: el ? (el.id || el.tagName + '.' + el.className) : null };
  })()`);
}

const OUT_TAG = HEADLESS ? 'headless' : 'headed-offscreen';
function writeReport() {
  console.log(JSON.stringify(report, null, 2));
  try {
    const jsonOut = path.join(outDir, `smoke-${URL_SLUG}-${PROTO_SLUG}-${OUT_TAG}.json`);
    fs.writeFileSync(jsonOut, JSON.stringify(report, null, 2));
    console.log('\nreport written:', path.relative(ROOT, jsonOut).replace(/\\/g, '/'));
  } catch (e) { console.log('report write failed:', String(e && e.message || e)); }
}

try {
  await connect();
  const t0 = Date.now();
  const readyTimeout = URL_ARG.startsWith('file:') ? 12000 : 90000;
  const ready = await waitFor(READY_EXPR, readyTimeout);
  report.page.ready = ready;
  report.page.readyMs = Date.now() - t0;
  report.page.title = await ev('document.title');
  report.environment.ua = await ev('navigator.userAgent');
  report.environment.dpr = await ev('window.devicePixelRatio');
  report.environment.innerSize = await ev('[window.innerWidth, window.innerHeight]');
  report.page.brushes = await ev(`(() => (window.__BRUSH_DEMO__ ? window.__BRUSH_DEMO__.presets.brushes.map(b => ({id:b.id,name:b.name,eraser:!!b.engine.eraser})) : (window.__V2_APP__ ? 'app' : null)))()`);
  report.page.brushButtons = await ev(`document.querySelectorAll('.brushBtn').length`);
  report.page.status = await ev(`document.getElementById('status') ? document.getElementById('status').textContent : null`);
  report.page.statusIsError = await ev(`(() => { const s = document.getElementById('status'); return s ? /失败|error/i.test(s.textContent) : null; })()`);
  report.page.readyFlag = await ev(`!!window.__BRUSH_READY__`);
  report.page.protocol = await ev('location.protocol');
  report.page.href = await ev('location.href');
  report.page.errText = await ev(`document.getElementById('err') ? document.getElementById('err').textContent : null`);
  report.page.engineStats = await ev(`(() => { try { const e = window.__V2__; return e ? e.getStats() : null; } catch (e) { return { error: String(e) }; } })()`);
  report.environment.gpu = report.page.engineStats && report.page.engineStats.gpuRenderer;

  await ev(INSTRUMENT);
  report.canvas = await canvasRect();
  if (!report.canvas) throw new Error('canvas element not found');

  const drawable = !!(report.page.ready && report.canvas.hit === CANVAS_ID && report.canvas.w > 0);
  report.page.drawable = drawable;

  // ---------- file:// / 未就绪：采集证据（预期不可绘） ----------
  if (!report.page.ready) {
    report.page.statusAfter = await ev(`(() => { const s = document.getElementById('status'); return s ? s.textContent : null; })()`);
    report.page.fileOverlay = await ev(`(() => { const el = document.getElementById('fileProtocolOverlay'); return el ? getComputedStyle(el).display : null; })()`);
    report.page.fatalBar = await ev(`(() => { const el = document.getElementById('fatalBar'); return el ? getComputedStyle(el).display : null; })()`);
    report.page.fileErrors = await ev(`(window.__BRUSH_ERRORS__ || []).slice(0, 6)`).catch(() => null);
    report.page.fatalLog = await ev(`(window.__FATAL_LOG__ || []).slice(0, 6)`).catch(() => null);
    const isFile = report.page.protocol === 'file:' || URL_ARG.startsWith('file:');
    report.expectation = isFile
      ? 'file:// 下按设计不可绘（浏览器拦截 ESM/CanvasKit WASM）；本次验证红色横幅/错误条是否向用户说明原因'
      : 'http 页面未就绪，需要排查初始化失败原因';
    report.ok = isFile && report.page.fileOverlay === 'flex';
    report.summary = {
      ready: false, drawable: false,
      fileBlockedBanner: report.page.fileOverlay,
      fatalBar: report.page.fatalBar,
      consoleErrors: report.consoleErrors.length,
      runtimeExceptions: report.runtimeExceptions.length,
      note: 'probe only (engine not ready)，未执行绘制用例',
    };
    try {
      const shot = await send('Page.captureScreenshot', { format: 'png' });
      const out = path.join(outDir, `smoke-${URL_SLUG}-fileprotocol.png`);
      fs.writeFileSync(out, Buffer.from(shot.result.data, 'base64'));
      report.screenshot = path.relative(ROOT, out).replace(/\\/g, '/');
    } catch (e) { /* ignore */ }
    throw new Error('SKIP_DRAW');
  }
  if (!drawable) throw new Error('page not drawable: ' + JSON.stringify({ ready: report.page.ready, hit: report.canvas.hit }));

  // 清空画布（undo 到底）
  await ev(`(async () => { const e = window.__V2__; let g = 0; while (e.canUndo() && g < 400) { e.undo(); g += 1; } e.compositor.compositeAll(e.store); return g; })()`);
  await sleep(200);
  const ink0 = await ev(`window.__smokeInk__()`);
  const rect = report.canvas;

  // ---- 1) 鼠标绘制基础验收 ----
  const before = await ev(`(() => { const s = window.__SMOKE__; return { down: s.pointerdowns, moves: s.moves, ups: s.ups }; })()`);
  const my0 = rect.y + rect.h * 0.2;
  await dispatchDraw(rect.x + rect.w * 0.12, my0, rect.x + rect.w * 0.88, my0 + rect.h * 0.04, { steps: 24, sleepMs: 8 });
  await sleep(250);
  const after = await ev(`(() => { const s = window.__SMOKE__; return { down: s.pointerdowns, moves: s.moves, ups: s.ups, last: s.last }; })()`);
  const ink1 = await ev(`window.__smokeInk__()`);
  report.mouse = {
    events: { before, after },
    inkBefore: ink0, inkAfter: ink1,
    inkDelta: ink1.ink - ink0.ink,
    undoDepth: ink1.undoDepth,
    tileCount: ink1.tileCount,
  };

  // ---- 2) 逐笔刷可绘：切 10 个笔刷各画一条 ----
  const nBrushes = await ev(`document.querySelectorAll('.brushBtn').length`);
  for (let i = 0; i < nBrushes && i < 10; i += 1) {
    const name = await ev(`(() => { const b = document.querySelectorAll('.brushBtn')[${i}]; return b ? b.textContent.trim() : null; })()`);
    await ev(`document.querySelectorAll('.brushBtn')[${i}].click()`);
    await sleep(120);
    const beforeI = await ev(`window.__smokeInk__()`);
    const y = rect.y + rect.h * (0.16 + 0.075 * i);
    // 用接近真实鼠标的速度（~2.5px/ms）画短笔，避免 CDP 瞬移把 T54 模拟压感压到最小值
    await dispatchDraw(rect.x + rect.w * 0.12, y, rect.x + rect.w * 0.40, y + rect.h * 0.012, { steps: 14, sleepMs: 12 });
    await sleep(160);
    const afterI = await ev(`window.__smokeInk__()`);
    const provider = await ev(`(() => { try { return window.__V2__.getBrushProvider().id; } catch (e) { return 'ERR:' + e.message; } })()`);
    const isEraser = await ev(`(() => { const d = window.__BRUSH_DEMO__; const p = d && d.presets.brushes[${i}]; return !!(p && p.engine && p.engine.eraser); })()`);
    const delta = afterI.ink - beforeI.ink;
    report.brushes.push({
      index: i, name, provider, eraser: !!isEraser,
      inkDelta: delta,
      undoBefore: beforeI.undoDepth, undoAfter: afterI.undoDepth,
      tileCountBefore: beforeI.tileCount, tileCountAfter: afterI.tileCount,
      // 橡皮在空白处擦可能没有墨量变化（视觉/像素验收由 live-render-test 专项覆盖），这里要求笔画事务成立
      ok: (isEraser || delta > 100) && afterI.undoDepth === beforeI.undoDepth + 1,
    });
  }

  // ---- 3) pen 压感透传（CDP pointerType=pen + force） ----
  try {
    await ev(`document.querySelectorAll('.brushBtn')[0].click()`);
    await sleep(120);
    const p0 = await ev(`(() => { const s = window.__SMOKE__; return { down: s.pointerdowns }; })()`);
    const y = rect.y + rect.h * 0.86;
    await dispatchDraw(rect.x + rect.w * 0.12, y, rect.x + rect.w * 0.5, y, {
      steps: 12, sleepMs: 8, pointerType: 'pen', forces: [0.15, 0.95],
    });
    await sleep(200);
    report.pen = await ev(`(() => {
      const s = window.__SMOKE__;
      const c = window.__BRUSH_DEMO__.controller;
      return { downDelta: s.pointerdowns - ${p0.down}, pressures: s.pressures.slice(-14), pointerTypes: s.pointerTypes.slice(-14),
        lastRawPressure: c && c.lastRaw ? c.lastRaw.pressure : null, pointCount: c ? c.pointCount : null };
    })()`);
  } catch (e) {
    report.pen = { error: String(e && e.message || e) };
  }

  // ---- 4) 实时反馈（未松手时画面是否已有墨迹）：截图 + 页面内裁画布区统计 ----
  try {
    const y = rect.y + rect.h * 0.93;
    const shotBeforeLive = await send('Page.captureScreenshot', { format: 'png' });
    const b64Before = shotBeforeLive.result?.data || '';
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: rect.x + rect.w * 0.12, y, button: 'left', buttons: 1, clickCount: 1 });
    for (let i = 1; i <= 10; i += 1) {
      await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: rect.x + rect.w * (0.12 + 0.3 * i / 10), y, button: 'left', buttons: 1 });
      await sleep(8);
    }
    await sleep(120);
    const shotLive = await send('Page.captureScreenshot', { format: 'png' });
    const b64Live = shotLive.result?.data || '';
    const shotInkBefore = await ev(`window.__smokeShotInk__(${JSON.stringify(b64Before)})`).catch((e) => ({ error: String(e) }));
    const shotInkLive = await ev(`window.__smokeShotInk__(${JSON.stringify(b64Live)})`).catch((e) => ({ error: String(e) }));
    report.live = {
      beforeBytes: b64Before.length,
      liveBytes: b64Live.length,
      differs: b64Before !== b64Live,
      shotInkBefore: shotInkBefore && shotInkBefore.dark,
      shotInkLive: shotInkLive && shotInkLive.dark,
      liveVisible: !!shotInkLive && shotInkLive.dark > (shotInkBefore ? shotInkBefore.dark : 0) + 200,
      note: 'headless 下 Page.captureScreenshot 对 WebGL 画布可能不保留 backbuffer；live 可见性以 data 墨迹 + 截图双口径记录',
    };
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: rect.x + rect.w * 0.42, y, button: 'left', buttons: 0, clickCount: 1 });
    await sleep(200);
  } catch (e) { report.live = { error: String(e && e.message || e) }; }

  // ---- 5) 截图留证 ----
  try {
    const shot = await send('Page.captureScreenshot', { format: 'png' });
    const out = path.join(outDir, `smoke-${URL_SLUG}-${PROTO_SLUG}-${OUT_TAG}.png`);
    fs.writeFileSync(out, Buffer.from(shot.result.data, 'base64'));
    report.screenshot = path.relative(ROOT, out).replace(/\\/g, '/');
  } catch (e) { report.screenshot = { error: String(e && e.message || e) }; }

  // ---- 6) 汇总 ----
  const brushOk = report.brushes.filter((b) => b.ok).length;
  report.summary = {
    ready: report.page.ready,
    drawable: report.page.drawable,
    headless: HEADLESS,
    mouseInkDelta: report.mouse.inkDelta,
    mouseUndoDepth: report.mouse.undoDepth,
    brushesDrawn: report.brushes.length ? (brushOk + '/' + report.brushes.length) : 'n/a (non-brush page)',
    liveScreenshotInk: report.live ? report.live.liveVisible : null,
    consoleErrors: report.consoleErrors.length,
    runtimeExceptions: report.runtimeExceptions.length,
    screenshot: report.screenshot,
  };
  report.ok = report.page.ready && report.mouse.inkDelta > 500 && brushOk === report.brushes.length && report.consoleErrors.length === 0;
  writeReport();
} catch (e) {
  if (String(e && e.message) === 'SKIP_DRAW') {
    report.skippedDraw = true;
    writeReport();
  } else {
    report.fatal = String(e && e.stack || e);
    writeReport();
  }
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  try { browser.kill(); } catch (e) { /* ignore */ }
  await sleep(500);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  process.exit(report.ok ? 0 : 1);
}
