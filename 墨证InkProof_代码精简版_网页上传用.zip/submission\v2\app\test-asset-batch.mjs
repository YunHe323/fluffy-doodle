// v2/app/test-asset-batch.mjs —— 素材批量理解队列（Mock 离线路径）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8163;
const out = { schema: 'mozheng.app.asset-batch.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-asset-batch-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('mozheng.ai.settings.v1', JSON.stringify({ preset: 'qwen', allowReal: false, requireConfirm: true, privacyMode: true })); } catch (e) {} });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1500);
  await page.evaluate(async () => { await window.__V2_APP__.t71.ensureSampleLibrary(); });
  await page.click('#btnLibrary');
  await page.waitForFunction(() => document.querySelectorAll('#libGrid .lib-card').length > 0, null, { timeout: 20000 });
  await page.waitForTimeout(500);
  out.cases.before = await page.evaluate(() => ({ assets: (window.__V2_APP__.state.library.assets || []).length, real: (window.__V2_APP__.state.library.assets || []).filter((a) => a.analysisSource === 'real').length }));
  await page.click('#libBatchRead');
  await page.waitForFunction(() => { const m = document.getElementById('batchReviewModal'); return m && m.classList.contains('show'); }, null, { timeout: 15000 });
  out.cases.preflight = await page.evaluate(() => ({ items: document.querySelectorAll('.batch-review-item').length, summary: (document.getElementById('batchReviewSummary') || {}).textContent || '', start: !!(document.getElementById('batchReviewStart') && !document.getElementById('batchReviewStart').hidden) }));
  await page.click('#batchReviewStart');
  await page.waitForFunction(() => (window.__V2_APP__.state.records || []).some((r) => r.params && r.params.task === 'asset_batch_decompose'), null, { timeout: 30000 });
  await page.waitForFunction(() => { const b = document.getElementById('batchReviewAdoptAll'); return b && !b.hidden; }, null, { timeout: 15000 });
  out.cases.beforeKeep = await page.evaluate(() => { const it = window.__V2_APP__.state.batchReview.items[0]; return { before: it.before ? { L1: it.before.L1 && it.before.L1.summary, tags: (it.before.tags || []).slice(0, 6), source: it.before.analysisSource || 'mock' } : null }; });
  const keepBtn = page.locator('[data-batch-act="keep"][data-batch-i="0"]').first();
  await keepBtn.click();
  await page.waitForTimeout(500);
  out.cases.keep = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const it = a.state.batchReview.items[0];
    const cur = (a.state.library.assets || []).find((x) => x.id === it.id) || {};
    return { status: it.status, L1: cur.L1 && cur.L1.summary, tags: (cur.tags || []).slice(0, 6), source: cur.analysisSource || 'mock' };
  });
  await page.click('#batchReviewAdoptAll');
  await page.waitForTimeout(300);
  out.cases.after = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const rec = a.state.records.filter((r) => r.params && r.params.task === 'asset_batch_decompose').slice(-1)[0];
    return { record: rec ? { mode: rec.params.mode, total: rec.params.total, done: rec.params.done, failed: rec.params.failed, skill: rec.params.skill } : null, assets: (a.state.library.assets || []).length, review: (a.state.batchReview && a.state.batchReview.items || []).map((x) => x.status), reviewVisible: document.getElementById('batchReviewModal').classList.contains('show') };
  });
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-asset-batch-1920.png' });
  out.cases.preflightOk = out.cases.preflight.items >= 1 && out.cases.preflight.start;
  out.cases.reviewOk = out.cases.after.review.length >= 1 && out.cases.after.review[0] === 'kept' && out.cases.after.review.slice(1).every((s) => s === 'adopted');
  out.cases.keepOk = out.cases.keep.status === 'kept' && !!out.cases.beforeKeep.before && out.cases.keep.L1 === out.cases.beforeKeep.before.L1 && JSON.stringify(out.cases.keep.tags) === JSON.stringify(out.cases.beforeKeep.before.tags) && out.cases.keep.source === out.cases.beforeKeep.before.source;
  out.cases.ok = !!out.cases.after.record && out.cases.after.record.mode === 'mock' && out.cases.after.record.total >= 1 && out.cases.after.record.done >= 1 && out.cases.after.record.failed === 0 && out.cases.after.record.skill === 'asset.decompose';
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.preflightOk && out.cases.reviewOk && out.cases.keepOk && out.cases.ok && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
