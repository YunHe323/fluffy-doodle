/**
 * v2 engine · V2Doc 统一文档/图层模型（T60）
 *
 * 被 Engine、LayerSystem（v2/layers）与 PSD 桥（v2/psd）共用：
 *   Doc  { schema:'mozheng.doc.v1', version:1, width, height,
 *          activeLayerId, groups:[Group], layers:[Layer] }   // layers 顺序 = 合成顺序（下→上）
 *   Group{ id, name, visible, opacity, collapsed }
 *   Layer{ id, name, kind:'raster', visible, opacity, blend, locked, clip,
 *          group:null|groupId, mask:{ exists:boolean, enabled:boolean } }
 *
 * 约定：
 *  - 组只支持 1 级嵌套（T60 范围）；layer.group=null 表示顶层。
 *  - blend 为 Procreate 风格 16 内部名（normal/dissolve/darken/.../luminosity）。
 *  - 本模块不依赖 CanvasKit（纯 JSON 模型），序列化与像素由 engine/tile-store 负责。
 */
export const DOC_SCHEMA = 'mozheng.doc.v1';
export const DOC_VERSION = 1;

export const BLEND_MODES = [
  'normal', 'dissolve',
  'darken', 'multiply', 'color-burn',
  'lighten', 'screen', 'color-dodge',
  'overlay', 'soft-light', 'hard-light',
  'difference', 'exclusion',
  'hue', 'saturation', 'color', 'luminosity',
];

const BLEND_SET = new Set(BLEND_MODES);

export function blendLabel(name) {
  return BLEND_SET.has(name) ? name : 'normal';
}

export function createGroup(overrides = {}) {
  return {
    id: overrides.id || `group-${Math.random().toString(36).slice(2, 9)}`,
    name: overrides.name || '组',
    visible: overrides.visible !== false,
    opacity: clamp01(overrides.opacity),
    collapsed: !!overrides.collapsed,
    clip: !!overrides.clip,
    mask: {
      exists: !!(overrides.mask && overrides.mask.exists),
      enabled: overrides.mask && overrides.mask.enabled === false ? false : true,
    },
  };
}

const LAYER_KINDS = new Set(['raster', 'adjust', 'text']);
export function createLayer(overrides = {}) {
  return {
    id: overrides.id || `layer-${Math.random().toString(36).slice(2, 9)}`,
    name: overrides.name || '图层',
    kind: LAYER_KINDS.has(overrides.kind) ? overrides.kind : 'raster',
    adjust: overrides.adjust && typeof overrides.adjust === 'object' ? JSON.parse(JSON.stringify(overrides.adjust)) : null,
    text: overrides.text && typeof overrides.text === 'object' ? JSON.parse(JSON.stringify(overrides.text)) : null,
    visible: overrides.visible !== false,
    opacity: clamp01(overrides.opacity),
    blend: blendLabel(overrides.blend),
    locked: !!overrides.locked,
    alphaLock: !!overrides.alphaLock,
    clip: !!overrides.clip,
    group: overrides.group || null,
    meta: overrides.meta && typeof overrides.meta === 'object' ? JSON.parse(JSON.stringify(overrides.meta)) : null,
    mask: {
      exists: !!(overrides.mask && overrides.mask.exists),
      enabled: overrides.mask && overrides.mask.enabled === false ? false : true,
    },
  };
}

function clamp01(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 1;
  return Math.max(0, Math.min(1, n));
}

/** 规范化/校验 doc：补齐字段、去重 id、清理悬空 group、保证 activeLayerId 有效 */
export function normalizeDoc(input) {
  const src = input || {};
  const width = Math.max(1, Math.floor(Number(src.width) || 1));
  const height = Math.max(1, Math.floor(Number(src.height) || 1));
  const groups = [];
  const groupIds = new Set();
  for (const g of Array.isArray(src.groups) ? src.groups : []) {
    if (!g || typeof g.id !== 'string' || groupIds.has(g.id)) continue;
    groupIds.add(g.id);
    groups.push(createGroup({ ...g, id: g.id }));
  }
  const layers = [];
  const layerIds = new Set();
  for (const l of Array.isArray(src.layers) ? src.layers : []) {
    if (!l || typeof l.id !== 'string' || layerIds.has(l.id)) continue;
    layerIds.add(l.id);
    const meta = createLayer({ ...l, id: l.id });
    meta.group = meta.group && groupIds.has(meta.group) ? meta.group : null;
    layers.push(meta);
  }
  const activeLayerId = layers.some((l) => l.id === src.activeLayerId)
    ? src.activeLayerId
    : (layers.length ? layers[layers.length - 1].id : null);
  return { schema: DOC_SCHEMA, version: DOC_VERSION, width, height, activeLayerId, groups, layers };
}

export function createDoc(opts = {}) {
  return normalizeDoc({
    width: opts.width || 1,
    height: opts.height || 1,
    groups: opts.groups || [],
    layers: opts.layers || [],
    activeLayerId: opts.activeLayerId,
  });
}

export function validateDoc(doc) {
  const errors = [];
  if (!doc || typeof doc !== 'object') return { ok: false, errors: ['doc 不是对象'] };
  if (doc.schema !== DOC_SCHEMA) errors.push(`schema 应为 ${DOC_SCHEMA}`);
  if (!(doc.width > 0) || !(doc.height > 0)) errors.push('width/height 非法');
  const ids = new Set();
  for (const g of doc.groups || []) {
    if (!g.id || ids.has(g.id)) errors.push(`组 id 重复/缺失: ${g.id}`);
    ids.add(g.id);
  }
  for (const l of doc.layers || []) {
    if (!l.id || ids.has(l.id)) errors.push(`图层 id 重复/缺失: ${l.id}`);
    ids.add(l.id);
    if (l.blend && !BLEND_SET.has(l.blend)) errors.push(`未知混合模式: ${l.blend}`);
    if (l.group && !ids.has(l.group) && !(doc.groups || []).some((g) => g.id === l.group)) {
      errors.push(`悬空 group: ${l.group}`);
    }
  }
  if (doc.activeLayerId && !(doc.layers || []).some((l) => l.id === doc.activeLayerId)) {
    errors.push(`activeLayerId 不在 layers: ${doc.activeLayerId}`);
  }
  return { ok: errors.length === 0, errors };
}

export function cloneDoc(doc) {
  return JSON.parse(JSON.stringify(normalizeDoc(doc)));
}

/** 从旧版平铺 layers 构造 doc（兼容 Engine 旧调用） */
export function docFromFlatLayers(width, height, layers, groups = [], activeLayerId = null) {
  return createDoc({
    width, height,
    groups: groups.map((g) => createGroup(g)),
    layers: layers.map((l) => createLayer(l)),
    activeLayerId: activeLayerId || (layers.length ? layers[layers.length - 1].id : null),
  });
}

/** 把 doc 图层转成平铺元数据（保留 group 字段；旧代码读 this.layers 用） */
export function docToEngineLayers(doc) {
  const d = normalizeDoc(doc);
  return d.layers.map((l) => ({ ...l, mask: { ...l.mask } }));
}

export function docStats(doc) {
  const d = normalizeDoc(doc);
  const groupMasks = d.groups.filter((g) => g.mask && g.mask.exists).length;
  const masks = d.layers.filter((l) => l.mask.exists).length;
  const locked = d.layers.filter((l) => l.locked).length;
  const clipped = d.layers.filter((l) => l.clip).length;
  return { layers: d.layers.length, groups: d.groups.length, masks, groupMasks, locked, clipped };
}
