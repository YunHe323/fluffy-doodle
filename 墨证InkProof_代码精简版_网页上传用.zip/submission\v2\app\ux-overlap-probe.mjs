// v2/app/ux-overlap-probe.mjs — T120 界面错位/叠加 + 笔刷光标跟随 专项探针
// 背景：负责人报告「按钮错位叠加」「画布上圆形光标不跟随鼠标」。
// 常见根因：Windows 显示缩放（125%/150%）使 CSS 视口变小；画布 zoom≠1 时光标坐标系不一致。
// 只读探针：不改产品代码。产物 v2/qa/ux/overlap-*.png + overlap-result.json
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = Number(process.env.SERVE_PORT || 4212);
const OUT = path.join(ROOT, 'v2', 'qa', 'ux');
fs.mkdirSync(OUT, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = { schema: 'mozheng.qa.overlap-probe.v1', port: PORT, viewports: [], cursor: [], overlaps: [], truncations: [] };
let browser = null, finished = false;
const finish = (code) => {
  if (finished) return; finished = true;
  out.timestamp = new Date().toISOString();
  try { fs.writeFileSync(path.join(OUT, 'overlap-result.json'), JSON.stringify(out, null, 2), 'utf8'); } catch (e) {}
  try { if (browser) browser.close(); } catch (e) {}
  console.log('[OVERLAP] viewports=' + out.viewports.length + ' overlaps=' + out.overlaps.length + ' truncations=' + out.truncations.length + ' cursorCases=' + out.cursor.length +
    ' cursorFail=' + out.cursor.filter((c) => !c.ok).length);
  process.exit(code);
};
setTimeout(() => { out.fatal = 'TIMEOUT_240s'; finish(3); }, 240000);

try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const context = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  const page = await context.newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push(String(e).slice(0, 200)));
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
  await sleep(1200);

  // ---------- A. 笔刷光标跟随：多个 zoom 下比较「鼠标点」与「实际画出的圆心」 ----------
  const checkCursor = async (label, zoomFn) => {
    await page.evaluate(() => { const a = window.__V2_APP__; a.setTool('brush'); a.closePopovers(); });
    if (zoomFn) await page.evaluate(zoomFn);
    await sleep(500);
    const box = await page.locator('#mainCanvas').boundingBox();
    const px = box.x + box.width * 0.5, py = box.y + box.height * 0.4;
    await page.mouse.move(px - 60, py - 40);
    await page.mouse.move(px, py, { steps: 6 });
    await sleep(250);
    const res = await page.evaluate(({ px, py }) => {
      const c = document.getElementById('brushCursorCanvas');
      const mc = document.getElementById('mainCanvas');
      if (!c) return { err: 'no brushCursorCanvas' };
      const ctx = c.getContext('2d');
      const d = ctx.getImageData(0, 0, c.width, c.height).data;
      // 找非透明像素的包围盒 → 即画出的圆
      let minX = 1e9, minY = 1e9, maxX = -1, maxY = -1, n = 0;
      for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) {
        if (d[(y * c.width + x) * 4 + 3] > 8) { n++; if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
      }
      const cr = c.getBoundingClientRect(), mr = mc.getBoundingClientRect();
      const expectDoc = { x: (px - mr.left) * mc.width / mr.width, y: (py - mr.top) * mc.height / mr.height };
      const centerDoc = n ? { x: (minX + maxX) / 2, y: (minY + maxY) / 2 } : null;
      // 再把圆心换算回屏幕坐标，与鼠标屏幕坐标比
      const centerScreen = centerDoc ? { x: cr.left + centerDoc.x * cr.width / c.width, y: cr.top + centerDoc.y * cr.height / c.height } : null;
      return {
        pixels: n,
        internal: { w: c.width, h: c.height }, css: { w: Math.round(cr.width), h: Math.round(cr.height) },
        mainInternal: { w: mc.width, h: mc.height }, mainCss: { w: Math.round(mr.width), h: Math.round(mr.height) },
        transform: c.style.transform || getComputedStyle(c).transform,
        mainTransform: mc.style.transform || getComputedStyle(mc).transform,
        expectDoc: { x: Math.round(expectDoc.x), y: Math.round(expectDoc.y) },
        centerDoc: centerDoc ? { x: Math.round(centerDoc.x), y: Math.round(centerDoc.y) } : null,
        centerScreen: centerScreen ? { x: Math.round(centerScreen.x), y: Math.round(centerScreen.y) } : null,
        mouseScreen: { x: Math.round(px), y: Math.round(py) },
        zoom: (window.__V2_APP__ && window.__V2_APP__.view) ? window.__V2_APP__.view.zoom : null,
      };
    }, { px, py });
    const dx = res.centerScreen ? Math.abs(res.centerScreen.x - px) : 999;
    const dy = res.centerScreen ? Math.abs(res.centerScreen.y - py) : 999;
    const ok = res.pixels > 20 && dx <= 6 && dy <= 6;
    out.cursor.push({ label, ok, dx: Math.round(dx), dy: Math.round(dy), ...res });
  };
  await checkCursor('zoom=1 (default)', null);
  await checkCursor('zoom=1.5', () => { window.__V2_APP__.view.zoom = 1.5; window.__V2_APP__.view.tx = 0; window.__V2_APP__.view.ty = 0; document.getElementById('mainCanvas') && window.dispatchEvent(new Event('resize')); });
  await checkCursor('after applyView zoom1.5', () => { const a = window.__V2_APP__; a.view.zoom = 1.5; a.view.tx = 0; a.view.ty = 0; if (a.resetView) { a.view.zoom = 1.5; } });
  await page.evaluate(() => { const a = window.__V2_APP__; a.resetView(); });
  await sleep(400);
  await checkCursor('after resetView', null);

  // ---------- B. 多分辨率下的错位/叠加/截断 ----------
  const detect = async (w, h, tag) => {
    await page.setViewportSize({ width: w, height: h });
    await sleep(800);
    const info = await page.evaluate(() => {
      const vw = document.documentElement.clientWidth, vh = document.documentElement.clientHeight;
      const vis = (el) => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
        return r.width > 1 && r.height > 1 && s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity) > 0.05 &&
          !el.closest('.modal-mask:not(.show)') && !el.closest('[hidden]') && r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth; };
      const name = (el) => el.id ? '#' + el.id : (el.className || el.tagName).toString().slice(0, 28);
      // B1 交互元素两两叠加（按钮/输入/链接之间）
      const items = [...document.querySelectorAll('button, input, select, a, [role="button"], .btn')].filter(vis);
      const ov = [];
      for (let i = 0; i < items.length; i++) for (let j = i + 1; j < items.length; j++) {
        const a = items[i].getBoundingClientRect(), b = items[j].getBoundingClientRect();
        const ix = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        const iy = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        if (ix > 4 && iy > 4) {
          // 父子/同容器嵌套不算错位
          if (items[i].contains(items[j]) || items[j].contains(items[i])) continue;
          ov.push({ a: name(items[i]), b: name(items[j]), ta: (items[i].textContent || '').trim().slice(0, 12), tb: (items[j].textContent || '').trim().slice(0, 12), ix: Math.round(ix), iy: Math.round(iy), ra: [Math.round(a.left), Math.round(a.top), Math.round(a.width), Math.round(a.height)], rb: [Math.round(b.left), Math.round(b.top), Math.round(b.width), Math.round(b.height)] });
        }
      }
      // B2 文字截断
      const tr = [];
      [...document.querySelectorAll('button, .btn, span, label, .bb-stat, .mode-opt')].filter(vis).forEach((el) => {
        if (el.scrollWidth > el.clientWidth + 2 && el.clientWidth > 8) {
          const s = getComputedStyle(el);
          if (s.overflow === 'visible' && !s.textOverflow) return;
          tr.push({ el: name(el), text: (el.textContent || '').trim().slice(0, 18), scrollW: el.scrollWidth, clientW: el.clientWidth });
        }
      });
      // B3 固定栏是否超出视口
      const bars = [...document.querySelectorAll('.pro-topbar,.pro-bottombar,.toolbar,.sidebar,.pro-rail,.quick-start,.pro-popover')].filter(vis)
        .map((el) => { const r = el.getBoundingClientRect(); return { el: name(el), l: Math.round(r.left), t: Math.round(r.top), r: Math.round(r.right), b: Math.round(r.bottom), outX: r.right > vw + 1 || r.left < -1, outY: r.bottom > vh + 1 }; });
      return { vw, vh, overflowX: document.documentElement.scrollWidth - vw, overlapCount: ov.length, overlaps: ov.slice(0, 25), truncCount: tr.length, truncations: tr.slice(0, 20), bars: bars.filter((b) => b.outX || b.outY) };
    });
    await page.screenshot({ path: path.join(OUT, `overlap-${tag}-${w}x${h}.png`) });
    out.viewports.push({ tag, w, h, ...info });
    info.overlaps.forEach((o) => out.overlaps.push({ tag, w, h, ...o }));
    info.truncations.forEach((t) => out.truncations.push({ tag, w, h, ...t }));
  };
  await detect(1280, 720, 'laptop125');
  await detect(1366, 768, 'laptop100');
  await detect(1536, 864, 'desktop125');
  await detect(1920, 1080, 'desktop100');
  // 打开 AI 面板与图层面板（最常见的叠加来源）
  await page.setViewportSize({ width: 1366, height: 768 });
  await sleep(400);
  await page.evaluate(() => window.__V2_APP__.openPopover('popAI'));
  await sleep(700);
  await page.screenshot({ path: path.join(OUT, 'overlap-ai-open-1366.png') });
  const aiInfo = await page.evaluate(() => {
    const p = document.getElementById('popAI').getBoundingClientRect();
    return { l: Math.round(p.left), t: Math.round(p.top), r: Math.round(p.right), b: Math.round(p.bottom), vw: innerWidth, vh: innerHeight, outRight: p.right > innerWidth + 1, outBottom: p.bottom > innerHeight + 1 };
  });
  out.viewports.push({ tag: 'aiPopover', w: 1366, h: 768, ...aiInfo });
  if (aiInfo.outRight || aiInfo.outBottom) out.overlaps.push({ tag: 'aiPopover', note: 'AI 面板超出视口', ...aiInfo });

  out.pageErrors = errs;
  finish(0);
} catch (e) { out.fatal = String(e && e.stack || e).slice(0, 600); finish(2); }
