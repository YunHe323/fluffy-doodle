/**
 * v2/brushes/tools/path-engine-ab.mjs
 * T52：同一组笔迹输入 → bezier（T43 自研 stamp 管线）vs perfect-freehand(MIT) 轮廓。
 * 真实浏览器（默认 headless=new + 真实 GPU）跑 path-engine-ab.html，导出 6 张图
 * （3 笔刷 × 2 引擎，每张含 5 个场景行）+ JSON（耗时/append 耗时/live-commit 一致性）。
 *
 * 用法（项目根目录，先 node v2/serve.mjs）：
 *   node v2/brushes/tools/path-engine-ab.mjs [--headed]
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
const OUT = path.join(ROOT, 'v2', 'brushes', 'samples', 'pf');
fs.mkdirSync(OUT, { recursive: true });
const CDP_PORT = Number((process.argv.find((a) => a.startsWith('--cdp=')) || '').split('=')[1] || 9570);
/** 团队规范：自动化一律 headless；--headed 才开窗且移出屏幕 */
const HEADLESS = !process.argv.includes('--headed');
function resolveBase() {
  if (process.env.INKPROOF_BASE) return process.env.INKPROOF_BASE;
  try {
    const port = fs.readFileSync(path.join(ROOT, 'v2', '.runtime-port'), 'utf8').trim();
    if (/^\d+$/.test(port)) return 'http://127.0.0.1:' + port;
  } catch (e) { /* ignore */ }
  return 'http://127.0.0.1:4200';
}
const URL_ARG = process.env.PF_AB_URL || `${resolveBase()}/v2/brushes/tools/path-engine-ab.html`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const EDGE = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
].find((p) => fs.existsSync(p));

const report = { schema: 'inkproof.pf-ab.v1', url: URL_ARG, headless: HEADLESS, files: {}, ok: false };
let ws = null; let msgId = 0; const pending = new Map();
const send = (method, params = {}) => new Promise((resolve) => { const id = ++msgId; pending.set(id, resolve); ws.send(JSON.stringify({ id, method, params })); });
async function ev(expression, timeoutMs = 180000) {
  const r = await Promise.race([send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true }), sleep(timeoutMs).then(() => ({ __t: true }))]);
  if (r.__t) throw new Error('evaluate timeout');
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1500));
  return r.result?.result?.value;
}

const profile = path.join(os.tmpdir(), 'pfab-' + Date.now());
const args = ['--remote-debugging-port=' + CDP_PORT, '--user-data-dir=' + profile, '--no-first-run', '--no-default-browser-check'];
if (HEADLESS) args.push('--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1400,1000');
else args.push('--window-size=1400,1000', '--window-position=-3000,-3000', '--start-minimized');
args.push(URL_ARG);
const browser = spawn(EDGE, args, { stdio: 'ignore' });
try {
  let target = null;
  for (let i = 0; i < 400 && !target; i += 1) {
    try { const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json(); target = list.find((t) => t.type === 'page' && /^https?:/.test(t.url)); } catch (e) { /* wait */ }
    if (!target) await sleep(150);
  }
  if (!target) throw new Error('no target');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { const r = pending.get(m.id); pending.delete(m.id); r(m); } };
  await send('Runtime.enable');
  const t0 = Date.now();
  let ready = false;
  while (Date.now() - t0 < 90000) {
    const err = await ev('window.__PFAB_ERROR__ || null').catch(() => null);
    if (err) throw new Error('page error: ' + err);
    ready = await ev('!!window.__PFAB_READY__').catch(() => false);
    if (ready) break;
    await sleep(300);
  }
  if (!ready) throw new Error('PF AB page not ready');
  report.ab = await ev('window.__runPFAB__()');
  const runs = report.ab.runs || {};
  report.summaryRuns = {};
  for (const [key, run] of Object.entries(runs)) {
    if (!run.image) continue;
    const file = path.join(OUT, `pf-${key}.png`);
    fs.writeFileSync(file, Buffer.from(run.image.split(',')[1], 'base64'));
    report.files[key] = path.relative(ROOT, file).replace(/\\/g, '/');
    report.summaryRuns[key] = {
      brush: run.brush, engine: run.engine,
      totalMs: run.totalMs, appendMs: run.appendMs,
      liveCommit: run.scenarios['slow-curve'] ? run.scenarios['slow-curve'].liveCommit : null,
    };
    delete run.image;
  }
  // ab 里 images 太大不回传：只保留 summary 结构
  report.ab = { schema: report.ab.schema, createdAt: report.ab.createdAt, canvas: report.ab.canvas, runs: Object.fromEntries(Object.entries(runs).map(([k, v]) => [k, { brush: v.brush, engine: v.engine, totalMs: v.totalMs, appendMs: v.appendMs, scenarios: v.scenarios }])) };
  report.ok = Object.keys(report.files).length === 6;
  fs.writeFileSync(path.join(OUT, 'ab-data.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ ok: report.ok, headless: report.headless, files: report.files, summaryRuns: report.summaryRuns }, null, 2));
} catch (e) {
  report.fatal = String(e && e.stack || e);
  fs.writeFileSync(path.join(OUT, 'ab-data.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ ok: false, fatal: report.fatal }, null, 2));
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  try { browser.kill(); } catch (e) { /* ignore */ }
  await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  process.exit(report.ok ? 0 : 1);
}
