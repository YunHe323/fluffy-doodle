# T114 最终独立 QA：更多菜单 4 组重构 + 首屏状态

> 执行：qa-engineer（独立 QA｜task-128；Lead 消息中编号 task-129 不存在，实际任务为 task-128）｜日期：2026-11-07 22:0x｜只写 `v2/qa/tools/`；**未改 app**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、单浏览器串行、小批次（日志 `archive/baseline-t114-final/logs/`）。

## 结论

**可交付（Deliverable）——P0/P1 = 0；P2 = 1（test-ui 既有字号检验口径，非本轮回归）。**
新测试 `test-more-menu` PASS；9 项回归全 PASS、0 console error；**10 项独立焦点核验全 PASS**：4 组层级/2 列/440px/1366 与 1920 无溢出、**20 个按钮（含历史 undo/redo）点击命中**、图像调整/画布尺寸/裁剪/网格/三分线/自定义参考线/设置等点击效果、历史与快捷键折叠、undo/redo 与 projectStatus、quickstart 2 动作、statusContext、密钥；证据 mtime 未变、无付费调用、残留 0。

## 1. 新测试 `test-more-menu`（PASS）

- 4 组标题：`文件 / AI 与图像 / 视图与画布 / 项目`；关键按钮 **18 个**（test 选择器口径）
- 菜单 **宽 440**、高 **600**、bottom **650 < 768**、无需内滚动
- 点击「图像调整」→ `#adjustModal.show`；「画布尺寸」→ `#canvasResizeModal.show` 且标题「画布尺寸」
- quickstart 仍 **2 动作**；0 console error

## 2. 独立焦点核验（QA 自建探针，10/10 PASS）

| # | 检查 | 结果 |
|---|---|---|
| 1 | **4 组层级 + 2 列 + 440px** | 组名顺序完全一致；`grid-template-columns` 两列；宽 440 ✅ |
| 2 | **1366 无溢出** | 高 600、bottom 650 < 768、right 在视口内、文档无横向滚动 ✅ |
| 3 | **1920 无溢出** | 宽 440、right/bottom 在视口内、文档无横向滚动 ✅ |
| 4 | **按钮点击命中** | 展开两个折叠后 **20/20** 按钮 `elementFromPoint` 均命中自身（含 `#btnHistoryUndo/#btnHistoryRedo`）✅ |
| 5 | **关键效果点击** | 图像调整 ✅；画布尺寸（标题「画布尺寸」）✅；网格/三分线 toggle ✅；自定义参考线弹窗 ✅；设置/关于弹窗 ✅；AI 模型接入（打开关于页并定位 `#aiAccessCard`）✅；**裁剪到选区**（先设选区，弹窗标题「裁剪画布」）✅ |
| 6 | **历史折叠 + 列表** | 默认折叠（2 个 details 均 closed）；展开后 `#historyList` 渲染 1 项 ✅ |
| 7 | **undo/redo** | `btnHistoryUndo` 使 steps 1→0、`btnHistoryRedo` 0→1 ✅ |
| 8 | **projectStatus** | 「已自动保存 21:59:57 · v2 gzip · 11 KB」随操作更新 ✅ |
| 9 | **快捷键折叠** | 展开后文本含 `Ctrl+Z` 等快捷键 ✅ |
| 10 | **quickstart/statusContext/密钥/console** | quickstart 可见且 2 动作（draw/example）；statusContext「图层 2 · 画笔 · Mock · 协作」；DOM/LS/SS/已加载 JS 无 key；**0 console error** ✅ |

## 3. 回归（9 项全 PASS，0 console error）

test-more-menu、test-ui、test-ux-p0、test-app、test-editor-basics、test-guides、test-canvas-resize、test-quickstart-context、test-library。

> test-ui 为 owner 的「无 pass 字段」型脚本：`errors=[]`，`interactions.pass` 全 true；`p1Checks.pass.popoverFont12=false` 是**既有检验口径**（测的是浮层根字号：popAI/popMore 为 11），而 T114 菜单按钮实际 `font-size:12px`（ui-polish.css `#popMore .more-group-body button`），不构成本轮回归，见 P2 记录。

## 4. 真实证据 / 费用（无新增付费调用）

| 证据 | 核对 |
|---|---|
| `asset-real-read-results.json`（mtime 17:12 未变） | pass=true；22,955ms；real / L2=5 / L4=4 |
| `qwen-real-e2e-results.json`（mtime 16:53 未变） | pass=true；21,337ms；obs=2、regions=2、mock=false |
| 本轮真实请求 | **0**（纯 UI/离线页） |

## 5. 密钥 / 残留 / 本地服务

- 密钥：无 DOM/LS/SS/已加载 JS 泄漏；未打印 key。
- 残留：**Edge 0、测试端口 0**。
- `.runtime-port` = **4200**；`http://127.0.0.1:4200/health` → **200** `{ok:true,port:4200,pid:38452}`。

## 6. 问题清单

| # | 级别 | 内容 | owner | 建议 |
|---|---|---|---|---|
| 1 | **P2（既有口径）** | `test-ui` 的 `popoverFont12=false`：测量浮层根字号（popAI/popMore=11）< 其 12px 阈值；T114 菜单按钮实际 12px，非本轮视觉回归 | demo-builder（owner 测试） | 可把该断言改为测量浮层内按钮/选项字号，或接受 11px 根字号作为设计口径 |
| — | — | P0 / P1 | — | **无** |

## 7. 产物与归档

- `v2/qa/tools/T114-final-qa.md`（本报告）
- `v2/qa/tools/archive/baseline-t114-final/`：`logs/`（9 项测试日志）、各 result JSON、`focus-results.json`（10 项焦点核验）、真实证据 JSON、README
- GATE：`v2/qa/tools/GATE-pw.md`「T114 最终独立 QA」行
