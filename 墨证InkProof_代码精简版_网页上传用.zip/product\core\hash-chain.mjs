// product/core/hash-chain.mjs
// 事件哈希链（证据链核心）：跨运行时（浏览器 + Node 22+）、零依赖。
// 算法：hash_i = SHA-256( canonicalJson({ chain_version, prev_hash, seq, type, payload, createdAt, actor, mode, aiRole }) )
// 说明：使用 WebCrypto（globalThis.crypto.subtle），因此 API 为异步；浏览器与 Node 行为一致。
// 对齐：06-技术/技术架构.md v0.2 §7.1 / 契约 §3。

export const CHAIN_VERSION = '0.1.0';
export const HASH_ALG = 'SHA-256';
/** 创世前驱哈希（64 个 0） */
export const GENESIS_HASH = '0'.repeat(64);

const encoder = new TextEncoder();

function bytesToHex(bytes) {
  let out = '';
  for (let i = 0; i < bytes.length; i += 1) {
    out += bytes[i].toString(16).padStart(2, '0');
  }
  return out;
}

function assertCrypto() {
  const subtle = globalThis.crypto?.subtle;
  if (!subtle) {
    throw new Error('hash-chain: 需要 WebCrypto（请使用 Node 22+ 或现代浏览器）');
  }
  return subtle;
}

/**
 * SHA-256 → 小写 hex。
 * @param {string|Uint8Array} value
 * @returns {Promise<string>}
 */
export async function sha256Hex(value) {
  const subtle = assertCrypto();
  let bytes;
  if (typeof value === 'string') bytes = encoder.encode(value);
  else if (value instanceof Uint8Array) bytes = value;
  else bytes = encoder.encode(String(value));
  const digest = await subtle.digest(HASH_ALG, bytes);
  return bytesToHex(new Uint8Array(digest));
}

/**
 * 确定性 JSON 规范化（键排序；用于哈希输入；近似 RFC 8785 的稳定子集）。
 * 不支持：undefined / function / symbol / bigint / NaN / Infinity（抛出 TypeError）。
 */
export function canonicalJson(value) {
  return JSON.stringify(canonicalize(value));
}

function canonicalize(value) {
  if (value === null) return null;
  const t = typeof value;
  if (t === 'string' || t === 'boolean') return value;
  if (t === 'number') {
    if (!Number.isFinite(value)) throw new TypeError('canonicalJson: 不支持 NaN/Infinity');
    return value;
  }
  if (t === 'undefined') throw new TypeError('canonicalJson: 不支持 undefined');
  if (t === 'function' || t === 'symbol' || t === 'bigint') {
    throw new TypeError(`canonicalJson: 不支持 ${t}`);
  }
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map(canonicalize);
  if (t === 'object') {
    const out = {};
    for (const key of Object.keys(value).sort()) {
      if (value[key] === undefined) continue;
      out[key] = canonicalize(value[key]);
    }
    return out;
  }
  throw new TypeError(`canonicalJson: 不支持的类型 ${t}`);
}

function normalizeEvent(event, seq) {
  if (!event || typeof event !== 'object') throw new TypeError('createEvent: event 必须是对象');
  if (typeof event.type !== 'string' || event.type.length === 0) {
    throw new TypeError('createEvent: type 必须是非空字符串');
  }
  return {
    chain_version: CHAIN_VERSION,
    seq: Number.isInteger(seq) ? seq : event.seq,
    type: event.type,
    payload: event.payload === undefined ? null : event.payload,
    createdAt: event.createdAt ?? event.created_at ?? new Date().toISOString(),
    actor: event.actor ?? 'system',
    mode: event.mode ?? 'collab',
    aiRole: event.aiRole ?? event.ai_role ?? null,
  };
}

function hashMaterial(event) {
  return {
    chain_version: CHAIN_VERSION,
    prev_hash: event.prev_hash,
    seq: event.seq,
    type: event.type,
    payload: event.payload,
    createdAt: event.createdAt,
    actor: event.actor,
    mode: event.mode,
    aiRole: event.aiRole,
  };
}

/**
 * 创建一条事件并计算 hash。
 * @param {string|{hash:string}|null} prev 前一条事件或它的 hash；null → 创世
 * @param {{type:string, payload?:any, seq?:number, createdAt?:string, actor?:string, mode?:string, aiRole?:string|null}} event
 * @returns {Promise<object>} 冻结的事件对象（含 prev_hash / hash）
 */
export async function createEvent(prev, event) {
  const prevHash =
    prev == null ? GENESIS_HASH : typeof prev === 'string' ? prev : prev.hash;
  if (typeof prevHash !== 'string' || !/^[0-9a-f]{64}$/.test(prevHash)) {
    throw new TypeError('createEvent: prev 必须是 64 位 hex 哈希或事件对象');
  }
  const seq = Number.isInteger(event?.seq) ? event.seq : 1;
  const normalized = normalizeEvent(event, seq);
  const hash = await sha256Hex(canonicalJson(hashMaterial({ ...normalized, prev_hash: prevHash })));
  return Object.freeze({
    chain_version: CHAIN_VERSION,
    ...normalized,
    prev_hash: prevHash,
    hash,
  });
}

/**
 * 批量搭链：从 genesis 开始，从 startSeq 递增。
 * @param {Array<{type:string,payload?:any,createdAt?:string,actor?:string,mode?:string,aiRole?:string|null}>} events
 * @param {{startSeq?:number}} [options]
 * @returns {Promise<object[]>}
 */
export async function buildChain(events, options = {}) {
  if (!Array.isArray(events)) throw new TypeError('buildChain: events 必须是数组');
  const startSeq = Number.isInteger(options.startSeq) ? options.startSeq : 1;
  const out = [];
  let prev = GENESIS_HASH;
  for (let i = 0; i < events.length; i += 1) {
    const withSeq = { ...events[i], seq: startSeq + i };
    const next = await createEvent(prev, withSeq);
    out.push(next);
    prev = next.hash;
  }
  return out;
}

/**
 * 校验整条链：prev_hash 衔接、seq 递增、hash 可复算。
 * @param {object[]} events
 * @param {{requireGenesisPrev?:boolean}} [options]
 * @returns {Promise<{ok:boolean, count:number, lastHash:string, index?:number, reason?:string, expected?:string, actual?:string}>}
 */
export async function verifyChain(events, options = {}) {
  if (!Array.isArray(events)) return { ok: false, count: 0, lastHash: GENESIS_HASH, index: -1, reason: 'not_an_array' };
  let prev = GENESIS_HASH;
  for (let i = 0; i < events.length; i += 1) {
    const event = events[i];
    if (!event || typeof event !== 'object') {
      return { ok: false, count: events.length, lastHash: prev, index: i, reason: 'not_an_object' };
    }
    if (event.prev_hash !== prev) {
      return {
        ok: false, count: events.length, lastHash: prev, index: i,
        reason: i === 0 && !options.requireGenesisPrev ? 'prev_hash_mismatch' : 'prev_hash_mismatch',
        expected: prev, actual: event.prev_hash,
      };
    }
    if (i > 0 && event.seq !== events[i - 1].seq + 1) {
      return { ok: false, count: events.length, lastHash: prev, index: i, reason: 'seq_mismatch' };
    }
    const expected = await sha256Hex(canonicalJson(hashMaterial(event)));
    if (expected !== event.hash) {
      return { ok: false, count: events.length, lastHash: prev, index: i, reason: 'hash_mismatch', expected, actual: event.hash };
    }
    prev = event.hash;
  }
  return { ok: true, count: events.length, lastHash: prev };
}

/** 链头哈希（空链 → GENESIS_HASH） */
export function headHash(events) {
  if (!Array.isArray(events) || events.length === 0) return GENESIS_HASH;
  return events[events.length - 1].hash;
}

/**
 * checkpoint：对（条数 + 链头）做一次摘要，用于每日/每次导出的锚点。
 * @param {object[]|string} eventsOrHash
 */
export async function checkpointHash(eventsOrHash) {
  if (typeof eventsOrHash === 'string') return sha256Hex(`checkpoint:1:${eventsOrHash}`);
  const events = Array.isArray(eventsOrHash) ? eventsOrHash : [];
  return sha256Hex(canonicalJson({ count: events.length, head: headHash(events) }));
}
