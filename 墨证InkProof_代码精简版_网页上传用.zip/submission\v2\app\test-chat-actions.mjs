// v2/app/test-chat-actions.mjs —— 对话行动 chips + 画像建议
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8169;
const out = { schema: 'mozheng.app.chat-actions.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-chat-actions-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('mozheng.ai.settings.v1', JSON.stringify({ preset: 'qwen', allowReal: false, requireConfirm: true, privacyMode: true })); } catch (e) {} });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  // 设置一个选区，让 Mock 返回 generate/reference 建议
  await page.evaluate(() => { const a = window.__V2_APP__; a.state.selection = { x: 300, y: 200, width: 420, height: 300 }; a.openPopover('popAI'); });
  await page.waitForTimeout(400);
  await page.fill('#aiChatInput', '这个选区怎么改？');
  await page.click('#btnAiChatSend');
  await page.waitForTimeout(700);
  out.cases.actions = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const last = a.aiChat.slice(-1)[0] || {};
    return { count: (last.actions || []).length, types: (last.actions || []).map((x) => x.type), chips: document.querySelectorAll('[data-chat-action]').length };
  });
  const genChip = page.locator('[data-chat-action]').filter({ hasText: /生成|局部/ }).first();
  if (await genChip.count()) await genChip.click(); else await page.locator('[data-chat-action]').first().click();
  await page.waitForTimeout(400);
  out.cases.click = await page.evaluate(() => ({ imageTab: getComputedStyle(document.getElementById('aiTabImage')).display, prompt: (document.getElementById('aiImagePrompt') || {}).value || '' }));
  // 画像建议：ensure sample, confirm an observation
  out.cases.hints = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    try { await a.t71.ensureSampleLibrary(); } catch (e) { /* seed already running */ }
    await new Promise((r) => setTimeout(r, 900));
    const list = a.t71.listAssets();
    const asset = list[0];
    if (!asset) return { error: 'no asset' };
    const obs = (asset.L4 || [])[0];
    if (obs) await a.t71.confirmAsset(asset.id, { targetId: obs.id, tags: asset.tags || [] });
    await a.t71.selectLibraryAsset(asset.id);
    a.openPopover('popAI');
    a.switchAiTab('obs');
    a.t71.renderLibrary && a.t71.renderLibrary();
    await new Promise((r) => setTimeout(r, 300));
    const details = document.querySelector('.ai-profile'); if (details) details.open = true;
    const hints = document.querySelector('.ai-profile-hints');
    return { hasHints: !!hints, text: hints ? hints.innerText : '', tags: asset.tags ? asset.tags.slice(0, 3) : [] };
  });
  const useBtn = page.locator('#btnUseProfileHints');
  if (await useBtn.count()) { await useBtn.click(); await page.waitForTimeout(300); }
  out.cases.profile = await page.evaluate(() => ({ style: (window.__V2_APP__.state.aiProfile || {}).style || '', stored: !!localStorage.getItem('mozheng.ai.profile.v1') }));
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-chat-actions-1366.png' });
  out.cases.actionsOk = out.cases.actions.count >= 2 && out.cases.actions.chips >= 2 && out.cases.actions.types.includes('generate');
  out.cases.clickOk = out.cases.click.imageTab !== 'none' && out.cases.click.prompt.length > 0;
  out.cases.hintsOk = out.cases.hints.hasHints && /从你的/.test(out.cases.hints.text);
  out.cases.profileOk = out.cases.profile.style.length > 0 && out.cases.profile.stored;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.actionsOk && out.cases.clickOk && out.cases.hintsOk && out.cases.profileOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
