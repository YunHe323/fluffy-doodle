// v2/qa/tools/variance-app-s1.mjs — 专项：ours-app S1 断点 5 轮分布 + 每轮读回截图（判定噪声 vs 真断笔）
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPO = path.resolve(__dirname, '..', '..', '..');
const require = createRequire(import.meta.url);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const argv = process.argv.slice(2);
const ROUNDS = Number(argv[argv.indexOf('--rounds') + 1]) || 5;
const PORT = 4275;
const S1 = (() => { const a = []; for (let i = 0; i <= 40; i += 1) { const t = i / 40; a.push([0.12 + 0.76 * t, 0.5 + 0.28 * Math.sin(t * Math.PI * 2)]); } return a; })();
const portFile = path.join(REPO, 'v2', '.runtime-port');
fs.rmSync(portFile, { force: true });
const srv = spawn(process.execPath, [path.join(REPO, 'v2', 'serve.mjs')], { cwd: REPO, env: { ...process.env, PORT: String(PORT) }, stdio: 'ignore', windowsHide: true });
let origin = null;
for (let i = 0; i < 100; i += 1) { await sleep(150); try { const p = Number(String(fs.readFileSync(portFile, 'utf8')).trim()); const r = await fetch(`http://127.0.0.1:${p}/v2/app/index.html`); if (r.ok) { origin = `http://127.0.0.1:${p}`; break; } } catch { /* wait */ } }
if (!origin) { console.error('no server'); process.exit(1); }
const { chromium } = require('playwright-core');
const browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--window-size=1600,1000', '--window-position=-3000,-3000'] });
const out = { schema: 'mozheng.variance.app-s1.v1', at: new Date().toISOString(), rounds: [] };
const shots = path.join(__dirname, 'shots', 'variance-app');
fs.mkdirSync(shots, { recursive: true });
try {
  const ctx = await browser.newContext({ viewport: { width: 1532, height: 791 }, deviceScaleFactor: 1 });
  for (let round = 1; round <= ROUNDS; round += 1) {
    const page = await ctx.newPage();
    try {
      await page.goto(origin + '/v2/app/index.html', { waitUntil: 'load' });
      await page.evaluate(`(async () => { try { localStorage.clear(); sessionStorage.clear(); const dbs = indexedDB.databases ? await indexedDB.databases() : []; for (const db of (dbs || [])) indexedDB.deleteDatabase(db.name); } catch (e) {} })()`);
      await page.reload({ waitUntil: 'load' });
      await page.waitForFunction('window.__V2_APP_READY__ === true', { timeout: 60000 });
      await page.waitForTimeout(1200);
      const rect = await page.evaluate(`(() => { const r = document.getElementById('mainCanvas').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
      await page.evaluate(`(() => { const app = window.__V2_APP__; app.engine.setActiveLayer(app.engine.getLayers()[0].id); app.setTool('brush'); })()`);
      await page.waitForTimeout(250);
      const ref = await page.evaluate(`(async () => { const e = window.__V2_APP__.engine; e.compositor.compositeAll(e.store); return await e.getCompositeDataUrl(); })()`);
      await page.mouse.move(rect.x + rect.w * S1[0][0], rect.y + rect.h * S1[0][1]);
      await page.mouse.down();
      for (let i = 1; i < S1.length; i += 1) { await page.mouse.move(rect.x + rect.w * S1[i][0], rect.y + rect.h * S1[i][1]); await sleep(12); }
      await page.mouse.up();
      await page.waitForTimeout(400);
      const cur = await page.evaluate(`(async () => { const e = window.__V2_APP__.engine; e.compositor.compositeAll(e.store); return await e.getCompositeDataUrl(); })()`);
      fs.writeFileSync(path.join(shots, `round${round}-readback.png`), Buffer.from(cur.split(',')[1], 'base64'));
      const st = await page.evaluate(async ({ u1, u2, pts }) => {
        const load = async (src) => { const img = new Image(); img.src = src; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const x = c.getContext('2d'); x.drawImage(img, 0, 0); return { w: c.width, h: c.height, d: x.getImageData(0, 0, c.width, c.height).data }; };
        const A = await load(u1), B = await load(u2); const W = A.w, H = A.h;
        const mask = new Uint8Array(W * H); let ink = 0;
        for (let y = 0; y < H; y += 1) for (let x = 0; x < W; x += 1) { const i = (y * W + x) * 4; if (Math.abs(A.d[i] - B.d[i]) > 24 || Math.abs(A.d[i + 1] - B.d[i + 1]) > 24 || Math.abs(A.d[i + 2] - B.d[i + 2]) > 24) { mask[y * W + x] = 1; ink += 1; } }
        const R = Math.max(24, Math.min(72, Math.round(Math.min(W, H) * 0.06)));
        const probes = [];
        for (let s = 0; s < 12; s += 1) {
          const t = (s + 0.5) / 12; const fi = Math.min(pts.length - 1, t * (pts.length - 1));
          const j0 = Math.floor(fi), j1 = Math.min(pts.length - 1, j0 + 1), f = fi - j0;
          const px = Math.round((pts[j0][0] + (pts[j1][0] - pts[j0][0]) * f) * W);
          const py = Math.round((pts[j0][1] + (pts[j1][1] - pts[j0][1]) * f) * H);
          let near = 0, minD = 1e9;
          for (let dy = -R; dy <= R; dy += 1) for (let dx = -R; dx <= R; dx += 1) { const xx = px + dx, yy = py + dy; if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue; if (mask[yy * W + xx]) { near += 1; const d = Math.max(Math.abs(dx), Math.abs(dy)); if (d < minD) minD = d; } }
          probes.push({ s, near, minD: near ? minD : null, present: near >= 1 });
        }
        return { w: W, h: H, ink, R, probes, breakpoints: probes.filter((p) => !p.present).length, missingSegments: probes.filter((p) => !p.present).map((p) => p.s), minDist: probes.map((p) => p.minD) };
      }, { u1: cur, u2: ref, pts: S1 });
      out.rounds.push({ round, ...st });
      console.log(`[app-var] round ${round}: bp=${st.breakpoints} missing=[${st.missingSegments}] ink=${st.ink}`);
    } catch (e) {
      out.rounds.push({ round, error: String(e.message || e) });
      console.log(`[app-var] round ${round}: ERROR ${String(e.message || e).slice(0, 100)}`);
    } finally { await page.close().catch(() => {}); }
  }
  const bps = out.rounds.map((r) => r.breakpoints).filter((v) => typeof v === 'number');
  bps.sort((a, b) => a - b);
  const med = bps.length ? bps[Math.floor(bps.length / 2)] : null;
  const within = med == null ? [] : bps.filter((v) => Math.abs(v - med) <= 1);
  out.summary = {
    n: bps.length, bps, median: med, withinMedianPm1: within.length,
    noise: med != null && med <= 1 && within.length >= Math.max(3, Math.ceil(bps.length * 0.8)),
    verdict: null,
  };
  out.summary.verdict = out.summary.noise
    ? '噪声：断点中位 ≤1，≥80% 轮在 中位±1 内，且读回截图未见真实断笔 → 修 metric（中位±1、允许 ≤1 离群轮），不列 owner'
    : '存在离群：需查看 shots/variance-app/round*-readback.png 定位真实断笔段，列 owner';
  fs.writeFileSync(path.join(__dirname, 'variance-app-s1.json'), JSON.stringify(out, null, 2), 'utf8');
  console.log('[app-var] 汇总：' + JSON.stringify(out.summary));
} finally {
  await browser.close().catch(() => {});
  try { srv.kill(); } catch {}
  fs.rmSync(portFile, { force: true });
}
