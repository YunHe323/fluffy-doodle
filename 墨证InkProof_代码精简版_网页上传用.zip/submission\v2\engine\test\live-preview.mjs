#!/usr/bin/env node
// v2/engine/test/live-preview.mjs —— T44 实时预览回归（零依赖 CDP）
// 用法：node v2/engine/test/live-preview.mjs <demoUrl> [port] [outJson]
// 验证：拖动中（未 end）第一笔仍在 + 新笔迹可见；end 后正确；cancel/undo 正确；擦除 live 正确。
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}

const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `new Promise(async (resolve) => {
  const errors = [];
  window.addEventListener('error', (e) => errors.push(String(e.message)));
  const waitReady = async () => { const t0 = Date.now(); while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); } };
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  try {
    await waitReady();
    const eng = window.__V2__;
    const W = eng.width, H = eng.height;
    const checks = {};
    const capture = async () => {
      const url = await eng.getCompositeDataUrl();
      const img = new Image(); img.src = url; await img.decode();
      const c = document.createElement('canvas'); c.width = W; c.height = H;
      const cx = c.getContext('2d'); cx.drawImage(img, 0, 0);
      return cx.getImageData(0, 0, W, H).data;
    };
    const isInk = (d, x, y) => { const i = (y * W + x) * 4; return d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220; };
    const regionInk = (d, x0, y0, x1, y1) => { let n = 0; for (let y = y0; y <= y1; y += 2) for (let x = x0; x <= x1; x += 2) if (isInk(d, x, y)) n += 1; return n; };
    const strokePoints = (x0, y, x1, step) => { const pts = []; for (let x = x0; x <= x1; x += step) pts.push({ x, y: y + Math.sin((x - x0) / 40) * 6, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' }); return pts; };
    const playStroke = async (x0, y, x1, end = true) => {
      const pts = strokePoints(x0, y, x1, 12);
      eng.beginStroke(pts[0]);
      for (let i = 1; i < pts.length; i += 1) eng.appendPoint(pts[i]);
      if (end) { eng.endStroke(); await raf(); }
      else { await raf(); await raf(); }
    };

    // 1) 第一笔 end 后：非白 > 0
    await playStroke(300, 400, 700, true);
    const a = await capture();
    checks.firstEndInk = regionInk(a, 280, 360, 720, 440);

    // 2) 第二笔 begin+append 未 end：第一笔仍在 + 新笔迹可见
    const pts2 = strokePoints(300, 800, 700, 12);
    eng.beginStroke(pts2[0]);
    for (let i = 1; i < pts2.length; i += 1) eng.appendPoint(pts2[i]);
    await raf(); await raf();
    const b = await capture();
    checks.liveFirstStrokeVisible = regionInk(b, 280, 360, 720, 440);
    checks.liveSecondStrokeVisible = regionInk(b, 280, 760, 720, 840);
    checks.liveFirstPixel = isInk(b, 400, 400);
    eng.endStroke(); await raf();
    const c = await capture();
    checks.afterSecondEndFirst = regionInk(c, 280, 360, 720, 440);
    checks.afterSecondEndSecond = regionInk(c, 280, 760, 720, 840);

    // 3) cancel：未 end → 取消后不应有残留
    const pts3 = strokePoints(300, 1200, 700, 12);
    eng.beginStroke(pts3[0]);
    for (let i = 1; i < pts3.length; i += 1) eng.appendPoint(pts3[i]);
    await raf(); await raf();
    const d = await capture();
    checks.liveThirdVisible = regionInk(d, 280, 1160, 720, 1240);
    eng.cancelStroke(); await raf();
    const e = await capture();
    checks.afterCancelThird = regionInk(e, 280, 1160, 720, 1240);

    // 4) undo/redo 第二笔
    eng.undo(); await raf();
    const f = await capture();
    checks.afterUndoSecond = regionInk(f, 280, 760, 720, 840);
    checks.afterUndoFirstStill = regionInk(f, 280, 360, 720, 440);
    eng.redo(); await raf();
    const g = await capture();
    checks.afterRedoSecond = regionInk(g, 280, 760, 720, 840);

    // 5) 擦除笔刷 live：应擦掉图层内容（白底），不能白盖/盖黑
    let eraserPaint = null;
    const eraserProvider = {
      id: 'test-eraser',
      eraser: true,
      radiusFor() { return 30; },
      paintFor(ctx) {
        if (!eraserPaint) { eraserPaint = new ctx.CK.Paint(); eraserPaint.setAntiAlias(true); eraserPaint.setStyle(ctx.CK.PaintStyle.Fill); }
        eraserPaint.setBlendMode(ctx.CK.BlendMode.Clear);
        return eraserPaint;
      },
      stampFor(ctx) { ctx.canvas.drawCircle(ctx.x, ctx.y, ctx.radius, ctx.paint); },
    };
    const prevProvider = eng.setBrushProvider(eraserProvider);
    eng.beginStroke({ x: 520, y: 400, pressure: 0.6, timestamp: performance.now(), pointerType: 'mouse' });
    for (let i = 0; i < 12; i += 1) eng.appendPoint({ x: 520 + i * 6, y: 400, pressure: 0.6, timestamp: performance.now(), pointerType: 'mouse' });
    await raf(); await raf();
    const h = await capture();
    checks.eraserLiveCenterWhite = !isInk(h, 520, 400);
    checks.eraserLiveEdgeKept = isInk(h, 350, 400);
    eng.endStroke(); await raf();
    const i2 = await capture();
    checks.eraserEndCenterWhite = !isInk(i2, 520, 400);
    eng.undo(); await raf();
    const j = await capture();
    checks.eraserUndoRestored = isInk(j, 520, 400);
    eng.setBrushProvider(prevProvider);

    checks.ok = checks.firstEndInk > 100
      && checks.liveFirstStrokeVisible > 100
      && checks.liveSecondStrokeVisible > 100
      && checks.liveFirstPixel
      && checks.afterSecondEndFirst > 100
      && checks.afterSecondEndSecond > 100
      && checks.liveThirdVisible > 50
      && checks.afterCancelThird < 10
      && checks.afterUndoSecond < 10
      && checks.afterUndoFirstStill > 100
      && checks.afterRedoSecond > 100
      && checks.eraserLiveCenterWhite
      && checks.eraserLiveEdgeKept
      && checks.eraserEndCenterWhite
      && checks.eraserUndoRestored
      && errors.length === 0;
    resolve({ ok: checks.ok, checks, errors, environment: { browser: (navigator.userAgent.match(/Chrome\\/[\\d.]+/) || [])[0] || '', headless: /HeadlessChrome/.test(navigator.userAgent) } });
  } catch (e) {
    resolve({ ok: false, error: String(e && e.stack || e), errors });
  }
})`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1200)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败:', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
