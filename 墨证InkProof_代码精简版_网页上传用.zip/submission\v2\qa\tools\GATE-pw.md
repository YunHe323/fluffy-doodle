﻿# GATE · T51 Playwright 重写版（tools/harness.mjs）

> 生成：2026-11-07T04:48:30.258Z｜浏览器：Microsoft Edge（playwright-core `channel:'msedge'`，headless=true）｜轮数：3
> 数据：`pw/results.json`、`pw/round-*.json`、`pw/shots/`｜旧 harness 结论对比：`pw/legacy-vs-pw.md`

## 结论

**全部闸门通过（冒烟 + Klecks 对照 + 3 轮一致性）。**

## 闸门清单

| # | 闸门 | 结果 | 证据 | 未过 owner |
|---|---|---|---|---|
| 1 | G1 · ours-app 冒烟（ready/canvas/绘制/帧稳定/undo） | ✅ 通过 | {"ready":true,"drew":true,"midStrokeKeepsPrevious":true,"frames1Stable":true,"frames2Stable":true,"undoFramesStable":true,"undoStateCorrect":true} | — |
| 2 | G1 · ours-brushes 冒烟（ready/canvas/绘制/帧稳定/undo） | ✅ 通过 | {"ready":true,"drew":true,"midStrokeKeepsPrevious":true,"frames1Stable":true,"frames2Stable":true,"undoFramesStable":true,"undoStateCorrect":true} | — |
| 3 | G1 · ours-engine 冒烟（ready/canvas/绘制/帧稳定/undo） | ✅ 通过 | {"ready":true,"drew":true,"midStrokeKeepsPrevious":true,"frames1Stable":true,"frames2Stable":true,"undoFramesStable":true,"undoStateCorrect":true} | — |
| 4 | ours-app · S1 慢速连续笔迹无断点（≤1） | ✅ 通过 | 断点中位=0；CV=0.166 | — |
| 5 | ours-app · S1 真线宽 CV（质量门槛 ≤0.45；宽<3px 时仅记录） | ✅ 通过 | S1 真线宽 CV=0.191（宽=22.67px，可信）；密度 CV=0.166（参考） | — |
| 6 | ours-app · S2 真线宽 CV（质量门槛 ≤0.60；宽<3px 时仅记录） | ✅ 通过 | S2 真线宽 CV=0.267（宽=8.1px，可信）；密度 CV=0.505（参考） | — |
| 7 | ours-app · S2 快速笔迹断点（ours ≤ Klecks+2；Klecks 为参照） | ✅ 通过 | 断点中位=4（Klecks=6；阈值=8） | — |
| 8 | ours-app · S3 帧稳定（3 轮 0/16/50/200ms） | ✅ 通过 | 帧 inks：3341/3341/3341/3341 | 3342/3342/3342/3342 | 3340/3340/3340/3340 | — |
| 9 | ours-app · S3 undo 帧完整（3 轮） | ✅ 通过 | undo 前/后：3341→1602 | 3342→1603 | 3340→1602 | — |
| 10 | ours-app · 3 轮结构稳定（中位±1 + 帧稳定） | ✅ 通过 | S1 断点：0/0/0（中位=0，中位±1 内 3/3 轮，允许 ≤1 离群）；帧稳定：✅/✅/✅；ink 范围 6863–7381（受笔刷动态/输入时序影响，仅记录） | — |
| 11 | ours-brushes · S1 慢速连续笔迹无断点（≤1） | ✅ 通过 | 断点中位=0；CV=0.34 | — |
| 12 | ours-brushes · S1 真线宽 CV（质量门槛 ≤0.45；宽<3px 时仅记录） | ✅ 通过 | S1 真线宽 CV=—（宽=1.82px，细线·CV 不作门槛）；密度 CV=0.34（参考） | — |
| 13 | ours-brushes · S2 真线宽 CV（质量门槛 ≤0.60；宽<3px 时仅记录） | ✅ 通过 | S2 真线宽 CV=—（宽=1.55px，细线·CV 不作门槛）；密度 CV=0.781（参考） | — |
| 14 | ours-brushes · S2 快速笔迹断点（ours ≤ Klecks+2；Klecks 为参照） | ✅ 通过 | 断点中位=4（Klecks=6；阈值=8） | — |
| 15 | ours-brushes · S3 帧稳定（3 轮 0/16/50/200ms） | ✅ 通过 | 帧 inks：1795/1795/1795/1795 | 1809/1809/1809/1809 | 1730/1730/1730/1730 | — |
| 16 | ours-brushes · S3 undo 帧完整（3 轮） | ✅ 通过 | undo 前/后：1795→898 | 1809→855 | 1730→882 | — |
| 17 | ours-brushes · 3 轮结构稳定（中位±1 + 帧稳定） | ✅ 通过 | S1 断点：0/0/0（中位=0，中位±1 内 3/3 轮，允许 ≤1 离群）；帧稳定：✅/✅/✅；ink 范围 1357–1606（受笔刷动态/输入时序影响，仅记录） | — |
| 18 | ours-engine · S1 慢速连续笔迹无断点（≤1） | ✅ 通过 | 断点中位=0；CV=0.506 | — |
| 19 | ours-engine · S1 真线宽 CV（质量门槛 ≤0.45；宽<3px 时仅记录） | ✅ 通过 | S1 真线宽 CV=0.276（宽=31.14px，可信）；密度 CV=0.506（参考） | — |
| 20 | ours-engine · S2 真线宽 CV（质量门槛 ≤0.60；宽<3px 时仅记录） | ✅ 通过 | S2 真线宽 CV=0.077（宽=13px，可信）；密度 CV=0.757（参考） | — |
| 21 | ours-engine · S2 快速笔迹断点（ours ≤ Klecks+2；Klecks 为参照） | ✅ 通过 | 断点中位=7（Klecks=6；阈值=8） | — |
| 22 | ours-engine · S3 帧稳定（3 轮 0/16/50/200ms） | ✅ 通过 | 帧 inks：6484/6484/6484/6484 | 6484/6484/6484/6484 | 6484/6484/6484/6484 | — |
| 23 | ours-engine · S3 undo 帧完整（3 轮） | ✅ 通过 | undo 前/后：6484→3242 | 6484→3242 | 6484→3242 | — |
| 24 | ours-engine · 3 轮结构稳定（中位±1 + 帧稳定） | ✅ 通过 | S1 断点：0/0/0（中位=0，中位±1 内 3/3 轮，允许 ≤1 离群）；帧稳定：✅/✅/✅；ink 范围 12614–13259（受笔刷动态/输入时序影响，仅记录） | — |
| 25 | klecks · S1 慢速连续笔迹无断点（≤1） | ✅ 通过 | 断点中位=0；CV=0.173 | — |
| 26 | klecks · S1 真线宽 CV（质量门槛 ≤0.45；宽<3px 时仅记录） | ✅ 通过 | S1 真线宽 CV=—（宽=1.13px，细线·CV 不作门槛）；密度 CV=0.173（参考） | — |
| 27 | klecks · S2 真线宽 CV（质量门槛 ≤0.60；宽<3px 时仅记录） | ✅ 通过 | S2 真线宽 CV=—（宽=1.25px，细线·CV 不作门槛）；密度 CV=0.435（参考） | — |
| 28 | klecks · S2 快速笔迹断点（ours ≤ Klecks+2；Klecks 为参照） | ✅ 通过 | 断点中位=6（Klecks=6；阈值=参照） | — |
| 29 | klecks · S3 帧稳定（3 轮 0/16/50/200ms） | ✅ 通过 | 帧 inks：302/383/383/383 | 302/383/383/383 | 383/383/383/383 | — |
| 30 | klecks · S3 undo 帧完整（3 轮） | ✅ 通过 | undo 前/后：383→185 | 383→185 | 383→185 | — |
| 31 | klecks · 3 轮结构稳定（中位±1 + 帧稳定） | ✅ 通过 | S1 断点：0/0/0（中位=0，中位±1 内 3/3 轮，允许 ≤1 离群）；帧稳定：✅/✅/✅；ink 范围 437–437（受笔刷动态/输入时序影响，仅记录） | — |

## 与 Klecks 对比（我们三页中位 vs Klecks 中位）

| 指标 | 我们 | Klecks | 判定 |
|---|---|---|---|
| S1 断点数（越少越好） | 0 | 0 | 🟰 持平（Δ=0） |
| S1 真线宽 CV（越小越好·质量门槛） | 0.23 | — | ❌ 数据缺失 |
| S1 密度 CV（参考·噪声大，不作门槛） | 0.34 | 0.173 | ❌ Klecks 更好（Δ=0.167） |
| S2 断点数（越少越好） | 4 | 6 | ✅ 我们更好（Δ=-2） |
| S2 真线宽 CV（越小越好·质量门槛） | 0.17 | — | ❌ 数据缺失 |
| S2 密度 CV（参考·噪声大，不作门槛） | 0.757 | 0.435 | ❌ Klecks 更好（Δ=0.322） |
| S3 两笔后 ink（口径参考） | 3341 | 383 | ✅ 我们更好（Δ=2958） |

## 口径说明
- 3 轮稳定性门槛采用**结构指标**（S1 断点一致 + 帧稳定）；ink 绝对值随笔刷动态（T54 鼠标速度模拟压感）与输入时序波动，只作记录不作为门槛。
- **T80 口径修订**：S1/S2 笔迹质量以**真线宽 CV**（法向截面 run-length）为准；密度 CV 受采样/细线影响属噪声，仅参考、不作门槛；帧稳定/undo/断点门槛不变。
- **细线说明**：笔画平均宽 <3px 时（如 Klecks 铅笔/brushes demo 默认笔刷），run-length 取整量化使 CV 不可靠 → 该情形 CV 仅记录、不作门槛（对比表相应行亦不据此判优劣）。
- 真线宽 CV 与 Klecks 的差异若存在，归 T59（owner brush-engineer），不阻塞画布验收；**不按密度 CV 判优劣**。

## 不可比项 / 替代验证

| 模块 | 状态 | 原因 | 替代验证 |
|---|---|---|---|
| 图层/组/蒙版/16 混合脚本化对照 | 不可比 | Klecks dist 无稳定公开脚本 hook；Playwright 虽可点 UI，但选择器随版本变，且会引入非绘制噪声 | 我们侧 `v2/qa/browser-smoke.mjs`、`v2/app/test-app.mjs`；观感见 `bench/quality/评分表.md` |
| PSD 往返 | 不可比（本轮） | Klecks PSD 入口为 UI 交互 | `v2/psd/results/fidelity.json`（T39，6 样本） |
| 压感/倾斜 | 不可比（无硬件） | 测试机无手绘板（P3 暂缓） | 鼠标速度模拟；有硬件后补 P3 |
| presented-frame 视觉证据 | 本 harness 用 readback（引擎离屏合成/canvas.toDataURL） | headless 截图对 WebGL 不稳定、可见窗口不可用（用户投诉） | T42 有头运行归档：`v2/qa/reports/smoke-http.json` + `reports/screens/` |

## 结论一致性

与旧 `compare/GATE.md` 的逐项对比见 `legacy-vs-pw.md`。
## T97 独立 QA 结论（AI 接入 + 交互 + 最终回归 · 2026-11-07 12:5x）

**结论：可交付（Deliverable）**，P0/P1 阻塞 = 0。

- AI 代理：owner 自带 26/26 + QA 对抗 **35/35**（token/confirm/Origin/尺寸/参考图/并发/12h URL/密钥泄漏/413/ACL）；app 模型接入独立 QA **18/18**（正常 serve、T99 注入 token，无 addInitScript）。
- 交互：owner 9/9 + QA 组合 **6/6**（含确认弹窗 Esc，首轮 P2 发现后已修）。
- 回归：三页冒烟 3/3、4×3 GATE 全部闸门通过、功能回归 25/25、app 测试 12/13（唯一 P2：素材库遮罩 scrim，owner demo-builder）。

- **P2 关闭（2026-11-07 12:57）**：`test-library` scrim 断言已修复（测试写死 T75 旧值 `0.72`；paper 实际 `rgba(35,27,18,.62)`，符合 T87）→ 断言改 alpha `0.55–0.75` + `blur(2px)`；QA 仅复跑 `test-library`（19/19，scrim=true）与 `test-ui`（0 error），**遗留 P2 = 0**。

## T102 真实 Qwen 集成独立 QA（2026-11-07 13:3x）

**结论：真实 Qwen 集成可交付（Deliverable），P0/P1 阻塞 = 0。**

- 代理/假上游独立复跑：`ai-proxy-qwen-test` **12/12**、`ai-proxy-test` **32/32**、`ai-proxy-adversarial` **35/35**（0 error）。
- 产物核对 **7/7**：候选 sha256=`29a2875…b12e` 与 `qwen-real-candidate.png` 一致；L6 含 provider=qwen/model/candidate_sha256/usage；证据 `real_calls=1`==L6 事件 1、`verify-evidence` 12/12 通过；静态/运行时无 key；`.gitignore` 生效。
- **一次最小真实视觉调用**：`/api/ai/chat` 64×64 → 200 · mode=real · `qwen3.8-max` · **3.7s / 203 tokens**（内容正确）；未重复真实生图。
- 回归：test-app / test-ui PASS（0 error）、test-interaction-sequences **9/9**、三页冒烟 **3/3**；GATE 保持 T97 全绿。
- 风险（非阻塞）：真实调用延迟 8.7–20s 需进度提示；生图成本高建议演示用预置缓存（owner lead/demo-builder）。

## T103 AI 深度嵌入 + 编辑器基础独立 QA（2026-11-07 14:3x）

**结论：可交付（Deliverable），P0/P1 = 0。** 新增 5 测试 + 回归全过；过程中 2 个 P1（Lead 已修复、QA 已复核），残留 1 个 P2（标注覆盖层缩放同步，owner=lead，不阻塞）。

- 新增：`test-editor-basics`（×2 稳定）、`test-image-pan`、`test-multimodal`、`test-chat`、`test-canvas-size` 全部 **PASS**，0 console error。
- P1-1（已修）：`ai-collab.css` 重写丢失覆盖层规则 → `#annotationCanvas` static、标注到不了画布；修复后 mode/dirty/ink/annotatedCrop 全 true（alphaPixels=2223）。
- P1-2（已修）：`[hidden]` 被 `display:flex` 覆盖 → 隐藏 chip 拦截点击、`?new=1` draw undo=0；加 `[hidden]{display:none!important}` 后 `test-canvas-size` PASS（undo=1）。
- **P2（残留）**：`annotationCanvas`/`candidatePreviewCanvas` 未加入 `app.js` L413 适配缩放循环 → fit 缩放(0.8275)下 main=993×662 而标注层仍 1200×800（rect 偏移 ~104/69px），AI 标注位置会偏；建议加两个 id 到缩放数组并补对齐断言（owner=lead）。
- 回归：test-app / test-ui / interaction **9/9** / library 19/19（scrim=true）/ demo / ai-provider 16/16 全 PASS；密钥运行时不泄漏；Qwen 证据有效（e2e 11014ms/1094tok、chat 2689ms/330tok，未新增真实调用）。
- 残留：Edge 0、测试端口 0；截图为 `v2/app/ui-editor-basics-1920.png`、`ui-multimodal-1920.png`、`ui-chat-1920.png`、`ui-canvas-1600x1000.png`。

- **T103 增补：P2 关闭（2026-11-07 14:4x）**：Lead 已将 `annotationCanvas`/`candidatePreviewCanvas` 补进 `fitView` 尺寸循环；`test-multimodal` 新增坐标对齐断言并通过 —— QA 复跑 `align` 三层 rect 完全一致 **(212.5,66,993×662)**、`alignOk=true`，annotation/done/locate/voice/noErrors 全 true、0 error。**T103 最终：P0/P1/P2 = 0，可交付。**

## T104 AI 图像工作台 / 真实图像编辑 / 文字工具 / AI 画布标注层 / 档案 schema 独立 QA（2026-11-07 15:2x）

**结论：可交付（Deliverable），P0/P1 = 0，P2 = 2（记录性，不阻塞）。**

- 新增：`test-image-workshop` **PASS×2 稳定**（2 候选/2 卡片、预览 alpha=1001、落层 2→3 + transformActive、编辑 task=edit）；`test-text` **PASS**（图层 2→3、层名「文字 · 雾中山谷」、**L6 text_inserted 记录=1**）；`test-multimodal` **PASS**（标注/对齐 alignOk/定位/语音/**橙色 AI 标注层 alpha=5001**）。
- schema：6 类 L6（text_inserted/pixel_paste/asset_inserted/reference_added/generation/critique）静态校验全 valid；运行时 pixel_paste(ai_role=null)/asset_inserted 均被接受，逐条校验 badCount=0。
- 真实证据：`qwen-image-edit-app-results.json` provider=qwen、modelVersion=qwen-image-3.0-pro、mock=false、51113ms、6.6MB、sha256 `b8790a18…`、落层 transformActive=true —— 全部核对通过。
- **QA 一次最小真实编辑**（代理 task=edit，512 源图）：200/real/qwen-image-3.0-pro/47.3s/2048²/2.97MB/sha `45c2ebe1…`，代理适配独立验证可用（仅 1 次，约 ¥0.2）。
- 回归 10 项全 PASS（app/ui/interaction 9/9/library 19/19/demo/ai-provider 16/16/image-pan/editor-basics/chat/canvas-size），0 console error；密钥无 DOM/localStorage/JS 泄漏；残留 0。
- **P2（记录性）**：①`qwen-image-edit-real.png` 与证据 JSON 候选字节不一致（PNG 2048²/5.16MB/sha `a7e9514d…` vs 6.6MB/sha `b8790a18…`，且 JSON 未引用该文件）→ owner lead 建议原样落盘并记录 sha；②`test-text.mjs` 收集 textRecord 但未纳入 pass 断言（QA 独立断言=1 通过）→ owner demo-builder/lead 建议补断言。

## T105-F 最终独立 QA（Skill + mask 落层 + 素材 AI + 编辑器操作 · 2026-11-07 17:0x）

**结论：可交付（Deliverable），P0/P1 = 0；P2 = 1（测试契约过期）。** 新增 6 测试 + 11 项回归均独立复核通过；真实证据一致；密钥/残留 0。

- 新增：test-mask-compare PASS（outsideDiff=0、mask_policy=selection_alpha、clip=70%、skill=image.generate）；test-editor-ui PASS（调整/形状 L6 adjust_layer/shape_inserted）；test-ux-p0 PASS（1366 顶栏无重叠、Esc/打开 AI 退出变换、AI 关闭按钮）；asset-ai-test 10/10；editor-ops-test 77 断言；Skill 5 路径 QA 独立复核 PASS（asset.decompose/canvas.observe/canvas.directions/image.generate/image.edit）。
- 回归 11 项全 PASS（library scrim 已恢复 0.62/2px 且 exit-code 已修；image-workshop/multimodal/chat/canvas-size/text/editor-basics/ai-provider 16/16/interaction 9/9/app/ui），0 console error。
- 证据：qwen-real-e2e 21.3s / obs=2 / regions=2 / usage=1271 / mock=false / evidence 12/12 / real_calls=1；qwen-image-edit-app（qwen-image-3.0-pro / 51.1s / sha b8790a18… / transformActive）；asset-real-read（real / qwen3.8-max / 26.3s / asset.decompose / L2=5 / L4=4）——全部核对通过，未新增真实调用。
- **P2-1**：skill-runtime-test.mjs 断言 3 skills 已过期（集成后 5 个：新增 canvas.directions/image.generate）→ 产品运行时正常，仅单测需更新（owner lead/demo-builder）；无 P0/P1。
- 密钥：DOM/localStorage/sessionStorage/已加载 JS/静态源码无泄漏；残留：Edge 0、端口 0。

## T106-F 最终独立 QA（视图/光标/文字二次编辑/素材批量 · 2026-11-07 17:2x）

**结论：可交付（Deliverable），P0/P1/P2 = 0。** 3 个新功能测试 + 5 个模块单测 + 14 项回归全过；6 项重点独立核验全 PASS；真实证据一致且未新增付费调用。

- 新功能：test-text-edit PASS（图层数不变、L6 text_edited=1、光标 alpha=432）；test-guides PASS（网格/三分线/对称轴 alpha 与标签）；test-asset-batch PASS（Mock 3/3、0 失败、L6 asset_batch_decompose mode=mock skill=asset.decompose）。
- 单测：asset-batch 11/11、guides 124 断言、asset-ai 10/10、editor-ops 77 断言、skill-runtime PASS（已更新为 5 skills）。
- 独立核验（QA 探针 6/6 PASS）：batch Mock **0 次 /api/ai 请求**、无假真实记录；文字编辑 **undo 后像素 diff=0**；guides 为纯视图层（导出 diff=0、undoDepth 不变、save/evidence 无 guide 字段、guideCanvas pointer-events:none）；密钥无 DOM/LS/SS/JS 泄漏。
- 回归 14 项全 PASS（含 test-library、test-ai-provider、test-interaction 9/9），0 console error；Edge 0、端口 0。
- 证据：asset-real-read 最新 **22,955ms / real / qwen3.8-max / L2=5 / L4=4**；qwen-real-e2e **21,337ms / obs=2 / regions=2 / mock=false / evidence 12/12 / real_calls=1** —— 与 Lead 口径一致，**未新增付费调用**。

## T107-F 最终独立 QA（文字持久化 / 对称笔迹 / 形状吸附 · 2026-11-07 17:3x）

**结论：可交付（Deliverable），P0/P1 = 0；P2 = 1（形状吸附记录值 1px 偏差）。** 新功能 3 项 + 模块单测 5 项 + 回归 16 项全过；文字 meta 持久化/旧 doc 兼容、对称 x/y/both 与关闭不重放、形状吸附均独立核验；真实证据一致且未新增付费调用。

- 新功能：test-text-edit PASS（persistOk：meta 入 doc、loadProjectText 恢复 textLayers、双击预填一致、text_edited=1、undo 像素 diff=0）；test-symmetry PASS（axis=x，leftInk 531/rightInk 864）；test-guides PASS（网格/三分线/对称轴 alpha+标签）。
- 独立核验：旧 doc 删 meta 后 load 正常（textLayers=0、layers=3、无崩溃）；对称 x→左右、y→上下、both→四象限均正确，**undo 步数 x/y=2、both=4（事实记录）**，关闭对称后不重放；形状吸附生效（x/y 距 80 倍数仅 1px：239/159 → 240/160）。
- 单测：guides 124、asset-batch 11/11、asset-ai 10/10、editor-ops 77、skill-runtime PASS（5 skills）。
- 回归 16 项全 PASS（含 interaction 9/9、asset-batch、ai-provider），0 console error；密钥无泄漏；Edge 0、端口 0。
- 证据：asset-real-read 22,955ms / real / L2=5 / L4=4；qwen-real-e2e 21,337ms / obs=2 / regions=2 / mock=false / evidence 12/12 / real_calls=1 —— 未新增付费调用。
- **P2**：shape_inserted 记录坐标 239/159（距 80 整数 1px），建议核实 1px 内缩或断言用 ±1px 容差（owner demo-builder/lead）。

## T108-F 最终独立 QA（对称 undo 合并 + 网格/三分线/变换吸附 · 2026-11-07 19:5x）

**结论：可交付（Deliverable），P0/P1/P2 = 0。** 新功能 2 项 + 模块单测 5 项 + 回归 13 项全过；对称/普通画笔/transform 吸附/密钥 4 组独立核验全 PASS；真实证据未变、未新增付费调用。

- 新功能：test-symmetry PASS（undoDelta=1、left 533/right 864、单次 undo 归零 0/0）；test-shape-snap PASS（shape_inserted x=240/y=160、anchor [240,160,80,80]、snapGrid (240,160)、snapThirds (400,266.667)）。
- 独立核验：对称 x/y/both **steps 增量均=1**、单次 undo 四象限归零、关闭对称不重放；普通画笔单笔 undoDelta=1、第二笔=1、undo/redo 像素 diff=0；transform 拖拽吸附（网格位移 -22.5/-83.5 命中 (240,160)；三分线 160/106.667 命中 (400,266.667)）。
- T107 遗留 P2 已关闭：形状吸附记录精确 240/160。
- 单测：guides 124、asset-batch 11/11、asset-ai 10/10、editor-ops 77、skill-runtime PASS。
- 回归 13 项全 PASS（app/ui/text-edit/guides/editor-basics/mask-compare/editor-ui/ux-p0/ai-provider/interaction 9/9/asset-batch/symmetry/shape-snap），0 console error；密钥无泄漏；Edge 0、端口 0。
- 证据：asset-real-read 22,955ms real/L2=5/L4=4；qwen-real-e2e 21,337ms obs2 regions2 mock=false real_calls=1（mtime 未变，未新增付费调用）。

## T109-F 最终独立 QA（画布 resize/crop + 历史清空 + mask 保留 · 2026-11-07 20:0x）

**结论：可交付（Deliverable），P0/P1/P2 = 0（另 1 条探针方法说明，非产品缺陷）。** 新测试 + 12 项独立核验 + 16 项回归全过；真实证据未变、未新增付费调用。

- 新测试 test-canvas-resize PASS：1200×800→800×600（canvas 同步、layers=2、steps=0、L6=1）；resize 后继续画 ink 2745→4821；裁剪 400×300（layers=2、ink=2076、steps=0、L6=2）；modal 标题/尺寸/锚点禁用正确；0 error。
- 独立核验 12/12：resize/crop 后保存→load 恢复尺寸/图层/文字 meta；连续 resize 两次 steps 均 0；最小 16×16、最大 4096×2048 与 4096×4096 均成功（无 OOM）；layer mask/组 mask 结构+像素数据保留（resize 后 masked 点白、unmasked 点深色）；保存 JSON 含 mask 且 load 后存在；密钥脱敏；0 console error。
- 回归 16 项全 PASS（app/ui/editor-basics/text-edit/symmetry/shape-snap/guides/mask-compare/editor-ui/ux-p0/ai-provider/interaction 9/9/asset-batch/image-workshop/chat 单跑），0 console error；Edge 0、端口 0。
- 证据：asset-real-read 22,955ms real/L2=5/L4=4；qwen-real-e2e 21,337ms obs2 regions2 mock=false（mtime 未变）。

## T110 最终验收 GATE（目标清单 + 打包/本地启动 · 2026-11-07 20:30）

**结论：可交付（Deliverable），P0/P1/P2 = 0。** 20 项回归 + 5 模块单测 + 目标清单 18 项全 PASS；打包/本地启动核对通过；证据 mtime 未变、未新增付费调用；残留 0。

| 目标项 | 判定 | 关键证据 |
|---|---|---|
| SkillRuntime 5 paths + L6 skill | ✅ | skill-runtime-test 5 skills 全 ok |
| 素材真实重读 22.955s/L2=5/L4=4 | ✅ | asset-real-read（mtime 未变） |
| 批量 Mock 0 网络 | ✅ | `/api/ai/*` 0 次；mode=mock 3/3、failed=0 |
| AI 结果回库 provenance | ✅ | analysis{source:real,provider:qwen,…}+L6 critique |
| 编辑器调整/形状/填充 | ✅ | editor-ui L6 adjust_layer/shape_inserted |
| 文字二次编辑 persist/undo | ✅ | text-edit：meta load 恢复、text_edited=1、undo diff=0 |
| resize/crop（mask/text meta/4096） | ✅ | canvas-resize PASS；16×16、4096²、mask 保留 |
| 网格/三分线/自定义参考线/对称/光标 | ✅ | guides customOnly snap 333/222；symmetry undoDelta=1；光标 alpha=432 |
| mask outsideDiff=0 + 对比滑杆 | ✅ | outsideDiff=0、clip 70%、mask_policy=selection_alpha |
| 真实 Qwen/手动确认/Mock 离线 | ✅ | ai-provider 16/16 |
| 证据链 buildEvidence/verify | ✅ | appEvidence events=12/head 7698a523d4ee/hasPng；e2e evidence 12/12 |
| UI 1366/变换退出/AI 关闭 | ✅ | ux-p0：lastRight 503<docLeft 632、Esc、AI 关闭 |
| UI toast/hint 分层 | ✅ | toast 654–694 vs hint 694–730 无重叠 |
| UI guide modal 可操作 | ✅ | add/clear、count 2→0 |
| serve 健康 200 | ✅ | 4200 `{ok:true,port:4200}`；app 页 200 |
| start.bat 路径/端口/自动打开 | ✅ | 静态 7/7 通过 |
| 密钥/残留 | ✅ | 无泄漏；Edge 0、端口 0 |
| 不新增付费调用 | ✅ | 证据 mtime 未变（17:12 / 16:53） |

- **P2-1（已修复复核）**：自定义参考线单独启用不吸附 → Lead 已修 `snapDocPoint` 早退条件；test-guides `customOnly` PASS，QA 独立探针 7/7 PASS（仅自定义 X=333/Y=222 时 snap (330,219)→(333,222)；导出 diff=0、undo 0→0、doc/evidence 无 guide；清空后回退 raw）。
- 提示（不阻塞）：`.runtime-port` 被任意 serve 实例覆写（QA 测试曾写 8162）；已恢复 4200，start.bat 启动前会重写。

## T111 最终独立 QA（AI 面板收口 + 长对话记忆 + 首屏 quickstart · 2026-11-07 21:0x）

**结论：可交付（Deliverable），P0/P1/P2 = 0（附 1 条流程提示）。** 2 新测试 + 14 回归全 PASS、0 console error；18 项独立焦点核验全 PASS；证据 mtime 未变、无付费调用、残留 0。

- AI 面板：3 primary tabs 观察/生成/记录；pinned 含 模型·选区·档案·素材·成本（¥0·不联网），滚动前后 pinned rect 140–175 不变（位于滚动区外 flex:0 0 auto）；记录子页 档案/证据 切换正常；模型 badge 打开模型面板且可回观察。
- 长对话：payload 反证含 选区 300×200/素材库 3 张/档案/画像「冷灰蓝、留白、颗粒」/images；L6 chat 记录 context_flags 全 true、images=2；真实 provider 代码 `slice(-30)` + 消息 `slice(0,4000)`；localStorage chat/profile 持久化；reload 保留；清空对话后 chat LS 删除、画像保留；4 个上下文 chips。
- 首屏：quickstart 空画布+未 dismissed 显示「从这里开始」+2 动作；draw/example 均隐藏并记忆 dismissed；reload 不再出现；底栏 statusContext 层名·工具·Mock·协作 并随工具更新；AI 面板含 成本/上下文。
- 回归：app/ui/library/image-workshop/multimodal/ux-p0/canvas-resize/text-edit/mask-compare/editor-ui/ai-provider/interaction 9/9/asset-batch/chat（单跑），全 PASS、0 error。
- 密钥 DOM/LS/SS/已加载 JS 无泄漏；Edge 0、端口 0；`.runtime-port` 恢复 4200、serve 4200 健康 200。
- 提示（不阻塞）：`.runtime-port` 会被其它 serve 实例覆写（本轮再次出现 8162，已恢复 4200）；MockProvider 本地路径未截断 history（真实 provider 已截断，无成本风险）。

## T112 最终独立 QA（对话行动/画像建议/安全加固 · 2026-11-07 21:3x）

**结论：可交付（Deliverable），P0/P1/P2 = 0。** 新测试+关联测试+13 回归共 17/17 PASS、0 console error；chat-actions 单测 11/11；19 项独立焦点核验全 PASS；无付费调用、残留 0。

- 代理 413 预算（本地 token，未触上游）：>30 messages / >60,000 字符 / >2 图均 **413 budget**；控制请求 200 mock。
- actions 安全：未知类型/脚本 URL/非白名单参数/null 全部拒绝；normalize 输出 0、无 proto 污染；执行面仅导航/prefill（chat/records 不变、/api/ai 0 次）；**reference 不自动加入**（仅定位+提示确认）。
- 画像：建议「建议·尚未写入」→「采用建议写入画像」持久化；画像 chip 默认开、关闭后 context_flags.profile=false 且回复不含画像；清空 AI 记忆删 chat+profile LS、素材/档案保留；清空对话**二次确认**且画像保留。
- 状态/语义：完成后 aiBusy=false、aiStatus=回答完成、取消按钮 hidden；chips 12px +「建议·不会自动执行」+「→类型」；最新消息可见；composer sticky；pinned「素材库/引用/档案」+¥0·不联网；context 无 sha256；密钥无泄漏；0 console error。
- 回归 13 项全 PASS（含 chat/interaction 单跑、ai-provider、asset-batch）；证据 mtime 未变（asset-real-read 22,955ms/L2=5/L4=4；qwen-e2e 21,337ms）→ 无付费调用；Edge 0、端口 0；.runtime-port=4200、serve 健康 200。
- 说明：上一版 focus 的 3 项 false 均为探针口径问题（L6 异步基线/画像 LS 被前一用例清空/不可滚动日志），已修正并重跑 19/19 PASS。

## T113 最终独立 QA（素材批量重读 review 闭环 · 2026-11-07 22:0x）

**结论：可交付（Deliverable），P0/P1/P2 = 0。** 新测试 + 单测 11/11 + 8 项回归全 PASS、0 console error；独立焦点核验 14/14 + keepAll 修复复核 5/5 全 PASS；无付费调用、残留 0。

- preflight 不发请求（0 次 /api/ai、items 全 planned、仅开始按钮）；Mock 全程 0 网络；L6 `asset_batch_decompose{mode:mock,total:3,done:3,failed:0,skill:asset.decompose}` 与 UI 一致。
- 按钮显隐（运行中开始 hidden/停止可见；完成后停止 hidden、全部按钮可见）；**真实模式 confirm→取消 0 请求/0 记录**（4200 config real，取消「不发送」）。
- keep 恢复 before（变异 L1/tags/palette/source 后运行覆盖 → keep 完全恢复）；adopt 保持新结果；retry 单跑不新增 L6；stop 剩余（done=2/total=3、停止 hidden）；L5 决策不被覆盖；关闭后可重开。
- **Lead keepAll 修复复核 5/5**：adoptAll→keepAll 后 adopted 全部转 kept 且逐项 L1/tags 精确恢复 before；按钮显隐正确；不新增记录；重开新 plan 全 planned。
- 回归：library/library-ai/app/ui/ux-p0/chat-actions/ai-provider/interaction（单跑 9/9）全 PASS。
- 证据 mtime 未变（asset-real-read 22,955ms/L2=5/L4=4；qwen-e2e 21,337ms）→ 无付费调用；密钥无泄漏；Edge 0、端口 0；.runtime-port=4200 健康 200。

## T114 最终独立 QA（更多菜单 4 组 + 首屏状态 · 2026-11-07 22:0x）

**结论：可交付（Deliverable），P0/P1 = 0；P2 = 1（test-ui 既有字号检验口径，非本轮回归）。** 新测试 + 9 项回归全 PASS、0 console error；10 项独立焦点核验全 PASS；无付费调用、残留 0。

- 菜单：4 组顺序「文件 / AI 与图像 / 视图与画布 / 项目」；2 列 grid；宽 **440**、高 **600**、bottom 650 < 768，1366/1920 均无横向滚动/溢出。
- 命中：展开折叠后 **20/20** 按钮 `elementFromPoint` 命中（含 history undo/redo）；效果点击：图像调整、画布尺寸（标题正确）、裁剪（标题「裁剪画布」）、网格/三分线 toggle、自定义参考线弹窗、设置/关于、AI 模型接入（定位 `#aiAccessCard`）全部正常。
- 历史/快捷键：默认折叠、展开后 `#historyList` 渲染；undo steps 1→0、redo 0→1；projectStatus 显示「已自动保存 … v2 gzip 11 KB」；快捷键含 Ctrl+Z。
- quickstart 仍 2 动作；statusContext「图层 2 · 画笔 · Mock · 协作」；密钥无泄漏；0 console error。
- 回归：test-more-menu/test-ui/test-ux-p0/test-app/test-editor-basics/test-guides/test-canvas-resize/test-quickstart-context/test-library 全 PASS。
- P2（既有口径）：test-ui `popoverFont12=false` 测的是浮层根字号 11px；菜单按钮实际 12px，非 T114 回归（owner demo-builder 可调整断言）。
- 证据 mtime 未变（asset-real-read 22,955ms/L2=5/L4=4；qwen-e2e 21,337ms）→ 无付费调用；Edge 0、端口 0；.runtime-port=4200 健康 200。

## T115 最终独立 QA（非破坏调整层 · 2026-11-07 22:1x）

**结论：可交付（Deliverable），P0/P1/P2 = 0。** 新测试 + 8 项回归全 PASS、0 console error；12 项独立焦点核验全 PASS；无付费调用、残留 0。

- 调整层：layers 2→3、`kind=adjust`、adjust 参数、`meta.adjustSource{sourceLayerId,bounds}`、L6 `create non_destructive=true`；图层面板「调整」badge。
- **源层像素不变**：源层 dataURL 创建前后完全一致；隐藏调整层合成 diff=**0**；取消 modal 后层数/参数/源层均不变。
- **同层更新**：重开预填 22→35，层数 3 不变、层 id 不变、**像素 diff=2,837**、L6 create+update（non_destructive）；undo 成功（像素可撤销；参数 meta 不入 undo，符合已知限制）。
- reload：`serializeDoc→loadProjectText` 后 layers=3、kind/adjust/meta 保留；保存 **27,039B**、PSD **278,490B head 8BPS**、重载正常；删除源层后应用 → toast「调整层的源图层已被删除，无法重算参数」、不崩、不加层。
- 回归：editor-ui/app/ui/canvas-resize/text-edit/library/chat-actions/ai-provider 全 PASS。
- 密钥无泄漏；0 console error；证据 mtime 未变（asset-real-read 22,955ms/L2=5/L4=4；qwen-e2e 21,337ms）→ 无付费调用；Edge 0、端口 0；.runtime-port=4200 健康 200。
- 已知限制（记录不阻塞）：方案 B 快照语义（源层后续改动不自动更新）；adjust 参数 meta 不进入 undo。

## T116 最终独立 QA（结构化文字层 + 原子 undo · 2026-11-07 22:5x）

**结论：可交付（Deliverable），P0/P1/P2 = 0。** 9 项测试全 PASS、0 console error；12 项独立焦点核验全 PASS；QA 首轮发现的 P1/P2 已由 Lead 修复并独立复核；无付费调用、残留 0。

- 文字层：`kind='text'`+`layer.text{content,fontSize,color,fontFamily,x,y,w,h}`、图层面板「文字」badge、新写入**不再产生 meta.text**；双击预填、编辑后像素 diff=14,649、state 同步。
- **键盘 Ctrl+Z/Ctrl+Y 原子性（P1 修复复核）**：undo 后 `engine.text=state.textLayers=初始文字` 且像素 diff=0；redo 后两者=修改后、diff=0；test-text-edit 已加入该断言。
- 旧档仅 `meta.text` fallback：加载后 textLayers=1、内容/预填「旧档文字」；保存/加载/再编辑正常（kind/text 保留）。
- 调整层 update 原子 undo/redo：0.22→0.35，undo→0.22（像素 diff=2,407）、redo→0.35，create 路径不受影响。
- **replaceLayerFromDataUrl 委托（P2 修复复核）**：独立干净页 ok=true、steps 1→2、kind=raster、无抛错、0 console error。
- L6：text_inserted/text_edited/adjust_layer 共 4 条，schema bad=0；密钥无泄漏；回归 editor-ui/app/ui/canvas-resize/library/chat-actions/ai-provider 全 PASS。
- 证据 mtime 未变（asset-real-read 22,955ms/L2=5/L4=4；qwen-e2e 21,337ms）→ 无付费调用；Edge 0、端口 0（4200 服务当前停止；测试用独立 python 服务）。
- 说明：Brooks R1「调整服务抽取」列为下一轮，不阻塞。
