#!/usr/bin/env node
/**
 * 墨证 InkProof · 可复现黑客松提交包生成器
 * 纯 Node / 零依赖 / 幂等：先清空 submission/ 再按白名单重建。
 * 用法：node hackathon/package-submission.mjs
 *
 * 设计要点：
 *  - 只删除 项目根/submission，绝不触碰其它目录（输出路径做校验）。
 *  - 把 QA 脚本、测试结果 JSON、回归日志、彩排截图全部随包，使「证据可核对」。
 *  - mock 时代旧 PPT/PDF/py 只进 _archive_pitch_DEPRECATED/ 并附 DEPRECATED.md。
 *  - 复制完成后扫描明文密钥；命中即退出码 1，且只报文件名与行号、不打印值。
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url)); // .../hackathon
const ROOT = path.resolve(HERE, '..');                      // 项目根
const OUT = path.resolve(ROOT, 'submission');              // 输出目录

const line = (s = '') => console.log(s);
const MB = (n) => (n / 1024 / 1024).toFixed(2) + ' MB';

// ---------------------------------------------------------------- 路径安全校验
// 只允许清空「项目根/submission」，绝不删除其它任何东西。
const outRel = path.relative(ROOT, OUT).split(path.sep).join('/');
if (outRel !== 'submission') {
  line('[FATAL] 拒绝在预期位置之外操作输出目录：' + OUT + '（相对项目根 = ' + outRel + '，必须正好是 submission）');
  process.exit(1);
}
if (!fs.existsSync(path.join(ROOT, 'v2')) || !fs.existsSync(path.join(ROOT, 'hackathon'))) {
  line('[FATAL] 未在项目根找到 v2/ 或 hackathon/；请确认本脚本位于项目根的 hackathon/ 下。');
  process.exit(1);
}

// ---------------------------------------------------------------- 清空并重建
if (fs.existsSync(OUT)) fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });
line('[1/6] 已清空并重建：' + OUT);

const SKIPS = [];
function ensureDir(d) { fs.mkdirSync(d, { recursive: true }); }
function copyOne(srcRel, dstRel) {
  const src = path.join(ROOT, srcRel);
  if (!fs.existsSync(src) || !fs.statSync(src).isFile()) { SKIPS.push(srcRel); return false; }
  const dst = path.join(OUT, dstRel);
  ensureDir(path.dirname(dst));
  fs.copyFileSync(src, dst);
  return true;
}
// 只复制目录的「直接子文件」，不递归。
function copyTopLevelFiles(srcRel, dstRel, filter = () => true) {
  const src = path.join(ROOT, srcRel);
  if (!fs.existsSync(src)) { SKIPS.push(srcRel + '/'); return; }
  const dst = path.join(OUT, dstRel);
  ensureDir(dst);
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    if (!e.isFile()) continue;
    if (!filter(e.name)) continue;
    fs.copyFileSync(path.join(src, e.name), path.join(dst, e.name));
  }
}
const DEFAULT_EXCLUDE_DIRS = new Set(['node_modules', '.git', 'archive']);
// 递归复制目录；默认排除 node_modules/、archive 深层大目录与 *.log。
function copyTree(srcRel, dstRel, opts = {}) {
  const src = path.join(ROOT, srcRel);
  if (!fs.existsSync(src)) { SKIPS.push(srcRel + '/'); return; }
  const excludeDirs = opts.excludeDirs || DEFAULT_EXCLUDE_DIRS;
  const fileFilter = opts.fileFilter || ((name) => !name.toLowerCase().endsWith('.log'));
  const rec = (cur, curDst) => {
    ensureDir(curDst);
    for (const e of fs.readdirSync(cur, { withFileTypes: true })) {
      const s = path.join(cur, e.name);
      const d = path.join(curDst, e.name);
      if (e.isDirectory()) { if (!excludeDirs.has(e.name)) rec(s, d); }
      else if (e.isFile() && fileFilter(e.name)) fs.copyFileSync(s, d);
    }
  };
  rec(src, path.join(OUT, dstRel));
}

// ---------------------------------------------------------------- 复制：v2 运行时
// 顶层白名单文件（刻意不复制 v2/.ai-config.json / .ai-token / .runtime-port / diag-shot*.png）
for (const f of ['serve.mjs', 'start.bat', 'stop.bat', '_server.bat', 'diag.html']) copyOne('v2/' + f, 'v2/' + f);
// 完整运行时目录（engine 含 src/ vendor/ demo.html 及 THIRD_PARTY_NOTICES）
for (const d of ['engine', 'brushes', 'layers', 'selection', 'library', 'psd']) copyTree('v2/' + d, 'v2/' + d);
// qa 顶层 NOTICES（qa/tools 是顶层文件复制，不含此文件，单独带上）
copyOne('v2/qa/THIRD_PARTY_NOTICES.md', 'v2/qa/THIRD_PARTY_NOTICES.md');
// qa/tools：全部顶层 .mjs / *result*.json / T1xx-final-qa.md / 回归日志 / 报告（排除 *.log）
copyTopLevelFiles('v2/qa/tools', 'v2/qa/tools', (n) => !n.toLowerCase().endsWith('.log'));
// shots 大图只保留 t117 关键截图
const shotsSrc = path.join(ROOT, 'v2/qa/tools/shots');
if (fs.existsSync(shotsSrc)) {
  for (const n of fs.readdirSync(shotsSrc)) {
    if (n.toLowerCase().startsWith('t117-') && n.toLowerCase().endsWith('.png')) {
      copyOne('v2/qa/tools/shots/' + n, 'v2/qa/tools/shots/' + n);
    }
  }
}
// app：index.html + 全部 .mjs / .json（含 41 个 test-*.mjs 与对应 test-*-result.json）+ rehearsal-*.png
// 大量 ui-*.png 调试截图（约 61MB）不属于证据，不复制。
copyTopLevelFiles('v2/app', 'v2/app', (n) => {
  if (n.toLowerCase().endsWith('.log')) return false;
  if (n.toLowerCase().endsWith('.png')) return n.toLowerCase().startsWith('rehearsal-');
  return true;
});
for (const d of ['core', 'css', 'js', 'demo']) copyTree('v2/app/' + d, 'v2/app/' + d);
line('[2/6] v2 运行时与全部证据已复制');

// ---------------------------------------------------------------- 复制：hackathon
// 顶层所有 .md / .html（排除 SUBMISSION_* 模板）；随后用修正版覆盖 README.md
copyTopLevelFiles('hackathon', 'hackathon', (n) =>
  (n.toLowerCase().endsWith('.md') || n.toLowerCase().endsWith('.html')) && !n.startsWith('SUBMISSION_'));
for (const d of ['scripts', 'assets', 'demo']) copyTree('hackathon/' + d, 'hackathon/' + d);

// pitch 旧 PPT/PDF/py：不打进 hackathon/pitch/，整体归档到根级 _archive_pitch_DEPRECATED/ 并附说明
const ARCHIVE_DIR = '_archive_pitch_DEPRECATED';
copyTree('hackathon/pitch', ARCHIVE_DIR);
const DEPRECATED_TEXT = [
  '# DEPRECATED — mock 时代旧稿，非当前评审材料',
  '',
  '本目录原为 hackathon/pitch/，是 2026-11-06 mock 时代的旧路演材料，仅作历史存档，**请勿据此评审当前作品**。',
  '',
  '## 为何不可用',
  '',
  '- 墨证_InkProof.pptx / 墨证_InkProof.pdf / build_pptx.py 均为 11-06 旧稿，slide 内容命中「全部 mock」「100% 本地 mock」「3 分钟现场」「单文件」「无需服务器」，不含 Qwen / 路演模式 / 5 分钟展示；',
  '- 其产品描述与当前 v2（真实 Qwen 多模态、路演 6 拍、5 分钟展示 + 3 分钟问答、本地 Node 服务 + 断网降级演示）完全相反；',
  '- 旧稿成本数字（0.31–0.84 元）与当前口径也不一致。',
  '',
  '## 当前有效材料',
  '',
  '- 交付说明：包根 README.md；复现说明：VERIFY.md；',
  '- 路演脚本：hackathon/路演5分钟脚本.md；操作手册：hackathon/路演操作手册.md；',
  '- 断网降级演示：hackathon/demo/index.html。',
  '',
  '本目录由 hackathon/package-submission.mjs 归档生成，README「目录」段已如实标注。',
  '',
].join('\n');
fs.writeFileSync(path.join(OUT, ARCHIVE_DIR, 'DEPRECATED.md'), DEPRECATED_TEXT, 'utf8');
line('[3/6] hackathon 文档 / assets / demo 已复制；旧 pitch 已归入 ' + ARCHIVE_DIR);

// ---------------------------------------------------------------- 生成文件
copyOne('hackathon/SUBMISSION_README.md', 'README.md');
copyOne('hackathon/SUBMISSION_README.md', 'hackathon/README.md'); // 覆盖旧错误版，统一口径
copyOne('hackathon/SUBMISSION_VERIFY.md', 'VERIFY.md');
// 只读验证器随包：评委可在包内直接用 Node 复核提交包（VERIFY.md §2.7 引用了此路径）
copyOne('hackathon/verify-submission.mjs', 'hackathon/verify-submission.mjs');
copyOne('hackathon/LICENSE', 'LICENSE');
copyOne('CHANGELOG.md', 'CHANGELOG.md');

const GITIGNORE_TEXT = [
  '# 本地密钥 / token —— 绝不入库',
  'v2/.ai-config.json',
  'v2/.ai-token',
  '.ai-config.json',
  '.ai-token',
  '# 运行时产物',
  'v2/.runtime-port',
  '*.log',
  '# 大媒体 / 导出证据',
  '*.mp4',
  '*.webm',
  '# 依赖',
  'node_modules/',
  '**/node_modules/',
  '# mock 时代旧稿归档（非当前材料）',
  '_archive_pitch_DEPRECATED/',
  '',
].join('\n');
fs.writeFileSync(path.join(OUT, '.gitignore'), GITIGNORE_TEXT, 'utf8');

// THIRD_PARTY_NOTICES.md：扫描包内实际存在的 NOTICES 生成索引
function walkFiles(dir, cb) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walkFiles(p, cb);
    else if (e.isFile()) cb(p);
  }
}
const notices = [];
walkFiles(OUT, (p) => {
  if (path.basename(p) === 'THIRD_PARTY_NOTICES.md') notices.push(path.relative(OUT, p).split(path.sep).join('/'));
});
notices.sort();
const noticeRows = notices.map((f) => '| ' + f + ' | 见该文件 |').join('\n') || '| （无） | |';
const NOTICES_TEXT = [
  '# 第三方声明索引 · 墨证 InkProof',
  '',
  '本文件由 hackathon/package-submission.mjs 生成，汇总本包内实际存在的 THIRD_PARTY_NOTICES 文件。',
  '项目自身源码许可见 LICENSE（MIT）。',
  '',
  '## 关键组件许可速查',
  '',
  '| 组件 | 许可 | 声明位置 |',
  '|---|---|---|',
  '| CanvasKit / Skia（canvaskit-wasm 0.42.0） | BSD-3-Clause | v2/engine/vendor/THIRD_PARTY_NOTICES.md、v2/engine/vendor/LICENSE |',
  '| ag-psd（28.3.1，含 pako / base64-js） | MIT | v2/psd/THIRD_PARTY_NOTICES.md |',
  '| perfect-freehand（1.2.3） | MIT | v2/brushes/THIRD_PARTY_NOTICES.md |',
  '| Klecks（参考实现） | MIT | v2/engine/vendor/THIRD_PARTY_NOTICES.md、v2/qa/THIRD_PARTY_NOTICES.md |',
  '| playwright-core（仅 QA 测试期，不进产品运行时） | Apache-2.0 | v2/qa/THIRD_PARTY_NOTICES.md |',
  '',
  '> 注：旧版 README 曾把 CanvasKit 误写为 Apache-2.0，实际为 BSD-3-Clause（见 v2/engine/vendor/THIRD_PARTY_NOTICES.md 第 9 行）。',
  '> GPL 项目（Krita / Krita AI Diffusion / ComfyUI / Fooocus / GIMP）仅作交互与工作流参考，未复制代码。',
  '',
  '## 包内 NOTICES 文件清单（动态扫描，共 ' + notices.length + ' 处）',
  '',
  '| 路径 | 说明 |',
  '|---|---|',
  noticeRows,
  '',
].join('\n');
fs.writeFileSync(path.join(OUT, 'THIRD_PARTY_NOTICES.md'), NOTICES_TEXT, 'utf8');
line('[4/6] 已生成 README.md / VERIFY.md / LICENSE / .gitignore / THIRD_PARTY_NOTICES.md / CHANGELOG.md');

// ---------------------------------------------------------------- 密钥扫描
// 针对「值」而非「标识符」：只匹配带引号的字符串字面量赋值形态，且值看起来像真实凭证。
// 排除测试占位符（test/mock/dummy/...）与 process.env.* / 变量引用 / 拼接表达式，避免误报。
const SECRET_FILES = new Set(['.ai-config.json', '.ai-token']);
const TEXT_EXT = new Set(['.mjs', '.js', '.cjs', '.mts', '.cts', '.ts', '.json', '.md', '.txt', '.html', '.htm',
  '.css', '.bat', '.ps1', '.py', '.csv', '.yml', '.yaml', '.xml', '.sh', '.cfg', '.ini', '.toml', '.svg']);
const ASSIGN_VALUE = /(?:apiKey|secretKey|secretId)["']?\s*[:=]\s*(["'`])([A-Za-z0-9_\-.]{16,})\1/gi;
const BEARER_VALUE = /(?:Authorization|authorization)["']?\s*[:=]\s*(["'`])Bearer\s+([A-Za-z0-9_\-.]{16,})\1/gi;
const SK_LITERAL = /(["'`])(sk-[A-Za-z0-9_\-]{16,})\1/gi;
// 公开的测试假密钥占位符（如 sk-test-... / sk-local-... / sk-upstream-...，QA 脚本里给本地 mock upstream 用），
// 以及拼接表达式/变量引用/空值，均不算「明文凭证」。真实凭证通常是 sk- + 长随机串且不含这些语义词。
const PLACEHOLDER = /test|mock|dummy|example|placeholder|sample|fake|never|frontend|local|secret|upstream|demo|adversarial|probe|stub|sandbox|t\d+-test|your[_-]?key|xxxx|replace|insert|<|\.\.\./i;

function scanSecrets() {
  const files = [];
  walkFiles(OUT, (p) => files.push(p));
  const hits = [];
  for (const p of files) {
    const rel = path.relative(OUT, p).split(path.sep).join('/');
    const name = path.basename(p);
    if (SECRET_FILES.has(name)) { hits.push({ file: rel, line: 0, why: '密钥文件名' }); continue; }
    const ext = path.extname(p).toLowerCase();
    if (ext !== '' && !TEXT_EXT.has(ext)) continue; // 二进制跳过内容扫描
    let text;
    try { text = fs.readFileSync(p, 'utf8'); } catch { continue; }
    const lines = text.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      let m, found = false;
      ASSIGN_VALUE.lastIndex = 0;
      while ((m = ASSIGN_VALUE.exec(l)) !== null) { if (!PLACEHOLDER.test(m[2])) { found = true; break; } }
      if (!found) {
        BEARER_VALUE.lastIndex = 0;
        while ((m = BEARER_VALUE.exec(l)) !== null) { if (!PLACEHOLDER.test(m[2])) { found = true; break; } }
      }
      if (!found) {
        SK_LITERAL.lastIndex = 0;
        while ((m = SK_LITERAL.exec(l)) !== null) { if (!PLACEHOLDER.test(m[2])) { found = true; break; } }
      }
      if (found) hits.push({ file: rel, line: i + 1, why: '明文凭证' });
    }
  }
  return hits;
}

const secretHits = scanSecrets();
line('[5/6] 密钥扫描完成');
if (secretHits.length > 0) {
  line('');
  line('==================== 密钥扫描：FAIL ====================');
  line('发现 ' + secretHits.length + ' 处疑似明文密钥（仅列文件名与行号，绝不打印值）：');
  for (const h of secretHits) line('  - ' + h.file + ':' + h.line + '  [' + h.why + ']');
  line('打包中止：请先从工作区移除这些明文凭证，再重新运行本脚本。');
  line('=======================================================');
  process.exit(1);
}
line('      密钥扫描：0 命中（PASS）');

// ---------------------------------------------------------------- 统计 + 证据对照表
function collectRels() {
  const rels = [];
  walkFiles(OUT, (p) => rels.push(path.relative(OUT, p).split(path.sep).join('/')));
  return rels;
}
const rels = collectRels();
let totalSize = 0;
for (const r of rels) { try { totalSize += fs.statSync(path.join(OUT, r)).size; } catch { /* ignore */ } }
const qaToolsMjs = rels.filter((r) => /^v2\/qa\/tools\/[^/]+\.mjs$/.test(r)).length;
const appTestMjs = rels.filter((r) => /^v2\/app\/test-[^/]*\.mjs$/.test(r)).length;
const appTestSeries = rels.filter((r) => /^v2\/app\/test-/.test(r)).length;
const resultJson = rels.filter((r) => r.toLowerCase().endsWith('.json') && /result|evidence/i.test(r)).length;
const pngAll = rels.filter((r) => r.toLowerCase().endsWith('.png')).length;
const rehearsalPng = rels.filter((r) => /^v2\/app\/rehearsal-.*\.png$/.test(r)).length;
const t117Png = rels.filter((r) => /^v2\/qa\/tools\/shots\/t117-.*\.png$/.test(r)).length;

// 与 README「证据与复现」表一致的断言 → 证据文件对照
const CLAIMS = [
  ['路演 6 拍端到端脚本', 'v2/app/test-roadshow.mjs'],
  ['路演 6 拍端到端结果', 'v2/app/test-roadshow-result.json'],
  ['核心回归日志', 'v2/qa/tools/final-core-regression.txt'],
  ['扩展回归日志', 'v2/qa/tools/extended-regression.txt'],
  ['功能回归结果', 'v2/qa/tools/functional-regression.json'],
  ['功能回归报告', 'v2/qa/tools/functional-regression-report.md'],
  ['性能回归报告', 'v2/qa/tools/perf-regression-report.md'],
  ['真实 Qwen 调用证据', 'v2/qa/tools/qwen-real-evidence.json'],
  ['最终彩排结果', 'v2/qa/tools/rehearse-final-result.json'],
  ['真实路演彩排结果', 'v2/qa/tools/rehearse-roadshow-real-result.json'],
  ['证据包第三方复核集成结果', 'v2/qa/tools/verify-evidence-integration-results.json'],
  ['证据包复核器（零依赖）', 'v2/qa/tools/verify-evidence.mjs'],
  ['复核器自测结果', 'v2/qa/tools/verify-evidence-test-results.json'],
  ['录屏前自检脚本', 'v2/qa/tools/demo-preflight.mjs'],
  ['T117 收口 QA 记录', 'v2/qa/tools/T117-final-qa.md'],
  ['彩排截图 1', 'v2/app/rehearsal-1-brief.png'],
  ['彩排截图 2', 'v2/app/rehearsal-2-select.png'],
  ['彩排截图 3', 'v2/app/rehearsal-3-observe.png'],
  ['彩排截图 4', 'v2/app/rehearsal-4-decide.png'],
  ['彩排截图 5', 'v2/app/rehearsal-5-apply.png'],
  ['彩排截图 6', 'v2/app/rehearsal-6-evidence.png'],
  ['断网降级单文件演示', 'hackathon/demo/index.html'],
  ['CanvasKit 许可声明', 'v2/engine/vendor/THIRD_PARTY_NOTICES.md'],
  ['ag-psd 许可声明', 'v2/psd/THIRD_PARTY_NOTICES.md'],
  ['perfect-freehand 许可声明', 'v2/brushes/THIRD_PARTY_NOTICES.md'],
  ['QA 许可声明', 'v2/qa/THIRD_PARTY_NOTICES.md'],
  ['项目自身许可', 'LICENSE'],
  ['复现说明', 'VERIFY.md'],
  ['第三方许可索引', 'THIRD_PARTY_NOTICES.md'],
  ['变更日志', 'CHANGELOG.md'],
  ['路演截图（观察）', 'hackathon/assets/roadshow-observe.png'],
  ['路演截图（落层）', 'hackathon/assets/roadshow-apply.png'],
  ['路演截图（证据）', 'hackathon/assets/roadshow-evidence.png'],
];

// 额外：从生成的 README.md 提取所有包内路径引用（含图片链接），逐一核对存在性
function extractReadmeRefs(mdPath) {
  const text = fs.readFileSync(mdPath, 'utf8');
  const set = new Set();
  const re = /`([^`\n]+)`|\]\(([^)\s]+)\)/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    let t = (m[1] || m[2] || '').trim().replace(/[),.;：、]+$/, '');
    if (!t) continue;
    if (/\s/.test(t) || t.includes('\\') || t.includes('*') || t.startsWith('http') || t.startsWith('#')) continue;
    if (/\/\.[^/]+$/.test(t)) continue; // 隐藏运行时文件（v2/.runtime-port 等）不算证据引用
    if (!/^(?:v2\/|hackathon\/|scripts\/|assets\/|_archive_pitch_DEPRECATED|LICENSE|VERIFY\.md|CHANGELOG\.md|THIRD_PARTY_NOTICES\.md|README\.md|\.gitignore)/.test(t)) continue;
    set.add(t);
  }
  return [...set];
}
function refExists(t) {
  return fs.existsSync(path.join(OUT, t)) || fs.existsSync(path.join(OUT, 'hackathon', t));
}
const readmeRefs = extractReadmeRefs(path.join(OUT, 'README.md'));
const readmeMissing = readmeRefs.filter((t) => !refExists(t));

line('');
line('==================== 打包统计 ====================');
line('输出目录            : ' + OUT);
line('文件总数            : ' + rels.length);
line('总大小              : ' + MB(totalSize) + ' (' + totalSize + ' B)');
line('v2/qa/tools/*.mjs   : ' + qaToolsMjs + ' 个');
line('v2/app/test-*.mjs   : ' + appTestMjs + ' 个（test-* 系列共 ' + appTestSeries + ' 个文件：含 test-*-result.json）');
line('结果/证据 JSON       : ' + resultJson + ' 个');
line('截图 *.png          : ' + pngAll + ' 张（彩排 rehearsal ' + rehearsalPng + ' 张 / t117 ' + t117Png + ' 张）');
line('密钥扫描            : 0 命中（PASS）');
if (SKIPS.length) line('缺失而跳过的源路径  : ' + SKIPS.length + ' 个 ' + JSON.stringify(SKIPS.slice(0, 8)));
line('');
line('-------- README「已验证断言 → 证据文件」对照表 --------');
for (const [label, ref] of CLAIMS) {
  line((fs.existsSync(path.join(OUT, ref)) ? '[OK]   ' : '[MISS] ') + label + '  ->  ' + ref);
}
line('');
line('-------- README 内其它路径引用核对 --------');
line('提取到 ' + readmeRefs.length + ' 条包内路径引用；不存在 ' + readmeMissing.length + ' 条');
for (const t of readmeMissing) line('  [MISS] ' + t);
line('');
line('-------- 关键交付文件 --------');
for (const f of ['README.md', 'VERIFY.md', 'LICENSE', 'THIRD_PARTY_NOTICES.md', 'CHANGELOG.md', '.gitignore',
  'hackathon/demo/index.html', '_archive_pitch_DEPRECATED/DEPRECATED.md']) {
  line((fs.existsSync(path.join(OUT, f)) ? '[OK]   ' : '[MISS] ') + f);
}
line('=======================================================');
line('完成。退出码 0。可重复运行本脚本以同步产品代码修复（幂等）。');
