/**
 * v2/brushes/tools/smudge-perf.mjs · T69 涂抹暂存内存/延迟 A/B（headless 真实 GPU，不弹窗）
 * 对比：整画布暂存（T62）vs engine.snapshotRegion(bbox) 区域暂存（T63/T69），4096×4096 文档。
 * 产物：samples/smudge/perf.json
 * 运行（项目根目录，先 node v2/serve.mjs）：node v2/brushes/tools/smudge-perf.mjs
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
const OUT = path.join(ROOT, 'v2', 'brushes', 'samples', 'smudge');
fs.mkdirSync(OUT, { recursive: true });
const CDP_PORT = Number((process.argv.find((a) => a.startsWith('--cdp=')) || '').split('=')[1] || 9597);
const HEADLESS = !process.argv.includes('--headed');
function resolveBase() {
  if (process.env.INKPROOF_BASE) return process.env.INKPROOF_BASE;
  try {
    const port = fs.readFileSync(path.join(ROOT, 'v2', '.runtime-port'), 'utf8').trim();
    if (/^\d+$/.test(port)) return 'http://127.0.0.1:' + port;
  } catch (e) { /* ignore */ }
  return 'http://127.0.0.1:4200';
}
const URL_ARG = `${resolveBase()}/v2/brushes/tools/smudge-perf.html`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const EDGE = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
].find((p) => fs.existsSync(p));
let ws = null; let msgId = 0; const pending = new Map();
const send = (method, params = {}) => new Promise((resolve) => { const id = ++msgId; pending.set(id, resolve); ws.send(JSON.stringify({ id, method, params })); });
async function ev(expression, timeoutMs = 180000) {
  const r = await Promise.race([send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true }), sleep(timeoutMs).then(() => ({ __t: true }))]);
  if (r.__t) throw new Error('evaluate timeout');
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1500));
  return r.result?.result?.value;
}
const report = { schema: 'inkproof.smudge-perf.v1', headless: HEADLESS, ok: false };
const profile = path.join(os.tmpdir(), 'smudgeperf-' + Date.now());
const args = ['--remote-debugging-port=' + CDP_PORT, '--user-data-dir=' + profile, '--no-first-run', '--no-default-browser-check'];
if (HEADLESS) args.push('--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1400,1000');
else args.push('--window-size=1400,1000', '--window-position=-3000,-3000', '--start-minimized');
args.push(URL_ARG);
const browser = spawn(EDGE, args, { stdio: 'ignore' });
try {
  let target = null;
  for (let i = 0; i < 500 && !target; i += 1) {
    try { const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json(); target = list.find((t) => t.type === 'page' && /^https?:/.test(t.url)); } catch (e) { /* wait */ }
    if (!target) await sleep(150);
  }
  if (!target) throw new Error('no target');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { const r = pending.get(m.id); pending.delete(m.id); r(m); } };
  await send('Runtime.enable');
  const t0 = Date.now(); let ready = false;
  while (Date.now() - t0 < 180000) {
    const err = await ev('window.__SMUDGE_PERF_ERROR__ || null').catch(() => null);
    if (err) throw new Error('page error: ' + err);
    ready = await ev('!!window.__SMUDGE_PERF_READY__').catch(() => false);
    if (ready) break;
    await sleep(400);
  }
  if (!ready) throw new Error('smudge-perf not ready');
  report.perf = await ev('window.__runSmudgePerf__()');
  const region = report.perf.variants.find((v) => v.mode === 'region');
  const full = report.perf.variants.find((v) => v.mode === 'full');
  report.compare = {
    fullCanvasBytes: full && full.stageBytes,
    regionBytes: region && region.stageBytes,
    savedPct: full && region && full.stageBytes ? Math.round((1 - region.stageBytes / full.stageBytes) * 1000) / 10 : null,
    fullMedianMs: full && full.medianMs,
    regionMedianMs: region && region.medianMs,
    latencyPct: full && region && full.medianMs ? Math.round((region.medianMs / full.medianMs - 1) * 1000) / 10 : null,
    regionInitMs: region && region.stageInitMs, fullInitMs: full && full.stageInitMs,
    regionGrows: region && region.stageGrows,
  };
  report.ok = !!(region && full && region.stageBytes && full.stageBytes && region.medianMs && full.medianMs);
  console.log(JSON.stringify({ ok: report.ok, compare: report.compare, variants: report.perf.variants }, null, 2));
  fs.writeFileSync(path.join(OUT, 'perf.json'), JSON.stringify(report, null, 2));
} catch (e) {
  report.fatal = String(e && e.stack || e);
  console.log(JSON.stringify({ ok: false, fatal: report.fatal }, null, 2));
  try { fs.writeFileSync(path.join(OUT, 'perf.json'), JSON.stringify(report, null, 2)); } catch (err) { /* ignore */ }
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  try { browser.kill(); } catch (e) { /* ignore */ }
  await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  process.exit(report.ok ? 0 : 1);
}
