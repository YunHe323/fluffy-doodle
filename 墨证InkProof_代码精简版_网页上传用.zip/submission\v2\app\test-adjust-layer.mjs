// v2/app/test-adjust-layer.mjs —— 非破坏调整层：参数保存/重开/更新/持久化
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8171;
const out = { schema: 'mozheng.app.adjust-layer.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-adjust-layer-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  const box = await page.locator('#mainCanvas').boundingBox();
  await page.mouse.move(box.x + box.width * 0.4, box.y + box.height * 0.4);
  await page.mouse.down(); await page.mouse.move(box.x + box.width * 0.55, box.y + box.height * 0.55, { steps: 8 }); await page.mouse.up();
  await page.waitForTimeout(500);
  const before = await page.evaluate(() => ({ layers: window.__V2_APP__.engine.getLayers().length }));
  // 设置选区，测试“仅作用到当前选区”蒙版
  await page.evaluate(() => { window.__V2_APP__.state.selection = { x: 420, y: 300, width: 260, height: 200 }; });
  // create adjustment layer
  await page.click('#btnMore'); await page.waitForTimeout(200);
  await page.click('#btnAdjustLayer'); await page.waitForTimeout(300);
  out.cases.maskUi = await page.evaluate(() => ({ checked: document.getElementById('adjMaskSelection').checked, disabled: document.getElementById('adjMaskSelection').disabled, hint: (document.getElementById('adjMaskHint') || {}).textContent }));
  await page.evaluate(() => { document.getElementById('adjMaskSelection').checked = true; const set = (id, v) => { const e = document.getElementById(id); e.value = String(v); e.dispatchEvent(new Event('input', { bubbles: true })); }; set('adjBrightness', 22); set('adjContrast', 12); set('adjSaturation', 8); set('adjHue', 4); document.getElementById('btnAdjustApply').click(); });
  await page.waitForTimeout(1200);
  out.cases.create = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const layers = a.engine.getLayers();
    const l = layers[layers.length - 1];
    const recs = a.state.records.filter((r) => r.kind === 'adjust_layer').slice(-2).map((r) => ({ action: r.params && r.params.action, nd: r.params && r.params.non_destructive, source: r.params && r.params.source_layer_id, masked: r.params && r.params.masked }));
    return { layers: layers.length, id: l.id, kind: l.kind, adjust: l.adjust, meta: a.engine.getLayerMeta(l.id), maskExists: !!(l.mask && l.mask.exists), maskTiles: a.engine.maskStore.listTiles(l.id).length, recs };
  });
  // reopen and update params on same layer
  await page.click('#btnMore'); await page.waitForTimeout(200);
  await page.click('#btnAdjustLayer'); await page.waitForTimeout(300);
  out.cases.prefill = await page.evaluate(() => ({ brightness: (document.getElementById('adjBrightness') || {}).value, name: (document.getElementById('adjustLayerName') || {}).textContent }));
  await page.evaluate(() => { const e = document.getElementById('adjBrightness'); e.value = '35'; e.dispatchEvent(new Event('input', { bubbles: true })); document.getElementById('btnAdjustApply').click(); });
  await page.waitForTimeout(1200);
  out.cases.update = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const layers = a.engine.getLayers(); const l = layers[layers.length - 1];
    return { layers: layers.length, kind: l.kind, adjust: l.adjust, recs: a.state.records.filter((r) => r.kind === 'adjust_layer' && r.params && r.params.action === 'update').length, mask: !!l.mask };
  });
  // 参数与像素一起 undo / redo
  out.cases.undo = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    const get = () => { const ls = a.engine.getLayers(); const l = ls[ls.length - 1]; return { brightness: l.adjust && l.adjust.brightness, layers: ls.length, kind: l.kind }; };
    a.engine.undo(); await new Promise((r) => setTimeout(r, 200));
    const afterUndo = get();
    a.engine.redo(); await new Promise((r) => setTimeout(r, 200));
    return { afterUndo, afterRedo: get() };
  });
  // persistence
  out.cases.persist = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    const json = a.engine.serializeDoc();
    await a.t61.loadProjectText(json);
    await new Promise((r) => setTimeout(r, 600));
    const layers = a.engine.getLayers();
    const l = layers.find((x) => x.kind === 'adjust') || layers[layers.length - 1];
    return { layers: layers.length, kind: l.kind, adjust: l.adjust, maskExists: !!(l.mask && l.mask.exists), maskTiles: a.engine.maskStore.listTiles(l.id).length, hasAdjustInDoc: json.includes('"kind":"adjust"') && json.includes('"adjust"') };
  });
  out.cases.ok = out.cases.create.layers === before.layers + 1 && out.cases.create.kind === 'adjust' && out.cases.create.adjust && out.cases.create.adjust.brightness === 0.22 && out.cases.create.meta && out.cases.create.meta.adjustSource && out.cases.create.recs.some((r) => r.action === 'create' && r.nd === true);
  out.cases.maskOk = out.cases.maskUi.checked === false && out.cases.maskUi.disabled === false && /选框|区域/.test(out.cases.maskUi.hint) && out.cases.create.maskExists === true && out.cases.create.maskTiles > 0 && out.cases.create.recs.some((r) => r.action === 'create' && r.masked === true);
  out.cases.prefillOk = out.cases.prefill.brightness === '22' && /调整层/.test(out.cases.prefill.name);
  out.cases.updateOk = out.cases.update.layers === out.cases.create.layers && out.cases.update.kind === 'adjust' && out.cases.update.adjust && out.cases.update.adjust.brightness === 0.35 && out.cases.update.recs >= 1;
  out.cases.undoOk = out.cases.undo.afterUndo.brightness === 0.22 && out.cases.undo.afterRedo.brightness === 0.35;
  out.cases.persistOk = out.cases.persist.kind === 'adjust' && out.cases.persist.adjust && out.cases.persist.adjust.brightness === 0.35 && out.cases.persist.maskExists === true && out.cases.persist.maskTiles > 0 && out.cases.persist.hasAdjustInDoc;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.ok && out.cases.maskOk && out.cases.prefillOk && out.cases.updateOk && out.cases.undoOk && out.cases.persistOk && out.cases.noErrors;
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-adjust-layer-1920.png' });
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
