// product/test/hash-chain.test.mjs
import test from 'node:test';
import assert from 'node:assert/strict';

import {
  sha256Hex, canonicalJson, createEvent, buildChain, verifyChain,
  checkpointHash, headHash, GENESIS_HASH, CHAIN_VERSION,
} from '../core/hash-chain.mjs';

test('SHA-256 已知向量', async () => {
  assert.equal(
    await sha256Hex('abc'),
    'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad',
  );
  assert.equal(
    await sha256Hex(''),
    'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
  );
  const utf8 = await sha256Hex('袖口');
  assert.match(utf8, /^[0-9a-f]{64}$/);
  assert.notEqual(utf8, await sha256Hex('袖口 '));
});

test('canonicalJson：键排序、日期、拒绝非有限值', () => {
  assert.equal(canonicalJson({ b: 1, a: { d: 2, c: [3, 4] } }), '{"a":{"c":[3,4],"d":2},"b":1}');
  assert.equal(canonicalJson({ t: new Date('2026-11-06T00:00:00.000Z') }), '{"t":"2026-11-06T00:00:00.000Z"}');
  assert.throws(() => canonicalJson({ n: NaN }), /NaN/);
  assert.throws(() => canonicalJson(undefined), /undefined/);
  // 对象中的 undefined 键按 JSON 语义忽略（与 JSON.stringify 一致）
  assert.equal(canonicalJson({ a: 1, u: undefined }), '{"a":1}');
  // 键顺序不同 → 规范化一致
  assert.equal(canonicalJson({ x: 1, y: 2 }), canonicalJson({ y: 2, x: 1 }));
});

test('buildChain：创世 prev_hash + 递增 seq + 冻结事件', async () => {
  const events = await buildChain([
    { type: 'project.created', payload: { id: 'p_1' }, createdAt: '2026-11-06T18:00:00+08:00' },
    { type: 'asset.imported', payload: { id: 'a7' }, createdAt: '2026-11-06T18:01:00+08:00' },
    { type: 'archive.record.created', payload: { id: 'L1-a7' }, createdAt: '2026-11-06T18:02:00+08:00', aiRole: 'assistant' },
  ]);
  assert.equal(events.length, 3);
  assert.equal(events[0].prev_hash, GENESIS_HASH);
  assert.equal(events[0].seq, 1);
  assert.equal(events[1].seq, 2);
  assert.equal(events[1].prev_hash, events[0].hash);
  assert.equal(events[2].prev_hash, events[1].hash);
  assert.equal(events[0].chain_version, CHAIN_VERSION);
  assert.ok(Object.isFrozen(events[0]));

  const verdict = await verifyChain(events);
  assert.deepEqual(verdict, { ok: true, count: 3, lastHash: events[2].hash });
  assert.equal(headHash(events), events[2].hash);
});

test('createEvent：从 hash 字符串续接；空链头为 GENESIS', async () => {
  const first = await createEvent(null, { type: 'a', payload: {} });
  const second = await createEvent(first.hash, { type: 'b', payload: {} });
  assert.equal(second.prev_hash, first.hash);
  assert.equal(second.seq, 1);
  assert.equal(headHash([]), GENESIS_HASH);
  await assert.rejects(() => createEvent('not-a-hash', { type: 'x' }), /prev/);
});

test('篡改检测：改 payload / 改 hash / 断链 / 乱序 seq', async () => {
  const events = await buildChain([
    { type: 'e1', payload: { v: 1 }, createdAt: '2026-11-06T18:00:00+08:00' },
    { type: 'e2', payload: { v: 2 }, createdAt: '2026-11-06T18:01:00+08:00' },
    { type: 'e3', payload: { v: 3 }, createdAt: '2026-11-06T18:02:00+08:00' },
  ]);

  const tamperedPayload = events.map((e) => ({ ...e }));
  tamperedPayload[1].payload = { v: 999 };
  const r1 = await verifyChain(tamperedPayload);
  assert.equal(r1.ok, false);
  assert.equal(r1.index, 1);
  assert.equal(r1.reason, 'hash_mismatch');

  const tamperedHash = events.map((e) => ({ ...e }));
  tamperedHash[2].hash = 'f'.repeat(64);
  const r2 = await verifyChain(tamperedHash);
  assert.equal(r2.ok, false);
  assert.equal(r2.index, 2);

  const brokenLink = events.map((e) => ({ ...e }));
  brokenLink[2].prev_hash = '0'.repeat(64);
  const r3 = await verifyChain(brokenLink);
  assert.equal(r3.ok, false);
  assert.equal(r3.index, 2);
  assert.equal(r3.reason, 'prev_hash_mismatch');

  const reordered = [events[0], events[2], events[1]];
  const r4 = await verifyChain(reordered);
  assert.equal(r4.ok, false);
});

test('checkpoint 确定性：条数或链头变化则摘要变化', async () => {
  const events = await buildChain([
    { type: 'e1', payload: { v: 1 }, createdAt: '2026-11-06T18:00:00+08:00' },
    { type: 'e2', payload: { v: 2 }, createdAt: '2026-11-06T18:01:00+08:00' },
  ]);
  const c1 = await checkpointHash(events);
  const c2 = await checkpointHash(events);
  assert.equal(c1, c2);
  assert.match(c1, /^[0-9a-f]{64}$/);

  const c3 = await checkpointHash([events[0]]);
  assert.notEqual(c1, c3);

  const fromHash = await checkpointHash(events[1].hash);
  assert.equal(fromHash, await checkpointHash(events[1].hash));
});
