#!/usr/bin/env node
// v2/engine/test/present-stability.mjs —— T46 present 帧稳定回归（零依赖 CDP）
// 验证：
//  - 两笔 end 后 0/16/50/200ms 截图非空且稳定（不闪白/不残缺）
//  - undo 后 0/16/50/200ms 截图非空且稳定，且内容与「只画第一笔」参考帧一致
// 用法：node v2/engine/test/present-stability.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

async function evaluate(expression, awaitPromise = true) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise, returnByValue: true, timeout: 120000 });
  if (r.result && r.result.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 800));
  return r.result && r.result.result && r.result.result.value;
}

const rect = await evaluate(`(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const stage = document.getElementById('stage');
  stage.style.width = '800px';
  stage.style.height = '800px';
  await new Promise((r) => requestAnimationFrame(r));
  const r = stage.getBoundingClientRect();
  return { x: r.x, y: r.y, width: r.width, height: r.height, dpr: window.devicePixelRatio };
})()`);

async function capture() {
  const clip = { x: Math.max(0, Math.round(rect.x)), y: Math.max(0, Math.round(rect.y)), width: Math.round(rect.width), height: Math.round(rect.height), scale: 1 };
  const shot = await send('Page.captureScreenshot', { format: 'png', clip, captureBeyondViewport: false });
  const dataUrl = 'data:image/png;base64,' + shot.result.data;
  return evaluate(`(async (dataUrl) => {
    const img = new Image(); img.src = dataUrl; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    const G = 8;
    const grid = new Array(G * G).fill(0);
    let total = 0;
    for (let y = 0; y < c.height; y += 1) {
      for (let x = 0; x < c.width; x += 1) {
        const i = (y * c.width + x) * 4;
        if (d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220) {
          total += 1;
          const gx = Math.min(G - 1, Math.floor(x / c.width * G));
          const gy = Math.min(G - 1, Math.floor(y / c.height * G));
          grid[gy * G + gx] += 1;
        }
      }
    }
    return { w: c.width, h: c.height, total, grid };
  })(${JSON.stringify(dataUrl)})`);
}

async function series(delays = [0, 16, 50, 200]) {
  const out = [];
  for (const delay of delays) {
    if (delay > 0) await new Promise((r) => setTimeout(r, delay));
    const s = await capture();
    s.t = delay;
    out.push(s);
  }
  return out;
}

function stable(list) {
  const totals = list.map((s) => s.total);
  const min = Math.min(...totals), max = Math.max(...totals);
  return { stable: min > 0 && (max - min) <= Math.max(4, max * 0.03), min, max, totals };
}

function gridDiff(a, b) {
  const sum = a.reduce((s, v) => s + v, 0) + b.reduce((s, v) => s + v, 0);
  if (!sum) return 0;
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) diff += Math.abs(a[i] - b[i]);
  return diff / sum;
}

const drawStroke = (y) => evaluate(`(async () => {
  const eng = window.__V2__;
  const y = ${y};
  eng.beginStroke({ x: 300, y, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
  for (let i = 0; i < 30; i += 1) eng.appendPoint({ x: 300 + i * 13, y: y + Math.sin(i / 5) * 8, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
  eng.endStroke();
  await new Promise((r) => requestAnimationFrame(r));
  return true;
})()`);

// 0) 空白基线（画布边框/页面背景的固定像素，用于空白判定）
const baseline = await series([100]);
const baselineSample = baseline[0];

// 1) 第一笔（参考帧）
await drawStroke(400);
const ref1 = await series([200]);
const ref1Sample = ref1[0];

// 2) 第二笔，end 后帧稳定
await drawStroke(800);
const afterEnd = await series([0, 16, 50, 200]);
const endStable = stable(afterEnd);
const endNonBlank = afterEnd.every((s) => s.total > 100);
const endMoreThanRef = afterEnd.every((s) => s.total > ref1Sample.total * 1.2);

// 3) undo 第二笔，帧稳定 + 与参考帧一致
await evaluate(`(async () => { window.__V2__.undo(); await new Promise((r) => requestAnimationFrame(r)); return true; })()`);
const afterUndo = await series([0, 16, 50, 200]);
const undoStable = stable(afterUndo);
const undoNonBlank = afterUndo.every((s) => s.total > 100);
const undoMatchesRef = afterUndo.map((s) => gridDiff(s.grid, ref1Sample.grid));
const undoOk = undoMatchesRef.every((d) => d < 0.06) && afterUndo.every((s) => Math.abs(s.total - ref1Sample.total) <= Math.max(20, ref1Sample.total * 0.03));

// 4) 再 undo 第一笔 → 接近空白
await evaluate(`(async () => { window.__V2__.undo(); await new Promise((r) => requestAnimationFrame(r)); return true; })()`);
const afterUndoAll = await series([200]);

const checks = {
  afterEndNonBlank: endNonBlank,
  afterEndStable: endStable.stable,
  afterEndComplete: endMoreThanRef,
  afterUndoNonBlank: undoNonBlank,
  afterUndoStable: undoStable.stable,
  afterUndoMatchesRef: undoOk,
  afterUndoAllBlankish: Math.abs(afterUndoAll[0].total - baselineSample.total) <= Math.max(20, baselineSample.total * 0.03)
    && gridDiff(afterUndoAll[0].grid, baselineSample.grid) < 0.03,
};
const ok = Object.values(checks).every(Boolean);
const result = { ok, checks, baseline: baselineSample, ref1: ref1Sample, afterEnd, afterUndo, undoMatchesRef, afterUndoAll: afterUndoAll[0], environment: { dpr: rect.dpr, clip: rect } };
console.log(JSON.stringify({ ok, checks, analysis: { baselineTotal: baselineSample.total, ref1Total: ref1Sample.total, afterEndTotals: afterEnd.map((s) => s.total), afterUndoTotals: afterUndo.map((s) => s.total), undoMatchesRef, afterUndoAllTotal: afterUndoAll[0].total } }, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(result, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(ok ? 0 : 1);
