// v2/app/test-ux-p0.mjs —— 1366 顶栏不重叠 / 变换退出 / AI 面板关闭
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8160;
const out = { schema: 'mozheng.app.ux-p0.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-ux-p0-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  out.cases.topbar = await page.evaluate(() => {
    const tools = [...document.querySelectorAll('.pro-topbar .pro-tools')];
    const doc = document.querySelector('.pro-topbar .pro-doc');
    const last = tools[tools.length - 1];
    const tr = last.getBoundingClientRect(), dr = doc ? doc.getBoundingClientRect() : null;
    return { lastRight: Math.round(tr.right), docLeft: dr ? Math.round(dr.left) : null, overlap: !!(dr && tr.right > dr.left), width: innerWidth };
  });
  await page.evaluate(() => { const a = window.__V2_APP__; a.setTool('transform'); });
  await page.waitForTimeout(200);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(250);
  out.cases.esc = await page.evaluate(() => ({ tool: window.__V2_APP__.state.tool, transformActive: !!window.__V2_APP__.state.transformActive, optionsHidden: document.getElementById('toolOptions').hidden, optionsDisplay: getComputedStyle(document.getElementById('toolOptions')).display }));
  await page.evaluate(() => { const a = window.__V2_APP__; a.setTool('transform'); a.openPopover('popAI'); });
  await page.waitForTimeout(300);
  out.cases.openAi = await page.evaluate(() => ({ tool: window.__V2_APP__.state.tool, transformActive: !!window.__V2_APP__.state.transformActive, optionsHidden: document.getElementById('toolOptions').hidden, aiOpen: document.getElementById('popAI').classList.contains('open'), closeBtn: !!document.getElementById('btnAiClose') }));
  const beforeClose = await page.evaluate(() => document.getElementById('popAI').classList.contains('open'));
  await page.click('#btnAiClose');
  await page.waitForTimeout(200);
  out.cases.close = { before: beforeClose, after: await page.evaluate(() => document.getElementById('popAI').classList.contains('open')) };
  out.cases.topbarOk = !out.cases.topbar.overlap;
  out.cases.escOk = out.cases.esc.tool === 'brush' && !out.cases.esc.transformActive && out.cases.esc.optionsHidden;
  out.cases.aiOk = out.cases.openAi.transformActive === false && out.cases.openAi.optionsHidden && out.cases.openAi.aiOpen && out.cases.openAi.closeBtn && out.cases.close.after === false;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.topbarOk && out.cases.escOk && out.cases.aiOk && out.cases.noErrors;
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-ux-p0-1366.png' });
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
