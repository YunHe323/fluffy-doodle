// bench/tools/memory-trace.mjs  (T38)
// 零依赖：本地起静态服务 + headless Chrome(硬件 GPU) + CDP tracing，跑 bench/p1p2.html?case=p1-4096
// 输出：bench/results/traces/p1-4096-memory.trace.json（原始 trace）
//       bench/results/memory-tracing.json（测量摘要，供 memory-tracing.md 引用）
// 用法：node bench/tools/memory-trace.mjs
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT_HTTP = 8096;
const PORT_CDP = 9401;
const OUT_TRACE = ROOT + '\\bench\\results\\traces\\p1-4096-memory.trace.json';
const OUT_JSON = ROOT + '\\bench\\results\\memory-tracing.json';
fs.mkdirSync(path.dirname(OUT_TRACE), { recursive: true });

const python = spawn('python', ['-m', 'http.server', String(PORT_HTTP), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
await sleep(1200);

const chromeProfile = path.join(os.tmpdir(), 'inkproof-t38-' + Date.now());
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--no-first-run', '--no-default-browser-check',
  '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist',
  '--force-device-scale-factor=1', '--window-size=1600,1000', '--hide-scrollbars',
  '--js-flags=--expose-gc',
  `--remote-debugging-port=${PORT_CDP}`, `--user-data-dir=${chromeProfile}`, 'about:blank'
], { stdio: 'ignore' });

let target = null;
for (let i = 0; i < 200 && !target; i++) {
  try {
    const r = await fetch(`http://127.0.0.1:${PORT_CDP}/json/list`);
    target = (await r.json()).find((t) => t.type === 'page');
  } catch (e) { /* retry */ }
  if (!target) await sleep(150);
}
if (!target) { console.log('FATAL no target'); process.exit(1); }
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map(); const consoleErrors = [];
const traceChunks = [];
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); return; }
  if (m.method === 'Runtime.exceptionThrown') consoleErrors.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text);
  if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') consoleErrors.push(m.params.args.map((a) => a.value || a.description).join(' '));
  if (m.method === 'Tracing.dataCollected' && m.params.value) traceChunks.push(...m.params.value);
  if (m.method === 'Tracing.tracingComplete') traceChunks.push({ __tracingComplete: true, dataLossOccurred: m.params.dataLossOccurred });
};
const send = (method, params = {}) => new Promise((resolve) => { const i = ++id; pending.set(i, resolve); ws.send(JSON.stringify({ id: i, method, params })); });
async function evaljs(expression) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true });
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1200));
  return r.result?.result?.value;
}

const summary = { schema: 'mozheng.memory-tracing.v1', createdAt: new Date().toISOString(), task: 'T38', scenario: 'CanvasKit 4096²×8 全满（bench/p1p2.html?case=p1-4096）' };
try {
  await send('Runtime.enable'); await send('Page.enable'); await send('Performance.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: 1600, height: 1000, deviceScaleFactor: 1, mobile: false });
  await send('Tracing.start', {
    categories: 'devtools.timeline,disabled-by-default-memory-infra,v8,blink,cc',
    options: 'record-as-much-as-possible',
    transferMode: 'ReportEvents'
  });
  const t0 = Date.now();
  await send('Page.navigate', { url: `http://127.0.0.1:${PORT_HTTP}/bench/p1p2.html?case=p1-4096` });
  let result = null;
  for (let i = 0; i < 600; i++) {
    result = await evaljs('window.__P1P2_RESULT__ || null').catch(() => null);
    if (result) break;
    const err = await evaljs('window.__P1P2_ERROR__ || null').catch(() => null);
    if (err) throw new Error('p1p2 error: ' + err);
    if (Date.now() - t0 > 240000) throw new Error('timeout waiting P1P2 result');
    await sleep(300);
  }
  await sleep(2500); // 稳定态
  const perfMetrics = (await send('Performance.getMetrics')).result?.metrics || [];
  const memSnap = await evaljs(`({ usedJSHeapSize: performance.memory ? performance.memory.usedJSHeapSize : null, totalJSHeapSize: performance.memory ? performance.memory.totalJSHeapSize : null, jsHeapSizeLimit: performance.memory ? performance.memory.jsHeapSizeLimit : null, gpu: (() => { const c=document.createElement('canvas'); const gl=c.getContext('webgl2'); if(!gl) return null; const e=gl.getExtension('WEBGL_debug_renderer_info'); return e? gl.getParameter(e.UNMASKED_RENDERER_WEBGL): gl.getParameter(gl.RENDERER); })() })`);
  await send('Tracing.end');
  for (let i = 0; i < 100 && !traceChunks.some((e) => e.__tracingComplete); i++) await sleep(200);

  const case4096 = (result.cases || []).find((c) => c.id && String(c.id).includes('4096'));
  const w = 4096, h = 4096, layers = 8;
  const layerBytes = w * h * 4 * layers;
  const surfaceBytes = w * h * 4;
  const estTotalMB = case4096?.summary?.estTotalMemMB ?? null;
  const wasmHeapMB = estTotalMB != null ? +(estTotalMB - layerBytes / 1048576 - surfaceBytes / 1048576).toFixed(1) : null;
  // trace 派生：UpdateCounters 的 JS heap 峰值 / memory dump 数量
  let traceJsHeapPeakMB = 0; let memDumpCount = 0;
  for (const e of traceChunks) {
    if (!e || typeof e !== 'object') continue;
    if (e.name === 'UpdateCounters' && e.args && e.args.data) {
      const used = e.args.data.jsHeapSizeUsed;
      if (typeof used === 'number' && used / 1048576 > traceJsHeapPeakMB) traceJsHeapPeakMB = used / 1048576;
    }
    if ((e.name === 'periodic_interval' || e.name === 'MemoryDump') && e.args && e.args.dumps) memDumpCount += e.args.dumps.length;
  }
  const traceClean = traceChunks.filter((e) => !e.__tracingComplete);
  fs.writeFileSync(OUT_TRACE, JSON.stringify({ traceEvents: traceClean }), 'utf8');
  const traceSizeMB = +(fs.statSync(OUT_TRACE).size / 1048576).toFixed(2);

  summary.result = {
    case: case4096 ? { id: case4096.id, summary: case4096.summary, passes: case4096.pass, config: case4096.config } : null,
    pageReported: result,
    stableState: {
      performanceMemory: memSnap,
      cdpMetrics: Object.fromEntries(perfMetrics.filter((m) => /JSHeap|Nodes|Documents/.test(m.name)).map((m) => [m.name, m.value])),
      traceJsHeapPeakMB: +traceJsHeapPeakMB.toFixed(1),
      memDumpCount
    },
    breakdown: {
      layerBytesMB: +(layerBytes / 1048576).toFixed(1),
      mainSurfaceMB: +(surfaceBytes / 1048576).toFixed(1),
      wasmHeapMBInferred: wasmHeapMB,
      estTotalMB,
      thresholdMB: 800,
      marginMB: estTotalMB != null ? +(800 - estTotalMB).toFixed(1) : null,
      formula: 'layerBytes=w*h*4*layers；mainSurface=w*h*4；wasmHeap=estTotal-layer-mainSurface（由页面 estTotal 反推）'
    },
    trace: { file: 'bench/results/traces/p1-4096-memory.trace.json', events: traceClean.length, sizeMB: traceSizeMB, categories: 'devtools.timeline,disabled-by-default-memory-infra,v8,blink,cc' },
    environment: { gpu: memSnap.gpu, headless: true, pointer: 'none（load-only）', note: 'headless=new + --use-angle=d3d11 硬件 GPU；无手绘板' },
    consoleErrors
  };
  fs.writeFileSync(OUT_JSON, JSON.stringify(summary, null, 2), 'utf8');
  console.log(JSON.stringify(summary.result.breakdown, null, 2));
  console.log('trace:', OUT_TRACE, traceSizeMB + 'MB', traceClean.length, 'events');
  console.log('JS heap:', memSnap.usedJSHeapSize, 'tracePeakMB:', traceJsHeapPeakMB.toFixed(1));
  console.log('errors:', JSON.stringify(consoleErrors));
} catch (e) {
  summary.fatal = String(e.stack || e);
  try { await send('Tracing.end'); } catch (e2) { /* ignore */ }
  fs.writeFileSync(OUT_JSON, JSON.stringify(summary, null, 2), 'utf8');
  console.log('FATAL', e.stack || e);
} finally {
  try { ws.close(); } catch (e) { /* ignore */ }
  chrome.kill(); python.kill();
  await sleep(500);
  try { fs.rmSync(chromeProfile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  process.exit(0);
}
