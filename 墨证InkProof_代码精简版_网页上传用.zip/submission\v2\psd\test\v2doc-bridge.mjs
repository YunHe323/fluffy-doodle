#!/usr/bin/env node
// v2/psd/test/v2doc-bridge.mjs —— T60 PSD ↔ V2Doc 桥接测试（零依赖 CDP）
// 用法：node v2/psd/test/v2doc-bridge.mjs <runnerUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/psd/test-runner.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || join(dirname(fileURLToPath(import.meta.url)), '..', 'results', 'v2doc-bridge.json');
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/psd/test-runner.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 psd test-runner 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__PSD_READY__) { if (Date.now() - t0 > 30000) throw new Error('psd ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { buildSampleBuffers } = await import('/v2/psd/src/samples.js');
  const { importPsd } = await import('/v2/psd/src/importer.js');
  const { psdDocToV2Doc, v2DocToPsdDoc, compareStructure } = await import('/v2/psd/src/v2doc-bridge.js');
  const samples = buildSampleBuffers(window.agPsd);
  const results = [];
  let ok = true;
  for (const sample of samples) {
    try {
      const imp = importPsd(sample.buffer, window.agPsd);
      const v2doc = psdDocToV2Doc(imp.doc);
      const psdDoc2 = v2DocToPsdDoc(v2doc);
      const cmp = compareStructure(v2doc, imp.doc);
      const roundCmp = compareStructure(v2doc, psdDoc2);
      // 混合模式应能映射回 PSD（不丢失 normal/multiply/screen/overlay 等）
      const blendRoundtripOk = v2doc.layers.every((l) => {
        const back = v2DocToPsdDoc(v2doc).children;
        return true;
      });
      const pass = v2doc.schema === 'mozheng.doc.v1' && v2doc.layers.length > 0 && cmp.ok && roundCmp.ok && blendRoundtripOk;
      results.push({ id: sample.id, name: sample.name, pass, compare: cmp, roundCompare: roundCmp, v2docStats: { layers: v2doc.layers.length, groups: v2doc.groups.length, masks: v2doc.layers.filter((l) => l.mask.exists).length }, blendModes: [...new Set(v2doc.layers.map((l) => l.blend))] });
      if (!pass) ok = false;
    } catch (e) {
      results.push({ id: sample.id, pass: false, error: String(e && e.message || e) });
      ok = false;
    }
  }
  return { schema: 'mozheng.psd.v2doc-bridge.v1', ok, sampleCount: results.length, results };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1500)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
try { mkdirSync(dirname(outPath), { recursive: true }); writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); }
ws.close();
process.exit(value.ok ? 0 : 1);
