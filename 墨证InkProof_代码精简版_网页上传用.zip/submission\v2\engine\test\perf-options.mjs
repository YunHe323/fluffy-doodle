#!/usr/bin/env node
// v2/engine/test/perf-options.mjs —— T66 测量：present 选项/内存（不改默认行为；仅创建临时 Engine）
// 用法：node v2/engine/test/perf-options.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const median = (a) => { const s = [...a].sort((x, y) => x - y); return s.length ? Math.round(s[Math.floor(s.length / 2)] * 100) / 100 : null; };
  const p95 = (a) => { const s = [...a].sort((x, y) => x - y); return s.length ? Math.round(s[Math.min(s.length - 1, Math.ceil(s.length * 0.95) - 1)] * 100) / 100 : null; };

  async function probe(width, opts) {
    const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = width;
    const eng = new Engine({ canvas, width, height: width, layers: 2, ...opts });
    await eng.init();
    eng.setBrush({ type: 'soft', sizePx: 64 });
    for (let s = 0; s < 3; s += 1) {
      const y = 100 + s * 120;
      eng.beginStroke({ x: 100, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
      for (let i = 1; i < 20; i += 1) eng.appendPoint({ x: 100 + i * 20, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
      eng.endStroke();
    }
    await raf(); await raf();
    const presentTimes = [];
    for (let i = 0; i < 5; i += 1) { const s = performance.now(); eng.presentFull(); presentTimes.push(performance.now() - s); await raf(); }
    const blitTimes = [];
    if (eng.presentSurface) {
      for (let i = 0; i < 5; i += 1) { const s = performance.now(); eng._blitRetained(); blitTimes.push(performance.now() - s); await raf(); }
    }
    const snapshotTimes = [];
    for (let i = 0; i < 2; i += 1) { const s = performance.now(); await eng.getCompositeDataUrl(); snapshotTimes.push(performance.now() - s); await raf(); }
    const serTimes = [];
    let jsonBytes = 0;
    for (let i = 0; i < 2; i += 1) { const s = performance.now(); jsonBytes = eng.serializeDoc().length; serTimes.push(performance.now() - s); }
    const stats = eng.getStats();
    eng.dispose();
    return {
      width,
      presentRetained: !!eng.presentRetained,
      presentSurfaceMB: stats.presentSurfaceMB,
      memoryEstimateMB: stats.memoryEstimateMB,
      tileCount: stats.tileCount,
      presentMs: { p50: median(presentTimes), p95: p95(presentTimes) },
      blitMs: blitTimes.length ? { p50: median(blitTimes), p95: p95(blitTimes) } : null,
      snapshotMs: { p50: median(snapshotTimes), p95: p95(snapshotTimes) },
      serializeMs: { p50: median(serTimes), p95: p95(serTimes) },
      serializeBytes: jsonBytes,
    };
  }

  const results = {};
  results.e2048 = await probe(2048, {});
  results.e4096retained = await probe(4096, { presentRetained: true });
  results.e4096auto = await probe(4096, {});
  results.e4096noRetained = await probe(4096, { presentRetained: false });
  return {
    schema: 'mozheng.perf-options.v1',
    generatedAt: new Date().toISOString(),
    env: { headless: /HeadlessChrome/.test(navigator.userAgent), browser: (navigator.userAgent.match(/Chrome\\/[\\d.]+/) || [])[0] || '' },
    results,
    notes: [
      'headless GPU 下 present 命令异步，ms 仅作相对比较；真实 Edge 全量合成 12.5ms@2048²（QA T46）',
      '4032/4096 内存按 T38 分项 704MiB + live 64MiB + present 64MiB 计算',
    ],
  };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 240000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1500)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(0);
