# 性能回归执行清单（M4.5 P0：T76 导出 Worker / T77 .mozheng gzip / T78 app 接入）

> 状态：**待命**（Lead 指示：等 T78 完成通知；期间不启动浏览器）。
> 执行人：qa-engineer｜前置：headless、独立端口 4260+/4310+、0 残留进程；覆盖前备份当前 `GATE-pw.md` 基线。

## 0. 接入点清单（T78 落地后先确认，再跑）

用只读方式确认以下 API/钩子（`page.evaluate` 探测 + 读代码）：

| 能力 | 预期来源 | 探测表达式（防御式） |
|---|---|---|
| 导出 PNG（2048²/4096²，Worker） | `t78.exportPng` 或 t61 | `window.__V2_APP__.t78?.exportPng \|\| window.__V2_APP__.t61?.exportPng` |
| 导出证据包 | `buildEvidence` / `t78.exportEvidence` | `typeof window.__V2_APP__.buildEvidence === 'function'` |
| 导出 PSD | `t61.psdExportBuffer` | 已有 |
| 导出取消/失败 | T76 cancel 钩子、worker 错误通道 | `t78.cancelExport` / `state.export?.jobId` |
| `.mozheng` v2（gzip）保存 | `t78.saveProjectBlob` / `t61.saveProjectText` | 返回 Blob/AbortSignal 支持 |
| `.mozheng` v1 打开 | `t61.loadProjectText`（v1 兼容） | 用归档 v1 文件 + `setInputFiles` |
| v2 回读 | `t61.loadProjectText` / `t78.loadProjectBlob` | 像素 diff 用 engine 合成图 |

若命名不同：以代码为准，记录在 `perf-regression.json.hooksFound`，**不改业务代码**。

## 1. 冒烟 + GATE（无回退确认）

```powershell
cd v2/qa
node tools/harness.mjs            # 三页冒烟 + 4 目标×3 轮
```

门槛：冒烟 3/3；GATE「全部闸门通过」；与 `archive/baseline-final/` 对比无新增 ❌。

## 2. 导出性能（T76 Worker 验证）

| 用例 | 画布 | 指标 |
|---|---|---|
| PNG 导出 | 2048²、4096² | 总耗时 ms、主线程 **long task（>50ms）次数/最长**、峰值内存（可选 `performance.memory`） |
| 证据包导出 | 1200×800 | 同上 + 包体积 |
| PSD 导出 | 1200×800 | 同上 + 文件体积 |
| 取消 | 4096² 导出中途 cancel | 取消生效时间、无残留 worker、无 console error |
| 失败注入 | 模拟 worker 不可用/抛错 | 页面可见错误提示（非静默失败）、可重试 |

判定：导出期间主线程长任务 **≤1 次且单次 ≤100ms**（Worker 生效的预期；具体阈值以 T76 规格为准），取消/失败均有可见反馈。
采集：`PerformanceObserver({entryTypes:['longtask']})` 在动作前注入，动作后取 `durationMs/count/longest`。

## 3. 保存性能（T77 gzip v2）

| 用例 | 指标 |
|---|---|
| `.mozheng` v2 保存（有内容文档） | 体积（v1 vs v2 压缩比）、保存耗时、主线程长任务 |
| `.mozheng` v1 文件打开 | 成功/失败、结构归一相等 |
| v2 保存→打开回读 | **结构归一相等 + 像素 diff=0**（硬门槛） |
| 大文档（多图层/组/蒙版） | 体积/耗时 |

## 4. 功能回归关键项抽测

- `.mozheng` 保存→刷新→打开（结构+像素 diff=0）
- 证据包导出（事件链头、refs 含 asset insert/ai_reference、zero_generation 语义）
- 素材库：插入图层（source=original-bitmap）+ AI 参考 chip
- 12 步演示主路径抽测

## 5. 产物与判定

| 产物 | 内容 |
|---|---|
| `tools/perf-regression.json` | 全量计时/长任务/体积/结构像素对比结果 |
| `tools/perf-regression-report.md` | 性能对比表（v1 vs v2、2048² vs 4096²、long task 统计） |
| `tools/GATE-pw.md` 增补 | 「M4.5 性能回归」章节 + 是否可验收结论 |
| `tools/archive/baseline-m45/` | 覆盖前备份（GATE/results/rounds/functional/perf） |

**判定**：冒烟 3/3 + GATE 无回退 + 导出 Worker 生效（长任务达标/取消失败有反馈）+ v2 回读像素 diff=0 + v1 可打开 + 功能抽测全过 = 可验收；任一 ❌ 列 owner（T76/T77 归 tech，T78 归 demo，worker/前端问题按证据归属）。
