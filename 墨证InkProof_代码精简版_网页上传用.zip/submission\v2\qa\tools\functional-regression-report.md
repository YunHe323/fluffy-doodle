﻿# 功能回归报告（T60–T65 后 · QA 独立 · Playwright-core headless）

> 生成：2026-11-07T04:48:31.391Z｜端口：http://127.0.0.1:4260｜headless=true｜控制台错误：0

| 用例 | 结果 | 关键证据 |
|---|---|---|
| F1 图层组/蒙版/剪贴/16 混合 | ✅ 通过 | {"groups":1,"blendOk":16,"blendTotal":16,"blendValue":"luminosity","clip":true,"mask":true,"grouped":true} |
| F2 .mozheng 保存→刷新→打开（结构+像素） | ✅ 通过 | {"structureEqual":true,"bytes":16921,"pixelDiff":{"changed":0,"total":960000,"ratio":0,"bbox":null},"hashBefore":"8ee75198796d16fd","hashAfter":"3255f5ed6092a768","structureDiffHint":null} |
| F3 自动保存→刷新恢复（结构+像素） | ✅ 通过 | {"structureEqual":true,"pixelDiff":{"changed":0,"total":960000,"ratio":0,"bbox":null},"layers":3,"groups":1} |
| F4 PSD 导出→导入保真 | ✅ 通过 | {"bytes":205006,"layersBefore":2,"layersAfter":2,"groupsAfter":0,"pixelDiff":{"changed":0,"total":960000,"ratio":0,"bbox":null},"fidelity":{"layers":2,"groups":0,"masks":0,"blend":0,"bytes":205006}} |
| F5 涂抹（已有墨迹像素变化） | ✅ 通过 | {"mode":{"mode":"smudge","isSmudge":true},"back":"brush","pixelDiff":{"changed":5224,"total":960000,"ratio":0.54,"bbox":{"minX":400,"minY":394,"maxX":666,"maxY":481}}} |
| F6 选区约束（选区外不落笔） | ✅ 通过 | {"hasSelection":true,"unchangedOutside":true,"pixelDiff":{"changed":0,"total":960000,"ratio":0,"bbox":null},"cleared":true} |
| F7 变换提交（1 步 undo）→ undo 像素还原 | ✅ 通过 | {"handles":9,"committedChangedPx":6001,"undoRestoreDiff":{"changed":0,"total":960000,"ratio":0,"bbox":null},"undo0":1,"undo1":2} |
| F8 结构操作 undo/redo | ✅ 通过 | {"n0":2,"n1":3,"n2":4,"nU":2,"nR":3} |
| F9 Alpha Lock（锁定空白层不落笔，解锁后可见） | ✅ 通过 | {"alphaLock":true,"lockedUnchanged":true,"unlockedChanged":true} |
| F10 组蒙版（组内容被蒙版隐藏 / 停用恢复） | ✅ 通过 | {"layers":3,"target":"group-mask","mask":{"exists":true,"enabled":true},"maskInkChangePx":1946,"toggleRestored":true,"disabled":{"enabled":{"exists":true,"enabled":false}}} |
| F11 组剪贴（直接相邻基底 + DstIn 裁剪生效） | ✅ 通过 | {"layersAfterPrep":1,"order":[{"id":"layer-1","group":null},{"id":"layer-2-mw5xbmvw","group":"group-8qkya6i"}],"clip":true,"clippedPx":1984,"bbox":{"minX":380,"minY":256,"maxX":387,"maxY":511},"preVsAfterPx":2034} |
| F12 涂抹 snapshotRegion（两次涂抹均生效） | ✅ 通过 | {"firstPassPx":6813,"secondPassPx":5686,"mode":{"mode":"smudge","smudgeFullCanvas":false}} |
| F13 压感默认 A/B（tau50 默认生效 + A/B 记录） | ✅ 通过 | {"defaultCfg":{"enabled":true,"strength":1,"curve":"soft","smoothingMs":65,"speedRef":2.2,"warmupMs":90,"minPressure":0.08,"startPressure":0.3,"catchUp":true,"speedTauMs":50,"slowSmoothingMs":0},"appDefault":{"enabled":true,"strength":1,"curve":"soft","smoothingMs":65,"startPressure":0.3,"catchUp":t |
| F14 素材库 Sheet 打开/关闭（画布状态不变） | ✅ 通过 | {"open":true,"vis":true,"closed":true,"canvasUnchangedOpen":true,"canvasUnchangedClose":true} |
| F15 搜索/筛选（全量+text+tag+color；UI chips 记录） | ✅ 通过 | {"total":3,"chips":["all","pending","referenced","lowconf"],"textCount":1,"tagCount":1,"colorCount":2} |
| F16 导入去重（同图二次导入跳过） | ✅ 通过 | {"before":3,"after":5,"r1":1,"r2":0,"r3":1,"r2skip":1,"lastImport":{"id":"asset-0070ca83a0d0a8cf","sha256":"0070ca83a0d0a8cf3d0f07a61f59b12caf012244bc62ac149eadc0a18fec0e3e","fileName":"qa-a.png","mime":"image/png","bytes":320,"width":80,"height":60,"createdAt":"2026-11-07T04:49:22.822Z","updatedAt" |
| F17 L4 确认/否决→L5（user-confirmed） | ✅ 通过 | {"assetId":"asset-0070ca83a0d0a8cf","l4Count":4,"l5Count":2,"kinds":["confirm","reject"],"sources":["user-confirmed","user-confirmed"],"confirmedOk":true,"rejectedOk":true} |
| F18 插入图层用原图 + AI 参考 chip + 证据 refs | ✅ 通过 | {"assetId":"asset-0070ca83a0d0a8cf","layers":"2→3","imageSource":"original-bitmap","canvasChanged":true,"aiRef":{"id":"asset-0070ca83a0d0a8cf","fileName":"qa-a.png"},"chipVisible":true,"evidenceRefs":[{"usage":"insert","asset_id":"asset-0070ca83a0d0a8cf","fileName":"qa-a.png","sha256":"0070ca83a0d0a |
| F19 12 步一键演示可跑完 | ✅ 通过 | {"count":12,"maxStep":11,"sawEnd":true,"exited":true} |
| F20 刷新持久化（素材库计数 + L5） | ✅ 通过 | {"before":{"count":5,"ids":["asset-0070ca83a0d0a8cf","asset-097e0cc94b00615f","asset-0d2a880d41c4e51f","asset-15d1a5ba379f9a05","asset-f31c2c0734bad765"],"demoSteps":12},"after":{"count":5,"demoSteps":12,"l5Count":3}} |
| F21 蒙版橡皮（T85：擦除=隐藏、停用蒙版恢复） | ✅ 通过 | {"target":"mask","paint":"black","maskStats":{"tiles":4,"meanAlpha":250,"darkFraction":0.021,"samples":15424},"maskedPx":224,"toggleRestored":true,"exit":"layer"} |
| F22 暖纸主题（T87：data-theme=paper + paper-theme.css + 暖色底） | ✅ 通过 | {"theme":"paper","paperCss":true,"bodyBg":"rgb(244, 235, 221)","paperVar":"","bgImg":"none"} |
| F23 一键演示说明卡（T87：12 步/卡片可见/步进更新/无溢出） | ✅ 通过 | {"steps":12,"titlesOk":true,"vis":true,"inView":true,"s1":{"step":"01 / 12","title":"打开示例作品","text":"先看一张本地示例作品：整幅画都在你的浏览器里，不上传、不联网。"},"s2":{"step":"02 / 12","title":"打开素材库","text":"创作卡住时回到私人视觉记忆：AI 已经读过这些素材，按整体、区域、观察整理好。"},"s3":{"step":"03 / 12","title":"选一张素材","text":"选「雾中山谷」：缩略图、标签、AI 已读/待确认一目了然， |
| F24 异步保存/PSD Worker（T81：worker 保存+gzip、进度、PSD 8BPS、异步任务条、取消） | ✅ 通过 | {"support":{"saveDocAsync":true,"exportPSDAsync":true,"worker":true,"compression":true},"warm":false,"save":{"bytes":313654,"compressed":true,"progress":25,"gzip":true},"psd":{"bytes":534422,"head":"8BPS","progress":3,"magic":true},"taskUi":{"visible":true,"label":"QA 异步任务"},"cancel":{"aborted":true |
| F25 .mozheng v2 gzip 保存→刷新→打开（结构 + 像素 diff=0） | ✅ 通过 | {"bytes":20926,"saveRetries":0,"structureEqual":true,"loadedLayers":2,"pixelDiff":{"changed":0,"total":960000,"ratio":0,"bbox":null}} |

**通过率：25/25**

失败 owner 归属：无（25/25 全通过）