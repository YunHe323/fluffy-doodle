# 真实 Qwen 视觉/生图集成 · 独立 QA 报告（T102）

> 执行：qa-engineer（独立于 owner 自测）｜环境：headless Edge、独立端口 8171、0 残留｜只写 `v2/qa/`
> 密钥处理：全程不打印/不落盘明文 key；静态与运行时泄漏检查用内存比对并只输出布尔值。

## 结论

**真实 Qwen 集成可交付（Deliverable）——通过，无阻塞项（P0/P1 = 0）。**

- 代理/假上游三套件独立复跑全绿：**qwen 12/12、proxy 32/32、adversarial 35/35**（0 error）
- 产物核对 **7/7 全过**：候选 sha256 与实际 PNG 一致、L6 字段完整、证据 real_calls 与 L6 事件一致、`verify-evidence` 12/12 通过、无 key 泄漏、`.gitignore` 生效
- 一次**最小真实视觉调用**成功：`qwen3.8-max`、mode=real、3.7s、203 tokens、返回正确描述（“蓝色背景上一个白色的正方形”）
- 回归：test-app / test-ui / test-interaction-sequences（9/9）+ 三页冒烟 **3/3** PASS；GATE 保持 T97 全绿

## 1. 代理/假上游独立复跑

| 套件 | 结果 | 说明 |
|---|---|---|
| `ai-proxy-qwen-test.mjs` | **12/12 PASS** | qwen preset/config、submit/queue/检索、结果 URL 缓存、sha256、usage、无上游 URL 泄漏 |
| `ai-proxy-test.mjs` | **32/32 PASS** | config/token/chat/SSE/image/并发 1/401/429/超时/mock/不泄漏 key |
| `ai-proxy-adversarial.mjs` | **35/35 PASS** | Origin scheme/host/port、缺 confirm、超大 body→413、尺寸/参考图上限、串行队列、12h URL 404、密钥不泄漏、Windows ACL、`.gitignore` |

## 2. 产物核对（7/7 PASS）

| 检查 | 结果 |
|---|---|
| 候选图 sha256 与声明一致 | ✅ `qwen-real-candidate.png` = `29a2875…b12e`（1,236,634 B，1024²），测试/结果 JSON 中声明一致 |
| 生图样本 sha256 | ✅ `qwen-image-real-sample.png` = `0a038f6…3519`（1,154,038 B） |
| L6 generation 字段 | ✅ provider=`qwen`、model=`qwen3.8-max`/`qwen-image-3.0`、candidate_sha256、usage（tokens / output_image_count 等） |
| 证据 manifest | ✅ `manifest.ai.real_calls=1` == L6 AI 事件数 1；`calls=1`、`mock_calls=0`、`providers=[qwen/qwen3.8-max]`、`total_tokens=967`、`total_latency_ms=11113` |
| `verify-evidence.mjs` 第三方复核 | ✅ 12/12 通过（schema/genesis/eventCount/chain/headHash/canvasHash/aiCalls/aiSplit/aiRealCalls/aiProviders/aiManifest/refs），0 error |
| 密钥泄漏（静态/运行时） | ✅ 静态源码无 key；浏览器 DOM/localStorage/已加载 JS 无 key；config GET 仅 `hasKey/keyLast4`，无 `apiKey` 字段 |
| `.gitignore` | ✅ 根 `.gitignore` 含 `v2/.ai-config.json`、`v2/.ai-token`（生效=已列管且无 VCS 跟踪风险） |

> 质量说明：`verify-evidence` 复核的 `canvasHash`、链式哈希、事件数均与证据包一致；证据包事件 5 条、L6 AI 事件 1 条。

## 3. 一次最小真实视觉调用（QA 独立发起，经本地代理）

| 项 | 值 |
|---|---|
| 请求 | `POST /api/ai/chat`，64×64 PNG（蓝底白方块）+ 中文简单问题，`x-ai-confirm: true` |
| 状态 | **200 · mode=real** |
| 模型 | `qwen3.8-max` |
| 延迟 | **3.7 s**（latencyMs=3724） |
| 用量 | **203 tokens**（prompt 101 / completion 102；image_tokens 66） |
| 返回 | “这张图主要是蓝色背景上一个白色的正方形。”（内容长度 20） |
| 结论 | 真实 provider 接线、usage/latency 回传正常；**未跑真实生图**（成本控制） |

## 4. 回归（T101 变更无回退）

| 项 | 结果 |
|---|---|
| `test-app.mjs` | ✅ PASS（0 error，截图产出） |
| `test-ui.mjs` | ✅ PASS（0 error，p1Checks 全过） |
| `test-interaction-sequences.mjs` | ✅ **9/9 PASS**（0 error） |
| 三页冒烟（harness --smoke-only） | ✅ **3/3 PASS**（app/brushes/engine：ready/绘制/拖动保留/帧稳定/undo） |
| GATE（4×3，T97 基线） | 保持全绿；真实 Qwen 变更未涉及画布/present 路径 |

## 5. 安全复核

- `v2/.ai-config.json` 权限：NTFS ACL 仅 `SYSTEM / Administrators / 当前用户`（+ 继承的系统标签），**无 Everyone/Users 写权限**；未在报告中输出任何 key 片段。
- 证据/响应中无上游 URL、无 key；代理响应仅 `hasKey/keyLast4`。
- 真实调用前均带 `x-ai-confirm: true`，符合“不确认不发送”契约。

## 6. 风险与建议（非阻塞）

| # | 风险 | 级别 | 建议/owner |
|---|---|---|---|
| 1 | 真实视觉端到端 8.7–14.4s、生图 16–20s，用户可能感知等待 | P2 | app 已有异步任务条/进度；建议保持“预计费用/耗时”提示（demo-builder） |
| 2 | 真实生图成本较高，本次仅复核 owner 产物未重复调用 | — | 交付前如需现场演示，建议预置缓存候选/明确计费提示（lead） |
| 3 | 证据中 `filePermissions` 在部分响应为 `acl:"pending"`（异步检测） | P2 | 非阻断；前端无需展示（tech） |

## 7. 产物

- `v2/qa/tools/qwen-real-qa-report.md`（本报告）
- `v2/qa/tools/t102-artifacts-results.json`（产物核对 7/7）
- `v2/qa/tools/t102-browser-results.json`（运行时/真实调用证据）
- `v2/qa/tools/archive/baseline-qwen-real/`（本报告 + 三套件结果 + 产物核对 + 证据 JSON 摘要）
