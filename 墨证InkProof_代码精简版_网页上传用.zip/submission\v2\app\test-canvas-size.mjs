// v2/app/test-canvas-size.mjs —— 新建画布尺寸（?new=1&w/h）、画布属性与绘制
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8151;
const out = { schema: 'mozheng.app.canvas-size.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  fs.writeFileSync(ROOT + '\\v2\\app\\test-canvas-size-result.json', JSON.stringify(out, null, 2), 'utf8');
  process.exit(code);
};
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html?new=1&w=1600&h=1000`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1200);
  out.cases.init = await page.evaluate(() => ({
    w: window.__V2_APP__.engine.width, h: window.__V2_APP__.engine.height,
    canvasW: document.getElementById('mainCanvas').width, canvasH: document.getElementById('mainCanvas').height,
    docSize: (document.getElementById('docSize') || {}).textContent,
    layers: window.__V2_APP__.engine.getLayers().length,
    url: location.search,
  }));
  const box = await page.locator('#mainCanvas').boundingBox();
  await page.mouse.move(box.x + box.width * 0.4, box.y + box.height * 0.45);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width * 0.65, box.y + box.height * 0.6, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(400);
  out.cases.draw = await page.evaluate(() => ({ undo: window.__V2_APP__.engine.getStats().undoDepth, canvasW: window.__V2_APP__.engine.width }));
  // 打开新建画布弹窗，点 1920×1080 预设
  await page.click('#btnMore');
  await page.waitForTimeout(200);
  await page.click('#btnNewCanvas');
  await page.waitForTimeout(300);
  out.cases.modal = await page.evaluate(() => ({ visible: !!document.querySelector('#newCanvasModal.show'), w: (document.getElementById('newCanvasW') || {}).value, h: (document.getElementById('newCanvasH') || {}).value }));
  await page.click('#newCanvasPresets [data-w="1920"]');
  await page.waitForTimeout(150);
  out.cases.preset = await page.evaluate(() => ({ w: (document.getElementById('newCanvasW') || {}).value, h: (document.getElementById('newCanvasH') || {}).value }));
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-canvas-1600x1000.png' });
  out.cases.initOk = out.cases.init.w === 1600 && out.cases.init.h === 1000 && out.cases.init.canvasW === 1600 && out.cases.init.canvasH === 1000;
  out.cases.drawOk = out.cases.draw.undo >= 1;
  out.cases.modalOk = out.cases.modal.visible && out.cases.modal.w === '1600' && out.cases.modal.h === '1000';
  out.cases.presetOk = out.cases.preset.w === '1920' && out.cases.preset.h === '1080';
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.initOk && out.cases.drawOk && out.cases.modalOk && out.cases.presetOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  await finish(3);
}
