/**
 * v2/app/core/asset-batch.mjs — T106-A 素材批量理解队列（纯逻辑，零网络/DOM）
 *
 * 设计目标：把「素材库持续真实理解」拆成可测试的排队/执行/合并/汇总四层；
 * 真正的模型调用由调用方注入的 runner 完成（可包 skill + 手动确认 + 隐私开关）。
 *
 * 只依赖同目录 T105-A 的纯函数 mergeRealAnalysis；无 IndexedDB / fetch / DOM。
 */

import { mergeRealAnalysis } from './asset-ai.mjs';

export const ASSET_BATCH_VERSION = 'asset-batch@1.0.0';
export const DEFAULT_BATCH_LIMIT = 3;
export const LOW_CONFIDENCE = 0.55;

const asArray = (v) => (Array.isArray(v) ? v : []);
const asStr = (v) => (v == null ? '' : String(v));
const nowIso = () => new Date().toISOString();
const clampInt = (v, def, min, max) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return def;
  return Math.max(min, Math.min(max, Math.floor(n)));
};

function isRealAsset(asset) {
  return !!asset && (asset.analysisSource === 'real' || (asset.analysis && asset.analysis.source === 'real'));
}
function l1Of(asset) { return asset && asset.L1 && typeof asset.L1 === 'object' ? asset.L1 : {}; }
function hasL1(asset) {
  const l1 = l1Of(asset);
  return !!(asStr(l1.summary) || asArray(l1.subject).length || asArray(l1.palette).length);
}
function confidenceOf(asset) {
  const c = Number(l1Of(asset).confidence);
  return Number.isFinite(c) ? c : null;
}

/**
 * 1) 规划批量阅读队列。
 * 优先级：缺 L1(0) > 低置信(1) > 尚未真实读(2) > 已真实读(3，仅 onlyMock=false)
 * @param {object[]} assets
 * @param {{limit?:number, onlyMock?:boolean}} opts
 * @returns {Array<{id:string,fileName:string,reason:string,priority:number}>}
 */
export function planBatchRead(assets, opts = {}) {
  const optsSafe = opts && typeof opts === 'object' ? opts : {};
  const limit = clampInt(optsSafe.limit, DEFAULT_BATCH_LIMIT, 0, 9999);
  const onlyMock = optsSafe.onlyMock !== false; // 默认只处理尚未真实理解的素材
  if (!limit) return [];
  const rows = [];
  asArray(assets).forEach((asset) => {
    if (!asset || typeof asset !== 'object') return;
    const id = asStr(asset.id || asset.assetId || asset.asset_id);
    if (!id) return;
    const real = isRealAsset(asset);
    if (onlyMock && real) return;
    const l1 = l1Of(asset);
    const confidence = confidenceOf(asset);
    let priority = 2;
    let reason = '尚未真实理解（mock/未读）';
    if (!hasL1(asset)) {
      priority = 0;
      reason = '缺少 L1 全局理解';
    } else if (confidence == null || confidence < LOW_CONFIDENCE) {
      priority = 1;
      reason = confidence == null ? '置信度未知' : `置信度偏低（${Math.round(confidence * 100)}%）`;
    } else if (real) {
      priority = 3;
      reason = '已真实理解（可选重读）';
    }
    rows.push({
      id,
      fileName: asStr(asset.fileName),
      reason,
      priority,
      _confidence: confidence == null ? 1 : confidence,
      _updatedAt: asStr(asset.updatedAt || asset.createdAt),
      _real: real,
    });
  });
  rows.sort((a, b) => a.priority - b.priority
    || a._confidence - b._confidence
    || String(a._updatedAt).localeCompare(String(b._updatedAt))
    || a.id.localeCompare(b.id));
  return rows.slice(0, limit).map(({ id, fileName, reason, priority }) => ({ id, fileName, reason, priority }));
}

/**
 * 2) 批量队列。runner(item, ctx) 由调用方注入；ctx = {index, signal, queue, isCancelled}
 * - 默认 concurrency=1（1/1 串行），失败不阻塞后续；
 * - cancel() 会 abort signal、将未开始项标记 cancelled，不再启动新项；
 * - run() 只能调用一次，resolve 为最终 state 快照。
 */
export class BatchQueue {
  constructor(plan, runner) {
    if (typeof runner !== 'function') throw new TypeError('BatchQueue runner 必须为函数');
    this._plan = asArray(plan).filter((p) => p && typeof p === 'object' && p.id).map((p) => ({
      id: asStr(p.id), fileName: asStr(p.fileName), reason: asStr(p.reason), priority: Number(p.priority) || 0,
    }));
    this._runner = runner;
    this._items = this._plan.map((p, index) => ({
      ...p,
      index,
      status: 'pending',
      error: null,
      errorCode: null,
      result: null,
      startedAt: null,
      finishedAt: null,
      attempts: 0,
    }));
    this._status = 'pending';
    this._started = false;
    this._startedAt = null;
    this._finishedAt = null;
    this._cancelRequested = false;
    this._abort = new AbortController();
  }

  /** 状态快照（items 为副本，result 仍为 runner 返回引用） */
  get state() {
    return {
      status: this._status,
      items: this._items.map((it) => ({ ...it })),
      startedAt: this._startedAt,
      finishedAt: this._finishedAt,
      cancelled: this._cancelRequested,
      version: ASSET_BATCH_VERSION,
    };
  }

  get status() { return this._status; }
  get items() { return this._items.map((it) => ({ ...it })); }
  get total() { return this._items.length; }

  /** 取消：不启动新项；未开始项标记 cancelled；已运行项等待其 runner 结束。 */
  cancel() {
    if (this._status === 'done' || this._status === 'failed' || this._status === 'cancelled') {
      this._cancelRequested = true;
      try { this._abort.abort(); } catch (e) { /* ignore */ }
      return this.state;
    }
    this._cancelRequested = true;
    try { this._abort.abort(); } catch (e) { /* ignore */ }
    for (const item of this._items) {
      if (item.status === 'pending') {
        item.status = 'cancelled';
        item.finishedAt = nowIso();
      }
    }
    this._status = 'cancelled';
    return this.state;
  }

  _counts() {
    const c = { total: this._items.length, done: 0, failed: 0, pending: 0, running: 0, cancelled: 0 };
    for (const it of this._items) {
      if (it.status === 'done') c.done += 1;
      else if (it.status === 'failed') c.failed += 1;
      else if (it.status === 'running') c.running += 1;
      else if (it.status === 'cancelled') c.cancelled += 1;
      else c.pending += 1;
    }
    return c;
  }

  _emitProgress(onProgress, item) {
    if (typeof onProgress !== 'function') return;
    const c = this._counts();
    const payload = {
      total: c.total,
      done: c.done,
      failed: c.failed,
      pending: c.pending + c.running,
      running: c.running,
      cancelled: c.cancelled,
      processed: c.done + c.failed + c.cancelled,
      status: this._status,
      item: item ? { id: item.id, status: item.status } : null,
    };
    try { onProgress(payload, this.state); } catch (e) { /* 回调异常不阻塞队列 */ }
  }

  _snapshotItem(item) {
    return { ...item };
  }

  async _runOne(item, ctx) {
    item.status = 'running';
    item.startedAt = nowIso();
    item.attempts += 1;
    let result = null;
    let error = null;
    try {
      if (this._cancelRequested) throw Object.assign(new Error('cancelled'), { name: 'AbortError', code: 'cancelled' });
      result = await this._runner(this._snapshotItem(item), ctx);
      item.result = result == null ? null : result;
      item.status = 'done';
    } catch (e) {
      error = e || new Error('runner failed');
      item.error = asStr(error.userMessage || error.message || error);
      item.errorCode = error.code || (error.name === 'AbortError' ? 'cancelled' : null);
      item.status = (this._cancelRequested || error.name === 'AbortError' || error.code === 'cancelled') ? 'cancelled' : 'failed';
    } finally {
      item.finishedAt = nowIso();
    }
    return { item, result: item.status === 'done' ? item.result : null, error };
  }

  /**
   * @param {{concurrency?:number,onProgress?:Function,onItem?:Function}} opts
   * onProgress(payload, state) 每个 item 结束 + 最终一次；
   * onItem(itemSnapshot, result|null, error|null) 每个 item 结束一次。
   */
  async run(opts = {}) {
    if (this._started) throw new Error('BatchQueue.run 只能调用一次');
    this._started = true;
    const safe = opts && typeof opts === 'object' ? opts : {};
    const concurrency = clampInt(safe.concurrency, 1, 1, 8);
    const onProgress = typeof safe.onProgress === 'function' ? safe.onProgress : null;
    const onItem = typeof safe.onItem === 'function' ? safe.onItem : null;
    this._startedAt = nowIso();

    if (!this._items.length) {
      this._status = this._cancelRequested ? 'cancelled' : 'done';
      this._finishedAt = nowIso();
      this._emitProgress(onProgress, null);
      return this.state;
    }
    if (this._cancelRequested) {
      this._status = 'cancelled';
      this._finishedAt = nowIso();
      this._emitProgress(onProgress, null);
      return this.state;
    }

    this._status = 'running';
    let cursor = 0;
    const nextIndex = () => {
      while (cursor < this._items.length) {
        const idx = cursor;
        cursor += 1;
        if (this._items[idx].status === 'pending') return idx;
      }
      return -1;
    };
    const worker = async () => {
      while (!this._cancelRequested) {
        const idx = nextIndex();
        if (idx < 0) break;
        const item = this._items[idx];
        const ctx = {
          index: idx,
          signal: this._abort.signal,
          queue: this,
          isCancelled: () => this._cancelRequested,
        };
        const settled = await this._runOne(item, ctx);
        if (onItem) {
          try { onItem(this._snapshotItem(settled.item), settled.result, settled.error); } catch (e) { /* ignore */ }
        }
        this._emitProgress(onProgress, settled.item);
      }
    };
    await Promise.all(Array.from({ length: Math.min(concurrency, this._items.length) }, () => worker()));

    // runner 未响应 cancellation 时，循环结束后把仍 pending 的项标记 cancelled
    if (this._cancelRequested) {
      for (const item of this._items) if (item.status === 'pending') { item.status = 'cancelled'; item.finishedAt = nowIso(); }
      this._status = 'cancelled';
    } else {
      const c = this._counts();
      this._status = c.failed > 0 && c.done === 0 ? 'failed' : 'done';
    }
    this._finishedAt = nowIso();
    this._emitProgress(onProgress, null);
    return this.state;
  }
}

/** 判断 runner 结果是否真实模型结果（用于 summarizeBatch.real 计数） */
function isRealResult(result) {
  if (!result || typeof result !== 'object') return false;
  if (result.analysisSource === 'real') return true;
  if (result.analysis && result.analysis.source === 'real') return true;
  if (result.meta && result.meta.mock === false) return true;
  if (result.mode === 'real' && result.mock === false) return true;
  if (result.raw && (result.raw.mock === false || result.raw.mode === 'real')) return true;
  return false;
}

/**
 * 3) 按 id 合并批量结果。
 * results 支持：
 *  - array/map of {id, analysis, meta}（推荐；调用 mergeRealAnalysis）
 *  - array/map of {id, L1/L2/L4/tags/...}（直接 Object.assign）
 *  - queue item 形态 {id, result: ...}
 * 失败/无 id/未知 id 跳过；保留 assets 原对象引用并原地合并。
 * @returns {object[]} 传入的 assets 数组（引用不变）
 */
export function mergeBatchResults(assets, results) {
  const list = asArray(assets);
  const byId = new Map();
  const addResult = (id, raw) => {
    const key = asStr(id);
    if (!key || !raw || typeof raw !== 'object') return;
    if (raw.status === 'failed' || raw.status === 'cancelled' || raw.error) return;
    if (raw.result && typeof raw.result === 'object' && !raw.analysis && !raw.L1 && !raw.merge && !raw.fields) {
      byId.set(key, raw.result);
    } else {
      byId.set(key, raw);
    }
  };
  if (Array.isArray(results)) {
    for (const r of results) {
      if (!r || typeof r !== 'object') continue;
      addResult(r.id || r.assetId || r.asset_id || (r.item && r.item.id), r);
    }
  } else if (results instanceof Map) {
    for (const [id, r] of results.entries()) addResult(id, r);
  } else if (results && typeof results === 'object') {
    if (Array.isArray(results.results)) return mergeBatchResults(assets, results.results);
    for (const [id, r] of Object.entries(results)) addResult(id, r);
  }
  for (const asset of list) {
    if (!asset || typeof asset !== 'object' || !asset.id) continue;
    const raw = byId.get(asStr(asset.id));
    if (!raw) continue;
    const payload = raw.result && typeof raw.result === 'object' && !raw.analysis && !raw.L1 ? raw.result : raw;
    if (payload.analysis && typeof payload.analysis === 'object') {
      const meta = payload.meta || payload.analysis.meta || {};
      try { Object.assign(asset, mergeRealAnalysis(asset, payload.analysis, meta)); } catch (e) { /* skip malformed */ }
      continue;
    }
    const fields = payload.merge || payload.fields || payload;
    const picked = {};
    for (const k of ['L1', 'L2', 'L4', 'tags', 'palette', 'modelVersion', 'analysisSource', 'analysis', 'source', 'updatedAt']) {
      if (fields[k] !== undefined) picked[k] = fields[k];
    }
    if (Object.keys(picked).length) Object.assign(asset, picked);
  }
  return list;
}

/**
 * 4) 批量结果汇总。state 可传 BatchQueue 实例或 queue.state 快照。
 * @returns {{total:number,done:number,failed:number,pending:number,real:number,cancelled:number}}
 */
export function summarizeBatch(state) {
  const s = state && state.items ? state : (state && state.state ? state.state : null);
  const items = asArray(s && s.items);
  let done = 0; let failed = 0; let pending = 0; let cancelled = 0; let real = 0;
  for (const it of items) {
    if (!it) continue;
    if (it.status === 'done') {
      done += 1;
      if (isRealResult(it.result)) real += 1;
    } else if (it.status === 'failed') failed += 1;
    else if (it.status === 'cancelled') cancelled += 1;
    else pending += 1;
  }
  return { total: items.length, done, failed, pending, real, cancelled };
}

export default {
  ASSET_BATCH_VERSION,
  DEFAULT_BATCH_LIMIT,
  planBatchRead,
  BatchQueue,
  mergeBatchResults,
  summarizeBatch,
};
