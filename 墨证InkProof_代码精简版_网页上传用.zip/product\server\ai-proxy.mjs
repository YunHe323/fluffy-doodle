// product/server/ai-proxy.mjs
// 真实 AI Provider 的预留位。
//
// 【v0.1 硬约束】
// 1. 本文件**绝不发起任何网络请求**：没有 fetch / http.request / DNS 解析。
// 2. 服务端无遥测、无静默外联；mock 模式完全离线可用。
// 3. 密钥只来自本地 config/provider.json（已 gitignore，由用户自己创建）；
//    不硬编码、不写日志、不通过 GET /api/config 返回明文。
//
// TODO(v0.2)：实现真实调用时，必须满足：
// - 只有用户在 /api/config 显式切换 provider 后才启用；
// - 只请求用户配置的 baseUrl，不请求任何统计/遥测域名；
// - 超时、取消、错误映射、重试上限；返回结构与 core/mock-ai.mjs 完全同形；
// - 密钥只存内存（从 provider.json 读取），日志与错误信息中脱敏。

export const PROVIDERS = Object.freeze(['mock', 'openai-compatible']);
export const CONFIG_FILE_NAME = 'provider.json';

export class NotImplementedError extends Error {
  constructor(feature) {
    super(`未实现：${feature}（真实 AI provider 为预留位；v0.1 仅支持 mock）`);
    this.name = 'NotImplementedError';
    this.code = 'NOT_IMPLEMENTED';
  }
}

/** 是否 mock 模式（无配置 / provider 缺省 / provider=mock） */
export function isMock(config) {
  return !config || !config.provider || config.provider === 'mock';
}

/** 非 mock 模式在 v0.1 一律抛 NotImplemented（服务端会映射为 501）。 */
export function assertProviderReady(config, kind = 'ai') {
  if (isMock(config)) return;
  throw new NotImplementedError(`${kind} provider=${String(config.provider)}`);
}

/**
 * 预留的真实调用入口。v0.1 永远抛 NotImplemented。
 * @param {'analyze'|'directions'|'generate'} kind
 * @param {object} payload
 * @param {object} config
 */
export async function callProvider(kind, payload, config) {
  void payload;
  assertProviderReady(config, kind);
  throw new NotImplementedError(kind);
}

const RE_BASE_URL = /^https?:\/\/[^\s]+$/i;
const MAX_URL_LEN = 500;
const MAX_MODEL_LEN = 120;
const MAX_KEY_LEN = 500;

/**
 * 校验并合并配置。规则见 product/CONTRACT.md §2.5。
 * @param {object} input PUT 的请求体（部分更新）
 * @param {object} current 当前内存配置
 * @returns {{ok:boolean, config?:object, errors:Array<{path:string,error:string}>}}
 */
export function sanitizeConfig(input, current = {}) {
  const errors = [];
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    return { ok: false, errors: [{ path: '', error: 'config_must_be_object' }] };
  }
  const next = {
    provider: current.provider ?? 'mock',
    baseUrl: current.baseUrl ?? '',
    model: current.model ?? '',
    apiKey: current.apiKey ?? '',
  };

  if (input.provider !== undefined) {
    if (!PROVIDERS.includes(input.provider)) {
      errors.push({ path: 'provider', error: `must_be_one_of:${PROVIDERS.join('|')}` });
    } else {
      next.provider = input.provider;
    }
  }
  if (input.baseUrl !== undefined) {
    if (typeof input.baseUrl !== 'string' || input.baseUrl.length > MAX_URL_LEN) {
      errors.push({ path: 'baseUrl', error: 'must_be_string<=500' });
    } else if (input.baseUrl !== '' && !RE_BASE_URL.test(input.baseUrl)) {
      errors.push({ path: 'baseUrl', error: 'must_be_http_url' });
    } else {
      next.baseUrl = input.baseUrl;
    }
  }
  if (input.model !== undefined) {
    if (typeof input.model !== 'string' || input.model.length > MAX_MODEL_LEN) {
      errors.push({ path: 'model', error: 'must_be_string<=120' });
    } else {
      next.model = input.model;
    }
  }
  if (input.apiKey !== undefined) {
    if (typeof input.apiKey !== 'string' || input.apiKey.length > MAX_KEY_LEN) {
      errors.push({ path: 'apiKey', error: 'must_be_string<=2000' });
    } else {
      next.apiKey = input.apiKey;
    }
  }

  // 非 mock 模式要求 baseUrl + model 非空（真实接入前的最小完整性）
  if (next.provider !== 'mock') {
    if (!next.baseUrl) errors.push({ path: 'baseUrl', error: 'required_for_provider' });
    if (!next.model) errors.push({ path: 'model', error: 'required_for_provider' });
  }

  if (errors.length > 0) return { ok: false, errors };
  return { ok: true, config: next, errors: [] };
}

/** 对外安全的配置视图（永不包含 apiKey 明文） */
export function publicConfig(config, source = 'default', updatedAt = null) {
  return {
    provider: config.provider ?? 'mock',
    baseUrl: config.baseUrl ?? '',
    model: config.model ?? '',
    apiKeySet: Boolean(config.apiKey),
    updatedAt,
    source,
  };
}
