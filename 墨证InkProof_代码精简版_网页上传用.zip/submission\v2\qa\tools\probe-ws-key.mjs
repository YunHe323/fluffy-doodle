// v2/qa/tools/probe-ws-key.mjs —— 探测新的 workspace API key 是否可用于 legacy DashScope 域名（不打印 key）
const key = process.env.WSKEY || '';
if (!key) { console.error('NO_KEY'); process.exit(2); }
async function tryChat(base) {
  const res = await fetch(base + '/compatible-mode/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + key },
    body: JSON.stringify({ model: 'qwen3.8-max', messages: [{ role: 'user', content: 'ping' }], max_tokens: 4, stream: false }),
  });
  const text = await res.text();
  let j = null; try { j = JSON.parse(text); } catch (e) { /* ignore */ }
  return { base, status: res.status, code: j && j.error && (j.error.code || j.error.type), msg: (j && j.error && j.error.message) ? String(j.error.message).slice(0, 200) : text.slice(0, 200) };
}
const results = [];
for (const base of ['https://dashscope.aliyuncs.com', 'https://trial.cn-beijing.maas.aliyuncs.com']) {
  try { results.push(await tryChat(base)); } catch (e) { results.push({ base, error: String(e && e.message || e).slice(0, 200) }); }
}
console.log(JSON.stringify(results, null, 2));
