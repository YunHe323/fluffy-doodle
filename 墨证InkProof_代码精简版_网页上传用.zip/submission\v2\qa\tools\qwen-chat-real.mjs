// v2/qa/tools/qwen-chat-real.mjs —— 真实 Qwen 自由对话（一次最小调用，验证实时上下文/选区）
import { chromium } from '../node_modules/playwright-core/index.mjs';
import fs from 'node:fs';
const OUT = 'v2/qa/tools/qwen-chat-real-results.json';
const res = { schema: 'mozheng.qa.qwen-chat-real.v1', cases: {}, errors: [], pass: false };
let browser = null;
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('mozheng.ai.settings.v1', JSON.stringify({ preset: 'qwen', allowReal: true, requireConfirm: false, privacyMode: false })); } catch (e) {} });
  const page = await ctx.newPage();
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) res.errors.push(m.text().slice(0, 300)); });
  await page.goto('http://127.0.0.1:4200/v2/app/index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(2000);
  res.cases.state = await page.evaluate(() => window.__V2_APP__.t96.getState());
  await page.evaluate(() => { const a = window.__V2_APP__; a.state.selection = { x: 300, y: 220, width: 360, height: 240 }; a.drawSelection(); a.openPopover('popAI'); });
  await page.waitForTimeout(300);
  const t0 = Date.now();
  await page.evaluate(() => window.__V2_APP__.runChat('用一句话说这个选区现在最该改什么？不要泛泛而谈。'));
  await page.waitForFunction(() => { const c = window.__V2_APP__.aiChat || []; return c.length >= 2 && c[c.length - 1].role === 'assistant'; }, null, { timeout: 90000 });
  await page.waitForTimeout(400);
  res.cases.chat = await page.evaluate(() => { const c = window.__V2_APP__.aiChat; const last = c[c.length - 1]; return { ms: 0, text: last.content, meta: last.meta, len: c.length }; });
  res.cases.chat.ms = Date.now() - t0;
  res.cases.ui = await page.evaluate(() => ({ rows: document.querySelectorAll('#aiBody .ai-chat-msg').length, input: !!document.getElementById('aiChatInput') }));
  await page.screenshot({ path: 'v2/app/ui-chat-real-1920.png' });
  res.pass = !!(res.cases.chat.meta && res.cases.chat.meta.mock === false && res.cases.chat.meta.provider === 'qwen' && String(res.cases.chat.text || '').length > 5 && res.errors.length === 0);
} catch (e) { res.fatal = String(e && e.stack || e); } finally { try { await browser.close(); } catch (e) {} }
await fs.promises.writeFile(OUT, JSON.stringify(res, null, 2), 'utf8');
console.log(JSON.stringify(res, null, 2));
process.exit(res.pass ? 0 : 1);
