// product/app/js/evidence.js
// 证据链：事件哈希链（SHA-256）、L6 派生记录、manifests、证据包导出（JSON + PNG）、零生成声明。
// 对齐：product/CONTRACT.md §3（/core/hash-chain.mjs）/ §4；损坏或离线时降级为本地实现并如实标注。
import {
  state, emit, $, uid, nowIso, fmtTime, fileStamp, escapeHtml, toast,
  canvasToBlob, canvasToArrayBuffer, downloadBlob, APP_VERSION, CONTRACT_VERSION, SCHEMA_VERSION
} from './state.js';
import { getCompositeCanvas, renderCanvas } from './canvas.js';
import { saveEventRecord, saveGenerationRecord } from './db.js';

/* ---------------- 哈希链：优先使用 /core/hash-chain.mjs ---------------- */
const encoder = new TextEncoder();
let coreHash = null;
export const HASH = { algorithm: 'SHA-256', backend: '检测中', available: false, core: false };
export const GENESIS_HASH = '0'.repeat(64);

function bytesToHex(bytes) {
  let out = '';
  for (let i = 0; i < bytes.length; i += 1) out += bytes[i].toString(16).padStart(2, '0');
  return out;
}
export async function sha256Hex(value) {
  let bytes;
  if (value instanceof Uint8Array) bytes = value;
  else if (value instanceof ArrayBuffer) bytes = new Uint8Array(value);
  else bytes = encoder.encode(String(value));
  if (globalThis.crypto && crypto.subtle) {
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return bytesToHex(new Uint8Array(digest));
  }
  return fallbackHashHex(bytes); // 降级（仅演示/受限环境）
}
function fallbackHashHex(bytes) {
  let h1 = 0x811c9dc5 >>> 0;
  let h2 = 0xcbf29ce4 >>> 0;
  for (let i = 0; i < bytes.length; i += 1) {
    h1 ^= bytes[i];
    h1 = Math.imul(h1, 0x01000193) >>> 0;
    h2 = (h2 + bytes[i] + ((h2 << 1) >>> 0)) >>> 0;
    h2 = Math.imul(h2 ^ (h2 >>> 13), 0x5bd1e995) >>> 0;
  }
  return h1.toString(16).padStart(8, '0') + h2.toString(16).padStart(8, '0');
}
export function canonicalJson(value) {
  return JSON.stringify(canonicalize(value));
}
function canonicalize(value) {
  if (value === null) return null;
  const t = typeof value;
  if (t === 'string' || t === 'boolean') return value;
  if (t === 'number') return Number.isFinite(value) ? value : null;
  if (t === 'undefined') return undefined;
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map(canonicalize);
  const out = {};
  for (const key of Object.keys(value).sort()) {
    if (value[key] === undefined) continue;
    out[key] = canonicalize(value[key]);
  }
  return out;
}
async function localCreateEvent(prevHash, event) {
  const normalized = {
    chain_version: '0.1.0',
    seq: event.seq,
    type: event.type,
    payload: event.payload ?? null,
    createdAt: event.createdAt || nowIso(),
    actor: event.actor || 'system',
    mode: event.mode || 'collab',
    aiRole: event.aiRole ?? null
  };
  const hash = await sha256Hex(canonicalJson({ ...normalized, prev_hash: prevHash }));
  return { ...normalized, prev_hash: prevHash, hash };
}
async function localVerifyChain(events) {
  let prev = GENESIS_HASH;
  for (let i = 0; i < events.length; i += 1) {
    const e = events[i];
    if (!e || e.prev_hash !== prev) return { ok: false, count: events.length, index: i, reason: 'prev_hash_mismatch' };
    if (i > 0 && e.seq !== events[i - 1].seq + 1) return { ok: false, count: events.length, index: i, reason: 'seq_mismatch' };
    const expected = await sha256Hex(canonicalJson({
      chain_version: '0.1.0', prev_hash: e.prev_hash, seq: e.seq, type: e.type,
      payload: e.payload, createdAt: e.createdAt, actor: e.actor, mode: e.mode, aiRole: e.aiRole
    }));
    if (expected !== e.hash) return { ok: false, count: events.length, index: i, reason: 'hash_mismatch' };
    prev = e.hash;
  }
  return { ok: true, count: events.length, lastHash: prev };
}
function headHash(events) {
  if (!events || !events.length) return GENESIS_HASH;
  return events[events.length - 1].hash;
}

export async function initEvidence() {
  // 哈希后端可用性
  try {
    if (globalThis.crypto && crypto.subtle) {
      await crypto.subtle.digest('SHA-256', new Uint8Array(1));
      HASH.available = true;
      HASH.backend = 'WebCrypto SHA-256';
    }
  } catch (e) {
    HASH.available = false;
    HASH.backend = '降级 FNV-1a-64（WebCrypto 不可用）';
    HASH.algorithm = 'FNV-1a-64';
  }
  state.hashAvailable = HASH.available;
  state.hashBackend = HASH.backend;
  // 共享 core 模块（由本地服务挂载；离线时降级）
  try {
    coreHash = await import('/core/hash-chain.mjs');
    HASH.core = !!(coreHash && coreHash.createEvent && coreHash.verifyChain);
  } catch (e) {
    coreHash = null;
    HASH.core = false;
  }
  updateHashPill();
  console.info(`[evidence] hashing=${HASH.backend}; core=${HASH.core ? 'hash-chain.mjs' : 'local fallback'}`);
}

export function updateHashPill() {
  const el = $('statusHash');
  if (el) el.textContent = HASH.available ? '哈希链：SHA-256 (WebCrypto)' : '哈希：降级 FNV-1a-64';
  const about = $('aboutHash');
  if (about) about.textContent = HASH.backend;
}

/* ---------------- 事件链（持久化 + 队列） ---------------- */
let chainPrev = GENESIS_HASH;
let chainSeq = 0;
let writeQueue = Promise.resolve();
let lastVerify = { ok: true, count: 0 };

export async function loadTimeline(events) {
  state.events = Array.isArray(events) ? events.slice() : [];
  chainPrev = headHash(state.events);
  chainSeq = state.events.length;
  if (state.events.length) {
    lastVerify = coreHash ? await coreHash.verifyChain(state.events) : await localVerifyChain(state.events);
    if (!lastVerify.ok) console.warn('[evidence] 事件链校验失败', lastVerify);
  } else {
    lastVerify = { ok: true, count: 0 };
  }
}

/** 记录一条链上事件（异步队列，保证串行与顺序） */
export function logEvent(type, payload = {}, opts = {}) {
  writeQueue = writeQueue.then(async () => {
    const eventInput = {
      type,
      payload,
      seq: chainSeq + 1,
      actor: opts.actor || 'user',
      mode: state.mode,
      aiRole: state.aiRole,
      createdAt: opts.createdAt || nowIso()
    };
    let ev;
    if (coreHash) {
      ev = await coreHash.createEvent(chainPrev, eventInput);
    } else {
      ev = await localCreateEvent(chainPrev, eventInput);
    }
    chainSeq += 1;
    chainPrev = ev.hash;
    state.events.push(ev);
    if (!state.persistencePaused) await saveEventRecord(ev).catch((e) => console.warn('[evidence] 事件持久化失败', e));
    emit('events:changed', ev);
  }).catch((e) => console.warn('[evidence] logEvent failed', e));
  return writeQueue;
}
export async function flushEventQueue() { try { await writeQueue; } catch (e) { /* 忽略 */ } }

export async function verifyTimeline() {
  lastVerify = coreHash ? await coreHash.verifyChain(state.events) : await localVerifyChain(state.events);
  return lastVerify;
}

/* ---------------- L6 派生记录 ---------------- */
function l6Base(kind, anchorRect, extra = {}) {
  return {
    id: 'L6-' + uid('g'),
    asset_id: state.projectId,
    layer: 'L6',
    anchor: anchorRect
      ? { type: 'bbox', value: [Math.round(anchorRect.x), Math.round(anchorRect.y), Math.round(anchorRect.w), Math.round(anchorRect.h)] }
      : { type: 'whole', value: null },
    source: 'inferred',
    author: 'ai',
    mode: state.mode,
    ai_role: state.aiRole,
    created_at: nowIso(),
    schema_version: SCHEMA_VERSION,
    ...extra
  };
}
function storeL6(record) {
  state.generations.push(record);
  if (!state.persistencePaused) saveGenerationRecord(record).catch((e) => console.warn('[evidence] L6 持久化失败', e));
  emit('archive:changed');
  return record;
}

export function recordCritique({ request, result, latencyMs, selection, analysisObsIds = [] }) {
  const record = l6Base('critique', selection, {
    kind: 'critique',
    model: { provider: 'local', model: result?.model || 'mock-ai@0.1.0' },
    params: { selection: request?.selection || null, mode: request?.context?.mode || state.mode, count: analysisObsIds.length },
    input_refs: analysisObsIds,
    output_asset_id: null,
    assertions: [{ label: 'inkproof.mock', data: true }],
    accepted: null,
    latency_ms: Math.round(latencyMs || 0),
    note: 'Mock AI 观察（本地确定性规则，非真实模型）'
  });
  return storeL6(record);
}

export function recordGeneration({ proposal, direction, latencyMs, inputRefs = [] }) {
  const record = l6Base('generation', proposal.rect, {
    kind: 'generation',
    model: { provider: 'local', model: proposal.model || 'mock-ai@0.1.0' },
    params: {
      direction_id: direction?.id || proposal.directionId || null,
      direction_title: direction?.title || null,
      filter: proposal.filter || null,
      overlay: proposal.overlay || null,
      mask: proposal.rect ? [Math.round(proposal.rect.x), Math.round(proposal.rect.y), Math.round(proposal.rect.w), Math.round(proposal.rect.h)] : null
    },
    input_refs: inputRefs,
    output_asset_id: proposal.id,
    mask_ref: proposal.rect ? `rect:${Math.round(proposal.rect.x)},${Math.round(proposal.rect.y)},${Math.round(proposal.rect.w)},${Math.round(proposal.rect.h)}` : null,
    accepted: false,
    accepted_at: null,
    output_layer_id: null,
    cost_cny: 0,
    credits: 0,
    latency_ms: Math.round(latencyMs || 0),
    assertions: [{ label: 'inkproof.mock', data: true }]
  });
  return storeL6(record);
}

export function markGenerationAccepted(generationId, layer) {
  const record = state.generations.find((g) => g.id === generationId);
  if (!record) return;
  record.accepted = true;
  record.accepted_at = nowIso();
  record.output_layer_id = layer.id;
  saveGenerationRecord(record).catch((e) => console.warn(e));
  emit('archive:changed');
}

export function recordModeChangeL6(fromMode, toMode) {
  const record = l6Base('mode_change', null, {
    kind: 'mode_change',
    model: { provider: 'local', model: 'inkproof-app@' + APP_VERSION },
    params: { from: fromMode, to: toMode },
    input_refs: [],
    assertions: [],
    from_mode: fromMode,
    to_mode: toMode,
    actor: 'user'
  });
  return storeL6(record);
}
export function recordRoleChangeL6(fromRole, toRole) {
  const record = l6Base('role_change', null, {
    kind: 'role_change',
    model: { provider: 'local', model: 'inkproof-app@' + APP_VERSION },
    params: { from: fromRole, to: toRole },
    input_refs: [],
    assertions: [],
    from_role: fromRole,
    to_role: toRole,
    actor: 'user'
  });
  return storeL6(record);
}

/* ---------------- 证据包构建 ---------------- */
async function hashLayerCanvases() {
  const out = [];
  for (let i = 0; i < state.layers.length; i += 1) {
    const layer = state.layers[i];
    const buf = await canvasToArrayBuffer(layer.canvas);
    out.push({
      id: layer.id,
      name: layer.name,
      kind: layer.kind,
      visible: layer.visible,
      opacity: layer.opacity,
      order: i,
      bbox: layer.bbox,
      ai_generation_id: layer.aiMeta?.generationId || null,
      sha256: await sha256Hex(buf),
      png_bytes: buf.byteLength,
      file: `layers/${layer.id}.png`
    });
  }
  return out;
}

export async function buildEvidencePackage() {
  renderCanvas();
  await flushEventQueue();
  const now = new Date();
  const modeStarted = state.modeStartedAt ? new Date(state.modeStartedAt) : now;
  const canvasBuf = await canvasToArrayBuffer(getCompositeCanvas());
  const canvasHash = await sha256Hex(canvasBuf);
  const layers = await hashLayerCanvases();
  const chain = await verifyTimeline();
  const timeline = state.events.map((e) => ({ ...e }));
  const archive = state.archive.map((r) => ({ ...r }));
  const generations = state.generations.map((g) => ({ ...g }));
  const crit = generations.filter((g) => g.kind === 'critique');
  const gens = generations.filter((g) => g.kind === 'generation');
  const acceptedGens = gens.filter((g) => g.accepted);
  const afterSwitch = generations.filter((g) => new Date(g.created_at) >= modeStarted);
  const genAfterSwitch = afterSwitch.filter((g) => g.kind === 'generation');
  // “AI 活动”只统计生成/观察，不含 mode_change 等元记录
  const aiActivityAfterSwitch = afterSwitch.filter((g) => g.kind === 'generation' || g.kind === 'critique');
  const zeroGeneration = state.mode === 'attest' && genAfterSwitch.length === 0;
  const zeroAiActivity = state.mode === 'attest' && aiActivityAfterSwitch.length === 0;
  const humanStrokes = timeline.filter((e) => e.type === 'stroke').length;
  const manifest = {
    tool: { name: '墨证 InkProof', version: APP_VERSION, form: 'local-first ESM web app', mock: true },
    contract_version: CONTRACT_VERSION,
    schema_version: SCHEMA_VERSION,
    exported_at: now.toISOString(),
    mode: state.mode,
    zero_generation: zeroGeneration,
    hashing: { algorithm: HASH.algorithm, backend: HASH.backend, available: HASH.available },
    integrity_scope: '本证据包含 canvas.png 与 JSON 两个文件；manifest 列出画布与各图层 PNG 的 SHA-256，可逐项复核',
    files: [
      { path: 'canvas.png', kind: 'canvas', sha256: canvasHash, bytes: canvasBuf.byteLength },
      ...layers.map((l) => ({ path: l.file, kind: 'layer', layer_id: l.id, name: l.name, sha256: l.sha256, bytes: l.png_bytes }))
    ],
    chain: {
      algorithm: 'SHA-256',
      chain_version: '0.1.0',
      count: chain.count,
      head: chain.lastHash || headHash(timeline),
      verified: chain.ok === true,
      reason: chain.reason || null,
      checkpoint: await sha256Hex(canonicalJson({ count: chain.count, head: chain.lastHash || headHash(timeline) }))
    },
    ai_events: { count: generations.length, hidden: false, note: 'AI 参与记录不可隐藏（这是可可信的前提）' },
    archive_counts: archive.reduce((acc, r) => { acc[r.layer] = (acc[r.layer] || 0) + 1; return acc; }, {})
  };
  return {
    format: 'inkproof.evidence',
    format_version: 1,
    schema_version: SCHEMA_VERSION,
    app: {
      name: '墨证 InkProof',
      version: APP_VERSION,
      local_first: true,
      mock_ai: true,
      network_requests: 0,
      generated_at: now.toISOString()
    },
    exported_at: now.toISOString(),
    mode: state.mode,
    mode_label: state.mode === 'attest' ? '存证模式' : '协作模式',
    zero_generation: zeroGeneration,
    zero_ai_activity: zeroAiActivity,
    scope: {
      project_id: state.projectId,
      project_name: state.projectName,
      canvas: { width: 1200, height: 800, file: 'canvas.png', sha256: canvasHash, bytes: canvasBuf.byteLength },
      layer_count: state.layers.length,
      mode_started_at: state.modeStartedAt,
      session_id: state.sessionId
    },
    layers,
    timeline,
    archive_records: archive,
    generations,
    summary: {
      human_stroke_events: humanStrokes,
      human_decisions: archive.filter((r) => r.layer === 'L5').length,
      ai_critique_events: crit.length,
      ai_generation_events: gens.length,
      ai_generation_accepted: acceptedGens.length,
      ai_events_total: generations.length,
      zero_generation: zeroGeneration
    },
    manifest,
    no_generation_attestation: {
      active: state.mode === 'attest',
      scope: { from: state.modeStartedAt, to: now.toISOString() },
      generation_calls_in_scope: genAfterSwitch.length,
      ai_events_in_scope: aiActivityAfterSwitch.length,
      statement: state.mode === 'attest'
        ? '本作品自进入存证模式起，未调用任何生成模型（本应用为本地 Mock AI，全程无真实模型调用）。'
        : '当前为协作模式，不做零生成声明；全部 AI 参与事件见 generations（不可隐藏）。',
      disclaimer: '本证据包不证明创作者未在其他工具或平台上使用 AI，也不构成法律意义上的作者身份证明；v0.1 无第三方时间戳与数字签名。'
    },
    c2pa_like: {
      note: '字段结构对齐 C2PA 草稿，v0.1 不签名、不做第三方时间戳验证',
      claim_generator: `墨证 InkProof ${APP_VERSION}`,
      assertions: [
        { label: 'inkproof.mode', data: { mode: state.mode, zero_generation: zeroGeneration, mode_started_at: state.modeStartedAt } },
        { label: 'inkproof.ai_events', data: { count: generations.length, hidden: false, mock: true } },
        { label: 'inkproof.chain', data: { head: manifest.chain.head, checkpoint: manifest.chain.checkpoint, verified: manifest.chain.verified } }
      ]
    },
    readme: [
      '本证据包记录作品在本工具内的创作过程：哪些操作由人完成、AI 在哪些步骤参与、每次生成用了哪些档案与选区。',
      '它不能证明创作者未使用其他工具，也不构成法律意义上的作者身份证明（v0.1 无第三方时间戳/签名）。',
      `本作品模式：${state.mode === 'attest' ? '存证模式（no_generation_attestation：创作期未调用生成模型）' : '协作模式（包含 AI 参与事件）'}。`,
      '校验方法：对 canvas.png 计算 SHA-256，与 manifest.files 中 canvas.png 的 sha256 比对；事件链可用 /core/hash-chain.mjs verifyChain 复核。',
      '⚠️ 本应用默认使用本地 Mock AI（确定性规则 + canvas 滤镜），未调用真实模型、无网络请求。'
    ].join('\n')
  };
}

/* ---------------- 证据包弹层 ---------------- */
export async function openEvidenceModal() {
  const modal = $('evidenceModal');
  const body = $('evidenceBody');
  if (!modal || !body) return;
  modal.classList.add('open');
  body.innerHTML = `<div class="progress-wrap">
      <div class="progress-label"><span>正在计算画布与图层 SHA-256、校验事件链…</span><span>本地计算</span></div>
      <div class="progress"><i></i></div>
    </div>`;
  try {
    const pkg = await buildEvidencePackage();
    state._evidencePackage = pkg;
    body.innerHTML = evidenceBodyHtml(pkg);
  } catch (e) {
    console.error(e);
    body.innerHTML = `<div class="statement warn">生成证据包失败：${escapeHtml(e.message || String(e))}</div>`;
  }
}

function evidenceBodyHtml(pkg) {
  const backend = pkg.manifest.hashing;
  const chain = pkg.manifest.chain;
  const layerRows = pkg.manifest.files.filter((f) => f.kind === 'layer').map((f) => `
    <div class="hash-row">
      <div><span style="color:#93a9c4">${escapeHtml(f.path)}</span> <span style="color:#5f7692">· ${f.bytes} bytes${f.name ? ' · ' + escapeHtml(f.name) : ''}</span></div>
      <div class="h">${f.sha256}</div>
    </div>`).join('');
  const genBadge = pkg.zero_generation
    ? '<span class="src-badge user-confirmed" style="font-size:11px">✓ 零 AI 生成（零生成声明已写入）</span>'
    : '<span class="src-badge inferred" style="font-size:11px">◇ 含 AI 参与事件（如实记录，不可隐藏）</span>';
  const att = pkg.no_generation_attestation;
  const events = pkg.timeline.slice(-8).reverse().map((e) => `<div class="archive-row" style="padding:6px 9px"><span class="layer-tag L6">${escapeHtml(e.type)}</span><span style="color:#a9bfdc;font-size:11px">${fmtTime(e.createdAt)}</span><div class="meta"><span>seq ${e.seq}</span><span class="h" style="color:#7dd3fc;font-size:9.5px">${escapeHtml(String(e.hash).slice(0, 16))}…</span></div></div>`).join('');
  return `
    <div class="stat-grid">
      <div class="stat"><div class="k">作品模式</div><div class="v">${pkg.mode_label}</div></div>
      <div class="stat"><div class="k">时间线事件</div><div class="v">${pkg.timeline.length}</div></div>
      <div class="stat"><div class="k">AI 事件（不可隐藏）</div><div class="v">${pkg.generations.length}</div></div>
      <div class="stat"><div class="k">零生成 zero_generation</div><div class="v ${pkg.zero_generation ? 'good' : 'warn'}">${pkg.zero_generation ? 'true' : 'false'}</div></div>
      <div class="stat"><div class="k">图层数</div><div class="v">${pkg.layers.length}</div></div>
      <div class="stat"><div class="k">人类笔触事件</div><div class="v">${pkg.summary.human_stroke_events}</div></div>
      <div class="stat"><div class="k">AI 观察 / 生成</div><div class="v">${pkg.summary.ai_critique_events} / ${pkg.summary.ai_generation_events}</div></div>
      <div class="stat"><div class="k">哈希链校验</div><div class="v ${chain.verified ? 'good' : 'bad'}">${chain.verified ? '通过' : '失败'}</div></div>
    </div>
    <div class="ev-block">
      <h3>零生成 / AI 参与范围声明 <span class="hint">${pkg.mode_label}</span></h3>
      <div class="statement ${pkg.zero_generation ? '' : 'warn'}">${genBadge}<br><br>
        <b>声明：</b>${escapeHtml(att.statement)}<br>
        <b>范围：</b>${fmtTime(att.scope.from)} → ${fmtTime(att.scope.to)}<br>
        <b>不承诺：</b>${escapeHtml(att.disclaimer)}
      </div>
    </div>
    <div class="ev-block">
      <h3>文件完整性 <span class="hint">${backend.backend} · 可用任何 SHA-256 工具复核</span></h3>
      <div class="hash-row" style="margin-bottom:6px">
        <div><span style="color:#93a9c4">canvas.png</span> <span style="color:#5f7692">· ${pkg.scope.canvas.bytes} bytes（当前画布）</span></div>
        <div class="h" style="color:#7dd3fc">${pkg.scope.canvas.sha256}</div>
      </div>
      ${layerRows}
    </div>
    <div class="ev-block">
      <h3>事件哈希链 <span class="hint">SHA-256 前后链接 · 最近 ${Math.min(8, pkg.timeline.length)} 条</span></h3>
      <div class="hash-row" style="margin-bottom:7px">
        <div>链头 hash</div><div class="h">${chain.head}</div>
        <div>checkpoint</div><div class="h">${chain.checkpoint}</div>
      </div>
      ${events || '<div class="arch-empty">暂无事件</div>'}
    </div>
    <div class="ev-block">
      <h3>manifest.json 预览</h3>
      <pre class="manifest-pre">${escapeHtml(JSON.stringify(pkg.manifest, null, 2))}</pre>
    </div>
    <div class="ev-block">
      <h3>本证据包能证明什么 / 不能证明什么</h3>
      <div class="statement warn">
        <b>能证明：</b>本作品在本工具内的操作时间线、哪些笔触由人完成、AI 在哪些步骤参与（含 mock 模型标识/参数/引用档案）、导出时画布与图层的 SHA-256 指纹、事件链未被篡改（本地复核）。<br>
        <b>不能证明：</b>创作者没有在其他工具中使用 AI；跳过本工具的操作；法律意义上的作者身份（无第三方时间戳/签名）。<br>
        <b>本应用：</b>默认 AI 为本地 Mock；哈希、事件链与时间线为真实本地计算。
      </div>
    </div>`;
}

/* ---------------- 下载 ---------------- */
export async function downloadEvidenceJson() {
  let pkg = state._evidencePackage;
  if (!pkg) pkg = await buildEvidencePackage();
  await logEvent('evidence_exported', { format: 'json', sha256: pkg.scope.canvas.sha256, zero_generation: pkg.zero_generation });
  downloadBlob(`证据包_墨证InkProof_${fileStamp()}.json`, new Blob([JSON.stringify(pkg, null, 2)], { type: 'application/json;charset=utf-8' }));
  toast('证据包 JSON 已下载（含 manifest 与哈希链）', 'ok', 3000);
  return pkg;
}
export async function downloadEvidencePng() {
  await logEvent('canvas_png_exported', { width: 1200, height: 800 });
  const blob = await canvasToBlob(getCompositeCanvas());
  downloadBlob(`画布_墨证InkProof_${fileStamp()}.png`, blob);
  toast('当前画布 PNG 已下载', 'ok');
}
export async function downloadEvidenceBoth() {
  await downloadEvidenceJson();
  await new Promise((r) => setTimeout(r, 350));
  await downloadEvidencePng();
}

/** 供 About 面板显示统计 */
export function evidenceStats() {
  return {
    events: state.events.length,
    archive: state.archive.length,
    generations: state.generations.length,
    chainOk: lastVerify.ok
  };
}
