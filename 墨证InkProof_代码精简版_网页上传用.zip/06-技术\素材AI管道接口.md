# 素材 AI 管道接口（T105-A）

> 模块：`v2/app/core/asset-ai.mjs` · 版本 `asset-ai@1.0.0`
> 测试：`v2/qa/tools/asset-ai-test.mjs`（Node，零依赖，10/10 PASS）
> 定位：**纯逻辑**。无 DOM / IndexedDB / fetch / 文件系统；不写数据库、不发网络请求。供 app.js 集成，但本任务不改 app.js / engine / CSS / HTML。

## 1. 数据契约

与 `v2/library/library-schema.mjs` 的 asset 兼容，输入可包含：

```js
{
  id, sha256, fileName, mime, bytes, width, height,
  tags: string[], palette: string[], usageCount,
  L0, L1, L2[], L4[], L5[],
  source: ['observed','inferred','user-confirmed'],
  modelVersion, analysisSource: 'mock'|'real'|null,
  analysis: { source, provider, model, at, latency_ms, usage },
  provenance: { source, provider, model, prompt, refs[], candidate_sha256, generated_at },
  projectRefs: [], createdAt, updatedAt
}
```

所有函数遇到空数组 / 缺字段 / `null` 均应安全返回（不抛异常，除非 `mergeRealAnalysis` 的 asset 非对象）。

## 2. 接口签名

### 2.1 `buildAssetKnowledge(asset) -> object`

精简素材知识，用于本地检索/推荐/提示词拼装：

```js
{
  id, sha256, fileName, mime, bytes, width, height,
  summary, subject[], mood[], medium, tags[], palette[],
  regionLabels: string[],
  observationTexts: string[],
  regions: [{id,label,bbox,importance}],
  observations: [{id,kind,text,confidence}],
  source[], sourceInfo: {l0:{fileName,sha256,importedAt}, provenance:{source,provider,model,prompt,refsCount,candidate_sha256,generated_at}},
  analysisSource: 'mock'|'real'|'unknown',
  modelVersion, usageCount, projectRefsCount,
  createdAt, updatedAt,
  searchText // 归一化后的可检索文本，供调试
}
```

### 2.2 `scoreAssetForQuery(asset, query) -> number`

返回 `0..1`。命中信号与权重（上限 1）：

| 信号 | 权重 |
|---|---|
| 完整 query 命中文件名/标签/L1/区域/L4 | 0.50（单字 0.28） |
| 标签包含词 | 0.30 |
| 文件名包含词 | 0.20 |
| L1 summary/subject/mood/medium 包含词 | 0.18 |
| L2 label 包含词 | 0.14 |
| L4 text 包含词 | 0.10 |
| provenance prompt/model 包含词 | 0.08 |
| 色板语义（蓝色/暖色/#hex 等） | 0.18–0.30 |
| 中文 bigram / 英文编辑距离模糊匹配 | 最多 0.18 |

- 中文查询按原词 + bigram + 单字分词，带同义词扩展（山水/雾/光/暖冷/颜色/建筑/留白/水墨…，见模块 `SYNONYM_GROUPS`）。
- 色板：支持中文颜色词、`#RRGGBB`、暖/冷/低饱和/高饱和，按 RGB 距离或 HSL 判断。
- 模糊匹配：中文 bigram Dice；英文 Dice + Levenshtein，阈值 0.58 后加分。

### 2.3 `rankAssetsForQuery(assets, query, limit = 8) -> Array<{asset, score, reasons[]}>`

- 非空 query：只返回 `score > 0` 的素材，按 score → usageCount → updatedAt → id 降/升序稳定排序，截断 limit。
- 空 query：按原顺序返回前 limit 个，`score=0`，便于“空搜索展示全部”。
- 不修改入参；`limit=0` 或空数组返回 `[]`。

### 2.4 `rankAssetsForSelection(assets, {intent, palette, selection, limit = 6}) -> Array<{asset, score, reasons[]}>`

纯启发式给画布/选区推荐素材：

```js
score = intentScore*0.62 + paletteOverlap*0.24 + selectionTextScore*0.10 + usageBoost(≤0.05)
```

- `palette` 支持 `string[]` 或 `[{hex}]`；`selection` 可含 `{label,text,tags[],palette[]}`。
- 色板相似度按每个查询色取素材 palette 最近色的平均 RGB 相似度。
- 返回结构与 `rankAssetsForQuery` 一致；空输入返回 `[]`。

### 2.5 `selectAssetsForBatchRead(assets, {onlyMock = false}) -> asset[]`

需要真实视觉重读的队列：

- 已 `analysisSource==='real'` 或 `analysis.source==='real'` 的素材**排除**。
- 默认返回所有尚未真实读的素材；**缺 L1（summary/subject/palette 皆空）优先**，再按 updatedAt 升序。
- `onlyMock=true` 只返回显式 mock：`analysisSource==='mock'` 或 `modelVersion` 以 `mock` 开头；来源未知（null）不包含。
- 返回原 asset 引用数组（不复制），供现有 `reanalyzeAssetReal(a)` 逐条消费。

### 2.6 `mergeRealAnalysis(asset, analysis, meta) -> partialAsset`

真实视觉结果合并，**只返回可 `Object.assign(asset, partial)` 的字段**，不写库、不修改入参：

```js
{
  L1, L2, L4, tags, palette, modelVersion,
  analysisSource: 'real',
  analysis: {
    source: 'real', provider, model, at,
    latency_ms, usage, confidence, regions, observations, skill
  },
  source, updatedAt
}
```

语义：
- `analysis` 接受 provider normalize 结构：`{global,regions,observations,confidence,meta}`（也兼容直接传 L1/L2/L4）。
- `meta`：`{provider,model,modelVersion,latencyMs,usage,at,skill}`，优先级 meta > analysis.meta > 旧 asset。
- **旧 tags 全部保留**，追加 subject/mood/medium/region labels，再加 `真实AI重读`，去重后截 32。
- L2/L4 用新结果；新结果为空时保留旧值。
- **旧 L4 中 `source==='user-confirmed'` 的条目保留**（除非新结果 id 冲突），避免真实重读覆盖用户确认。
- palette 新结果优先；新结果为空保留旧 palette。
- 不返回 L0/L5，调用方无需改动它们。

示例：

```js
const partial = mergeRealAnalysis(latest, res, {
  provider: run.meta.provider, modelVersion: latest.modelVersion,
  latencyMs: run.log?.latencyMs, usage: run.meta.usage, at: iso(),
});
Object.assign(latest, partial);
await api.store.put(latest);
```

### 2.7 `summarizeProvenance(asset) -> object`

来源/引用/模型摘要（用于素材详情“来源”区）：

```js
{
  fileName, sha256, source, sourceLabel, provider, model, modelVersion,
  prompt, candidate_sha256, generated_at, importedAt, createdAt, updatedAt,
  analysisSource, modelVersionSource, refCount, refs[{asset_id,fileName,sha256}],
  usageCount, confirmations, rejections, decisions,
  layers: {L0:boolean,L1:boolean,L2:number,L4:number,L5:number},
  summary, // 'AI 生成 · qwen/qwen-image-3.0 · 引用 1 次'
  chain[]  // 简短 L0/L1/确认链
}
```

来源判定优先级：`provenance.source` → `AI生成` 标签/candidate_sha256 → 有 L0/fileName 视为 imported → unknown。

## 3. 集成建议（app.js 将来只调这几处）

| app.js 位置 | 现状 | 建议 |
|---|---|---|
| `libFilterAssets()` 本地搜索（约 line 3748） | `hay.includes(query)` | `const ranked = rankAssetsForQuery(list, query, 50); return ranked.map(x=>x.asset);`；保留 filter/tag 逻辑 |
| 素材库/参考条“推荐素材” | 无 | `rankAssetsForSelection(state.library.assets, {intent: state.aiImagePrompt || state.selectedDirection?.title, palette: state.analysis?.global?.palette, selection: state.selection, limit: 3})` |
| 批量“真实重读”入口 | 逐条手动 | `for (const a of selectAssetsForBatchRead(state.library.assets, {onlyMock: true})) await reanalyzeAssetReal(a);` |
| `reanalyzeAssetReal()` 合并块（约 line 4077–4090） | 手工拼 L1/L2/L4/tags | 替换为 `Object.assign(latest, mergeRealAnalysis(latest, res, meta))`，L6/证据逻辑不动 |
| 素材详情“来源”区 | 零散字段 | `summarizeProvenance(a)`，直接渲染 sourceLabel/model/refs/L5 计数 |
| 提示词/素材摘要 | 手工拼字段 | `buildAssetKnowledge(a)` 取 summary/subject/regions/observationTexts |

集成注意：
- 不改变现有 `library-schema.mjs` / IndexedDB 结构；merge 结果可直接 `store.put`。
- `rank*` 返回 `{asset,...}` 包装；UI 列表需 `.map(x => x.asset)`。
- 搜索排序需保留原有 filter/tag 过滤，再对过滤结果调用 rank。
- 真实重读前仍走现有确认/隐私/开关；本模块不发起调用。
- 本模块不改 `analysisSource` 之外的持久字段；merge 才会写 `analysisSource='real'`。

## 4. 测试

```bash
node v2/qa/tools/asset-ai-test.mjs
```

覆盖 10 个场景：
1. 模块导出/无浏览器全局依赖/文本归一化
2. buildAssetKnowledge 字段
3. 中文标签/L1/区域命中；无关为 0
4. 中文同义词/模糊（雾气→雾带、山峦→远山）
5. 色板（蓝色/hex/暖色）
6. 排序/limit/不修改入参/空 query
7. 空数组与空输入
8. 选区推荐（意图+色板）
9. 批量重读筛选（mock/未知/真实排除/缺 L1 优先）
10. merge 保留旧标签/用户确认 L4/模型/来源/不可变；provenance 摘要

验收：全部通过，`exit 0`。

## 5. 限制与后续

- 纯本地启发式，不引入 embedding/模型；词表与颜色词可继续扩充 `SYNONYM_GROUPS` / `COLOR_TARGETS`。
- 模糊匹配针对短查询；长 L4 文本不做全文模糊，避免误召回。
- 批量重读不做并发/限流；调用方应按既有代理串行/开关执行。
- 本任务只交付模块/测试/文档；app.js 接线属于 T105-B，不在此次改动范围。
