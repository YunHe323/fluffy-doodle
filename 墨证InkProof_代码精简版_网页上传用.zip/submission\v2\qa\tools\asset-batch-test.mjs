// v2/qa/tools/asset-batch-test.mjs — T106-A asset-batch.mjs 单测（Node，无浏览器/网络）
// 运行：node v2/qa/tools/asset-batch-test.mjs   exit 0 = 全过
import assert from 'node:assert/strict';
import {
  ASSET_BATCH_VERSION,
  DEFAULT_BATCH_LIMIT,
  planBatchRead,
  BatchQueue,
  mergeBatchResults,
  summarizeBatch,
} from '../../app/core/asset-batch.mjs';

const results = [];
async function test(name, fn) {
  try { await fn(); results.push({ name, pass: true }); }
  catch (e) { results.push({ name, pass: false, error: String(e && (e.stack || e.message || e)) }); }
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function mkAsset(id, opts = {}) {
  return {
    id: `asset-${id}`,
    fileName: `${id}.png`,
    createdAt: '2026-11-01T00:00:00.000Z',
    updatedAt: opts.updatedAt || '2026-11-02T00:00:00.000Z',
    tags: [], palette: [], L2: [], L4: [], L5: [], source: ['observed', 'inferred'],
    L1: { layer: 'L1', source: 'inferred', confidence: 0.8, summary: '画面摘要', subject: ['山'], medium: { kind: '水墨' }, palette: ['#7f97a8'], mood: ['安静'] },
    modelVersion: 'mock-ai@0.1.0', analysisSource: 'mock',
    ...opts,
  };
}
function mkPlan(ids) {
  return ids.map((id, i) => ({ id, fileName: `${id}.png`, reason: 'test', priority: 0 }));
}

await test('0 模块版本/默认 limit', () => {
  assert.match(ASSET_BATCH_VERSION, /^asset-batch@/);
  assert.equal(DEFAULT_BATCH_LIMIT, 3);
  assert.equal(typeof planBatchRead, 'function');
  assert.equal(typeof BatchQueue, 'function');
  assert.equal(typeof mergeBatchResults, 'function');
  assert.equal(typeof summarizeBatch, 'function');
});

await test('1 planBatchRead：优先级/limit/默认 onlyMock/不修改资产', async () => {
  const aNoL1 = mkAsset('no-l1', { L1: { layer: 'L1', source: 'inferred', confidence: 0.2, summary: '', subject: [], medium: null, palette: [], mood: [] }, updatedAt: '2026-10-01T00:00:00.000Z' });
  const bLow = mkAsset('low', { L1: { layer: 'L1', source: 'inferred', confidence: 0.4, summary: '低置信素材', subject: ['雾'], medium: null, palette: [], mood: [] }, updatedAt: '2026-10-02T00:00:00.000Z' });
  const cOk = mkAsset('ok', { updatedAt: '2026-10-03T00:00:00.000Z' });
  const dReal = mkAsset('real', { modelVersion: 'qwen3.8-max', analysisSource: 'real', analysis: { source: 'real' }, updatedAt: '2026-10-04T00:00:00.000Z' });
  const assets = [dReal, cOk, bLow, aNoL1];
  const before = JSON.stringify(assets);
  const plan = planBatchRead(assets, { limit: 2 });
  assert.deepEqual(plan.map((x) => x.id), [aNoL1.id, bLow.id]);
  assert.equal(plan[0].priority, 0);
  assert.ok(plan[0].reason.includes('L1'));
  assert.equal(plan[1].priority, 1);
  assert.ok(plan[1].reason.includes('置信度'));
  assert.deepEqual(Object.keys(plan[0]).sort(), ['fileName', 'id', 'priority', 'reason']);
  assert.equal(JSON.stringify(assets), before, 'plan 不修改资产');
  const all = planBatchRead(assets, { limit: 10 });
  assert.equal(all.length, 3);
  assert.equal(all.some((x) => x.id === dReal.id), false, '默认排除已真实读');
  const withReal = planBatchRead(assets, { limit: 10, onlyMock: false });
  assert.equal(withReal.length, 4);
  assert.equal(withReal[withReal.length - 1].id, dReal.id);
  assert.equal(withReal[withReal.length - 1].priority, 3);
});

await test('2 planBatchRead：空数组/limit 0/缺 id 安全', async () => {
  assert.deepEqual(planBatchRead([], {}), []);
  assert.deepEqual(planBatchRead(null, {}), []);
  const list = [mkAsset('a'), { fileName: 'no-id.png' }];
  assert.equal(planBatchRead(list, { limit: 5 }).length, 1);
  assert.deepEqual(planBatchRead(list, { limit: 0 }), []);
  assert.deepEqual(planBatchRead(list, { limit: -1 }), []);
});

await test('3 BatchQueue 串行成功：1/1、顺序、进度、onItem、summary', async () => {
  const calls = []; let active = 0; let maxActive = 0;
  const progress = []; const doneItems = [];
  const q = new BatchQueue(mkPlan(['1', '2', '3']), async (item, ctx) => {
    calls.push(item.id);
    assert.ok(ctx.signal instanceof AbortSignal);
    assert.equal(ctx.queue, q);
    active += 1; maxActive = Math.max(maxActive, active);
    await sleep(3);
    active -= 1;
    return { analysisSource: 'real', analysis: { global: { summary: '真实 ' + item.id } }, meta: { provider: 'qwen', modelVersion: 'qwen3.8-max' } };
  });
  const st = await q.run({ concurrency: 1, onProgress: (p) => progress.push(p), onItem: (it, res) => doneItems.push([it.id, it.status, !!res]) });
  assert.equal(st.status, 'done');
  assert.deepEqual(calls, ['1', '2', '3']);
  assert.equal(maxActive, 1, '默认串行，最大并发应为 1');
  assert.equal(doneItems.length, 3);
  assert.deepEqual(doneItems.map((x) => x[1]), ['done', 'done', 'done']);
  assert.ok(progress.length >= 3);
  assert.equal(progress[progress.length - 1].done, 3);
  assert.equal(progress[progress.length - 1].pending, 0);
  assert.equal(progress[progress.length - 1].status, 'done');
  assert.equal(q.state.items.every((it) => it.status === 'done'), true);
  assert.deepEqual(summarizeBatch(q), { total: 3, done: 3, failed: 0, pending: 0, real: 3, cancelled: 0 });
  await assert.rejects(() => q.run(), /只能调用一次/);
});

await test('4 BatchQueue 失败不阻塞后续；部分失败整体 done；summary failed', async () => {
  const calls = [];
  const q = new BatchQueue(mkPlan(['a', 'b', 'c']), async (item) => {
    calls.push(item.id);
    await sleep(2);
    if (item.id === 'b') throw Object.assign(new Error('boom'), { code: 'mock_fail' });
    return { analysisSource: 'real', analysis: { global: { summary: 'ok' } } };
  });
  const st = await q.run({ concurrency: 1 });
  assert.deepEqual(calls, ['a', 'b', 'c']);
  assert.equal(st.status, 'done');
  assert.deepEqual(st.items.map((x) => x.status), ['done', 'failed', 'done']);
  assert.equal(st.items[1].error, 'boom');
  assert.equal(st.items[1].errorCode, 'mock_fail');
  assert.deepEqual(summarizeBatch(st), { total: 3, done: 2, failed: 1, pending: 0, real: 2, cancelled: 0 });
});

await test('5 BatchQueue cancel：中途取消不启动后续，状态 cancelled', async () => {
  const calls = [];
  let startedResolve; const started = new Promise((r) => { startedResolve = r; });
  const q = new BatchQueue(mkPlan(['1', '2', '3', '4']), async (item) => {
    calls.push(item.id);
    if (item.id === '1') {
      startedResolve();
      await sleep(30);
    }
    return { analysisSource: 'real', analysis: { global: { summary: 'ok' } } };
  });
  const runPromise = q.run({ concurrency: 1 });
  await started;
  q.cancel();
  assert.equal(q.state.status, 'cancelled');
  const st = await runPromise;
  assert.equal(st.status, 'cancelled');
  assert.deepEqual(calls, ['1'], '取消后不再启动后续项');
  const cancelled = st.items.filter((x) => x.status === 'cancelled').length;
  assert.equal(cancelled, 3);
  assert.deepEqual(summarizeBatch(st), { total: 4, done: 1, failed: 0, pending: 0, real: 1, cancelled: 3 });
});

await test('6 BatchQueue cancel 在 run 之前：不执行任何 item', async () => {
  let calls = 0;
  const q = new BatchQueue(mkPlan(['a', 'b']), async () => { calls += 1; return {}; });
  q.cancel();
  const st = await q.run();
  assert.equal(calls, 0);
  assert.equal(st.status, 'cancelled');
  assert.equal(st.items.every((x) => x.status === 'cancelled'), true);
  assert.deepEqual(summarizeBatch(st), { total: 2, done: 0, failed: 0, pending: 0, real: 0, cancelled: 2 });
});

await test('7 BatchQueue 空计划：done、进度最终回调、summary 全 0', async () => {
  const progress = [];
  const q = new BatchQueue([], async () => { throw new Error('不应运行'); });
  const st = await q.run({ onProgress: (p) => progress.push(p) });
  assert.equal(st.status, 'done');
  assert.equal(progress.length, 1);
  assert.equal(progress[0].total, 0);
  assert.deepEqual(summarizeBatch(st), { total: 0, done: 0, failed: 0, pending: 0, real: 0, cancelled: 0 });
});

await test('8 BatchQueue 全部失败：status failed、失败不吞异常', async () => {
  const q = new BatchQueue(mkPlan(['x', 'y']), async () => { throw new Error('all bad'); });
  const st = await q.run({ concurrency: 1 });
  assert.equal(st.status, 'failed');
  assert.equal(st.items.every((x) => x.status === 'failed'), true);
  assert.equal(summarizeBatch(st).failed, 2);
});

await test('9 mergeBatchResults：按 id 原地合并、保留引用、未知/失败跳过', async () => {
  const a = mkAsset('a', { tags: ['旧标签'], L1: { layer: 'L1', source: 'inferred', confidence: 0.6, summary: '旧摘要', subject: [], medium: null, palette: [], mood: [] } });
  const b = mkAsset('b', { tags: ['b旧'] });
  const c = mkAsset('c', { L1: { layer: 'L1', source: 'inferred', confidence: 0.7, summary: 'C 原样', subject: [], medium: null, palette: [], mood: [] } });
  const assets = [a, b, c];
  const real = {
    id: a.id,
    analysis: {
      global: { summary: '真实摘要', subject: ['雾'], medium: { kind: '水墨' }, palette: [{ hex: '#7f97a8' }], mood: ['安静'] },
      regions: [{ label: '远山', bbox: [1, 2, 3, 4], confidence: 0.8 }],
      observations: [{ id: 'o1', kind: 'observation', text: '真实观察', bbox: [1, 2, 3, 4], confidence: 0.8 }],
      confidence: 0.8,
    },
    meta: { provider: 'qwen', model: 'qwen3.8-max', modelVersion: 'qwen3.8-max', latencyMs: 10, usage: { total_tokens: 10 } },
  };
  const direct = { id: b.id, L1: { layer: 'L1', source: 'inferred', confidence: 0.9, summary: '直接覆盖', subject: [], medium: null, palette: [], mood: [] }, tags: ['新标签'], analysisSource: 'real' };
  const out = mergeBatchResults(assets, [real, direct, { id: 'unknown', L1: { summary: 'nope' } }, { id: c.id, status: 'failed', error: 'skip' }]);
  assert.equal(out, assets, '返回同一 assets 数组');
  assert.equal(out[0], a); assert.equal(out[1], b); assert.equal(out[2], c);
  assert.equal(a.L1.summary, '真实摘要');
  assert.equal(a.analysisSource, 'real');
  assert.equal(a.modelVersion, 'qwen3.8-max');
  assert.ok(a.tags.includes('旧标签') && a.tags.includes('雾') && a.tags.includes('真实AI重读'));
  assert.equal(a.L2[0].label, '远山');
  assert.equal(a.L4[0].text, '真实观察');
  assert.equal(b.L1.summary, '直接覆盖');
  assert.deepEqual(b.tags, ['新标签']);
  assert.equal(c.L1.summary, 'C 原样');
  const map = new Map([[b.id, { id: b.id, tags: ['map标签'] }]]);
  mergeBatchResults([b], map);
  assert.deepEqual(b.tags, ['map标签']);
  const qShape = [{ id: a.id, result: { analysis: { global: { summary: '队列结果' } }, meta: { provider: 'qwen' } } }];
  mergeBatchResults([a], qShape);
  assert.equal(a.L1.summary, '队列结果');
});

await test('10 summarizeBatch：兼容 state 快照/队列实例，real 只计真实结果', async () => {
  const q = new BatchQueue(mkPlan(['r', 'm', 'f', 'p']), async (item) => {
    if (item.id === 'r') return { analysisSource: 'real' };
    if (item.id === 'm') return { analysisSource: 'mock' };
    if (item.id === 'p') return { analysisSource: 'mock', analysis: { global: { summary: 'p' } } };
    throw new Error('fail');
  });
  // 手动构造一个 pending 快照测试 pending 字段（runner 会在 f 失败后继续，p 正常完成）
  const st = await q.run();
  const s = summarizeBatch(st);
  assert.deepEqual(Object.keys(s).sort(), ['cancelled', 'done', 'failed', 'pending', 'real', 'total']);
  assert.equal(s.total, 4);
  assert.equal(s.done, 3);
  assert.equal(s.failed, 1);
  assert.equal(s.real, 1);
  assert.equal(s.pending, 0);
  const fake = { items: [{ status: 'done', result: { analysisSource: 'real' } }, { status: 'pending' }, { status: 'cancelled' }, { status: 'failed' }] };
  assert.deepEqual(summarizeBatch(fake), { total: 4, done: 1, failed: 1, pending: 1, real: 1, cancelled: 1 });
});

const failed = results.filter((r) => !r.pass);
console.log(JSON.stringify({ module: ASSET_BATCH_VERSION, total: results.length, passed: results.length - failed.length, failed: failed.length, cases: results }, null, 2));
if (failed.length) process.exit(1);
