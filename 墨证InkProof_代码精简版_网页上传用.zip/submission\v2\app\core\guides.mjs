/**
 * v2/app/core/guides.mjs — T106-B 编辑器辅助线 / 对称 / 笔刷光标「纯几何」模块
 *
 * 设计原则：
 *  - 全部为纯函数：不依赖 DOM / canvas / app.js，可在 Node 直接 import + 单测；
 *  - 不做渲染，只给坐标/半径等几何数据，由调用方（app）画到 overlay/canvas；
 *  - 不修改 app.js / CSS / HTML；接入方式见 `06-技术/编辑器辅助线接口.md`。
 *
 * 坐标约定：画布坐标系，原点左上角，x 向右、y 向下；单位 px。
 * 尺寸（width/height）必须为有限正数，否则抛 RangeError（`尺寸为 0 抛错`）。
 */

export const GUIDE_DEFAULTS = Object.freeze({
  spacing: 80,
  majorEvery: 4,
  threshold: 6,
  axis: 'both',
  hardness: 0.8,
  pressure: 1,
});

const isFiniteNum = (v) => typeof v === 'number' && Number.isFinite(v);

function positiveDimension(name, value) {
  if (!isFiniteNum(value) || value <= 0) {
    throw new RangeError(`${name} 必须是有限正数（收到 ${String(value)}）`);
  }
  return value;
}

function finiteNumber(name, value) {
  if (!isFiniteNum(value)) throw new TypeError(`${name} 必须是有限数字（收到 ${String(value)}）`);
  return value;
}

function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

/* ============================ 网格 / 三分线 ============================ */

/**
 * 网格线（画布内部线，不含画布边界 0/width/height）。
 * @param {number} width
 * @param {number} height
 * @param {{spacing?:number, majorEvery?:number}} [opts]
 * @returns {{vertical:Array<{value:number,major:boolean,index:number}>, horizontal:Array<{value:number,major:boolean,index:number}>, spacing:number, majorEvery:number}}
 */
export function gridLines(width, height, opts = {}) {
  const w = positiveDimension('gridLines.width', width);
  const h = positiveDimension('gridLines.height', height);
  const spacing = opts.spacing == null ? GUIDE_DEFAULTS.spacing : opts.spacing;
  if (!isFiniteNum(spacing) || spacing <= 0) throw new RangeError(`gridLines.spacing 必须是有限正数（收到 ${String(spacing)}）`);
  const majorEvery = opts.majorEvery == null ? GUIDE_DEFAULTS.majorEvery : opts.majorEvery;
  if (!Number.isInteger(majorEvery) || majorEvery < 1) throw new RangeError(`gridLines.majorEvery 必须是 ≥1 的整数（收到 ${String(majorEvery)}）`);

  const build = (len) => {
    const out = [];
    // 严格内部线：跳过 0 与 len，避免和画布边框重复
    for (let i = 1; i * spacing < len - 1e-9; i += 1) {
      out.push({ value: round3(i * spacing), major: i % majorEvery === 0, index: i });
    }
    return out;
  };
  return { vertical: build(w), horizontal: build(h), spacing, majorEvery };
}

/**
 * 三分线（1/3、2/3，始终各一条）。
 * @returns {{vertical:[number,number], horizontal:[number,number]}}
 */
export function thirdsLines(width, height) {
  const w = positiveDimension('thirdsLines.width', width);
  const h = positiveDimension('thirdsLines.height', height);
  return { vertical: [round3(w / 3), round3((w * 2) / 3)], horizontal: [round3(h / 3), round3((h * 2) / 3)] };
}

/* ============================ 吸附 ============================ */

function round3(v) { return Math.round(v * 1000) / 1000; }

function guideScalar(entry) {
  if (isFiniteNum(entry)) return entry;
  if (entry && typeof entry === 'object') {
    for (const k of ['value', 'x', 'y']) if (isFiniteNum(entry[k])) return entry[k];
  }
  return null;
}

/** 把 guides 拆成竖向（x）与横向（y）列表；数字默认视为竖向 guide（x 位置） */
export function normalizeGuides(guides) {
  if (guides == null) return { x: [], y: [], all: [] };
  if (!Array.isArray(guides)) throw new TypeError('guides 必须是数组');
  const xs = [];
  const ys = [];
  const all = [];
  for (const g of guides) {
    if (isFiniteNum(g)) { xs.push(g); all.push({ axis: 'x', value: g }); continue; }
    if (g && typeof g === 'object') {
      const axis = g.axis === 'y' ? 'y' : g.axis === 'x' ? 'x' : null;
      const value = guideScalar(g);
      if (value == null) throw new TypeError(`guides 项无法解析（${JSON.stringify(g)}）`);
      if (axis === 'y' || (!axis && isFiniteNum(g.y) && !isFiniteNum(g.x))) { ys.push(value); all.push({ axis: 'y', value }); }
      else { xs.push(value); all.push({ axis: 'x', value }); }
      continue;
    }
    throw new TypeError(`guides 项必须是数字或 {axis,value}（收到 ${String(g)}）`);
  }
  return { x: xs, y: ys, all };
}

/**
 * 在 guides 中找与 value 最近、且距离 ≤ threshold 的值。
 * @param {number} value
 * @param {Array<number|{value?:number,x?:number,y?:number,axis?:'x'|'y'}>} guides
 * @param {number} [threshold=6]
 * @returns {{value:number|null, distance:number, index:number}} 无命中时 value=null、distance=Infinity、index=-1
 */
export function nearestGuideValue(value, guides, threshold = GUIDE_DEFAULTS.threshold) {
  const v = finiteNumber('nearestGuideValue.value', value);
  if (!isFiniteNum(threshold) || threshold < 0) throw new RangeError(`nearestGuideValue.threshold 必须是 ≥0 的有限数（收到 ${String(threshold)}）`);
  if (!Array.isArray(guides)) throw new TypeError('nearestGuideValue.guides 必须是数组');
  let best = null;
  let bestDist = Infinity;
  let bestIdx = -1;
  for (let i = 0; i < guides.length; i += 1) {
    const gv = guideScalar(guides[i]);
    if (gv == null) continue;
    const d = Math.abs(gv - v);
    if (d <= threshold && d < bestDist) { best = gv; bestDist = d; bestIdx = i; }
  }
  return best == null ? { value: null, distance: Infinity, index: -1 } : { value: best, distance: bestDist, index: bestIdx };
}

/**
 * 点吸附到最近辅助线（竖向 guide 吸 x，横向 guide 吸 y）。
 * @param {{x:number,y:number}} point
 * @param {{guides?:Array, threshold?:number, width?:number, height?:number}} [opts]
 *   width/height 可选：提供时把结果 clamp 到 [0,width]/[0,height]（负坐标吸附后也不出界）；
 *   不提供则保持原坐标（可负/可超出，供变换/导出等场景使用）。
 * @returns {{x:number,y:number,snappedX:boolean,snappedY:boolean,guideX:number|null,guideY:number|null}}
 */
export function snapPoint(point, opts = {}) {
  if (!point || typeof point !== 'object') throw new TypeError('snapPoint.point 必须是 {x,y}');
  const px = finiteNumber('snapPoint.point.x', point.x);
  const py = finiteNumber('snapPoint.point.y', point.y);
  const threshold = opts.threshold == null ? GUIDE_DEFAULTS.threshold : opts.threshold;
  if (!isFiniteNum(threshold) || threshold < 0) throw new RangeError(`snapPoint.threshold 必须是 ≥0 的有限数（收到 ${String(threshold)}）`);
  const list = normalizeGuides(opts.guides);
  const nx = nearestGuideValue(px, list.x, threshold);
  const ny = nearestGuideValue(py, list.y, threshold);
  let x = nx.value == null ? px : nx.value;
  let y = ny.value == null ? py : ny.value;
  if (opts.width != null) {
    const w = positiveDimension('snapPoint.width', opts.width);
    x = Math.min(w, Math.max(0, x));
  }
  if (opts.height != null) {
    const h = positiveDimension('snapPoint.height', opts.height);
    y = Math.min(h, Math.max(0, y));
  }
  // 吸附后再 clamp 导致坐标变化时，snapped 标记只在确实落在 guide 值上才 true
  return {
    x: round3(x), y: round3(y),
    snappedX: nx.value != null && x === nx.value,
    snappedY: ny.value != null && y === ny.value,
    guideX: nx.value == null ? null : nx.value,
    guideY: ny.value == null ? null : ny.value,
  };
}

/* ============================ 对称镜像 ============================ */

/**
 * 点关于画布中心线的镜像：
 *  - axis='x'：以竖向中线左右镜像 → x' = width - x（y 不变）
 *  - axis='y'：以横向中线上下镜像 → y' = height - y（x 不变）
 *  - axis='both'：中心对称 → (width-x, height-y)
 * 镜像后允许落在画布外（例如负坐标输入会镜像到 >width 处），不做 clamp。
 * @param {{x:number,y:number}} point
 * @param {{axis?:'x'|'y'|'both', width:number, height:number}} opts
 * @returns {{x:number,y:number}}
 */
export function mirrorPoint(point, opts = {}) {
  if (!point || typeof point !== 'object') throw new TypeError('mirrorPoint.point 必须是 {x,y}');
  const px = finiteNumber('mirrorPoint.point.x', point.x);
  const py = finiteNumber('mirrorPoint.point.y', point.y);
  const width = positiveDimension('mirrorPoint.width', opts.width);
  const height = positiveDimension('mirrorPoint.height', opts.height);
  const axis = opts.axis == null ? GUIDE_DEFAULTS.axis : opts.axis;
  if (axis !== 'x' && axis !== 'y' && axis !== 'both') throw new TypeError(`mirrorPoint.axis 只支持 'x'|'y'|'both'（收到 ${String(axis)}）`);
  const mx = axis === 'x' || axis === 'both' ? width - px : px;
  const my = axis === 'y' || axis === 'both' ? height - py : py;
  return { x: round3(mx), y: round3(my) };
}

function mirrorOnePoint(p, axis, width, height) {
  if (Array.isArray(p)) {
    if (p.length < 2) throw new TypeError('mirrorStroke: 点数组项至少 [x,y]');
    const r = mirrorPoint({ x: p[0], y: p[1] }, { axis, width, height });
    return [r.x, r.y];
  }
  if (!p || typeof p !== 'object') throw new TypeError('mirrorStroke: 点必须是 {x,y} 或 [x,y]');
  const r = mirrorPoint(p, { axis, width, height });
  return { ...p, x: r.x, y: r.y };
}

/**
 * 笔迹对称镜像（不含原笔迹）。返回镜像笔迹数组：
 *  - axis='x' → [镜像X]；'y' → [镜像Y]；'both' → [镜像X, 镜像Y, 中心对称]
 *  - 空笔迹 → []；点格式（{x,y} 或 [x,y]）与输入一致，对象点会保留额外字段。
 * @param {Array<{x:number,y:number}|[number,number]>} points
 * @param {{axis?:'x'|'y'|'both', width:number, height:number}} opts
 * @returns {Array<Array>}
 */
export function mirrorStroke(points, opts = {}) {
  if (!Array.isArray(points)) throw new TypeError('mirrorStroke.points 必须是数组');
  const width = positiveDimension('mirrorStroke.width', opts.width);
  const height = positiveDimension('mirrorStroke.height', opts.height);
  const axis = opts.axis == null ? GUIDE_DEFAULTS.axis : opts.axis;
  if (axis !== 'x' && axis !== 'y' && axis !== 'both') throw new TypeError(`mirrorStroke.axis 只支持 'x'|'y'|'both'（收到 ${String(axis)}）`);
  if (points.length === 0) return [];
  const axes = axis === 'both' ? ['x', 'y', 'both'] : [axis];
  return axes.map((ax) => points.map((p) => mirrorOnePoint(p, ax, width, height)));
}

/* ============================ 笔刷光标 ============================ */

/**
 * 笔刷光标圆（纯数据；调用方画两个同心圆即可）。
 *  - radius = size/2 × (0.5 + 0.5 × pressure)，即压力 0→半宽、1→全宽；
 *  - innerRadius = radius × hardness（硬度=实心边界；0=只有外圈，1=实心）；
 *  - alpha = 0.35 + 0.45 × hardness（硬度越高光标越清晰）。
 * @param {{x:number,y:number,size:number,hardness?:number,pressure?:number}} opts
 * @returns {{x:number,y:number,radius:number,innerRadius:number,alpha:number}}
 */
export function brushCursorCircle(opts = {}) {
  if (!opts || typeof opts !== 'object') throw new TypeError('brushCursorCircle 需要 {x,y,size}');
  const x = finiteNumber('brushCursorCircle.x', opts.x);
  const y = finiteNumber('brushCursorCircle.y', opts.y);
  const size = finiteNumber('brushCursorCircle.size', opts.size);
  if (size <= 0) throw new RangeError(`brushCursorCircle.size 必须为正数（收到 ${String(size)}）`);
  const hardness = clamp01(opts.hardness == null ? GUIDE_DEFAULTS.hardness : finiteNumber('brushCursorCircle.hardness', opts.hardness));
  const pressure = clamp01(opts.pressure == null ? GUIDE_DEFAULTS.pressure : finiteNumber('brushCursorCircle.pressure', opts.pressure));
  const radius = (size / 2) * (0.5 + 0.5 * pressure);
  const innerRadius = radius * hardness;
  const alpha = clamp01(0.35 + 0.45 * hardness);
  return { x: round3(x), y: round3(y), radius: round3(radius), innerRadius: round3(innerRadius), alpha: round3(alpha) };
}

export default {
  GUIDE_DEFAULTS,
  gridLines,
  thirdsLines,
  normalizeGuides,
  nearestGuideValue,
  snapPoint,
  mirrorPoint,
  mirrorStroke,
  brushCursorCircle,
};
