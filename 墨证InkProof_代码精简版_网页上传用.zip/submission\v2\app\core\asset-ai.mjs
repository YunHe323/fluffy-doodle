/**
 * v2/app/core/asset-ai.mjs — T105-A 素材库 × AI 管道（纯逻辑，零依赖）
 *
 * 只做计算：无 DOM / IndexedDB / fetch / 文件系统；Node 与浏览器均可直接 import。
 * 与 v2/library/library-schema.mjs 的 asset 字段兼容：
 *   {id,sha256,fileName,mime,bytes,width,height,tags,palette,usageCount,
 *    L0,L1,L2,L4,L5,source,modelVersion,analysisSource,analysis,projectRefs,provenance}
 *
 * 导出（7 个主函数）：
 *   buildAssetKnowledge(asset)
 *   scoreAssetForQuery(asset, query)
 *   rankAssetsForQuery(assets, query, limit = 8)
 *   rankAssetsForSelection(assets, {intent, palette, selection, limit = 6})
 *   selectAssetsForBatchRead(assets, {onlyMock = false})
 *   mergeRealAnalysis(asset, analysis, meta)
 *   summarizeProvenance(asset)
 */

export const ASSET_AI_VERSION = 'asset-ai@1.0.0';

const clamp01 = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0;
};
const asArray = (v) => (Array.isArray(v) ? v : []);
const asStr = (v) => (v == null ? '' : String(v));
const uniq = (arr) => [...new Set(asArray(arr).map((x) => String(x).trim()).filter(Boolean))];
const round3 = (n) => Math.round((Number(n) || 0) * 1000) / 1000;

/** 归一化文本：全半角/大小写/标点/空白，中文不拆字（保留连续汉字）。 */
export function normalizeText(v) {
  return asStr(v)
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[，。；、,.!?！？:：;（）()【】\[\]<>《》"'“”‘’/\\|_\-+*=~`^]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const CJK = /[\u3400-\u9fff]/;

function bigrams(s) {
  const str = asStr(s).replace(/\s+/g, '');
  const out = new Set();
  for (let i = 0; i < str.length - 1; i += 1) out.add(str.slice(i, i + 2));
  return out;
}
function diceCoefficient(a, b) {
  const A = bigrams(a); const B = bigrams(b);
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const g of A) if (B.has(g)) inter += 1;
  return (2 * inter) / (A.size + B.size);
}
function levenshteinRatio(a, b) {
  const A = asStr(a); const B = asStr(b);
  if (!A.length || !B.length) return 0;
  if (A === B) return 1;
  const prev = new Array(B.length + 1);
  for (let j = 0; j <= B.length; j += 1) prev[j] = j;
  for (let i = 1; i <= A.length; i += 1) {
    let diag = prev[0];
    prev[0] = i;
    for (let j = 1; j <= B.length; j += 1) {
      const tmp = prev[j];
      prev[j] = Math.min(prev[j] + 1, prev[j - 1] + 1, diag + (A[i - 1] === B[j - 1] ? 0 : 1));
      diag = tmp;
    }
  }
  return 1 - prev[B.length] / Math.max(A.length, B.length);
}

const SYNONYM_GROUPS = [
  ['山', '山峦', '山脉', '远山', '峰', '山峰', 'mountain', 'hill', 'peak', 'ridge'],
  ['雾', '雾气', '晨雾', '雾带', '薄雾', 'fog', 'mist', 'haze'],
  ['水', '水面', '湖', '湖面', '河', '河流', '海', '海洋', 'water', 'lake', 'river', 'sea', 'ocean'],
  ['树', '树木', '森林', '树林', '林', 'forest', 'tree', 'woods'],
  ['花', '花卉', '花朵', '花丛', 'flower', 'bloom', 'floral'],
  ['人', '人物', '人像', '女孩', '男孩', 'portrait', 'figure', 'person'],
  ['建筑', '房子', '房屋', '屋', '庭院', 'architecture', 'building', 'house', 'courtyard'],
  ['光', '光线', '光影', '阳光', '光斑', 'light', 'glow', 'shadow'],
  ['夜', '夜晚', '夜间', '夜色', 'night', 'dark'],
  ['暖', '暖色', '暖调', 'warm'],
  ['冷', '冷色', '冷调', 'cool', 'cold'],
  ['蓝', '蓝色', '蓝调', 'blue'],
  ['绿', '绿色', '绿调', 'green'],
  ['红', '红色', '红调', 'red'],
  ['黄', '黄色', '黄调', 'yellow'],
  ['橙', '橙色', 'orange'],
  ['紫', '紫色', 'purple', 'violet'],
  ['粉', '粉色', 'pink'],
  ['黑', '黑色', 'black'],
  ['白', '白色', 'white'],
  ['灰', '灰色', 'gray', 'grey'],
  ['棕', '棕色', '褐色', 'brown'],
  ['青', '青色', 'cyan', 'teal'],
  ['黑白', '单色', 'monochrome', 'grayscale'],
  ['留白', '空白', 'negative space', 'blank', 'empty'],
  ['水墨', 'ink', 'inkwash', 'sumi'],
  ['低饱和', '灰调', 'muted', 'desaturated'],
  ['安静', '宁静', '平静', 'quiet', 'calm', 'serene'],
  ['温暖', '暖意', 'cozy'],
];
const SYNONYM_MAP = (() => {
  const map = new Map();
  for (const group of SYNONYM_GROUPS) {
    for (const key of group) {
      const norm = normalizeText(key);
      if (!norm) continue;
      const set = map.get(norm) || new Set();
      for (const other of group) {
        const n = normalizeText(other);
        if (n && n !== norm) set.add(n);
      }
      map.set(norm, set);
    }
  }
  return map;
})();

/** 查询词：原文/分词/中文 bigram/单字，并扩展同义词。 */
function queryTerms(query) {
  const q = normalizeText(query);
  if (!q) return [];
  const terms = new Set();
  const add = (t) => { const n = normalizeText(t); if (n) terms.add(n); };
  add(q);
  for (const chunk of q.split(' ')) {
    if (!chunk) continue;
    add(chunk);
    const cjkRuns = chunk.match(/[\u3400-\u9fff]+/g) || [];
    for (const run of cjkRuns) {
      if (run.length <= 3) add(run);
      for (let i = 0; i < run.length - 1; i += 1) add(run.slice(i, i + 2));
      if (run.length === 1) add(run);
    }
  }
  for (const t of [...terms]) {
    const syn = SYNONYM_MAP.get(t);
    if (syn) for (const s of syn) terms.add(s);
  }
  // 去掉被更长查询词完全包含的同义扩展（避免权重过度膨胀），但保留原文 term
  return [...terms].slice(0, 40);
}

function fieldTexts(asset) {
  const l1 = asset.L1 || {};
  const provenance = asset.provenance || {};
  return {
    fileName: normalizeText(asStr(asset.fileName).replace(/\.[a-z0-9]{2,5}$/i, '')),
    tags: normalizeText(asArray(asset.tags).join(' ')),
    summary: normalizeText(l1.summary),
    subject: normalizeText(asArray(l1.subject).join(' ')),
    mood: normalizeText(asArray(l1.mood).join(' ')),
    medium: normalizeText([l1.medium && l1.medium.kind, l1.medium && l1.medium.detail].filter(Boolean).join(' ')),
    regions: normalizeText(asArray(asset.L2).map((r) => r && r.label).join(' ')),
    observations: normalizeText(asArray(asset.L4).map((o) => o && o.text).join(' ')),
    provenance: normalizeText([provenance.source, provenance.prompt, provenance.model].filter(Boolean).join(' ')),
    palette: normalizeText(asArray(asset.palette).join(' ')),
  };
}

const COLOR_TARGETS = {
  红: '#d64545', 红色: '#d64545', red: '#d64545',
  蓝: '#3b6ea5', 蓝色: '#3b6ea5', 蓝调: '#3b6ea5', blue: '#3b6ea5',
  绿: '#4e8a5a', 绿色: '#4e8a5a', green: '#4e8a5a',
  黄: '#e0c14e', 黄色: '#e0c14e', yellow: '#e0c14e',
  橙: '#d07a3a', 橙色: '#d07a3a', orange: '#d07a3a',
  紫: '#7a5a9a', 紫色: '#7a5a9a', purple: '#7a5a9a', violet: '#7a5a9a',
  粉: '#d77a9a', 粉色: '#d77a9a', pink: '#d77a9a',
  黑: '#1a1a1a', 黑色: '#1a1a1a', black: '#1a1a1a',
  白: '#f2efe6', 白色: '#f2efe6', white: '#f2efe6',
  灰: '#8a8a8a', 灰色: '#8a8a8a', gray: '#8a8a8a', grey: '#8a8a8a',
  棕: '#7a5a3a', 棕色: '#7a5a3a', 褐色: '#7a5a3a', brown: '#7a5a3a',
  青: '#4a9a9a', 青色: '#4a9a9a', cyan: '#4a9a9a', teal: '#4a9a9a',
  米色: '#d8c4a0', beige: '#d8c4a0',
};
function parseHex(v) {
  const m = /^#?([0-9a-f]{6})$/i.exec(asStr(v).trim());
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255, hex: '#' + m[1].toLowerCase() };
}
function rgbToHsl(rgb) {
  const r = rgb.r / 255; const g = rgb.g / 255; const b = rgb.b / 255;
  const max = Math.max(r, g, b); const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  if (max === min) return { h: 0, s: 0, l };
  const d = max - min;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  let h;
  if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
  else if (max === g) h = ((b - r) / d + 2) / 6;
  else h = ((r - g) / d + 4) / 6;
  return { h: h * 360, s, l };
}
function colorSimilarity(hexA, hexB) {
  const a = parseHex(hexA); const b = parseHex(hexB);
  if (!a || !b) return 0;
  const dist = Math.sqrt((a.r - b.r) ** 2 + (a.g - b.g) ** 2 + (a.b - b.b) ** 2);
  return 1 - Math.min(1, dist / 441.67);
}
function queryColorIntent(query) {
  const q = normalizeText(query);
  if (!q) return [];
  const out = [];
  const hexes = q.match(/#?[0-9a-f]{6}\b/gi) || [];
  for (const h of hexes) { const rgb = parseHex(h); if (rgb) out.push({ type: 'hex', rgb }); }
  for (const [word, hex] of Object.entries(COLOR_TARGETS)) {
    if (q.includes(word)) out.push({ type: 'hex', rgb: parseHex(hex) });
  }
  if (/暖色|暖调|warm/.test(q)) out.push({ type: 'warm' });
  if (/冷色|冷调|cool|cold/.test(q)) out.push({ type: 'cool' });
  if (/低饱和|灰调|muted|desaturat/.test(q)) out.push({ type: 'muted' });
  if (/高饱和|鲜艳|vivid|saturat/.test(q)) out.push({ type: 'vivid' });
  // 去重
  const seen = new Set(); const uniqOut = [];
  for (const t of out) { const k = t.type + (t.rgb ? t.rgb.hex : ''); if (!seen.has(k)) { seen.add(k); uniqOut.push(t); } }
  return uniqOut.slice(0, 4);
}
function paletteScore(asset, query) {
  const intents = queryColorIntent(query);
  const pal = asArray(asset.palette).map(parseHex).filter(Boolean);
  if (!intents.length || !pal.length) return 0;
  const sims = [];
  for (const intent of intents) {
    let best = 0;
    for (const c of pal) {
      if (intent.type === 'hex') best = Math.max(best, colorSimilarity(c.hex, intent.rgb.hex));
      else {
        const hsl = rgbToHsl(c);
        if (intent.type === 'warm') best = Math.max(best, (hsl.h <= 70 || hsl.h >= 300) && hsl.s > 0.12 ? 0.9 : 0.15);
        else if (intent.type === 'cool') best = Math.max(best, hsl.h >= 120 && hsl.h <= 290 && hsl.s > 0.10 ? 0.9 : 0.15);
        else if (intent.type === 'muted') best = Math.max(best, hsl.s < 0.32 ? 0.9 : 0.15);
        else if (intent.type === 'vivid') best = Math.max(best, hsl.s > 0.5 ? 0.9 : 0.15);
      }
    }
    sims.push(best);
  }
  return sims.reduce((a, b) => a + b, 0) / sims.length;
}
function fuzzyTermScore(term, fields) {
  if (!term || term.length < 2) return 0;
  const hay = fields;
  if (CJK.test(term)) {
    const targets = [hay.fileName, hay.tags, hay.summary, hay.subject, hay.regions, hay.observations, hay.mood].filter(Boolean).join(' ');
    if (!targets) return 0;
    return diceCoefficient(term, targets) * 0.55 + Math.max(...targets.split(' ').filter(Boolean).map((tok) => diceCoefficient(term, tok)), 0) * 0.45;
  }
  const tokens = uniq([hay.fileName, hay.tags, hay.summary, hay.subject, hay.mood, hay.medium, hay.regions, hay.observations].join(' ').split(/\s+/));
  let best = 0;
  for (const token of tokens) {
    if (!token) continue;
    const ratio = Math.max(diceCoefficient(term, token), levenshteinRatio(term, token));
    if (ratio > best) best = ratio;
  }
  return best;
}

/**
 * 1) 精简资产知识：只保留本地检索/推荐需要的字段（不含图像二进制）。
 * @param {object} asset
 * @returns {object}
 */
export function buildAssetKnowledge(asset = {}) {
  const l0 = asset.L0 || {};
  const l1 = asset.L1 || {};
  const prov = asset.provenance || {};
  const modelVersion = asset.modelVersion || l1.modelVersion || null;
  const analysisSource = asset.analysisSource || (asset.analysis && asset.analysis.source) || (/^mock/i.test(asStr(modelVersion)) ? 'mock' : 'unknown');
  return {
    id: asset.id || null,
    sha256: asset.sha256 || null,
    fileName: asStr(asset.fileName),
    mime: asset.mime || l0.mime || null,
    bytes: Number(asset.bytes || l0.bytes || 0),
    width: Number(asset.width || l0.width || 0),
    height: Number(asset.height || l0.height || 0),
    summary: asStr(l1.summary),
    subject: uniq(l1.subject),
    mood: uniq(l1.mood),
    medium: l1.medium || null,
    tags: uniq(asset.tags),
    palette: uniq(asset.palette),
    regionLabels: uniq(asArray(asset.L2).map((r) => r && r.label)),
    observationTexts: asArray(asset.L4).map((o) => asStr(o && o.text)).filter(Boolean),
    regions: asArray(asset.L2).map((r) => ({ id: r.id || null, label: asStr(r && r.label), bbox: asArray(r && r.bbox), importance: clamp01(r && r.importance) })),
    observations: asArray(asset.L4).map((o) => ({ id: o.id || null, kind: (o && o.kind) || null, text: asStr(o && o.text), confidence: clamp01(o && o.confidence) })),
    source: uniq(asset.source),
    sourceInfo: { l0: { fileName: asStr(l0.fileName), sha256: l0.sha256 || asset.sha256 || null, importedAt: l0.importedAt || null }, provenance: { source: prov.source || null, provider: prov.provider || null, model: prov.model || null, prompt: prov.prompt || null, refsCount: asArray(prov.refs).length, candidate_sha256: prov.candidate_sha256 || null, generated_at: prov.generated_at || null } },
    analysisSource,
    modelVersion,
    usageCount: Math.max(0, Number(asset.usageCount) || 0),
    projectRefsCount: asArray(asset.projectRefs).length,
    createdAt: asset.createdAt || null,
    updatedAt: asset.updatedAt || null,
    searchText: (() => { const f = fieldTexts(asset); return [f.fileName, f.tags, f.summary, f.subject, f.mood, f.medium, f.regions, f.observations, f.provenance].filter(Boolean).join(' '); })(),
  };
}

/**
 * 2) 本地相关性评分（0..1）：标签/文件名/L1/区域/L4/色板/同义词/模糊匹配。
 * @param {object} asset
 * @param {string} query
 * @returns {number}
 */
export function scoreAssetForQuery(asset, query) {
  const q = normalizeText(query);
  if (!asset || typeof asset !== 'object' || !q) return 0;
  const fields = fieldTexts(asset);
  const terms = queryTerms(query);
  if (!terms.length) return 0;
  let score = 0;
  let fullMatched = false;
  if (q.length >= 1) {
    const full = [fields.fileName, fields.tags, fields.summary, fields.subject, fields.mood, fields.regions, fields.observations].some((f) => f && f.includes(q));
    if (full) { score += q.length >= 2 ? 0.5 : 0.28; fullMatched = true; }
  }
  for (const term of terms) {
    if (term.length < 1) continue;
    if (term === q && fullMatched) continue; // 全文匹配已计
    if (fields.tags.includes(term)) score += 0.3;
    if (fields.fileName.includes(term)) score += 0.2;
    if (fields.summary.includes(term) || fields.subject.includes(term) || fields.mood.includes(term) || fields.medium.includes(term)) score += 0.18;
    if (fields.regions.includes(term)) score += 0.14;
    if (fields.observations.includes(term)) score += 0.1;
    if (fields.provenance.includes(term)) score += 0.08;
  }
  // 色板语义（蓝色/暖色/#hex…）
  const colorScore = paletteScore(asset, query);
  if (colorScore > 0.35) score += 0.18 + colorScore * 0.12;
  // 模糊匹配：取最好的一项，最多 +0.18
  let bestFuzzy = 0;
  for (const term of terms) {
    if (term.length < 2) continue;
    const f = fuzzyTermScore(term, fields);
    if (f > bestFuzzy) bestFuzzy = f;
  }
  if (bestFuzzy >= 0.58) score += Math.min(0.18, (bestFuzzy - 0.5) * 0.6);
  // 文件名直接等于/包含完整 query 的轻量加权
  if (fields.fileName && q && fields.fileName.includes(q)) score += 0.06;
  return clamp01(round3(score));
}

/**
 * 3) 查询排序；返回 [{asset, score, reasons}]，不修改 asset。
 * 空 query 返回原顺序（稳定）的前 limit 个，score 0。
 */
export function rankAssetsForQuery(assets, query, limit = 8) {
  const list = asArray(assets).filter((a) => a && typeof a === 'object');
  const n = Number.isFinite(Number(limit)) ? Math.max(0, Math.floor(Number(limit))) : 8;
  if (!n) return [];
  const q = normalizeText(query);
  if (!q) return list.slice(0, n).map((asset) => ({ asset, score: 0, reasons: [] }));
  const scored = [];
  for (const asset of list) {
    const score = scoreAssetForQuery(asset, query);
    if (score <= 0) continue;
    const f = fieldTexts(asset);
    const terms = queryTerms(query).filter((t) => t && t !== q);
    const hitTags = uniq(asArray(asset.tags).filter((tag) => terms.some((t) => normalizeText(tag).includes(t))));
    const hitLabels = uniq(asArray(asset.L2).map((r) => r && r.label).filter((label) => terms.some((t) => normalizeText(label).includes(t))));
    const reasons = [];
    if (f.fileName.includes(q)) reasons.push('文件名命中');
    if (hitTags.length) reasons.push('标签: ' + hitTags.slice(0, 3).join('/'));
    if (hitLabels.length) reasons.push('区域: ' + hitLabels.slice(0, 2).join('/'));
    if (paletteScore(asset, query) > 0.6) reasons.push('色板接近');
    if (score > 0 && !reasons.length) reasons.push('文字/语义接近');
    scored.push({ asset, score, reasons });
  }
  scored.sort((a, b) => b.score - a.score
    || (Number(b.asset.usageCount) || 0) - (Number(a.asset.usageCount) || 0)
    || String(b.asset.updatedAt || '').localeCompare(String(a.asset.updatedAt || ''))
    || String(a.asset.id || '').localeCompare(String(b.asset.id || '')));
  return scored.slice(0, n);
}

function paletteOverlap(asset, palette) {
  const asked = asArray(palette).map((p) => (typeof p === 'string' ? p : p && (p.hex || p.color))).map(parseHex).filter(Boolean);
  const own = asArray(asset.palette).map(parseHex).filter(Boolean);
  if (!asked.length || !own.length) return 0;
  let total = 0;
  for (const q of asked) {
    let best = 0;
    for (const c of own) best = Math.max(best, colorSimilarity(q.hex, c.hex));
    total += best;
  }
  return total / asked.length;
}

/**
 * 4) 给画布/选区推荐素材：意图（文字）+ 色板 + 选区标签的启发式打分。
 * @returns {Array<{asset:object, score:number, reasons:string[]}>}
 */
export function rankAssetsForSelection(assets, opts = {}) {
  const { intent = '', palette = [], selection = null } = opts || {};
  const limit = Number.isFinite(Number(opts && opts.limit)) ? Math.max(0, Math.floor(Number(opts.limit))) : 6;
  const list = asArray(assets).filter((a) => a && typeof a === 'object');
  if (!limit) return [];
  const sel = selection && typeof selection === 'object' ? selection : null;
  const selTags = sel ? uniq([...(asArray(sel.tags)), sel.label, sel.text, sel.name]) : [];
  const selPalette = sel && Array.isArray(sel.palette) ? sel.palette : [];
  const palettes = [...asArray(palette), ...selPalette];
  const selText = selTags.join(' ');
  const scored = list.map((asset) => {
    const intentScore = scoreAssetForQuery(asset, intent);
    const selScore = scoreAssetForQuery(asset, selText);
    const palScore = paletteOverlap(asset, palettes);
    const usageBoost = Math.min(0.05, (Number(asset.usageCount) || 0) * 0.005);
    const score = clamp01(round3(intentScore * 0.62 + palScore * 0.24 + selScore * 0.10 + usageBoost));
    const reasons = [];
    if (intentScore > 0) reasons.push('意图匹配 ' + Math.round(intentScore * 100) + '%');
    if (palScore > 0.45) reasons.push('色板相近 ' + Math.round(palScore * 100) + '%');
    if (selScore > 0) reasons.push('选区文字匹配');
    if (usageBoost > 0) reasons.push('常用素材');
    return { asset, score, reasons };
  });
  scored.sort((a, b) => b.score - a.score
    || (Number(b.asset.usageCount) || 0) - (Number(a.asset.usageCount) || 0)
    || String(b.asset.updatedAt || '').localeCompare(String(a.asset.updatedAt || ''))
    || String(a.asset.id || '').localeCompare(String(b.asset.id || '')));
  return scored.slice(0, limit);
}

function isRealAnalysis(asset) {
  return !!asset && (asset.analysisSource === 'real' || (asset.analysis && asset.analysis.source === 'real'));
}
function isExplicitMock(asset) {
  return !!asset && (asset.analysisSource === 'mock' || /^mock/i.test(asStr(asset.modelVersion)));
}

/**
 * 5) 需要真实视觉重读的队列。
 * - 默认返回所有「尚未真实读」的素材（含 mock/无分析/来源未知），缺 L1 的优先；
 * - onlyMock=true 只返回显式 mock / modelVersion=mock-* 的素材。
 */
export function selectAssetsForBatchRead(assets, opts = {}) {
  const onlyMock = !!(opts && opts.onlyMock);
  const list = asArray(assets).filter((a) => a && typeof a === 'object');
  const queue = [];
  for (const asset of list) {
    if (isRealAnalysis(asset)) continue;
    if (onlyMock && !isExplicitMock(asset)) continue;
    const l1 = asset.L1 || {};
    const hasL1 = !!(asStr(l1.summary) || asArray(l1.subject).length || asArray(l1.palette).length);
    queue.push({ asset, priority: hasL1 ? 1 : 0, updatedAt: asset.updatedAt || asset.createdAt || '' });
  }
  queue.sort((a, b) => a.priority - b.priority || String(a.updatedAt).localeCompare(String(b.updatedAt)) || String(a.asset.id || '').localeCompare(String(b.asset.id || '')));
  return queue.map((x) => x.asset);
}

function normalizePaletteInput(p) {
  return uniq(asArray(p).map((x) => (typeof x === 'string' ? x : x && (x.hex || x.color))).filter(Boolean));
}
function normalizeBBox(v) {
  return asArray(v).slice(0, 4).map((n) => { const x = Number(n); return Number.isFinite(x) ? Math.round(x) : 0; });
}

/**
 * 6) 真实视觉分析结果合并：返回可 Object.assign(asset, result) 的字段（不写库、不修改入参）。
 * analysis 形如 analyzeResult: {global,regions,observations,confidence,meta}
 * meta: {provider,model,modelVersion,latencyMs,usage,at,skill}
 */
export function mergeRealAnalysis(asset, analysis, meta = {}) {
  if (!asset || typeof asset !== 'object') throw new TypeError('asset 必须为对象');
  const a = analysis && typeof analysis === 'object' ? analysis : {};
  const m = meta && typeof meta === 'object' ? meta : {};
  const am = a.meta && typeof a.meta === 'object' ? a.meta : {};
  const g = a.global && typeof a.global === 'object' ? a.global : (a.L1 || {});
  const oldL1 = asset.L1 || {};
  const modelVersion = m.modelVersion || m.model || am.modelVersion || am.model || a.modelVersion || a.model || oldL1.modelVersion || asset.modelVersion || null;
  const provider = m.provider || am.provider || (asset.analysis && asset.analysis.provider) || null;
  const at = m.at || am.at || asset.analysis?.at || new Date().toISOString();
  const confidence = clamp01(g.confidence != null ? g.confidence : (a.confidence != null ? a.confidence : oldL1.confidence));
  const palette = normalizePaletteInput(g.palette || a.palette);
  const nextPalette = palette.length ? palette : uniq(asset.palette);
  const l1 = {
    ...oldL1,
    layer: 'L1',
    source: 'inferred',
    confidence,
    anchor: { type: 'whole', value: null },
    summary: asStr(g.summary != null ? g.summary : oldL1.summary),
    subject: g.subject !== undefined ? uniq(g.subject) : uniq(oldL1.subject),
    medium: g.medium !== undefined ? g.medium : (oldL1.medium || null),
    palette: nextPalette,
    mood: g.mood !== undefined ? uniq(g.mood) : uniq(oldL1.mood),
    modelVersion,
  };
  const regionSrc = asArray(a.regions).length ? asArray(a.regions) : asArray(a.L2);
  const oldL2 = asArray(asset.L2);
  const l2 = regionSrc.length ? regionSrc.map((r, i) => {
    const bbox = normalizeBBox(r.bbox || (r.anchor && r.anchor.value));
    return {
      ...(r && typeof r === 'object' ? r : {}),
      id: (r && r.id) || `L2-real-${String(i + 1).padStart(2, '0')}`,
      layer: 'L2',
      source: 'inferred',
      confidence: clamp01(r && r.confidence),
      label: asStr(r && (r.label || r.name || r.text)) || `区域 ${i + 1}`,
      bbox,
      importance: clamp01(r && r.importance),
      anchor: { type: 'bbox', value: bbox },
      modelVersion,
    };
  }) : oldL2;
  const obsSrc = asArray(a.observations).length ? asArray(a.observations) : asArray(a.L4);
  const oldL4 = asArray(asset.L4);
  const newL4 = obsSrc.map((o, i) => {
    const bbox = normalizeBBox(o.bbox || (o.anchor && o.anchor.value));
    return {
      ...(o && typeof o === 'object' ? o : {}),
      id: (o && o.id) || `L4-real-${String(i + 1).padStart(2, '0')}`,
      layer: 'L4',
      kind: (o && o.kind) || 'observation',
      source: 'inferred',
      author: 'ai',
      confidence: clamp01(o && o.confidence),
      text: asStr(o && (o.text || o.description)),
      anchor: o && o.anchor && o.anchor.type ? o.anchor : { type: 'bbox', value: bbox },
      evidenceRefs: asArray(o && o.evidenceRefs),
      modelVersion,
    };
  });
  const newIds = new Set(newL4.map((o) => o.id));
  const preservedConfirmed = oldL4.filter((o) => o && o.source === 'user-confirmed' && !newIds.has(o.id));
  const l4 = newL4.length ? [...newL4, ...preservedConfirmed] : oldL4;
  const derivedTags = uniq([
    ...asArray(g.subject), ...asArray(g.mood), g.medium && g.medium.kind,
    ...l2.map((r) => r.label),
    '真实AI重读',
  ]);
  const tags = uniq([...asArray(asset.tags), ...derivedTags]).slice(0, 32);
  const sourceSet = new Set([...asArray(asset.source), 'observed', 'inferred']);
  const analysisMeta = {
    source: 'real',
    provider,
    model: modelVersion,
    at,
    latency_ms: (m.latencyMs != null ? Number(m.latencyMs) : (m.latency_ms != null ? Number(m.latency_ms) : (am.latencyMs != null ? Number(am.latencyMs) : null))),
    usage: m.usage || am.usage || a.usage || null,
    confidence,
    regions: l2.length,
    observations: l4.filter((o) => o && o.source !== 'user-confirmed').length,
    skill: m.skill || am.skill || null,
  };
  return {
    L1: l1,
    L2: l2,
    L4: l4,
    tags,
    palette: nextPalette,
    modelVersion,
    analysisSource: 'real',
    analysis: analysisMeta,
    source: [...sourceSet],
    updatedAt: m.updatedAt || at,
  };
}

/**
 * 7) 来源摘要：AI 生成/本地导入、模型、引用、确认/否决、层级来源。
 */
export function summarizeProvenance(asset = {}) {
  const p = asset.provenance || {};
  const l0 = asset.L0 || {};
  const l1 = asset.L1 || {};
  const l5 = asArray(asset.L5);
  const refs = asArray(p.refs).length ? asArray(p.refs) : asArray(asset.projectRefs);
  const analysisSource = asset.analysisSource || (asset.analysis && asset.analysis.source) || (/^mock/i.test(asStr(asset.modelVersion || l1.modelVersion)) ? 'mock' : 'unknown');
  let source = p.source || null;
  if (!source) {
    if (asArray(asset.tags).some((t) => /AI生成|ai-generated/i.test(t)) || p.candidate_sha256) source = 'ai-generated';
    else if (l0.fileName || asset.fileName) source = 'imported';
    else source = 'unknown';
  }
  const sourceLabel = { 'ai-generated': 'AI 生成', imported: '本地导入', user: '用户上传', unknown: '未知来源' }[source] || source;
  const confirms = l5.filter((x) => x && (x.kind === 'confirm' || x.kind === 'use')).length;
  const rejects = l5.filter((x) => x && x.kind === 'reject').length;
  const model = p.model || l1.modelVersion || asset.modelVersion || null;
  const provider = p.provider || (asset.analysis && asset.analysis.provider) || null;
  const refCount = refs.length || (Number(asset.usageCount) || 0);
  const summary = [sourceLabel, provider && model ? provider + '/' + model : model, refCount ? '引用 ' + refCount + ' 次' : '未被引用'].filter(Boolean).join(' · ');
  return {
    fileName: asset.fileName || l0.fileName || '',
    sha256: asset.sha256 || l0.sha256 || null,
    source,
    sourceLabel,
    provider,
    model,
    modelVersion: model,
    prompt: p.prompt || null,
    candidate_sha256: p.candidate_sha256 || null,
    generated_at: p.generated_at || null,
    importedAt: l0.importedAt || asset.createdAt || null,
    createdAt: asset.createdAt || null,
    updatedAt: asset.updatedAt || null,
    analysisSource,
    modelVersionSource: asset.modelVersion || l1.modelVersion || null,
    refCount,
    refs: refs.map((r) => (r && typeof r === 'object' ? { asset_id: r.asset_id || r.id || null, fileName: r.fileName || null, sha256: r.sha256 || null } : null)).filter(Boolean).slice(0, 16),
    usageCount: Number(asset.usageCount) || 0,
    confirmations: confirms,
    rejections: rejects,
    decisions: l5.length,
    layers: {
      L0: !!asset.L0,
      L1: !!asset.L1,
      L2: asArray(asset.L2).length,
      L4: asArray(asset.L4).length,
      L5: l5.length,
    },
    summary,
    chain: [
      asset.L0 ? 'L0 原件 ' + (asset.sha256 || l0.sha256 || '').slice(0, 12) : 'L0 缺失',
      asset.L1 ? 'L1 全局（' + analysisSource + '）' : 'L1 待读',
      confirms + ' 确认 / ' + rejects + ' 否决',
    ],
  };
}

export default {
  ASSET_AI_VERSION,
  buildAssetKnowledge,
  scoreAssetForQuery,
  rankAssetsForQuery,
  rankAssetsForSelection,
  selectAssetsForBatchRead,
  mergeRealAnalysis,
  summarizeProvenance,
  normalizeText,
};
