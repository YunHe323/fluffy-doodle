#!/usr/bin/env node
// v2/engine/test/export-async.mjs —— T76 异步导出 Worker 测试（零依赖 CDP）
// 用法：node v2/engine/test/export-async.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const checks = {};
  const results = {};

  async function makeEngine(width) {
    const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = width;
    const eng = new Engine({ canvas, width, height: width, layers: 2 });
    await eng.init(); eng.setBrush({ type: 'soft', sizePx: 48 });
    for (let s = 0; s < 3; s += 1) {
      const y = 100 + s * 120;
      eng.beginStroke({ x: 100, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
      for (let i = 1; i < 18; i += 1) eng.appendPoint({ x: 100 + i * 20, y: y + Math.sin(i / 4) * 20, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
      eng.endStroke();
    }
    await raf(); await raf();
    return eng;
  }
  async function warmUp(eng) {
    // 首次导出包含 GPU/Worker/编码管线暖机（应用可在空闲时调用，避免用户可见卡顿）
    await eng.warmUpExportAsync();
  }
  function decodeToData(imgLike) {
    return new Promise((resolve, reject) => {
      const finish = (img) => {
        const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
        const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
        resolve({ width: c.width, height: c.height, data: ctx.getImageData(0, 0, c.width, c.height).data });
      };
      if (imgLike instanceof Blob) {
        const url = URL.createObjectURL(imgLike);
        const img = new Image(); img.onload = () => { finish(img); URL.revokeObjectURL(url); };
        img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('blob 解码失败')); };
        img.src = url;
      } else {
        const img = new Image(); img.onload = () => finish(img); img.onerror = () => reject(new Error('URL 解码失败')); img.src = imgLike;
      }
    });
  }
  function comparePixels(a, b, stride) {
    if (a.width !== b.width || a.height !== b.height) return { ok: false, reason: 'dimensions', diff: -1 };
    let diff = 0;
    const step = stride || 1;
    for (let i = 0; i < a.data.length; i += 4 * step) {
      if (a.data[i] !== b.data[i] || a.data[i + 1] !== b.data[i + 1] || a.data[i + 2] !== b.data[i + 2] || a.data[i + 3] !== b.data[i + 3]) diff += 1;
    }
    return { ok: diff === 0, diff, checked: Math.ceil(a.data.length / (4 * step)) };
  }

  for (const width of [2048, 4096]) {
    const eng = await makeEngine(width);
    await warmUp(eng);
    // 长任务观测
    let longTasks = [];
    let longTaskEntries = [];
    let observer = null;
    try {
      observer = new PerformanceObserver((list) => {
        for (const e of list.getEntries()) { longTasks.push(e.duration); longTaskEntries.push({ start: e.startTime, duration: e.duration }); }
      });
      observer.observe({ entryTypes: ['longtask'] });
    } catch (e) { observer = null; }
    const progress = [];
    const exportStartAbs = performance.now();
    const tStart = performance.now();
    const blob = await eng.exportPNGAsync({ onProgress: (p) => progress.push(Object.assign({}, p, { _t: performance.now() - exportStartAbs })) });
    const exportMs = Math.round((performance.now() - tStart) * 100) / 100;
    await new Promise((r) => setTimeout(r, 100));
    if (observer) { try { observer.disconnect(); } catch (e) { /* ignore */ } }
    const longTaskMax = longTasks.length ? Math.max(...longTasks) : 0;
    const syncUrl = await eng.getCompositeDataUrl();
    const [a, b] = await Promise.all([decodeToData(blob), decodeToData(syncUrl)]);
    const cmp = comparePixels(a, b, width === 4096 ? 16 : 1);
    results[width] = {
      ok: !!blob && blob.type === 'image/png' && blob.size > 0 && cmp.ok,
      blobBytes: blob ? blob.size : 0,
      exportMs,
      progressCount: progress.length,
      progressPhases: [...new Set(progress.map((p) => p.phase))],
      progressFinal: progress[progress.length - 1] || null,
      longTaskCount: longTasks.length,
      longTaskMaxMs: Math.round(longTaskMax * 100) / 100,
      longTaskEntries: longTaskEntries.map((e) => ({ startMs: Math.round((e.start - exportStartAbs) * 100) / 100, durationMs: Math.round(e.duration * 100) / 100 })),
      firstProgressAtMs: progress.length ? Math.round((progress[0]._t || 0) * 100) / 100 : null,
      pixel: cmp,
      syncUrlBytes: Math.round(syncUrl.length * 3 / 4),
    };
    checks['export' + width] = results[width].ok;
    checks['pixelDiff' + width] = cmp.ok;
    checks['progress' + width] = progress.length > 0 && progress.some((p) => p.phase === 'done');
    // 取消测试（2048 才跑，避免 4096 耗时翻倍）
    if (width === 2048) {
      let canceled = false;
      try {
        await eng.exportPNGAsync({ onProgress: (p) => { if (!canceled && p.phase === 'read' && p.done >= 3) { canceled = true; eng.cancelExport(); } } });
      } catch (e) { checks.cancelWorks = e && e.name === 'AbortError' && canceled; }
      const blob2 = await eng.exportPNGAsync({});
      checks.cancelRecovery = !!blob2 && blob2.size > 0;
    }
    eng.dispose();
  }
  checks.longTasksUnder50 = Object.values(results).every((r) => r.longTaskMaxMs < 50);
  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  return { ok: checks.ok, checks, results, environment: { headless: /HeadlessChrome/.test(navigator.userAgent) } };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 300000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 2000)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
