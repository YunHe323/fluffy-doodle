// v2/app/test-tools.mjs — T64 涂抹/选区/变换/结构 undo 回归（Playwright + msedge，硬超时，headless）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8113;
const out = { schema: 'mozheng.app.tools-test.v1', cases: {}, errors: [] };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
let browser = null;
const finish = (code = 0) => { try { fs.writeFileSync(ROOT + '\\v2\\app\\test-tools-result.json', JSON.stringify(out, null, 2), 'utf8'); } catch (e) {} process.exit(code); };
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_180s'; finish(3); }, 180000);

try {
  await new Promise((r) => setTimeout(r, 800));
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  const load = async () => {
    await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
    await page.waitForTimeout(350);
    return page.locator('#mainCanvas').boundingBox();
  };
  const grab = () => page.evaluate(() => window.__V2_APP__.engine.getCompositeDataUrl());

  let box = await load();

  // ---------- 涂抹 ----------
  await page.evaluate(() => { const a = window.__V2_APP__; a.engine.setActiveLayer(a.engine.getLayers()[0].id); a.engine.setLayerLocked(a.engine.getLayers()[0].id, false); a.setTool('brush'); });
  const beforeBrush = await grab();
  await page.mouse.move(box.x + box.width * 0.3, box.y + box.height * 0.35);
  await page.mouse.down();
  for (let i = 1; i <= 10; i++) await page.mouse.move(box.x + box.width * (0.3 + i * 0.02), box.y + box.height * (0.35 + i * 0.015));
  await page.mouse.up();
  await page.waitForTimeout(400);
  const afterBrush = await grab();
  await page.evaluate(() => window.__V2_APP__.setTool('smudge'));
  const smMode = await page.evaluate(() => ({ tool: window.__V2_APP__.state.tool, mode: window.__V2_APP__.controller.getMode(), preset: window.__V2_APP__.controller.preset.id }));
  const beforeSmudge = await grab();
  await page.mouse.move(box.x + box.width * 0.32, box.y + box.height * 0.37);
  await page.mouse.down();
  for (let i = 1; i <= 12; i++) await page.mouse.move(box.x + box.width * (0.32 + i * 0.018), box.y + box.height * (0.37 + i * 0.012));
  await page.mouse.up();
  await page.waitForTimeout(700);
  const afterSmudge = await grab();
  out.cases.smudge = { brushChanged: beforeBrush !== afterBrush, mode: smMode.mode, preset: smMode.preset, changed: beforeSmudge !== afterSmudge };
  await page.evaluate(() => window.__V2_APP__.setTool('brush'));

  // ---------- 矩形选区 + 约束 + Ctrl+D ----------
  await page.evaluate(() => { window.__V2_APP__.setTool('select'); window.__V2_APP__.t64.setSelectionMode('rect'); });
  await page.mouse.move(box.x + box.width * 0.2, box.y + box.height * 0.2);
  await page.mouse.down();
  for (let i = 1; i <= 8; i++) await page.mouse.move(box.x + box.width * (0.2 + i * 0.035), box.y + box.height * (0.2 + i * 0.04));
  await page.mouse.up();
  await page.waitForTimeout(400);
  out.cases.selection = await page.evaluate(() => ({ has: window.__V2_APP__.t64.hasSelection(), options: !document.getElementById('toolOptions').hidden, selGroup: !document.getElementById('toSelection').hidden, sel: window.__V2_APP__.state.selection }));
  await page.evaluate(() => { window.__V2_APP__.engine.setActiveLayer(window.__V2_APP__.engine.getLayers()[0].id); window.__V2_APP__.setTool('brush'); });
  const beforeOutside = await grab();
  await page.mouse.move(box.x + box.width * 0.72, box.y + box.height * 0.7);
  await page.mouse.down();
  for (let i = 1; i <= 6; i++) await page.mouse.move(box.x + box.width * (0.72 + i * 0.012), box.y + box.height * (0.7 + i * 0.015));
  await page.mouse.up();
  await page.waitForTimeout(350);
  const afterOutside = await grab();
  await page.keyboard.press('Control+d');
  await page.waitForTimeout(250);
  out.cases.selectionConstraint = { constrainedOutside: beforeOutside === afterOutside, cleared: !(await page.evaluate(() => window.__V2_APP__.t64.hasSelection())) };

  // ---------- 变换 ----------
  await page.evaluate(() => { window.__V2_APP__.engine.setActiveLayer(window.__V2_APP__.engine.getLayers()[0].id); });
  const undoBefore = await page.evaluate(() => window.__V2_APP__.engine.getStats().undoDepth);
  await page.evaluate(() => window.__V2_APP__.setTool('transform'));
  out.cases.transformStart = await page.evaluate(() => ({ active: window.__V2_APP__.state.transformActive, handles: (window.__V2_APP__.t64.getTransformHandles() || {}).handles ? window.__V2_APP__.t64.getTransformHandles().handles.length : 0, options: !document.getElementById('toolOptions').hidden, trVisible: !document.getElementById('toTransform').hidden }));
  await page.evaluate(() => { window.__V2_APP__.engine.updateTransform({ scaleX: 1.1, scaleY: 0.9, rotate: 15, x: 12, y: -8 }); window.__V2_APP__.t64.drawTransformOverlay(); window.__V2_APP__.t64.commitTransformUI(); });
  const undoAfter = await page.evaluate(() => window.__V2_APP__.engine.getStats().undoDepth);
  await page.evaluate(() => window.__V2_APP__.engine.undo());
  const undoAfterUndo = await page.evaluate(() => window.__V2_APP__.engine.getStats().undoDepth);
  out.cases.transform = { undoBefore, undoAfter, undoAfterUndo, committed: !(await page.evaluate(() => window.__V2_APP__.state.transformActive)), pass: undoAfter === undoBefore + 1 && undoAfterUndo === undoBefore };

  // ---------- 结构 undo/redo ----------
  await page.evaluate(() => window.__V2_APP__.setTool('brush'));
  const layers0 = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.evaluate(() => document.getElementById('btnAddLayer').click()); await page.waitForTimeout(250);
  const layers1 = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.evaluate(() => document.getElementById('btnDuplicateLayer').click()); await page.waitForTimeout(250);
  const layers2 = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.evaluate(() => { window.__V2_APP__.engine.undo(); window.__V2_APP__.engine.undo(); });
  const layersAfterUndo = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.evaluate(() => window.__V2_APP__.engine.redo());
  const layersAfterRedo = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  out.cases.structuralUndo = { layers0, layers1, layers2, layersAfterUndo, layersAfterRedo, pass: layers1 === layers0 + 1 && layers2 === layers0 + 2 && layersAfterUndo === layers0 && layersAfterRedo === layers0 + 1 };
  await page.evaluate(() => window.__V2_APP__.engine.undo());

  // ---------- 三档截图 ----------
  const shots = {};
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await page.setViewportSize({ width: w, height: h });
    box = await load();
    await page.evaluate(() => { window.__V2_APP__.setTool('select'); window.__V2_APP__.t64.setSelectionMode('rect'); });
    await page.waitForTimeout(350);
    await page.screenshot({ path: ROOT + '\\v2\\app\\ui-tools-' + w + '.png' });
    shots[w] = await page.evaluate(() => ({ overX: document.documentElement.scrollWidth > innerWidth + 1, overY: document.documentElement.scrollHeight > innerHeight + 1, optBottom: document.getElementById('toolOptions').getBoundingClientRect().bottom, bottom: document.querySelector('.pro-bottombar').getBoundingClientRect().top }));
  }
  out.cases.screenshots = shots;
  out.errors = errors.slice(0, 10);
  out.pass = {
    smudge: out.cases.smudge.brushChanged && out.cases.smudge.mode === 'smudge' && out.cases.smudge.changed,
    selection: out.cases.selection.has && out.cases.selection.options && out.cases.selection.selGroup,
    selectionConstraint: out.cases.selectionConstraint.constrainedOutside && out.cases.selectionConstraint.cleared,
    transform: out.cases.transformStart.active && out.cases.transformStart.handles >= 9 && out.cases.transformStart.options && out.cases.transformStart.trVisible && out.cases.transform.committed && out.cases.transform.pass,
    structuralUndo: out.cases.structuralUndo.pass,
    screenshots: Object.values(shots).every((v) => !v.overX && !v.overY && v.optBottom <= v.bottom + 1),
  };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  out.errors = errors ? errors.slice(0, 10) : [];
  console.log(JSON.stringify(out, null, 2));
} finally {
  clearTimeout(hard);
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  finish(0);
}
