# THIRD_PARTY_NOTICES · v2/brushes

本目录包含/引用的第三方代码与素材：

## 1. perfect-freehand 1.2.3（T52 新增）

- **项目**：perfect-freehand — https://github.com/steveruizok/perfect-freehand
- **版本**：npm `perfect-freehand@1.2.3`（从 npm registry 获取，`dist/esm/index.mjs`）
- **许可**：**MIT License**，Copyright (c) 2021 Stephen Ruiz Ltd（见 `vendor/perfect-freehand.LICENSE.txt`）
- **引入方式**：原样 vendor 到 `vendor/perfect-freehand.js`（文件头加了来源/版权注释；核心代码未修改）。
- **用途**：可选路径引擎 `pathEngine: 'perfect-freehand'` 的压感笔迹轮廓生成
  （`getStroke(points, { size, thinning, smoothing, streamline, taper, ... })`）。
- **MIT 义务**：保留版权声明与许可文本（已保留 LICENSE 文件 + 文件头注释 + 本清单）。
- **已知限制**：MIT 不提供任何担保；上游 API 版本升级需人工回归（本目录锁定 1.2.3）。

## 2. CanvasKit / Skia（经 v2/engine/vendor 间接使用）

- **许可**：BSD-3-Clause（见 `v2/engine/vendor/LICENSE` 与 `v2/engine/vendor/THIRD_PARTY_NOTICES.md`）。
- 本目录不直接 vendor CanvasKit，只经 `v2/engine` 引擎使用其 API。

## 3. 纹理素材

- `textures/*.png`：本项目自制（`textures/generate_textures.py` 生成，seed=20261106），随项目许可（MIT 待定）。
- 无 GPL / 无来源不明素材。

## 4. 参考但未复制代码的开源实现

| 项目 | 许可 | 使用方式 |
|---|---|---|
| Klecks (bitbof/klecks) | MIT | 仅行为/算法思路参考（BezierLine 过点相切平滑、延迟一段绘制等），代码为自研，未复制；对照测试通过浏览器公开 UI 驱动 |
| Krita / MyPaint / Drawpile | GPL-3.0 / GPL / GPL-3.0 | 只读算法思想，未复制、未链接、未 vendor 任何代码 |
