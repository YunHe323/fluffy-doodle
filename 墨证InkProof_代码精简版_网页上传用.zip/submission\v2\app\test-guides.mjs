// v2/app/test-guides.mjs —— 网格 / 三分线 / 对称轴 overlay
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8162;
const out = { schema: 'mozheng.app.guides.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-guides-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  const alpha = async () => page.evaluate(() => { const c = document.getElementById('guideCanvas'); const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let n = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 8) n += 1; return n; });
  await page.click('#btnMore'); await page.waitForTimeout(200);
  await page.click('#btnToggleGrid'); await page.waitForTimeout(200);
  out.cases.grid = { alpha: await alpha(), label: await page.textContent('#gridStateLabel'), state: await page.evaluate(() => window.__V2_APP__.state.showGrid) };
  await page.click('#btnToggleThirds'); await page.waitForTimeout(200);
  out.cases.thirds = { alpha: await alpha(), label: await page.textContent('#thirdsStateLabel'), state: await page.evaluate(() => window.__V2_APP__.state.showThirds) };
  await page.click('#btnToggleSymmetry'); await page.waitForTimeout(200);
  out.cases.symmetry = { alpha: await alpha(), label: await page.textContent('#btnToggleSymmetry'), axis: await page.evaluate(() => window.__V2_APP__.state.symmetryAxis) };
  // 自定义参考线：X=333 / Y=222
  await page.click('#btnCustomGuides'); await page.waitForTimeout(300);
  out.cases.guideModal = await page.evaluate(() => ({ show: !!document.querySelector('#guidesModal.show'), list: (document.getElementById('guideList') || {}).innerText || '' }));
  await page.fill('#guideXInput', '333'); await page.click('#btnAddGuideX');
  await page.fill('#guideYInput', '222'); await page.click('#btnAddGuideY');
  await page.waitForTimeout(300);
  out.cases.customGuides = await page.evaluate(() => { const a = window.__V2_APP__; const p = a.snapDocPoint({ x: 330, y: 219 }); return { count: a.state.customGuides.length, p: { x: p.x, y: p.y }, btn: (document.getElementById('btnCustomGuides') || {}).textContent || '' }; });
  out.cases.customOnly = await page.evaluate(() => { const a = window.__V2_APP__; a.state.showGrid = false; a.state.showThirds = false; const p = a.snapDocPoint({ x: 330, y: 219 }); return { p: { x: p.x, y: p.y } }; });
  await page.click('[data-close="guidesModal"]'); await page.waitForTimeout(250);
  out.cases.afterGuide = { alpha: await alpha() };
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-guides-1920.png' });
  out.cases.gridOk = out.cases.grid.alpha > 100 && out.cases.grid.label === '开' && out.cases.grid.state === true;
  out.cases.thirdsOk = out.cases.thirds.label === '开' && out.cases.thirds.state === true && out.cases.thirds.alpha > out.cases.grid.alpha;
  out.cases.symmetryOk = out.cases.symmetry.axis === 'x' && /左右/.test(out.cases.symmetry.label);
  out.cases.customOk = out.cases.guideModal.show && out.cases.customGuides.count === 2 && out.cases.customGuides.p.x === 333 && out.cases.customGuides.p.y === 222 && /\(2\)/.test(out.cases.customGuides.btn) && out.cases.customOnly.p.x === 333 && out.cases.customOnly.p.y === 222;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.gridOk && out.cases.thirdsOk && out.cases.symmetryOk && out.cases.customOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
