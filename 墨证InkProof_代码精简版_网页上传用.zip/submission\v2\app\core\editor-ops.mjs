/**
 * v2/app/core/editor-ops.mjs — T105-B 编辑器操作纯逻辑模块（Procreate/SAI 级基本功）
 *
 * 设计原则：
 *  - 本文件所有「纯函数」不依赖 DOM，可在 Node 直接 import + 单测；
 *  - 浏览器包装（computeAdjustedDataUrl / rasterizeShapeToDataUrl / rasterizeTextToDataUrl）
 *    内部才使用 document / OffscreenCanvas，Node 调用会得到明确报错；
 *  - 不修改 app.js / engine.js / CSS / HTML；由调用方（Lead/demo-builder）按需集成。
 *
 * 值域约定（详见 `06-技术/编辑器操作接口.md`）：
 *  - 颜色矩阵为 4×5（行优先 R/G/B/A 行，列为 r/g/b/a/offset），输入/输出归一化到 0..1
 *    （与 CanvasKit ColorFilter.MakeMatrix 兼容：offset 也是 0..1，不是 0..255）。
 *  - brightness ∈ [-1,1]（0 中性）：offset = brightness × 0.5（±1 对应 ±0.5，即极端到全黑/全白）；
 *  - contrast ∈ [-1,1]（0 中性）：factor = 1 + contrast，围绕 0.5 缩放；
 *  - saturation ∈ [0,2]（1 中性）：Rec.709 luma 混合；
 *  - hue ∈ [-180,180]（度，0 中性）：SVG feColorMatrix hueRotate 公式。
 */

export const COLOR_MATRIX_SIZE = 20;

export const ADJUSTMENT_DEFAULTS = Object.freeze({
  brightness: 0,
  contrast: 0,
  saturation: 1,
  hue: 0,
});

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

/** 单位颜色矩阵（4×5，归一化 offset=0） */
export function identityColorMatrix() {
  return [
    1, 0, 0, 0, 0,
    0, 1, 0, 0, 0,
    0, 0, 1, 0, 0,
    0, 0, 0, 1, 0,
  ];
}

/** 4×5 颜色矩阵相乘：先应用 a，再应用 b（b · a，A 通道恒等） */
export function multiplyColorMatrices(a, b) {
  if (!Array.isArray(a) || a.length !== COLOR_MATRIX_SIZE) throw new TypeError('multiplyColorMatrices: a 需 20 个元素');
  if (!Array.isArray(b) || b.length !== COLOR_MATRIX_SIZE) throw new TypeError('multiplyColorMatrices: b 需 20 个元素');
  const out = new Array(COLOR_MATRIX_SIZE).fill(0);
  for (let row = 0; row < 4; row += 1) {
    for (let col = 0; col < 5; col += 1) {
      let sum = 0;
      for (let k = 0; k < 4; k += 1) sum += b[row * 5 + k] * a[k * 5 + col];
      if (col === 4) sum += b[row * 5 + 4];
      out[row * 5 + col] = sum;
    }
  }
  return out;
}

/** 归一化参数（缺省值 + 范围收敛） */
export function normalizeAdjustmentParams(params = {}) {
  const p = params || {};
  return {
    brightness: clamp(Number.isFinite(+p.brightness) ? +p.brightness : 0, -1, 1),
    contrast: clamp(Number.isFinite(+p.contrast) ? +p.contrast : 0, -1, 1),
    saturation: clamp(Number.isFinite(+p.saturation) ? +p.saturation : 1, 0, 2),
    hue: clamp(Number.isFinite(+p.hue) ? +p.hue : 0, -180, 180),
  };
}

/** 亮度矩阵：output = input + offset */
export function brightnessMatrix(brightness) {
  const offset = clamp(brightness, -1, 1) * 0.5;
  return [
    1, 0, 0, 0, offset,
    0, 1, 0, 0, offset,
    0, 0, 1, 0, offset,
    0, 0, 0, 1, 0,
  ];
}

/** 对比度矩阵：围绕 0.5 缩放（factor=1 中性；contrast=-1→0，+1→2） */
export function contrastMatrix(contrast) {
  const f = 1 + clamp(contrast, -1, 0.999);
  const offset = 0.5 * (1 - f);
  return [
    f, 0, 0, 0, offset,
    0, f, 0, 0, offset,
    0, 0, f, 0, offset,
    0, 0, 0, 1, 0,
  ];
}

/** 饱和度矩阵（luma 混合；s=1 中性，s=0 灰度，s=2 过饱和） */
export function saturationMatrix(saturation) {
  const s = clamp(saturation, 0, 2);
  const lr = 0.2126, lg = 0.7152, lb = 0.0722;
  const a = (1 - s) * lr, b = (1 - s) * lg, c = (1 - s) * lb;
  return [
    a + s, b, c, 0, 0,
    a, b + s, c, 0, 0,
    a, b, c + s, 0, 0,
    0, 0, 0, 1, 0,
  ];
}

/** 色相旋转矩阵（SVG feColorMatrix hueRotate，Rec.601 权重；hue 单位：度） */
export function hueMatrix(hueDeg) {
  const rad = (clamp(hueDeg, -180, 180) * Math.PI) / 180;
  const cos = Math.cos(rad), sin = Math.sin(rad);
  return [
    0.213 + cos * 0.787 - sin * 0.213, 0.715 - cos * 0.715 - sin * 0.715, 0.072 - cos * 0.072 + sin * 0.928, 0, 0,
    0.213 - cos * 0.213 + sin * 0.143, 0.715 + cos * 0.285 + sin * 0.140, 0.072 - cos * 0.072 - sin * 0.283, 0, 0,
    0.213 - cos * 0.213 - sin * 0.787, 0.715 - cos * 0.715 + sin * 0.715, 0.072 + cos * 0.928 + sin * 0.072, 0, 0,
    0, 0, 0, 1, 0,
  ];
}

/**
 * 颜色调整矩阵（4×5，归一化 0..1）。
 * 组合顺序：brightness → contrast → saturation → hue（先执行的在右乘）。
 * @param {{brightness?:number,contrast?:number,saturation?:number,hue?:number}} [params]
 * @returns {number[]} 长度 20 的矩阵（行优先 4 行 × 5 列；offset 归一化 0..1）
 */
export function getAdjustmentMatrix(params = {}) {
  const p = normalizeAdjustmentParams(params);
  let m = identityColorMatrix();
  if (p.brightness !== 0) m = multiplyColorMatrices(m, brightnessMatrix(p.brightness));
  if (p.contrast !== 0) m = multiplyColorMatrices(m, contrastMatrix(p.contrast));
  if (p.saturation !== 1) m = multiplyColorMatrices(m, saturationMatrix(p.saturation));
  if (p.hue !== 0) m = multiplyColorMatrices(m, hueMatrix(p.hue));
  return m;
}

/**
 * 纯像素颜色调整：返回新 Uint8ClampedArray（不修改入参）。
 * 透明像素（alpha=0）保持原样（RGBA 全部拷贝），避免出现半透明黑边。
 * @param {Uint8Array|Uint8ClampedArray} rgba
 * @param {number} width
 * @param {number} height
 * @param {{brightness?:number,contrast?:number,saturation?:number,hue?:number}} [params]
 * @returns {Uint8ClampedArray}
 */
export function applyAdjustmentsToPixels(rgba, width, height, params = {}) {
  if (!rgba || typeof rgba.length !== 'number') throw new TypeError('applyAdjustmentsToPixels: rgba 需为 Uint8(Clamped)Array');
  const w = Math.max(0, Math.floor(width));
  const h = Math.max(0, Math.floor(height));
  const need = w * h * 4;
  if (w === 0 || h === 0) throw new TypeError('applyAdjustmentsToPixels: width/height 需为正整数');
  if (rgba.length < need) throw new RangeError(`applyAdjustmentsToPixels: rgba 长度 ${rgba.length} < ${need}`);
  const m = getAdjustmentMatrix(params);
  const out = new Uint8ClampedArray(need);
  // 输入按 0..255 参与矩阵（RGB 行和为 1），offset 从归一化 0..1 ×255 转成像素偏移
  const r00 = m[0], r01 = m[1], r02 = m[2], r03 = m[3], r04 = m[4] * 255;
  const g00 = m[5], g01 = m[6], g02 = m[7], g03 = m[8], g04 = m[9] * 255;
  const b00 = m[10], b01 = m[11], b02 = m[12], b03 = m[13], b04 = m[14] * 255;
  const a00 = m[15], a01 = m[16], a02 = m[17], a03 = m[18], a04 = m[19] * 255;
  for (let i = 0; i < need; i += 4) {
    const r = rgba[i], g = rgba[i + 1], b = rgba[i + 2], a = rgba[i + 3];
    if (a === 0) { out[i] = r; out[i + 1] = g; out[i + 2] = b; out[i + 3] = 0; continue; }
    out[i] = clamp(r00 * r + r01 * g + r02 * b + r03 * a + r04, 0, 255);
    out[i + 1] = clamp(g00 * r + g01 * g + g02 * b + g03 * a + g04, 0, 255);
    out[i + 2] = clamp(b00 * r + b01 * g + b02 * b + b03 * a + b04, 0, 255);
    out[i + 3] = clamp(a00 * r + a01 * g + a02 * b + a03 * a + a04, 0, 255);
  }
  return out;
}

/* ============================ 浏览器环境工具 ============================ */

function needBrowserCanvas() {
  if (typeof document !== 'undefined' && typeof document.createElement === 'function') return 'dom';
  if (typeof OffscreenCanvas !== 'undefined') return 'offscreen';
  throw new Error('editor-ops: 该函数需要浏览器环境（document 或 OffscreenCanvas）');
}

function createCanvasEl(width, height) {
  const w = Math.max(1, Math.round(width));
  const h = Math.max(1, Math.round(height));
  const env = needBrowserCanvas();
  if (env === 'dom') {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    return c;
  }
  return new OffscreenCanvas(w, h);
}

async function canvasToDataUrl(canvas) {
  if (typeof canvas.toDataURL === 'function') return canvas.toDataURL('image/png');
  if (typeof canvas.convertToBlob === 'function') {
    const blob = await canvas.convertToBlob({ type: 'image/png' });
    const dataUrl = await new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result || ''));
      fr.onerror = () => reject(fr.error || new Error('读取 blob 失败'));
      fr.readAsDataURL(blob);
    });
    return dataUrl;
  }
  throw new Error('editor-ops: canvas 不支持 toDataURL/convertToBlob');
}

async function loadImageElement(dataUrl) {
  if (typeof Image === 'undefined') throw new Error('editor-ops: 当前环境无 Image');
  const img = new Image();
  img.decoding = 'async';
  const p = new Promise((resolve, reject) => {
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('图片解码失败'));
  });
  img.src = dataUrl;
  if (typeof img.decode === 'function') {
    try { await img.decode(); } catch (e) { /* 走 onload 兜底 */ }
  }
  return p;
}

/**
 * 浏览器包装：读 dataURL → 像素调整 → 返回新 PNG dataURL。
 * Node 环境调用会 reject（明确报错），不静默返回错误结果。
 * @param {string} dataUrl
 * @param {{brightness?:number,contrast?:number,saturation?:number,hue?:number}} [params]
 * @returns {Promise<string>} PNG dataURL（尺寸与原图一致）
 */
export async function computeAdjustedDataUrl(dataUrl, params = {}) {
  if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:')) throw new TypeError('computeAdjustedDataUrl: 需要 image dataURL');
  const img = await loadImageElement(dataUrl);
  const w = Math.max(1, img.naturalWidth || img.width);
  const h = Math.max(1, img.naturalHeight || img.height);
  const canvas = createCanvasEl(w, h);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, 0, 0, w, h);
  const imgData = ctx.getImageData(0, 0, w, h);
  const out = applyAdjustmentsToPixels(imgData.data, w, h, params);
  imgData.data.set(out);
  ctx.putImageData(imgData, 0, 0);
  return canvasToDataUrl(canvas);
}

/* ============================ 形状几何（纯函数） ============================ */

function num(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function shapeType(shape) {
  const t = shape && shape.type;
  if (t !== 'rect' && t !== 'ellipse' && t !== 'line') {
    throw new TypeError(`shapeToSvgPath/computeShapeBounds: 不支持 shape.type=${JSON.stringify(t)}（支持 rect/ellipse/line）`);
  }
  return t;
}

function rotationDeg(shape) { return num(shape.rotation, 0); }

function rotatePoint(px, py, cx, cy, deg) {
  if (!deg) return { x: px, y: py };
  const rad = (deg * Math.PI) / 180;
  const cos = Math.cos(rad), sin = Math.sin(rad);
  const dx = px - cx, dy = py - cy;
  return { x: cx + dx * cos - dy * sin, y: cy + dx * sin + dy * cos };
}

/** 形状基础轴对齐 bbox（未旋转） */
function baseBounds(shape) {
  const t = shapeType(shape);
  if (t === 'rect') {
    const x = num(shape.x), y = num(shape.y);
    const w = Math.max(0, num(shape.width)), h = Math.max(0, num(shape.height));
    return { x, y, width: w, height: h };
  }
  if (t === 'ellipse') {
    if (shape.rx != null || shape.ry != null) {
      const cx = num(shape.cx), cy = num(shape.cy);
      const rx = Math.max(0, Math.abs(num(shape.rx))), ry = Math.max(0, Math.abs(num(shape.ry)));
      return { x: cx - rx, y: cy - ry, width: rx * 2, height: ry * 2 };
    }
    const x = num(shape.x), y = num(shape.y);
    const w = Math.max(0, num(shape.width)), h = Math.max(0, num(shape.height));
    return { x, y, width: w, height: h };
  }
  const x1 = num(shape.x1), y1 = num(shape.y1), x2 = num(shape.x2), y2 = num(shape.y2);
  return { x: Math.min(x1, x2), y: Math.min(y1, y2), width: Math.abs(x2 - x1), height: Math.abs(y2 - y1) };
}

/** 形状几何 bbox（含 rotation 后的轴对齐外接框；不含描边宽度） */
export function computeShapeBounds(shape) {
  const t = shapeType(shape);
  const base = baseBounds(shape);
  const deg = rotationDeg(shape);
  if (!deg) return { ...base };
  const cx = base.x + base.width / 2;
  const cy = base.y + base.height / 2;
  if (t === 'ellipse') {
    const rad = (deg * Math.PI) / 180;
    const rx = base.width / 2, ry = base.height / 2;
    const halfW = Math.hypot(rx * Math.cos(rad), ry * Math.sin(rad));
    const halfH = Math.hypot(rx * Math.sin(rad), ry * Math.cos(rad));
    return { x: cx - halfW, y: cy - halfH, width: halfW * 2, height: halfH * 2 };
  }
  const pts = [];
  if (t === 'rect') {
    pts.push([base.x, base.y], [base.x + base.width, base.y], [base.x + base.width, base.y + base.height], [base.x, base.y + base.height]);
  } else {
    pts.push([num(shape.x1), num(shape.y1)], [num(shape.x2), num(shape.y2)]);
  }
  const rotated = pts.map(([px, py]) => rotatePoint(px, py, cx, cy, deg));
  const xs = rotated.map((p) => p.x), ys = rotated.map((p) => p.y);
  const minX = Math.min(...xs), minY = Math.min(...ys);
  return { x: minX, y: minY, width: Math.max(...xs) - minX, height: Math.max(...ys) - minY };
}

/**
 * 形状 → SVG path 字符串（未旋转的局部几何；rotation 需由调用方 transform）。
 * rect: M x y H x+w V y+h H x Z
 * ellipse: 两段 A 弧（四分之一圆路径闭合）
 * line: M x1 y1 L x2 y2
 */
export function shapeToSvgPath(shape) {
  const t = shapeType(shape);
  const b = baseBounds(shape);
  const fmt = (v) => {
    const r = Math.round(v * 1000) / 1000;
    return Object.is(r, -0) ? 0 : r;
  };
  if (t === 'rect') {
    const { x, y, width: w, height: h } = b;
    if (!(w > 0) || !(h > 0)) throw new RangeError('shapeToSvgPath: rect 需要正 width/height');
    return `M ${fmt(x)} ${fmt(y)} H ${fmt(x + w)} V ${fmt(y + h)} H ${fmt(x)} Z`;
  }
  if (t === 'ellipse') {
    const rx = b.width / 2, ry = b.height / 2;
    if (!(rx > 0) || !(ry > 0)) throw new RangeError('shapeToSvgPath: ellipse 需要正 rx/ry（或 width/height）');
    const cx = b.x + rx, cy = b.y + ry;
    return `M ${fmt(cx - rx)} ${fmt(cy)} A ${fmt(rx)} ${fmt(ry)} 0 1 0 ${fmt(cx + rx)} ${fmt(cy)} A ${fmt(rx)} ${fmt(ry)} 0 1 0 ${fmt(cx - rx)} ${fmt(cy)} Z`;
  }
  return `M ${fmt(num(shape.x1))} ${fmt(num(shape.y1))} L ${fmt(num(shape.x2))} ${fmt(num(shape.y2))}`;
}

/**
 * 形状光栅化计划（纯函数，便于 Node 测试与调用方预计算落点）。
 * @param {object} shape
 * @param {{pixelWidth?:number,pixelHeight?:number,padding?:number,strokeWidth?:number}} [opts]
 *   pixelWidth/pixelHeight 缺省 = bounds + 2*(padding + strokeWidth/2)
 * @returns {{width:number,height:number,scale:number,offsetX:number,offsetY:number,bounds:object,contentBox:object,strokeWidth:number}}
 */
export function computeShapeRasterPlan(shape, opts = {}) {
  const bounds = computeShapeBounds(shape);
  const padding = Math.max(0, num(opts.padding, 0));
  const strokeWidth = Math.max(0, num(opts.strokeWidth, 0));
  const pad = padding + strokeWidth / 2;
  const contentW = bounds.width + pad * 2;
  const contentH = bounds.height + pad * 2;
  let width = Math.max(1, Math.round(num(opts.pixelWidth, Math.ceil(contentW) || 1)));
  let height = Math.max(1, Math.round(num(opts.pixelHeight, Math.ceil(contentH) || 1)));
  if (width <= 0) width = 1;
  if (height <= 0) height = 1;
  // 等比缩放到目标画布，居中
  const fit = fitRectIntoCanvas(contentW, contentH, width, height);
  const scale = fit.scale;
  return {
    width, height, scale,
    offsetX: fit.x, offsetY: fit.y,
    bounds, padding, strokeWidth,
    contentBox: { x: 0, y: 0, width: contentW, height: contentH },
  };
}

function drawShape(ctx, shape, plan, { fill = 'none', stroke = '#000000', strokeWidth = 1 } = {}) {
  const b = plan.bounds || computeShapeBounds(shape);
  const base = baseBounds(shape);
  const deg = rotationDeg(shape);
  const cx = base.x + base.width / 2, cy = base.y + base.height / 2;
  ctx.save();
  ctx.translate(plan.offsetX, plan.offsetY);
  ctx.scale(plan.scale, plan.scale);
  ctx.translate(-b.x + (plan.padding || 0) + (plan.strokeWidth || 0) / 2, -b.y + (plan.padding || 0) + (plan.strokeWidth || 0) / 2);
  if (deg) {
    ctx.translate(cx, cy);
    ctx.rotate((deg * Math.PI) / 180);
    ctx.translate(-cx, -cy);
  }
  ctx.beginPath();
  const t = shapeType(shape);
  if (t === 'rect') {
    const r = baseBounds(shape);
    ctx.rect(r.x, r.y, r.width, r.height);
  } else if (t === 'ellipse') {
    const r = baseBounds(shape);
    const rx = Math.max(0.0001, r.width / 2), ry = Math.max(0.0001, r.height / 2);
    ctx.ellipse(r.x + rx, r.y + ry, rx, ry, 0, 0, Math.PI * 2);
  } else {
    ctx.moveTo(num(shape.x1), num(shape.y1));
    ctx.lineTo(num(shape.x2), num(shape.y2));
  }
  if (fill && fill !== 'none') { ctx.fillStyle = fill; ctx.fill(); }
  if (strokeWidth > 0) {
    ctx.lineWidth = Math.max(0.0001, strokeWidth / Math.max(plan.scale, 1e-6));
    ctx.strokeStyle = stroke || '#000000';
    ctx.stroke();
  }
  ctx.restore();
}

/**
 * 浏览器包装：形状 → PNG dataURL（透明背景）。
 * @param {object} shape rect/ellipse/line；可选 rotation(deg)
 * @param {{pixelWidth?:number,pixelHeight?:number,padding?:number,fill?:string,stroke?:string,strokeWidth?:number}} [opts]
 * @returns {Promise<{dataUrl:string,width:number,height:number,plan:object}>}
 */
export async function rasterizeShapeToDataUrl(shape, opts = {}) {
  const plan = computeShapeRasterPlan(shape, opts);
  const canvas = createCanvasEl(plan.width, plan.height);
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, plan.width, plan.height);
  drawShape(ctx, shape, plan, {
    fill: opts.fill == null ? 'none' : opts.fill,
    stroke: opts.stroke == null ? (opts.fill && opts.fill !== 'none' ? 'none' : '#000000') : opts.stroke,
    strokeWidth: opts.strokeWidth == null ? 1 : opts.strokeWidth,
  });
  const dataUrl = await canvasToDataUrl(canvas);
  return { dataUrl, width: plan.width, height: plan.height, plan };
}

/* ============================ 文本（纯布局 + 浏览器光栅） ============================ */

export const TEXT_DEFAULTS = Object.freeze({
  fontSize: 48,
  fontFamily: 'system-ui, "Microsoft YaHei", sans-serif',
  color: '#000000',
  lineHeight: 1.25,
  padding: 16,
});

/** 文本按 \n 切行；空字符串 → []（不产生空图层） */
export function splitTextLines(text) {
  if (text == null) return [];
  const s = String(text);
  if (!s.trim()) return [];
  return s.split(/\r?\n/).map((ln) => ln.replace(/\s+$/u, ''));
}

/** 归一化文本参数（Node 也可用） */
export function normalizeTextOptions(opts = {}) {
  const o = { ...TEXT_DEFAULTS, ...(opts || {}) };
  return {
    fontSize: Math.max(1, num(o.fontSize, TEXT_DEFAULTS.fontSize)),
    fontFamily: String(o.fontFamily || TEXT_DEFAULTS.fontFamily),
    color: String(o.color || TEXT_DEFAULTS.color),
    lineHeight: num(o.lineHeight, TEXT_DEFAULTS.lineHeight) > 0 ? num(o.lineHeight, 1.25) : TEXT_DEFAULTS.lineHeight,
    padding: Math.max(0, num(o.padding, TEXT_DEFAULTS.padding)),
    text: o.text == null ? '' : String(o.text),
  };
}

/**
 * 纯文本布局：无字体度量时用「字符数 × fontSize × 0.6」估算宽度；
 * 浏览器包装会传入 measureLine 用真实 metrics。
 * @param {{text:string,fontSize?:number,fontFamily?:string,lineHeight?:number,padding?:number}} opts
 * @param {(line:string,ctx:{fontSize:number,fontFamily:string})=>number} [measureLine]
 * @returns {{lines:string[],lineHeightPx:number,width:number,height:number,padding:number,font:string,color:string}}
 */
export function computeTextLayout(opts = {}, measureLine) {
  const o = normalizeTextOptions(opts);
  const lines = splitTextLines(o.text);
  const lineHeightPx = o.fontSize * o.lineHeight;
  const font = `${o.fontSize}px ${o.fontFamily}`;
  const pad = o.padding;
  if (!lines.length) {
    return { lines: [], lineHeightPx, width: Math.max(1, Math.ceil(pad * 2)), height: Math.max(1, Math.ceil(pad * 2)), padding: pad, font, color: o.color };
  }
  let maxW = 0;
  for (const ln of lines) {
    const measured = typeof measureLine === 'function'
      ? Math.max(0, Number(measureLine(ln, { fontSize: o.fontSize, fontFamily: o.fontFamily })) || 0)
      : Array.from(ln).length * o.fontSize * 0.6;
    if (measured > maxW) maxW = measured;
  }
  return {
    lines,
    lineHeightPx,
    width: Math.max(1, Math.ceil(maxW + pad * 2)),
    height: Math.max(1, Math.ceil(lines.length * lineHeightPx + pad * 2)),
    padding: pad,
    font,
    color: o.color,
  };
}

/**
 * 浏览器包装：文本 → PNG dataURL（透明背景，textBaseline='top'）。
 * 空文本返回 1×1 透明 dataURL（lines=[]，避免创建空图层数据）。
 * @param {{text:string,fontSize?:number,fontFamily?:string,color?:string,lineHeight?:number,padding?:number}} opts
 * @returns {Promise<{dataUrl:string,width:number,height:number,layout:object}>}
 */
export async function rasterizeTextToDataUrl(opts = {}) {
  const o = normalizeTextOptions(opts);
  const env = needBrowserCanvas();
  // 先建临时 canvas 量字体宽度（与最终绘制同字体）
  const probe = createCanvasEl(8, 8);
  const pctx = probe.getContext('2d');
  pctx.font = `${o.fontSize}px ${o.fontFamily}`;
  const measure = (line) => pctx.measureText(line).width;
  const layout = computeTextLayout({ ...o, text: o.text }, measure);
  const canvas = createCanvasEl(layout.width, layout.height);
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (layout.lines.length) {
    ctx.font = layout.font;
    ctx.fillStyle = layout.color;
    ctx.textBaseline = 'top';
    layout.lines.forEach((ln, i) => {
      ctx.fillText(ln, layout.padding, layout.padding + i * layout.lineHeightPx);
    });
  }
  const dataUrl = await canvasToDataUrl(canvas);
  void env;
  return { dataUrl, width: canvas.width, height: canvas.height, layout };
}

/* ============================ 适配框（纯函数） ============================ */

/**
 * 等比 contain 适配：把 srcW×srcH 放进 dstW×dstH，居中，返回绘制 box。
 * 允许放大（scale 可 >1）；非法/零尺寸返回 zeros。
 * @param {number} srcW
 * @param {number} srcH
 * @param {number} dstW
 * @param {number} dstH
 * @returns {{x:number,y:number,width:number,height:number,scale:number}}
 */
export function fitRectIntoCanvas(srcW, srcH, dstW, dstH) {
  const sw = Number(srcW), sh = Number(srcH), dw = Number(dstW), dh = Number(dstH);
  const zeros = { x: 0, y: 0, width: 0, height: 0, scale: 0 };
  if (![sw, sh, dw, dh].every((v) => Number.isFinite(v))) return zeros;
  if (sw <= 0 || sh <= 0 || dw <= 0 || dh <= 0) return zeros;
  const scale = Math.min(dw / sw, dh / sh);
  const width = Math.max(1, Math.round(sw * scale * 1000) / 1000);
  const height = Math.max(1, Math.round(sh * scale * 1000) / 1000);
  const x = Math.round(((dw - width) / 2) * 1000) / 1000;
  const y = Math.round(((dh - height) / 2) * 1000) / 1000;
  return { x, y, width, height, scale };
}

export default {
  ADJUSTMENT_DEFAULTS,
  COLOR_MATRIX_SIZE,
  TEXT_DEFAULTS,
  identityColorMatrix,
  multiplyColorMatrices,
  normalizeAdjustmentParams,
  brightnessMatrix,
  contrastMatrix,
  saturationMatrix,
  hueMatrix,
  getAdjustmentMatrix,
  applyAdjustmentsToPixels,
  computeAdjustedDataUrl,
  computeShapeBounds,
  shapeToSvgPath,
  computeShapeRasterPlan,
  rasterizeShapeToDataUrl,
  splitTextLines,
  normalizeTextOptions,
  computeTextLayout,
  rasterizeTextToDataUrl,
  fitRectIntoCanvas,
};
