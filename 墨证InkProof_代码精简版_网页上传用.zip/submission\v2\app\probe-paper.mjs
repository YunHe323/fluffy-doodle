// probe-paper.mjs — inspect T86 computed colors
import { spawn } from 'node:child_process';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8118;
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const b = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
const page = await b.newPage({ viewport: { width: 1920, height: 1080 } });
await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`);
await page.waitForFunction('window.__V2_APP_READY__ === true');
await page.waitForTimeout(500);
await page.click('#btnLibrary');
await page.waitForTimeout(1500);
const info = await page.evaluate(() => {
  const cs = (s) => { const e = document.querySelector(s); return e ? getComputedStyle(e) : null; };
  const out = {
    body: cs('body') && { bg: cs('body').backgroundColor, color: cs('body').color, img: cs('body').backgroundImage.slice(0, 60) },
    theme: document.documentElement.dataset.theme,
    backdrop: cs('#libraryBackdrop') && { bg: cs('#libraryBackdrop').backgroundColor, z: cs('#libraryBackdrop').zIndex, display: cs('#libraryBackdrop').display, hidden: document.getElementById('libraryBackdrop').hidden, filter: cs('#libraryBackdrop').backdropFilter },
    sheet: cs('#librarySheet') && { bg: cs('#librarySheet').backgroundColor, color: cs('#librarySheet').color },
    h1: cs('.lib-h1') && { color: cs('.lib-h1').color, fontSize: cs('.lib-h1').fontSize },
    summary: cs('.lib-l1-summary') && { color: cs('.lib-l1-summary').color, fontSize: cs('.lib-l1-summary').fontSize },
    l2label: cs('.lib-l2-label') && { color: cs('.lib-l2-label').color },
    topbar: cs('.pro-topbar') && { bg: cs('.pro-topbar').backgroundColor, color: cs('.pro-topbar').color },
    canvas: cs('#mainCanvas') && { bg: cs('#mainCanvas').backgroundColor, border: cs('#mainCanvas').borderTopColor },
    hitAt50: document.elementFromPoint(50, 50) && document.elementFromPoint(50, 50).id || document.elementFromPoint(50, 50).className,
  };
  return out;
});
console.log(JSON.stringify(info, null, 2));
await page.screenshot({ path: ROOT + '\\v2\\app\\ui-paper-probe.png' });
await b.close(); py.kill(); process.exit(0);
