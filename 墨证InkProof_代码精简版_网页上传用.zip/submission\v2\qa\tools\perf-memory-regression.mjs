#!/usr/bin/env node
/**
 * v2/qa/tools/perf-memory-regression.mjs — M4.5 P1b：T88 present 脏区/双缓冲 A/B + T89 历史内存回收（QA 独立口径）
 *
 * 真实 Edge 优先：默认 **headed Edge（窗口移到屏幕外 -3000,-3000）**；`--headless` 用于对照（提交-only 数据失真，会标注）。
 *
 * 输出：tools/perf-memory-regression.json
 * 用法：node v2/qa/tools/perf-memory-regression.mjs [--headless] [--port 4262]
 */
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const QA = path.resolve(__dirname, '..');
const REPO = path.resolve(QA, '..', '..');
const require = createRequire(import.meta.url);
const argv = process.argv.slice(2);
const argOf = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? argv[i + 1] : d; };
const HEADLESS = argv.includes('--headless');
const PORT = Number(argOf('--port', 4262));
const OUT = path.join(__dirname, 'perf-memory-regression.json');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const nowIso = () => new Date().toISOString();

async function startServer() {
  const portFile = path.join(REPO, 'v2', '.runtime-port');
  await fsp.rm(portFile, { force: true }).catch(() => {});
  const proc = spawn(process.execPath, [path.join(REPO, 'v2', 'serve.mjs')], { cwd: REPO, env: { ...process.env, PORT: String(PORT) }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  for (let i = 0; i < 120; i += 1) {
    await sleep(150);
    try { const p = Number(String(await fsp.readFile(portFile, 'utf8')).trim()); const r = await fetch(`http://127.0.0.1:${p}/v2/engine/demo.html`); if (r.ok) return { origin: `http://127.0.0.1:${p}`, proc }; } catch { /* wait */ }
  }
  throw new Error('无法启动静态服务');
}

const INSTRUMENT = `
window.__PM__ = window.__PM__ || {};
try {
  if (!window.__PM_OBS__) {
    window.__PM_OBS__ = new PerformanceObserver((l) => { for (const e of l.getEntries()) (window.__PM__.longtasks = window.__PM__.longtasks || []).push({ dur: Math.round(e.duration) }); });
    window.__PM_OBS__.observe({ entryTypes: ['longtask'] });
  }
} catch (e) { window.__PM__.ltError = String(e); }
window.__PM__.resetLT = () => { window.__PM__.longtasks = []; };
window.__PM__.lt = () => { const a = window.__PM__.longtasks || []; return { count: a.length, over50: a.filter((x) => x.dur > 50).length, longest: a.length ? Math.max(...a.map((x) => x.dur)) : 0 }; };
window.__PM__.raf = () => new Promise((r) => requestAnimationFrame(r));
window.__PM__.pct = (arr, p) => { const a = arr.slice().sort((x, y) => x - y); return a.length ? Math.round(a[Math.min(a.length - 1, Math.floor(a.length * p))] * 100) / 100 : null; };
window.__PM__.mkEngine = async (size) => {
  const { Engine } = await import(new URL('./src/engine.js', location.href).href);
  const canvas = document.createElement('canvas');
  canvas.width = size; canvas.height = size;
  canvas.style.cssText = 'position:fixed;left:-99999px;top:0;width:128px;height:128px';
  document.body.appendChild(canvas);
  const e = new Engine({ canvas, width: size, height: size, layers: 2, presentRetained: true });
  await e.init();
  e.setBrush({ type: 'soft', sizePx: Math.max(16, Math.round(size / 64)) });
  for (let s = 0; s < 2; s += 1) {
    const y = 100 + s * Math.round(size / 8);
    e.beginStroke({ x: 80, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
    for (let i = 1; i < 16; i += 1) e.appendPoint({ x: 80 + i * Math.round(size / 40), y: y + Math.sin(i / 3) * 24, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
    e.endStroke();
  }
  await window.__PM__.raf(); await window.__PM__.raf();
  return e;
};
window.__PM__.syncGPU = (e) => {
  try {
    const CK = e.CK;
    const im = e.presentSurface.makeImageSnapshot();
    im.readPixels(0, 0, { width: 1, height: 1, colorType: CK.ColorType.RGBA_8888, alphaType: CK.AlphaType.Unpremul, colorSpace: CK.ColorSpace.SRGB });
    im.delete();
  } catch (err) { /* ignore */ }
};
window.__PM__.compositePixels = async (e) => {
  try { e.compositor.compositeAll(e.store); } catch (err) { /* ignore */ }
  const url = await e.getCompositeDataUrl();
  const img = new Image(); img.src = url; await img.decode();
  const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
  const g = c.getContext('2d'); g.drawImage(img, 0, 0);
  return { w: c.width, h: c.height, d: g.getImageData(0, 0, c.width, c.height).data };
};
window.__PM__.pixelDiffData = (A, B, stride) => {
  let changed = 0, total = 0, maxD = 0;
  const step = stride || 1;
  for (let i = 0; i < A.d.length; i += 4 * step) {
    total += 1;
    const d = Math.max(Math.abs(A.d[i] - B.d[i]), Math.abs(A.d[i + 1] - B.d[i + 1]), Math.abs(A.d[i + 2] - B.d[i + 2]));
    if (d > 8) changed += 1;
    if (d > maxD) maxD = d;
  }
  return { changed, total, maxDelta: maxD };
};
`;

async function presentSuite(page, size) {
  return page.evaluate(async (sz) => {
    const PM = window.__PM__;
    const out = { size: sz };
    try {
      const e = await PM.mkEngine(sz);
      const memBefore = e.getStats().memoryEstimateMB;
      const presentSurfaceMB = e.getStats().presentSurfaceMB;
      const sync = () => PM.syncGPU(e);
      const sample = (fn, n) => { const times = []; for (let i = 0; i < n; i += 1) { const t = performance.now(); fn(); sync(); times.push(performance.now() - t); } return times; };
      // A: 全量 present
      e.setPresentStrategy('full');
      sample(() => e.presentFull(), 3);
      const fullTimes = sample(() => e.presentFull(), sz === 4096 ? 12 : 20);
      const fullStats = e.getPresentStats();
      // B: 脏区 present（单 tile）
      e.setPresentStrategy('dirty');
      sample(() => e.presentDirty(['0,0']), 3);
      const dirtyTimes = sample(() => e.presentDirty(['0,0']), sz === 4096 ? 12 : 20);
      const dirtyStats = e.getPresentStats();
      // C: 每帧调度（rAF）帧间隔 — dirty / full 各 40 帧
      const frameLoop = async (mode, frames) => {
        e.setPresentStrategy(mode);
        PM.resetLT();
        const deltas = []; let last = performance.now();
        for (let i = 0; i < frames; i += 1) { await PM.raf(); const t = performance.now(); deltas.push(t - last); last = t; if (mode === 'dirty') e.presentDirty(['0,0']); else e.presentFull(); }
        const avg = deltas.reduce((a, b) => a + b, 0) / deltas.length;
        return { p50: PM.pct(deltas, 0.5), p95: PM.pct(deltas, 0.95), avg: Math.round(avg * 100) / 100, fps: Math.round((1000 / avg) * 10) / 10, longTask: PM.lt() };
      };
      const frameDirty = await frameLoop('dirty', 40);
      const frameFull = await frameLoop('full', 40);
      // D: 正确性 —— dirty 策略下 present 保留帧 vs 合成图（采样 4x4 网格 + 逐像素抽样）
      e.setPresentStrategy('dirty');
      e.presentDirty(['0,0']); e.presentDirty(['1,1']);
      await PM.raf(); await PM.raf();
      const comp = await PM.compositePixels(e);
      const CK = e.CK;
      const im = e.presentSurface.makeImageSnapshot();
      const info = { width: sz, height: sz, colorType: CK.ColorType.RGBA_8888, alphaType: CK.AlphaType.Unpremul, colorSpace: CK.ColorSpace.SRGB };
      const px = im.readPixels(0, 0, info);
      im.delete();
      const presentData = { w: sz, h: sz, d: px };
      const correctness = PM.pixelDiffData(presentData, comp, 17);
      // 帧稳定：连续 3 帧 present 后 presentSurface 像素一致
      e.presentFull(); await PM.raf();
      const p1 = e.presentSurface.makeImageSnapshot().readPixels(0, 0, info);
      e.presentFull(); await PM.raf();
      const p2 = e.presentSurface.makeImageSnapshot().readPixels(0, 0, info);
      const D3 = PM.pixelDiffData({ w: sz, h: sz, d: p1 }, { w: sz, h: sz, d: p2 }, 17);
      // E: undo 后像素正确（dirty 策略）
      const beforeStroke = await PM.compositePixels(e);
      e.setActiveLayer(e.getLayers()[0].id);
      e.setPresentStrategy('dirty');
      e.beginStroke({ x: sz * 0.3, y: sz * 0.3, pressure: 0.9, timestamp: performance.now(), pointerType: 'synthetic' });
      for (let i = 1; i <= 12; i += 1) e.appendPoint({ x: sz * (0.3 + 0.4 * i / 12), y: sz * (0.3 + 0.2 * i / 12), pressure: 0.9, timestamp: performance.now(), pointerType: 'synthetic' });
      e.endStroke();
      await PM.raf(); await PM.raf();
      e.undo();
      await PM.raf(); await PM.raf(); await PM.raf();
      const afterUndo = await PM.compositePixels(e);
      const undoDiff = PM.pixelDiffData(beforeStroke, afterUndo, 17);
      const memAfter = e.getStats().memoryEstimateMB;
      out.memory = { beforeMB: memBefore, afterMB: memAfter, presentSurfaceMB };
      out.full = { ...fullStats, p50: PM.pct(fullTimes, 0.5), p95: PM.pct(fullTimes, 0.95), avg: Math.round(fullTimes.reduce((a, b) => a + b, 0) / fullTimes.length * 100) / 100, n: fullTimes.length };
      out.dirty = { ...dirtyStats, p50: PM.pct(dirtyTimes, 0.5), p95: PM.pct(dirtyTimes, 0.95), avg: Math.round(dirtyTimes.reduce((a, b) => a + b, 0) / dirtyTimes.length * 100) / 100, n: dirtyTimes.length };
      out.frames = { dirty: frameDirty, full: frameFull };
      out.correctness = { presentVsComposite: correctness, frameStability: D3, undoDiff };
      out.ok = !!(out.dirty.lastMode === 'dirty' && out.dirty.lastRedrawPct < 0.5 && out.dirty.p95 <= Math.max(3, out.full.p95 * 1.3)
        && correctness.changed / Math.max(1, correctness.total) < 0.02 && D3.changed === 0 && undoDiff.changed === 0);
    } catch (err) { out.error = String((err && (err.stack || err.message)) || err); out.ok = false; }
    return out;
  }, size);
}

async function historySuite(page) {
  return page.evaluate(async () => {
    const PM = window.__PM__;
    const out = {};
    try {
      const { Engine } = await import(new URL('./src/engine.js', location.href).href);
      const canvas = document.createElement('canvas'); canvas.width = 2048; canvas.height = 2048;
      canvas.style.cssText = 'position:fixed;left:-99999px;top:0;width:128px;height:128px';
      document.body.appendChild(canvas);
      const e = new Engine({ canvas, width: 2048, height: 2048, layers: 2 });
      await e.init();
      e.setBrush({ type: 'soft', sizePx: 40 });
      const stroke = (k) => {
        const y = 80 + ((k * 53) % 1700);
        const x = 60 + ((k * 37) % 1500);
        e.beginStroke({ x, y, pressure: 0.85, timestamp: performance.now(), pointerType: 'synthetic' });
        for (let i = 1; i < 12; i += 1) e.appendPoint({ x: x + i * 26, y: y + Math.sin(i * 0.7) * 26, pressure: 0.85, timestamp: performance.now(), pointerType: 'synthetic' });
        e.endStroke();
      };
      const samples = [];
      const sample = (label) => { const st = e.getHistoryStats(); samples.push({ label, steps: st.steps, bytesMB: Math.round(st.bytes / 1048576 * 100) / 100, evicted: st.evictedSteps, imagesReleased: st.imagesReleased, imageRefs: st.imageRefs, memMB: e.getStats().memoryEstimateMB }); return st; };
      // 默认预算（80 步/200MB）：80 步
      sample('start');
      for (let i = 1; i <= 80; i += 1) { stroke(i); if (i % 20 === 0) sample('default-' + i); }
      out.default80 = sample('default-80');
      // 200 步长跑
      for (let i = 81; i <= 200; i += 1) { stroke(i); if (i % 40 === 0) sample('long-' + i); }
      out.longRun = sample('long-200');
      // 收紧预算触发回收
      const applied = e.setHistoryBudget({ maxSteps: 12, maxBytes: 64 * 1024 * 1024, auto: true });
      for (let i = 201; i <= 230; i += 1) stroke(i);
      out.lowBudget = sample('low-budget');
      out.historyStats = e.getHistoryStats();
      // 回收后 undo 正确
      const beforeUndo = await PM.compositePixels(e);
      let undone = 0;
      for (let i = 0; i < 8; i += 1) { if (e.undo()) undone += 1; }
      await PM.raf(); await PM.raf();
      const afterUndo = await PM.compositePixels(e);
      const undoDiff = PM.pixelDiffData(beforeUndo, afterUndo, 1);
      out.undoAfterEvict = { undone, changedSamples: undoDiff.changed, maxDelta: undoDiff.maxDelta };
      const beforeRedo = await PM.compositePixels(e);
      for (let i = 0; i < 8; i += 1) e.redo();
      await PM.raf(); await PM.raf();
      const afterRedo = await PM.compositePixels(e);
      const redoDiff = PM.pixelDiffData(beforeUndo, afterRedo, 1);
      out.redoAfterEvict = { changedSamples: redoDiff.changed, maxDelta: redoDiff.maxDelta };
      out.samples = samples;
      out.budgetApplied = applied;
      const memSeries = samples.filter((s) => /long-/.test(s.label)).map((s) => s.memMB);
      out.bounded = !!out.lowBudget && out.lowBudget.steps <= 12;
      out.noMonotonicGrowth = memSeries.length >= 2 ? (Math.max(...memSeries) - Math.min(...memSeries)) <= Math.max(4, memSeries[0] * 0.15) : true;
      out.ok = !!(out.lowBudget.steps <= 12 && out.lowBudget.evictedSteps > 0 && out.historyStats.imagesReleased > 0
        && out.undoAfterEvict.undone > 0 && out.undoAfterEvict.changedSamples > 100
        && out.longRun.imageRefs >= 0 && out.longRun.imageRefs < 5000 && out.redoAfterEvict.changedSamples === 0
        && out.bounded && out.noMonotonicGrowth && out.historyStats.maxSteps === 12);
      e.dispose && e.dispose();
    } catch (err) { out.error = String((err && (err.stack || err.message)) || err); out.ok = false; }
    return out;
  });
}

async function main() {
  const { chromium } = require('playwright-core');
  const srv = await startServer();
  const report = { schema: 'mozheng.perf-memory-regression.v1', at: nowIso(), mode: HEADLESS ? 'headless' : 'headed-real-edge', origin: srv.origin, present: {}, history: {}, errors: [], pass: null };
  const browser = await chromium.launch({
    channel: 'msedge', headless: HEADLESS,
    args: ['--enable-gpu', '--use-angle=d3d11', '--window-size=1600,1000', '--window-position=-3000,-3000', '--disable-background-timer-throttling'],
  });
  const ctx = await browser.newContext({ viewport: { width: 1532, height: 791 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  page.setDefaultTimeout(240000);
  const isBenign = (t) => /favicon|status of 404|null function/i.test(String(t));
  page.on('console', (m) => { if (m.type() === 'error' && !isBenign(m.text())) report.errors.push(m.text().slice(0, 200)); });
  page.on('pageerror', (e) => { if (!isBenign(e.message)) report.errors.push(String(e.message || e).slice(0, 200)); });
  try {
    await page.goto(`${srv.origin}/v2/engine/demo.html`, { waitUntil: 'load' });
    await page.waitForFunction('window.__V2_READY__ === true', { timeout: 120000 });
    await page.waitForTimeout(800);
    await page.evaluate(INSTRUMENT);
    report.present['2048'] = await presentSuite(page, 2048);
    report.present['4096'] = await presentSuite(page, 4096);
    report.history = await historySuite(page);
    report.pass = !!(report.present['2048'].ok && report.present['4096'].ok && report.history.ok);
  } catch (e) {
    report.fatal = String(e.stack || e.message || e);
    report.pass = false;
  } finally {
    await browser.close().catch(() => {});
    try { srv.proc.kill(); } catch { /* ignore */ }
    await fsp.rm(path.join(REPO, 'v2', '.runtime-port'), { force: true }).catch(() => {});
  }
  report.headless = HEADLESS;
  report.note = HEADLESS
    ? 'headless Edge：rAF/提交-only，帧间隔与 fps 仅参考；present 调用耗时已用 makeImageSnapshot+readPixels 强制 GPU 同步'
    : 'headed real Edge（窗口在屏幕外 -3000,-3000）：present 调用耗时用 readPixels 强制 GPU 同步，帧间隔为真实 rAF';
  await fsp.writeFile(OUT, JSON.stringify(report, null, 2), 'utf8');
  console.log('[pm] ' + (report.pass ? 'PASS' : 'FAIL') + ' mode=' + report.mode);
  console.log('[pm] 2048: full p95=' + (report.present['2048'].full ? report.present['2048'].full.p95 : 'err') + ' dirty p95=' + (report.present['2048'].dirty ? report.present['2048'].dirty.p95 : 'err') + ' redrawPct=' + (report.present['2048'].dirty ? report.present['2048'].dirty.lastRedrawPct : '-'));
  console.log('[pm] 4096: full p95=' + (report.present['4096'].full ? report.present['4096'].full.p95 : 'err') + ' dirty p95=' + (report.present['4096'].dirty ? report.present['4096'].dirty.p95 : 'err') + ' redrawPct=' + (report.present['4096'].dirty ? report.present['4096'].dirty.lastRedrawPct : '-'));
  console.log('[pm] history: lowBudget.steps=' + (report.history.lowBudget ? report.history.lowBudget.steps : 'err') + ' evicted=' + (report.history.lowBudget ? report.history.lowBudget.evicted : '-') + ' undoAfterEvict=' + JSON.stringify(report.history.undoAfterEvict));
  console.log('[pm] 输出：' + path.relative(process.cwd(), OUT));
  process.exit(report.pass ? 0 : 1);
}

main().catch((e) => { console.error('perf-memory 失败：', e.stack || e); process.exit(2); });
