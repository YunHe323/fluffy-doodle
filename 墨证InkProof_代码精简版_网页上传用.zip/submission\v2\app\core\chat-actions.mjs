/**
 * v2/app/core/chat-actions.mjs — T112-A AI 对话行动（纯逻辑，零依赖）
 *
 * 把模型返回的「行动建议」规范化成可安全接给 UI 的对象；本模块不执行任何行动，
 * 不读 DOM / 不发网络 / 不写存储。app.js 只负责把 normalize 后的 action 交给
 * 现有 executeChatAction（observe/generate/edit/adjust/reference/annotate/export）。
 *
 * 安全边界：
 * - 只允许 7 种 ACTIONS；
 * - 拒绝 <script>/iframe/onXxx/ javascript:/data:/file: 等脚本注入；
 * - 拒绝 http(s):// / www. / 协议 URL（行动不能夹带外链）；
 * - params 只允许各类白名单字段，未知字段直接拒绝整个 action；
 * - 字符串截断、数字 clamp，防止超长内容进入 UI/日志。
 */

export const CHAT_ACTIONS_VERSION = 'chat-actions@1.0.0';

const asArray = (v) => (Array.isArray(v) ? v : []);
const asStr = (v) => (v == null ? '' : String(v));
const clampInt = (v, min, max, def) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return def;
  return Math.max(min, Math.min(max, Math.floor(n)));
};
const clampNum = (v, min, max, def) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : def;
};
const takeChars = (s, max) => Array.from(asStr(s)).slice(0, Math.max(0, max)).join('');

const UNSAFE_SCRIPT = /<\s*\/?\s*(script|iframe|object|embed|svg|img|a|style|meta|link)\b|\bon[a-z]+\s*=|\b(?:javascript|vbscript)\s*:/i;
const UNSAFE_URL = /(?:^|[\s"'()<>])(?:https?:\/\/|ftp:\/\/|www\.)|(?:^|[\s"'()<>])(?:data|file|blob):/i;

function hasUnsafeText(s) {
  const text = asStr(s);
  return UNSAFE_SCRIPT.test(text) || UNSAFE_URL.test(text);
}
function cleanText(v, max) {
  let s = asStr(v).normalize('NFKC').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').replace(/\s+/g, ' ').trim();
  s = takeChars(s, max);
  return s;
}
function isPlainObject(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}
function deepFreeze(obj) {
  if (!obj || typeof obj !== 'object' || Object.isFrozen(obj)) return obj;
  for (const v of Object.values(obj)) deepFreeze(v);
  return Object.freeze(obj);
}

/**
 * 允许的行动枚举；paramsSchema 为白名单（字段名 → 校验规则）。
 * 参数全部可选；normalize 不注入默认值，只保留调用方给出的字段。
 */
export const ACTIONS = deepFreeze({
  observe: {
    type: 'observe',
    label: '让 AI 看看',
    description: '读当前选区/画面，返回观察后再决定下一步',
    paramsSchema: {
      scope: { type: 'enum', values: ['selection', 'canvas'], label: '观察范围' },
    },
  },
  generate: {
    type: 'generate',
    label: '生成局部候选',
    description: '在选区/画面生成局部方案，落成新图层，不改原画',
    paramsSchema: {
      prompt: { type: 'string', max: 600, label: '生成提示' },
      scope: { type: 'enum', values: ['selection', 'canvas'], label: '生成范围' },
      count: { type: 'number', min: 1, max: 2, integer: true, label: '候选数' },
    },
  },
  edit: {
    type: 'edit',
    label: '编辑局部',
    description: '按文字指令对选区做图像编辑，输出新图层',
    paramsSchema: {
      prompt: { type: 'string', max: 600, label: '编辑指令' },
      scope: { type: 'enum', values: ['selection', 'canvas'], label: '编辑范围' },
    },
  },
  adjust: {
    type: 'adjust',
    label: '调整图层',
    description: '在当前图层上做亮度/对比度/饱和度/色相调整',
    paramsSchema: {
      brightness: { type: 'number', min: -1, max: 1, label: '亮度' },
      contrast: { type: 'number', min: -1, max: 1, label: '对比度' },
      saturation: { type: 'number', min: 0, max: 2, label: '饱和度' },
      hue: { type: 'number', min: -180, max: 180, label: '色相' },
    },
  },
  reference: {
    type: 'reference',
    label: '参考素材',
    description: '把素材库中的一张素材设为本次 AI 参考',
    paramsSchema: {
      assetId: { type: 'string', max: 96, pattern: /^[A-Za-z0-9._:-]+$/, label: '素材 id' },
      fileName: { type: 'string', max: 160, label: '素材文件名' },
      query: { type: 'string', max: 120, label: '检索词' },
    },
  },
  annotate: {
    type: 'annotate',
    label: '在画布标注',
    description: '打开标注模式，圈出想指给 AI 的位置',
    paramsSchema: {
      label: { type: 'string', max: 160, label: '标注名' },
      note: { type: 'string', max: 300, label: '标注说明' },
    },
  },
  export: {
    type: 'export',
    label: '导出/证据',
    description: '打开证据视图或导出当前作品',
    paramsSchema: {
      format: { type: 'enum', values: ['evidence', 'png', 'json', 'psd'], label: '导出格式' },
      includeProject: { type: 'boolean', label: '包含项目文件' },
    },
  },
});

export const ACTION_TYPES = Object.freeze(Object.keys(ACTIONS));

function schemaFor(type) { return ACTIONS[type] ? ACTIONS[type].paramsSchema : null; }

/** 校验并清洗单个参数；返回 {ok, value?, errors[]}。 */
function sanitizeParam(type, key, value) {
  const schema = schemaFor(type);
  const rule = schema && schema[key];
  if (!rule) return { ok: false, errors: [`params.${key} 不在 ${type} 白名单`] };
  if (rule.type === 'string') {
    if (typeof value !== 'string' && typeof value !== 'number') return { ok: false, errors: [`params.${key} 必须是字符串`] };
    const s = cleanText(value, rule.max || 600);
    if (hasUnsafeText(s)) return { ok: false, errors: [`params.${key} 包含脚本/URL，已拒绝`] };
    if (rule.pattern && !rule.pattern.test(s)) return { ok: false, errors: [`params.${key} 格式不合法`] };
    return { ok: true, value: s };
  }
  if (rule.type === 'number') {
    const n = Number(value);
    if (!Number.isFinite(n)) return { ok: false, errors: [`params.${key} 必须是数字`] };
    let v = Math.max(rule.min, Math.min(rule.max, n));
    if (rule.integer) v = Math.round(v);
    return { ok: true, value: v };
  }
  if (rule.type === 'boolean') {
    if (typeof value !== 'boolean') return { ok: false, errors: [`params.${key} 必须是布尔值`] };
    return { ok: true, value };
  }
  if (rule.type === 'enum') {
    const s = asStr(value);
    if (!rule.values.includes(s)) return { ok: false, errors: [`params.${key} 只能是 ${rule.values.join('/')}`] };
    return { ok: true, value: s };
  }
  return { ok: false, errors: [`params.${key} 校验规则未知`] };
}

function sanitizeParams(type, params) {
  if (params === undefined || params === null) return { ok: true, value: {} };
  if (!isPlainObject(params)) return { ok: false, errors: ['params 必须是普通对象'] };
  const schema = schemaFor(type);
  if (!schema) return { ok: false, errors: [`未知行动类型：${type}`] };
  const known = new Set(Object.keys(schema));
  const unknown = Object.keys(params).filter((k) => !known.has(k));
  if (unknown.length) return { ok: false, errors: unknown.map((k) => `params.${k} 不在白名单`) };
  const out = {};
  const errors = [];
  for (const [k, v] of Object.entries(params)) {
    const r = sanitizeParam(type, k, v);
    if (!r.ok) errors.push(...r.errors);
    else out[k] = r.value;
  }
  return { ok: errors.length === 0, value: out, errors };
}

/**
 * 3) 校验一个 action（用于 normalize 后的二次检查/测试）。
 * 允许省略 label/reason（normalize 会补默认）；已给出的字段必须合法。
 * @returns {{ok:boolean, errors:string[]}}
 */
export function validateAction(action) {
  const errors = [];
  if (!action || typeof action !== 'object' || Array.isArray(action)) return { ok: false, errors: ['action 必须是对象'] };
  const type = asStr(action.type);
  if (!type) return { ok: false, errors: ['缺少 type'] };
  if (!ACTIONS[type]) return { ok: false, errors: [`未知类型：${type}`] };
  if (action.label !== undefined) {
    if (typeof action.label !== 'string') errors.push('label 必须是字符串');
    else if (takeChars(action.label, 25).length > 24) errors.push('label 超过 24 字');
    else if (hasUnsafeText(action.label)) errors.push('label 包含脚本/URL');
  }
  if (action.reason !== undefined) {
    if (typeof action.reason !== 'string') errors.push('reason 必须是字符串');
    else if (takeChars(action.reason, 161).length > 160) errors.push('reason 超过 160 字');
    else if (hasUnsafeText(action.reason)) errors.push('reason 包含脚本/URL');
  }
  if (action.params !== undefined) {
    const r = sanitizeParams(type, action.params);
    if (!r.ok) errors.push(...r.errors);
  }
  return { ok: errors.length === 0, errors };
}

function normalizeOne(raw, state) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const type = asStr(raw.type).trim();
  if (!ACTIONS[type]) return null;
  if (state.seen.has(type)) return null;
  const def = ACTIONS[type];
  let label = raw.label === undefined || raw.label === null ? def.label : cleanText(raw.label, 24);
  if (!label) label = def.label;
  label = takeChars(label, 24);
  if (hasUnsafeText(label)) return null;
  let reason = raw.reason === undefined || raw.reason === null ? '' : cleanText(raw.reason, 160);
  reason = takeChars(reason, 160);
  if (reason && hasUnsafeText(reason)) return null;
  const p = sanitizeParams(type, raw.params);
  if (!p.ok) return null;
  state.seen.add(type);
  return { type, label, reason, params: p.value };
}

/**
 * 2) 规范化模型输出的 actions。
 * @param {any} raw 数组或 {actions: []}
 * @param {{max?:number}} opts max 默认 3，硬上限 3
 * @returns {Array<{type:string,label:string,reason:string,params:object}>}
 */
export function normalizeChatActions(raw, opts = {}) {
  const max = clampInt(opts && opts.max, 0, 3, 3);
  if (!max) return [];
  let list = [];
  if (Array.isArray(raw)) list = raw;
  else if (isPlainObject(raw) && Array.isArray(raw.actions)) list = raw.actions;
  const state = { seen: new Set() };
  const out = [];
  for (const item of list) {
    if (out.length >= max) break;
    const a = normalizeOne(item, state);
    if (a) out.push(a);
  }
  return out;
}

function formatNumber(n) { return Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100); }
function describeParams(type, params = {}) {
  const p = isPlainObject(params) ? params : {};
  const bits = [];
  if (p.scope) bits.push(p.scope === 'canvas' ? '整幅画面' : '当前选区');
  if (p.prompt) bits.push('提示「' + takeChars(p.prompt, 60) + '」');
  if (p.count !== undefined) bits.push(p.count + ' 个候选');
  if (p.format) bits.push('格式 ' + p.format);
  if (p.includeProject === true) bits.push('包含项目文件');
  if (p.fileName) bits.push('素材「' + takeChars(p.fileName, 40) + '」');
  else if (p.assetId) bits.push('素材 ' + takeChars(p.assetId, 40));
  if (p.query) bits.push('检索「' + takeChars(p.query, 30) + '」');
  if (p.label) bits.push('标注「' + takeChars(p.label, 30) + '」');
  if (p.note) bits.push('说明「' + takeChars(p.note, 40) + '」');
  if (p.brightness !== undefined || p.contrast !== undefined || p.saturation !== undefined || p.hue !== undefined) {
    const adj = [];
    if (p.brightness !== undefined) adj.push('亮度' + formatNumber(p.brightness));
    if (p.contrast !== undefined) adj.push('对比' + formatNumber(p.contrast));
    if (p.saturation !== undefined) adj.push('饱和' + formatNumber(p.saturation));
    if (p.hue !== undefined) adj.push('色相' + formatNumber(p.hue) + '°');
    bits.push('调整 ' + adj.join(' / '));
  }
  return bits.join(' · ');
}

/**
 * 4) 用户可读文案（纯文本，不执行）。
 * @returns {string}
 */
export function describeAction(action) {
  const normalized = normalizeChatActions([action], { max: 1 })[0];
  if (!normalized) return '无法执行的建议';
  const def = ACTIONS[normalized.type];
  const parts = [def.label];
  if (normalized.label && normalized.label !== def.label) parts.push('「' + normalized.label + '」');
  if (normalized.reason) parts.push(normalized.reason);
  const pd = describeParams(normalized.type, normalized.params);
  if (pd) parts.push(pd);
  return parts.join(' · ');
}

/**
 * 5) Mock 建议（observe/generate/reference）。
 * @param {{selection?:object, libraryCount?:number, referenced?:object[]}} ctx
 * @returns {Array<{type,label,reason,params}>}
 */
export function buildMockActions(ctx = {}) {
  const c = ctx && typeof ctx === 'object' ? ctx : {};
  const sel = c.selection && typeof c.selection === 'object' ? c.selection : {};
  const rect = sel.rect && typeof sel.rect === 'object' ? sel.rect : sel;
  const hasSelection = Number(rect.width) > 0 && Number(rect.height) > 0;
  const libraryCount = Math.max(0, Number(c.libraryCount) || 0);
  const refs = asArray(c.referenced).filter((x) => x && typeof x === 'object');
  const raw = [{ type: 'observe', label: '让 AI 看看', reason: '先确认选区/画面，再决定改哪里', params: { scope: hasSelection ? 'selection' : 'canvas' } }];
  if (hasSelection) {
    raw.push({ type: 'generate', label: '生成局部候选', reason: '在选区里出候选，框外不动', params: { prompt: '保留我的笔触，只改这个区域', scope: 'selection', count: 2 } });
  }
  if (refs.length) {
    const first = refs[0];
    const fileName = cleanText(first.fileName || '', 40);
    raw.push({
      type: 'reference',
      label: '参考「' + takeChars(fileName || '素材', 12) + '」',
      reason: '把这张素材作为风格/元素参考',
      params: { ...(first.id ? { assetId: String(first.id) } : {}), ...(fileName ? { fileName } : {}) },
    });
  } else if (libraryCount > 0) {
    raw.push({ type: 'reference', label: '从素材库选参考', reason: '用你的私有素材补上下文', params: { query: '' } });
  }
  return normalizeChatActions(raw, { max: 3 });
}

export default {
  CHAT_ACTIONS_VERSION,
  ACTIONS,
  ACTION_TYPES,
  normalizeChatActions,
  validateAction,
  describeAction,
  buildMockActions,
};
