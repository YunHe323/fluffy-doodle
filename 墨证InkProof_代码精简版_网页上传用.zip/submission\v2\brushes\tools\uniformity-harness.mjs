/**
 * v2/brushes/tools/uniformity-harness.mjs · T59 均匀度复测（Playwright-core，headless）
 *
 * 用与 QA T51 harness 等价的 S1/S2 场景和口径，在同一构建里对比多组配置，
 * 并额外给出「沿中心线法向的线宽 CV」（widthCV，替代指标；不受笔刷绝对粗细影响）。
 *
 * 变体：
 *   before      = T54 原始起笔（startPressure .55 / catchUp off）
 *   after       = T59 修正（startPressure .30 / catchUp on）
 *   after-rs    = T59 + 半径距离域平滑
 *   minp-*      = T59 + 最小模拟压力抬高（高速段补偿）
 *   t54off      = 关闭模拟压感（常量 0.5，诊断）
 *   thin12      = t54off + size 12（验证「粗细导致密度 CV 不可比」假设）
 *   klecks      = MIT 参考实现（同一 Playwright mouse 输入）
 *
 * 输出：samples/uniformity/*.png + harness-metrics.json + 控制台表格。
 * 复用 v2/qa/node_modules/playwright-core（只读，不写入 v2/qa/）。
 * 运行：node v2/brushes/tools/uniformity-harness.mjs [--rounds=4] [--headed]
 */
import { spawn, spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
const QA = path.join(ROOT, 'v2', 'qa');
const OUT = path.join(ROOT, 'v2', 'brushes', 'samples', 'uniformity');
await fsp.mkdir(OUT, { recursive: true });

const argv = process.argv.slice(2);
const HEADLESS = !argv.includes('--headed');
const ROUNDS = Number((argv.find((a) => a.startsWith('--rounds=')) || '').split('=')[1] || 4);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const nowIso = () => new Date().toISOString();
const median = (arr) => { const v = arr.filter((x) => x != null).sort((a, b) => a - b); return v.length ? v[Math.floor(v.length / 2)] : null; };

// 与 QA harness 完全一致
const S1 = (() => { const a = []; for (let i = 0; i <= 40; i += 1) { const t = i / 40; a.push([0.12 + 0.76 * t, 0.5 + 0.28 * Math.sin(t * Math.PI * 2)]); } return a; })();
const S2 = [[0.10, 0.50], [0.20, 0.24], [0.30, 0.20], [0.44, 0.38], [0.56, 0.62], [0.70, 0.78], [0.84, 0.72], [0.92, 0.50]];
const SEGMENTS = 12;

const PAGE_HELPERS = `
window.__PWQA__ = {
  async grab(kind) {
    if (kind === 'ours') {
      const e = window.__V2__ || (window.__V2_APP__ && window.__V2_APP__.engine) || (window.__BRUSH_DEMO__ && window.__BRUSH_DEMO__.engine);
      if (!e) return null;
      if (e.compositor && e.store) e.compositor.compositeAll(e.store);
      return await e.getCompositeDataUrl();
    }
    const cs = [...document.querySelectorAll('canvas')].sort((a, b) => (b.width * b.height) - (a.width * a.height));
    const c = cs[0];
    if (!c) return null;
    try { return c.toDataURL('image/png'); } catch (e) { return null; }
  },
  async load(src) {
    const img = new Image(); img.src = src; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const x = c.getContext('2d'); x.drawImage(img, 0, 0);
    return { w: c.width, h: c.height, d: x.getImageData(0, 0, c.width, c.height).data };
  },
  async stats(curUrl, refUrl, points) {
    const cur = await this.load(curUrl); const ref = refUrl ? await this.load(refUrl) : null;
    const W = cur.w, H = cur.h; const points2 = points || [];
    const isInk = (x, y) => {
      if (x < 0 || y < 0 || x >= W || y >= H) return false;
      const i = (y * W + x) * 4;
      const bg = cur.d[i] < 34 && cur.d[i + 1] < 36 && cur.d[i + 2] < 42;
      if (ref && ref.w === W && ref.h === H) return !bg && (Math.abs(cur.d[i] - ref.d[i]) > 24 || Math.abs(cur.d[i + 1] - ref.d[i + 1]) > 24 || Math.abs(cur.d[i + 2] - ref.d[i + 2]) > 24);
      return !bg && cur.d[i + 3] > 8 && cur.d[i] < 200;
    };
    let ink = 0;
    const seg = new Array(${SEGMENTS}).fill(0);
    const samples = new Array(${SEGMENTS}).fill(0);
    const centers = [];
    for (let s = 0; s < ${SEGMENTS}; s += 1) {
      if (!points2.length) { centers.push(null); continue; }
      const t = (s + 0.5) / ${SEGMENTS};
      const fi = Math.min(points2.length - 1, t * (points2.length - 1));
      const i0 = Math.floor(fi), i1 = Math.min(points2.length - 1, i0 + 1), f = fi - i0;
      const px = points2[i0][0] + (points2[i1][0] - points2[i0][0]) * f;
      const py = points2[i0][1] + (points2[i1][1] - points2[i0][1]) * f;
      const r = Math.max(8, Math.min(44, Math.round(Math.min(W, H) * 0.05)));
      centers.push({ x: Math.round(px * W), y: Math.round(py * H), r });
    }
    const STEP = 2;
    for (let y = 0; y < H; y += STEP) for (let x = 0; x < W; x += STEP) {
      if (!isInk(x, y)) continue;
      ink += 1;
      for (let s = 0; s < ${SEGMENTS}; s += 1) { const c0 = centers[s]; if (!c0) continue; samples[s] += 1; if (Math.abs(x - c0.x) <= c0.r && Math.abs(y - c0.y) <= c0.r) seg[s] += 1; }
    }
    const dens = seg.map((v, s) => (samples[s] ? v / samples[s] : 0));
    const covered = dens.filter((v) => v > 0.01).length;
    const mean = dens.reduce((a, b) => a + b, 0) / dens.length;
    const sd = Math.sqrt(dens.reduce((a, b) => a + (b - mean) * (b - mean), 0) / dens.length);
    // ---------- 替代指标：中心线法向线宽 CV（排除起收笔区段，避免 taper 干扰） ----------
    const widths = [];
    const NC = 56;
    const pin = (u, v) => [Math.round(u * W), Math.round(v * H)];
    if (points2.length >= 2) {
      for (let k = 0; k < NC; k += 1) {
        const t = 0.10 + (0.80 * k) / (NC - 1);
        const fi = Math.min(points2.length - 1, t * (points2.length - 1));
        const i0 = Math.floor(fi), i1 = Math.min(points2.length - 1, i0 + 1), f = fi - i0;
        const [cx, cy] = pin(points2[i0][0] + (points2[i1][0] - points2[i0][0]) * f, points2[i0][1] + (points2[i1][1] - points2[i0][1]) * f);
        const eps = 1.5 / (points2.length - 1);
        const t0 = Math.max(0, t - eps), t1 = Math.min(1, t + eps);
        const f0 = t0 * (points2.length - 1), f1 = t1 * (points2.length - 1);
        const a0 = Math.floor(f0), b0 = Math.min(points2.length - 1, a0 + 1), f0r = f0 - a0;
        const a1 = Math.floor(f1), b1 = Math.min(points2.length - 1, a1 + 1), f1r = f1 - a1;
        const [x0, y0] = pin(points2[a0][0] + (points2[b0][0] - points2[a0][0]) * f0r, points2[a0][1] + (points2[b0][1] - points2[a0][1]) * f0r);
        const [x1, y1] = pin(points2[a1][0] + (points2[b1][0] - points2[a1][0]) * f1r, points2[a1][1] + (points2[b1][1] - points2[a1][1]) * f1r);
        const tx = x1 - x0, ty = y1 - y0; const tl = Math.hypot(tx, ty) || 1;
        const nx = -ty / tl, ny = tx / tl;
        // 找包含最近中心点的连续墨迹区间
        let run = 0; let center = -1;
        for (let s = -36; s <= 36; s += 1) {
          const px = Math.round(cx + nx * s), py = Math.round(cy + ny * s);
          if (isInk(px, py)) { if (center < 0 && Math.abs(s) <= 2) center = s; }
        }
        if (center < 0) { // 中心没墨：取最近墨迹
          for (let s = 0; s <= 36; s += 1) {
            if (isInk(Math.round(cx + nx * s), Math.round(cy + ny * s))) { center = s; break; }
            if (isInk(Math.round(cx - nx * s), Math.round(cy - ny * s))) { center = -s; break; }
          }
        }
        if (center < 0) continue;
        let lo = center; while (lo > -36 && isInk(Math.round(cx + nx * (lo - 1)), Math.round(cy + ny * (lo - 1)))) lo -= 1;
        let hi = center; while (hi < 36 && isInk(Math.round(cx + nx * (hi + 1)), Math.round(cy + ny * (hi + 1)))) hi += 1;
        const w = hi - lo + 1;
        if (w >= 1) widths.push(w);
      }
    }
    let widthCV = null; let medianWidthPx = null;
    if (widths.length >= 8) {
      const wm = widths.reduce((a, b) => a + b, 0) / widths.length;
      const wsd = Math.sqrt(widths.reduce((a, b) => a + (b - wm) * (b - wm), 0) / widths.length);
      widthCV = wm > 0 ? Math.round((wsd / wm) * 1000) / 1000 : null;
      const wsorted = widths.slice().sort((a, b) => a - b);
      medianWidthPx = wsorted[Math.floor(wsorted.length / 2)];
    }
    return { ink, breakpoints: ${SEGMENTS} - covered, thicknessCV: mean > 0 ? Math.round((sd / mean) * 1000) / 1000 : null, widthCV, medianWidthPx, dens };
  },
}; 'ok'`;

// ---------------------------------------------------------------- servers
async function ensureOurs() {
  const portFile = path.join(ROOT, 'v2', '.runtime-port');
  await fsp.rm(portFile, { force: true }).catch(() => {});
  const proc = spawn(process.execPath, [path.join(ROOT, 'v2', 'serve.mjs')], { cwd: ROOT, env: { ...process.env, PORT: '4270' }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  for (let i = 0; i < 120; i += 1) {
    await sleep(150);
    try {
      const p = Number(String(await fsp.readFile(portFile, 'utf8')).trim());
      const r = await fetch(`http://127.0.0.1:${p}/v2/brushes/demo.html`);
      if (r.ok) return { origin: `http://127.0.0.1:${p}`, proc };
    } catch { /* wait */ }
  }
  try { proc.kill(); } catch { /* ignore */ }
  throw new Error('无法启动 v2/serve.mjs');
}
async function ensureKlecks() {
  const proc = spawn(process.execPath, [path.join(QA, 'compare', 'serve-klecks.mjs'), '--port', '4315'], { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  let log = '';
  proc.stdout.setEncoding('utf8'); proc.stdout.on('data', (d) => { log += d; });
  proc.stderr.setEncoding('utf8'); proc.stderr.on('data', (d) => { log += d; });
  for (let i = 0; i < 80; i += 1) {
    await sleep(150);
    const m = /http:\/\/127\.0\.0\.1:(\d+)\//.exec(log);
    if (m) return { origin: `http://127.0.0.1:${m[1]}`, proc };
  }
  throw new Error('无法启动 Klecks 静态服务');
}

// ---------------------------------------------------------------- page helpers
async function canvasRect(page) {
  return page.evaluate(`(() => {
    const cs = [...document.querySelectorAll('canvas')].map((c) => { const r = c.getBoundingClientRect(); return { id: c.id || null, w: c.width, h: c.height, x: r.x, y: r.y, cw: r.width, ch: r.height }; })
      .filter((c) => c.cw > 50 && c.ch > 50).sort((a, b) => b.cw * b.ch - a.cw * a.ch);
    return cs[0] || null;
  })()`);
}
async function grab(page, kind) { return page.evaluate(`window.__PWQA__.grab('${kind}')`); }
async function stats(page, cur, ref, points) { return page.evaluate((a) => window.__PWQA__.stats(a.cur, a.ref, a.points), { cur, ref, points }); }
async function drawPath(page, rect, norm, { stepMs = 10 } = {}) {
  const x = (f) => Math.round(rect.x + rect.cw * f);
  const y = (f) => Math.round(rect.y + rect.ch * f);
  await page.mouse.move(x(norm[0][0]), y(norm[0][1]));
  await page.mouse.down();
  for (let i = 1; i < norm.length; i += 1) { await page.mouse.move(x(norm[i][0]), y(norm[i][1])); if (stepMs) await sleep(stepMs); }
  await page.mouse.up();
}
async function resetOurs(page) {
  await page.evaluate(`(() => { const e = window.__V2__ || (window.__V2_APP__ && window.__V2_APP__.engine) || (window.__BRUSH_DEMO__ && window.__BRUSH_DEMO__.engine); if (!e) return 0; let g = 0; while (e.canUndo && e.canUndo() && g < 400) { e.undo(); g += 1; } if (e.compositor) e.compositor.compositeAll(e.store); return g; })()`).catch(() => {});
  await sleep(350);
}

// ---------------------------------------------------------------- main
async function main() {
  let playwright;
  try { playwright = createRequire(path.join(QA, 'package.json'))('playwright-core'); } catch (e) {
    console.error('未安装 playwright-core（v2/qa/node_modules）'); process.exit(2);
  }
  const ours = await ensureOurs();
  const klecks = await ensureKlecks();
  console.log(`[t59] ours=${ours.origin} klecks=${klecks.origin} headless=${HEADLESS} rounds=${ROUNDS}`);
  const browser = await playwright.chromium.launch({
    channel: 'msedge', headless: HEADLESS,
    args: ['--enable-gpu', '--use-angle=d3d11', '--window-position=-3000,-3000', '--window-size=1600,1000'],
  });
  const report = { schema: 'inkproof.uniformity.v1', at: nowIso(), headless: HEADLESS, rounds: ROUNDS, ours: {}, klecks: {}, targets: { S1_CV: 0.20, S2_CV: 1.40 } };
  try {
    const ctx = await browser.newContext({ viewport: { width: 1532, height: 791 }, deviceScaleFactor: 1 });
    const variants = [
      { id: 'before', label: 'T54 默认', cfg: { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 45, startPressure: 0.55, catchUp: false, speedTauMs: 0 } },
      { id: 'opt', label: 'T69 建议（tau50/sm65）', cfg: { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 65, startPressure: 0.30, catchUp: true, speedTauMs: 50 } },
      { id: 'slow150', label: 'opt + 慢速段平滑 150ms', cfg: { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 65, startPressure: 0.30, catchUp: true, speedTauMs: 50, slowSmoothingMs: 150 } },
      { id: 'slow250', label: 'opt + 慢速段平滑 250ms', cfg: { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 65, startPressure: 0.30, catchUp: true, speedTauMs: 50, slowSmoothingMs: 250 } },
      { id: 'slow250-rs1.5', label: 'slow250 + 半径平滑 1.5', cfg: { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 65, startPressure: 0.30, catchUp: true, speedTauMs: 50, slowSmoothingMs: 250 }, params: { 'smoothing.radiusSmooth': 1.5 } },
      { id: 'slow250-sp0.03', label: 'slow250 + spacing 0.03', cfg: { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 65, startPressure: 0.30, catchUp: true, speedTauMs: 50, slowSmoothingMs: 250 }, params: { 'spacing.ratio': 0.03 } },
    ];
    for (const v of variants) report.ours[v.id] = { label: v.label, S1runs: [], S2runs: [] };
    for (let round = 0; round < ROUNDS; round += 1) {
      for (const v of variants) {
        const page = await ctx.newPage();
        try {
          await page.goto(`${ours.origin}/v2/brushes/demo.html`, { waitUntil: 'load' });
          await page.evaluate(`(() => { try { localStorage.clear(); sessionStorage.clear(); } catch (e) {} return true; })()`).catch(() => {});
          await page.reload({ waitUntil: 'load' }).catch(() => {});
          await page.waitForFunction('window.__BRUSH_READY__ === true', { timeout: 60000 }).catch(() => {});
          await page.waitForTimeout(900);
          await page.evaluate(PAGE_HELPERS);
          const rect = await canvasRect(page);
          if (!report.ours.canvas) report.ours.canvas = rect;
          await page.evaluate((cfg) => window.__BRUSH_DEMO__.controller.setSimulatedPressure(cfg), v.cfg);
          if (v.params) {
            for (const [k, x] of Object.entries(v.params)) await page.evaluate(([key, val]) => window.__BRUSH_DEMO__.controller.setParam(key, val), [k, x]);
          }
          await sleep(100);
          for (const [scen, norm, stepMs] of [['S1', S1, 12], ['S2', S2, 3]]) {
            await resetOurs(page);
            const blank = await grab(page, 'ours');
            await drawPath(page, rect, norm, { stepMs });
            await sleep(350);
            const cur = await grab(page, 'ours');
            const st = await stats(page, cur, blank, norm);
            (scen === 'S1' ? report.ours[v.id].S1runs : report.ours[v.id].S2runs).push(st);
            if (round === 0 && scen === 'S1' && process.argv.includes('--trace')) {
              const dbg = await page.evaluate(`(() => { const c = window.__BRUSH_DEMO__.controller; const t = c._pressureTrace || []; const ps = t.map((x) => x.pressure); return { n: t.length, min: Math.min(...ps), max: Math.max(...ps), mean: ps.reduce((a, b) => a + b, 0) / (ps.length || 1), sim: c.getSimulatedPressure(), trace: t.slice(0, 12), w: ${JSON.stringify(st.widthCV)}, wp: ${JSON.stringify(st.medianWidthPx)} }; })()`);
              report.ours[v.id].trace = dbg;
              console.log(`[trace] ${v.id}`, JSON.stringify(dbg).slice(0, 700));
            }
            if (round === 0) fs.writeFileSync(path.join(OUT, `ours-${v.id}-${scen}.png`), Buffer.from(cur.split(',')[1], 'base64'));
          }
        } catch (e) {
          report.ours[v.id].errors = (report.ours[v.id].errors || []).concat(String(e && e.message || e));
        } finally {
          try { await page.close(); } catch (e) { /* ignore */ }
        }
      }
      console.log(`[t59] round ${round + 1}/${ROUNDS} done`);
    }
    for (const v of variants) {
      const o = report.ours[v.id];
      o.S1 = { CV: median(o.S1runs.map((r) => r.thicknessCV)), widthCV: median(o.S1runs.map((r) => r.widthCV)), medianWidthPx: median(o.S1runs.map((r) => r.medianWidthPx)), breakpoints: median(o.S1runs.map((r) => r.breakpoints)), ink: median(o.S1runs.map((r) => r.ink)) };
      o.S2 = { CV: median(o.S2runs.map((r) => r.thicknessCV)), widthCV: median(o.S2runs.map((r) => r.widthCV)), medianWidthPx: median(o.S2runs.map((r) => r.medianWidthPx)), breakpoints: median(o.S2runs.map((r) => r.breakpoints)), ink: median(o.S2runs.map((r) => r.ink)) };
    }

    // ---------- klecks 参考 ----------
    const kRuns = { S1: [], S2: [] };
    for (let round = 0; round < ROUNDS; round += 1) {
      const kpage = await ctx.newPage();
      try {
        await kpage.goto(`${klecks.origin}/index.html`, { waitUntil: 'load' });
        await kpage.waitForFunction(`(() => document.readyState === 'complete' && [...document.querySelectorAll('canvas')].some((c) => c.width > 200 && c.height > 200))()`, { timeout: 60000 }).catch(() => {});
        await kpage.waitForTimeout(2200);
        await kpage.evaluate(PAGE_HELPERS);
        const krect = await canvasRect(kpage);
        if (!report.klecks.canvas) report.klecks.canvas = krect;
        for (const [scen, norm, stepMs] of [['S1', S1, 12], ['S2', S2, 3]]) {
          for (let i = 0; i < 8; i += 1) { await kpage.keyboard.press('Control+z'); await sleep(20); }
          await sleep(250);
          const blank = await grab(kpage, 'klecks');
          await drawPath(kpage, krect, norm, { stepMs });
          await sleep(350);
          const cur = await grab(kpage, 'klecks');
          const st = await stats(kpage, cur, blank, norm);
          kRuns[scen].push(st);
          if (round === 0) fs.writeFileSync(path.join(OUT, `klecks-${scen}.png`), Buffer.from(cur.split(',')[1], 'base64'));
        }
      } catch (e) {
        (report.klecks.errors = report.klecks.errors || []).push(String(e && e.message || e));
      } finally {
        try { await kpage.close(); } catch (e) { /* ignore */ }
      }
    }
    report.klecks = {
      ...report.klecks,
      S1: { CV: median(kRuns.S1.map((r) => r.thicknessCV)), widthCV: median(kRuns.S1.map((r) => r.widthCV)), medianWidthPx: median(kRuns.S1.map((r) => r.medianWidthPx)), breakpoints: median(kRuns.S1.map((r) => r.breakpoints)), ink: median(kRuns.S1.map((r) => r.ink)) },
      S2: { CV: median(kRuns.S2.map((r) => r.thicknessCV)), widthCV: median(kRuns.S2.map((r) => r.widthCV)), medianWidthPx: median(kRuns.S2.map((r) => r.medianWidthPx)), breakpoints: median(kRuns.S2.map((r) => r.breakpoints)), ink: median(kRuns.S2.map((r) => r.ink)) },
      raw: kRuns,
    };

    const fmt = (v) => (v == null ? '—' : v);
    console.log('\n[id]                 S1 CV  wCV  w(px)  bp  ink  | S2 CV  wCV  w(px)  bp  ink');
    for (const id of Object.keys(report.ours).filter((k) => k !== 'canvas')) {
      const r = report.ours[id];
      console.log(`${id.padEnd(20)} ${fmt(r.S1.CV)}  ${fmt(r.S1.widthCV)}  ${fmt(r.S1.medianWidthPx)}  ${fmt(r.S1.breakpoints)}  ${fmt(r.S1.ink)}  | ${fmt(r.S2.CV)}  ${fmt(r.S2.widthCV)}  ${fmt(r.S2.medianWidthPx)}  ${fmt(r.S2.breakpoints)}  ${fmt(r.S2.ink)}`);
    }
    const k = report.klecks;
    console.log(`klecks               ${fmt(k.S1.CV)}  ${fmt(k.S1.widthCV)}  ${fmt(k.S1.medianWidthPx)}  ${fmt(k.S1.breakpoints)}  ${fmt(k.S1.ink)}  | ${fmt(k.S2.CV)}  ${fmt(k.S2.widthCV)}  ${fmt(k.S2.medianWidthPx)}  ${fmt(k.S2.breakpoints)}  ${fmt(k.S2.ink)}`);
    const best = report.ours['opt'];
    report.pass = {
      S1: best.S1.CV != null && best.S1.CV <= 0.20,
      S2: best.S2.CV != null && best.S2.CV <= 1.40,
      breakpointsNotWorse: (best.S1.breakpoints <= report.ours.before.S1.breakpoints + 1) && (best.S2.breakpoints <= report.ours.before.S2.breakpoints + 1),
    };
    console.log('pass:', JSON.stringify(report.pass));
    fs.writeFileSync(path.join(OUT, 'harness-metrics.json'), JSON.stringify(report, null, 2));
  } finally {
    try { await browser.close(); } catch (e) { /* ignore */ }
    try { ours.proc && ours.proc.kill(); } catch (e) { /* ignore */ }
    try { klecks.proc && klecks.proc.kill(); } catch (e) { /* ignore */ }
    try { spawnSync('taskkill', ['/PID', String(ours.proc && ours.proc.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  }
}
main().catch((e) => { console.error('FATAL', e && (e.stack || e)); process.exit(1); });
