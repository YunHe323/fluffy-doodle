// v2/app/test-multimodal.mjs —— 画布标注随图发送 / AI 定位 / 语音入口 / AI 会话
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8152;
const out = { schema: 'mozheng.app.multimodal.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  fs.writeFileSync(ROOT + '\\v2\\app\\test-multimodal-result.json', JSON.stringify(out, null, 2), 'utf8');
  process.exit(code);
};
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  out.cases.align = await page.evaluate(() => {
    const m = document.getElementById('mainCanvas').getBoundingClientRect();
    const a = document.getElementById('annotationCanvas').getBoundingClientRect();
    const p = document.getElementById('candidatePreviewCanvas').getBoundingClientRect();
    const near = (r) => Math.abs(r.x - m.x) < 2 && Math.abs(r.y - m.y) < 2 && Math.abs(r.width - m.width) < 2 && Math.abs(r.height - m.height) < 2;
    return { main: { x: m.x, y: m.y, w: m.width, h: m.height }, annotation: { x: a.x, y: a.y, w: a.width, h: a.height }, preview: { x: p.x, y: p.y, w: p.width, h: p.height }, near: near(a) && near(p) };
  });
  await page.evaluate(() => window.__V2_APP__.t96.setToggles({ allowReal: false, privacyMode: true }));
  await page.evaluate(() => { const a = window.__V2_APP__; a.state.selection = { x: 420, y: 260, width: 360, height: 260 }; a.drawSelection(); a.toggleAnnotationMode(true); });
  await page.waitForTimeout(300);
  const box = await page.locator('#mainCanvas').boundingBox();
  const p = (dx, dy) => ({ x: box.x + dx, y: box.y + dy });
  // 画一个红圈 + 箭头
  await page.mouse.move(p(560, 340).x, p(560, 340).y); await page.mouse.down();
  for (let i = 0; i <= 20; i += 1) { const ang = (i / 20) * Math.PI * 2; await page.mouse.move(p(660 + Math.cos(ang) * 55, 400 + Math.sin(ang) * 42).x, p(660 + Math.cos(ang) * 55, 400 + Math.sin(ang) * 42).y); }
  await page.mouse.move(p(730, 430).x, p(730, 430).y); await page.mouse.up();
  await page.waitForTimeout(200);
  out.cases.annotation = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const crop = a.aiSelectionCrop('analyze');
    return { mode: a.state.annotationMode, dirty: a.state.annotationDirty, ink: a.annotationInk(), bar: !document.getElementById('annotationBar').hidden, annotatedCrop: !!crop.annotated, cropLen: crop.dataUrl.length };
  });
  await page.evaluate(() => window.__V2_APP__.toggleAnnotationMode(false));
  await page.waitForTimeout(150);
  out.cases.annotationDone = await page.evaluate(() => ({ mode: window.__V2_APP__.state.annotationMode, bar: !document.getElementById('annotationBar').hidden, ink: window.__V2_APP__.annotationInk() }));
  // 带标注跑一次 Mock 观察（不花钱）
  // T120：空白画布预检会拦截 runAnalyze（标注画在 annotationCanvas，不算画布内容）；先画一笔让画布非空。
  await page.evaluate(() => {
    const c = window.__V2_APP__.controller;
    c.begin({ x: 480, y: 340, pressure: 0.8, timestamp: performance.now() });
    for (let i = 1; i <= 14; i++) c.append({ x: 480 + i * 18, y: 340 + Math.sin(i / 4) * 46, pressure: 0.7, timestamp: performance.now() + i * 16 });
    c.end();
  });
  await page.waitForTimeout(300);
  await page.evaluate(() => { const a = window.__V2_APP__; a.runAnalyze(); });
  await page.waitForTimeout(900);
  out.cases.locate = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const btn = document.querySelector('#aiBody [data-locate]');
    const before = a.state.selection ? { ...a.state.selection } : null;
    if (btn) btn.click();
    const after = a.state.selection ? { ...a.state.selection } : null;
    return { hasBtn: !!btn, before, after, moved: !!(before && after && (before.x !== after.x || before.y !== after.y)) };
  });
  await page.waitForTimeout(250);
  out.cases.aiOverlay = await page.evaluate(async () => {
    const a = window.__V2_APP__;
    a.toggleAiCanvasOverlay(true);
    await new Promise((r) => setTimeout(r, 120));
    const c = document.getElementById('aiSuggestionCanvas');
    const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    let alpha = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 8) { alpha += 1; if (alpha > 5000) break; }
    const label = [...document.querySelectorAll('#aiBody button')].map((b) => b.textContent).find((t) => t.includes('画布 AI 标注')) || '';
    a.toggleAiCanvasOverlay(false);
    return { alpha, label, visible: a.state.aiOverlayVisible };
  });
  out.cases.voice = await page.evaluate(() => ({ hasVoiceBtn: !!document.getElementById('btnAiVoice'), speechApi: !!(window.SpeechRecognition || window.webkitSpeechRecognition), annotateBtn: !!document.getElementById('btnAnnotateToggle') }));
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-multimodal-1920.png' });
  out.cases.annotationOk = out.cases.annotation.mode && out.cases.annotation.ink && out.cases.annotation.bar && out.cases.annotation.annotatedCrop;
  out.cases.alignOk = !!out.cases.align.near;
  out.cases.doneOk = !out.cases.annotationDone.mode && !out.cases.annotationDone.bar && out.cases.annotationDone.ink;
  out.cases.locateOk = out.cases.locate.hasBtn;
  out.cases.overlayOk = out.cases.aiOverlay.alpha > 500 && !!out.cases.aiOverlay.label;
  out.cases.voiceOk = out.cases.voice.hasVoiceBtn && out.cases.voice.annotateBtn;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.annotationOk && out.cases.alignOk && out.cases.doneOk && out.cases.locateOk && out.cases.overlayOk && out.cases.voiceOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  await finish(3);
}
