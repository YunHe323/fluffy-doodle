# T112-C AI 对话行动 UI 审查 v1.0

> 审查者：ux-designer｜日期：2026-11-07｜对象：当前 T110 交付版「AI 对话 → 行动 chips + 画像建议 + 长对话」（只读）
> 产出：本报告 + `09-设计/audit-chat/` 截图；未改 app/js/css/html/engine/qa。
> 方法：headless Edge 单页面顺序截图；Mock 模式构造对话（不触发真实付费调用）；1920×1080 与 1366×768。
> 结论：**无 P0；Top 5 中 4 个 P1 + 1 个 P2**。3 tab + pinned 的骨架成立；问题集中在“状态是否真实、建议是否有语义、长了以后还能不能用”。

---

## 0. 先给结论

| 检查项 | 结果 |
|---|---|
| 3 tab + pinned | ✅ **通过**：`观察/生成/记录` 清晰，层级顺序正确；pinned 条位置正确 |
| pinned 上下文是否可信 | ❌ **不可全信**：`素材` 语义混淆（pinned `素材0` vs 聊天上下文 `素材3张`）；没有 latency；字号 11px |
| 行动 chips 是否只是建议 | ⚠️ **功能正确、语义不足**：点击不会执行，但 chips 像“执行按钮”，无“建议/前往”提示；11px；最新回复的 chips 可能被聊天窗裁掉 |
| 画像建议是否会被误读为自动写入 | ⚠️ **有风险**：`AI 对你的理解（记忆）` + 类已填 placeholder + 小按钮，缺少“仅建议、尚未写入”状态 |
| 长对话滚动/成本/清空 | ❌ **1366 不可持续**：chat log 340px 嵌套滚动；长对话后输入框/画像掉到面板滚动区外；清空无确认；token 只在标题/meta（10px） |
| 状态真实性 | ❌ **P1 bug**：回复完成后 header 仍停在 `AI 正在回答...`（清空后仍如此） |

---

## 1. 审查与截图方法

- 浏览器：Edge headless，单页面；1920/1366；Mock 模式（init localStorage 强制 `allowReal:false, privacyMode:true`），无真实计费。
- 构造顺序：关闭 Quickstart → 素材库确认 1 条 L4 → 设置 420×300 选区 → 打开 AI → 发首条对话 → 点生成/观察 chips → 展开画像建议并填入 → 连发 6 条 → 1366 重排 → 清空对话。
- 截图：`09-设计/audit-chat/` 共 10 张；`console-errors.json` = `[]`。
- 已知边界：Mock 回复是固定文本，不代表真实模型语气；本审查只看 UI 行为与信息结构。

---

## 2. 逐项回答（任务要求）

### 2.1 3 tab + pinned + 聊天/画像/行动 chips 的层级

**做对了：**
- `观察 / 生成 / 记录` 3 个 primary tab 比上一版 5 tab 清楚很多；当前 tab 用朱砂下划线，识别成本低。
- pinned 位于 tabs 与内容之间，位置正确，不易被滚动带走；`本地 Mock · 选区 420×300 · 档案 0 · 素材 0 · ¥0 · 不联网` 的格式可读。
- header 模型 badge、关闭 ×、状态都齐。

**仍偏挤：**
- 内容区顺序：意图输入（textarea+6 chips+3 actions）→ 聊天头 → 上下文 chips → messages → 画像折叠 → quick questions → composer → global footer；一屏内两个输入区（意图 + 对话）并列，层级近似。
- 画像 `AI 对你的理解（记忆）` 折叠夹在消息与 quick questions 之间，长对话后需要滚动才看到。
- chips 11px、pinned 11px、profile hints 11px、profile labels 10.5px、message meta 10px，均低于 12px 系统下限；在 1366 更明显。
- 1366 长对话时，聊天窗内滚动 + 面板 body 滚动双层，composer/画像在下方，用户需要“猜”该滚哪一层。

### 2.2 行动 chips：是否像“建议”、点后去哪

**实际行为（OK）：**
- 点「生成局部候选」→ 切到 **生成 tab**，prompt 自动填为「保留我的笔触，只改这个区域」，toast `已切到图像工作台并填入建议；确认后生成`。**不会自动生成**。
- 点「让 AI 看看」→ 停留 **观察 tab**，意图框填入建议，toast `已把建议放进意图；点「让 AI 看看」继续`。**不会自动分析**。
- 目标落点符合任务预期：chips 是“带去下一步”，不是执行。

**UI 问题：**
- chips 没有 `建议`、`→`、目标 tab 名称等语义；`让 AI 看看` 本身就是一个动作动词，用户容易理解为“点了就分析”。
- `title` 里的 reason 只在 hover 才出现；触屏/键盘看不到。
- chips 是 11px 的小号 teal 边框按钮，和可执行主按钮视觉区分不足；最新 AI 回复过长时，chips 会落到 `.ai-chat-log` 视口之外，需要滚动才出现（`1920-chat-actions.png` 首条回复下方就被裁掉）。
- 点击后 toast 在底部，与固定 footer `让 AI 看看` 叠在一起（`1920-action-observe-destination.png`），落点反馈不够干净。

### 2.3 画像建议：是否容易理解、会不会误以为自动写入

**实际行为：**
- 确认 1 条素材观察后，展开 `AI 对你的理解（记忆）`，出现：
  `从你的 1 次素材确认里看到：#雾 #山 #冷蓝 #低饱和 #安静 #示例 [填入画像]`
- 点「填入画像」→ 写入 `state.aiProfile.style` + toast `已把素材决策里的关键词填入画像`；没有自动写入；字段仍是用户可编辑。

**风险：**
1. 摘要写 `AI 对你的理解（记忆）`，暗示已有记忆；实际画像字段此前为空。
2. 四个字段的 placeholder（`冷灰蓝、留白、颗粒、克制` 等）视觉上很像已填入的内容；用户可能把 placeholder 当作“AI 已经写好的画像”。
3. 建议区没有 `仅建议 · 尚未写入` 状态；按钮 `填入画像` 只有 11px/28 高，弱于建议文本。
4. 点击后 details 收起，用户看不到“到底写入了什么”，只能重新展开；没有预览/撤销。
5. `AI 对你的理解` 折叠默认关闭；长对话/1366 下容易被忽略，用户不知道有“建议”。

### 2.4 长对话滚动 / 消息密度 / 成本 / 清空

- `.ai-chat-log` 被限制为 `max-height:340px`，内部滚动；消息密度高，AI 回复是整段长文本，没有段落/要点；14 条后 header 变成 `长期对话 · 14 条 · 3010 tokens`，可读。
- 1366 下 chat log 只有约 120px 可视高度；用户输入在下方，长对话后 composer/画像被挤出面板，必须先滚整个 `.ai-propop-body` 才能继续发消息；没有“跳到最新”按钮。
- 成本/tokens：pinned 显示 `¥0`；chat header 显示总 tokens；每条 assistant 的 meta 是 `mock / mock-ai@0.1.0 · Mock · 0ms · 590 tokens`，但字号 10px，很难读；没有真实 provider 的汇总成本行。
- 清空：`清空对话` 按钮在聊天头右侧，标签清楚；但**点击立即清空、无确认/撤销**，只 toast `对话记忆已清空（素材/档案记忆不受影响）`。长对话场景下误触成本高。

### 2.5 1920 vs 1366

| 项目 | 1920 | 1366 |
|---|---|---|
| 3 tab + pinned | 完整、易读 | 可见，但 pinned 11px 更紧 |
| 行动 chips | 首条回复可能被裁；展开画像后可见 | 更易被裁；与 footer 争空间 |
| 长对话 | 面板高 675，composer 仍可见但拥挤 | composer/画像掉到面板滚动区外，需双层滚动 |
| 画像建议 | 展开后可见；字段小 | 更小；需滚动 |
| 清空 | 清楚 | 清楚但无确认 |

---

## 3. Top 5 P1/P2

| # | P | 问题 | 截图 | 影响 | 具体建议（CSS/组件） | 工作量 |
|---|---|---|---|---|---|---|
| 1 | **P1** | **pinned 上下文语义混淆且不完整**：`素材 0` 实际指 AI 引用数，但同一屏聊天上下文写 `素材 3 张`；无 latency；字号 11px | `audit-chat/1920-ai-idle.png`、`1920-profile-suggestions.png`、`1366-profile.png` | 用户以为 pinned 是“事实”，却与下方数字冲突；一眼扫到的上下文不可信 | 文案改 `参考 0` 或 `素材库 3 / 参考 0`；`renderAiPinnedStatus()` 增加 `延迟 0ms · tokens`；`.ai-pinned{font-size:12px;line-height:18px;gap:8px}`；增加 `mock/真实` 与 `¥0` 的语义 title | **S** |
| 2 | **P1** | **`AI 正在回答...` 状态在回复完成后不消失**：有结果、有 chips、已清空对话时 header 仍显示正在回答 | `audit-chat/1920-chat-actions.png`、`1920-profile-suggestions.png`、`1920-chat-cleared.png` | 用户以为 AI 还在忙，不敢点 chips/发下一条；状态机不可信 | `runChat()` 成功/失败/取消后统一 `setAiStatus('待决定')`；复用现有 `updateAiStatus`；busy 只在真实请求期间；加 `aria-live` 状态 | **S** |
| 3 | **P1** | **行动 chips 语义与位置不足**：11px，像执行按钮；无“建议/不会自动执行/前往 tab”提示；最新回复的 chips 可能被 chat log 裁掉；点击后 toast 与 footer 重叠 | `audit-chat/1920-chat-actions.png`、`1920-profile-suggestions.png`、`1920-action-generate-destination.png`、`1920-action-observe-destination.png` | 用户误以为点击自动执行；找不到 chips；落点反馈被遮挡 | chips 前缀 `建议 ·`，后缀 `→ 生成`/`→ 观察`；12px/28px；`.ai-chat-action::after{content:"→";}`；hover/focus 显示 reason；chat log 自动滚到包含最新 chips；toast 移到顶部 | **S/M** |
| 4 | **P1** | **画像建议容易被误读为已写入**：summary `AI 对你的理解（记忆）`；placeholder 文案像已填值；无 `仅建议` 状态；填入按钮过小，写完即收起 | `audit-chat/1920-profile-suggestions.png`、`1920-profile-filled.png`、`1366-profile.png` | 用户不知道图片画像是否已被 AI 改动；不信任/误信任 | summary 改 `AI 对你的理解（建议，尚未写入）`；按钮 `采用建议写入画像` 28×?/12px；字段 placeholder 加 `例：` 并降低对比；写入后保留展开并显示 diff/撤销 toast | **S/M** |
| 5 | **P1** | **长对话布局不可持续**：chat log 340px 嵌套滚动；1366 下输入框/画像掉到面板滚动外；无“跳到最新”；token meta 10px；清空无确认 | `audit-chat/1920-chat-long.png`、`1366-chat-long.png`、`1366-profile.png`、`1920-chat-cleared.png` | 长对话后发不出下一句/看不到画像；清空误触不可恢复；成本信息难读 | `.ai-chat-log{max-height:min(42vh,340px)}` + 可见 scrollbar；composer `position:sticky; bottom:0`；`清空对话` 二次确认/可撤销；meta 10→12px；header 增加“跳到最新” | **M** |

> 3 tab 本身不再列为问题：当前 `观察/生成/记录` 层级清楚，保留。控制/成本在 pinned 的雏形也保留，只修正语义与字号。

---

## 4. 只改 3 处（下一轮就做）

1. **状态真实性（S）**：pinned 计数改为明确语义（`素材库 N / 参考 N`）+ 加 latency/tokens；`runChat` 结束后重置 `AI 状态` 到 `待决定`；清空/失败/取消都复位。验收：回复完成 1s 内 header 不再显示“正在回答”；pinned 与聊天上下文数字一致。
2. **建议层语义（S/M）**：行动 chips 加 `建议 · … → 生成/观察` 与 12px/28px；画像 summary 改 `AI 对你的理解（建议，尚未写入）`，按钮改 `采用建议写入画像`，placeholder 加 `例：`；点击后展开并显示写入内容/撤销。验收：5 位新用户中至少 4 人能说出“chips 只是建议，不会自动执行；画像还没写入”。
3. **长对话可用性（M）**：聊天 log 固定高度+可见滚动条；“跳到最新”；composer sticky 在 footer 上方；清空对话二次确认或 5s 撤销；meta 10→12px。验收：1366 连发 14 条后，仍能在不滚动整个面板的情况下继续输入、看到最新 chips、展开画像。

---

## 5. 已验证正常（不要回退）

- `观察/生成/记录` 三 tab 可切换；tab active 态清楚。
- pinned 条位置稳定，不随 body 滚走；Mock/真实与选区/成本字段可读。
- 行动 chips 点击落点正确：生成→生成 tab + 预填 prompt；观察→观察 tab + 意图；**不自动执行**（符合 D1/D5）。
- 画像建议确实从 `L5` 确认记录提炼；按钮写入 `aiProfile.style` 并持久化，有 toast；没有自动写入。
- 长对话有总条数/tokens 统计、每条 meta、清空按钮；清空仅清聊天，不删素材/档案（文案已说明）。
- 0 console error；未触发真实付费 AI。

---

## 6. 证据清单

- `audit-chat/1920-ai-idle.png`：3 tab + pinned + 空聊天/画像折叠。
- `audit-chat/1920-chat-actions.png`：第一条 Mock 回复；header 状态与 chips 可见性证据。
- `audit-chat/1920-action-generate-destination.png`：点生成 chip → 生成 tab + prompt。
- `audit-chat/1920-action-observe-destination.png`：点观察 chip → 观察 tab + 意图/toast。
- `audit-chat/1920-profile-suggestions.png`：画像折叠展开 + 建议 + 字段。
- `audit-chat/1920-profile-filled.png`：填入画像后收起 + toast。
- `audit-chat/1920-chat-long.png`：14 条长对话、tokens/清空。
- `audit-chat/1366-chat-long.png`：1366 长对话布局/composer 掉出视野。
- `audit-chat/1366-profile.png`：1366 画像建议。
- `audit-chat/1920-chat-cleared.png`：清空后状态（header 仍“正在回答”）。
- `audit-chat/console-errors.json` = `[]`。

## 7. 限制

本次使用 Mock 对话（不触发真实付费），Mock 回复文本不代表真实模型质量；真实 provider 的成本/延迟展示需在配置真实 key 后复测。长对话只构造到 14 条、未测 60 条上限；1024 未纳入本轮（任务只要求 1920/1366）。
