#!/usr/bin/env node
// v2/psd/test/psd-roundtrip.mjs —— T39 保真测试（零依赖 CDP）
// 用法：node v2/psd/test/psd-roundtrip.mjs <pageUrl> [port]
// 输出：v2/psd/results/{fidelity.json, fidelity.md, manifest.json, samples/*.psd}
import process from 'node:process';
import { writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/psd/test-runner.html';
const port = Number(process.argv[3] || 9333);
const base = `http://127.0.0.1:${port}`;
const root = join(dirname(fileURLToPath(import.meta.url)), '..'); // v2/psd
const resultsDir = join(root, 'results');
const samplesDir = join(resultsDir, 'samples');
mkdirSync(samplesDir, { recursive: true });

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/psd/test-runner.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}

const page = await findPage();
if (!page) { console.error('找不到 test-runner 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__PSD_READY__) { if (Date.now() - t0 > 30000) throw new Error('timeout waiting ready'); await new Promise((r) => setTimeout(r, 200)); }
  return await window.__PSD_TEST__.run();
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 240000 });
const report = r.result && r.result.result && r.result.result.value;
if (!report) { console.error('无 report', JSON.stringify(r).slice(0, 1500)); process.exit(3); }
ws.close();

// 写 PSD 样本 + manifest + 报告
const manifest = [];
for (const s of report.samples) {
  if (s.base64) {
    const src = Buffer.from(s.base64.src, 'base64');
    const round = Buffer.from(s.base64.round, 'base64');
    writeFileSync(join(samplesDir, `${s.id}-source.psd`), src);
    writeFileSync(join(samplesDir, `${s.id}-roundtrip.psd`), round);
    manifest.push({
      id: s.id, name: s.name, description: s.description, provenance: s.provenance, license: s.license,
      expectedFeatures: s.expectedFeatures,
      source: { file: `samples/${s.id}-source.psd`, bytes: src.length, sha256: createHash('sha256').update(src).digest('hex') },
      roundtrip: { file: `samples/${s.id}-roundtrip.psd`, bytes: round.length, sha256: createHash('sha256').update(round).digest('hex') },
      ok: s.ok,
    });
  } else {
    manifest.push({ id: s.id, name: s.name, provenance: s.provenance, license: s.license, ok: s.ok, error: s.error });
  }
}
writeFileSync(join(resultsDir, 'manifest.json'), JSON.stringify({ schema: 'mozheng.psd.testset.v1', generatedAt: report.generatedAt, environment: report.environment, samples: manifest }, null, 2));

// fidelity.json：去掉 base64（二进制单独存）
const fidelity = {
  ...report,
  samples: report.samples.map((s) => { const copy = { ...s }; delete copy.base64; return copy; }),
};
writeFileSync(join(resultsDir, 'fidelity.json'), JSON.stringify(fidelity, null, 2));

// fidelity.md
const lines = [];
lines.push('# PSD 导入/导出保真矩阵（T39）');
lines.push('');
lines.push(`> 生成：${report.generatedAt}｜环境：${report.environment.browser}${report.environment.headless ? '（headless）' : ''}｜ag-psd ${report.environment.agPsd}`);
lines.push('');
lines.push('| 样本 | 结构 | 像素通过率 | 蒙版 | 混合 | 源/往返字节 | 不支持项 | 判定 |');
lines.push('|---|---|---|---|---|---|---|---|');
for (const s of report.samples) {
  if (s.error) { lines.push(`| ${s.id} | - | - | - | - | - | - | ✗ ${String(s.error).slice(0, 60)} |`); continue; }
  const unsupported = (s.importFidelity.items || []).map((i) => i.feature).filter((v, i, a) => a.indexOf(v) === i).join(', ') || '无';
  lines.push(`| ${s.id} | ${s.compare.structurePass ? '✓' : '✗'} (${s.compare.structureMatchRate}) | ${(s.compare.pixelPassRate * 100).toFixed(1)}% | ${s.compare.maskPreserved ? '✓' : '✗'} | ${s.compare.blendPreserved ? '✓' : '✗'} | ${s.srcBytes} / ${s.roundBytes} | ${unsupported} | ${s.ok ? '✓' : '✗'} |`);
}
lines.push('');
lines.push('## 汇总');
lines.push('');
lines.push(`- 样本数：${report.summary.sampleCount}（有效 ${report.summary.validSamples}）`);
lines.push(`- 结构通过率：${(report.summary.structurePassRate * 100).toFixed(1)}%`);
lines.push(`- 像素通过率：${(report.summary.pixelPassRate * 100).toFixed(1)}%`);
lines.push(`- 蒙版保留样本：${report.summary.maskPreserved}`);
lines.push(`- 不支持项报告：${report.summary.unsupportedReported ? '✓（文字层）' : '✗'}`);
lines.push(`- 引擎集成：${report.summary.engineIntegrationOk ? '✓' : '✗'}${report.engineIntegration && report.engineIntegration.stats ? `（${JSON.stringify(report.engineIntegration.stats)}）` : ''}`);
lines.push('');
lines.push('## 限制');
lines.push('');
lines.push('- 文字/智能对象/图层样式/调整层/矢量：不可编辑（记录于 fidelity.items，不静默丢失）。');
lines.push('- 非 8-bit / 非 RGB：按 8-bit RGB 栅格近似。');
lines.push('- 组蒙版/组剪贴/多级组：与 T37 LayerSystem 集成时降级（引擎仅 1 级组）。');
lines.push('- Procreate 样本为**结构模拟**（非真实 Procreate 导出文件；Procreate 未参与）。');
lines.push('');
writeFileSync(join(resultsDir, 'fidelity.md'), lines.join('\n'));

console.log(JSON.stringify({ summary: report.summary, samples: report.samples.map((s) => ({ id: s.id, ok: s.ok, error: s.error })) }, null, 2));
process.exit(report.summary.allOk ? 0 : 1);
