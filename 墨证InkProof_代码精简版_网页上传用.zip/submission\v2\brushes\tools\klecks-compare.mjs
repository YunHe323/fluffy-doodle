/**
 * v2/brushes/tools/klecks-compare.mjs
 * T43 开源对照：用同一组 5 个笔迹场景，在
 *   ① Klecks dist（MIT，参考实现）默认圆笔
 *   ② 我们 v2/brushes 的 hard-round / pencil / ink-liner / chalk
 * 上分别绘制，导出两张/多张画布图 + 元数据，供 Python 拼对照 sheet 与指标。
 *
 * 注意：Klecks 只作为「行为/观感参考」，本脚本通过浏览器输入事件驱动 Klecks 的公开 UI，
 * 不复制 Klecks 源码；我们的笔刷实现为自研（仅借鉴 BezierLine 算法思路，见 brush-controller.js 注释）。
 *
 * 用法（项目根目录，先 node v2/serve.mjs）：
 *   node v2/brushes/tools/klecks-compare.mjs [--cdp 9542]
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
const OUT = path.join(ROOT, 'v2', 'brushes', 'samples', 'klecks');
fs.mkdirSync(OUT, { recursive: true });
const CDP_PORT = Number((process.argv.find((a) => a.startsWith('--cdp=')) || '').split('=')[1] || 9542);
/** 本地服务端口：优先 INKPROOF_BASE，其次 v2/.runtime-port（serve.mjs 自动选端口），最后 4200 */
function resolveBase() {
  if (process.env.INKPROOF_BASE) return process.env.INKPROOF_BASE;
  try {
    const port = fs.readFileSync(path.join(ROOT, 'v2', '.runtime-port'), 'utf8').trim();
    if (/^\d+$/.test(port)) return 'http://127.0.0.1:' + port;
  } catch (e) { /* ignore */ }
  return 'http://127.0.0.1:4200';
}
const BASE = resolveBase();
const KLECKS_URL = `${BASE}/spike/klecks/vendor/klecks/dist/index.html`;
const OURS_URL = `${BASE}/v2/brushes/demo.html`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const EDGE = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
].find((p) => fs.existsSync(p));

/** 5 个场景：归一化坐标 u,v ∈ [0,1]，pressure(t)（笔输入） */
const SCENARIOS = [
  {
    id: 'slow-curve', label: '慢速曲线', points: 46, durationMs: 1400,
    pressure: (t) => 0.3 + 0.55 * Math.sin(t * Math.PI),
    pos: (t) => ({ u: 0.14 + 0.72 * t, v: 0.16 + 0.085 * Math.sin(t * Math.PI * 2) }),
  },
  {
    id: 'fast-s', label: '快速 S 形', points: 10, durationMs: 170,
    pressure: () => 0.65,
    pos: (t) => ({ u: 0.14 + 0.72 * t, v: 0.36 + 0.08 * Math.sin(t * Math.PI * 2.1) }),
  },
  {
    id: 'light-pressure', label: '轻压直线', points: 32, durationMs: 850,
    pressure: () => 0.15,
    pos: (t) => ({ u: 0.14 + 0.72 * t, v: 0.55 + 0.005 * Math.sin(t * 9) }),
  },
  {
    id: 'heavy-pressure', label: '重压直线', points: 32, durationMs: 850,
    pressure: () => 0.92,
    pos: (t) => ({ u: 0.14 + 0.72 * t, v: 0.68 + 0.005 * Math.sin(t * 9) }),
  },
  {
    id: 'short-dots', label: '短点', points: 6, durationMs: 420,
    dots: true,
    pressure: () => 0.75,
    pos: (t) => ({ u: 0.16 + 0.66 * (Math.round(t * 5) / 5), v: 0.82 }),
  },
];

const report = { schema: 'inkproof.klecks-compare.v1', createdAt: new Date().toISOString(), scenarios: SCENARIOS.map((s) => s.id), klecks: null, ours: [], ok: false };

let ws = null; let msgId = 0; const pending = new Map();
const send = (method, params = {}) => new Promise((resolve) => { const id = ++msgId; pending.set(id, resolve); ws.send(JSON.stringify({ id, method, params })); });
async function ev(expression, timeoutMs = 60000) {
  const r = await Promise.race([
    send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true }),
    sleep(timeoutMs).then(() => ({ __timeout: true })),
  ]);
  if (r.__timeout) throw new Error('evaluate timeout: ' + expression.slice(0, 100));
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1500));
  return r.result?.result?.value;
}
async function waitFor(expr, timeoutMs) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) { if (await ev(expr).catch(() => false)) return true; await sleep(200); }
  return false;
}
async function connect(port) {
  let target = null;
  for (let i = 0; i < 400 && !target; i += 1) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
      target = list.find((t) => t.type === 'page' && /^https?:/.test(t.url));
    } catch (e) { /* wait */ }
    if (!target) await sleep(150);
  }
  if (!target) throw new Error('CDP target not found');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (m.id && pending.has(m.id)) { const r = pending.get(m.id); pending.delete(m.id); r(m); return; }
    if (m.method === 'Runtime.exceptionThrown') report.runtimeExceptions = (report.runtimeExceptions || []).concat(m.params.exceptionDetails?.text).slice(0, 10);
  };
  await send('Runtime.enable');
  await send('Page.enable');
  return target;
}
async function navigate(url) {
  await send('Page.navigate', { url });
  await send('Page.enable');
  await sleep(500);
}

/* ---------------- Klecks：真实输入事件绘制 ---------------- */
async function drawKlecks() {
  const info = await ev(`(() => {
    const c = [...document.querySelectorAll('canvas')][0];
    const r = c.getBoundingClientRect();
    return { w: c.width, h: c.height, css: [r.width, r.height], rect: { x: r.x, y: r.y, w: r.width, h: r.height }, dpr: devicePixelRatio };
  })()`);
  report.klecks = { ...info, scenarios: [] };
  const rect = info.rect;
  const p2c = (u, v) => ({ x: rect.x + u * rect.w, y: rect.y + v * rect.h });
  for (const sc of SCENARIOS) {
    const t0 = Date.now();
    if (sc.dots) {
      for (let i = 0; i < 6; i += 1) {
        const t = i / 5;
        const p = p2c(sc.pos(t).u, sc.pos(t).v);
        await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: p.x, y: p.y, button: 'left', buttons: 1, clickCount: 1, pointerType: 'pen', force: sc.pressure(t) });
        await sleep(30);
        await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: p.x, y: p.y, button: 'left', buttons: 0, clickCount: 1, pointerType: 'pen', force: sc.pressure(t) });
        await sleep(70);
      }
    } else {
      const p0 = sc.pos(0);
      const start = p2c(p0.u, p0.v);
      await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: start.x, y: start.y, button: 'left', buttons: 1, clickCount: 1, pointerType: 'pen', force: sc.pressure(0) });
      const stepMs = Math.max(4, Math.round(sc.durationMs / sc.points));
      for (let i = 1; i <= sc.points; i += 1) {
        const t = i / sc.points;
        const pt = sc.pos(t);
        const p = p2c(pt.u, pt.v);
        await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: p.x, y: p.y, button: 'left', buttons: 1, pointerType: 'pen', force: sc.pressure(t) });
        await sleep(stepMs);
      }
      const end = sc.pos(1);
      const pe = p2c(end.u, end.v);
      await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: pe.x, y: pe.y, button: 'left', buttons: 0, clickCount: 1, pointerType: 'pen', force: sc.pressure(1) });
      await sleep(120);
    }
    const out = await ev(`(() => {
      const c = [...document.querySelectorAll('canvas')][0];
      return { url: c.toDataURL('image/png'), w: c.width, h: c.height, undo: (window.klApp && window.klApp.getHistoryState) ? 'api' : null };
    })()`).catch((e) => ({ error: String(e && e.message || e) }));
    if (out.url) {
      const file = path.join(OUT, `klecks-${sc.id}.png`);
      fs.writeFileSync(file, Buffer.from(out.url.split(',')[1], 'base64'));
      sc.file = path.relative(ROOT, file).replace(/\\/g, '/');
    }
    report.klecks.scenarios.push({ id: sc.id, elapsedMs: Date.now() - t0, file: sc.file, canvas: [out.w, out.h].filter(Boolean) });
    sc.file = null;
  }
  // 整张 Klecks 画布（含 5 行）
  const finalCanvas = await ev(`(() => { const c = [...document.querySelectorAll('canvas')][0]; return { url: c.toDataURL('image/png'), w: c.width, h: c.height }; })()`);
  const f = path.join(OUT, 'klecks-scenes.png');
  fs.writeFileSync(f, Buffer.from(finalCanvas.url.split(',')[1], 'base64'));
  report.klecks.full = path.relative(ROOT, f).replace(/\\/g, '/');
  report.klecks.fullSize = [finalCanvas.w, finalCanvas.h];
}

/* ---------------- 我们：同一场景程序化绘制（同 controller 路径） ---------------- */
const OURS_BRUSHES = ['hard-round', 'pencil', 'ink-liner', 'chalk'];
async function drawOurs() {
  await waitFor('!!window.__BRUSH_READY__', 90000);
  const rect = await ev(`(() => { const r = document.getElementById('stage').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
  const p2c = (u, v) => ({ x: rect.x + u * rect.w, y: rect.y + v * rect.h });
  for (const brushId of OURS_BRUSHES) {
    // 清空 + 选笔刷 + 适配大小（Klecks 默认 size 4 → 我们直径 ~8px；pencil 另行）
    await ev(`(async () => {
      const e = window.__V2__; let g = 0; while (e.canUndo() && g < 400) { e.undo(); g += 1; }
      const presets = window.__BRUSH_DEMO__.presets;
      const idx = presets.brushes.findIndex((b) => b.id === '${brushId}');
      document.querySelectorAll('.brushBtn')[idx].click();
      return idx;
    })()`);
    await sleep(200);
    const sizeFor = { 'hard-round': 9, pencil: 9, 'ink-liner': 5, chalk: 16 }[brushId];
    await ev(`window.__BRUSH_DEMO__.controller.setParam('size.base', ${sizeFor})`);
    await ev(`(() => { const c = window.__BRUSH_DEMO__.controller; c.preset.size.base = ${sizeFor}; return c.preset.size.base; })()`);
    const t0 = Date.now();
    const scenarios = [];
    for (const sc of SCENARIOS) {
      const tt0 = Date.now();
      if (sc.dots) {
        for (let i = 0; i < 6; i += 1) {
          const t = i / 5;
          const uv = sc.pos(t);
          const x = +(uv.u * 1600).toFixed(2), y = +(uv.v * 1000).toFixed(2), pr = sc.pressure(t);
          await ev(`(() => { const c = window.__BRUSH_DEMO__.controller;
            c.begin({ x: ${x}, y: ${y}, pressure: ${pr}, timestamp: performance.now(), pointerType: 'pen' });
            c.append({ x: ${x}, y: ${y}, pressure: ${pr}, timestamp: performance.now() + 40, pointerType: 'pen' });
            c.end(); return true; })()`);
          await sleep(70);
        }
      } else {
        const n = sc.points;
        const stepMs = Math.max(4, Math.round(sc.durationMs / n));
        const pts = [];
        for (let i = 0; i <= n; i += 1) {
          const t = i / n;
          const uv = sc.pos(t);
          pts.push({ x: +(uv.u * 1600).toFixed(2), y: +(uv.v * 1000).toFixed(2), pressure: sc.pressure(t), timestamp: 1000 + i * stepMs, pointerType: 'pen' });
        }
        await ev(`(() => { const c = window.__BRUSH_DEMO__.controller; const pts = ${JSON.stringify(pts)};
          c.begin(pts[0]); for (let i = 1; i < pts.length; i++) c.append(pts[i]); c.end(); return pts.length; })()`);
        await sleep(120);
      }
      scenarios.push({ id: sc.id, elapsedMs: Date.now() - tt0 });
    }
    const url = await ev(`window.__V2__.getCompositeDataUrl()`);
    const file = path.join(OUT, `ours-${brushId}.png`);
    fs.writeFileSync(file, Buffer.from(url.split(',')[1], 'base64'));
    report.ours.push({ brush: brushId, sizePx: sizeFor, file: path.relative(ROOT, file).replace(/\\/g, '/'), scenarios, elapsedMs: Date.now() - t0 });
  }
  report.oursCanvas = rect;
  report.oursSize = [1600, 1000];
}

try {
  if (!EDGE) throw new Error('no Edge found');
  const profile = path.join(os.tmpdir(), 'kleckscmp-' + Date.now());
  // 团队规范：自动化一律 headless（不弹窗）；--headed 才开窗且移出屏幕
  const HEADLESS = !process.argv.includes('--headed');
  const launchArgs = [
    '--remote-debugging-port=' + CDP_PORT, '--user-data-dir=' + profile,
    '--no-first-run', '--no-default-browser-check',
  ];
  if (HEADLESS) {
    launchArgs.push('--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1680,1050');
  } else {
    launchArgs.push('--window-size=1680,1050', '--window-position=-3000,-3000', '--start-minimized');
  }
  launchArgs.push(KLECKS_URL);
  const browser = spawn(EDGE, launchArgs, { stdio: 'ignore' });
  report.headless = HEADLESS;
  report.browser = path.basename(EDGE);
  try {
    await connect(CDP_PORT);
    // 1) Klecks
    const klecksLoaded = await waitFor(`(() => { const l = document.getElementById('loading-screen'); return !l || getComputedStyle(l).display === 'none'; })()`, 60000);
    await sleep(2500);
    report.klecks = { loaded: klecksLoaded };
    if (!klecksLoaded) throw new Error('Klecks 未加载完成');
    await drawKlecks();
    // 2) 我们的页面（Page.navigate 到同源）
    await navigate(OURS_URL);
    await drawOurs();
    report.ok = true;
  } finally {
    try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
    try { browser.kill(); } catch (e) { /* ignore */ }
    await sleep(400);
    try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  }
  fs.writeFileSync(path.join(OUT, 'compare-data.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
} catch (e) {
  report.fatal = String(e && e.stack || e);
  fs.writeFileSync(path.join(OUT, 'compare-data.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  process.exit(report.ok ? 0 : 1);
}
