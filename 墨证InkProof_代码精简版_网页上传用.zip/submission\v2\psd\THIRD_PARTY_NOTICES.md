# 第三方声明（v2/psd/vendor）

## ag-psd

| 项 | 值 |
|---|---|
| 组件 | **ag-psd**（PSD/PSB 读写，浏览器 bundle） |
| 版本 | `28.3.1`（`vendor/ag-psd/package.json`） |
| SPDX | **MIT** |
| 版权 | Copyright (c) 2016 Agamnentzar |
| 来源 | 用户提供 Klecks 离线包内 `node_modules/ag-psd`（`spike/klecks/vendor/klecks/node_modules/ag-psd`），复制 browser bundle 到 `v2/psd/vendor/ag-psd/` |
| 文件 | `bundle.js`（794,368 B，SHA-256 `0d13ba3bc8f6900b8041ef407f6924213b9d412f88ba2b009a733c3d9c736af0`）、`LICENSE`、`package.json`、`README_PSD.md` |

## bundle 内含的第三方库

`bundle.js` 由 ag-psd 打包，内含以下依赖（均为 MIT）：

| 组件 | 版本 | 许可 | 说明 |
|---|---|---|---|
| `pako` | 2.1.0 | MIT（Zlib 派生） | zlib 压缩/解压（PSD 数据压缩） |
| `base64-js` | 1.5.1 | MIT | base64 编解码 |

> 义务：保留 MIT 版权与许可声明。本 vendor 目录保留 ag-psd `LICENSE`；pako/base64-js 的许可文本通过 ag-psd 包元数据与 bundle 打包来源可追溯。合并进 `product/` 时需在 `product/THIRD_PARTY_NOTICES.md` 一并登记。

## pdf.js 注记（Apache-2.0，继承 T24 第三方清单）

T24 预研的第三方清单记录：ag-psd 在部分 **PSD 文本/字体描述符** 解析上与 **pdf.js（Apache-2.0）** 存在参考/兼容关系。当前 `v2/psd/vendor/ag-psd/bundle.js` 内**未检出 pdf.js 代码**，因此：
- 现阶段按 **MIT** 使用 ag-psd；
- 若后续启用文字层/字体嵌入等与 pdf.js 相关的解析能力，需附 **Apache-2.0** 许可与 NOTICE，并在产品 NOTICES 中单独列出。

## 使用约束

- 不使用 GPL/LGPL/许可不明代码；本模块唯一第三方运行时是 ag-psd（MIT）及其 bundle 内 MIT 依赖。
- 测试集 PSD 全部由本项目程序生成（CC0-1.0）；Procreate 样本为结构模拟，非真实 Procreate 文件。
