#!/usr/bin/env node
/**
 * v2/qa/pw/harness.mjs — T51：Playwright-core 版 QA harness（替代自研手写 CDP）
 *
 * 为什么重写：自研 CDP 在多次运行中出现过截图超时/卡住/判定与证据不一致；Playwright 自带
 * 自动等待、稳定超时、截图与输入 API，且 `channel:'msedge'` 直接复用本机 Edge（无需下载浏览器）。
 *
 * 覆盖：
 *   A. 冒烟（对应 T42）：app / brushes / engine 三页 —— 就绪、canvas、pointer、绘制后内容变化、
 *      pointerup 0/16/50/200ms 帧稳定、undo 帧完整。
 *   B. 对照（对应 T48）：我们三页 vs Klecks（MIT dist）× 3 轮 —— 连续笔迹断点/CV、帧稳定、undo；
 *      输出 GATE-pw.md，并与旧 compare.mjs 的 GATE.md 做结论一致性对比。
 *
 * 运行约束：默认 headless（不弹用户窗口）；--headed 仅用于最终人工证据（窗口移屏外+告知 Lead）。
 * 用法：
 *   node v2/qa/pw/harness.mjs                 # 冒烟 + 对照 3 轮
 *   node v2/qa/pw/harness.mjs --rounds 1      # 快速冒烟
 *   node v2/qa/pw/harness.mjs --smoke-only
 */
import { spawn } from 'node:child_process';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const QA = path.resolve(__dirname, '..');
const REPO = path.resolve(QA, '..', '..');
const OUT = __dirname;
const SHOTS = path.join(OUT, 'shots');
const require = createRequire(import.meta.url);

const argv = process.argv.slice(2);
const argOf = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? argv[i + 1] : d; };
const ROUNDS = Number(argOf('--rounds', 3));
const HEADLESS = !argv.includes('--headed');
const SMOKE_ONLY = argv.includes('--smoke-only');
const TARGET_TIMEOUT = Number(argOf('--timeout', 90)) * 1000;

const TARGETS = [
  { id: 'ours-app', kind: 'ours', url: (o) => o.ours + '/v2/app/index.html', ready: 'window.__V2_APP_READY__ === true' },
  { id: 'ours-brushes', kind: 'ours', url: (o) => o.ours + '/v2/brushes/demo.html', ready: 'window.__BRUSH_READY__ === true' },
  { id: 'ours-engine', kind: 'ours', url: (o) => o.ours + '/v2/engine/demo.html', ready: 'window.__V2__ && window.__V2__.ready === true' },
  { id: 'klecks', kind: 'klecks', url: (o) => o.klecks + '/index.html', ready: `(() => document.readyState === 'complete' && [...document.querySelectorAll('canvas')].some((c) => c.width > 200 && c.height > 200))()` },
];
const S1 = (() => { const a = []; for (let i = 0; i <= 40; i += 1) { const t = i / 40; a.push([0.12 + 0.76 * t, 0.5 + 0.28 * Math.sin(t * Math.PI * 2)]); } return a; })();
const S2 = [[0.10, 0.50], [0.20, 0.24], [0.30, 0.20], [0.44, 0.38], [0.56, 0.62], [0.70, 0.78], [0.84, 0.72], [0.92, 0.50]];
const S3A = [[0.15, 0.25], [0.35, 0.3], [0.55, 0.25], [0.8, 0.3]];
const S3B = [[0.15, 0.72], [0.4, 0.68], [0.62, 0.72], [0.85, 0.68]];
const SEGMENTS = 12;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const nowIso = () => new Date().toISOString();
const fmt = (v) => (v == null ? '—' : String(v));

// ---------------------------------------------------------------- 服务
async function ensureOurs() {
  // 用自己的独立服务（固定高段端口，避免与其它会话/队友残留服务互相影响）：
  // 先删 .runtime-port，再起 serve.mjs（被占会自动 +1），读回实际端口并做健康检查。
  const portFile = path.join(REPO, 'v2', '.runtime-port');
  await fsp.rm(portFile, { force: true }).catch(() => {});
  const proc = spawn(process.execPath, [path.join(REPO, 'v2', 'serve.mjs')], { cwd: REPO, env: { ...process.env, PORT: '4260' }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  for (let i = 0; i < 120; i += 1) {
    await sleep(150);
    try {
      const p = Number(String(await fsp.readFile(portFile, 'utf8')).trim());
      const r = await fetch(`http://127.0.0.1:${p}/v2/app/index.html`);
      if (r.ok) return { origin: `http://127.0.0.1:${p}`, proc };
    } catch { /* wait */ }
  }
  try { proc.kill(); } catch { /* ignore */ }
  throw new Error('无法启动 v2/serve.mjs（独立端口 4260+）');
}

async function ensureKlecks() {
  // 始终起自己的 Klecks 静态服务（不接管别人已在跑的服务），端口从 4310 起自动 +1
  const proc = spawn(process.execPath, [path.join(QA, 'compare', 'serve-klecks.mjs'), '--port', '4310'], { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  let log = '';
  proc.stdout.setEncoding('utf8'); proc.stdout.on('data', (d) => { log += d; });
  proc.stderr.setEncoding('utf8'); proc.stderr.on('data', (d) => { log += d; });
  for (let i = 0; i < 80; i += 1) {
    await sleep(150);
    const m = /http:\/\/127\.0\.0\.1:(\d+)\//.exec(log);
    if (m) return { origin: `http://127.0.0.1:${m[1]}`, proc };
  }
  throw new Error('无法启动 Klecks 静态服务（spike/klecks/vendor/klecks/dist 是否存在？）');
}

// ---------------------------------------------------------------- 页面内工具（readback：不依赖截图/窗口可见性）
const PAGE_HELPERS = `
window.__PWQA__ = {
  async grab(kind) {
    if (kind === 'ours') {
      const e = window.__V2__ || (window.__V2_APP__ && window.__V2_APP__.engine) || (window.__BRUSH_DEMO__ && window.__BRUSH_DEMO__.engine);
      if (!e) return null;
      if (e.compositor && e.store) e.compositor.compositeAll(e.store);
      return await e.getCompositeDataUrl();
    }
    const cs = [...document.querySelectorAll('canvas')].sort((a, b) => (b.width * b.height) - (a.width * a.height));
    const c = cs[0];
    if (!c) return null;
    try { return c.toDataURL('image/png'); } catch (e) { return null; }
  },
  async load(src) {
    try {
      const img = new Image(); img.src = src; await img.decode();
      const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
      const x = c.getContext('2d'); x.drawImage(img, 0, 0);
      return { w: c.width, h: c.height, d: x.getImageData(0, 0, c.width, c.height).data };
    } catch (e) { return null; }
  },
  async stats(curUrl, refUrl, points) {
    const cur = await this.load(curUrl); const ref = refUrl ? await this.load(refUrl) : null;
    if (!cur) return { ink: 0, breakpoints: null, thicknessCV: null, decodeFailed: true };
    const W = cur.w, H = cur.h; const points2 = points || [];
    let ink = 0;
    const seg = new Array(${SEGMENTS}).fill(0);
    const samples = new Array(${SEGMENTS}).fill(0);
    const centers = [];
    for (let s = 0; s < ${SEGMENTS}; s += 1) {
      if (!points2.length) { centers.push(null); continue; }
      const t = (s + 0.5) / ${SEGMENTS};
      const fi = Math.min(points2.length - 1, t * (points2.length - 1));
      const j0 = Math.floor(fi), j1 = Math.min(points2.length - 1, j0 + 1), f = fi - j0;
      const px = points2[j0][0] + (points2[j1][0] - points2[j0][0]) * f;
      const py = points2[j0][1] + (points2[j1][1] - points2[j0][1]) * f;
      centers.push({ x: Math.round(px * W), y: Math.round(py * H) });
    }
    // 稳健口径：每个理论路径采样点取方形窗口（边长 2R），窗口内 ink 面积 / (2R) ≈ 该处条带宽度（角度无关的一阶近似）
    const STEP = 2;
    const R = Math.max(24, Math.min(72, Math.round(Math.min(W, H) * 0.06)));
    const segInk = new Array(${SEGMENTS}).fill(0);
    const inkMask = new Uint8Array(W * H);   // 真线宽：法向截面 run-length 用
    for (let y = 0; y < H; y += STEP) for (let x = 0; x < W; x += STEP) {
      const i = (y * W + x) * 4;
      const bg = cur.d[i] < 34 && cur.d[i + 1] < 36 && cur.d[i + 2] < 42;
      let isInk;
      if (ref && ref.w === W && ref.h === H) isInk = !bg && (Math.abs(cur.d[i] - ref.d[i]) > 24 || Math.abs(cur.d[i + 1] - ref.d[i + 1]) > 24 || Math.abs(cur.d[i + 2] - ref.d[i + 2]) > 24);
      else isInk = !bg && cur.d[i + 3] > 8 && cur.d[i] < 200;
      if (!isInk) continue;
      ink += 1;
      inkMask[y * W + x] = 1;
      for (let s = 0; s < ${SEGMENTS}; s += 1) {
        const c0 = centers[s]; if (!c0) continue;
        if (Math.abs(x - c0.x) <= R && Math.abs(y - c0.y) <= R) segInk[s] += 1;
      }
    }
    const widths = segInk.map((v) => Math.round(((v * STEP * STEP) / (2 * R)) * 100) / 100);
    // 断点 = 探针窗口内「几乎没有 ink」（gap 检测，对细线稳健：1px 线穿过窗口也有 ~2R/STEP 个采样）
    const present = segInk.map((v) => v >= 1);
    const coveredArr = widths.filter((w, i) => present[i]);
    const mean = coveredArr.length ? coveredArr.reduce((a, b) => a + b, 0) / coveredArr.length : 0;
    const sd = coveredArr.length > 1 ? Math.sqrt(coveredArr.reduce((a, b) => a + (b - mean) * (b - mean), 0) / coveredArr.length) : 0;
    // ---- 真线宽（T80）：沿路径法向做截面 run-length ----
    const trueWidths = [];
    for (let s = 0; s < ${SEGMENTS}; s += 1) {
      const c0 = centers[s]; if (!c0) { trueWidths.push(0); continue; }
      const t = (s + 0.5) / ${SEGMENTS};
      const fi = Math.min(points2.length - 1, t * (points2.length - 1));
      const i0 = Math.max(0, Math.floor(fi) - 2), i1 = Math.min(points2.length - 1, Math.floor(fi) + 2);
      const ax = points2[i0][0] * W, ay = points2[i0][1] * H, bx2 = points2[i1][0] * W, by2 = points2[i1][1] * H;
      let tx = bx2 - ax, ty = by2 - ay; const tl = Math.hypot(tx, ty) || 1; tx /= tl; ty /= tl;
      const nx = -ty, ny = tx;
      const maxW = Math.min(180, Math.max(24, Math.round(Math.max(W, H) * 0.08)));
      let run = 0, best = 0;
      for (let k = -maxW; k <= maxW; k += 1) {
        const xx = Math.round(c0.x + nx * k), yy = Math.round(c0.y + ny * k);
        let isInkPx = false;
        if (xx >= 0 && yy >= 0 && xx < W && yy < H) {
          const ii = (yy * W + xx) * 4;
          const bg2 = cur.d[ii] < 34 && cur.d[ii + 1] < 36 && cur.d[ii + 2] < 42;
          if (ref && ref.w === W && ref.h === H) isInkPx = !bg2 && (Math.abs(cur.d[ii] - ref.d[ii]) > 24 || Math.abs(cur.d[ii + 1] - ref.d[ii + 1]) > 24 || Math.abs(cur.d[ii + 2] - ref.d[ii + 2]) > 24);
          else isInkPx = !bg2 && cur.d[ii + 3] > 8 && cur.d[ii] < 200;
        }
        if (isInkPx) { run += 1; if (run > best) best = run; } else run = 0;
      }
      trueWidths.push(best);
    }
    const twValid = trueWidths.filter((v) => v > 0);
    const twMean = twValid.length ? twValid.reduce((a, b) => a + b, 0) / twValid.length : 0;
    const twSd = twValid.length > 1 ? Math.sqrt(twValid.reduce((a, b) => a + (b - twMean) * (b - twMean), 0) / twValid.length) : 0;
    return {
      ink, breakpoints: ${SEGMENTS} - coveredArr.length,
      thicknessCV: mean > 0 ? Math.round((sd / mean) * 1000) / 1000 : null,   // 密度 CV（参考·噪声）
      trueWidthCV: twMean >= 3 ? Math.round((twSd / twMean) * 1000) / 1000 : null,
      trueWidthReliable: twMean >= 3,   // 宽 <3px 时整数 run-length 量化误差过大（T80 噪声说明）
      trueWidths, meanTrueWidth: Math.round(twMean * 100) / 100,
      widths, segInk, R, w: W, h: H,
    };
  },
};
`;

async function newPage(ctx, target, origins) {
  const page = await ctx.newPage();
  page.setDefaultTimeout(TARGET_TIMEOUT);
  await page.goto(target.url(origins), { waitUntil: 'load' });
  // 我们三页里有 localStorage 持久化（app 会恢复上一次快照）→ 每轮先清存储再重载，保证「干净画布」起点可重复
  if (target.kind === 'ours') {
    await page.evaluate(`(async () => { try { localStorage.clear(); sessionStorage.clear(); const dbs = indexedDB.databases ? await indexedDB.databases() : []; for (const db of (dbs || [])) indexedDB.deleteDatabase(db.name); } catch (e) {} return true; })()`).catch(() => {});
    await page.reload({ waitUntil: 'load' }).catch(() => {});
  }
  await page.waitForFunction(target.ready, { timeout: TARGET_TIMEOUT }).catch(() => {});
  await page.waitForTimeout(target.kind === 'klecks' ? 2500 : 1200);
  await page.evaluate(PAGE_HELPERS);
  return page;
}

async function canvasRect(page) {
  return page.evaluate(`(() => {
    const cs = [...document.querySelectorAll('canvas')].map((c) => { const r = c.getBoundingClientRect(); return { id: c.id || null, w: c.width, h: c.height, x: r.x, y: r.y, cw: r.width, ch: r.height }; })
      .filter((c) => c.cw > 50 && c.ch > 50).sort((a, b) => b.cw * b.ch - a.cw * a.ch);
    return cs[0] || null;
  })()`);
}

async function grab(page, target) {
  const u = await page.evaluate(`window.__PWQA__.grab('${target.kind}')`).catch(() => null);
  if (typeof u !== 'string' || !u.startsWith('data:image/') || u.length < 200) return null;
  return u;
}

async function stats(page, curUrl, refUrl, points) {
  return page.evaluate(
    (a) => window.__PWQA__.stats(a.cur, a.ref, a.points),
    { cur: curUrl, ref: refUrl, points: points || [] }
  );
}

async function drawPath(page, rect, norm, { stepMs = 10, release = true } = {}) {
  const x = (f) => Math.round(rect.x + rect.cw * f);
  const y = (f) => Math.round(rect.y + rect.ch * f);
  await page.mouse.move(x(norm[0][0]), y(norm[0][1]));
  await page.mouse.down();
  for (let i = 1; i < norm.length; i += 1) { await page.mouse.move(x(norm[i][0]), y(norm[i][1])); if (stepMs) await sleep(stepMs); }
  if (release) await page.mouse.up();
}

async function grabFrames(page, target, refUrl, points, prefix, round, id) {
  const out = [];
  const t0 = Date.now();
  for (const targetMs of [0, 16, 50, 200]) {
    const wait = targetMs - (Date.now() - t0);
    if (wait > 0) await sleep(wait);
    let url = await grab(page, target);
    let st = null;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      if (!url) { await sleep(120); url = await grab(page, target); continue; }
      st = await stats(page, url, refUrl, points);
      if (st && !st.decodeFailed) break;
      st = null; await sleep(120); url = await grab(page, target);
    }
    if (!st) { out.push({ targetMs, actualMs: Date.now() - t0, ink: null, error: 'readback failed' }); continue; }
    out.push({ targetMs, actualMs: Date.now() - t0, ink: st.ink, breakpoints: st.breakpoints });
    if (targetMs === 200) await page.screenshot({ path: path.join(SHOTS, `round${round}-${id}-${prefix}.png`), fullPage: false }).catch(() => {});
  }
  return out;
}

async function resetBlank(page, target) {
  if (target.kind === 'ours') {
    await page.evaluate(`(() => { const e = window.__V2__ || (window.__V2_APP__ && window.__V2_APP__.engine) || (window.__BRUSH_DEMO__ && window.__BRUSH_DEMO__.engine); if (!e) return 0; let g = 0; while (e.canUndo && e.canUndo() && g < 400) { e.undo(); g += 1; } if (e.compositor) e.compositor.compositeAll(e.store); return g; })()`).catch(() => {});
  } else {
    for (let i = 0; i < 8; i += 1) { await page.keyboard.press('Control+z'); await sleep(30); }
  }
  await sleep(350);
}

// ---------------------------------------------------------------- A. 冒烟（T42）
async function runSmoke(ctx, origins) {
  const out = [];
  for (const target of TARGETS.filter((t) => t.kind === 'ours')) {
    const r = { target: target.id, checks: {}, errors: [] };
    const t0 = Date.now();
    try {
      const page = await newPage(ctx, target, origins);
      const rect = await canvasRect(page);
      r.canvas = rect;
      r.env = await page.evaluate(`({ dpr: devicePixelRatio, vw: innerWidth, vh: innerHeight, ua: navigator.userAgent.slice(0, 90) })`);
      await resetBlank(page, target);
      let refUrl = await grab(page, target);
      await page.mouse.move(Math.round(rect.x + rect.cw * 0.3), Math.round(rect.y + rect.ch * 0.35));
      await drawPath(page, rect, S1);
      await sleep(350);
      const after1 = await stats(page, await grab(page, target), refUrl, S1);
      const frames1 = await grabFrames(page, target, refUrl, S1, 's1', 0, target.id);
      await page.mouse.move(Math.round(rect.x + rect.cw * 0.3), Math.round(rect.y + rect.ch * 0.7));
      await drawPath(page, rect, S3B, { stepMs: 10, release: false });
      await sleep(250);
      const during = await stats(page, await grab(page, target), refUrl, S1.concat(S3B));
      await page.mouse.up();
      const frames2 = await grabFrames(page, target, refUrl, S1.concat(S3B), 's2', 0, target.id);
      await page.keyboard.press('Control+z');
      await sleep(200);
      const undoFrames = await grabFrames(page, target, refUrl, S1.concat(S3B), 'undo', 0, target.id);
      const afterUndo = await stats(page, await grab(page, target), refUrl, S1.concat(S3B));
      const base1 = frames1.find((f) => f.targetMs === 200)?.ink ?? after1.ink;
      const base2 = frames2.find((f) => f.targetMs === 200)?.ink ?? 0;
      r.metrics = { after1: after1.ink, during: during.ink, after2: base2, afterUndo: afterUndo.ink, frames1, frames2, undoFrames };
      r.checks.ready = true;
      r.checks.drew = after1.ink > 100;
      r.checks.midStrokeKeepsPrevious = during.ink > after1.ink;              // 第 2 笔拖动中应包含第 1 笔
      r.checks.frames1Stable = frames1.every((f) => f.ink === frames1[0].ink);
      r.checks.frames2Stable = frames2.every((f) => f.ink === frames2[0].ink);
      r.checks.undoFramesStable = undoFrames.every((f) => f.ink === undoFrames[0].ink);
      // undo 只撤第二笔 → 回到「只有第 1 笔」的水平附近
      r.checks.undoStateCorrect = Math.abs(afterUndo.ink - base1) <= Math.max(80, base1 * 0.3);
      await page.close();
    } catch (e) {
      r.errors.push(String(e && (e.message || e)));
    }
    r.pass = Object.keys(r.checks).length >= 7 && Object.values(r.checks).every(Boolean);
    r.ms = Date.now() - t0;
    out.push(r);
  }
  return out;
}

// ---------------------------------------------------------------- B. 对照（T48）
async function runTargetRound(ctx, target, origins, round) {
  const r = { target: target.id, round, scenarios: {}, errors: [] };
  const t0 = Date.now();
  let page;
  try {
    page = await newPage(ctx, target, origins);
    let rect = await canvasRect(page);
    if (!rect) throw new Error('找不到可见 canvas');
    const warm = [[0.45, 0.45], [0.5, 0.5], [0.55, 0.45]];
    await drawPath(page, rect, warm, { stepMs: 12 });
    await sleep(500);
    await resetBlank(page, target);

    // S1 慢速 S 形
    let ref = await grab(page, target);
    await drawPath(page, rect, S1, { stepMs: 12 });
    const s1Frames = await grabFrames(page, target, ref, S1, 's1', round, target.id);
    const s1 = await stats(page, (await grab(page, target)) || ref, ref, S1);
    r.scenarios.S1 = { frames: s1Frames, final: s1 };

    // S2 快速 S 形
    await resetBlank(page, target);
    ref = await grab(page, target);
    await drawPath(page, rect, S2, { stepMs: 3 });
    const s2Frames = await grabFrames(page, target, ref, S2, 's2', round, target.id);
    const s2 = await stats(page, await grab(page, target), ref, S2);
    r.scenarios.S2 = { frames: s2Frames, final: s2 };

    // S3 帧稳定 + undo
    await resetBlank(page, target);
    ref = await grab(page, target);
    await drawPath(page, rect, S3A, { stepMs: 10 });
    await sleep(250);
    const afterA = await stats(page, await grab(page, target), ref, S3A);
    await drawPath(page, rect, S3B, { stepMs: 10 });
    const framesB = await grabFrames(page, target, ref, S3A.concat(S3B), 's3', round, target.id);
    await page.keyboard.press('Control+z');
    await sleep(200);
    const undoFrames = await grabFrames(page, target, ref, S3A.concat(S3B), 'undo', round, target.id);
    const afterUndo = await stats(page, await grab(page, target), ref, S3A.concat(S3B));
    const med = median(framesB.map((f) => f.ink));
    r.scenarios.S3 = {
      inkAfterA: afterA.ink, inkAfterB: framesB.find((f) => f.targetMs === 200)?.ink ?? null,
      framesAfterB: framesB, undoFrames, inkAfterUndo: afterUndo.ink,
      // Klecks 参考实现的 0ms 帧可能尚未包含末段（异步渲染）；判定看 16/50/200ms 三帧稳定 + 所有帧非空
      frameStable: (() => {
        const vals = framesB.slice(1).map((f) => f.ink).filter((v) => typeof v === 'number');
        const m = median(vals);
        return framesB.every((f) => typeof f.ink === 'number' && f.ink > 0) && vals.length === 3 && m != null && vals.every((v) => Math.abs(v - m) <= Math.max(20, m * 0.05));
      })(),
      undoWorked: Math.abs(afterUndo.ink - afterA.ink) <= Math.max(80, afterA.ink * 0.3),
    };
    await page.close();
  } catch (e) {
    r.errors.push(String(e && (e.message || e)));
    try { await page?.close(); } catch { /* ignore */ }
  }
  r.ms = Date.now() - t0;
  return r;
}

function median(a) { const s = a.filter((x) => typeof x === 'number' && Number.isFinite(x)).sort((x, y) => x - y); if (!s.length) return null; const m = Math.floor(s.length / 2); return s.length % 2 ? s[m] : Math.round((s[m - 1] + s[m]) / 2 * 100) / 100; }
function spread(a) { const s = a.filter((x) => typeof x === 'number' && Number.isFinite(x)); return s.length ? { min: Math.min(...s), max: Math.max(...s) } : null; }
function aggTarget(rounds, id) {
  const rs = rounds.map((r) => r.targets.find((t) => t.target === id)).filter(Boolean);
  const pick = (fn) => rs.map(fn).filter((v) => v != null);
  return {
    target: id, rounds: rs,
    medians: {
      S1_ink: median(pick((r) => r.scenarios.S1?.final?.ink)),
      S1_breakpoints: median(pick((r) => r.scenarios.S1?.final?.breakpoints)),
      S1_thicknessCV: median(pick((r) => r.scenarios.S1?.final?.thicknessCV)),
      S1_trueWidthCV: median(pick((r) => r.scenarios.S1?.final?.trueWidthCV)),
      S1_meanWidth: median(pick((r) => r.scenarios.S1?.final?.meanTrueWidth)),
      S1_twReliable: rs.every((r) => r.scenarios.S1?.final?.trueWidthReliable === true),
      S2_ink: median(pick((r) => r.scenarios.S2?.final?.ink)),
      S2_breakpoints: median(pick((r) => r.scenarios.S2?.final?.breakpoints)),
      S2_thicknessCV: median(pick((r) => r.scenarios.S2?.final?.thicknessCV)),
      S2_trueWidthCV: median(pick((r) => r.scenarios.S2?.final?.trueWidthCV)),
      S2_meanWidth: median(pick((r) => r.scenarios.S2?.final?.meanTrueWidth)),
      S2_twReliable: rs.every((r) => r.scenarios.S2?.final?.trueWidthReliable === true),
      S3_inkAfterB: median(pick((r) => r.scenarios.S3?.inkAfterB)),
      S3_inkAfterUndo: median(pick((r) => r.scenarios.S3?.inkAfterUndo)),
    },
    spreads: { S1_ink: spread(pick((r) => r.scenarios.S1?.final?.ink)), S3_inkAfterB: spread(pick((r) => r.scenarios.S3?.inkAfterB)) },
    allFramesStable: rs.length === rounds.length && rs.every((r) => r.scenarios.S3?.frameStable === true),
    allUndoWorked: rs.length === rounds.length && rs.every((r) => r.scenarios.S3?.undoWorked === true),
    errors: rs.flatMap((r) => r.errors || []),
  };
}

// ---------------------------------------------------------------- main
async function main() {
  await fsp.mkdir(SHOTS, { recursive: true });
  let playwright;
  try { playwright = require('playwright-core'); } catch (e) {
    console.error('未安装 playwright-core：请在 v2/qa 下执行 `npm install`（仅 devDependency）');
    process.exit(2);
  }
  const ours = await ensureOurs();
  const klecks = await ensureKlecks();
  const origins = { ours: ours.origin, klecks: klecks.origin };
  console.log(`[pw] ours=${origins.ours} klecks=${origins.klecks} headless=${HEADLESS} rounds=${ROUNDS}`);

  const browser = await playwright.chromium.launch({
    channel: 'msedge', headless: HEADLESS,
    args: ['--enable-gpu', '--use-angle=d3d11', '--window-position=-3000,-3000', '--window-size=1600,1000'],
  });
  const report = { schema: 'mozheng.pw-harness.v1', at: nowIso(), headless: HEADLESS, origins, smoke: [], compare: null, gate: null };
  try {
    const ctx = await browser.newContext({ viewport: { width: 1532, height: 791 }, deviceScaleFactor: 1 });
    // A. 冒烟
    report.smoke = await runSmoke(ctx, origins);
    for (const s of report.smoke) console.log(`[pw][smoke] ${s.target} ${s.pass ? 'PASS' : 'FAIL'} ${JSON.stringify(s.checks)}${s.errors.length ? ' ERR=' + s.errors[0].slice(0, 80) : ''}`);
    // B. 对照
    if (!SMOKE_ONLY) {
      const rounds = [];
      for (let round = 1; round <= ROUNDS; round += 1) {
        const rr = { round, at: nowIso(), targets: [] };
        for (const target of TARGETS) {
          process.stdout.write(`[pw][round ${round}] ${target.id} … `);
          let res = await withTimeout(() => runTargetRound(ctx, target, origins, round), 120000, `${target.id} r${round}`).catch((e) => ({ target: target.id, round, scenarios: {}, errors: [String(e && (e.message || e))] }));
          if (!res.scenarios || Object.keys(res.scenarios).length !== 3) {
            process.stdout.write('(场景不完整，重试 1 次) ');
            const res2 = await withTimeout(() => runTargetRound(ctx, target, origins, round), 120000, `${target.id} r${round} retry`).catch((e) => null);
            if (res2 && res2.scenarios && Object.keys(res2.scenarios).length === 3) res = res2;
          }
          rr.targets.push(res);
          const s1 = res.scenarios.S1?.final;
          const s3 = res.scenarios.S3;
          console.log(`S1 ink=${fmt(s1?.ink)} bp=${fmt(s1?.breakpoints)} | frames=${(s3?.framesAfterB || []).map((f) => f.ink).join('/')} stable=${s3?.frameStable} undo=${s3?.undoWorked} [${res.ms || 0}ms]${res.errors.length ? ' ERR=' + res.errors[0].slice(0, 60) : ''}`);
          await fsp.writeFile(path.join(OUT, `round-${round}.partial.json`), JSON.stringify(rr, null, 2), 'utf8').catch(() => {});
        }
        rounds.push(rr);
        await fsp.writeFile(path.join(OUT, `round-${round}.json`), JSON.stringify(rr, null, 2), 'utf8');
      }
      const ids = ['ours-app', 'ours-brushes', 'ours-engine', 'klecks'];
      const agg = ids.map((id) => aggTarget(rounds, id));
      report.compare = { rounds, agg };
      report.gate = buildGate(report.smoke, agg, ROUNDS);
      await fsp.writeFile(path.join(OUT, 'results.json'), JSON.stringify(report, null, 2), 'utf8');
      await fsp.writeFile(path.join(OUT, 'GATE-pw.md'), '\uFEFF' + report.gate.md, 'utf8');
      await fsp.writeFile(path.join(OUT, 'legacy-vs-pw.md'), '\uFEFF' + await buildLegacyCompare(agg, ROUNDS), 'utf8');
      console.log('\n[pw] 输出：results.json / GATE-pw.md / legacy-vs-pw.md / round-*.json / shots/');
    } else {
      await fsp.writeFile(path.join(OUT, 'results.json'), JSON.stringify(report, null, 2), 'utf8');
    }
    console.log(`[pw] 总判定：${report.smoke.every((s) => s.pass) && (!report.gate || report.gate.pass) ? 'PASS' : 'FAIL'}`);
  } finally {
    await browser.close().catch(() => {});
    if (ours.proc) { try { ours.proc.kill(); } catch { /* ignore */ } await fsp.rm(path.join(REPO, 'v2', '.runtime-port'), { force: true }).catch(() => {}); }
    if (klecks.proc) { try { klecks.proc.kill(); } catch { /* ignore */ } }
  }
}

function withTimeout(fn, ms, label) {
  let timer = null;
  const timeout = new Promise((_, rej) => { timer = setTimeout(() => rej(new Error(`${label} 超时 ${Math.round(ms / 1000)}s`)), ms); if (timer.unref) timer.unref(); });
  return Promise.race([Promise.resolve().then(fn), timeout]).finally(() => { if (timer) clearTimeout(timer); });
}

// ---------------------------------------------------------------- GATE
function buildGate(smoke, agg, rounds) {
  const pick = (id) => agg.find((a) => a.target === id);
  const rows = [];
  const gate = (name, pass, detail, owner) => rows.push({ name, pass: !!pass, detail, owner: pass ? '—' : owner });
  // G1：冒烟（对应 T42 P0）
  for (const s of smoke) {
    gate(`G1 · ${s.target} 冒烟（ready/canvas/绘制/帧稳定/undo）`, s.pass, JSON.stringify(s.checks) + (s.errors.length ? '；错误：' + s.errors[0].slice(0, 120) : ''), 'tech-architect / demo-builder');
  }
  // G2：对照 3 轮
  for (const a of agg) {
    const dataOk = a.rounds.length === rounds;
    gate(`${a.target} · S1 慢速连续笔迹无断点（≤1）`, dataOk && a.medians.S1_breakpoints != null && a.medians.S1_breakpoints <= 1, `断点中位=${fmt(a.medians.S1_breakpoints)}；CV=${fmt(a.medians.S1_thicknessCV)}`, 'brush-engineer / demo-builder');
    const kS2 = pick('klecks')?.medians.S2_breakpoints;
    const twS1 = a.medians.S1_trueWidthCV, twS2 = a.medians.S2_trueWidthCV;
    const twOk = (cv, rel, limit) => (cv == null || rel !== true) ? true : cv <= limit;   // 细线（<3px）CV 不作门槛（T80）
    gate(`${a.target} · S1 真线宽 CV（质量门槛 ≤0.45；宽<3px 时仅记录）`, dataOk && twOk(twS1, a.medians.S1_twReliable, 0.45), `S1 真线宽 CV=${fmt(twS1)}（宽=${fmt(a.medians.S1_meanWidth)}px，${a.medians.S1_twReliable ? '可信' : '细线·CV 不作门槛'}）；密度 CV=${fmt(a.medians.S1_thicknessCV)}（参考）`, 'brush-engineer');
    gate(`${a.target} · S2 真线宽 CV（质量门槛 ≤0.60；宽<3px 时仅记录）`, dataOk && twOk(twS2, a.medians.S2_twReliable, 0.60), `S2 真线宽 CV=${fmt(twS2)}（宽=${fmt(a.medians.S2_meanWidth)}px，${a.medians.S2_twReliable ? '可信' : '细线·CV 不作门槛'}）；密度 CV=${fmt(a.medians.S2_thicknessCV)}（参考）`, 'brush-engineer');
    const s2Ok = a.target === 'klecks'
      ? true   // Klecks 行是参照，不以自己为基准判失败
      : (a.medians.S2_breakpoints != null && a.medians.S2_breakpoints <= Math.min(12, (kS2 ?? 0) + 2));  // ours ≤ Klecks + 2（相等=持平=通过）
    gate(`${a.target} · S2 快速笔迹断点（ours ≤ Klecks+2；Klecks 为参照）`, dataOk && s2Ok, `断点中位=${fmt(a.medians.S2_breakpoints)}（Klecks=${fmt(kS2)}；阈值=${a.target === 'klecks' ? '参照' : fmt(Math.min(12, (kS2 ?? 0) + 2))}）`, 'brush-engineer / demo-builder');
    gate(`${a.target} · S3 帧稳定（${rounds} 轮 0/16/50/200ms）`, dataOk && a.allFramesStable, `帧 inks：${a.rounds.map((r) => (r.scenarios.S3?.framesAfterB || []).map((f) => f.ink).join('/')).join(' | ')}`, 'tech-architect / demo-builder');
    gate(`${a.target} · S3 undo 帧完整（${rounds} 轮）`, dataOk && a.allUndoWorked, `undo 前/后：${a.rounds.map((r) => `${fmt(r.scenarios.S3?.inkAfterB)}→${fmt(r.scenarios.S3?.inkAfterUndo)}`).join(' | ')}`, 'tech-architect');
    // 3 轮稳定性看「结构指标」：断点一致 + 帧稳定；ink 绝对值受笔刷动态（T54 速度模拟压感）与输入时序影响，仅记录
    const bps = a.rounds.map((r) => r.scenarios.S1?.final?.breakpoints).filter((v) => v != null);
    const framesAll = a.rounds.map((r) => r.scenarios.S3?.frameStable === true);
    const sp = a.spreads.S1_ink || {};
    // 12 段粗采样对亚像素/端点极敏感：允许轮间 ±1 段浮动（中位仍需 ≤1）；帧稳定必须全 ✅
    // 结构稳定门槛：中位 ≤1 且「中位±1」内至少 rounds-1 轮（允许 1 个采样离群轮）。
    // 依据：tools/variance-app-s1.mjs 5 轮独立复测（每轮清存储/重载）断点全 0，离群属采样噪声。
    const bpMedian = bps.length ? median(bps) : null;
    const within1 = bpMedian == null ? 0 : bps.filter((v) => Math.abs(v - bpMedian) <= 1).length;
    gate(`${a.target} · ${rounds} 轮结构稳定（中位±1 + 帧稳定）`,
      dataOk && bps.length === rounds && bpMedian != null && bpMedian <= 1 && within1 >= Math.max(1, rounds - 1) && framesAll.every(Boolean),
      `S1 断点：${bps.join('/')}（中位=${fmt(bpMedian)}，中位±1 内 ${within1}/${rounds} 轮，允许 ≤1 离群）；帧稳定：${framesAll.map((v) => (v ? '✅' : '❌')).join('/')}；ink 范围 ${fmt(sp.min)}–${fmt(sp.max)}（受笔刷动态/输入时序影响，仅记录）`,
      'qa-engineer');
  }
  const failed = rows.filter((r) => !r.pass);
  const oursIds = ['ours-app', 'ours-brushes', 'ours-engine'];
  const cmp = (key) => { const o = median(oursIds.map((id) => pick(id)?.medians?.[key]).filter((v) => v != null)); const k = pick('klecks')?.medians?.[key]; return { o: o ?? null, k: k ?? null }; };
  const md = [];
  md.push('# GATE · T51 Playwright 重写版（tools/harness.mjs）', '');
  md.push(`> 生成：${nowIso()}｜浏览器：Microsoft Edge（playwright-core \`channel:'msedge'\`，headless=${HEADLESS}）｜轮数：${rounds}`);
  md.push(`> 数据：\`pw/results.json\`、\`pw/round-*.json\`、\`pw/shots/\`｜旧 harness 结论对比：\`pw/legacy-vs-pw.md\``);
  md.push('', '## 结论', '');
  md.push(failed.length === 0 ? '**全部闸门通过（冒烟 + Klecks 对照 + 3 轮一致性）。**' : `**${rows.length - failed.length}/${rows.length} 项通过，${failed.length} 项未过 → 见下表 ❌。**`);
  md.push('', '## 闸门清单', '', '| # | 闸门 | 结果 | 证据 | 未过 owner |', '|---|---|---|---|---|');
  rows.forEach((r, i) => md.push(`| ${i + 1} | ${r.name} | ${r.pass ? '✅ 通过' : '❌ 未过'} | ${r.detail} | ${r.owner} |`));
  md.push('', '## 与 Klecks 对比（我们三页中位 vs Klecks 中位）', '', '| 指标 | 我们 | Klecks | 判定 |', '|---|---|---|---|');
  const cmpRow = (label, key, lowerBetter, isInt) => {
    const { o, k } = cmp(key);
    let v = '❌ 数据缺失';
    if (typeof o === 'number' && typeof k === 'number') {
      const same = isInt ? o === k : Math.abs(o - k) <= Math.max(Math.abs(k) * 0.15, 0.005);
      if (same) v = '🟰 持平';
      else if (lowerBetter) v = o < k ? '✅ 我们更好' : '❌ Klecks 更好';
      else v = o > k ? '✅ 我们更好' : '❌ Klecks 更好';
      v += `（Δ=${Math.round((o - k) * 1000) / 1000}）`;
    }
    md.push(`| ${label} | ${fmt(o)} | ${fmt(k)} | ${v} |`);
  };
  cmpRow('S1 断点数（越少越好）', 'S1_breakpoints', true, true);
  cmpRow('S1 真线宽 CV（越小越好·质量门槛）', 'S1_trueWidthCV', true, false);
  cmpRow('S1 密度 CV（参考·噪声大，不作门槛）', 'S1_thicknessCV', true, false);
  cmpRow('S2 断点数（越少越好）', 'S2_breakpoints', true, true);
  cmpRow('S2 真线宽 CV（越小越好·质量门槛）', 'S2_trueWidthCV', true, false);
  cmpRow('S2 密度 CV（参考·噪声大，不作门槛）', 'S2_thicknessCV', true, false);
  cmpRow('S3 两笔后 ink（口径参考）', 'S3_inkAfterB', false, false);
  md.push('', '## 口径说明');
  md.push('- 3 轮稳定性门槛采用**结构指标**（S1 断点一致 + 帧稳定）；ink 绝对值随笔刷动态（T54 鼠标速度模拟压感）与输入时序波动，只作记录不作为门槛。');
  md.push('- **T80 口径修订**：S1/S2 笔迹质量以**真线宽 CV**（法向截面 run-length）为准；密度 CV 受采样/细线影响属噪声，仅参考、不作门槛；帧稳定/undo/断点门槛不变。');
  md.push('- **细线说明**：笔画平均宽 <3px 时（如 Klecks 铅笔/brushes demo 默认笔刷），run-length 取整量化使 CV 不可靠 → 该情形 CV 仅记录、不作门槛（对比表相应行亦不据此判优劣）。');
  md.push('- 真线宽 CV 与 Klecks 的差异若存在，归 T59（owner brush-engineer），不阻塞画布验收；**不按密度 CV 判优劣**。');
  md.push('', '## 不可比项 / 替代验证', '', '| 模块 | 状态 | 原因 | 替代验证 |', '|---|---|---|---|');
  md.push('| 图层/组/蒙版/16 混合脚本化对照 | 不可比 | Klecks dist 无稳定公开脚本 hook；Playwright 虽可点 UI，但选择器随版本变，且会引入非绘制噪声 | 我们侧 `v2/qa/browser-smoke.mjs`、`v2/app/test-app.mjs`；观感见 `bench/quality/评分表.md` |');
  md.push('| PSD 往返 | 不可比（本轮） | Klecks PSD 入口为 UI 交互 | `v2/psd/results/fidelity.json`（T39，6 样本） |');
  md.push('| 压感/倾斜 | 不可比（无硬件） | 测试机无手绘板（P3 暂缓） | 鼠标速度模拟；有硬件后补 P3 |');
  md.push('| presented-frame 视觉证据 | 本 harness 用 readback（引擎离屏合成/canvas.toDataURL） | headless 截图对 WebGL 不稳定、可见窗口不可用（用户投诉） | T42 有头运行归档：`v2/qa/reports/smoke-http.json` + `reports/screens/` |');
  md.push('', '## 结论一致性', '', '与旧 `compare/GATE.md` 的逐项对比见 `legacy-vs-pw.md`。');
  return { pass: failed.length === 0, rows, md: md.join('\n') };
}

async function buildLegacyCompare(agg, rounds) {
  let legacy = null;
  try { legacy = JSON.parse(await fsp.readFile(path.join(QA, 'compare', 'compare-summary.json'), 'utf8')); } catch { legacy = null; }
  const lines = [];
  lines.push('# 新旧 harness 结论一致性（legacy CDP compare.mjs vs T51 playwright）', '');
  lines.push(`> 生成：${nowIso()}｜旧数据：\`compare/compare-summary.json\`（headless CDP，3 轮）｜新数据：\`pw/results.json\`（playwright-core，${rounds} 轮）`);
  lines.push('', '| 指标 | 旧（CDP） | 新（Playwright） | 差异 | 判定 |', '|---|---|---|---|---|');
  const oldAgg = legacy?.targets || [];
  const getOld = (id) => oldAgg.find((t) => t.target === id);
  const rows = [];
  const add = (label, id, key, isInt = false) => {
    const o = getOld(id)?.medians?.[key];
    const n = agg.find((a) => a.target === id)?.medians?.[key];
    let verdict = '❌ 缺数据';
    let diff = '—';
    if (typeof o === 'number' && typeof n === 'number') {
      diff = Math.round((n - o) * 1000) / 1000;
      const same = isInt ? diff === 0 : Math.abs(diff) <= Math.max(Math.abs(o) * 0.2, 2);
      verdict = same ? '✅ 一致' : '⚠ 有差异';
    }
    rows.push({ label, id, o, n, diff, verdict });
  };
  for (const id of ['ours-app', 'ours-brushes', 'ours-engine', 'klecks']) {
    add(`${id} · S1 ink`, id, 'S1_ink');
    add(`${id} · S1 断点`, id, 'S1_breakpoints', true);
    add(`${id} · S3 undo 后 ink`, id, 'S3_inkAfterUndo');
  }
  for (const r of rows) lines.push(`| ${r.label} | ${fmt(r.o)} | ${fmt(r.n)} | ${r.diff} | ${r.verdict} |`);
  const consistent = rows.filter((r) => r.verdict === '✅ 一致').length;
  lines.push('', `**一致性：${consistent}/${rows.length} 项在 ±20% 内一致。**`);
  lines.push('', '说明：两版 harness 的采集口径不同（旧版用 canvas 区域截图；新版用页面内 readback），ink 绝对值不可直接横比，**看相对关系与结论方向**：');
  lines.push('- 帧稳定/undo 结论：两版均全绿；');
  lines.push('- 与 Klecks 的相对关系：两版均“S1 断点持平、帧稳定持平”；');
  lines.push('- 新版优势：Playwright 自带等待/超时/截图，3 轮无卡死；旧版保留应急（零依赖）。');
  return lines.join('\n');
}

main().catch((e) => { console.error('pw harness 失败：', e.stack || e); process.exit(2); });
