// v2/app/test-demo.mjs — T82 一键演示说明卡/目标标签/控制条/结束（Playwright/msedge，硬超时）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8117;
const out = { schema: 'mozheng.app.demo-test.v1', cases: {}, errors: [] };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
let browser = null;
let errors = [];
const finish = (code = 0) => { try { fs.writeFileSync(ROOT + '\\v2\\app\\test-demo-result.json', JSON.stringify(out, null, 2), 'utf8'); } catch (e) {} process.exit(code); };
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_240s'; finish(3); }, 240000);

try {
  await new Promise((r) => setTimeout(r, 800));
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const context = await browser.newContext({ viewport: { width: 1366, height: 768 }, acceptDownloads: true });
  const page = await context.newPage();
  errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(500);
  out.cases.api = await page.evaluate(() => { const t = window.__V2_APP__.t82; const steps = t.steps(); return { count: t.stepCount(), steps: steps.map((s) => ({ title: s.title, label: s.label, desc: s.desc, duration: s.duration })) }; });

  // 启动 → 逐步标题/说明/标签（T120：20 步完整叙事版；步数从 API 读取，不写死）
  await page.click('#btnDemo');
  await page.waitForTimeout(300);
  const STEP_N = out.cases.api.count;
  const perStep = [];
  for (let i = 0; i < STEP_N; i += 1) {
    if (i > 0) { await page.click('#btnDemoNext'); await page.waitForTimeout(250); }
    perStep.push(await page.evaluate(() => {
      const t = window.__V2_APP__.t82;
      const card = document.getElementById('demoNarr');
      const sp = document.getElementById('demoSpotlight');
      const label = document.getElementById('demoSpotlightLabel');
      return {
        step: t.state().step,
        counter: document.getElementById('demoStepLabel').textContent,
        narrStep: document.getElementById('demoNarrStep').textContent,
        title: document.getElementById('demoNarrTitle').textContent,
        text: document.getElementById('demoNarrText').textContent,
        cardVisible: getComputedStyle(card).display !== 'none',
        spotlightVisible: getComputedStyle(sp).display !== 'none',
        label: label ? label.textContent : '',
      };
    }));
  }
  out.cases.steps = perStep;
  out.cases.stepsPass = perStep.every((s, i) => s.step === i && new RegExp('^(\\d+) / ' + STEP_N + '$').test(s.counter) && s.title.trim().length > 0 && s.text.trim().length > 0 && s.cardVisible && s.spotlightVisible && s.label.trim().length > 0);
  out.cases.durations = out.cases.api.steps.map((s) => s.duration);
  out.cases.totalDuration = out.cases.durations.reduce((a, b) => a + b, 0);
  out.cases.durationPass = out.cases.durations.every((d) => d >= 4200 && d <= 5000) && out.cases.totalDuration <= 120000;

  // 暂停/继续/上一步
  await page.evaluate(() => window.__V2_APP__.t82.runDemoStep(3));
  await page.waitForTimeout(200);
  await page.click('#btnDemoPause');
  const pausedAt = await page.evaluate(() => window.__V2_APP__.t82.state());
  await page.waitForTimeout(1200);
  const stillAt = await page.evaluate(() => window.__V2_APP__.t82.state());
  await page.click('#btnDemoPause');
  await page.click('#btnDemoPrev');
  await page.waitForTimeout(250);
  const prevState = await page.evaluate(() => window.__V2_APP__.t82.state());
  out.cases.pause = { pausedAt, stillAt, prevState, pass: pausedAt.paused && stillAt.step === pausedAt.step && !prevState.paused && prevState.step === 2 };

  // 接管
  await page.click('#btnDemoTakeover');
  await page.waitForTimeout(300);
  out.cases.takeover = await page.evaluate(() => { const t = window.__V2_APP__.t82; const st = t.state(); return { st, card: getComputedStyle(document.getElementById('demoNarr')).display, bar: getComputedStyle(document.getElementById('demoBar')).display }; });
  out.cases.takeoverPass = !out.cases.takeover.st.active && out.cases.takeover.st.takenOver && out.cases.takeover.card === 'none' && out.cases.takeover.bar === 'none';

  // 结束停在证据包
  await page.evaluate(() => { window.__V2_APP__.t82.startDemo(true); });
  await page.waitForTimeout(400);
  // T120：跳到「导出证据包」步（最后一步，会打开证据 modal），再 next() 触发 endDemo
  const LAST = await page.evaluate(() => window.__V2_APP__.t82.stepCount() - 1);
  await page.evaluate((i) => window.__V2_APP__.t82.runDemoStep(i), LAST);
  await page.waitForTimeout(2500);
  await page.evaluate(() => window.__V2_APP__.t82.next());
  await page.waitForTimeout(600);
  out.cases.end = await page.evaluate(() => {
    const end = document.getElementById('demoEnd');
    const ev = document.getElementById('evidenceModal');
    return {
      state: window.__V2_APP__.t82.state(),
      endVisible: getComputedStyle(end).display !== 'none',
      endText: end.textContent.replace(/\s+/g, ' ').trim(),
      evidenceOpen: !!ev && (ev.classList.contains('show') || getComputedStyle(ev).display !== 'none'),
      card: getComputedStyle(document.getElementById('demoNarr')).display,
      bar: getComputedStyle(document.getElementById('demoBar')).display,
    };
  });
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-demo-end-1920.png' });
  out.cases.endPass = out.cases.end.endVisible && /演示完成/.test(out.cases.end.endText) && /接管/.test(out.cases.end.endText) && /重播/.test(out.cases.end.endText) && out.cases.end.evidenceOpen;
  await page.click('#btnDemoEndTry');
  await page.waitForTimeout(300);
  out.cases.endTakeover = await page.evaluate(() => ({ state: window.__V2_APP__.t82.state(), end: getComputedStyle(document.getElementById('demoEnd')).display }));

  // 三档截图（第 2 步：素材库入口）
  const shots = {};
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await page.setViewportSize({ width: w, height: h });
    await page.reload();
    await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
    await page.waitForTimeout(500);
    await page.click('#btnDemo');
    await page.waitForTimeout(1300);
    await page.click('#btnDemoNext');
    await page.waitForTimeout(1500);
    await page.screenshot({ path: ROOT + '\\v2\\app\\ui-demo-' + w + '.png' });
    shots[w] = await page.evaluate(() => ({
      overX: document.documentElement.scrollWidth > innerWidth + 1,
      overY: document.documentElement.scrollHeight > innerHeight + 1,
      card: getComputedStyle(document.getElementById('demoNarr')).display,
      label: document.getElementById('demoSpotlightLabel').textContent,
      step: document.getElementById('demoStepLabel').textContent,
    }));
    await page.evaluate(() => window.__V2_APP__.t82.exitDemo());
  }
  out.cases.screenshots = shots;
  out.errors = errors.slice(0, 10);
  out.pass = {
    stepCount20: out.cases.api.count === 20,
    allSteps: out.cases.stepsPass,
    durations: out.cases.durationPass,
    pause: out.cases.pause.pass,
    takeover: out.cases.takeoverPass,
    endEvidence: out.cases.endPass,
    endTakeover: !out.cases.endTakeover.state.active && out.cases.endTakeover.end === 'none',
    screenshots: Object.values(shots).every((v) => !v.overX && !v.overY && v.card !== 'none' && v.label.trim().length > 0 && /\/ \d+$/.test(v.step)),
  };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  out.errors = errors ? errors.slice(0, 10) : [];
  console.log(JSON.stringify(out, null, 2));
} finally {
  clearTimeout(hard);
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  finish(0);
}
