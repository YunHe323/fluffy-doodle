# VERIFY · 验证与复现说明

> **诚实声明（先读）**
> 本文件列出的是**开发工作区的实测记录**与**在包内核对证据的方法**。
> **本提交包内没有重跑下面任何一条测试命令**，因此这里不附任何「本包内已跑通」的输出或结论。
> 评委可在包内逐条核对随包的结果 JSON、回归日志与彩排截图；**在无 Edge / playwright-core 的现场机器上重跑这些测试需要额外依赖**（见下）。
> 提交包内的可复现核心是「证据文件 + 复核器」，而不是「现场重跑整套浏览器自动化测试」。

---

## 1. 环境依赖总览

| 依赖 | 是否随包 | 说明 |
|---|---|---|
| Node.js（v22 验证过） | 否（系统提供） | 运行 `.mjs` 脚本与 `v2/serve.mjs` 的前提；主产品也依赖它 |
| `playwright-core` | **否** | 原位于 `v2/qa/node_modules/`，按提交规则与 `.gitignore` 排除；多数 `test-*.mjs` 通过 `../qa/node_modules/playwright-core/index.mjs` / `../node_modules/playwright-core/index.mjs` 引用它 |
| 本机 Microsoft Edge | 否（系统提供） | 脚本用 `chromium.launch({ channel: 'msedge' })` 复用系统 Edge，不下载浏览器 |
| `python -m http.server` | 否（系统提供） | 多个测试脚本 `spawn('python', ...)` 起本地静态服务 |
| 运行中的 v2 本地服务 | 否（按需启动） | `demo-preflight` / `rehearse-*` 默认打 `http://127.0.0.1:4200` |
| 真实 DashScope / Qwen key | 否 | 仅「真实模型」相关脚本需要；无 key 时产品走 Mock |

> **重要**：工作区里的测试脚本把仓库根路径写死为 `C:\Users\xiao1\Desktop\项目一`（见各脚本头部 `const ROOT = ...`）。因此在**另一台机器 / 另一个路径**下直接 `node` 这些脚本，即使补齐了 playwright-core 与 Edge，也可能因写死路径而找不到文件或把结果写到别处。现场重跑需先按实际路径调整脚本；**这正是本包把「原始结果文件」而非「重跑能力」作为证据交付的原因**。

---

## 2. 逐条命令（依赖 / 预期输出 / 证据文件 / 无依赖替代）

### 2.1 证据包第三方复核器（零依赖）

```
node v2/qa/tools/verify-evidence.mjs <inkproof-evidence.json>
```

- **依赖**：仅 Node 内置模块 + `v2/app/core/hash-chain.mjs`（已随包）。**不需要** playwright-core / Edge / 网络 / key。
- **参数**：一个 `schema: "inkproof.evidence.v1"` 的证据包 JSON。**包内没有现成的样本证据包**（`.gitignore` 排除 `inkproof-evidence.json`）；可在产品「导出证据包」后得到，或从 `v2/qa/tools/verify-evidence-integration-results.json` 看集成测试的复核结论。
- **预期输出**：`JSON.stringify({ ok, checks, errors, summary })`；`ok:true` 时退出码 0，否则 1；缺参数时打印用法并退出 2。
- **对应证据**：`v2/qa/tools/verify-evidence.mjs`、`v2/qa/tools/verify-evidence-test-results.json`、`v2/qa/tools/verify-evidence-integration-results.json`。
- **无依赖替代**：直接读上述结果 JSON 中的 `checks` / `ok` 字段。

### 2.2 路演模式端到端

```
node v2/app/test-roadshow.mjs
```

- **依赖**：playwright-core（`v2/qa/node_modules/`）+ 本机 Edge + `python http.server`（独立端口 8188）。
- **预期输出**：控制台打印结果 JSON；写 `v2/app/test-roadshow-result.json` 与 `v2/app/ui-roadshow-1920.png`。
- **对应证据**：`v2/app/test-roadshow.mjs`、`v2/app/test-roadshow-result.json`、`v2/app/rehearsal-1-brief.png` … `v2/app/rehearsal-6-evidence.png`。
- **无依赖替代**：直接读 `v2/app/test-roadshow-result.json` 的 `cases` / `pass` 字段，并看 6 张 `rehearsal-*.png`。

### 2.3 其余 `v2/app/test-*.mjs`（41 个脚本）

```
node v2/app/test-adjust-layer.mjs        # 例：非破坏调整层
node v2/app/test-save-psd.mjs            # 例：PSD 保存
node v2/app/test-ui.mjs                  # 例：UI 交互
```

- **依赖**：同 2.2（playwright-core + Edge + `python http.server`）。
- **预期输出**：各脚本写对应的 `v2/app/test-<name>-result.json`（如 `test-adjust-layer-result.json`），部分写截图。
- **对应证据**：`v2/app/test-*.mjs` 与同目录 `test-*-result.json`（41 组，共 82 个 `test-*` 系列文件）。
- **无依赖替代**：**直接读对应的 `test-*-result.json`**——这是本包为每个测试提供的可离线核对证据。

### 2.4 录屏前自检

```
node v2/qa/tools/demo-preflight.mjs
```

- **依赖**：playwright-core（`v2/qa/node_modules/`）+ 本机 Edge + **已启动的本地服务**（默认 `http://127.0.0.1:4200`，可用 `BASE` 环境变量改）；不调用 AI、不花钱。
- **预期输出**：检查 `/health`、`/api/ai/health`、预置素材 sha256、路演 UI 与徽章，打印 `mozheng.roadshow.preflight.v1` 结果。
- **对应证据**：`v2/qa/tools/demo-preflight.mjs`、`v2/qa/tools/rehearse-final-result.json`、`hackathon/彩排记录.md`。
- **无依赖替代**：读彩排结果 JSON 与 `hackathon/彩排记录.md`。

### 2.5 功能 / 性能回归

```
node v2/qa/tools/functional-regression.mjs
node v2/qa/tools/perf-regression.mjs
```

- **依赖**：playwright-core + Edge + `python http.server`（`functional-regression.mjs` 默认端口 4260+）。
- **预期输出**：`v2/qa/tools/functional-regression.json` + `functional-regression-report.md`；`perf-regression.json` 等。
- **对应证据**：`v2/qa/tools/functional-regression.json`、`v2/qa/tools/functional-regression-report.md`、`v2/qa/tools/perf-regression-report.md`、`v2/qa/tools/final-core-regression.txt`、`v2/qa/tools/extended-regression.txt`。
- **无依赖替代**：**直接读** `final-core-regression.txt` / `extended-regression.txt` 两份回归日志与上述报告 md/json。

### 2.6 真实路演彩排 / 证据集成

```
node v2/qa/tools/rehearse-roadshow-real.mjs
node v2/qa/tools/rehearse-final.mjs
node v2/qa/tools/verify-evidence-integration.mjs
```

- **依赖**：playwright-core + Edge + 运行中的本地服务（彩排脚本默认 4200）；`verify-evidence-integration.mjs` 另需 `python http.server`（端口 8145）+ 真实 app 页面。
- **预期输出**：`v2/qa/tools/rehearse-roadshow-real-result.json`、`rehearse-final-result.json`、`verify-evidence-integration-results.json`。
- **对应证据**：上述三个结果 JSON + `v2/qa/tools/qwen-real-evidence.json`（真实 Qwen 调用证据）。
- **无依赖替代**：**直接读这三个结果 JSON**；彩排画面看 `v2/app/rehearsal-*.png` 与 `hackathon/assets/roadshow-*.png`。

### 2.7 2026-11-08 整改轮新增的三项独立复核

```
node v2/qa/tools/port-hygiene.mjs                 # 零依赖、只读、可在现场直接跑
node hackathon/verify-submission.mjs --dir .     # 零依赖、只读，包根目录下运行
node v2/qa/tools/T118-fix-verification.mjs       # 需 playwright-core + Edge + python http.server
```

| 脚本 | 作用 | 依赖 | 对应证据 |
|---|---|---|---|
| `port-hygiene.mjs` | 扫描本地 4200–4210 所有可达端口，逐个请求 `.ai-config.json` / `.ai-token` / `.runtime-port` / `backups/` / 压缩包等敏感路径；泄露即退出码 1。**不启停服务、不打印密钥明文** | **仅 Node 内置模块，可现场直接复验** | `v2/qa/tools/port-hygiene-result.json`（实测 4200 / 4210 各 10/10 阻断、0 泄露） |
| `verify-submission.mjs` | 只读核对提交包：密钥 / 完整度 / README 宣称→证据 / 死链 / 许可 / 口径 / 旧材料 / 用户验证诚信 | **仅 Node 内置模块** | `VERIFY-RESULT.json`（PASS=6 / WARN=2 / FAIL=0 / exit 0） |
| `T118-fix-verification.mjs` | 真实浏览器内注入 3 条合成 + 2 条真实事件，验证演示事件不进正式 `events[]`、链自洽、AI 统计只计真实事件、静态路由阻断 | playwright-core + Edge + `python http.server` | `v2/qa/tools/T118-fix-verification-result.json`（13/13 PASS） |

> **为什么需要 `port-hygiene`**：P0-1 是代码层修复，而 Node 进程把模块载入内存后不会热更新。整改中实测发现 4201 端口仍是整改前启动的旧实例并继续返回 200，已停止该进程。只改磁盘代码、不查运行期端口，等于没修完。该脚本已用「刻意泄露假密钥」的负例验证能正确报警（子进程 exit=1）。
>
> **关于 T117 的 7 个失败断言**：`v2/qa/tools/T117-mask-qa-result.json` 为 48 项 41 PASS / 7 FAIL / 0 error。D5 与 F1/F2/F3/F5 是原脚本「缺陷仍存在」前提失效导致的**非回归失败**，G2/G3 是 4096² 性能**真实未达标**（已降级 P2 已知限制）。**本轮未修改任何断言凑通过**，原脚本与结果 JSON 均可复核。

### 2.8 产品运行（非测试）

```
双击 v2/start.bat        # 需要 Node；会写 v2/.runtime-port 并自动打开正确地址
直接打开 hackathon/demo/index.html    # 零依赖：仅需浏览器，可断网
```

- **依赖**：`start.bat` 需要 Node（找不到时尝试 `D:\nodejs\node.exe`）；`hackathon/demo/index.html` **无需 Node、无需联网**。
- **预期**：`start.bat` 的黑窗口打印实际端口并自动打开产品页；`demo/index.html` 是单文件降级演示，可离线直接打开（B 计划）。
- **对应证据**：`v2/start.bat`、`v2/serve.mjs`、`hackathon/demo/index.html`、`hackathon/demo/README.md`。
- **无 Node 替代**：直接打开 `hackathon/demo/index.html`。

---

## 3. 包内证据文件清单（可离线直接核对）

```
v2/qa/tools/final-core-regression.txt          核心回归日志
v2/qa/tools/extended-regression.txt            扩展回归日志
v2/qa/tools/functional-regression.json         功能回归结果
v2/qa/tools/functional-regression-report.md    功能回归报告
v2/qa/tools/perf-regression-report.md          性能回归报告
v2/qa/tools/qwen-real-evidence.json            真实 Qwen 调用证据
v2/qa/tools/rehearse-final-result.json         最终彩排结果
v2/qa/tools/rehearse-roadshow-real-result.json 真实路演彩排结果
v2/qa/tools/verify-evidence-integration-results.json   证据复核集成结果
v2/qa/tools/verify-evidence-test-results.json  复核器自测结果
v2/qa/tools/verify-evidence.mjs                证据包复核器（零依赖）
v2/qa/tools/port-hygiene.mjs                   运行期敏感路径黑盒自检（零依赖）
v2/qa/tools/port-hygiene-result.json           端口自检结果（0 泄露）
v2/qa/tools/T118-fix-verification.mjs          整改轮独立回归（13 项）
v2/qa/tools/T118-fix-verification-result.json  T118 结果（13/13 PASS）
v2/qa/tools/T117-mask-qa.mjs                   T117 48 项 QA（原脚本未改）
v2/qa/tools/T117-mask-qa-result.json           T117 结果（41 PASS / 7 FAIL）
hackathon/verify-submission.mjs                提交包只读验证器（零依赖）
VERIFY-RESULT.json                             提交包验证结果（FAIL=0）
v2/qa/tools/*.mjs                              全部 QA 脚本
v2/qa/tools/*result*.json                      全部结果 JSON
v2/qa/tools/T1xx-final-qa.md                   各阶段收口 QA 记录
v2/qa/tools/shots/t117-*.png                   T117 关键截图
v2/app/test-*.mjs                              41 个端到端测试脚本
v2/app/test-*-result.json                      41 个对应结果 JSON
v2/app/rehearsal-1-brief.png … rehearsal-6-evidence.png   彩排 6 拍截图
hackathon/assets/roadshow-*.png                路演截图
hackathon/demo/index.html                      断网降级单文件演示
THIRD_PARTY_NOTICES.md                         第三方许可索引
LICENSE                                        项目自身 MIT 许可
```

---

## 4. 密钥与隐私

- `package-submission.mjs` 复制完成后会扫描包内：是否含 `.ai-config.json` / `.ai-token`，以及任何含 `apiKey` / `secretKey` / `Authorization: Bearer` **明文值**的文件；命中即以退出码 1 阻断，且**只报告文件名与行号，不打印密钥值**。
- 扫描针对「赋值形态的值」，不针对标识符本身——`v2/serve.mjs` 源码里出现 `apiKey` 标识符、以及测试脚本里的占位 token（如 `qwen-test-key-never-frontend`）均属正常，不会被当作命中。
- `.gitignore` 排除 `v2/.ai-config.json`、`v2/.ai-token`、`v2/.runtime-port`、`*.mp4`、`*.log`、`node_modules/`。

---

## 5. 结论口径

- 证据链是**本地事件完整性校验链**：无签名、无第三方时间戳、无外部锚定，**不能抵御蓄意改写**，`manifest.attest` 不在链上，**不是法律鉴定，也不构成「没用 AI」的证明**。
- 本包只保证「证据文件真实随包、可离线核对」，**不保证**在无 Edge / playwright-core 的现场机器上重跑整套浏览器测试；但 `port-hygiene.mjs`、`verify-submission.mjs`、`verify-evidence.mjs` 三个零依赖工具可在仅装有 Node 的机器上直接运行。
- 本包**不宣称** T117 48/48 通过，也不宣称「P0/P1 全部清零」：两条 P0 与四个功能 P1 已修复，4096² 性能项仍为已知限制；真实用户验证仍为空白模板，未由 AI 代填。
- 内部严格评审与整改台账（`评审报告_黑客松严格审核_2026-11-08.md`、`06-技术/整改记录_2026-11-08.md`、`06-技术/最终复评报告_2026-11-08.md`）属工作区内部材料，**不随提交包**。
