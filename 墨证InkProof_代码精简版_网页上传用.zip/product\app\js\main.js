// product/app/js/main.js
// 启动与编排：初始化 IndexedDB / 画布 / 图层 / 档案 / 证据 / UI，加载项目，自动保存，注册动作，接一键演示。
import {
  state, emit, on, $, uid, nowIso, toast, setStatusHint, setSaveState, sleep, call, register,
  downloadBlob, fileStamp, canvasToArrayBuffer, APP_VERSION
} from './state.js';
import * as db from './db.js';
import {
  initCanvas, makeLayer, deserializeLayer, serializeLayer, renderAll, pushHistory,
  makeActionHistory, findLayer, markLayerDirty, markProjectDirty, undoAction, redoAction,
  activeLayer, setTool, setColor, setSize
} from './canvas.js';
import { initLayers, renderLayerList } from './layers.js';
import { initArchive, recordL0 } from './archive.js';
import {
  initEvidence, loadTimeline, logEvent, flushEventQueue, sha256Hex, openEvidenceModal, buildEvidencePackage
} from './evidence.js';
import {
  initUI, renderAiPanel, updateStatusBar, showOnboarding, hideOnboarding, setAiClientInfo, flashLayerRow
} from './ui.js';
import {
  askAi, decideObservation, selectDirection, generateProposals, previewProposal,
  acceptProposal, setMode, revealObservations
} from './ui.js';
import { paintNightSky, paintMountains, paintMistAndDetails } from './example.js';
import { initDemo, startDemo } from './demo.js';
import { MOCK_MODEL } from './ai-client.js';

let flushTimer = null;
let flushPromise = Promise.resolve();

/* ============================ 启动 ============================ */
async function main() {
  try {
    await db.openDB();
  } catch (e) {
    console.error('[boot] IndexedDB 不可用', e);
    toast('浏览器 IndexedDB 不可用：本次操作不会被保存', 'warn', 5000);
  }
  initCanvas();
  initLayers();
  await initArchive();
  await initEvidence();
  initUI();
  setAiClientInfo(`本地 MockAI（${MOCK_MODEL}）`);
  registerAppActions();
  bindPersistence();
  await bootProject();
  register('app.startDemo', startDemo);
  initDemo(demoActions);
  window.__INKPROOF_READY__ = true;
  window.__INKPROOF__ = {
    version: APP_VERSION,
    state,
    db,
    actions: {
      startDemo, askAi, decideObservation, selectDirection, generateProposals,
      previewProposal, acceptProposal, setMode, openEvidenceModal, buildEvidencePackage
    }
  };
  pingHealth();
  const onboarded = await db.loadMeta('onboardingDone').catch(() => null);
  if (!onboarded) showOnboarding();
  console.info('[inkproof] ready · local-first · mock AI · v' + APP_VERSION);
}

async function bootProject() {
  let lastId = null;
  try { lastId = await db.loadMeta('lastProjectId'); } catch (e) { /* ignore */ }
  if (lastId) {
    const ok = await loadProject(lastId);
    if (ok) return;
  }
  // 没有历史项目：用内置示例项目作为首次体验（保存到本地）
  await buildExampleProject({ persist: true });
}

/* ============================ 项目构建 / 载入 ============================ */
function resetSessionState() {
  state.layers = [];
  state.activeLayerId = null;
  state.archive = [];
  state.decisions = [];
  state.events = [];
  state.generations = [];
  state.observations = [];
  state.directions = [];
  state.observationsReveal = null;
  state.proposals = [];
  state.selectedDirectionId = null;
  state.previewProposalId = null;
  state.committedProposalId = null;
  state.aiReview = null;
  state.aiBusy = false;
  state.generating = false;
  state.ignoreArchive = false;
  state.undoStack = [];
  state.redoStack = [];
  state.strokeCount = 0;
  state.stroke = null;
  state.drag = null;
  state.selection = null;
  state.highlightObsId = null;
  state.hoverObsId = null;
  state.dirtyLayers.clear();
  state.mode = 'collab';
  state.aiRole = 'assistant';
  state.modeStartedAt = nowIso();
  try { const m = document.querySelector('.modal-mask.open'); if (m) m.classList.remove('open'); } catch (e) { /* ignore */ }
}

/** 用代码生成示例作品（3 图层），可指定是否落库（演示沙箱用 persist=false） */
export async function buildExampleProject({ persist = true, name = '《雾中山谷》' } = {}) {
  resetSessionState();
  state.projectId = uid('project');
  state.projectName = name;
  state.projectCreatedAt = nowIso();
  state.sessionId = uid('s');
  await loadTimeline([]);

  const sky = makeLayer('底图 · 夜空与月', 'base');
  paintNightSky(sky.ctx);
  const mountain = makeLayer('图层 · 远山', 'user');
  paintMountains(mountain.ctx);
  const detail = makeLayer('细节 · 雾与灯', 'user');
  paintMistAndDetails(detail.ctx);
  state.layers = [sky, mountain, detail];
  state.activeLayerId = detail.id;
  state.selection = { x: 300, y: 430, w: 440, h: 250 };
  setTool('brush-hard');
  setColor(state.color);
  setSize(state.size);

  logEvent('project_created', { name, source: 'builtin_example', layers: 3 });
  await flushEventQueue();
  // L0 原件记录（示例作品为代码绘制，仍记录一张可校验的画布指纹）
  try {
    const buf = await canvasToArrayBuffer(sky.canvas);
    recordL0({
      filePath: `inline://example/${state.projectId}`,
      sha256: await sha256Hex(buf),
      format: 'png',
      width: 1200,
      height: 800,
      importedAt: nowIso()
    });
  } catch (e) { console.warn('[boot] L0 记录失败', e); }

  if (persist) {
    await saveAllLayers();
    await db.saveProjectMeta();
  }
  renderAll();
  renderLayerList();
  renderAiPanel();
  updateStatusBar();
  emit('project:loaded', state.projectId);
  return state.projectId;
}

export async function loadProject(projectId) {
  const projects = await db.listProjects().catch(() => []);
  const project = projects.find((p) => p.id === projectId) || projects[0];
  if (!project) return false;
  resetSessionState();
  state.projectId = project.id;
  state.projectName = project.name || '未命名作品';
  state.projectCreatedAt = project.createdAt || nowIso();
  state.sessionId = 's-' + project.id;
  state.mode = project.mode === 'attest' ? 'attest' : 'collab';
  state.aiRole = project.aiRole === 'tool' ? 'tool' : 'assistant';
  state.modeStartedAt = project.modeStartedAt || nowIso();
  state.strokeCount = project.strokeCount || 0;
  state.selection = project.selection || null;

  const layerRecords = await db.loadLayerRecords(project.id).catch(() => []);
  const order = Array.isArray(project.layerOrder) ? project.layerOrder : [];
  const byId = new Map(layerRecords.map((r) => [r.id, r]));
  const ordered = [];
  for (const id of order) if (byId.has(id)) { ordered.push(byId.get(id)); byId.delete(id); }
  for (const r of byId.values()) ordered.push(r);
  const layers = [];
  for (const rec of ordered) {
    try { layers.push(await deserializeLayer(rec)); } catch (e) { console.warn('[load] 图层恢复失败', rec.id, e); }
  }
  state.layers = layers;
  state.activeLayerId = layers.find((l) => l.id === project.activeLayerId) ? project.activeLayerId : (layers[layers.length - 1]?.id || null);
  state.archive = await db.loadArchiveRecords(project.id).catch(() => []);
  state.decisions = state.archive.filter((r) => r.layer === 'L5');
  state.generations = await db.loadGenerationRecords(project.id).catch(() => []);
  state.events = await db.loadEventRecords(project.id).catch(() => []);
  await loadTimeline(state.events);

  document.querySelectorAll('.mode-opt').forEach((btn) => btn.classList.toggle('active', btn.dataset.mode === state.mode));
  renderAll();
  renderLayerList();
  renderAiPanel();
  updateStatusBar();
  emit('project:loaded', project.id);
  return true;
}

/* ============================ 持久化 ============================ */
async function saveAllLayers() {
  if (!state.projectId) return;
  for (let i = 0; i < state.layers.length; i += 1) {
    const rec = await serializeLayer(state.layers[i], i);
    await db.saveLayerRecord(rec);
  }
  state.dirtyLayers.clear();
}

function bindPersistence() {
  // 把 UI / 画布 emit 的 'log' 事件统一写入哈希链（证据链）
  on('log', (ev) => {
    if (!ev || !ev.type) return;
    logEvent(ev.type, ev.payload || {}, { actor: ev.actor });
  });
  on('persist:project', () => scheduleFlush(600));
  on('persist:layer', (layerId) => {
    if (layerId) state.dirtyLayers.add(layerId);
    scheduleFlush(700);
  });
  on('layer:deleted', (layerId) => {
    state.dirtyLayers.delete(layerId);
    db.deleteLayerRecord(layerId).catch((e) => console.warn('[db] 删除图层失败', e));
    scheduleFlush(400);
  });
  window.addEventListener('beforeunload', () => {
    flushEventQueue().catch(() => {});
    db.saveProjectMeta().catch(() => {});
  });
}
function scheduleFlush(delay = 700) {
  if (!state.projectId || state.persistencePaused) return;
  clearTimeout(flushTimer);
  flushTimer = setTimeout(() => { flushSave().catch(() => {}); }, delay);
}
async function flushSave() {
  if (!state.projectId || state.persistencePaused) return;
  flushPromise = flushPromise.then(async () => {
    setSaveState('saving', '保存中…');
    try {
      await db.saveProjectMeta();
      for (const layerId of [...state.dirtyLayers]) {
        const layer = findLayer(layerId);
        if (layer) await db.saveLayerRecord(await serializeLayer(layer, state.layers.indexOf(layer)));
        state.dirtyLayers.delete(layerId);
      }
      setSaveState('saved', '已保存 ' + new Date().toLocaleTimeString('zh-CN', { hour12: false }));
      emit('save:changed', { kind: 'saved' });
    } catch (e) {
      console.error('[save] 失败', e);
      setSaveState('error', '保存失败');
      emit('save:changed', { kind: 'error' });
    }
  });
  return flushPromise;
}

/* ============================ 动作注册（供 UI 调用） ============================ */
async function loadExample() {
  await flushSave();
  await buildExampleProject({ persist: true });
  toast('示例作品已加载（代码绘制，可自由修改）', 'ok');
  setStatusHint('示例作品已载入 · 已自动框选区域 · 点「让 AI 看看」（K）');
}

async function importLocalImage(file) {
  try {
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
    const img = await new Promise((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('图片解码失败'));
      el.src = dataUrl;
    });
    const shortName = file.name.length > 16 ? file.name.slice(0, 14) + '…' : file.name;
    const layer = makeLayer('导入 · ' + shortName, 'user');
    const scale = Math.min(1200 / img.width, 800 / img.height);
    const w = img.width * scale;
    const h = img.height * scale;
    layer.ctx.drawImage(img, (1200 - w) / 2, (800 - h) / 2, w, h);
    state.layers.push(layer);
    state.activeLayerId = layer.id;
    pushHistory(makeActionHistory(
      () => { state.layers = state.layers.filter((l) => l.id !== layer.id); renderAll(); emit('layers:changed'); },
      () => { state.layers.push(layer); state.activeLayerId = layer.id; renderAll(); emit('layers:changed'); },
      '导入图片'
    ));
    logEvent('image_imported', { file_name: file.name, file_size: file.size, image: { width: img.width, height: img.height }, layer_id: layer.id, local_only: true });
    renderAll();
    renderLayerList();
    markLayerDirty(layer.id);
    markProjectDirty();
    toast('图片已导入为新图层（本地读取，不上传）', 'ok');
  } catch (e) {
    console.error(e);
    toast('图片导入失败：' + e.message, 'warn');
  }
}

async function exportProject() {
  await flushEventQueue();
  await flushSave();
  try {
    const json = await db.exportProjectJson();
    const safeName = (state.projectName || '项目').replace(/[《》\s/\\:*?"<>|]/g, '');
    downloadBlob(`InkProof_项目_${safeName}_${fileStamp()}.json`, new Blob([JSON.stringify(json, null, 2)], { type: 'application/json;charset=utf-8' }));
    await logEvent('project_exported', { format: 'json', layers: json.layers.length, archive_records: json.archive_records.length, events: json.events.length });
    toast('项目 JSON 已导出（含图层、档案、事件链）', 'ok', 3200);
  } catch (e) {
    console.error(e);
    toast('导出项目失败：' + e.message, 'warn');
  }
}

async function importProject(file) {
  try {
    const text = await file.text();
    let json;
    try { json = JSON.parse(text); } catch (e) { toast('项目文件不是合法 JSON', 'warn'); return; }
    if (!confirm('导入项目会覆盖当前本地数据（建议先导出备份）。继续？')) return;
    await db.importProjectJson(json);
    const last = await db.loadMeta('lastProjectId');
    if (last) await loadProject(last);
    toast('项目已导入（图层 / 档案 / 事件链已恢复）', 'ok', 3400);
  } catch (e) {
    console.error(e);
    toast('导入项目失败：' + e.message, 'warn', 4000);
  }
}

async function clearLocalData() {
  try {
    await db.clearAllData();
    toast('本地数据已清空，即将刷新页面', 'ok');
    setTimeout(() => location.reload(), 800);
  } catch (e) {
    toast('清空失败：' + e.message, 'warn');
  }
}

function registerAppActions() {
  register('canvas.undo', undoAction);
  register('canvas.redo', redoAction);
  register('app.loadExample', loadExample);
  register('app.importImage', importLocalImage);
  register('app.exportProject', exportProject);
  register('app.importProject', importProject);
  register('app.clearLocalData', clearLocalData);
  register('app.saveNow', flushSave);
  register('app.loadProject', loadProject);
}

/* ============================ 一键演示：沙箱与恢复 ============================ */
let sandboxUserProjectId = null;
const demoActions = {
  async beginSandbox() {
    await flushSave();
    sandboxUserProjectId = state.projectId;
    state.persistencePaused = true;
    await buildExampleProject({ persist: false });
  },
  async takeOverSandbox() {
    state.persistencePaused = false;
    // 演示期间不写库；用户点「自己试试」后，将当前演示场景完整落库（示例项目独立保存）
    for (const ev of state.events) await db.saveEventRecord(ev).catch(() => {});
    for (const g of state.generations) await db.saveGenerationRecord(g).catch(() => {});
    for (const rec of state.archive) await db.saveArchiveRecord(rec).catch(() => {});
    await saveAllLayers();
    await flushSave();
  },
  async restoreSandbox() {
    state.persistencePaused = false;
    let lastId = null;
    try { lastId = await db.loadMeta('lastProjectId'); } catch (e) { /* ignore */ }
    if (lastId && lastId !== state.projectId) {
      await loadProject(lastId);
      return;
    }
    if (sandboxUserProjectId) await loadProject(sandboxUserProjectId);
  },
  closeModal(id) { const m = $(id); if (m) m.classList.remove('open'); },
  askAi, decideObservation, selectDirection, generateProposals, previewProposal, acceptProposal,
  setMode, revealObservations, openEvidenceModal, flashLayerRow
};

/* ============================ 本地服务健康检查（可选） ============================ */
async function pingHealth() {
  const el = $('statusMock');
  if (!el) return;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 1500);
    const resp = await fetch('/api/health', { signal: controller.signal });
    clearTimeout(timer);
    if (resp.ok) {
      const json = await resp.json();
      el.textContent = `本地服务已连接（${json.mode || 'mock'}）· 无外部网络请求`;
    } else {
      el.textContent = '本地服务异常 · 本地 Mock 模式可用';
    }
  } catch (e) {
    el.textContent = '本地服务未启动 · 本地 Mock 模式可用（数据在本地）';
  }
}

main().catch((e) => {
  console.error('[inkproof] 启动失败', e);
  const el = $('statusHint');
  if (el) el.textContent = '启动失败：' + e.message;
});
