// product/app/js/archive.js
// 七层素材档案（MVP：L0/L1/L2/L4/L5 + 最小 L6）：记录创建、确认/否决、持久化、档案弹层。
// 对齐：product/CONTRACT.md §3 / product/core/archive-schema.mjs v0.2.0（若可用则逐条校验）。
import { state, emit, on, $, uid, nowIso, escapeHtml, toast, register, SCHEMA_VERSION } from './state.js';
import { saveArchiveRecord } from './db.js';

let validateArchiveRecord = null;
export let SCHEMA_READY = false;

/** 尝试加载共享 schema（/core 由本地服务挂载；离线打开时降级为不校验） */
export async function initArchive() {
  try {
    const core = await import('/core/archive-schema.mjs');
    if (core && typeof core.validateArchiveRecord === 'function') {
      validateArchiveRecord = core.validateArchiveRecord;
      SCHEMA_READY = true;
    }
  } catch (e) {
    SCHEMA_READY = false;
    console.info('[archive] /core/archive-schema.mjs 不可用，跳过 schema 校验（不影响本地使用）');
  }
  register('archive.recordDeleteAiLayer', recordDeleteAiLayer);
  on('project:loaded', () => { state.decisions = state.archive.filter((r) => r.layer === 'L5'); });
}

/* ---------------- 记录工厂 ---------------- */
function common(layer, anchor, source, author, extra = {}) {
  return {
    id: `${layer}-${uid('a')}`.replace(/^L(\d)-a-/, 'L$1-a-'),
    asset_id: state.projectId,
    layer,
    anchor,
    source,
    author,
    mode: state.mode,
    ai_role: state.aiRole,
    created_at: nowIso(),
    schema_version: SCHEMA_VERSION,
    ...extra
  };
}

function persist(record) {
  state.archive.push(record);
  if (record.layer === 'L5') state.decisions.push(record);
  const result = validateArchiveRecord ? validateArchiveRecord(record) : { ok: true, errors: [] };
  if (!result.ok) {
    console.warn(`[archive] ${record.layer} 记录未通过 schema 校验（已保存，开发期提示）`, record.id, result.errors);
  }
  if (!state.persistencePaused) saveArchiveRecord(record).catch((e) => console.warn('[archive] 持久化失败', e));
  emit('archive:changed');
  return record;
}

/* ---------------- L0：原件 ---------------- */
export function recordL0({ filePath, sha256, format = 'png', width, height, colorSpace = 'sRGB', importedAt }) {
  const record = common('L0', { type: 'whole', value: null }, 'observed', 'user', {
    file_path: filePath || `project/${state.projectId}.png`,
    sha256,
    format,
    width,
    height,
    color_space: colorSpace,
    imported_at: importedAt || nowIso(),
    consent: { allow_training: false, allow_ai_processing: true, allow_display: false }
  });
  return persist(record);
}

/* ---------------- L1 / L2 / L4：mock 反解结果 ---------------- */
export function recordAnalyzeResult(analyze, selection) {
  const g = analyze.global || {};
  const l1 = persist(common('L1', { type: 'whole', value: null }, 'inferred', 'ai', {
    subject: Array.isArray(g.subject) ? g.subject : [],
    scene: g.summary || '未命名场景',
    medium: g.medium && g.medium.kind ? g.medium : { kind: 'digital_painting', detail: '未识别' },
    palette: (g.palette || []).map((c) => ({ hex: String(c.hex).toLowerCase(), weight: c.weight ?? null })),
    mood: Array.isArray(g.mood) ? g.mood : [],
    composition: { type: 'custom', notes: 'mock 反解（本地规则）' },
    confidence: analyze.confidence ?? 0.6,
    model_version: analyze.model || 'mock-ai@0.1.0'
  }));
  const regions = (analyze.regions || []).map((r) => persist(common('L2', { type: 'bbox', value: r.bbox }, 'inferred', 'ai', {
    label: r.label,
    crop_path: `inline/${r.id}`,
    bbox: r.bbox,
    importance: r.importance ?? 0.5,
    local_observation_refs: [],
    confidence: r.confidence ?? 0.6,
    model_version: analyze.model || 'mock-ai@0.1.0'
  })));
  const observations = (analyze.observations || []).map((o, i) => persist(common('L4', { type: 'bbox', value: o.anchor.value }, 'inferred', 'ai', {
    kind: o.kind || 'observation',
    text: o.text,
    evidence_refs: o.evidenceRefs || (regions[0] ? [regions[0].id] : []),
    confidence: o.confidence ?? 0.6,
    model_version: o.modelVersion || analyze.model || 'mock-ai@0.1.0',
    anchor_bbox: o.anchor.value,
    display_index: i + 1
  })));
  return { l1, regions, observations };
}

/* ---------------- L5：用户决策（确认 / 否决 / 接受 / 删除） ---------------- */
function l5(anchor, kind, extra = {}) {
  return common('L5', anchor, 'observed', 'user', {
    kind,
    session_id: state.sessionId,
    created_by: 'user',
    ai_role: state.aiRole,
    created_at: nowIso(),
    ...extra
  });
}

export function confirmObservation(record, observation) {
  const bbox = observation.anchorRect
    ? [Math.round(observation.anchorRect.x), Math.round(observation.anchorRect.y), Math.round(observation.anchorRect.w), Math.round(observation.anchorRect.h)]
    : (record.anchor.value || null);
  if (record.layer === 'L1') {
    // 确认的是 L1 全局档案：生成 user-confirmed 的新版本（保留 AI 原版本可追溯）
    persist(common('L1', { type: 'whole', value: null }, 'user-confirmed', 'user', {
      subject: record.subject || [],
      scene: record.scene || '',
      medium: record.medium || { kind: 'digital_painting', detail: '未识别' },
      palette: record.palette || [],
      mood: record.mood || [],
      composition: record.composition || { type: 'custom', notes: '' },
      confidence: null,
      model_version: record.model_version || null,
      supersedes: record.id
    }));
  } else {
    // 确认的是 L4 观察：生成 user-confirmed 的新版本 L4（旧 inferred 记录保留）
    persist(common('L4', { type: 'bbox', value: bbox }, 'user-confirmed', 'user', {
      kind: record.kind || 'observation',
      text: observation.text || record.text,
      confidence: null,
      evidence_refs: record.evidence_refs || observation.evidenceRefs || [],
      supersedes: record.id,
      model_version: record.model_version || null
    }));
  }
  persist(l5({ type: 'bbox', value: bbox }, 'keep', {
    target_ref: record.id,
    note: `确认${record.layer === 'L1' ? '全局档案' : '观察'}「${String(observation.text || record.text || '').slice(0, 24)}」`
  }));
  toast('已确认 · 写回档案（user-confirmed 新版本 + L5 决策）', 'ok');
}

export function rejectObservation(record, observation) {
  const bbox = observation.anchorRect
    ? [Math.round(observation.anchorRect.x), Math.round(observation.anchorRect.y), Math.round(observation.anchorRect.w), Math.round(observation.anchorRect.h)]
    : (record.anchor.value || null);
  persist(l5({ type: 'bbox', value: bbox }, 'reject_ai', {
    target_ref: record.id,
    note: `否决观察「${String(record.text).slice(0, 24)}」`,
    rationale: '用户点「不对」（未填理由）'
  }));
  toast('已记录否决 · 后续生成会排除这条', 'warn');
}

export function revertObservation(record, observation, decision) {
  const bbox = observation.anchorRect
    ? [Math.round(observation.anchorRect.x), Math.round(observation.anchorRect.y), Math.round(observation.anchorRect.w), Math.round(observation.anchorRect.h)]
    : (record.anchor.value || null);
  persist(l5({ type: 'bbox', value: bbox }, 'keep', {
    target_ref: record.id,
    note: `撤销${decision === 'confirmed' ? '确认' : '否决'}（保留原决策记录）`,
    revert_of: state.decisions.length ? state.decisions[state.decisions.length - 1].id : null
  }));
  toast('已撤销这条决定（历史决策仍保留）');
}

export function recordAcceptAi(layer, proposal, directionTitle) {
  persist(l5({ type: 'bbox', value: layer.bbox ? [Math.round(layer.bbox.x), Math.round(layer.bbox.y), Math.round(layer.bbox.w), Math.round(layer.bbox.h)] : null }, 'accept_ai', {
    target_ref: layer.id,
    note: `接受 AI 方案「${directionTitle || proposal.title || proposal.id}」并落为新图层`,
    generation_id: proposal.generationId || null
  }));
}

export function recordDeleteAiLayer(layer) {
  persist(l5({ type: 'bbox', value: layer.bbox ? [Math.round(layer.bbox.x), Math.round(layer.bbox.y), Math.round(layer.bbox.w), Math.round(layer.bbox.h)] : null }, 'delete', {
    target_ref: layer.id,
    note: `删除 AI 图层「${layer.name}」`
  }));
}

/* ---------------- 查询 ---------------- */
export function recordsByLayer(layer) {
  return state.archive.filter((r) => r.layer === layer);
}
export function getArchiveStats() {
  const by = {};
  for (const r of state.archive) by[r.layer] = (by[r.layer] || 0) + 1;
  return by;
}

/* ---------------- 档案弹层 ---------------- */
let activeTab = 'all';
export function openArchiveModal() {
  renderArchiveBody();
  $('archiveModal').classList.add('open');
}
export function renderArchiveBody() {
  const body = $('archiveBody');
  if (!body) return;
  const stats = getArchiveStats();
  const tabs = ['all', 'L0', 'L1', 'L2', 'L4', 'L5', 'L6'];
  const rows = state.archive
    .filter((r) => activeTab === 'all' || r.layer === activeTab)
    .slice()
    .sort((a, b) => String(a.created_at).localeCompare(String(b.created_at)));
  const tabHtml = tabs.map((t) => `<button class="archive-tab ${activeTab === t ? 'active' : ''}" data-arch-tab="${t}">${t === 'all' ? '全部' : t}<span style="color:#64748b"> ${t === 'all' ? state.archive.length : (stats[t] || 0)}</span></button>`).join('');
  const sourceBadge = (s) => {
    const map = { observed: ['可见', 'observed'], inferred: ['AI 推断', 'inferred'], 'user-confirmed': ['你确认', 'user-confirmed'] };
    const [label, cls] = map[s] || [s, 'observed'];
    return `<span class="src-badge ${cls}">${label}</span>`;
  };
  const rowHtml = rows.length ? rows.map((r) => {
    const meta = [];
    if (r.confidence != null) meta.push(`置信度 ${Math.round(r.confidence * 100)}%`);
    if (r.model_version) meta.push(r.model_version);
    if (r.kind) meta.push(`kind: ${r.kind}`);
    meta.push(fmtIso(r.created_at));
    if (r.supersedes) meta.push(`supersedes ${r.supersedes}`);
    return `<div class="archive-row">
      <div><span class="layer-tag ${r.layer}">${r.layer}</span>${sourceBadge(r.source)} <b style="color:#dbeafe">${escapeHtml(r.label || r.text || r.note || r.file_path || r.kind || r.id)}</b></div>
      ${r.text && r.label ? `<div style="color:#a9bfdc;font-size:11.5px;margin-top:3px">${escapeHtml(r.text)}</div>` : ''}
      <div class="meta">${meta.map((m) => `<span>${escapeHtml(m)}</span>`).join('')}</div>
    </div>`;
  }).join('') : `<div class="arch-empty">暂无记录。点「让 AI 看看」后，这里会出现 L1 全局 / L2 区域 / L4 观察；你的确认与否决会写入 L5。</div>`;

  body.innerHTML = `
    <div class="statement" style="margin-bottom:12px">
      档案 = AI 写的 L1/L2/L4（只读原话）+ 你的 L5 决策。所有记录带来源标记、置信度、锚点与时间；
      否认与确认都会留痕并影响后续生成。schema ${SCHEMA_VERSION}${SCHEMA_READY ? ' · 已通过 core 校验模块加载' : ' · 校验模块未连接（离线降级）'}。
    </div>
    <div class="archive-tabs">${tabHtml}</div>
    <div class="archive-list">${rowHtml}</div>`;
  body.querySelectorAll('[data-arch-tab]').forEach((btn) => {
    btn.addEventListener('click', () => { activeTab = btn.dataset.archTab; renderArchiveBody(); });
  });
}
function fmtIso(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
