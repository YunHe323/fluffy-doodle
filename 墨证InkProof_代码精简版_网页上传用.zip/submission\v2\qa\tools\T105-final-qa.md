# T105 最终独立 QA：Skill + mask 落层 + 素材 AI + 编辑器操作（T105-F）

> 执行：qa-engineer（独立 QA｜task-108）｜日期：2026-11-07 17:0x｜只写 `v2/qa/tools/`；**未改 app/engine/CSS/HTML**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、单浏览器串行、小批次（每批 1–3 个测试）、完整日志落盘 `archive/baseline-t105-final/logs/`；执行时内存约 2.4GB。

## 结论

**可交付（Deliverable）——P0/P1 = 0；P2 = 1（测试契约过期，非产品缺陷）。**
Lead 集成的 5 条 Skill 主路径、mask 落层、素材 AI、编辑器操作与 UX P0 全部独立复核通过；11 项回归全过；真实证据一致；密钥/残留 0。

## 1. 新增测试（全部 PASS）

| 测试 | 结果 | 关键证据 |
|---|---|---|
| `test-mask-compare.mjs` | **PASS** | mask **outsideDiff=0**、insideDiff>0；对比滑杆 `clip=inset(0px 0px 0px 70%)`；落层 L6 `{masked:true, mask_policy:'selection_alpha', skill:'image.generate'}`；layers 3、transformActive |
| `test-editor-ui.mjs` | **PASS** | 图像调整：layers 2→3、层名「调整 · 图层 2」、L6 记录 1；形状：layers 3→4、层名「形状 · 矩形」、L6 记录 1；0 error |
| `test-ux-p0.mjs` | **PASS** | 1366 顶栏 `lastRight=503 < docLeft=632`（无重叠）；Esc 退出变换/隐藏浮动选项；打开 AI 自动退出变换/隐藏选项且面板有独立关闭按钮、可关闭 |
| `asset-ai-test.mjs`（Node 单测） | **PASS 10/10** | `asset-ai@1.0.0`；10 用例全过、0 失败（含精确词排序、参考推荐、mergeRealAnalysis、provenance 摘要） |
| `editor-ops-test.mjs`（Node 单测） | **PASS 77 断言** | 颜色矩阵/调整单调性/透明像素/形状 bounds+SVG path/文本空行/fitRect/浏览器包装降级报错 全过 |
| `skill-runtime-test.mjs`（Node 单测） | ⚠️ **FAIL（测试断言过期）** | 见 §4 P2-1；产品运行时正常（下列独立 5 路径复核 PASS） |

### Skill 5 路径独立复核（QA 补充，Node + fake provider）

`skill-5path.log`：注册表 **5 个 skill**（`asset.decompose`、`canvas.observe`、`canvas.directions`、`image.edit`、`image.generate`），逐个 `rt.run()` 全部 ok、返回结构正确（observe→global/regions/observations/…；directions→directions；generate/edit→candidates）、日志 5 条、无异常。→ **P2-1 仅为单测断言未随集成扩展（3→5）更新，不是产品回归。**

## 2. 回归（11 项，全 PASS、0 console error）

| 测试 | 结果 |
|---|---|
| test-app / test-ui | PASS（exit 0、errors 0） |
| test-library | **PASS**（scrim 已恢复 `rgba(35,27,18,0.62)`+`blur(2px)`；`finish(allPass?0:1)` 退出码已修） |
| test-image-workshop | PASS（2 候选/预览 alpha 1001/落层 transformActive/edit task=edit） |
| test-multimodal | PASS（标注/对齐/AI 标注层 alpha=5001/定位/语音） |
| test-chat | PASS |
| test-canvas-size | PASS（1600×1000/undo=1/弹窗预设） |
| test-text | PASS（L6 `text_inserted`=1） |
| test-editor-basics | PASS（复制粘贴/数值变换/Ctrl+J/重命名/AI 会话） |
| test-ai-provider | **PASS 16/16** |
| test-interaction-sequences | **PASS 9/9** |

## 3. 真实证据核对（未新增任何付费调用）

| 证据 | 核对结果 |
|---|---|
| `qwen-real-e2e-results.json`（最新） | pass=true；**21337ms / observations=2 / regions=2**；lastCall provider=**qwen**、model=qwen3.8-max、**mock=false**、latency=21288ms、usage=1271 tokens；evidence 12/12 检查真、`real_calls=1` ✅ 与 Lead 口径一致 |
| `qwen-image-edit-app-results.json` | pass=true；1 候选；modelVersion=**qwen-image-3.0-pro**、mock=false、51113ms、sha256=`b8790a18…`；落层 layers=3、transformActive=true ✅ |
| `asset-real-read-results.json` | pass=true；source=**real**、qwen3.8-max、latency=26348ms、skill=`asset.decompose`、L2=5/L4=4、1 条 critique ✅ |
| 新增真实调用 | **0**（仅核对已有证据） |

## 4. 问题清单

| # | 级别 | 问题 | owner | 建议 |
|---|---|---|---|---|
| 1 | **P2** | `skill-runtime-test.mjs` 断言 `skills.length===3` 已过期：集成后 builtin 注册 **5 个**（新增 canvas.directions/image.generate），导致单测 pass=false（产品运行时正常，QA 独立 5 路径全过） | **lead / demo-builder** | 更新断言为 5 个（或按注册表动态断言），并补 `canvas.directions` / `image.generate` 的 run 断言 |
| — | ~~P2~~ | T105 基线 P2 已关闭：①library scrim 恢复 0.62/blur(2px) 且 `pass.scrim=true`；②`test-library.mjs` 已改 `finish(allPass?0:1)` | demo-builder | 已确认 |
| — | — | P0/P1：**无** | — | — |

## 5. 密钥 / 残留

- 密钥：DOM、localStorage、sessionStorage、已加载 JS（app.js/ai-provider/archive-schema/skills/asset-ai/editor-ops/css）、静态源码均无 key；config GET 仅 `hasKey/keyLast4`；T99 token 注入正常。**全程未打印 key**。
- 残留：Edge 测试进程 **0**、测试端口 **0**；每批后清理并确认。
- 稳定性：全部批次单浏览器串行、每批 1–3 个；完整输出在 `logs/`。

## 6. 合并验收建议门槛（最终）

| 级别 | 门槛 |
|---|---|
| **P0（阻塞交付）** | app READY/绘制/undo、保存→刷新→打开像素 diff=0、AI 代理安全基线任一失败 |
| **P1（阻塞合并）** | mask 落层 outsideDiff≠0 或 mask_policy≠selection_alpha；对比滑杆缺失；Skill 主路径 L6 params.skill 缺失；asset-ai 单测失败；editor-ops 单测失败；图像调整/形状 L6 记录缺失；UX P0（1366 重叠/变换未退出/AI 无关闭）任一失败；11 项回归任一失败 |
| **P2（跟踪）** | 测试断言过期（如 skill 数量）、视觉细节、日志/证据包装 |
| 稳定性 | 关键测试小批次连跑一致、0 console error、0 残留；单浏览器串行；执行前 free≥2GB |

## 7. 产物与归档

- `v2/qa/tools/T105-final-qa.md`（本报告）
- `v2/qa/tools/archive/baseline-t105-final/`：`logs/`（全部原始输出）、各 result JSON、`keycheck-results.json`、`skill-5path.log`、README
- GATE：见 `v2/qa/tools/GATE-pw.md`「T105-F 最终独立 QA」行
