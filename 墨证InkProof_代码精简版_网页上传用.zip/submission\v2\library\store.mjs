/**
 * v2/library · IndexedDB 持久化（T70）
 * stores：assets（素材资产，key=id；sha256 唯一索引、tags multiEntry）、thumbnails（缩略图）、meta（偏好/状态）
 * 零第三方依赖；浏览器 IndexedDB。
 */
import { LIBRARY_DB, LIBRARY_DB_VERSION } from './library-schema.mjs';

export { LIBRARY_DB, LIBRARY_DB_VERSION };

const STORE_ASSETS = 'assets';
const STORE_THUMBS = 'thumbnails';
const STORE_ORIGINALS = 'originals';
const STORE_META = 'meta';

function promisify(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('IndexedDB 请求失败'));
  });
}

/** SHA-256（hex）；浏览器 crypto.subtle */
export async function sha256Hex(buffer) {
  const digest = await crypto.subtle.digest('SHA-256', buffer);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export class LibraryStore {
  constructor(opts = {}) {
    this.dbName = opts.dbName || LIBRARY_DB;
    this.version = opts.version || LIBRARY_DB_VERSION;
    this.db = null;
  }

  async open() {
    if (this.db) return this;
    this.db = await new Promise((resolve, reject) => {
      const req = indexedDB.open(this.dbName, this.version);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_ASSETS)) {
          const assets = db.createObjectStore(STORE_ASSETS, { keyPath: 'id' });
          assets.createIndex('sha256', 'sha256', { unique: true });
          assets.createIndex('tags', 'tags', { multiEntry: true });
          assets.createIndex('createdAt', 'createdAt');
        }
        if (!db.objectStoreNames.contains(STORE_THUMBS)) db.createObjectStore(STORE_THUMBS, { keyPath: 'id' });
        if (!db.objectStoreNames.contains(STORE_ORIGINALS)) db.createObjectStore(STORE_ORIGINALS, { keyPath: 'id' });
        if (!db.objectStoreNames.contains(STORE_META)) db.createObjectStore(STORE_META, { keyPath: 'key' });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('IndexedDB 打开失败'));
      req.onblocked = () => reject(new Error('IndexedDB 被其他标签页阻塞'));
    });
    return this;
  }

  _tx(store, mode = 'readonly') {
    if (!this.db) throw new Error('LibraryStore 未 open');
    return this.db.transaction(store, mode).objectStore(store);
  }

  async get(id) { return promisify(this._tx(STORE_ASSETS).get(id)); }

  async getBySha(sha256) {
    return promisify(this._tx(STORE_ASSETS).index('sha256').get(sha256));
  }

  async put(asset) {
    await this.open();
    await promisify(this._tx(STORE_ASSETS, 'readwrite').put(asset));
    return asset;
  }

  async putThumbnail(id, thumb) {
    await this.open();
    await promisify(this._tx(STORE_THUMBS, 'readwrite').put({ id, ...thumb }));
    return thumb;
  }

  async getThumbnail(id) { return promisify(this._tx(STORE_THUMBS).get(id)); }

  /** T74：原始图片 Blob（含 mime/bytes/宽高），按 asset id 存 */
  async putOriginal(id, original) {
    await this.open();
    const rec = { id, ...original };
    await promisify(this._tx(STORE_ORIGINALS, 'readwrite').put(rec));
    return rec;
  }

  async getOriginal(id) { return promisify(this._tx(STORE_ORIGINALS).get(id)); }

  async countOriginals() {
    await this.open();
    return promisify(this._tx(STORE_ORIGINALS).count());
  }

  async originalBytes() {
    const all = await promisify(this._tx(STORE_ORIGINALS).getAll());
    return all.reduce((s, r) => s + (r && r.bytes ? r.bytes : 0), 0);
  }

  async delete(id) {
    await this.open();
    await promisify(this._tx(STORE_ASSETS, 'readwrite').delete(id));
    await promisify(this._tx(STORE_THUMBS, 'readwrite').delete(id));
    await promisify(this._tx(STORE_ORIGINALS, 'readwrite').delete(id));
    return true;
  }

  async all() { return promisify(this._tx(STORE_ASSETS).getAll()); }

  async count() {
    await this.open();
    return promisify(this._tx(STORE_ASSETS).count());
  }

  async clear() {
    await this.open();
    await promisify(this._tx(STORE_ASSETS, 'readwrite').clear());
    await promisify(this._tx(STORE_THUMBS, 'readwrite').clear());
    await promisify(this._tx(STORE_ORIGINALS, 'readwrite').clear());
    await promisify(this._tx(STORE_META, 'readwrite').clear());
  }

  async getMeta(key) { return promisify(this._tx(STORE_META).get(key)); }

  async setMeta(key, value) {
    await this.open();
    const rec = { key, value, updatedAt: new Date().toISOString() };
    await promisify(this._tx(STORE_META, 'readwrite').put(rec));
    return rec;
  }

  /** 搜索：文本 + tag + 尺寸 + 简单颜色 */
  async search(filter = {}) {
    const all = await this.all();
    const text = String(filter.text || '').trim().toLowerCase();
    const tags = Array.isArray(filter.tags) ? filter.tags : [];
    const color = filter.color ? String(filter.color).toLowerCase() : '';
    return all.filter((a) => {
      if (text) {
        const hay = [a.fileName, ...(a.tags || []), a.L1 && a.L1.summary,
          ...(a.L1 && a.L1.subject ? a.L1.subject : []),
          ...(a.L1 && a.L1.mood ? a.L1.mood : []),
          ...(a.L2 || []).map((r) => r.label)].join(' ').toLowerCase();
        if (!hay.includes(text)) return false;
      }
      if (tags.length) {
        const set = new Set(a.tags || []);
        for (const t of tags) if (!set.has(t)) return false;
      }
      if (filter.minWidth && a.width < filter.minWidth) return false;
      if (filter.minHeight && a.height < filter.minHeight) return false;
      if (filter.maxWidth && a.width > filter.maxWidth) return false;
      if (filter.maxHeight && a.height > filter.maxHeight) return false;
      if (color) {
        const hit = (a.palette || []).some((hex) => String(hex).toLowerCase().startsWith(color.slice(0, 4)));
        if (!hit) return false;
      }
      return true;
    });
  }

  close() {
    if (this.db) { try { this.db.close(); } catch (e) { /* ignore */ } }
    this.db = null;
  }

  static async deleteDatabase(name = LIBRARY_DB) {
    await new Promise((resolve) => {
      const req = indexedDB.deleteDatabase(name);
      req.onsuccess = req.onerror = req.onblocked = () => resolve();
    });
  }
}
