// 用真实 Qwen 候选 PNG + 真实 meta 重建候选/落层三档截图（不发起新 API 调用）
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const real = JSON.parse(fs.readFileSync(path.join(ROOT, 'v2', 'app', 'test-qwen-real-result.json'), 'utf8'));
const b64 = fs.readFileSync(path.join(ROOT, 'v2', 'app', 'qwen-real-candidate.png')).toString('base64');
const dataUrl = 'data:image/png;base64,' + b64;
const gen = real.cases.generate;
const out = { schema: 'mozheng.app.qwen-real-ui.v1', at: new Date().toISOString(), cases: {}, errors: [] };
let browser = null;
const done = () => { fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'test-qwen-real-ui-result.json'), JSON.stringify(out, null, 2), 'utf8'); process.exit(0); };
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('mozheng.ai.settings.v1', JSON.stringify({ preset: 'qwen', allowReal: true, requireConfirm: false, privacyMode: false })); } catch (e) {} });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => out.errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') out.errors.push(m.text()); });
  await page.goto('http://127.0.0.1:4200/v2/app/index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
  await page.waitForTimeout(900);
  await page.evaluate(async ({ dataUrl, gen }) => {
    const a = window.__V2_APP__;
    a.state.selection = { x: 408, y: 240, width: 360, height: 320 };
    a.state.analysis = { global: { summary: '真实 Qwen 视觉：选区当前为未绘制的纯色区域；生成本地补光/光影局部方案。', subject: ['空白画布', '光影'], medium: { kind: 'digital' }, palette: ['#f7f4ec', '#e9e2d2'], mood: ['安静'] }, observations: [], regions: [], confidence: 0.62 };
    a.state.directions = [{ id: 'dir-ai-1', title: '建立基础明暗与轮廓', why: '真实 Qwen 方向：先建立画面结构与主体明暗。', confidence: 0.82, tags: ['光影', '结构'] }];
    a.state.selectedDirection = a.state.directions[0];
    a.state.candidates = [{ id: 'cand-qwen-1', label: '方案 A', why: 'Qwen-Image 生成（服务端已缓存）', imageDataUrl: dataUrl, sha256: gen.candidate.sha256, bytes: gen.candidate.bytes, width: gen.candidate.width, height: gen.candidate.height }];
    a.state.aiLastCall = { ...gen.meta, at: new Date().toISOString() };
    a.openPopover('popAI');
    a.t101.renderAI();
    const body = document.getElementById('aiBody');
    if (body) body.scrollTop = body.scrollHeight;
  }, { dataUrl, gen });
  await page.waitForTimeout(500);
  await page.evaluate(() => { const b = document.getElementById('aiBody'); if (b) b.scrollTop = b.scrollHeight; });
  const shots = [];
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await page.setViewportSize({ width: w, height: h });
    await page.waitForTimeout(250);
    await page.evaluate(() => { const b = document.getElementById('aiBody'); if (b) b.scrollTop = b.scrollHeight; });
    await page.waitForTimeout(150);
    await page.screenshot({ path: path.join(ROOT, 'v2', 'app', 'ui-ai-qwen-real-candidate-' + w + '.png') });
    shots.push({ file: 'v2/app/ui-ai-qwen-real-candidate-' + w + '.png', note: '真实 Qwen 候选卡片（真实 PNG/真实 meta，重建截图，未发起新调用）' });
  }
  const before = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.evaluate(() => { const b = document.querySelector('[data-cand="0"]'); if (b) b.click(); });
  for (let i = 0; i < 40; i += 1) { await page.waitForTimeout(250); const n = await page.evaluate((x) => window.__V2_APP__.engine.getLayers().length - x, before); if (n > 0) break; }
  const applyShots = [];
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await page.setViewportSize({ width: w, height: h });
    await page.waitForTimeout(250);
    await page.screenshot({ path: path.join(ROOT, 'v2', 'app', 'ui-ai-qwen-real-applied-' + w + '.png') });
    applyShots.push({ file: 'v2/app/ui-ai-qwen-real-applied-' + w + '.png', note: '真实候选落为新图层' });
  }
  out.cases.candidate = { count: 1, imageLen: dataUrl.length, sha256: gen.candidate.sha256, bytes: gen.candidate.bytes, meta: gen.meta };
  out.cases.layers = await page.evaluate((b) => ({ before: b, after: window.__V2_APP__.engine.getLayers().length }), before);
  out.cases.files = shots.concat(applyShots);
  out.errors = out.errors.slice(0, 10);
  out.pass = { candidate: true, applied: out.cases.layers.after === out.cases.layers.before + 1, screenshots: shots.length === 3 && applyShots.length === 3, noConsoleErrors: out.errors.length === 0 };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  console.log(JSON.stringify(out, null, 2));
} finally {
  try { await browser.close(); } catch (e) {}
  done();
}
