# AI 对话行动模块（T112-A）

> 模块：`v2/app/core/chat-actions.mjs` · 版本 `chat-actions@1.0.0`
> 测试：`v2/qa/tools/chat-actions-test.mjs`（Node，11/11 PASS，exit 0）
> 定位：把「AI 对话返回的行动建议」变成**可校验、可展示、可安全交给 UI** 的对象；本模块不执行行动、不读 DOM、不发网络、不写存储。app.js 的 `executeChatAction` 仍负责最终执行。

## 1. 允许的行动（ACTIONS）

| type | label | 说明 | params 白名单 |
|---|---|---|---|
| `observe` | 让 AI 看看 | 读选区/画面，返回观察 | `scope`: selection/canvas |
| `generate` | 生成局部候选 | 选区生成局部方案→新图层 | `prompt`(≤600)、`scope`、`count`(1–2) |
| `edit` | 编辑局部 | 按文字指令编辑选区→新图层 | `prompt`(≤600)、`scope` |
| `adjust` | 调整图层 | 亮度/对比度/饱和度/色相 | `brightness`(-1..1)、`contrast`(-1..1)、`saturation`(0..2)、`hue`(-180..180) |
| `reference` | 参考素材 | 把素材库一张设为参考 | `assetId`(安全 id)、`fileName`(≤160)、`query`(≤120) |
| `annotate` | 在画布标注 | 打开标注模式 | `label`(≤160)、`note`(≤300) |
| `export` | 导出/证据 | 打开证据视图或导出 | `format`: evidence/png/json/psd、`includeProject`(boolean) |

`ACTIONS[type]` 含 `{type,label,description,paramsSchema}`；`ACTION_TYPES` 为 7 个 type 的数组。所有参数**可选**；normalize 只保留传入的字段，不会注入默认值（enum/number 校验会 clamp）。

## 2. 接口

```js
import {
  ACTIONS, ACTION_TYPES,
  normalizeChatActions, validateAction, describeAction, buildMockActions,
} from './v2/app/core/chat-actions.mjs';
```

### 2.1 `normalizeChatActions(raw, {max=3}) -> safeAction[]`

- `raw`：数组，或 `{actions: []}`；其他输入返回 `[]`。
- 输出对象固定形状：
  ```js
  { type: 'generate', label: '生成局部候选', reason: '框外不动', params: { prompt: '保留笔触', scope: 'selection', count: 2 } }
  ```
- 规则：
  - 只接受 7 种 type；未知 type、缺 type、非对象条目丢弃；
  - 同 type **去重**（保留第一个）；`max` 默认 3，硬上限 3；
  - `label` 默认用 ACTIONS label，截断 ≤24 字符；`reason` 截断 ≤160；
  - `params` 只允许白名单字段；出现未知字段、非普通对象、非法类型/枚举值 → **整个 action 丢弃**（不产生半合法对象）；
  - 字符串清洗控制字符/空白；数字 clamp；boolean/enum 严格校验；
  - **脚本注入**（`<script>`、`<iframe>`、`onerror=`、`javascript:` 等）和 **URL/协议**（`http(s)://`、`www.`、`data:`、`file:`、`blob:`）出现在 label/reason/params 中 → 丢弃。

### 2.2 `validateAction(action) -> {ok, errors[]}`

对单个 action 做结构/安全二次检查（normalize 后的对象，或原始 action）：

```js
validateAction({ type: 'observe', label: '让 AI 看看', reason: 'ok', params: {} })
// {ok:true,errors:[]}
validateAction({ type: 'generate', params: { prompt: 'x', evil: 1 } })
// {ok:false,errors:['params.evil 不在白名单']}
```

- 已给出的 label/reason 必须为字符串≤24/≤160 且不含脚本/URL；
- params 走与 normalize 相同的白名单校验；
- 缺 label/reason 允许（normalize 会补默认），缺 type/未知 type 拒绝。

### 2.3 `describeAction(action) -> string`

返回纯文本用户可读文案，例如：

```
生成局部候选 · 框外不动 · 当前选区 · 提示「保留笔触」 · 2 个候选
调整图层 · 调整 亮度0.2 / 色相-15°
```

非法 action 返回 `无法执行的建议`。可用于按钮 title/aria，不可作为 HTML 直接插入（调用方仍需 escape）。

### 2.4 `buildMockActions({selection, libraryCount, referenced}) -> safeAction[]`

Mock 模式执行计划建议：

- 总是 `observe`（有选区 scope=selection，否则 canvas）；
- 有选区（width/height>0）追加 `generate`，prompt 默认「保留我的笔触，只改这个区域」，count 2；
- 有 `referenced[0]` 追加 `reference`，带 assetId/fileName；否则 `libraryCount>0` 追加无参数 reference；
- 再经 `normalizeChatActions(..., {max:3})`，保证 label/rf 裁剪、安全、去重。

## 3. 测试覆盖（11 项，exit 0）

```bash
node v2/qa/tools/chat-actions-test.mjs
```

1. 模块版本/ACTIONS 枚举完整且冻结
2. 合法 normalize（补默认 label/params）
3. 超长 label/reason 截断；空输入安全
4. 非法 type/未知枚举/非对象条目过滤
5. 同 type 去重、max≤3
6. label/reason/params 脚本注入拒绝
7. URL/未知 params/非对象 params 拒绝
8. params 白名单/数字 clamp/enum/boolean
9. validateAction 合法/非法/长度/注入/未知字段
10. describeAction 可读文案/非法安全返回
11. buildMockActions observe/generate/reference、截断/安全、空输入

## 4. 与 app.js 的集成建议（本任务不改 app.js）

### 4.1 在 provider 返回后统一 normalize

现有 `runChat`（约 line 3497–3504）拿到 `res.actions` 后直接 push：

```js
const res = await provider.converse({ ... });
const safeActions = normalizeChatActions(res.actions, { max: 3 });
state.aiChat.push({ role: 'assistant', content: res.text, actions: safeActions, meta: res.meta || state.aiLastCall });
```

这样即使真实模型返回未知 type/URL/脚本/超长字段，也不会进入 UI/日志/执行链。

### 4.2 执行前二次校验

`bindAiChat` 点击 action 时：

```js
const action = msg.actions[parts[1]];
if (validateAction(action).ok) executeChatAction(action);
else showToast('这条建议不安全，已忽略', true);
```

`executeChatAction` 保持现有 type switch；params 已保证是白名单字段，尤其 `params.prompt` 可安全填 `state.aiImagePrompt`。

### 4.3 展示用 describeAction

```js
const btn = document.createElement('button');
btn.textContent = action.label || ACTIONS[action.type].label;
btn.title = describeAction(action);
btn.setAttribute('aria-label', describeAction(action));
```

### 4.4 Mock fallback

Mock provider 当前自己拼 actions；可替换为：

```js
const actions = buildMockActions({
  selection: state.selection,
  libraryCount: (state.library.assets || []).length,
  referenced: state.aiWorkshopRefs || [],
});
```

保证 Mock/真实两条路径都经过同一个安全管道。

## 5. 限制

- 去重按 type：同一回复最多一个 observe/generate/…；需要多个同 type 时由调用方合并 params。
- 拒绝任何 URL（包括提示词里的参考链接）；如未来需要外链素材，走 `reference` 的 assetId/本地素材，不走 URL。
- 本模块只做建议对象的安全化与文案，不执行、不落库、不判定是否已在画布执行；执行与真实调用仍由 app.js/ai-provider 负责。
- `params` 白名单是代码内 schema；新增行动类型必须同时更新 ACTIONS、schema、测试与 executeChatAction。
