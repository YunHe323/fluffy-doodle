#!/usr/bin/env node
// v2/engine/test/memory-4096-review.mjs —— T49 后续：4096² 内存复核 + presentRetained 回退验证
// 不改变引擎默认行为：仅创建临时 Engine 实例（4096²/8 层）读统计与功能验证。
// 用法：node v2/engine/test/memory-4096-review.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const checks = {};
  const MI = 1048576;

  async function probe(width, presentRetained) {
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = width;
    const opts = { canvas, width, height: width, layers: 8 };
    if (presentRetained !== undefined) opts.presentRetained = presentRetained;
    const eng = new Engine(opts);
    await eng.init();
    const stats = eng.getStats();
    // 画一笔验证 present；再读 composite 非空
    eng.beginStroke({ x: 1200, y: 1200, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
    for (let i = 1; i < 20; i += 1) eng.appendPoint({ x: 1200 + i * 20, y: 1200, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
    eng.endStroke();
    await raf(); await raf();
    const url = await eng.getCompositeDataUrl();
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const cx = c.getContext('2d'); cx.drawImage(img, 0, 0);
    const d = cx.getImageData(0, 0, c.width, c.height).data;
    let ink = 0; for (let i = 0; i < d.length; i += 4) if (d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220) ink += 1;
    const out = {
      presentRetained,
      presentSurfaceMB: stats.presentSurfaceMB,
      memoryEstimateMB: stats.memoryEstimateMB,
      lastPresentMode: eng.lastPresentMode,
      lastBlitMs: stats.lastBlitMs,
      ink,
      width: stats.width, height: stats.height, layers: stats.layers,
    };
    eng.dispose();
    return out;
  }

  const retained = await probe(4096, true);
  const noRetained = await probe(4096, false);
  const auto4096 = await probe(4096, undefined);
  const auto2048 = await probe(2048, undefined);
  // 运行时 toggle（2048² 默认开 → 关 → 开），行为等价、可重绘
  const toggleCanvas = document.createElement('canvas');
  toggleCanvas.width = 2048; toggleCanvas.height = 2048;
  const toggleEng = new Engine({ canvas: toggleCanvas, width: 2048, height: 2048, layers: 2 });
  await toggleEng.init();
  const toggleOnMB = toggleEng.getStats().presentSurfaceMB;
  toggleEng.beginStroke({ x: 300, y: 400, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
  for (let i = 1; i < 20; i += 1) toggleEng.appendPoint({ x: 300 + i * 13, y: 400, pressure: 0.6, timestamp: performance.now(), pointerType: 'synthetic' });
  toggleEng.endStroke(); await raf();
  const offResult = toggleEng.setPresentRetained(false);
  const offMB = toggleEng.getStats().presentSurfaceMB;
  const onResult = toggleEng.setPresentRetained(true);
  const onMB = toggleEng.getStats().presentSurfaceMB;
  const toggleStats = toggleEng.getStats();
  toggleEng.dispose();
  // T38 分项（全满 4096²×8）：图层纹理 512 + 主 surface 64 + WASM 128 = 704 MiB；引擎另有 live surface 64 MiB
  const T38 = 704;
  const live = 64;
  const withRetained = T38 + live + 64;
  const withoutRetained = T38 + live;
  const result = {
    retained,
    noRetained,
    auto4096,
    auto2048,
    toggle: { onMB: toggleOnMB, offResult, offMB, onResult, onMB, modeAfterOn: toggleStats.lastPresentMode },
    calc: {
      t38BaselineMiB: T38,
      engineLiveSurfaceMiB: live,
      enginePresentSurfaceMiB: 64,
      totalWithRetainedMiB: withRetained,
      totalWithoutRetainedMiB: withoutRetained,
      budgetMiB: 800,
      passWithRetained: withRetained <= 800,
      passWithoutRetained: withoutRetained <= 800,
      marginWithoutRetainedMiB: 800 - withoutRetained,
    },
    checks,
  };
  checks.retainedHasSurface = retained.presentSurfaceMB === 64 && retained.ink > 0;
  checks.fallbackWorks = noRetained.presentSurfaceMB === 0 && noRetained.ink > 0;
  checks.fallbackPresentMode = noRetained.lastPresentMode === 'full' || noRetained.lastPresentMode === 'blit';
  checks.retainedOverBudget = withRetained > 800;
  checks.fallbackWithinBudget = withoutRetained <= 800;
  checks.auto4096Off = auto4096.presentSurfaceMB === 0 && auto4096.ink > 0;
  checks.auto2048On = auto2048.presentSurfaceMB === 16 && auto2048.ink > 0;
  checks.toggleWorks = toggleOnMB === 16 && offMB === 0 && onMB === 16 && toggleStats.lastPresentMode === 'full';
  result.ok = checks.retainedHasSurface && checks.fallbackWorks && checks.fallbackPresentMode && checks.retainedOverBudget
    && checks.fallbackWithinBudget && checks.auto4096Off && checks.auto2048On && checks.toggleWorks;
  return result;
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1200)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
