// 真实 Edge（非 headless）探测：app?debug=1 → pointer 绘制 → 像素验证 → 截图
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const EDGE = ['C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'].find((p) => fs.existsSync(p));
if (!EDGE) { console.log('NO EDGE'); process.exit(1); }
const PORT_HTTP = 8102;
const PORT_CDP = 9411;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const python = spawn('python', ['-m', 'http.server', String(PORT_HTTP), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
await sleep(800);
const profile = path.join(os.tmpdir(), 'edgeprobe-' + Date.now());
const edge = spawn(EDGE, [
  '--remote-debugging-port=' + PORT_CDP, '--user-data-dir=' + profile,
  '--window-position=60,40', '--window-size=1500,950', '--no-first-run',
  `http://127.0.0.1:${PORT_HTTP}/v2/app/index.html?debug=1`,
], { stdio: 'ignore' });
let target = null;
for (let i = 0; i < 300 && !target; i++) {
  try { const r = await fetch(`http://127.0.0.1:${PORT_CDP}/json/list`); target = (await r.json()).find((t) => t.type === 'page' && t.url.startsWith('http')); } catch (e) {}
  if (!target) await sleep(200);
}
if (!target) { console.log('NO TARGET'); process.exit(1); }
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map(); const errors = [];
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); return; }
  if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text);
  if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push(m.params.args.map((a) => a.value || a.description).join(' '));
};
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
async function ev(expression) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true });
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1200));
  return r.result?.result?.value;
}
const out = { edge: 'non-headless', url: target.url };
try {
  await send('Runtime.enable'); await send('Page.enable');
  const t0 = Date.now();
  while (Date.now() - t0 < 120000) { if (await ev('!!window.__V2_APP_READY__').catch(() => false)) break; await sleep(300); }
  out.ready = await ev('!!window.__V2_APP_READY__');
  out.debugBefore = await ev('window.__APP_DEBUG__ ? window.__APP_DEBUG__() : null');
  const rect = await ev(`(() => { const c=document.getElementById('mainCanvas'); const r=c.getBoundingClientRect(); return {x:r.x,y:r.y,w:r.width,h:r.height}; })()`);
  out.rect = rect;
  out.hitTest = await ev(`(() => { const r=document.getElementById('mainCanvas').getBoundingClientRect(); const el=document.elementFromPoint(r.x+r.width*0.5, r.y+r.height*0.5); return { tag: el && el.tagName, id: el && el.id, cls: el && el.className }; })()`);
  const y = rect.y + rect.h * 0.45;
  const xs = [0.18, 0.3, 0.42, 0.54, 0.66];
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: rect.x + rect.w * xs[0], y, button: 'left', clickCount: 1 });
  for (let i = 1; i < 20; i++) {
    const t = i / 20;
    await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: rect.x + rect.w * (0.18 + 0.5 * t), y: y + Math.sin(t * Math.PI * 2) * 40, button: 'left', buttons: 1 });
    await sleep(12);
  }
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: rect.x + rect.w * 0.68, y, button: 'left', clickCount: 1 });
  await sleep(600);
  out.debugAfter = await ev('window.__APP_DEBUG__ ? window.__APP_DEBUG__() : null');
  out.pixels = await ev(`(async () => { const e=window.__V2__; e.compositor.compositeAll(e.store); const url=await e.getCompositeDataUrl(); const img=new Image(); img.src=url; await img.decode(); const c=document.createElement('canvas'); c.width=img.width; c.height=img.height; const ctx=c.getContext('2d'); ctx.drawImage(img,0,0); const d=ctx.getImageData(0,0,c.width,c.height).data; let dark=0; for (let i=0;i<d.length;i+=4) if (d[i+3]>0 && d[i]<240) dark++; return { dark, w:c.width, h:c.height }; })()`);
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'edge-screenshot.png'), Buffer.from(shot.result.data, 'base64'));
  out.screenshot = 'v2/app/edge-screenshot.png';
  out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e.stack || e); out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} finally {
  try { ws.close(); } catch (e) {}
  edge.kill(); python.kill();
  await sleep(500);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
  process.exit(0);
}
