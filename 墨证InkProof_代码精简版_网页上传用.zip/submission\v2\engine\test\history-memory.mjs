#!/usr/bin/env node
// v2/engine/test/history-memory.mjs —— T89 历史图片回收/预算测试（零依赖 CDP）
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const checks = {};
  async function mkEngine() {
    const canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 512;
    const eng = new Engine({ canvas, width: 512, height: 512, layers: 2 });
    await eng.init(); eng.setBrush({ type: 'soft', sizePx: 24 });
    return eng;
  }
  const ink = async (url) => { const img = new Image(); img.src = url; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const x = c.getContext('2d'); x.drawImage(img, 0, 0); const d = x.getImageData(0, 0, c.width, c.height).data; let n = 0; for (let i = 0; i < d.length; i += 4) if (d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220) n += 1; return n; };
  const draw = (eng, i) => {
    const y = 20 + (i * 37) % 460;
    eng.beginStroke({ x: 20, y, pressure: 0.9, timestamp: performance.now(), pointerType: 'synthetic' });
    for (let k = 1; k < 8; k += 1) eng.appendPoint({ x: 20 + k * 50, y: y + Math.sin(k) * 10, pressure: 0.9, timestamp: performance.now(), pointerType: 'synthetic' }, { flush: false });
    eng.endStroke();
  };
  const eng = await mkEngine();
  eng.setHistoryBudget({ maxSteps: 12, maxBytes: 64 * 1024 * 1024, auto: true });
  for (let i = 0; i < 80; i += 1) draw(eng, i);
  await raf();
  const s1 = eng.getHistoryStats();
  checks.stepsLimited = s1.steps <= 12;
  checks.autoEviction = s1.auto === true && s1.evictedSteps > 0;
  checks.imagesReleased = s1.imagesReleased > 0;
  checks.bytesBounded = s1.bytes < 64 * 1024 * 1024;
  checks.imageRefsFinite = s1.imageRefs > 0 && s1.imageRefs < 10000;
  const beforeUndo = await ink(await eng.getCompositeDataUrl());
  eng.undo(); eng.undo(); eng.undo();
  const afterUndo = await ink(await eng.getCompositeDataUrl());
  checks.undoAfterEvict = beforeUndo > 0 && afterUndo > 0;
  eng.redo();
  checks.redoAfterEvict = (await ink(await eng.getCompositeDataUrl())) >= 0;
  // 长跑：继续画，历史内存/图片引用不持续增长
  for (let i = 0; i < 80; i += 1) draw(eng, i + 80);
  await raf();
  const s2 = eng.getHistoryStats();
  checks.longRunBounded = s2.steps <= 12 && s2.bytes <= s1.bytes * 2 + 1024;
  checks.releaseIncremental = s2.imagesReleased >= s1.imagesReleased;
  // 关闭自动回收（可回退）
  eng.setHistoryBudget({ auto: false, maxSteps: 5 });
  for (let i = 0; i < 20; i += 1) draw(eng, i + 200);
  await raf();
  const s3 = eng.getHistoryStats();
  checks.autoOff = s3.auto === false && s3.steps > 5;
  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  eng.dispose();
  return { ok: checks.ok, checks, data: { after80: s1, after160: s2, autoOff: s3, beforeUndo, afterUndo }, environment: { headless: /HeadlessChrome/.test(navigator.userAgent) } };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 240000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value || !value.checks) { console.error('无返回/异常', JSON.stringify(r).slice(0, 4000)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
