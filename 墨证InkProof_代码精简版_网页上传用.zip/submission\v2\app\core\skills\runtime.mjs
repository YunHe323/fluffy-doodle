/**
 * 墨证 Skill Runtime v0.1
 * ------------------------------------------------------------------
 * 目的：把"调用某个模型"升级为"执行一个平台技能"。
 *
 *   Skill = 领域知识 + 上下文构建 + 模型调用 + 输出校验 + 平台动作
 *
 * 同一个 Skill 可以跑在不同 provider/model 上；模型只负责它擅长的能力，
 * 上下文、schema、校验、fallback、证据记录都由平台负责。
 *
 * 这是后续所有 AI 功能的统一入口：
 * - canvas.observe / canvas.critique / canvas.directions
 * - asset.decompose（素材理解拆解）
 * - image.generate / image.edit
 * - evidence.pack
 */

export const SKILL_RUNTIME_VERSION = '0.1.0';

export class SkillRuntime {
  constructor(opts = {}) {
    this.skills = new Map();
    this.logs = [];
    this.logger = typeof opts.logger === 'function' ? opts.logger : null;
  }

  register(skill) {
    if (!skill || !skill.id) throw new Error('skill.id 必填');
    if (typeof skill.method !== 'string') throw new Error('skill.method 必填（provider 方法名，如 analyze）');
    this.skills.set(skill.id, {
      id: skill.id,
      version: skill.version || '0.1.0',
      title: skill.title || skill.id,
      description: skill.description || '',
      capability: skill.capability || 'vision',
      method: skill.method,
      buildPayload: skill.buildPayload || (({ input }) => input),
      normalize: skill.normalize || ((res) => res),
      validate: skill.validate || (() => ({ ok: true, errors: [] })),
      fallback: skill.fallback || null,
      raw: skill,
    });
    return this;
  }

  list() {
    return [...this.skills.values()].map((s) => ({ id: s.id, version: s.version, title: s.title, description: s.description, capability: s.capability }));
  }

  has(id) { return this.skills.has(id); }

  async run(id, input = {}, ctx = {}) {
    const skill = this.skills.get(id);
    if (!skill) throw new Error('未知 skill：' + id);
    const t0 = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    const provider = ctx.provider;
    if (!provider) throw new Error('SkillRuntime.run 缺少 provider');
    const fn = provider[skill.method];
    if (typeof fn !== 'function') throw new Error('provider 不支持方法：' + skill.method);
    const payload = await skill.buildPayload({ input, context: ctx.context || {}, skill });
    let raw;
    let lastErr = null;
    const attempts = Math.max(1, Number(ctx.retries) || 1);
    for (let i = 0; i < attempts; i += 1) {
      try {
        raw = await fn.call(provider, payload);
        lastErr = null;
        break;
      } catch (e) {
        lastErr = e;
        if (!e || !e.retryable || i === attempts - 1) break;
        await new Promise((r) => setTimeout(r, 250 * (i + 1)));
      }
    }
    if (lastErr) {
      const entry = { skill: skill.id, version: skill.version, ok: false, error: lastErr.code || 'ai_error', at: new Date().toISOString(), latencyMs: Math.round(((typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0)) };
      this.logs.push(entry);
      this.logger && this.logger('skill_error', entry);
      throw lastErr;
    }
    const result = skill.normalize(raw, input);
    const validation = skill.validate(result, input) || { ok: true, errors: [] };
    const entry = {
      skill: skill.id, version: skill.version, ok: !!validation.ok,
      provider: (raw && raw.meta && raw.meta.provider) || ctx.providerName || null,
      model: (raw && raw.meta && (raw.meta.modelVersion || raw.meta.model)) || null,
      latencyMs: Math.round(((typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0)),
      validation, at: new Date().toISOString(),
    };
    this.logs.push(entry);
    if (this.logs.length > 50) this.logs.shift();
    this.logger && this.logger('skill_ok', entry);
    return { ok: !!validation.ok, result, meta: raw && raw.meta ? raw.meta : {}, validation, skill: { id: skill.id, version: skill.version }, log: entry };
  }
}

export default SkillRuntime;
