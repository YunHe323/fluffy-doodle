// v2/app/test-ui.mjs — T58 布局/响应式/浮层/快捷键回归（headless，三档截图）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT_HTTP = 8105;
const PORT_CDP = 9417;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const python = spawn('python', ['-m', 'http.server', String(PORT_HTTP), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
await sleep(900);
const profile = path.join(os.tmpdir(), 'uitest-' + Date.now());
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist',
  '--window-size=1920,1080', '--hide-scrollbars',
  `--remote-debugging-port=${PORT_CDP}`, `--user-data-dir=${profile}`, 'about:blank',
], { stdio: 'ignore' });
let target = null;
for (let i = 0; i < 200 && !target; i++) {
  try { const r = await fetch(`http://127.0.0.1:${PORT_CDP}/json/list`); target = (await r.json()).find((t) => t.type === 'page'); } catch (e) {}
  if (!target) await sleep(150);
}
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map(); const errors = [];
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); return; }
  if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text);
  if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push(m.params.args.map((a) => a.value || a.description).join(' '));
};
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
async function ev(expression) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true });
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1200));
  return r.result?.result?.value;
}
async function key(k, code, vk, mods = 0) {
  await send('Input.dispatchKeyEvent', { type: 'keyDown', key: k, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, modifiers: mods });
  await send('Input.dispatchKeyEvent', { type: 'keyUp', key: k, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, modifiers: mods });
  await sleep(160);
}
const out = { schema: 'mozheng.app.ui-test.v1', sizes: {}, interactions: {}, errors: [] };
const sizes = [[1920, 1080], [1536, 864], [1366, 768]];
try {
  await send('Runtime.enable'); await send('Page.enable');
  for (const [w, h] of sizes) {
    await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: false });
    await send('Page.navigate', { url: `http://127.0.0.1:${PORT_HTTP}/v2/app/index.html` });
    const t0 = Date.now();
    let ready = false;
    while (Date.now() - t0 < 120000) { ready = await ev('!!window.__V2_APP_READY__').catch(() => false); if (ready) break; await sleep(250); }
    if (!ready) throw new Error('app not ready at ' + w + 'x' + h);
    await ev('window.__V2_APP__.closePopovers && window.__V2_APP__.closePopovers()');
    await sleep(500);
    const metrics = await ev(`(() => {
      const r = (id) => { const e = document.getElementById(id); if (!e) return null; const b = e.getBoundingClientRect(); return { x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.width), h: Math.round(b.height), bottom: Math.round(b.bottom), right: Math.round(b.right) }; };
      const canvas = document.getElementById('mainCanvas').getBoundingClientRect();
      const topbar = document.querySelector('.pro-topbar').getBoundingClientRect();
      const bottom = document.querySelector('.pro-bottombar').getBoundingClientRect();
      const rail = document.querySelector('.pro-rail').getBoundingClientRect();
      const overflowX = document.documentElement.scrollWidth > window.innerWidth + 1;
      const overflowY = document.documentElement.scrollHeight > window.innerHeight + 1;
      const minFont = (() => {
        let min = 99;
        document.querySelectorAll('#app *').forEach((el) => { const s = getComputedStyle(el); if (el.offsetParent !== null && s.visibility !== 'hidden' && (el.textContent || '').trim()) { const fs = parseFloat(s.fontSize) || 99; if (fs < min) min = fs; } });
        return min;
      })();
      return {
        inner: [window.innerWidth, window.innerHeight], overflowX, overflowY,
        topbarH: Math.round(topbar.height), bottomH: Math.round(bottom.height), railW: Math.round(rail.width), bottomBottom: Math.round(bottom.bottom),
        canvas: { x: Math.round(canvas.x), y: Math.round(canvas.y), w: Math.round(canvas.width), h: Math.round(canvas.height), bottom: Math.round(canvas.bottom), right: Math.round(canvas.right) },
        fixedSidebar: !!document.querySelector('.sidebar'),
        popovers: (() => {
          const out = [];
          for (const id of ['popLayers','popBrush','popColor','popAI','popMore']) {
            window.__V2_APP__.openPopover(id);
            const e = document.getElementById(id);
            out.push({ id, width: e ? Math.round(e.getBoundingClientRect().width) : 0, open: e ? e.classList.contains('open') : false });
          }
          window.__V2_APP__.closePopovers();
          return out;
        })(),
        minFont,
      };
    })()`);
    const shot = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(path.join(ROOT, 'v2', 'app', `ui-${w}.png`), Buffer.from(shot.result.data, 'base64'));
    out.sizes[w + 'x' + h] = {
      ...metrics,
      pass: {
        noOverflowX: !metrics.overflowX,
        noOverflowY: !metrics.overflowY,
        noFixedSidebar: !metrics.fixedSidebar,
        bottomBarVisible: metrics.bottomBottom <= h + 1 && metrics.bottomH >= 20,
        canvasVisible: metrics.canvas.w > 200 && metrics.canvas.h > 150,
        canvasTarget: w === 1920 ? (metrics.canvas.w >= 1400 && metrics.canvas.h >= 930) : w === 1366 ? (metrics.canvas.w >= 980 && metrics.canvas.h >= 650) : true,
        minFont12: metrics.minFont >= 11.5,
      },
    };
    await sleep(200);
  }
  // 交互：只开一个浮层；点外关闭不落笔；键盘
  await send('Emulation.setDeviceMetricsOverride', { width: 1920, height: 1080, deviceScaleFactor: 1, mobile: false });
  await send('Page.navigate', { url: `http://127.0.0.1:${PORT_HTTP}/v2/app/index.html` });
  for (let i = 0; i < 600; i++) { if (await ev('!!window.__V2_APP_READY__').catch(() => false)) break; await sleep(200); }
  await ev('window.__V2_APP__.closePopovers()');
  out.interactions.popover = await ev(`(async () => {
    document.getElementById('btnPanelLayers').click();
    const a = window.__V2_APP__.getActivePopover();
    document.getElementById('btnToolBrush').click();
    const b = window.__V2_APP__.getActivePopover();
    const layersClosed = !document.getElementById('popLayers').classList.contains('open');
    return { first: a, second: b, layersClosed };
  })()`);
  const before = await ev('({ undo: window.__V2_APP__.engine.getStats().undoDepth, pd: window.__V2_APP__.state.pointerdowns })');
  // 点画布外（topbar空白）关闭浮层，不应落笔
  await ev(`(() => { window.__V2_APP__.openPopover('popColor'); })()`);
  const canvasRect = await ev(`(() => { const r=document.getElementById('mainCanvas').getBoundingClientRect(); return {x:r.x,y:r.y,w:r.width,h:r.height}; })()`);
  const outsideX = canvasRect.x + canvasRect.w * 0.5;
  const outsideY = canvasRect.y + canvasRect.h * 0.8;
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: outsideX, y: outsideY, button: 'left', clickCount: 1 });
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: outsideX, y: outsideY, button: 'left', clickCount: 1 });
  await sleep(400);
  const after = await ev('({ undo: window.__V2_APP__.engine.getStats().undoDepth, pd: window.__V2_APP__.state.pointerdowns, popover: window.__V2_APP__.getActivePopover() })');
  out.interactions.outsideCloseNoDraw = { before, after, popoverClosed: after.popover === null, noStroke: after.undo === before.undo };
  // 快捷键
  await ev('window.dispatchEvent(new KeyboardEvent("keydown", { key: "m" }))');
  const toolM = await ev('window.__V2_APP__.state.tool');
  await ev('window.dispatchEvent(new KeyboardEvent("keydown", { key: "v" }))');
  const toolV = await ev('window.__V2_APP__.state.tool');
  await ev('window.dispatchEvent(new KeyboardEvent("keydown", { key: "b" }))');
  const toolB = await ev('window.__V2_APP__.state.tool');
  const sizeBefore = await ev('window.__V2_APP__.controller.preset.size.base');
  await ev('window.dispatchEvent(new KeyboardEvent("keydown", { key: "]" }))');
  const sizeAfter = await ev('window.__V2_APP__.controller.preset.size.base');
  out.interactions.keys = { toolM, toolV, toolB, sizeDelta: sizeAfter - sizeBefore };
  out.interactions.pass = {
    singlePopover: out.interactions.popover.second === 'popBrush' && out.interactions.popover.layersClosed,
    outsideNoDraw: out.interactions.outsideCloseNoDraw.popoverClosed && out.interactions.outsideCloseNoDraw.noStroke,
    keysWork: toolM === 'select' && toolV === 'transform' && toolB === 'brush' && Math.abs((sizeAfter - sizeBefore) - 5) < 0.01,
  };
  // P1 checks
  out.p1Checks = await ev(`(async () => {
    const popIds = ['popLayers','popBrush','popColor','popAI','popMore'];
    const popFonts = {};
    for (const id of popIds) {
      window.__V2_APP__.openPopover(id);
      const pop = document.getElementById(id);
      let min = 99;
      pop.querySelectorAll('*').forEach((el) => {
        const cs = getComputedStyle(el);
        if (el.offsetParent !== null && cs.visibility !== 'hidden' && (el.textContent || '').trim()) {
          const fs = parseFloat(cs.fontSize) || 99;
          if (fs < min) min = fs;
        }
      });
      popFonts[id] = min;
    }
    window.__V2_APP__.closePopovers();
    const ms = document.getElementById('modeSwitch').getBoundingClientRect();
    const modeAria = Array.from(document.querySelectorAll('#modeSwitch .mode-opt')).map((b) => b.getAttribute('aria-pressed'));
    const smudge = document.getElementById('btnToolSmudge');
    const smudgeOpacity = parseFloat(getComputedStyle(smudge).opacity);
    const smudgeDisabled = smudge.disabled;
    const smudgeBadge = smudge.querySelector('.soon') ? smudge.querySelector('.soon').textContent : null;
    const undoRect = document.getElementById('btnUndo').getBoundingClientRect();
    const pop = document.getElementById('popBrush');
    const transition = getComputedStyle(pop).transitionDuration;
    const layerSub = document.getElementById('layerCountSub');
    return {
      popFonts, popFontMin: Math.min(...Object.values(popFonts)),
      modeW: Math.round(ms.width), modeH: Math.round(ms.height), modeAria,
      smudgeOpacity, smudgeBadge, smudgeDisabled,
      undoW: Math.round(undoRect.width), undoH: Math.round(undoRect.height),
      transition, layerCountText: layerSub ? layerSub.textContent : null,
    };
  })()`);
  out.p1Checks.pass = {
    popoverFont12: out.p1Checks.popFontMin >= 11.5,
    modeSwitch84x22: Math.abs(out.p1Checks.modeW - 84) <= 2 && Math.abs(out.p1Checks.modeH - 22) <= 2,
    modeAria: out.p1Checks.modeAria.every((v) => v === 'true' || v === 'false'),
    smudge: out.p1Checks.smudgeDisabled === false && out.p1Checks.smudgeOpacity >= 0.9,
    undoHit28x24: Math.abs(out.p1Checks.undoW - 28) <= 1 && Math.abs(out.p1Checks.undoH - 24) <= 1,
    transition120ms: out.p1Checks.transition.includes('0.12s'),
    layerCountHeader: /^[0-9]+\/30$/.test(out.p1Checks.layerCountText || ''),
  };
  out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e.stack || e); out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} finally {
  try { ws.close(); } catch (e) {}
  chrome.kill(); python.kill(); await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
  fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'test-ui-result.json'), JSON.stringify(out, null, 2), 'utf8');
  process.exit(0);
}
