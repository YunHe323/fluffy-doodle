#!/usr/bin/env node
/**
 * v2/qa/tools/perf-regression.mjs — M4.5 P0 性能回归（T76 导出 Worker / T77 .mozheng gzip / T78 app 接入）
 *
 * A. 导出性能（engine 级，直接测 T76）：2048² / 4096² PNG 耗时、体积、主线程 longtask（>50ms 次数/最长）、
 *    进度事件、取消生效与恢复。
 * B. 保存性能（engine 级，直接测 T77）：.mozheng v1 JSON vs v2 gzip 的体积/保存耗时/打开耗时；
 *    v1 兼容打开；v2 回读结构一致 + 像素 diff=0（硬门槛）；损坏文件拒绝。
 * C. app 接入点（T78）探测；功能抽测由 tools/functional-regression.mjs 覆盖。
 *
 * 运行（headless、独立端口、跑完杀进程）：node v2/qa/tools/perf-regression.mjs
 * 输出：tools/perf-regression.json / tools/perf-regression-report.md
 */
import { spawn } from 'node:child_process';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const QA = path.resolve(__dirname, '..');
const REPO = path.resolve(QA, '..', '..');
const require = createRequire(import.meta.url);
const argv = process.argv.slice(2);
const argOf = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? argv[i + 1] : d; };
const PORT = Number(argOf('--port', 4262));
const OUT = path.join(__dirname, 'perf-regression.json');
const REPORT = path.join(__dirname, 'perf-regression-report.md');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const nowIso = () => new Date().toISOString();

async function startServer() {
  const portFile = path.join(REPO, 'v2', '.runtime-port');
  await fsp.rm(portFile, { force: true }).catch(() => {});
  const proc = spawn(process.execPath, [path.join(REPO, 'v2', 'serve.mjs')], { cwd: REPO, env: { ...process.env, PORT: String(PORT) }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  for (let i = 0; i < 120; i += 1) {
    await sleep(150);
    try { const p = Number(String(await fsp.readFile(portFile, 'utf8')).trim()); const r = await fetch(`http://127.0.0.1:${p}/v2/engine/demo.html`); if (r.ok) return { origin: `http://127.0.0.1:${p}`, proc }; } catch { /* wait */ }
  }
  throw new Error('无法启动静态服务');
}

const PERF_INSTRUMENT = `
window.__PERF__ = window.__PERF__ || { longtasks: [] };
try {
  if (!window.__PERF_OBS__) {
    window.__PERF_OBS__ = new PerformanceObserver((list) => { for (const e of list.getEntries()) window.__PERF__.longtasks.push({ start: Math.round(e.startTime), dur: Math.round(e.duration) }); });
    window.__PERF_OBS__.observe({ entryTypes: ['longtask'] });
  }
} catch (e) { window.__PERF__.longtaskError = String(e); }
window.__PERF__.reset = () => { window.__PERF__.longtasks = []; };
window.__PERF__.summary = () => { const a = window.__PERF__.longtasks.slice(); return { count: a.length, over50: a.filter((x) => x.dur > 50).length, longest: a.length ? Math.max(...a.map((x) => x.dur)) : 0, list: a.slice(0, 10) }; };
window.__PERF__.drawInk = async (engine, n) => {
  const W = engine.width, H = engine.height;
  if (engine.setBrush) engine.setBrush({ type: 'hard', sizePx: Math.max(8, Math.round(W / 64)) });
  for (let k = 0; k < n; k += 1) {
    const y = H * (0.2 + 0.6 * k / Math.max(1, n - 1));
    engine.beginStroke({ x: W * 0.12, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
    for (let i = 1; i <= 10; i += 1) engine.appendPoint({ x: W * (0.12 + 0.7 * i / 10), y: y + Math.sin(i) * H * 0.02, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' }, { flush: false });
    engine.endStroke();
  }
  await new Promise((r) => setTimeout(r, 250));
};
window.__PERF__.pixelDiff = async (a, b) => {
  const load = async (src) => { const img = new Image(); img.src = src; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const x = c.getContext('2d'); x.drawImage(img, 0, 0); return { w: c.width, h: c.height, d: x.getImageData(0, 0, c.width, c.height).data }; };
  const A = await load(a), B = await load(b);
  if (A.w !== B.w || A.h !== B.h) return { changed: -1, total: 0, sizeMismatch: true };
  let changed = 0;
  for (let i = 0; i < A.d.length; i += 4) if (Math.abs(A.d[i] - B.d[i]) > 10 || Math.abs(A.d[i + 1] - B.d[i + 1]) > 10 || Math.abs(A.d[i + 2] - B.d[i + 2]) > 10) changed += 1;
  return { changed, total: A.w * A.h, ratio: Math.round((changed / (A.w * A.h)) * 10000) / 100 };
};
`;

async function newEngine(page, size) {
  // 在页面里新建 size² Engine（复用 engine 模块，不改业务代码）
  return page.evaluate(async (sz) => {
    const modUrl = new URL('./src/engine.js', location.href).href;
    const { Engine } = await import(modUrl);
    const canvas = document.createElement('canvas');
    canvas.width = sz; canvas.height = sz;
    canvas.style.cssText = 'position:fixed;left:-99999px;top:0;width:128px;height:128px';
    document.body.appendChild(canvas);
    const e = new Engine({ canvas, width: sz, height: sz, layers: 2, loaderBase: './vendor/' });
    await e.init();
    window.__PERF_ENGINE_TAIL__ = e;
    await window.__PERF__.drawInk(e, 3);
    const url = await e.getCompositeDataUrl();
    return { ready: true, width: sz, compositeLen: (url || '').length };
  }, size);
}

async function main() {
  const { chromium } = require('playwright-core');
  const srv = await startServer();
  const browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--window-size=1600,1000', '--window-position=-3000,-3000'] });
  const report = { schema: 'mozheng.perf-regression.v1', at: nowIso(), headless: true, origin: srv.origin, export: {}, save: {}, appIntegration: {}, errors: [], checks: {}, pass: null };
  const ctx = await browser.newContext({ viewport: { width: 1532, height: 791 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  page.setDefaultTimeout(240000);
  const consoleErrors = [];
  const httpErrors = [];
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|status of 404/i.test(m.text())) consoleErrors.push(m.text().slice(0, 300)); });
  page.on('pageerror', (e) => consoleErrors.push(String(e.message || e).slice(0, 300)));
  page.on('response', (r) => { if (r.status() >= 400 && !/favicon/i.test(r.url())) httpErrors.push(r.status() + ' ' + r.url()); });

  try {
    await page.goto(`${srv.origin}/v2/engine/demo.html`, { waitUntil: 'load' });
    await page.waitForFunction('window.__V2__ && window.__V2__.ready === true', { timeout: 120000 });
    await page.waitForTimeout(1200);
    await page.evaluate(PERF_INSTRUMENT);

    // ---------- A1. 2048²（demo 自带引擎） ----------
    report.export.png2048 = await page.evaluate(async () => {
      const out = { size: 2048 };
      try {
        const e = window.__V2__;
        await window.__PERF__.drawInk(e, 3);
        const before = await e.getCompositeDataUrl();
        await new Promise((r) => setTimeout(r, 600));   // 等 before 快照的 longtask 事件派发完
        window.__PERF__.reset();
        await new Promise((r) => setTimeout(r, 120));
        const t0 = performance.now();
        let progressCount = 0, lastProgress = null;
        const blob = await e.exportPNGAsync({ tileSize: 256, onProgress: (p) => { progressCount += 1; lastProgress = p; } });
        out.exportMs = Math.round(performance.now() - t0);
        out.blobBytes = blob ? blob.size : 0;
        out.progressCount = progressCount;
        out.lastProgress = lastProgress;
        out.longTask = window.__PERF__.summary();
        const after = await e.getCompositeDataUrl();
        out.pixelDiff = await window.__PERF__.pixelDiff(before, after);
        out.ok = !!blob && blob.size > 1000 && out.longTask.over50 === 0 && (out.pixelDiff.ratio == null || out.pixelDiff.ratio <= 0.01);
      } catch (err) { out.error = String(err && (err.message || err)); out.ok = false; }
      return out;
    }).catch((e) => ({ size: 2048, ok: false, error: String(e.message || e) }));

    // ---------- A2. 4096²（新建引擎） ----------
    report.export.png4096 = await page.evaluate(async () => {
      const out = { size: 4096 };
      try {
        const modUrl = new URL('./src/engine.js', location.href).href;
        const { Engine } = await import(modUrl);
        const canvas = document.createElement('canvas');
        canvas.width = 4096; canvas.height = 4096;
        canvas.style.cssText = 'position:fixed;left:-99999px;top:0;width:128px;height:128px';
        document.body.appendChild(canvas);
        const e = new Engine({ canvas, width: 4096, height: 4096, layers: 2, loaderBase: './vendor/' });
        await e.init();
        window.__PERF_E4096__ = e;
        await window.__PERF__.drawInk(e, 3);
        const before = await e.getCompositeDataUrl();
        await new Promise((r) => setTimeout(r, 600));   // 等 before 快照的 longtask 事件派发完
        window.__PERF__.reset();
        await new Promise((r) => setTimeout(r, 120));
        const t0 = performance.now();
        let progressCount = 0, lastProgress = null;
        const blob = await e.exportPNGAsync({ tileSize: 256, onProgress: (p) => { progressCount += 1; lastProgress = p; } });
        out.exportMs = Math.round(performance.now() - t0);
        out.blobBytes = blob ? blob.size : 0;
        out.progressCount = progressCount;
        out.lastProgress = lastProgress;
        out.longTask = window.__PERF__.summary();
        const after = await e.getCompositeDataUrl();
        out.pixelDiff = await window.__PERF__.pixelDiff(before, after);
        out.ok = !!blob && blob.size > 1000 && out.longTask.over50 === 0 && (out.pixelDiff.ratio == null || out.pixelDiff.ratio <= 0.01);
      } catch (err) { out.error = String(err && (err.message || err)); out.ok = false; }
      return out;
    }).catch((e) => ({ size: 4096, ok: false, error: String(e.message || e) }));

    // ---------- A3. 取消 + 恢复（4096²） ----------
    report.export.cancel = await page.evaluate(async () => {
      const out = {};
      try {
        const e = window.__PERF_E4096__;
        if (!e) throw new Error('4096 engine 不可用');
        const p = e.exportPNGAsync({ tileSize: 256 }).then(() => ({ resolved: true })).catch((err) => ({ aborted: err && err.name === 'AbortError', msg: String(err && (err.message || err)) }));
        setTimeout(() => { try { e.cancelExport(); } catch (err) {} }, 120);
        out.abort = await p;
        const blob = await e.exportPNGAsync({ tileSize: 256 });
        out.recovered = !!blob && blob.size > 1000;
        out.ok = !!(out.abort && out.abort.aborted) && out.recovered;
      } catch (err) { out.error = String(err && (err.message || err)); out.ok = false; }
      return out;
    }).catch((e) => ({ ok: false, error: String(e.message || e) }));

    // ---------- B. 保存性能（T77，2048² demo 引擎） ----------
    report.save = await page.evaluate(async () => {
      const out = {};
      try {
        const e = window.__V2__;
        await window.__PERF__.drawInk(e, 2);
        window.__PERF__.reset();
        const before = await e.getCompositeDataUrl();
        await new Promise((r) => setTimeout(r, 600));
        window.__PERF__.reset();
        await new Promise((r) => setTimeout(r, 120));
        const t0 = performance.now();
        const v1Json = e.serializeDoc();
        out.v1 = { jsonBytes: v1Json.length, saveMs: Math.round((performance.now() - t0) * 10) / 10 };
        const t1 = performance.now();
        const gz = await e.serializeDocGzip();
        out.v2 = { gzipBytes: gz.length, saveMs: Math.round((performance.now() - t1) * 10) / 10, gzipMagic: gz[0] === 0x1f && gz[1] === 0x8b };
        const t2 = performance.now();
        const blob = await e.getDocFileBlob({ compress: true });
        out.v2.blobBytes = blob.size;
        out.v2.blobSaveMs = Math.round((performance.now() - t2) * 10) / 10;
        out.v2.ratioPct = Math.round((1 - gz.length / Math.max(1, v1Json.length)) * 1000) / 10;
        out.longTaskSave = window.__PERF__.summary();
        const t3 = performance.now();
        await e.deserializeDocGzip(gz);
        out.openV2Ms = Math.round((performance.now() - t3) * 10) / 10;
        await new Promise((r) => setTimeout(r, 300));
        const after = await e.getCompositeDataUrl();
        out.roundtripPixel = await window.__PERF__.pixelDiff(before, after);
        const t4 = performance.now();
        await e.deserializeDoc(v1Json);
        out.openV1Ms = Math.round((performance.now() - t4) * 10) / 10;
        out.v1CompatLayers = (e.getDoc().layers || []).length;
        try { await e.deserializeDocGzip(new Uint8Array([1, 2, 3, 4])); out.corruptRejected = false; } catch (err) { out.corruptRejected = true; }
        // 注：serializeDoc()（v1 tile PNG base64 同步编码）是既有长任务来源；T77 gzip 为异步增量。
        out.saveTotalMs = Math.round((out.v1.saveMs + out.v2.saveMs) * 10) / 10;
        out.ok = out.v2.gzipMagic && out.v2.ratioPct > 0 && out.corruptRejected === true && out.saveTotalMs <= 400
          && out.roundtripPixel && (out.roundtripPixel.ratio == null || out.roundtripPixel.ratio <= 0.01);
      } catch (err) { out.error = String(err && (err.message || err)); out.ok = false; }
      return out;
    }).catch((e) => ({ ok: false, error: String(e.message || e) }));

    // ---------- B2. 异步保存（T79 Worker）：2048² / 4096² + 取消恢复 ----------
    const measureSaveAsync = async (size) => page.evaluate(async (sz) => {
      const out = { size: sz };
      try {
        const modUrl = new URL('./src/engine.js', location.href).href;
        const { Engine } = await import(modUrl);
        const canvas = document.createElement('canvas');
        canvas.width = sz; canvas.height = sz;
        canvas.style.cssText = 'position:fixed;left:-99999px;top:0;width:128px;height:128px';
        document.body.appendChild(canvas);
        const e = new Engine({ canvas, width: sz, height: sz, layers: 2, loaderBase: './vendor/' });
        await e.init();
        window['__PERF_SAVE_' + sz] = e;
        await window.__PERF__.drawInk(e, 2);
        const beforeUrl = await e.getCompositeDataUrl();
        await new Promise((r) => setTimeout(r, 600));
        window.__PERF__.reset();
        await new Promise((r) => setTimeout(r, 120));
        const t0 = performance.now();
        let progressCount = 0;
        if (e.warmUpSaveAsync) { try { await e.warmUpSaveAsync(); } catch (err) {} }
        const blob = await e.saveDocAsync({ compress: true, onProgress: () => { progressCount += 1; } });
        out.saveMs = Math.round((performance.now() - t0) * 10) / 10;
        out.blobBytes = blob ? blob.size : 0;
        out.progressCount = progressCount;
        out.longTask = window.__PERF__.summary();
        // 回读像素 diff（blob → gzip → doc → 合成图）
        const bytes = new Uint8Array(await blob.arrayBuffer());
        const gzMagic = bytes[0] === 0x1f && bytes[1] === 0x8b;
        await e.deserializeDocGzip(bytes);
        await new Promise((r) => setTimeout(r, 300));
        const afterUrl = await e.getCompositeDataUrl();
        out.gzMagic = gzMagic;
        out.pixelDiff = await window.__PERF__.pixelDiff(beforeUrl, afterUrl);
        out.ok = !!blob && blob.size > 1000 && out.longTask.over50 === 0 && gzMagic && out.pixelDiff && (out.pixelDiff.ratio == null || out.pixelDiff.ratio <= 0.01);
      } catch (err) { out.error = String(err && (err.message || err)); out.ok = false; }
      return out;
    }, size).catch((e) => ({ size, ok: false, error: String(e.message || e) }));
    report.saveAsync2048 = await measureSaveAsync(2048);
    report.saveAsync4096 = await measureSaveAsync(4096);

    // 取消保存 + 恢复（4096²）
    report.saveCancel = await page.evaluate(async () => {
      const out = {};
      try {
        const e = window.__PERF_SAVE_4096;
        if (!e) throw new Error('4096 保存引擎不可用');
        const p = e.saveDocAsync({ compress: true }).then(() => ({ resolved: true })).catch((err) => ({ aborted: err && err.name === 'AbortError', msg: String(err && (err.message || err)) }));
        setTimeout(() => { try { e.cancelSave(); } catch (err) {} }, 60);
        out.abort = await p;
        const blob = await e.saveDocAsync({ compress: true });
        out.recovered = !!blob && blob.size > 1000;
        out.ok = !!(out.abort && out.abort.aborted) && out.recovered;
      } catch (err) { out.error = String(err && (err.message || err)); out.ok = false; }
      return out;
    }).catch((e) => ({ ok: false, error: String(e.message || e) }));

    // ---------- B3. PSD Worker 导出（T79 exportPSDAsync） ----------
    report.psd = await page.evaluate(async () => {
      const out = {};
      try {
        const e = window.__PERF_E4096__ || window.__V2__;
        if (!e || typeof e.exportPSDAsync !== 'function') { out.skipped = true; out.reason = 'exportPSDAsync 不可用'; return out; }
        await new Promise((r) => setTimeout(r, 500));
        window.__PERF__.reset();
        await new Promise((r) => setTimeout(r, 120));
        const t0 = performance.now();
        const buf = await e.exportPSDAsync({ onProgress: () => {} });
        out.ms = Math.round((performance.now() - t0) * 10) / 10;
        const ab = (buf && typeof buf.arrayBuffer === 'function') ? await buf.arrayBuffer() : buf;
        const bytes = ab instanceof ArrayBuffer ? new Uint8Array(ab) : (ab instanceof Uint8Array ? ab : new Uint8Array(0));
        out.bytes = bytes.length;
        out.magic = String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) === '8BPS';
        out.longTask = window.__PERF__.summary();
        out.ok = out.bytes > 1000 && out.magic;
      } catch (err) { out.error = String(err && (err.message || err)); out.ok = false; }
      return out;
    }).catch((e) => ({ ok: false, error: String(e.message || e) }));

    // PSD 取消 + 恢复（4096²）
    report.psdCancel = await page.evaluate(async () => {
      const out = {};
      try {
        const e = window.__PERF_E4096__;
        if (!e || typeof e.exportPSDAsync !== 'function') { out.skipped = true; return out; }
        let canceled = false;
        const p = e.exportPSDAsync({ onProgress: (pr) => { if (!canceled && pr && pr.phase === 'render' && pr.done >= 1) { canceled = true; try { e.cancelPSDExport(); } catch (err) {} } } })
          .then(() => ({ resolved: true }))
          .catch((err) => ({ aborted: err && err.name === 'AbortError', msg: String(err && (err.message || err)) }));
        const timer = setTimeout(() => { try { e.cancelPSDExport(); } catch (err) {} }, 300);
        out.abort = await p;
        clearTimeout(timer);
        await new Promise((r) => setTimeout(r, 600));
        const buf = await e.exportPSDAsync({});
        const ab = (buf && typeof buf.arrayBuffer === 'function') ? await buf.arrayBuffer() : buf;
        const bytes = ab instanceof ArrayBuffer ? new Uint8Array(ab) : (ab instanceof Uint8Array ? ab : new Uint8Array(0));
        out.recovered = bytes.length > 1000;
        out.ok = !!(out.abort && out.abort.aborted) && out.recovered;
      } catch (err) { out.error = String(err && (err.message || err)); out.ok = false; }
      return out;
    }).catch((e) => ({ ok: false, error: String(e.message || e) }));

    // ---------- C. app 接入点（T78）探测 ----------
    const appPage = await ctx.newPage();
    appPage.setDefaultTimeout(120000);
    try {
      await appPage.goto(`${srv.origin}/v2/app/index.html`, { waitUntil: 'load' });
      await appPage.waitForFunction('window.__V2_APP_READY__ === true', { timeout: 120000 });
      await appPage.waitForTimeout(2000);
      await appPage.evaluate(PERF_INSTRUMENT);
      report.appIntegration = await appPage.evaluate(() => {
        const app = window.__V2_APP__ || {};
        const t78 = app.t78 || {}, engine = app.engine || {};
        return {
          t78Keys: Object.keys(t78),
          engineApis: {
            exportPNGAsync: typeof engine.exportPNGAsync === 'function',
            getDocFileBlob: typeof engine.getDocFileBlob === 'function',
            deserializeDocGzip: typeof engine.deserializeDocGzip === 'function',
            cancelExport: typeof engine.cancelExport === 'function',
          },
          appExportButton: !!document.getElementById('btnExportPng') || !!document.getElementById('btnExportPngAsync'),
          appSaveProject: !!document.getElementById('btnSaveProject') || !!document.getElementById('miSaveProject'),
        };
      });
      report.appIntegration.appSave = await appPage.evaluate(async () => {
        try {
          const app = window.__V2_APP__, e = app.engine;
          if (!window.__PERF__ || typeof e.getDocFileBlob !== 'function') return { skipped: true };
          e.setActiveLayer && e.setActiveLayer(e.getLayers()[0].id);
          if (app.setTool) app.setTool('brush');
          const W = e.width, H = e.height;
          for (let k = 0; k < 2; k += 1) {
            const y = H * (0.35 + 0.3 * k);
            e.beginStroke({ x: W * 0.2, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
            for (let i = 1; i <= 8; i += 1) e.appendPoint({ x: W * (0.2 + 0.5 * i / 8), y: y + Math.sin(i) * 20, pressure: 0.8, timestamp: performance.now(), pointerType: "synthetic" }, { flush: false });
            e.endStroke();
          }
          await new Promise((r) => setTimeout(r, 500));
          window.__PERF__.reset();
          await new Promise((r) => setTimeout(r, 120));
          const t0 = performance.now();
          let blob = null, mode = "sync";
          if (typeof e.saveDocAsync === 'function') { mode = "worker"; if (e.warmUpSaveAsync) { try { await e.warmUpSaveAsync(); } catch (err) {} } blob = await e.saveDocAsync({ compress: true }); }
          else blob = await e.getDocFileBlob({ compress: true });
          const ms = performance.now() - t0;
          return { bytes: blob.size, saveMs: Math.round(ms * 10) / 10, mode, longTask: window.__PERF__.summary(), canvas: [W, H] };
        } catch (err) { return { error: String(err && (err.message || err)) }; }
      }).catch((e) => ({ error: String(e.message || e) }));
      report.appIntegration.perf = await appPage.evaluate(async () => {
        const app = window.__V2_APP__ || {};
        const t78 = app.t78 || {};
        const out = { workerSupported: t78.isWorkerSupported ? t78.isWorkerSupported() : null, compressionSupported: t78.isCompressionSupported ? t78.isCompressionSupported() : null };
        const timed = async (fn) => {
          try { if (t78.warmUp) await t78.warmUp(); } catch (e) {}
          await new Promise((r) => setTimeout(r, 250));
          if (window.__PERF__) window.__PERF__.reset();
          await new Promise((r) => setTimeout(r, 120));
          const t0 = performance.now();
          let res = null, err = null;
          try { res = await fn(); } catch (e) { err = String((e && (e.message || e)) || e); }
          const ms = performance.now() - t0;
          return { ms: Math.round(ms * 10) / 10, longTask: window.__PERF__ ? window.__PERF__.summary() : null, err, res };
        };
        out.evidence = await timed(async () => { const pkg = await app.buildEvidence({ asyncPNG: true }); return { bytes: JSON.stringify(pkg || {}).length, refs: ((pkg && pkg.refs) || []).length, events: ((pkg && pkg.events) || []).length }; });
        out.psd = await timed(async () => { const b = await t78.psdExportBuffer(); return { bytes: b && b.buffer ? b.buffer.byteLength : (b ? b.byteLength : 0) }; });
        out.fileSizes = t78.getFileSizes ? t78.getFileSizes() : null;
        // 取消生效时间
        try {
          const p = t78.exportPngBlob({});
          await new Promise((r) => setTimeout(r, 150));
          const c0 = performance.now();
          t78.cancelExport();
          const r = await p.then(() => ({ ok: true })).catch((e) => ({ err: String((e && (e.name || e.message)) || e) }));
          out.cancel = { callMs: Math.round((performance.now() - c0) * 10) / 10, result: r };
        } catch (e) { out.cancel = { error: String((e && (e.message || e)) || e) }; }
        // 失败提示（注入 exportPNGAsync 抛错，观察 UI 反馈；结束后恢复）
        const orig = app.engine && app.engine.exportPNGAsync;
        try {
          if (!orig) out.failure = { skipped: true };
          else {
            app.engine.exportPNGAsync = async () => { throw new Error("QA 注入导出失败"); };
            const btn = document.getElementById("btnExportPng");
            if (!btn) out.failure = { skipped: true, why: "btnExportPng 缺失" };
            else {
              btn.click();
              await new Promise((r2) => setTimeout(r2, 1200));
              out.failure = {
                clicked: true,
                toasts: [...document.querySelectorAll("#toastWrap *")].map((x) => String(x.textContent || "").trim()).filter(Boolean).slice(-3),
                asyncTask: t78.getAsyncTask ? t78.getAsyncTask() : null,
                statusHint: (document.getElementById("statusHint") || {}).textContent || null,
              };
            }
          }
        } catch (e) { out.failure = { error: String((e && (e.message || e)) || e) }; }
        finally { if (app.engine && orig) app.engine.exportPNGAsync = orig; }
        // PSD：优先 Worker 异步（T81 接入），回退既有 t61.psdExportBuffer
        out.psdAsync = await timed(async () => {
          const e = app.engine;
          let buf = null, mode = "sync";
          if (t78.psdExportAsync) { mode = "worker-t78"; buf = await t78.psdExportAsync(); }
          else if (typeof e.exportPSDAsync === 'function') { mode = "worker-engine"; buf = await e.exportPSDAsync({}); }
          else if (t78.psdExportBuffer) { mode = "sync-t78"; buf = await t78.psdExportBuffer(); }
          else { return { skipped: true }; }
          const ab = (buf && typeof buf.arrayBuffer === 'function') ? await buf.arrayBuffer() : buf;
          const bytes = ab instanceof ArrayBuffer ? new Uint8Array(ab) : (ab instanceof Uint8Array ? ab : new Uint8Array(0));
          return { mode, bytes: bytes.length, magic: String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) === "8BPS" };
        });
        return out;
      }).catch((e) => ({ error: String(e.message || e) }));
    } catch (e) { report.appIntegration = { error: String(e.message || e) }; } finally { await appPage.close().catch(() => {}); }

    report.errors = consoleErrors.slice(0, 10);
    report.httpErrors = httpErrors.slice(0, 10);
    report.checks = {
      export2048: !!(report.export.png2048 && report.export.png2048.ok),
      export4096: !!(report.export.png4096 && report.export.png4096.ok),
      exportCancel: !!(report.export.cancel && report.export.cancel.ok),
      saveV2: !!(report.save && report.save.ok),
      saveAsync2048: !!(report.saveAsync2048 && report.saveAsync2048.ok),
      saveAsync4096: !!(report.saveAsync4096 && report.saveAsync4096.ok),
      saveCancel: !!(report.saveCancel && report.saveCancel.ok),
      psdAsync: !!(report.psd && report.psd.ok),
      psdCancel: !!(report.psdCancel && report.psdCancel.skipped ? true : report.psdCancel && report.psdCancel.ok),
      longTaskExportClean: ((report.export.png2048?.longTask?.over50) || 0) === 0
        && ((report.export.png4096?.longTask?.over50) || 0) === 0,
      noConsoleErrors: report.errors.length === 0,
    };
    report.pass = Object.values(report.checks).every(Boolean);
  } catch (e) {
    report.fatal = String(e.stack || e.message || e);
    report.pass = false;
  } finally {
    await browser.close().catch(() => {});
    try { srv.proc.kill(); } catch { /* ignore */ }
    await fsp.rm(path.join(REPO, 'v2', '.runtime-port'), { force: true }).catch(() => {});
  }

  await fsp.writeFile(OUT, JSON.stringify(report, null, 2), 'utf8');
  const L = [];
  L.push('# 性能回归报告（M4.5 P0 · T76 导出 Worker / T77 .mozheng gzip）', '');
  L.push('> 生成：' + report.at + '｜headless（playwright-core channel:msedge）｜服务 ' + (report.origin || '') + '｜数据：`perf-regression.json`');
  L.push('');
  L.push('## 结论：' + (report.pass ? '✅ **M4.5 性能可验收**' : '❌ 未通过（见下表）'));
  L.push('');
  L.push('| 检查 | 结果 |');
  L.push('|---|---|');
  for (const [k, v] of Object.entries(report.checks)) L.push('| ' + k + ' | ' + (v ? '✅' : '❌') + ' |');
  L.push('');
  L.push('## A. 导出性能（PNG，Worker；longtask=主线程 >50ms 次数）');
  L.push('');
  L.push('| 画布 | 耗时 ms | 体积 | 进度事件 | longtask(>50ms) | 最长 ms | 导出前后像素 diff | 结果 |');
  L.push('|---|---|---|---|---|---|---|---|');
  for (const k of ['png2048', 'png4096']) {
    const r = report.export[k] || {};
    L.push('| ' + (r.size || '-') + '² | ' + (r.exportMs ?? '—') + ' | ' + (r.blobBytes ? Math.round(r.blobBytes / 1024) + ' KB' : '—') + ' | ' + (r.progressCount ?? '—') + ' | ' + (r.longTask ? r.longTask.over50 : '—') + ' | ' + (r.longTask ? r.longTask.longest : '—') + ' | ' + (r.pixelDiff ? r.pixelDiff.ratio + '%' : '—') + ' | ' + (r.ok ? '✅' : '❌ ' + (r.error || '')) + ' |');
  }
  const c = report.export.cancel || {};
  L.push('');
  L.push('- **取消**（4096² 中途 cancelExport）：' + (c.ok ? '✅ AbortError + 后续导出恢复成功' : '❌ ' + (c.error || JSON.stringify(c.abort || {}))));
  L.push('');
  L.push('## B. 保存（.mozheng v1 JSON vs v2 gzip）');
  L.push('');
  const sv = report.save || {};
  if (sv.v1 && sv.v2) {
    L.push('| 项 | v1（JSON） | v2（gzip Blob） |');
    L.push('|---|---|---|');
    L.push('| 体积 | ' + Math.round(sv.v1.jsonBytes / 1024) + ' KB | ' + Math.round(sv.v2.blobBytes / 1024) + ' KB（压缩 −' + sv.v2.ratioPct + '%） |');
    L.push('| 保存耗时 | ' + sv.v1.saveMs + ' ms | ' + sv.v2.blobSaveMs + ' ms（gzip ' + sv.v2.saveMs + ' ms） |');
    L.push('| 打开耗时 | ' + (sv.openV1Ms ?? '—') + ' ms | ' + (sv.openV2Ms ?? '—') + ' ms |');
    L.push('');
    L.push('- gzip 魔数：' + (sv.v2.gzipMagic ? '✅' : '❌') + '；保存期间 longtask（>50ms）：' + (sv.longTaskSave ? sv.longTaskSave.over50 + ' 次（最长 ' + sv.longTaskSave.longest + 'ms）' : '—'));
    L.push('- **v2 回读**：像素 diff=' + (sv.roundtripPixel ? sv.roundtripPixel.ratio + '%' : '—') + '（硬门槛 ≤0.01%）→ ' + (sv.roundtripPixel && (sv.roundtripPixel.ratio == null || sv.roundtripPixel.ratio <= 0.01) ? '✅ 一致' : '❌'));
    L.push('- v1 兼容打开：layers=' + (sv.v1CompatLayers ?? '—') + '；损坏文件拒绝：' + (sv.corruptRejected ? '✅' : '❌'));
    L.push('- 保存总耗时（v1 serialize + gzip）：' + (sv.saveTotalMs ?? '—') + ' ms；longtask（归因 v1 serializeDoc 同步编码，非 T77 gzip）：' + (sv.longTaskSave ? sv.longTaskSave.over50 + ' 次，最长 ' + sv.longTaskSave.longest + 'ms' : '—'));
  } else L.push('无数据：' + (sv.error || ''));
  L.push('');
  L.push('## C. app 接入点（T78）');
  L.push('');
  L.push('```json');
  L.push(JSON.stringify(report.appIntegration, null, 2).slice(0, 1200));
  L.push('```');
  L.push('');
  L.push('## D. app 级保存（1200×800 真实产品文档）');
  L.push('');
  L.push('```json');
  L.push(JSON.stringify((report.appIntegration && report.appIntegration.appSave) || null, null, 2).slice(0, 800));
  L.push('');
  L.push('**app 级导出抽测**（证据包 / PSD / 失败提示；能力探测）：');
  L.push('');
  L.push('```json');
  L.push(JSON.stringify((report.appIntegration && report.appIntegration.perf) || null, null, 2).slice(0, 1600));
  L.push('```');
  L.push('```');
  L.push('');
  L.push('> 功能抽测（保存/打开、证据包、素材库插入）由 `tools/functional-regression.mjs` 覆盖。');
  L.push('');
  await fsp.writeFile(REPORT, '\uFEFF' + L.join('\n'), 'utf8');
  console.log('[perf] ' + (report.pass ? 'PASS' : 'FAIL') + ' checks=' + JSON.stringify(report.checks));
  console.log('[perf] 输出：' + path.relative(process.cwd(), OUT) + ' / ' + path.relative(process.cwd(), REPORT));
  process.exit(report.pass ? 0 : 1);
}

main().catch((e) => { console.error('perf 失败：', e.stack || e); process.exit(2); });
