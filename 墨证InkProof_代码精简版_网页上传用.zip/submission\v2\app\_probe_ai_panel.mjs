// 临时：检查 AI 面板「模型」入口与新版协作上下文
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
import fs from 'node:fs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const out = { errors: [], cases: {} };
let browser = null;
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto('http://127.0.0.1:4200/v2/app/index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1500);
  await page.evaluate(() => window.__V2_APP__.t96.setToggles({ allowReal: false, privacyMode: true, requireConfirm: true }));
  await page.click('#btnAiPanel');
  await page.waitForTimeout(300);
  await page.click('#btnAiTabModel');
  await page.waitForTimeout(500);
  out.cases.modelTab = await page.evaluate(() => ({
    visible: getComputedStyle(document.getElementById('aiTabModel')).display !== 'none',
    text: (document.getElementById('aiModelBody') || {}).innerText || '',
    pills: [...document.querySelectorAll('#popAI .ai-provider-pill')].map((x) => x.textContent),
    hasSettingsBtn: !!document.getElementById('btnAiSettingsOpen'),
  }));
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-ai-model-entry-1920.png' });
  await page.click('#btnAiSettingsOpen');
  await page.waitForTimeout(500);
  out.cases.settings = await page.evaluate(() => ({ modalVisible: !!document.querySelector('#aboutModal.show'), aiCardVisible: !!document.getElementById('aiAccessCard'), provider: (document.getElementById('aiProviderSelect') || {}).value }));
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-ai-settings-entry-1920.png' });
  await page.click('#aboutModal .close-x');
  await page.waitForTimeout(300);
  // mock 观察面板（不花钱）
  await page.evaluate(() => { const a = window.__V2_APP__; a.state.selection = { x: 240, y: 200, width: 420, height: 300 }; a.closePopovers(); });
  await page.evaluate(() => window.__V2_APP__.runAnalyze());
  await page.waitForTimeout(800);
  await page.click('#btnAiPanel');
  await page.waitForTimeout(300);
  out.cases.obsPanel = await page.evaluate(() => ({ steps: document.querySelectorAll('#aiBody .ai-step').length, ctx: !!document.querySelector('#aiBody .ai-ctx'), observations: document.querySelectorAll('#aiBody .obs-card').length, dirCta: !!document.getElementById('btnGetDirections') }));
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-ai-collab-redesign-1920.png' });
} catch (e) { out.fatal = String(e && e.stack || e); } finally { try { await browser.close(); } catch (e) {} }
fs.writeFileSync(ROOT + '\\v2\\app\\_ai_panel_probe.json', JSON.stringify(out, null, 2), 'utf8');
console.log(JSON.stringify(out, null, 2));
process.exit(out.errors.length ? 1 : 0);
