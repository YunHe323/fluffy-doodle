// v2/app/test-quickstart-context.mjs —— 第一屏 quick-start + AI 上下文/成本
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8167;
const out = { schema: 'mozheng.app.quickstart-context.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-quickstart-context-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('mozheng.ai.settings.v1', JSON.stringify({ preset: 'qwen', allowReal: false, requireConfirm: true, privacyMode: true })); } catch (e) {} });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1200);
  out.cases.quick = await page.evaluate(() => ({ visible: !(document.getElementById('quickStart') || {}).hidden, text: (document.getElementById('quickStart') || {}).innerText || '', dismissed: localStorage.getItem('mozheng.quickstart.dismissed.v1') }));
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-quickstart-1920.png' });
  await page.click('[data-qs="draw"]');
  await page.waitForTimeout(300);
  out.cases.afterDraw = await page.evaluate(() => ({ hidden: !!(document.getElementById('quickStart') || {}).hidden, tool: window.__V2_APP__.state.tool, dismissed: localStorage.getItem('mozheng.quickstart.dismissed.v1') }));
  // 重新加载后不再出现（记住关闭）
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  out.cases.afterReload = await page.evaluate(() => ({ hidden: !!(document.getElementById('quickStart') || {}).hidden }));
  // AI 面板上下文/成本
  await page.evaluate(() => window.__V2_APP__.openPopover('popAI'));
  await page.waitForTimeout(400);
  out.cases.ai = await page.evaluate(() => ({ text: (document.getElementById('aiBody') || {}).innerText || '' }));
  const txt = out.cases.ai.text;
  out.cases.quickOk = out.cases.quick.visible && /从这里开始/.test(out.cases.quick.text) && out.cases.afterDraw.hidden && out.cases.afterDraw.tool === 'brush' && out.cases.afterDraw.dismissed === '1' && out.cases.afterReload.hidden;
  out.cases.contextOk = /成本/.test(txt) && /Mock/.test(txt) && /¥0/.test(txt) && /不联网/.test(txt) && /上下文/.test(txt);
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.quickOk && out.cases.contextOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
