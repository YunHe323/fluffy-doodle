# T112 最终独立 QA：AI 对话 → 行动建议 + 画像建议 + 安全加固

> 执行：qa-engineer（独立 QA｜task-126）｜日期：2026-11-07 21:3x｜只写 `v2/qa/tools/`；**未改 app**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、单浏览器串行、小批次（日志 `archive/baseline-t112-final/logs/`）；执行期内存约 2.6–2.9GB。

## 结论

**可交付（Deliverable）——P0/P1/P2 = 0。**
1 个新测试 + 3 个关联测试 + 13 项回归全 PASS、0 console error；`chat-actions` 单测 **11/11**；19 项独立焦点核验全 PASS；代理 413 预算、actions 白名单/伪造拒绝、画像开关/建议/清空、状态复位、chips 语义、composer sticky 均确认；证据 mtime 未变、无付费调用、残留 0。

> **探针修正说明（非产品问题）**：上一版 focus 有 3 项 false，复核后均为探针口径问题并已修正重跑通过：①`actionsNoAutoExecute` 的 records 基线取在 `runChat` 异步写入 L6 chat 记录之前（改取 actions 返回后基线）；②`clearChatTwoStep` 之前先测了 `clearAiMemory`（按设计已清 profile LS），该检查前改为通过 UI 重新写入画像；③`latestMessageVisible` 对不可滚动（294=294）的日志区要求 `scrollTop>0` 过严（改为「lastVisible && 可滚动时到底」）。

## 1. 新测试与关联测试（PASS）

| 测试 | 关键证据 |
|---|---|
| `test-chat-actions.mjs` | Mock 返回 actions **2 个（observe/generate）**、chips=2；点击「生成局部候选」→ 图像工作台显示、prompt 预填「保留我的笔触,只改这个区域」（只导航/prefill） |
| 同上（画像建议） | `.ai-profile-hints` 文本「**建议 · 尚未写入** … 从你的 1 次素材确认里看到：#水彩纸 #颗粒 #米色…」；点「采用建议写入画像」→ style 写入 + LS 持久化 |
| `test-ai-panel-v3.mjs` | 3 tabs/pinned/记录子页/模型 badge/长对话记忆与 reload 持久化 |
| `test-quickstart-context.mjs` | quickstart 2 动作/关闭记忆/AI 成本条 |
| `test-chat.mjs` | 对话表单→发送→回复 |
| `chat-actions-test.mjs`（Node 单测） | **11/11 passed，0 failed** |

## 2. 独立焦点核验（QA 自建探针，19/19 PASS）

| # | 检查 | 结果 |
|---|---|---|
| 1 | **代理 413 预算**（本地 token，不触发上游） | >30 messages → **413 budget**；>60,000 字符 → **413**；>2 图 → **413**；控制请求（无 confirm，走 mock）→ **200 mock** ✅ |
| 2 | actions 伪造/白名单（模块级） | 未知类型 `deleteAll` 拒绝；prompt/assetId 含 `javascript:`/脚本 → 拒绝；非白名单参数 → 拒绝；`null` → 拒绝；`normalizeChatActions` 输出 **0**；无 `__proto__` 污染 ✅ |
| 3 | **执行面只导航/prefill** | 依次点击 observe/generate/reference 三个 chip：`chat` 不变、`records` 不变、`/api/ai/*` 请求 **0**；generate → 图像 tab + prompt 预填；observe → 意图；**reference 不自动加入参考**（aiReference=null、workshopRefs 不变，仅定位素材并提示「作为 AI 参考」确认）✅ |
| 4 | 画像建议语义 | 「建议 · 尚未写入」；采用按钮写入 style + `mozheng.ai.profile.v1` ✅ |
| 5 | **画像 chip 开关** | 默认开；关闭后 `context_flags.profile=false`，Mock 回复**不含**「我记住的你是」，记录 flags.profile=false ✅ |
| 6 | **清空 AI 记忆** | chat+profile localStorage 均删除；素材库 assets、档案 records 数量不变 ✅ |
| 7 | **清空对话二次确认** | 第一次点击：chat 仍在、按钮变「再点一次确认」、armed=true；第二次：chat=0、chat LS 删除、**画像保留**（state+LS）✅ |
| 8 | AI 状态复位 | 回答完成后 `aiBusy=false`、`#aiStatus=回答完成`、取消按钮 hidden（不再卡「AI 正在回答」）✅ |
| 9 | 行动 chips 语义 | chips=3、`font-size:12px`、标签「建议 · 不会自动执行」、每个 chip 含「→ 类型」✅ |
| 10 | 最新消息/滚动 | 最后一条消息完整可见（日志区不可滚动时同样成立）✅ |
| 11 | composer sticky | `.ai-chat-form` `position:sticky`，在视口内 ✅ |
| 12 | pinned 语义 | 「本地 Mock · 选区 400×300 · **素材库 3 · 引用 0 · 档案 0** · ¥0·不联网」✅ |
| 13 | context 去 sha256 | `buildChatContext` 的 referenced 仅 `{id, fileName}`（无 sha256）✅ |
| 14 | 密钥 | DOM/localStorage/sessionStorage/已加载 JS 均无 key ✅ |
| 15 | console error | 全程 **0** ✅ |

## 3. 回归（13 项全 PASS，0 console error）

test-app、test-ui、test-library、test-image-workshop、test-multimodal、test-ux-p0、test-canvas-resize、test-text-edit、test-mask-compare、test-editor-ui、test-ai-provider、test-interaction（单跑 9/9）、test-asset-batch；连同 4 个新/关联测试共 **17/17 全部 PASS、errors=0**。

## 4. 真实证据（无新增付费调用）

| 证据 | 核对 |
|---|---|
| `asset-real-read-results.json`（mtime 17:12 未变） | pass=true；22,955ms；real / L2=5 / L4=4 |
| `qwen-real-e2e-results.json`（mtime 16:53 未变） | pass=true；21,337ms；obs=2、regions=2、mock=false |
| 本轮真实请求 | **0**；proxy 测试中 3 个超预算请求均被本地 413 拦截（未触上游），1 个控制请求走本地 mock |

## 5. 密钥 / 残留 / 本地服务

- 密钥：无 DOM/LS/SS/已加载 JS 泄漏；未打印 key。
- 残留：**Edge 0、测试端口 0**。
- `.runtime-port` = **4200**；`http://127.0.0.1:4200/health` → **200** `{ok:true,port:4200,pid:38452}`。

## 6. 问题清单

| # | 级别 | 内容 | 状态 |
|---|---|---|---|
| — | — | P0 / P1 / P2 | **均无** |

## 7. 产物与归档

- `v2/qa/tools/T112-final-qa.md`（本报告）
- `v2/qa/tools/archive/baseline-t112-final/`：`logs/`（chat-actions 单测 + 17 项测试日志）、各 result JSON、`focus-results.json`（19 项焦点核验）、真实证据 JSON、README
- GATE：`v2/qa/tools/GATE-pw.md`「T112 最终独立 QA」行
