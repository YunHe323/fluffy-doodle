/**
 * v2/library · 偏好（T70 最小）：L5 用户确认/否决 + 使用次数 → 偏好标签/权重
 * 不训练模型；仅聚合用户决策与使用，供 UI 展示"已读懂你的偏好"。
 */
const nowIso = () => new Date().toISOString();
const uid = (prefix) => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

function tagList(asset, decision) {
  const tags = Array.isArray(decision && decision.tags) ? decision.tags : (asset.tags || []).slice(0, 8);
  return [...new Set(tags.map(String).filter(Boolean))];
}

async function appendDecision(store, assetId, kind, opts = {}) {
  const asset = await store.get(assetId);
  if (!asset) return null;
  const decision = {
    id: uid(`L5-${kind}`),
    layer: 'L5',
    kind,
    source: 'user-confirmed',
    author: 'user',
    targetId: opts.targetId || null,
    tags: Array.isArray(opts.tags) ? [...new Set(opts.tags.map(String))] : (asset.tags || []).slice(0, 8),
    note: opts.note || null,
    at: nowIso(),
    anchor: { type: 'whole', value: null },
  };
  asset.L5 = [...(asset.L5 || []), decision];
  asset.source = [...new Set([...(asset.source || []), 'observed', 'inferred', 'user-confirmed'])];
  asset.updatedAt = nowIso();
  await store.put(asset);
  return decision;
}

export function confirmAsset(store, assetId, opts = {}) {
  return appendDecision(store, assetId, 'confirm', opts);
}

export function rejectAsset(store, assetId, opts = {}) {
  return appendDecision(store, assetId, 'reject', opts);
}

/** 使用次数 +1（可在 L5 留一条 use 记录，便于偏好解释） */
export async function recordUse(store, assetId, opts = {}) {
  const asset = await store.get(assetId);
  if (!asset) return null;
  const count = Math.max(1, Math.floor(Number(opts.count) || 1));
  asset.usageCount = Math.max(0, Math.floor(Number(asset.usageCount) || 0)) + count;
  asset.L5 = [...(asset.L5 || []), {
    id: uid('L5-use'),
    layer: 'L5',
    kind: 'use',
    source: 'user-confirmed',
    author: 'user',
    targetId: opts.targetId || null,
    tags: Array.isArray(opts.tags) ? opts.tags : (asset.tags || []).slice(0, 8),
    note: opts.note || null,
    at: nowIso(),
    anchor: { type: 'whole', value: null },
  }];
  asset.updatedAt = nowIso();
  await store.put(asset);
  return asset;
}

/**
 * 聚合偏好：
 *  - 每个 tag 统计 confirm/reject/use（决策可在 decision.tags 里指定目标 tag）
 *  - score = confirm*2 + use*1 - reject*2
 *  - 返回 topTags/positiveTags/negativeTags + 可展示 summary
 */
export async function getPreferences(store) {
  const assets = await store.all();
  const map = new Map();
  let decisions = 0;
  let uses = 0;
  const bump = (tag, field, n = 1) => {
    const m = map.get(tag) || { tag, confirm: 0, reject: 0, uses: 0, score: 0 };
    m[field] += n;
    map.set(tag, m);
  };
  for (const asset of assets) {
    for (const d of asset.L5 || []) {
      if (d.kind === 'use') {
        uses += 1;
        for (const t of tagList(asset, d)) bump(t, 'uses');
      } else if (d.kind === 'confirm' || d.kind === 'reject') {
        decisions += 1;
        for (const t of tagList(asset, d)) bump(t, d.kind === 'confirm' ? 'confirm' : 'reject');
      }
    }
  }
  const tags = [...map.values()].map((m) => ({
    ...m,
    score: m.confirm * 2 + m.uses * 1 - m.reject * 2,
  })).sort((a, b) => b.score - a.score || a.tag.localeCompare(b.tag));
  const positiveTags = tags.filter((t) => t.score > 0).slice(0, 8);
  const negativeTags = tags.filter((t) => t.score < 0).sort((a, b) => a.score - b.score).slice(0, 8);
  const summary = tags.length === 0
    ? '还没有足够的偏好——确认/否决素材或使用素材后会逐渐形成。'
    : `已读懂偏好：${positiveTags.map((t) => t.tag).slice(0, 4).join('、') || '（暂无正向标签）'}`
      + (negativeTags.length ? `；避免：${negativeTags.map((t) => t.tag).slice(0, 3).join('、')}` : '');
  return {
    schema: 'mozheng.library.preferences.v1',
    updatedAt: nowIso(),
    totalAssets: assets.length,
    decisions,
    uses,
    topTags: tags.slice(0, 12),
    positiveTags,
    negativeTags,
    summary,
  };
}

/** 清空所有素材上的 L5 决策与使用次数（偏好重置） */
export async function resetPreferences(store) {
  const assets = await store.all();
  for (const asset of assets) {
    asset.L5 = [];
    asset.usageCount = 0;
    asset.updatedAt = nowIso();
    await store.put(asset);
  }
  return assets.length;
}
