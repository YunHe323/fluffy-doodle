# T115 最终独立 QA：非破坏调整层（参数化栅格层）

> 执行：qa-engineer（独立 QA｜task-129）｜日期：2026-11-07 22:1x｜只写 `v2/qa/tools/`；**未改 app**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、单浏览器串行、小批次（日志 `archive/baseline-t115-final/logs/`）。

## 结论

**可交付（Deliverable）——P0/P1/P2 = 0。**
新测试 `test-adjust-layer` PASS；8 项回归全 PASS、0 console error；**12 项独立焦点核验全 PASS**：源层像素不变、取消不改变、同层更新（像素变化）、reload 保留 kind/adjust、删除源层可读报错不崩、保存/PSD 正常、调整 badge、undo 事实（像素可撤销、参数 meta 不入 undo）、密钥/残留；证据 mtime 未变、无付费调用。

## 1. 新测试 `test-adjust-layer`（PASS）

- 画一笔 → 图像调整 → 生成 `kind:'adjust'` 层：layers **2→3**、adjust `{brightness:0.22,contrast:0.12,saturation:1.08,hue:4}`、`meta.adjustSource.sourceLayerId=layer-2`、bounds `[479,318,182,123]`
- 重开预填：brightness=`22`、名称「调整 · 图层 2（调整层 · 参数可重开）」
- 更新 brightness→0.35：图层数不变（3）、kind=adjust、L6 update 记录=1
- `serializeDoc→loadProjectText`：kind/adjust 保留（brightness 0.35）、doc 含 `"kind":"adjust"` 与 `"adjust"`
- 0 error

## 2. 独立焦点核验（12/12 PASS）

| # | 检查 | 结果 |
|---|---|---|
| 1 | **源层像素不变** | 源层 `getLayerDataUrl` 创建前后**完全相同**；隐藏调整层后合成图与创建前 **diff=0** ✅ |
| 2 | **调整层创建** | layers 2→3、`kind=adjust`、参数正确、`meta.adjustSource{sourceLayerId,bounds}`、L6 `action=create non_destructive=true` ✅ |
| 3 | **调整 badge** | 图层面板含「调整」badge / 层名「调整 · …」 ✅ |
| 4 | **取消不改变** | 打开调整 → 改 brightness=77 → 关闭：层数 3→3、adjust 参数不变、源层 URL 不变 ✅ |
| 5 | **同层更新** | 重开预填 22 → brightness 35：层数仍 3、**层 id 不变**、adjust.brightness=0.35、**像素 diff=2,837**、L6 create+update、`non_destructive=true` ✅ |
| 6 | **参数预填** | brightness=22、名称「调整 · 图层 2（调整层 · 参数可重开）」 ✅ |
| 7 | **undo 事实** | undo 成功：像素可撤销（层像素 URL 变化）、`kind` 仍 adjust、**参数仍 0.35（meta 不入 undo，符合已知限制）**；无崩溃 ✅ |
| 8 | **reload 持久化** | `serializeDoc→loadProjectText` 后 layers=3、kind=adjust、adjust=0.35、meta.adjustSource 保留、doc 含 adjust ✅ |
| 9 | **保存 .mozheng** | `saveProjectAsync` → blob **27,039 B**、compressed=true；再 load 正常 ✅ |
| 10 | **PSD 导出** | `exportPsdAsync` → **278,490 B**、head `8BPS`；导出后 reload 仍 3 层/参数保留，无异常 ✅ |
| 11 | **删除源层** | 删源层后 layers 2；对调整层重开（预填 35）并应用 → **toast「调整层的源图层已被删除，无法重算参数」**、层数不变、不崩、0 console error ✅ |
| 12 | **密钥 / console** | DOM/LS/SS/已加载 JS 无 key；全程 **0 console error** ✅ |

> 已知限制（记录，非问题）：方案 B 为快照语义，源层后续修改不自动更新调整层；`adjust` 参数 meta 不进入 undo（仅像素可撤销）——与实现说明一致。

## 3. 回归（8 项全 PASS，0 console error）

test-editor-ui、test-app、test-ui、test-canvas-resize、test-text-edit、test-library、test-chat-actions、test-ai-provider。

## 4. 真实证据 / 费用（无新增付费调用）

| 证据 | 核对 |
|---|---|
| `asset-real-read-results.json`（mtime 17:12 未变） | pass=true；22,955ms；real / L2=5 / L4=4 |
| `qwen-real-e2e-results.json`（mtime 16:53 未变） | pass=true；21,337ms；obs=2、regions=2、mock=false |
| 本轮真实请求 | **0**（纯本地 UI/引擎/PSD 操作） |

## 5. 密钥 / 残留 / 本地服务

- 密钥：无 DOM/LS/SS/已加载 JS 泄漏；未打印 key。
- 残留：**Edge 0、测试端口 0**。
- `.runtime-port` = **4200**；`http://127.0.0.1:4200/health` → **200** `{ok:true,port:4200,pid:38452}`。

## 6. 问题清单

| # | 级别 | 内容 | 状态 |
|---|---|---|---|
| — | — | P0 / P1 / P2 | **均无** |
| 说明 | — | 方案 B 快照语义 / adjust 参数不进 undo | 与实现说明一致，记录不阻塞 |

## 7. 产物与归档

- `v2/qa/tools/T115-final-qa.md`（本报告）
- `v2/qa/tools/archive/baseline-t115-final/`：`logs/`（9 项测试日志）、各 result JSON、`focus-results.json`（12 项焦点核验）、真实证据 JSON、README
- GATE：`v2/qa/tools/GATE-pw.md`「T115 最终独立 QA」行
