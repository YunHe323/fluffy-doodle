#!/usr/bin/env node
/**
 * v2/qa/tools/app-ai-qa.mjs —— T97 B 节：app 模型接入独立 QA（headless、独立端口、假上游、0 残留）
 *
 * 覆盖：设置保存/脱敏/测试连接；手动确认取消（不发请求/不写记录）；确认后调用成功；
 *       provider/model/latency/usage 进 L6；无 key/隐私模式降级 Mock；401/429/超时提示；密钥不在前端可读位置。
 * 输出：v2/qa/tools/app-ai-qa-results.json
 */
import { spawn } from 'node:child_process';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..', '..', '..');
const require = createRequire(import.meta.url);
const TOKEN = 't97-qa-token';
const UPSTREAM_PORT = 8141;
const APP_PORT = 8142;
const SECRET = 'sk-t97-qa-secret-3f9';
const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Z4z8AAAAASUVORK5CYII=';
const out = { schema: 'mozheng.qa.app-ai.v1', at: new Date().toISOString(), checks: {}, details: {}, errors: [] };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const check = (k, ok, detail) => { out.checks[k] = !!ok; if (!ok) out.details[k] = detail; };

// ---- 假上游（可控模式）----
let fakeMode = 'ok';
const counts = { chat: 0, image: 0 };
let lastChat = null;
const fakePayload = {
  global: { summary: 'QA 上游返回的低饱和山谷。', subject: ['山', '雾'], medium: { kind: 'digital', detail: 'painting' }, palette: ['#7f97a8', '#4f6778', '#e4ebee'], mood: ['安静'] },
  regions: [{ id: 'r-qa-1', label: '远山', bbox: [100, 80, 500, 300], importance: 0.8, confidence: 0.7 }],
  observations: [{ id: 'o-qa-1', kind: 'observation', text: '雾带是视线停留处。', anchor: { type: 'bbox', value: [100, 80, 500, 300] }, bbox: [100, 80, 500, 300], confidence: 0.7, evidenceRefs: [] }],
  directions: [{ id: 'd-qa-1', title: '保留雾带留白', why: '右侧更安静', confidence: 0.7, tags: ['留白'] }],
  candidates: [{ id: 'c-qa-1', label: '局部方案 A', why: '保持雾带', imageDataUrl: 'data:image/png;base64,' + PNG, width: 1, height: 1 }],
  confidence: 0.7,
};
const fake = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => { body += c; });
  req.on('end', () => {
    const send = (code, obj, delay = 0) => setTimeout(() => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); }, delay);
    if (req.url === '/__mode') { fakeMode = String(body || 'ok').trim(); res.writeHead(200); res.end('ok'); return; }
    if (req.url && req.url.includes('/chat/completions')) {
      counts.chat += 1; try { lastChat = JSON.parse(body || '{}'); } catch (e) { /* ignore */ }
      if (fakeMode === '401') return send(401, { error: { message: 'bad key' } }, 30);
      if (fakeMode === '429') return send(429, { error: { message: 'rate limit' } }, 30);
      if (fakeMode === 'slow') return send(200, { id: 'slow', model: 'fake', choices: [{ message: { content: JSON.stringify(fakePayload) } }], usage: { prompt_tokens: 120, completion_tokens: 80, total_tokens: 200 } }, 1500);
      return send(200, { id: 'chatcmpl-qa', model: 'kimi-k3.1-pro', choices: [{ index: 0, message: { role: 'assistant', content: JSON.stringify(fakePayload) } }], usage: { prompt_tokens: 120, completion_tokens: 80, total_tokens: 200 } }, 20);
    }
    if (req.url && req.url.includes('/images/generations')) {
      counts.image += 1;
      if (fakeMode === '401') return send(401, { error: { message: 'bad key' } }, 30);
      return send(200, { created: 1, model: 'hy-image-v3.0', data: [{ b64_json: PNG }], usage: { images: 1 } }, 30);
    }
    res.writeHead(200); res.end('{}');
  });
});
await new Promise((r) => fake.listen(UPSTREAM_PORT, '127.0.0.1', r));

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mozheng-t97-'));
const configPath = path.join(tmp, 'ai-config.json');
const tokenPath = path.join(tmp, 'ai-token');
const serve = spawn(process.execPath, [path.join(ROOT, 'v2', 'serve.mjs')], {
  cwd: ROOT, env: { ...process.env, PORT: String(APP_PORT), AI_LOCAL_TOKEN: TOKEN, AI_CONFIG_PATH: configPath, AI_TOKEN_PATH: tokenPath }, stdio: 'ignore',
});
let appPort = null;
for (let i = 0; i < 100 && !appPort; i += 1) {
  for (let p = APP_PORT; p <= APP_PORT + 6; p += 1) { try { const r = await fetch(`http://127.0.0.1:${p}/health`); if (r.ok) { appPort = p; break; } } catch (e) { /* ignore */ } }
  if (!appPort) await sleep(150);
}
if (!appPort) { console.error('[aiqa] serve 未启动'); process.exit(2); }
let browser = null;
const finish = async (code = 0) => {
  try { fs.writeFileSync(path.join(__dirname, 'app-ai-qa-results.json'), JSON.stringify(out, null, 2), 'utf8'); } catch (e) { /* ignore */ }
  try { browser && await browser.close(); } catch (e) { /* ignore */ }
  try { serve.kill(); } catch (e) { /* ignore */ }
  try { fake.close(); } catch (e) { /* ignore */ }
  try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  console.log('[aiqa] ' + (out.pass ? 'PASS' : 'FAIL') + ' ' + Object.values(out.checks).filter(Boolean).length + '/' + Object.keys(out.checks).length);
  if (!out.pass) console.log('[aiqa] failed: ' + JSON.stringify(Object.entries(out.checks).filter(([k, v]) => !v).map(([k]) => k)));
  process.exit(code);
};
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_420s'; finish(3); }, 420000);
try {
  const { chromium } = require('playwright-core');
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-position=-3000,-3000'] });
  const context = await browser.newContext({ viewport: { width: 1366, height: 768 }, acceptDownloads: true, deviceScaleFactor: 1 });
  if (process.env.QA_INJECT_TOKEN) await context.addInitScript((token) => { window.__AI_LOCAL_TOKEN__ = token; }, TOKEN);   // T99 后默认不注入，验证正常 serve
  const page = await context.newPage();
  page.setDefaultTimeout(120000);
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|status of 404/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  const api = (p, b, h = {}) => page.evaluate(async ({ p, b, h }) => {
    const headers = { 'x-ai-token': window.__AI_LOCAL_TOKEN__, ...h };
    const r = await fetch(p, { method: b === undefined ? 'GET' : 'POST', headers: { ...headers, ...(b === undefined ? {} : { 'content-type': 'application/json' }) }, body: b === undefined ? undefined : JSON.stringify(b) });
    const text = await r.text(); let json = null; try { json = JSON.parse(text); } catch (e) { /* ignore */ }
    return { status: r.status, json, text: text.slice(0, 400) };
  }, { p, b, h });
  const setMode = (m) => fetch(`http://127.0.0.1:${UPSTREAM_PORT}/__mode`, { method: 'POST', body: m });
  const jclick = (sel) => page.evaluate((q) => { const el = document.querySelector(q); if (el) el.click(); else throw new Error('missing ' + q); }, sel);
  const openAbout = async () => { await page.evaluate(() => window.__V2_APP__.closePopovers && window.__V2_APP__.closePopovers()); await sleep(100); await page.evaluate(() => document.getElementById('btnMore').click()); await sleep(120); await page.evaluate(() => document.getElementById('btnAbout').click()); await sleep(350); };
  const closeModals = async () => { await page.evaluate(() => window.__V2_APP__.closePopovers && window.__V2_APP__.closePopovers()); await sleep(150); };

  await page.goto(`http://127.0.0.1:${appPort}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', { timeout: 60000 });
  await page.waitForTimeout(1200);
  await page.evaluate(() => window.__V2_APP__.t96 && window.__V2_APP__.t96.refreshConfig());
  await page.waitForTimeout(400);
  out.details.defaults = await page.evaluate(() => ({ state: window.__V2_APP__.t96.getState(), settings: window.__V2_APP__.t96.getSettings(), presets: Object.keys(window.__V2_APP__.t96.getPresets()) }));

  // 1) 默认（无 key/privacy）→ mock 降级：分析不弹确认、L6 mock
  let l6Before = await page.evaluate(() => window.__V2_APP__.t96.getL6AiCalls().length);
  let chatBefore = counts.chat;
  out.details.mockAnalyze = await page.evaluate(async () => {
    const a = window.__V2_APP__; const res = await a.runAnalyze({}); return { ok: !!(res), obs: res ? (res.observations || []).length : 0, confirmShown: document.getElementById('aiConfirmModal').classList.contains('show'), meta: a.t96.getLastCall(), l6: a.t96.getL6AiCalls().slice(-1)[0], badge: a.t96.providerBadge() };
  });
  check('defaultMockAnalyze', !!(out.details.mockAnalyze.ok) && out.details.mockAnalyze.meta && out.details.mockAnalyze.meta.mock === true && counts.chat === chatBefore);
  check('defaultMockL6', !!(out.details.mockAnalyze.l6) && !!(out.details.mockAnalyze.l6.params) && out.details.mockAnalyze.l6.params.mock === true && (out.details.mockAnalyze.l6.model || {}).provider === 'mock');

  // 2) 设置面板：打开/结构/保存/脱敏
  await openAbout();
  out.details.settingsUi = await page.evaluate(() => ({ card: !!document.getElementById('aiAccessCard'), provider: document.getElementById('aiProviderSelect').value, keyState: document.getElementById('aiKeyState').textContent, privacy: document.getElementById('aiPrivacyMode').checked, allow: document.getElementById('aiAllowReal').checked }));
  check('settingsUiVisible', out.details.settingsUi.card === true);
  await page.evaluate(() => document.getElementById('aiAllowReal').click());
  await page.evaluate(() => document.getElementById('aiPrivacyMode').click());
  await page.selectOption('#aiProviderSelect', 'moonshot');
  await page.fill('#aiBaseUrl', `http://127.0.0.1:${UPSTREAM_PORT}/v1`);
  await page.fill('#aiModel', 'kimi-k3.1-pro');
  await page.fill('#aiKeyInput', SECRET);
  await jclick('#btnAiSave');
  await page.waitForTimeout(900);
  out.details.save = await page.evaluate(async () => {
    const token = window.__AI_LOCAL_TOKEN__;
    const r = await fetch('/api/ai/config', { headers: { 'x-ai-token': token } });
    const cfg = await r.json();
    return {
      status: (document.getElementById('aiTestStatus') || {}).textContent,
      keyInput: (document.getElementById('aiKeyInput') || {}).value,
      keyState: (document.getElementById('aiKeyState') || {}).textContent,
      cfg,
      domHasSecret: document.documentElement.innerHTML.includes('sk-t97-qa-secret-3f9'),
      lsHasSecret: JSON.stringify(localStorage).includes('sk-t97-qa-secret-3f9'),
      settings: window.__V2_APP__.t96.getSettings(),
    };
  });
  check('settingsSaved', /已保存/.test(out.details.save.status || '') && out.details.save.cfg && out.details.save.cfg.ok === true);
  check('keyRedacted', out.details.save.keyInput === '' && !out.details.save.domHasSecret && !out.details.save.lsHasSecret && out.details.save.cfg.hasKey === true && out.details.save.cfg.mode === 'real' && out.details.save.cfg.providers.moonshot.hasKey === true && out.details.save.cfg.providers.moonshot.keyLast4 === '-3f9');
  check('keyLast4Shown', /末|已配置|Key/.test(out.details.save.keyState || ''));

  // 3) 测试连接（真实 fake 上游）
  await jclick('#btnAiTest');
  await page.waitForTimeout(700);
  out.details.testReal = await page.evaluate(() => ({ status: document.getElementById('aiTestStatus').textContent }));
  check('testConnectionReal', /连接成功/.test(out.details.testReal.status || '') && /mock|real|ms/.test(out.details.testReal.status || ''));

  // 4) 手动确认取消：不发请求、不写记录
  await setMode('ok');
  await closeModals();
  chatBefore = counts.chat; l6Before = await page.evaluate(() => window.__V2_APP__.t96.getL6AiCalls().length);
  await page.evaluate(() => { window.__V2_APP__.runAnalyze({}); });
  await page.waitForTimeout(450);
  out.details.confirmModal = await page.evaluate(() => ({ show: document.getElementById('aiConfirmModal').classList.contains('show'), text: (document.getElementById('aiConfirmText') || {}).textContent || '', provider: window.__V2_APP__.t96.providerBadge() }));
  check('confirmModalShown', out.details.confirmModal.show === true && out.details.confirmModal.text.length > 0);
  await jclick('#btnAiConfirmCancel');
  await page.waitForTimeout(700);
  out.details.cancel = await page.evaluate(() => ({ show: document.getElementById('aiConfirmModal').classList.contains('show'), l6: window.__V2_APP__.t96.getL6AiCalls().length, toast: [...document.querySelectorAll('.toast')].map((x) => x.textContent).join(' '), status: document.getElementById('aiStatus').textContent }));
  out.details.cancel.chatDelta = counts.chat - chatBefore;
  out.details.cancel.l6Delta = out.details.cancel.l6 - l6Before;
  check('confirmCancelNoRequest', out.details.cancel.chatDelta === 0);
  check('confirmCancelNoRecord', out.details.cancel.l6Delta === 0 && out.details.cancel.show === false);

  // 5) 确认 → 真实调用成功；L6 记录 provider/model/latency/usage
  await closeModals();
  chatBefore = counts.chat;
  await page.evaluate(() => { window.__V2_APP__.runAnalyze({}); });
  await page.waitForTimeout(400);
  await jclick('#btnAiConfirmOk');
  await page.waitForTimeout(1600);
  out.details.real = await page.evaluate(() => { const a = window.__V2_APP__; const l6 = a.t96.getL6AiCalls().slice(-1)[0]; return { analysis: !!a.state.analysis, obs: a.state.analysis ? a.state.analysis.observations.length : 0, meta: a.t96.getLastCall(), badge: a.t96.providerBadge(), l6, status: (document.getElementById('aiStatus') || {}).textContent }; });
  out.details.real.chatDelta = counts.chat - chatBefore;
  check('realCallSucceeded', out.details.real.chatDelta === 1 && out.details.real.obs > 0);
  const l6 = out.details.real.l6 || {};
  const l6params = l6.params || {};
  check('l6Fields', !!(l6.model) && l6.model.provider === 'moonshot' && l6.model.model === 'kimi-k3.1-pro' && typeof l6params.latency_ms === 'number' && !!(l6params.usage) && l6params.usage.total_tokens === 200 && l6params.mock === false, { model: l6.model, params: { latency_ms: l6params.latency_ms, usage: l6params.usage } });

  // 6) 隐私模式 → 强制 Mock（即使有 key）
  chatBefore = counts.chat;
  await page.evaluate(() => { document.getElementById('aiPrivacyMode').click(); });
  await jclick('#btnAiSave'); await page.waitForTimeout(700);
  await page.evaluate(() => { window.__V2_APP__.runAnalyze({}); });
  await page.waitForTimeout(1200);
  out.details.privacy = await page.evaluate(() => ({ meta: window.__V2_APP__.t96.getLastCall(), badge: window.__V2_APP__.t96.providerBadge(), confirmShown: document.getElementById('aiConfirmModal').classList.contains('show') }));
  out.details.privacy.chatDelta = counts.chat - chatBefore;
  check('privacyForcesMock', out.details.privacy.chatDelta === 0 && out.details.privacy.meta && out.details.privacy.meta.mock === true);

  // 7) 无 key 降级：清除 key 后真实调用回退 Mock
  await openAbout();
  await page.evaluate(() => { document.getElementById('aiPrivacyMode').click(); }); // 关隐私
  await jclick('#btnAiClearKey'); await page.waitForTimeout(700);
  const cfgNoKey = await api('/api/ai/config');
  chatBefore = counts.chat;
  await closeModals();
  await page.evaluate(() => { window.__V2_APP__.runAnalyze({}); });
  await page.waitForTimeout(1200);
  out.details.noKey = await page.evaluate(() => ({ meta: window.__V2_APP__.t96.getLastCall(), badge: window.__V2_APP__.t96.providerBadge(), keyState: document.getElementById('aiKeyState').textContent }));
  out.details.noKey.chatDelta = counts.chat - chatBefore;
  check('noKeyFallsBackMock', cfgNoKey.json && cfgNoKey.json.hasKey === false && out.details.noKey.meta && out.details.noKey.meta.mock === true && out.details.noKey.chatDelta === 0);

  out.errorsBeforeErrorTests = out.errors.length;   // 注入错误前的控制台错误数（应为 0）
  // 8) 401 / 429 / 超时提示（真实配置 + fake 上游故障）
  const configureReal = async (model = 'kimi-k3.1-pro', key = SECRET) => {
    await openAbout();
    await page.selectOption('#aiProviderSelect', 'moonshot');
    await page.fill('#aiBaseUrl', `http://127.0.0.1:${UPSTREAM_PORT}/v1`);
    await page.fill('#aiModel', model);
    await page.fill('#aiKeyInput', key);
    await page.evaluate(() => { const p = document.getElementById('aiPrivacyMode'); if (p.checked) p.click(); const a = document.getElementById('aiAllowReal'); if (!a.checked) a.click(); });
    await jclick('#btnAiSave'); await page.waitForTimeout(900);
    await closeModals();
  };
  for (const mode of ['401', '429']) {
    await setMode(mode);
    await configureReal();
    await page.evaluate(() => { window.__V2_APP__.runAnalyze({}); });
    await page.waitForTimeout(400);
    await jclick('#btnAiConfirmOk').catch(() => {});
    await page.waitForTimeout(1400);
    out.details['err' + mode] = await page.evaluate(() => ({ meta: window.__V2_APP__.t96.getLastCall(), toast: [...document.querySelectorAll('.toast')].map((x) => x.textContent).join(' '), status: document.getElementById('aiStatus').textContent, ready: !!window.__V2_APP_READY__ }));
    check('error' + mode + 'Notice', out.details['err' + mode].ready === true && /失败|错误|鉴权|限流|稍后|重试|token|key/i.test((out.details['err' + mode].meta && (out.details['err' + mode].meta.error || '')) + ' ' + out.details['err' + mode].toast + ' ' + out.details['err' + mode].status));
  }
  // 超时：重新配置真实 provider（此前已清 key）+ server timeoutMs 800 + slow 上游 1500ms
  await setMode('slow');
  await configureReal();
  await page.evaluate(async () => { const token = window.__AI_LOCAL_TOKEN__; await fetch('/api/ai/config', { method: 'POST', headers: { 'x-ai-token': token, 'content-type': 'application/json' }, body: JSON.stringify({ timeoutMs: 800, mode: 'real', provider: 'moonshot', model: 'kimi-k3.1-pro' }) }); });
  const chatBeforeTimeout = counts.chat;
  await page.evaluate(() => { window.__V2_APP__.runAnalyze({}); });
  await page.waitForTimeout(500);
  await page.evaluate(() => { const el = document.getElementById('btnAiConfirmOk'); if (el) el.click(); }).catch(() => {});
  await page.waitForTimeout(4500);
  out.details.timeout = await page.evaluate(() => ({ meta: window.__V2_APP__.t96.getLastCall(), toast: [...document.querySelectorAll('.toast')].map((x) => x.textContent).join(' '), aiStatus: (document.getElementById('aiStatus') || {}).textContent, ready: !!window.__V2_APP_READY__ }));
  out.details.timeout.chatDelta = counts.chat - chatBeforeTimeout;
  check('timeoutNotice', out.details.timeout.ready === true && out.details.timeout.chatDelta >= 1 && (/超时|timeout/i.test(JSON.stringify(out.details.timeout)) || (out.details.timeout.meta && out.details.timeout.meta.status === 'error')));
  await setMode('ok');

  const expectedErrRe = /Failed to load resource: the server responded with a status of (401|429|504)|AIProviderError: /;
  out.expectedErrors = out.errors.filter((e) => expectedErrRe.test(e));
  out.unexpectedErrors = out.errors.filter((e) => !expectedErrRe.test(e));
  check('noConsoleErrors', out.errorsBeforeErrorTests === 0 && out.unexpectedErrors.length === 0);
  out.pass = Object.values(out.checks).every(Boolean);
} catch (e) {
  out.fatal = String(e.stack || e.message || e);
  out.pass = false;
} finally { clearTimeout(hard); await finish(out.pass ? 0 : 1); }
