// product/test/mock-ai.test.mjs
import test from 'node:test';
import assert from 'node:assert/strict';

import {
  mockAnalyze, mockDirections, mockGenerate, mockConfig, MOCK_MODEL,
} from '../core/mock-ai.mjs';

const CANVAS = {
  dataUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
  width: 1024,
  height: 768,
  layerCount: 3,
};

const BASE_INPUT = {
  canvas: CANVAS,
  selection: { mode: 'rect', rect: { x: 200, y: 120, width: 300, height: 260 } },
  context: { mode: 'collab', aiRole: 'assistant', userNote: '袖口有点闷' },
};

test('analyze：确定性（同输入同输出）', () => {
  const a = mockAnalyze(BASE_INPUT);
  const b = mockAnalyze(BASE_INPUT);
  assert.deepEqual(a, b);
  assert.equal(a.model, MOCK_MODEL);
  assert.match(a.seed, /^[0-9a-f]{24}$/);
});

test('analyze：输入变化（userNote）→ 输出变化', () => {
  const a = mockAnalyze(BASE_INPUT);
  const b = mockAnalyze({ ...BASE_INPUT, context: { ...BASE_INPUT.context, userNote: '换一句' } });
  assert.notEqual(a.seed, b.seed);
  assert.notDeepEqual(a.observations, b.observations);
});

test('analyze：结构符合契约（L1 子集 + L2 + L4）', () => {
  const { global, regions, observations, confidence } = mockAnalyze(BASE_INPUT);

  // L1 子集
  assert.equal(typeof global.summary, 'string');
  assert.ok(Array.isArray(global.subject));
  assert.ok(['digital_painting', 'watercolor', 'oil', 'ink', 'pencil', 'lineart', 'mixed', 'photography', '3d', 'other'].includes(global.medium.kind));
  assert.ok(Array.isArray(global.palette) && global.palette.length >= 2);
  for (const color of global.palette) assert.match(color.hex, /^#[0-9a-f]{6}$/);
  assert.ok(Array.isArray(global.mood));

  // L2：1–3 个，bbox 合法
  assert.ok(regions.length >= 1 && regions.length <= 3);
  for (const region of regions) {
    assert.match(region.id, /^L2-mock-\d{3}$/);
    assert.equal(region.anchor.type, 'bbox');
    assert.deepEqual(region.anchor.value, region.bbox);
    assert.equal(region.bbox.length, 4);
    const [x, y, w, h] = region.bbox;
    assert.ok(x >= 0 && y >= 0 && w > 0 && h > 0);
    assert.ok(x + w <= 1024 && y + h <= 768, `region 越界: ${region.bbox}`);
    assert.ok(region.confidence >= 0 && region.confidence <= 1);
  }

  // L4：2–4 条；AI 观察必须带证据
  assert.ok(observations.length >= 2 && observations.length <= 4);
  const regionIds = new Set(regions.map((r) => r.id));
  for (const observation of observations) {
    assert.match(observation.id, /^L4-mock-\d{3}$/);
    assert.equal(observation.layer, 'L4');
    assert.equal(observation.source, 'inferred');
    assert.equal(observation.author, 'ai');
    assert.ok(['observation', 'association', 'question', 'teaching'].includes(observation.kind));
    assert.equal(observation.evidenceRefs.length, 1);
    assert.ok(regionIds.has(observation.evidenceRefs[0]));
    assert.ok(observation.confidence >= 0 && observation.confidence <= 1);
    assert.equal(observation.modelVersion, MOCK_MODEL);
  }
  assert.ok(confidence >= 0 && confidence <= 1);
});

test('directions：数量 2–3、id 唯一、确定性', () => {
  const two = mockDirections(BASE_INPUT);
  assert.equal(two.directions.length, 2);

  const three = mockDirections({ ...BASE_INPUT, count: 3 });
  assert.equal(three.directions.length, 3);
  assert.equal(new Set(three.directions.map((d) => d.id)).size, 3);
  for (const direction of three.directions) {
    assert.match(direction.id, /^dir-mock-\d{2}$/);
    assert.equal(typeof direction.title, 'string');
    assert.equal(typeof direction.why, 'string');
    assert.ok(Array.isArray(direction.tags));
  }

  assert.deepEqual(mockDirections({ ...BASE_INPUT, count: 3 }), three);
  // 越界裁剪
  assert.equal(mockDirections({ ...BASE_INPUT, count: 1 }).directions.length, 2);
  assert.equal(mockDirections({ ...BASE_INPUT, count: 99 }).directions.length, 3);
});

test('generate：确定性 SVG dataURL、尺寸、候选数', () => {
  const input = { ...BASE_INPUT, directionId: 'dir-mock-01', count: 2, size: { width: 512, height: 384 } };
  const a = mockGenerate(input);
  const b = mockGenerate(input);
  assert.deepEqual(a, b);
  assert.equal(a.credits, 0);
  assert.equal(a.candidates.length, 2);
  for (const candidate of a.candidates) {
    assert.match(candidate.id, /^cand-mock-\d{2}$/);
    assert.equal(candidate.width, 512);
    assert.equal(candidate.height, 384);
    assert.ok(candidate.imageDataUrl.startsWith('data:image/svg+xml;base64,'));
    const svg = Buffer.from(candidate.imageDataUrl.split(',')[1], 'base64').toString('utf8');
    assert.ok(svg.startsWith('<svg'));
    assert.ok(svg.includes('width="512"'));
  }
  // count 越界
  assert.equal(mockGenerate({ ...input, count: 0 }).candidates.length, 1);
  assert.equal(mockGenerate({ ...input, count: 10 }).candidates.length, 3);
  // 尺寸缺省 = 选区尺寸（但夹到 256–2048）
  const defaultSize = mockGenerate({ ...BASE_INPUT, directionId: 'dir-mock-01' });
  assert.equal(defaultSize.candidates[0].width, 300);
  assert.equal(defaultSize.candidates[0].height, 260);
});

test('generate：缺少 directionId 抛错', () => {
  assert.throws(() => mockGenerate(BASE_INPUT), /directionId/);
});

test('mockConfig 默认 mock 且无密钥', () => {
  assert.deepEqual(mockConfig(), { provider: 'mock', baseUrl: '', model: '', apiKeySet: false });
});
