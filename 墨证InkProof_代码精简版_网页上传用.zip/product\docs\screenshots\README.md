# Screenshots

Product screenshots live here. They must be taken from the **actual product** using the built-in **sample project** path (open product → Load Sample Project → walk the main flow). No prototype links, no separate demo product.

Expected files (to be added before the v0.1.0 release):

| File | Scene |
|---|---|
| `canvas-sample.png` | Canvas + layers after loading the sample project |
| `stuck-observations.png` | “Let AI take a look” panel with observations & directions |
| `archive-cards.png` | Archive cards with source / confidence / anchor |
| `evidence-export.png` | Evidence package preview (manifest + hash chain) |
| `one-click-demo.png` | One-click demo control layer (step n/8, pause/next/exit) |

Temporary/working screenshots can go to `docs/screenshots/tmp/` (gitignored).
