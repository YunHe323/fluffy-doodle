// v2/brushes/test-demo.mjs — 冒烟测试 demo.html：加载、切换 10 笔刷、pointer 绘制、截图
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const python = spawn('python', ['-m', 'http.server', '8100', '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
await sleep(900);
const profile = path.join(os.tmpdir(), 'brushtest-' + Date.now());
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
  '--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist',
  '--window-size=1700,1000', '--hide-scrollbars',
  '--remote-debugging-port=9406', `--user-data-dir=${profile}`,
  'http://127.0.0.1:8100/v2/brushes/demo.html'], { stdio: 'ignore' });
let target = null;
for (let i = 0; i < 200 && !target; i++) {
  try { const r = await fetch('http://127.0.0.1:9406/json/list'); target = (await r.json()).find((t) => t.type === 'page'); } catch (e) {}
  if (!target) await sleep(150);
}
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map(); const errors = [];
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); return; }
  if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text);
  if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push(m.params.args.map((a) => a.value || a.description).join(' '));
};
const send = (method, params = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
async function ev(expression) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true });
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1200));
  return r.result?.result?.value;
}
try {
  await send('Runtime.enable');
  for (let i = 0; i < 600; i++) { if (await ev('!!window.__BRUSH_READY__').catch(() => false)) break; await sleep(200); }
  const ready = await ev('!!window.__BRUSH_READY__');
  console.log('ready:', ready);
  await ev('window.__BRUSH_DEMO__.engine.compositor.compositeAll(window.__BRUSH_DEMO__.engine.store)');
  const rect = await ev('(() => { const r = document.getElementById("stage").getBoundingClientRect(); return {x:r.x,y:r.y,w:r.width,h:r.height}; })()');
  // 切换笔刷 & 绘制 3 条
  const strokes = [0, 5, 8]; // hard-round, charcoal, watercolor
  for (const bi of strokes) {
    await ev(`document.querySelectorAll('.brushBtn')[${bi}].click()`);
    const pts = [];
    for (let k = 0; k <= 24; k += 1) pts.push({ cx: rect.x + rect.w * (0.2 + 0.55 * (k / 24)), cy: rect.y + rect.h * (0.3 + 0.12 * bi) , t: k });
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: pts[0].cx, y: pts[0].cy, button: 'left', clickCount: 1, pointerType: 'mouse' });
    for (let k = 1; k < pts.length; k += 1) {
      await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: pts[k].cx, y: pts[k].cy, button: 'left', buttons: 1, pointerType: 'mouse' });
    }
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: pts[pts.length - 1].cx, y: pts[pts.length - 1].cy, button: 'left', clickCount: 1, pointerType: 'mouse' });
    await sleep(120);
  }
  const result = await ev(`(() => {
    const d = window.__BRUSH_DEMO__; const s = d.engine.getStats();
    const btns = document.querySelectorAll('.brushBtn').length;
    const sliders = document.querySelectorAll('#studioBody input[type=range]').length;
    const status = document.getElementById('status').textContent;
    const err = document.getElementById('err').textContent;
    return { btns, sliders, status, errText: err, layers: s.layers, tileCount: s.tileCount, undoDepth: s.undoDepth, jsHeapMB: s.jsHeapMB, gpu: String(s.gpuRenderer||'').slice(0,40), brush: d.controller.preset.id };
  })()`);
  console.log('result:', JSON.stringify(result));
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  const out = path.join(ROOT, 'v2', 'brushes', 'demo-screenshot.png');
  fs.writeFileSync(out, Buffer.from(shot.result.data, 'base64'));
  console.log('screenshot:', out);
  console.log('errors:', JSON.stringify(errors.slice(0, 8)));
} catch (e) { console.log('FATAL', e.stack || e); }
finally { try { ws.close(); } catch (e) {} chrome.kill(); python.kill(); await sleep(400); try { fs.rmSync(profile, {recursive:true,force:true}); } catch (e) {} process.exit(0); }
