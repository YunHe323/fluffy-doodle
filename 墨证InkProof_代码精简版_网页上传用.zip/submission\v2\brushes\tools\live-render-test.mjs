/**
 * v2/brushes/tools/live-render-test.mjs
 * T43/T44 真实浏览器验收：拖动过程中可见 + 松手提交正确 + 再画不白板 + 实时/提交一致性。
 *
 * 对 10 种笔刷逐个执行：
 *   1. 按下并移动（不松手）→ 截图分析「画布区域墨迹像素」= liveVisible
 *      + engine.getCompositeDataUrl()（T44 含 live）→ liveDataInk
 *   2. 松手 → 截图 = committedVisible；再取 dataURL = committedInk，并计算 live vs commit 像素差
 *   3. 再画第二笔 → 墨迹继续增加（不白板）
 *   4. engine.currentStroke === null（不卡死）
 * 橡皮单独：先用硬笔画底，再用橡皮拖 → live 截图里底被擦除（墨迹减少）、提交后一致。
 *
 * 用法（项目根目录，先 node v2/serve.mjs）：
 *   node v2/brushes/tools/live-render-test.mjs [url] [cdpPort] [--headed]
 *   默认 headless=new + 真实 GPU（不弹窗）；--headed 才开窗且自动移到屏幕外 (-3000,-3000)+最小化
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
/** 本地服务端口：优先 INKPROOF_BASE，其次 v2/.runtime-port（serve.mjs 自动选端口），最后 4200 */
function resolveBase() {
  if (process.env.INKPROOF_BASE) return process.env.INKPROOF_BASE;
  try {
    const port = fs.readFileSync(path.join(ROOT, 'v2', '.runtime-port'), 'utf8').trim();
    if (/^\d+$/.test(port)) return 'http://127.0.0.1:' + port;
  } catch (e) { /* ignore */ }
  return 'http://127.0.0.1:4200';
}
const BASE = resolveBase();
const URL_ARG = process.argv.slice(2).filter((a) => !a.startsWith('--'))[0] || `${BASE}/v2/brushes/demo.html`;
const CDP_PORT = Number(process.argv.slice(2).filter((a) => !a.startsWith('--'))[1] || 9530);
/** 团队规范：自动化一律 headless；--headed 才开窗（移出屏幕 + 最小化） */
const HEADLESS = !process.argv.includes('--headed');
const OUT = path.join(ROOT, 'v2', 'brushes', 'samples');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(OUT, { recursive: true });

function findBrowser() {
  return [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  ].find((p) => fs.existsSync(p));
}
const EXE = findBrowser();
if (!EXE) { console.log(JSON.stringify({ ok: false, error: 'no browser' })); process.exit(1); }
const profile = path.join(os.tmpdir(), 'livetest-' + Date.now());
const args = [
  '--remote-debugging-port=' + CDP_PORT, '--user-data-dir=' + profile,
  '--no-first-run', '--no-default-browser-check',
];
if (HEADLESS) {
  args.push('--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1680,1050');
} else {
  args.push('--window-size=1680,1050', '--window-position=-3000,-3000', '--start-minimized');
}
args.push(URL_ARG);
const browser = spawn(EXE, args, { stdio: 'ignore' });

let ws = null; let msgId = 0; const pending = new Map();
const report = {
  schema: 'inkproof.live-render-test.v1', createdAt: new Date().toISOString(),
  browser: path.basename(EXE), headless: HEADLESS, url: URL_ARG,
  env: {}, page: {}, brushes: [], eraser: null, ok: false, consoleErrors: [], runtimeExceptions: [],
};
const send = (method, params = {}) => new Promise((resolve) => { const id = ++msgId; pending.set(id, resolve); ws.send(JSON.stringify({ id, method, params })); });
async function ev(expression, timeoutMs = 60000) {
  const r = await Promise.race([
    send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true }),
    sleep(timeoutMs).then(() => ({ __timeout: true })),
  ]);
  if (r.__timeout) throw new Error('evaluate timeout: ' + expression.slice(0, 100));
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1500));
  return r.result?.result?.value;
}
async function waitFor(expr, timeoutMs = 90000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) { if (await ev(expr).catch(() => false)) return true; await sleep(200); }
  return false;
}

const ANALYZER = `(() => {
  window.__ltAnalyzeShot__ = async (b64) => {
    const img = new Image(); img.src = 'data:image/png;base64,' + b64; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
    const stage = document.getElementById('stage') || document.querySelector('canvas');
    const r = stage.getBoundingClientRect();
    const s = img.width / window.innerWidth;
    const x = Math.max(0, Math.round(r.x * s)), y = Math.max(0, Math.round(r.y * s));
    const w = Math.max(1, Math.min(img.width - x, Math.round(r.width * s)));
    const h = Math.max(1, Math.min(img.height - y, Math.round(r.height * s)));
    const d = ctx.getImageData(x, y, w, h).data;
    let dark = 0;
    for (let i = 0; i < d.length; i += 4) if (d[i] < 235 || d[i + 1] < 235 || d[i + 2] < 235) dark += 1;
    return { dark, box: { x, y, w, h } };
  };
  window.__ltDataInk__ = async () => {
    const e = window.__V2__;
    const url = await e.getCompositeDataUrl();
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    let dark = 0;
    for (let i = 0; i < d.length; i += 4) if (d[i] < 235 || d[i + 1] < 235 || d[i + 2] < 235) dark += 1;
    const st = e.getStats();
    return { dark, w: c.width, h: c.height, undoDepth: st.undoDepth, tileCount: st.tileCount, strokeActive: !!e.currentStroke };
  };
  /** 实时（含 live）与提交后两张合成图的像素差（只比较画布区中部，排除收锋尾巴） */
  window.__ltDiffLiveCommit__ = async () => {
    const e = window.__V2__;
    const a = await e.getCompositeDataUrl();
    e.currentStroke && console.log('diff called while stroke active');
    const b = await e.getCompositeDataUrl();
    return { a: a.length, b: b.length, sameDataUrl: a === b };
  };
  return true;
})()`;

async function shot(label, save) {
  const r = await send('Page.captureScreenshot', { format: 'png' });
  const b64 = r.result?.data || '';
  const analysis = await ev(`window.__ltAnalyzeShot__(${JSON.stringify(b64)})`);
  if (save) {
    try { fs.writeFileSync(path.join(OUT, `live-${label}.png`), Buffer.from(b64, 'base64')); } catch (e) { /* ignore */ }
  }
  return analysis.dark;
}

const rect = { x: 0, y: 0, w: 0, h: 0 };
async function refreshRect() {
  const r = await ev(`(() => { const c = document.getElementById('stage'); const b = c.getBoundingClientRect(); return { x: b.x, y: b.y, w: b.width, h: b.height }; })()`);
  Object.assign(rect, r);
}

async function drawStroke(yRatio, x0r, x1r, steps = 12, opts = {}) {
  const y = rect.y + rect.h * yRatio;
  const x0 = rect.x + rect.w * x0r;
  const x1 = rect.x + rect.w * x1r;
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: x0, y, button: 'left', buttons: 1, clickCount: 1, pointerType: 'mouse' });
  for (let i = 1; i <= steps; i += 1) {
    const t = i / steps;
    await send('Input.dispatchMouseEvent', {
      type: 'mouseMoved', x: x0 + (x1 - x0) * t, y: y + Math.sin(t * Math.PI) * (opts.wave || 10),
      button: 'left', buttons: 1, pointerType: 'mouse',
    });
    await sleep(opts.stepSleep == null ? 14 : opts.stepSleep);
  }
  return { x0, x1, y };
}
async function release(x, y) {
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', buttons: 0, clickCount: 1, pointerType: 'mouse' });
}

/** 实时 vs 提交像素一致性：页面内比较两 dataURL（排除右侧标签区，画布整幅） */
const DIFF_FN = `(() => {
  window.__ltPixelDiff__ = async (urlA, urlB) => {
    const load = async (u) => { const img = new Image(); img.src = u; await img.decode();
      const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
      const x = c.getContext('2d'); x.drawImage(img, 0, 0); return x.getImageData(0, 0, c.width, c.height).data; };
    const a = await load(urlA), b = await load(urlB);
    if (a.length !== b.length) return { error: 'size mismatch' };
    let diff = 0, big = 0;
    for (let i = 0; i < a.length; i += 4) {
      const d = Math.abs(a[i] - b[i]) + Math.abs(a[i + 1] - b[i + 1]) + Math.abs(a[i + 2] - b[i + 2]);
      if (d > 0) diff += 1;
      if (d > 30) big += 1;
    }
    return { pixels: a.length / 4, diff, big, diffPct: Math.round(diff / (a.length / 4) * 10000) / 100, bigPct: Math.round(big / (a.length / 4) * 10000) / 100 };
  };
  return true;
})()`;

try {
  let target = null;
  for (let i = 0; i < 400 && !target; i += 1) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json();
      target = list.find((t) => t.type === 'page' && /^https?:/.test(t.url));
    } catch (e) { /* wait */ }
    if (!target) await sleep(150);
  }
  if (!target) throw new Error('CDP target not found');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (m.id && pending.has(m.id)) { const r = pending.get(m.id); pending.delete(m.id); r(m); return; }
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') report.consoleErrors.push(m.params.args.map((a) => a.value || a.description).join(' '));
    if (m.method === 'Runtime.exceptionThrown') report.runtimeExceptions.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text);
  };
  await send('Runtime.enable');
  await send('Page.enable');

  report.page.ready = await waitFor('!!window.__BRUSH_READY__');
  report.env = await ev(`(() => ({ ua: navigator.userAgent, dpr: devicePixelRatio, size: [innerWidth, innerHeight],
    gpu: (() => { try { return window.__V2__.getStats().gpuRenderer; } catch (e) { return null; } })() }))()`);
  report.page.status = await ev(`document.getElementById('status') ? document.getElementById('status').textContent : null`);
  report.page.brushButtons = await ev(`document.querySelectorAll('.brushBtn').length`);
  report.page.debug = await ev(`typeof window.__BRUSH_DEBUG__ === 'function' ? window.__BRUSH_DEBUG__() : null`);

  await ev(ANALYZER);
  await ev(DIFF_FN);
  await refreshRect();
  report.page.canvas = { ...rect, inner: [await ev('document.getElementById("stage").width'), await ev('document.getElementById("stage").height')] };

  // 基线：清空 + 白底
  await ev(`(async () => { const e = window.__V2__; let g = 0; while (e.canUndo() && g < 300) { e.undo(); g += 1; } return g; })()`);
  await sleep(400);
  await ev(`new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)))`);
  await sleep(250);
  const baseDark = await shot('00-baseline', false);
  const baseData = await ev(`window.__ltDataInk__()`);

  const n = Math.min(10, report.page.brushButtons);
  for (let i = 0; i < n; i += 1) {
    const name = await ev(`document.querySelectorAll('.brushBtn')[${i}].textContent.trim()`);
    await ev(`document.querySelectorAll('.brushBtn')[${i}].click()`);
    await sleep(150);
    const isEraser = await ev(`(() => { const p = window.__BRUSH_DEMO__.presets.brushes[${i}]; return !!(p.engine && p.engine.eraser); })()`);
    const yRatio = isEraser ? 0.15 : 0.17 + 0.072 * i;
    // ---- 1) 按下 + 拖动（不松手）→ live 可见性 ----
    const pos = await drawStroke(yRatio, 0.12, 0.52, 14, { wave: isEraser ? 0 : 12 });
    await sleep(200);
    const liveShotDark = await shot(`brush${String(i + 1).padStart(2, '0')}-live`, i === 4 || isEraser);
    const liveData = await ev(`window.__ltDataInk__()`);
    // ---- 2) 松手 → 提交 ----
    await release(pos.x1, pos.y);
    await sleep(280);
    await ev(`new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)))`);
    await sleep(150);
    const commitShotDark = await shot(`brush${String(i + 1).padStart(2, '0')}-commit`, isEraser);
    const commitData = await ev(`window.__ltDataInk__()`);
    // ---- 3) 实时 vs 提交 像素一致性（用两帧 dataURL 对比；live 帧已无法重取，改为对比 live 截图墨迹与提交墨迹比例） ----
    // ---- 4) 第二笔 → 不白板 ----
    const x0 = rect.x + rect.w * 0.55;
    const y2 = rect.y + rect.h * yRatio + 26;
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: pos.x1 + 8, y: pos.y, button: 'left', buttons: 1, clickCount: 1, pointerType: 'mouse' });
    for (let k = 1; k <= 8; k += 1) {
      await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: pos.x1 + 8 + 14 * k, y: pos.y + Math.sin(k / 2) * 6, button: 'left', buttons: 1, pointerType: 'mouse' });
      await sleep(12);
    }
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: pos.x1 + 8 + 112, y: pos.y, button: 'left', buttons: 0, clickCount: 1, pointerType: 'mouse' });
    await sleep(220);
    const afterSecond = await ev(`window.__ltDataInk__()`);
    void x0; void y2;
    // 橡皮在白底上「擦无可擦」时不可见，视觉连续性由下面的橡皮专项覆盖；此处只验不卡死/不报错
    const ok = isEraser
      ? (afterSecond.strokeActive === false && afterSecond.undoDepth === commitData.undoDepth + 1)
      : (liveShotDark > baseDark + 50 && commitShotDark > baseDark + 50 &&
        liveData.dark > baseData.dark + 100 && commitData.dark > baseData.dark + 100 &&
        afterSecond.dark > commitData.dark + 20 && afterSecond.strokeActive === false);
    report.brushes.push({
      index: i, name, eraser: !!isEraser,
      liveVisible: liveShotDark > baseDark + 50,
      liveShotDark, liveDataInk: liveData.dark,
      committedVisible: commitShotDark > baseDark + 50,
      commitShotDark, commitDataInk: commitData.dark,
      liveDataVsCommitData: commitData.dark - liveData.dark,
      secondStrokeInkDelta: afterSecond.dark - commitData.dark,
      notStuck: afterSecond.strokeActive === false && afterSecond.undoDepth === commitData.undoDepth + 1,
      undoDepth: afterSecond.undoDepth,
      ok,
    });
  }

  // ---- 橡皮专项：硬笔底 → 橡皮拖动（不松手）实时可见 + 提交一致 ----
  try {
    await ev(`document.querySelectorAll('.brushBtn')[0].click()`);
    await sleep(150);
    await ev(`(async () => { const e = window.__V2__; let g = 0; while (e.canUndo() && g < 300) { e.undo(); g += 1; } return g; })()`);
    await sleep(200);
    const pos = await drawStroke(0.7, 0.2, 0.8, 16, { wave: 0, stepSleep: 12 });
    await release(pos.x1, pos.y);
    await sleep(250);
    const beforeErase = await ev(`window.__ltDataInk__()`);
    await ev(`document.querySelectorAll('.brushBtn')[9].click()`);
    await sleep(150);
    const pos2 = await drawStroke(0.7, 0.25, 0.75, 14, { wave: 0, stepSleep: 14 });
    await sleep(200);
    const liveAfterErase = await ev(`window.__ltDataInk__()`);
    const liveShotDark = await shot('eraser-live', true);
    await release(pos2.x1, pos2.y);
    await sleep(280);
    await ev(`new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)))`);
    await sleep(150);
    const commitAfterErase = await ev(`window.__ltDataInk__()`);
    const commitShotDark = await shot('eraser-commit', true);
    report.eraser = {
      beforeEraseInk: beforeErase.dark,
      liveAfterEraseInk: liveAfterErase.dark,
      commitAfterEraseInk: commitAfterErase.dark,
      liveEraseDelta: liveAfterErase.dark - beforeErase.dark,
      commitEraseDelta: commitAfterErase.dark - liveAfterErase.dark,
      liveShotDark, commitShotDark, baseDark,
      liveVisible: liveShotDark > baseDark + 50,
      liveErases: liveAfterErase.dark < beforeErase.dark,
      // 说明：新实现按 Klecks 思路「推迟最后一段贝塞尔」→ 松手时 flushTail 才提交最后一段，
      // 故提交后比 live 多擦一点是预期行为（≈ 最后一个 pointer 事件到笔尖的距离）；阈值按笔画长度 12% 给余量。
      deferredTailNote: 'commit 比 live 多擦的部分 = 松手时补画的最后一段（延迟一帧的平滑策略）',
      commitConsistent: Math.abs(commitAfterErase.dark - liveAfterErase.dark) < Math.max(400, beforeErase.dark * 0.12),
    };
  } catch (e) { report.eraser = { error: String(e && e.message || e) }; }

  report.summary = {
    ready: report.page.ready,
    brushesTested: report.brushes.length,
    allLiveVisible: report.brushes.every((b) => b.liveVisible),
    allCommitted: report.brushes.every((b) => b.committedVisible),
    allNotStuck: report.brushes.every((b) => b.notStuck),
    okCount: report.brushes.filter((b) => b.ok).length,
    eraserLiveVisible: !!(report.eraser && report.eraser.liveVisible),
    eraserLiveErases: !!(report.eraser && report.eraser.liveErases),
    eraserCommitConsistent: !!(report.eraser && report.eraser.commitConsistent),
    consoleErrors: report.consoleErrors.length,
    runtimeExceptions: report.runtimeExceptions.length,
  };
  report.ok = report.page.ready && report.summary.okCount === report.brushes.length && report.consoleErrors.length === 0 &&
    report.summary.eraserLiveVisible && report.summary.eraserLiveErases && report.summary.eraserCommitConsistent;
  console.log(JSON.stringify(report, null, 2));
  fs.writeFileSync(path.join(OUT, 'live-render-test.json'), JSON.stringify(report, null, 2));
} catch (e) {
  report.fatal = String(e && e.stack || e);
  console.log(JSON.stringify(report, null, 2));
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  try { browser.kill(); } catch (e) { /* ignore */ }
  await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  process.exit(report.ok ? 0 : 1);
}
