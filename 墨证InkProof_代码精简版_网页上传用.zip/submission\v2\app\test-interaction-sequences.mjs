// v2/app/test-interaction-sequences.mjs —— 组合/先后交互回归（Playwright headless）
// 依据：05-交互/交互状态机与组合契约.md
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8131;
const out = { schema: 'mozheng.app.interaction-test.v1', cases: {}, errors: [], pass: null };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
let browser = null;
const errors = [];
const finish = (code = 0) => {
  out.errors = errors;
  out.pass = Object.values(out.cases).every((c) => c && c.ok === true) && errors.length === 0;
  try { fs.writeFileSync(ROOT + '\\v2\\app\\test-interaction-result.json', JSON.stringify(out, null, 2), 'utf8'); } catch (e) {}
  try { browser && browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  process.exit(out.pass ? 0 : 1);
};
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_180s'; finish(3); }, 180000);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const caseRun = async (name, fn) => {
  try { const detail = await fn(); out.cases[name] = { ok: true, detail }; }
  catch (e) { out.cases[name] = { ok: false, error: String(e && e.message || e) }; }
};

try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(900);
  const app = () => page.evaluate(() => {
    const a = window.__V2_APP__;
    return { tool: a.state.tool, demo: { active: a.state.demo.active, paused: a.state.demo.paused, takenOver: !!a.state.demo.takenOver }, transformActive: !!a.state.transformActive, undo: a.engine.getStats().undoDepth, pointerdowns: a.state.pointerdowns, strokeActive: !!a.state.strokeActive, libOpen: !!a.state.library.open };
  });
  const cleanupDemo = async () => {
    const s = await app();
    if (s.demo.active) { await page.evaluate(() => window.__V2_APP__.takeoverDemo()); await page.waitForTimeout(250); }
  };
  const box = await page.locator('#mainCanvas').boundingBox();
  const draw = async (y = 0.4) => {
    await page.mouse.move(box.x + box.width * 0.25, box.y + box.height * y);
    await page.mouse.down();
    for (let i = 1; i <= 12; i += 1) { await page.mouse.move(box.x + box.width * (0.25 + i * 0.03), box.y + box.height * (y + Math.sin(i / 3) * 0.03)); await sleep(8); }
    await page.mouse.up();
    await page.waitForTimeout(120);
  };

  await caseRun('sShortcut', async () => {
    await page.keyboard.press('s');
    let s = await app();
    if (s.tool !== 'smudge') throw new Error('S 未切到涂抹: ' + s.tool);
    await page.keyboard.press('s');
    s = await app();
    if (s.tool !== 'brush') throw new Error('再按 S 未回到画笔: ' + s.tool);
    return { tool: s.tool };
  });

  await caseRun('noDuplicateListeners', async () => {
    await page.evaluate(() => { const a = window.__V2_APP__; ['brush', 'eraser', 'brush', 'select', 'brush'].forEach((t) => a.setTool(t)); });
    const before = (await app()).pointerdowns;
    await page.mouse.move(box.x + box.width * 0.5, box.y + box.height * 0.5);
    await page.mouse.down(); await page.mouse.up();
    await page.waitForTimeout(80);
    const after = (await app()).pointerdowns;
    if (after - before !== 1) throw new Error('pointerdown 计数增加 ' + (after - before) + '（应为 1，说明监听重复）');
    return { delta: after - before };
  });

  await caseRun('libraryKeyboardIsolation', async () => {
    await page.evaluate(() => window.__V2_APP__.setTool('eraser'));
    await page.click('#btnLibrary');
    await page.waitForFunction(() => !document.getElementById('librarySheet').hidden, null, { timeout: 10000 });
    await page.waitForTimeout(500);
    let s = await app();
    if (!s.libOpen) throw new Error('素材库未打开');
    await page.keyboard.press('b');
    s = await app();
    if (s.tool !== 'eraser') throw new Error('素材库打开时 B 穿透改工具: ' + s.tool);
    await page.keyboard.press('Escape');
    await page.waitForTimeout(300);
    s = await app();
    if (s.libOpen) throw new Error('Esc 未关闭素材库');
    if (s.tool !== 'eraser') throw new Error('关闭素材库后工具未恢复: ' + s.tool);
    return { tool: s.tool };
  });

  await caseRun('demoTakeoverPointer', async () => {
    const before = (await app()).undo;
    await page.evaluate(() => window.__V2_APP__.startDemo(true));
    await page.waitForTimeout(400);
    let s = await app();
    if (!s.demo.active) throw new Error('演示未启动');
    await page.mouse.move(box.x + box.width * 0.5, box.y + box.height * 0.5);
    await page.mouse.down(); await page.mouse.up();
    await page.waitForTimeout(400);
    s = await app();
    if (s.demo.active) throw new Error('画布手动操作未接管演示');
    if (!s.demo.takenOver) throw new Error('takenOver=false');
    await draw();
    const afterDraw = await app();
    if (afterDraw.undo <= before) throw new Error('接管后绘制未进入 undo（演示历史未恢复？）');
    await page.keyboard.press('Control+z');
    await page.waitForTimeout(250);
    const afterUndo = await app();
    if (afterUndo.undo >= afterDraw.undo) throw new Error('接管后 undo 无效');
    await cleanupDemo();
    return { before, afterDraw: afterDraw.undo, afterUndo: afterUndo.undo };
  });

  await caseRun('demoTakeoverKeyboard', async () => {
    await page.evaluate(() => window.__V2_APP__.startDemo(true));
    await page.waitForTimeout(350);
    let s = await app();
    if (!s.demo.active) throw new Error('演示未启动');
    await page.keyboard.press('b');
    await page.waitForTimeout(250);
    s = await app();
    if (s.demo.active) throw new Error('键盘未接管演示');
    if (s.tool !== 'brush') throw new Error('接管后 B 未生效: ' + s.tool);
    return { tool: s.tool };
  });

  await caseRun('demoAfterKeyboardCleanup', async () => {
    await cleanupDemo();
    return { demoActive: (await app()).demo.active };
  });

  await caseRun('demoHistoryClean', async () => {
    await cleanupDemo();
    await page.waitForTimeout(300);
    const before = (await app()).undo;
    await page.evaluate(() => window.__V2_APP__.startDemo(true));
    await page.waitForTimeout(500);
    await page.evaluate(() => window.__V2_APP__.takeoverDemo());
    await page.waitForTimeout(300);
    const s = await app();
    if (s.undo !== before) throw new Error('演示动作进入 undo 栈：' + before + ' → ' + s.undo);
    return { undo: s.undo };
  });

  await caseRun('drawingBlocksUndo', async () => {
    await cleanupDemo();
    await page.evaluate(() => window.__V2_APP__.setTool('brush'));
    const before = (await app()).undo;
    await page.mouse.move(box.x + box.width * 0.3, box.y + box.height * 0.3);
    await page.mouse.down();
    await page.mouse.move(box.x + box.width * 0.4, box.y + box.height * 0.35);
    const active = await app();
    if (!active.strokeActive) throw new Error('pointerdown 后 strokeActive=false');
    await page.keyboard.press('Control+z');
    await page.waitForTimeout(150);
    const mid = await app();
    if (mid.undo !== before) throw new Error('绘制中 undo 改变了历史: ' + before + ' → ' + mid.undo);
    await page.mouse.up();
    await page.waitForTimeout(150);
    return { undoDuring: mid.undo, strokeActiveDuring: mid.strokeActive };
  });

  await caseRun('transformToolSwitch', async () => {
    await page.evaluate(() => window.__V2_APP__.setTool('select'));
    await page.mouse.move(box.x + box.width * 0.2, box.y + box.height * 0.2);
    await page.mouse.down();
    await page.mouse.move(box.x + box.width * 0.55, box.y + box.height * 0.5);
    await page.mouse.up();
    await page.waitForTimeout(250);
    await page.evaluate(() => window.__V2_APP__.setTool('transform'));
    await page.waitForTimeout(250);
    let s = await app();
    if (!s.transformActive) throw new Error('选区后变换未激活');
    await page.evaluate(() => window.__V2_APP__.setTool('brush'));
    await page.waitForTimeout(200);
    s = await app();
    if (s.transformActive) throw new Error('切画笔后变换未取消');
    return { tool: s.tool };
  });

  clearTimeout(hard);
  finish(errors.length ? 2 : 0);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  clearTimeout(hard);
  finish(3);
}
