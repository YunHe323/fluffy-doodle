// v2/app/test-text.mjs —— 文字工具：点击画布 → 输入 → 提交为图层
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8154;
const out = { schema: 'mozheng.app.text.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  fs.writeFileSync(ROOT + '\\v2\\app\\test-text-result.json', JSON.stringify(out, null, 2), 'utf8');
  process.exit(code);
};
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  const before = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.click('#btnToolText');
  await page.waitForTimeout(200);
  const box = await page.locator('#mainCanvas').boundingBox();
  await page.mouse.click(box.x + box.width * 0.35, box.y + box.height * 0.4);
  await page.waitForTimeout(300);
  out.cases.open = await page.evaluate(() => ({ composer: !!document.querySelector('.text-composer'), textarea: !!document.getElementById('tcText'), tool: window.__V2_APP__.state.tool }));
  await page.fill('#tcText', '雾中山谷\n测试文字');
  await page.fill('#tcSize', '64');
  await page.click('#tcOk');
  await page.waitForTimeout(700);
  out.cases.commit = await page.evaluate(() => {
    const a = window.__V2_APP__;
    const names = a.engine.getLayers().map((l) => l.name);
    return { count: a.engine.getLayers().length, undo: a.engine.getStats().undoDepth, names: names.slice(-3), textRecord: a.state.records.filter((r) => r.kind === 'text_inserted').length, composerGone: !document.querySelector('.text-composer') };
  });
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-text-tool-1920.png' });
  out.cases.before = before;
  out.cases.openOk = out.cases.open.composer && out.cases.open.textarea && out.cases.open.tool === 'text';
  out.cases.commitOk = out.cases.commit.count === before + 1 && out.cases.commit.undo >= 1 && out.cases.commit.names.some((n) => n.startsWith('文字 ·')) && out.cases.commit.composerGone && out.cases.commit.textRecord >= 1;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.openOk && out.cases.commitOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  await finish(3);
}
