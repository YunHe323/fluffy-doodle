<div align="center">

# Mozheng · 墨证

**A local-first creation memory & process-provenance layer for artists.**
*AI helps you draw — and every step proves it was you.*

[![Status](https://img.shields.io/badge/status-v0.1.0--in--development-yellow)](#status)
[![License](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
[![No telemetry](https://img.shields.io/badge/telemetry-none-brightgreen)](docs/privacy.md)
[![Mock AI by default](https://img.shields.io/badge/AI-mock%20by%20default-purple)](docs/getting-started.md#mock-ai)

</div>

> **Repository:** `mozheng` · **Working subtitle:** InkProof · **License:** MIT (placeholder — see [LICENSE](LICENSE))
>
> Research and design documents are kept **outside** this repository. This repository contains the product only.

---

## What is Mozheng?

AI image tools can draw well, but they forget **why** you draw the way you do — and they can't prove **which parts are yours**. Mozheng puts three things into one local-first canvas:

1. **Private visual memory** — your imported artwork is turned into a structured archive (global / regional / observation / decision records) that AI can use as context.
2. **Process provenance** — every AI action and every edit is recorded in a local SHA-256 hash chain; export an evidence package (JSON + canvas PNG) at any time.
3. **Canvas-native collaboration** — when you're stuck, select the area on the canvas and ask AI to take a look; it returns observations and two directions. A chosen candidate becomes a **new, editable layer** — never a silent overwrite.

> **Not a replacement for Procreate or Photoshop.** PSD import/export, cloud sync, and real model integration are **not** in v0.1 (see [Roadmap](#roadmap)).

---

## Status

- **Version:** `v0.1.0` — **in development**. Core modules are being built under `app/`, `server/`, `core/`; see [CHANGELOG](CHANGELOG.md).
- **Default AI:** **Mock AI** — offline, deterministic, no API key required. The UI always labels mock results.
- **Telemetry:** none. **Network:** in mock mode the app makes **no external requests** (only the local service on `127.0.0.1`). See [privacy](docs/privacy.md).
- **Platforms:** Windows / macOS / Linux with Node.js **22+**; browsers: recent **Chrome / Edge** (Chromium). Safari/Firefox are not verified in v0.1.

---

## Quick start (3 steps)

### 1. Requirements

- [Node.js](https://nodejs.org/) **22 or newer** (`node -v` to check).
- A Chromium-based browser (Chrome/Edge).

### 2. Start

**Windows**

```bat
start.bat
```

**macOS / Linux**

```bash
chmod +x start.sh   # first time only
./start.sh
```

**Or start the local service manually**

```bash
node server/server.mjs
# or: npm start
```

The app opens automatically at **http://127.0.0.1:4173**. If the port is busy, it tries `4174`, `4175`, … and prints the actual URL.

> No `npm install` is required: the project has **zero third-party runtime dependencies**.
> Do not open `app/index.html` directly via `file://` — browsers block ES modules there. Use the start script / local service.

### 3. First run — the only demo path

1. Click **“Load Sample Project”** (or draw from a blank canvas).
2. Optional: click **“演示 Demo / Demo”** in the top bar (or “Watch once” in the onboarding) to run the **one-click demo**: an 8-step automated walkthrough on the real UI, about 2.5–3 minutes, with pause / previous / next / exit (`Esc`) and progress `n/8`. Any manual action on the canvas exits auto mode and hands control back to you. The demo is labeled **“Simulated demo · AI is Mock”** and makes no network requests.
3. Press **`K`** (or click **“Let AI take a look”**) and select a region — no text needed.
4. Review the archive cards (confirm / reject), pick a direction, apply a candidate as a new layer.
5. Open **“Export Evidence Package”** — get JSON + canvas PNG.
6. Switch to **Attestation mode** and export again — the package states *zero generation* for that scope.

> **Demo rule:** the sample project **is** the demo. We do not ship a separate demo app/page. Screenshots, videos, and live demos all use: **open product → Load Sample Project (or one-click demo) → walk the main flow**.

---

## Run from a Release download

If you received a release archive (e.g. `inkproof-v0.1.0.zip`):

1. **Verify the download** (optional but recommended):
   - Windows: `certutil -hashfile inkproof-v0.1.0.zip SHA256`
   - macOS/Linux: `shasum -a 256 inkproof-v0.1.0.zip` / `sha256sum inkproof-v0.1.0.zip`
   Compare with the `.sha256` file and the manifest on the release page.
2. **Unzip it** anywhere (no admin rights, no installer, no `npm install`).
3. **Start it:**
   - **Windows:** double-click `start.bat`.
   - **macOS / Linux:** `bash start.sh` (the script works without `chmod +x`).
   - Or manually: `node server/server.mjs`.
4. Your browser opens **http://127.0.0.1:4173**. If that port is busy the server automatically tries `4174`, `4175`, … and prints the actual URL; check the server window if the browser opens the wrong one.
5. **Stop it:** press `Ctrl+C` in the server window/terminal (on Windows you can also close the window titled *“Mozheng InkProof Server”*).
6. **No API key is needed.** Mock AI is offline and deterministic. `config/provider.example.json` is only a shape reference — keep `apiKey` empty and do not commit a real `config/provider.json`; real provider support is planned for v0.2.

> The release contains `RELEASE.json` (version/build metadata) and is built from the same zero-dependency source. It intentionally excludes `reference/`, tests, and any real `config/provider.json` (which may contain keys).

---

## Features (v0.1 scope)

| Area | What you get |
|---|---|
| **Canvas** | Hard/soft brush, eraser, color, size, undo/redo, zoom & pan, image import |
| **Layers** | Add / delete / rename / reorder / hide / opacity; AI candidate layers are editable and removable |
| **Archive** | Mock AI reads your image into L0 (original), L1 (global), L2 (regions), L4 (observations), plus L5 decisions and minimal L6 derivation records; confirm / reject / edit each card |
| **Stuck moment** | Zero-text region selection → 2–4 observations + 2 directions + simulated candidates → applied as a new layer (move / hide / delete / undo) |
| **Provenance** | Append-only event hash chain, manifest with SHA-256, evidence package (JSON + canvas PNG), attestation mode with a scoped “zero generation” statement; AI events cannot be hidden |
| **Local-first** | Everything is stored in **IndexedDB** in your browser; project export/import as JSON; refresh/restart does not lose work |
| **Onboarding** | 3-step skippable guide; built-in **sample project**; **one-click demo** (8-step automated walkthrough, pausable, user takeover, cleanup) |
| **AI adapter** | **MockAI** by default (offline, deterministic). A provider interface is reserved; real model calls and keys are **not** part of v0.1 |

**What v0.1 deliberately does not do:** accounts, commercial features, cloud sync, collaboration, PSD import/export, L3 relationship archive, real model quality promises, auto semantic layer decomposition. See [roadmap](#roadmap) and `docs/architecture.md`.

---

## Mock AI — please read

The default AI is a **mock**: deterministic observations, directions, and SVG placeholder candidates. It exists to make the workflow testable and demoable **offline**, not to pretend to be a real model.

- Every AI result is labeled **MOCK / simulated** in the UI.
- No API key required; no external network requests in mock mode.
- Evidence and derivation records store the model id `mock-ai@0.1.0` — never a real vendor name.
- A provider hook is reserved for a future version. When real AI arrives, **keys stay local** (`config/provider.json`, gitignored, never committed; not stored in browser storage/logs).

Test hooks for manual QA: append `?mock=low`, `?mock=fail`, or `?mock=slow` to the app URL to simulate low-confidence, failure, or slow responses.

---

## Repository structure

```
mozheng/
├─ README.md                 ← you are here (English, Chinese below)
├─ LICENSE                   ← MIT placeholder (copyright line to be completed)
├─ CONTRIBUTING.md
├─ CODE_OF_CONDUCT.md
├─ CHANGELOG.md
├─ .gitignore
├─ .github/
│  ├─ ISSUE_TEMPLATE/bug_report.md
│  ├─ ISSUE_TEMPLATE/feature_request.md
│  └─ PULL_REQUEST_TEMPLATE.md
├─ docs/
│  ├─ getting-started.md
│  ├─ architecture.md
│  ├─ privacy.md
│  └─ screenshots/           ← product screenshots (sample-project path)
├─ start.bat / start.sh
├─ package.json              ← scripts only, no dependencies
├─ CONTRACT.md               ← app ↔ local server interface contract (v0.1.1)
├─ app/                      ← frontend (canvas, layers, archive, evidence, UI)
├─ server/                   ← zero-dependency local HTTP service (static + /api/*)
├─ core/                     ← environment-agnostic pure logic (hash chain, schema, mock AI)
├─ config/provider.example.json
└─ test/                     ← node --test unit tests
```

> Development note: `app/`, `server/`, `core/`, and `test/` are actively being built; a module may be a stub until the v0.1.0 tag. See [CHANGELOG](CHANGELOG.md).

---

## Screenshots

Screenshots will be added from the **built-in sample project** path before the v0.1.0 release:

| File | Scene |
|---|---|
| `docs/screenshots/canvas-sample.png` | Canvas + layers after loading the sample project |
| `docs/screenshots/stuck-observations.png` | “Let AI take a look” panel with observations & directions |
| `docs/screenshots/archive-cards.png` | Archive cards with source / confidence / anchor |
| `docs/screenshots/evidence-export.png` | Evidence package preview (manifest + hash chain) |

*(Placeholder — no prototype links. All screenshots are from the actual product.)*

---

## Roadmap

Not a commitment; priorities will be decided after real usage of v0.1.

- **v0.1 (current):** local-first canvas + archive + stuck moment + evidence package + sample project + mock AI.
- **v0.2 candidates:** PSD import/export · L3 relationship archive · real model provider (optional, opt-in) · cloud sync (encrypted, opt-in) · desktop shell · mobile/iPad viewing · evidence ZIP with layer PNGs + verify script.

No dates are promised. The project is open source and free; **there is no commercialization in this stage**.

---

## Development & tests

```bash
node --test        # unit tests (Node 22+); no install required
```

- Zero third-party runtime dependencies; no build step for development.
- Code style, directory ownership, and PR flow: see [CONTRIBUTING.md](CONTRIBUTING.md).
- Interface contract between app and local service: [CONTRACT.md](CONTRACT.md) — **current contract: v0.1.1**.

---

## Security & privacy

- The local service binds to **127.0.0.1 only**.
- Mock mode: **no telemetry, no analytics, no external network requests**.
- No account system; data stays in your browser’s IndexedDB. Clear site data to delete it; export a project JSON to back it up.
- Please report security issues privately — see [docs/privacy.md](docs/privacy.md).

---

## License

[MIT](LICENSE) — placeholder license; the copyright line is still `<to be filled>` and the final license will be confirmed before public release.

**The open-source license will be finally confirmed before release.**

Third-party assets used by the product (e.g. Lucide icons under ISC, system fonts) are listed in [docs/architecture.md](docs/architecture.md#third-party-assets) and must be attributed if reused.

---

## 中文说明

**墨证（Mozheng）** —— 给画师的**创作记忆与过程证据层**：AI 帮你画，但每一步都证明是你画的。

### 它是什么

- **私人视觉记忆**：导入的作品被 AI 读成结构化的素材档案（全局 / 区域 / 观察 / 决策），成为协作的依据；
- **过程证据链**：每次笔触、每次 AI 介入都留下时间线、哈希与 manifest，可导出证据包；
- **卡住时刻协作**：画到一半卡住，在画布上圈出区域，AI 给观察与方向，选中的方案落成可编辑的新图层；
- **本地优先**：作品与档案存在浏览器 IndexedDB 里；刷新/重启不丢；可导出 JSON 备份与迁移。

### 怎么跑

1. 安装 Node.js **22+**；
2. Windows 双击 `start.bat`；macOS/Linux 执行 `./start.sh`；或运行 `node server/server.mjs`；
3. 浏览器打开 **http://127.0.0.1:4173**（端口被占用会自动换）；
4. 首页点 **「加载示例项目」**；可选点顶栏 **「演示 Demo」** 自动播放 8 步（2.5–3 分钟，可暂停/上一步/下一步/Esc，手动操作即接管）；也可按 `K` 体验「卡住」，再导出证据包。

> **演示方式只有一种**：打开成品 → 加载示例项目 / 一键演示 → 走主流程。我们没有额外的 demo 产品/页面；截图与演示都来自产品本身。

### 诚实边界

- 默认 AI 是 **Mock（模拟）**：离线、确定性、无需 API key；界面会明确标注「模拟」，不假装是真实模型；
- v0.1 **不做**：账号、云同步、商业化功能、PSD、L3 关系层、真实模型质量承诺、自动分层；
- 证据包证明的是「本工具内的创作过程、图层指纹与 AI 事件」；**不证明**未在其它工具使用 AI，也不构成第三方可信时间戳或法律意见；
- 默认**无遥测、无外部网络请求**（Mock 模式）；未来真实 AI 为可选配置，key 只存本地，绝不入库。

### 参与贡献

见 [CONTRIBUTING.md](CONTRIBUTING.md) 与 [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md)。项目零依赖、零构建，`node --test` 可跑测试。

### 许可

[MIT](LICENSE)（占位；版权行 `<待填作者>`）。**开源协议发布前最终确认。**
