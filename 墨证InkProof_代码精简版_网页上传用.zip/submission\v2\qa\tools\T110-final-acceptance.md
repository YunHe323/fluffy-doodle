# T110 最终验收 QA：目标清单逐项核对 + 打包/本地启动

> 执行：qa-engineer（独立 QA｜task-118，目标收口前最后一轮）｜日期：2026-11-07 20:30（含 P2 修复复核）
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、单浏览器串行、小批次（日志 `archive/baseline-t110-final/logs/`）；执行期内存约 5.5GB。
> 只写 `v2/qa/tools/`；**未改 app**。

## 结论

**可交付（Deliverable）——P0 / P1 / P2 = 0。**
20 项新/回归全 PASS、0 console error；5 个模块单测 PASS；目标清单 18 项逐项有证据；打包/本地启动核对通过；证据 mtime 未变、未新增付费调用；残留 0。
**唯一 P2（自定义参考线单独启用时不吸附）已由 Lead 修复，QA 独立复核通过**：关网格/三分线、仅自定义 X=333/Y=222 时 `snapDocPoint(330,219)` → **(333,222)**；test-guides 新增 `customOnly` 断言并 PASS。

## 1. 全量回归（20 项全 PASS，0 console error）

| 测试 | 结果 | 测试 | 结果 |
|---|---|---|---|
| test-guides（含自定义参考线 333/222、按钮(2)、**customOnly**） | PASS | test-canvas-resize | PASS |
| test-app | PASS（errors 0） | test-ui | PASS（errors 0） |
| test-library | PASS | test-image-workshop | PASS |
| test-multimodal | PASS | test-chat（单跑） | PASS |
| test-canvas-size | PASS | test-text | PASS |
| test-editor-basics | PASS | test-text-edit | PASS |
| test-symmetry | PASS | test-shape-snap | PASS |
| test-mask-compare | PASS | test-editor-ui | PASS |
| test-ux-p0 | PASS | test-ai-provider **16/16** | PASS |
| test-interaction-sequences **9/9**（单跑） | PASS | test-asset-batch | PASS |

## 2. 模块单测（Node-only，全 PASS）

`skill-runtime-test`（**5 skills**：asset.decompose / canvas.observe / canvas.directions / image.generate / image.edit）、`asset-batch-test` **11/11**、`asset-ai-test` **10/10**、`guides-test` **124 断言**、`editor-ops-test` **77 断言**。

## 3. P2 修复复核（QA 独立探针，7/7 PASS）

| 检查 | 结果 |
|---|---|
| 仅自定义参考线吸附（网格/三分线 **关**） | count=2、`snapDocPoint(330,219)` = **(333,222)**、按钮「自定义参考线… (2)」✅ |
| 纯视图层：导出 | 开/关自定义参考线导出 PNG diff=**0** ✅ |
| 纯视图层：undo | undoDepth **0→0** 不变 ✅ |
| 纯视图层：文档/证据 | `saveProjectText()` 无 customGuides/guideCanvas；`buildEvidence()` 无 guide 字段 ✅ |
| 清空参考线 | count=2→0，`snapDocPoint(330,219)` 回退 (330,219) ✅ |
| 密钥 / console | 无泄漏；0 console error ✅ |

## 4. 最终目标清单 GATE（逐项证据）

| # | 目标项 | 判定 | 证据 |
|---|---|---|---|
| 1 | SkillRuntime 5 paths + L6 skill | ✅ | skill-runtime-test 5 skills 全 run ok；L6 `params.skill{id,version}` 前轮记录核验 |
| 2 | 素材真实重读 22.955s / L2=5 / L4=4 | ✅ | `asset-real-read-results.json`（mtime 17:12 未变）：pass、22,955ms、real、qwen3.8-max、L2=5、L4=4、records=1 |
| 3 | 批量 Mock 0 网络 | ✅ | 探针 `/api/ai/*` **0 次**；mode=mock total=3 done=3 failed=0 skill=asset.decompose；realAssets=0 |
| 4 | AI 结果回库 provenance | ✅ | analysis{source:real,provider:qwen,model,latency_ms,skill:asset.decompose} + L6 critique |
| 5 | 编辑器：图像调整/形状/填充 | ✅ | test-editor-ui：L6 adjust_layer/shape_inserted、图层+1、0 error |
| 6 | 文字二次编辑（persist/undo） | ✅ | test-text-edit：meta 入 doc→load 恢复、双击预填、text_edited=1、undo 像素 diff=0 |
| 7 | 画布 resize/crop（mask/text meta/4096） | ✅ | test-canvas-resize PASS；前轮核验：save/load 恢复、16×16、4096×2048/4096×4096、layer/组 mask 保留 |
| 8 | 网格/三分线/自定义参考线/对称/光标 | ✅ | test-guides：grid/thirds alpha+标签、custom count=2、**customOnly snap 333/222**、按钮(2)、modal 增删清空；test-symmetry undoDelta=1；光标 alpha=432 |
| 9 | 可控编辑 mask outsideDiff=0 + 对比滑杆 | ✅ | test-mask-compare：outsideDiff=**0**、insideDiff>0、clip=`inset(0px 0px 0px 70%)`、mask_policy=selection_alpha |
| 10 | 真实 Qwen / 手动确认 / Mock 离线 | ✅ | test-ai-provider 16/16（confirm/cancel/mock/real/directions/generate/error401/badjson…） |
| 11 | 证据链 buildEvidence/verify | ✅ | test-app appEvidence：events=12、head=`7698a523d4ee`、layers=4、hasPng=true；qwen-real-e2e evidence 12/12、real_calls=1、mock=false |
| 12 | UI：1366 无重叠/变换退出/AI 关闭 | ✅ | test-ux-p0：topbar lastRight 503 < docLeft 632、Esc 退出变换、打开 AI 自动退出+关闭按钮 |
| 13 | UI：toast/hint 分层 | ✅ | 探针实测 toast(654–694) 与 hint(694–730) **无重叠** |
| 14 | UI：guide modal 可操作 | ✅ | modal show、X/Y 输入、add/clear 按钮；加 2 条→清空→count 0 |
| 15 | 打包：`v2/serve.mjs` 健康 | ✅ | 4200 `/health` **200** `{ok:true,port:4200,pid:30792}`；app 页 200（40,322B） |
| 16 | 打包：`v2/start.bat` 路径/端口/自动打开 | ✅ | 静态 7/7：`cd /d "%~dp0.."`、node 回退 `D:\nodejs\node.exe`、`del .runtime-port`、`start v2\_server.bat`、`set /p ACTUAL_PORT=<.runtime-port`、打开 `/v2/app/index.html`、engine demo 回退；`_server.bat`/`app/index.html` 均存在 |
| 17 | 密钥无泄漏 / 0 残留 | ✅ | DOM/localStorage/sessionStorage/已加载 JS 无 key、configMasked；Edge **0**、测试端口 **0** |
| 18 | 不新增付费调用 / 证据 mtime 不变 | ✅ | asset-real-read 17:12、qwen-real-e2e 16:53（mtime 均未变），本轮未发起真实请求 |

## 5. 问题清单

| # | 级别 | 问题 | 状态 |
|---|---|---|---|
| 1 | ~~P2~~ | 自定义参考线单独启用时不吸附（`app.js:492` 早退条件遗漏 customGuides） | **已修复并复核**：Lead 修改条件 + test-guides 新增 customOnly；QA 独立探针 7/7 PASS |
| 2 | 提示 | `.runtime-port` 会被任意 serve.mjs 实例（含测试服务器）覆写（QA 测试实例曾写 8162） | QA 已恢复为 **4200**；start.bat 启动前会删除重写，功能影响低；建议测试统一用 python http.server 或测试后恢复（不阻塞） |

**P0/P1/P2 = 0。**

## 6. 产物与归档

- `v2/qa/tools/T110-final-acceptance.md`（本报告）
- `v2/qa/tools/archive/baseline-t110-final/`：`logs/`（20 项测试+5 模块+修复后重跑日志）、全部 result JSON、`focus-results.json`（首轮 7 项核验）、`focus2-results.json`（P2 修复复核 7 项）、真实证据、README
- GATE：`v2/qa/tools/GATE-pw.md`「T110 最终验收 GATE」行（已更新为 P0/P1/P2=0）
