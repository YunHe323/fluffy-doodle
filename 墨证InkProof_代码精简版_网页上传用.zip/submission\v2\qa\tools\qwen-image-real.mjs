// 临时：真实 Qwen-Image 3.0 经本地代理（DashScope 异步）验证；不打印密钥
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
const KEY = process.env.QWEN_API_KEY || '';
if (!KEY) { console.error('no key'); process.exit(2); }
const ROOT = process.cwd();
const cfgPath = path.join(ROOT, 'v2', '.tmp-qwen-image-config.json');
const cfg = {
  version: 1, mode: 'real', provider: 'qwen', model: 'qwen3.8-max',
  providers: { qwen: { apiKey: KEY, baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1', imageBaseUrl: 'https://dashscope.aliyuncs.com', model: 'qwen3.8-max', imageModel: 'qwen-image-3.0' } },
  privacyMode: false,
  limits: { perMinute: 10, timeoutMs: 60000, maxImageBytes: 6291456 },
  dashscopePollMs: 2500, dashscopeMaxPolls: 80,
};
fs.writeFileSync(cfgPath, JSON.stringify(cfg), 'utf8');
const PORT = 4293;
const TOKEN = 'qwen-image-test-token';
const srv = spawn(process.execPath, [path.join(ROOT, 'v2', 'serve.mjs')], {
  cwd: ROOT,
  env: { ...process.env, PORT: String(PORT), AI_CONFIG_PATH: cfgPath, AI_TOKEN_PATH: path.join(ROOT, 'v2', '.tmp-qwen-image-token'), AI_LOCAL_TOKEN: TOKEN },
  stdio: 'ignore', windowsHide: true,
});
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = { schema: 'mozheng.qa.qwen-image-real.v1', pass: false, errors: [] };
let browserLike = null;
try {
  for (let i = 0; i < 40; i += 1) { await sleep(200); try { const r = await fetch(`http://127.0.0.1:${PORT}/health`); if (r.ok) break; } catch (e) {} }
  const t0 = Date.now();
  const res = await fetch(`http://127.0.0.1:${PORT}/api/ai/image`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-ai-token': TOKEN, 'x-ai-confirm': 'true', origin: `http://127.0.0.1:${PORT}` },
    body: JSON.stringify({ provider: 'qwen', model: 'qwen-image-3.0', prompt: '水彩风格的一只橘猫坐在窗台上，干净背景，柔和光线', size: '1024x1024', count: 1 }),
  });
  const ms = Date.now() - t0;
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch (e) {}
  out.status = res.status; out.ms = ms;
  if (json) {
    const c = (json.candidates || [])[0] || {};
    out.billed = json.billed;
    out.model = json.model;
    out.error = json.error || null;
    out.taskId = json.taskId || null;
    out.candidate = { hasImage: !!c.imageDataUrl, sha256: c.sha256 || null, bytes: c.bytes || null, width: c.width, height: c.height };
    out.usage = json.usage || null;
    out.noUpstreamUrlInResponse = !text.includes('aliyuncs.com') && !text.includes('Expires=');
    out.pass = !!(res.ok && c.imageDataUrl && c.sha256 && c.sha256.length === 64);
    if (!c.imageDataUrl) out.body = text.slice(0, 1200);
    if (c.imageDataUrl) {
      const b64 = String(c.imageDataUrl).split(',')[1] || '';
      const buf = Buffer.from(b64, 'base64');
      fs.writeFileSync(path.join(ROOT, 'v2', 'qa', 'tools', 'qwen-image-real-sample.png'), buf);
      out.sampleBytes = buf.length;
    }
  } else {
    out.body = text.slice(0, 800);
  }
} catch (e) {
  out.errors.push(String(e && e.stack || e));
} finally {
  try { srv.kill(); } catch (e) {}
  await sleep(300);
  try { fs.unlinkSync(cfgPath); } catch (e) {}
  try { fs.unlinkSync(path.join(ROOT, 'v2', '.tmp-qwen-image-token')); } catch (e) {}
}
fs.writeFileSync(path.join(ROOT, 'v2', 'qa', 'tools', 'qwen-image-real-results.json'), JSON.stringify(out, null, 2), 'utf8');
console.log(JSON.stringify(out, null, 2));
process.exit(out.pass ? 0 : 1);
