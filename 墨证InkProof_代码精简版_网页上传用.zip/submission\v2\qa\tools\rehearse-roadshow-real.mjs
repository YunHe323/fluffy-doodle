// v2/qa/tools/rehearse-roadshow-real.mjs —— 在真实 4200 服务上彩排路演模式（真实 AI 路径 + 预置样本 + 证据）
import fs from 'node:fs';
import { chromium } from '../node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const URL = 'http://127.0.0.1:4200/v2/app/index.html';
const out = { schema: 'mozheng.roadshow.rehearsal.v1', cases: {}, errors: [], pageErrors: [], consoleErrors: [], pass: false };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\qa\\tools\\rehearse-roadshow-real-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  page.on('pageerror', (e) => out.pageErrors.push(String(e.message || e).slice(0, 300)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.consoleErrors.push(m.text().slice(0, 300)); });
  await page.goto(URL, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
  await sleep(1200);

  out.cases.entry = await page.evaluate(() => ({ hasT122: !!(window.__V2_APP__ && window.__V2_APP__.t122), realEligible: (() => { try { return window.__V2_APP__.aiRealEligible(); } catch (e) { return 'ERR:' + e.message; } })() }));
  await page.click('#btnRoadshow'); await sleep(400);
  await page.click('#btnRoadshowStart');
  await page.waitForFunction('(() => { const t = window.__V2_APP__ && window.__V2_APP__.t122; if (!t) return false; const s = t.state(); return s.prepared === true; })()', null, { timeout: 60000 });
  await sleep(800);
  out.cases.prepared = await page.evaluate(() => {
    const app = window.__V2_APP__;
    const t = app.t122; const s = t.state();
    const b = document.getElementById('roadshowBadge');
    return { state: s, badge: { text: b && b.textContent, title: b && b.getAttribute('title'), cls: b && b.className }, aiSettings: (() => { try { return JSON.parse(localStorage.getItem('mozheng.ai.settings.v1') || 'null'); } catch (e) { return 'parse-error'; } })(), canvas: { w: app.engine.width, h: app.engine.height }, selection: app.state.selection, layers: app.engine.getLayers().map((l) => l.name) };
  });

  // 第 3 拍：真实视觉观察（goto(2)）
  await page.evaluate(() => window.__V2_APP__.t122.goto(2));
  await sleep(300);
  const t3 = Date.now();
  await page.click('#btnRoadshowExec');
  await page.waitForFunction('!!window.__V2_APP__.state.analysis', null, { timeout: 120000 });
  await sleep(1200);
  out.cases.observe = await page.evaluate(() => {
    const app = window.__V2_APP__;
    const last = app.state.aiLastCall || {};
    const l6 = (app.state.records || []).filter((r) => r.kind === 'critique').slice(-1)[0] || {};
    return { mock: last.mock, model: last.model, latencyMs: last.latencyMs, obsCount: (app.state.analysis && app.state.analysis.observations || []).length, obsTexts: (app.state.analysis && app.state.analysis.observations || []).map((o) => String(o.text || '').slice(0, 160)), anchors: (app.state.analysis && app.state.analysis.observations || []).map((o) => o.anchor), regions: (app.state.analysis && app.state.analysis.regions || []).map((r) => r.bbox), l6l5: l6.params && l6.params.l5_refs, memoryUsed: l6.params && l6.params.memory_used, confirmVisible: !!document.getElementById('aiConfirmModal') && document.getElementById('aiConfirmModal').classList.contains('show') };
  });
  out.cases.observe.elapsedMs = Date.now() - t3;
  out.cases.badgeAfterObserve = await page.evaluate(() => { const b = document.getElementById('roadshowBadge'); return { text: b && b.textContent, cls: b && b.className, meta: (document.getElementById('roadshowMeta') || {}).textContent }; });

  // 第 4 拍：确认/否决（无 AI 成本）
  await page.evaluate(() => window.__V2_APP__.t122.goto(3));
  await sleep(300);
  await page.click('#btnRoadshowExec');
  await sleep(1500);
  out.cases.decide = await page.evaluate(() => { const app = window.__V2_APP__; return { l5: (app.state.library && app.state.library.prefs && app.state.library.prefs.decisions) ? 'prefs' : null, obs: (app.state.analysis && app.state.analysis.observations || []).map((o) => o.status || o.source) }; });

  // 第 5 拍：预置样本落层（无 AI 成本）
  await page.evaluate(() => window.__V2_APP__.t122.goto(4));
  await sleep(300);
  await page.click('#btnRoadshowExec');
  await sleep(2000);
  out.cases.presetApply = await page.evaluate(() => {
    const app = window.__V2_APP__;
    const layers = app.engine.getLayers();
    const l = layers[layers.length - 1];
    const l6 = (app.state.records || []).filter((r) => r.kind === 'generation').slice(-1)[0] || {};
    return { layerName: l.name, layerCount: layers.length, kind: l.kind, l6cost: l6.cost_cny, params: l6.params, badge: (document.getElementById('roadshowBadge') || {}).textContent };
  });

  // 第 6 拍：证据
  await page.evaluate(() => window.__V2_APP__.t122.goto(5));
  await sleep(300);
  await page.click('#btnRoadshowExec');
  await page.waitForFunction('!!document.querySelector("#evidenceModal.show")', null, { timeout: 90000 }).catch(() => {});
  await sleep(1500);
  out.cases.evidence = await page.evaluate(() => {
    const app = window.__V2_APP__;
    const modal = document.getElementById('evidenceModal');
    const html = modal ? modal.textContent.slice(0, 500) : '';
    let ev = null;
    try { ev = app.state.lastEvidence || null; } catch (e) {}
    return { modalOpen: !!(modal && modal.classList.contains('show')), snippet: html, hasVerifyBtn: !!document.querySelector('#btnEvidenceVerify'), lastEvidence: ev };
  });

  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-roadshow-real-1920.png', fullPage: false });
  out.cases.noErrors = out.pageErrors.length === 0 && out.consoleErrors.length === 0;
  out.pass = !!out.cases.prepared && out.cases.observe.mock === false && out.cases.observe.obsCount >= 2 && out.cases.presetApply.layerCount >= 4 && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  await finish(3);
}
