// product/server/server.mjs
// 本地优先的零依赖 Node HTTP 服务（v0.1）。
//
// 设计约束（与 product/CONTRACT.md、00-产品化计划.md 一致）：
// - 只监听 127.0.0.1；端口占用自动 +1；不向任何外部域名发请求（无遥测、无静默外联）。
// - 静态服务 product/app/；/core/* 只读挂载 product/core/（前端可直接 import 共享纯逻辑）。
// - /api/ai/* 默认走 core/mock-ai.mjs；非 mock provider 返回 501（预留位，不实现网络调用）。
// - 请求体只在内存中；不写磁盘、不记录图像内容；日志仅 method/pathname/status/ms/requestId。
// - 配置：启动时读取 config/provider.json（可选，已 gitignore）；PUT /api/config 只更新内存。
//
// 运行：node server/server.mjs  （或 npm start）
// 测试：node --test test/

import http from 'node:http';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';

import { mockAnalyze, mockDirections, mockGenerate, MOCK_MODEL } from '../core/mock-ai.mjs';
import {
  isMock, sanitizeConfig, publicConfig, CONFIG_FILE_NAME,
} from './ai-proxy.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const PRODUCT_ROOT = path.resolve(__dirname, '..');
export const APP_DIR = path.join(PRODUCT_ROOT, 'app');
export const CORE_DIR = path.join(PRODUCT_ROOT, 'core');
export const CONFIG_DIR = path.join(PRODUCT_ROOT, 'config');
export const CONFIG_FILE = path.join(CONFIG_DIR, CONFIG_FILE_NAME);

export const HOST = '127.0.0.1';
export const DEFAULT_PORT = 4173;
export const MAX_PORT_TRIES = 10;
export const MAX_BODY_BYTES = 8 * 1024 * 1024;
const MOCK_MODE = 'mock';

async function readVersion() {
  try {
    const raw = await fs.readFile(path.join(PRODUCT_ROOT, 'package.json'), 'utf8');
    const pkg = JSON.parse(raw);
    return typeof pkg.version === 'string' ? pkg.version : '0.1.0';
  } catch {
    return '0.1.0';
  }
}
export const VERSION = await readVersion();

// ---------------------------------------------------------------------------
// 运行时状态（全部在内存；进程退出即失效）
// ---------------------------------------------------------------------------

const startedAt = Date.now();

const state = {
  config: { provider: 'mock', baseUrl: '', model: '', apiKey: '' },
  configSource: 'default',
  configUpdatedAt: new Date().toISOString(),
};

/**
 * 启动时（可选）加载本地 provider.json。只读，不写；解析失败只警告，不崩。
 * 安全：绝不把 apiKey 打进日志。
 */
export async function loadConfigFromFile(configFile = CONFIG_FILE) {
  try {
    const raw = await fs.readFile(configFile, 'utf8');
    const parsed = JSON.parse(raw);
    const result = sanitizeConfig(parsed, { provider: 'mock', baseUrl: '', model: '', apiKey: '' });
    if (!result.ok) return { loaded: false, reason: 'invalid_config', errors: result.errors };
    state.config = result.config;
    state.configSource = 'file';
    state.configUpdatedAt = new Date().toISOString();
    return { loaded: true };
  } catch (error) {
    if (error && error.code === 'ENOENT') return { loaded: false, reason: 'absent' };
    return { loaded: false, reason: 'unreadable' };
  }
}

export function getRuntimeConfig() {
  return state.config;
}

// ---------------------------------------------------------------------------
// 响应工具
// ---------------------------------------------------------------------------

const LOCAL_ORIGIN = /^https?:\/\/(127\.0\.0\.1|localhost)(:\d{1,5})?$/i;

function applyCors(req, res) {
  const origin = req.headers.origin;
  if (typeof origin === 'string' && LOCAL_ORIGIN.test(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Expose-Headers', 'X-Request-Id');
  }
}

function sendJson(req, res, status, body, requestId, extraHeaders = {}) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'X-Request-Id': requestId,
    ...extraHeaders,
  });
  res.end(payload);
}

function sendError(req, res, status, requestId, code, message, detail) {
  const body = { ok: false, requestId, code, message };
  if (detail !== undefined) body.detail = detail;
  sendJson(req, res, status, body, requestId);
}

const MIME = Object.freeze({
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.woff2': 'font/woff2',
  '.map': 'application/json; charset=utf-8',
});

function mimeOf(filePath) {
  return MIME[path.extname(filePath).toLowerCase()] ?? 'application/octet-stream';
}

// ---------------------------------------------------------------------------
// 安全路径解析：只允许静态根目录内，拒绝穿越 / 绝对路径 / 空字节
// ---------------------------------------------------------------------------

function safeDecodePath(pathname) {
  try {
    return decodeURIComponent(pathname);
  } catch {
    return null;
  }
}

/**
 * @returns {string|null} 绝对路径；越界或非法返回 null
 */
export function resolveWithin(root, urlPath) {
  if (typeof urlPath !== 'string') return null;
  let decoded;
  try {
    decoded = decodeURIComponent(urlPath);
  } catch {
    return null;
  }
  if (decoded.includes('\0')) return null;
  const rel = decoded.replace(/\\/g, '/').replace(/^\/+/, '');
  const normalized = path.normalize(rel);
  if (normalized.length === 0) return null;
  if (normalized.startsWith('..') || path.isAbsolute(normalized)) return null;
  const abs = path.resolve(root, normalized);
  const rootResolved = path.resolve(root);
  const prefix = rootResolved.endsWith(path.sep) ? rootResolved : rootResolved + path.sep;
  if (abs !== rootResolved && !abs.startsWith(prefix)) return null;
  return abs;
}

async function statFile(filePath) {
  try {
    const stat = await fs.stat(filePath);
    return stat;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// 请求体解析
// ---------------------------------------------------------------------------

class BodyError extends Error {
  constructor(code, message, status) {
    super(message);
    this.code = code;
    this.status = status;
    this.name = 'BodyError';
  }
}

function readBody(req, maxBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    let settled = false;
    req.on('data', (chunk) => {
      if (settled) return;
      total += chunk.length;
      if (total > maxBytes) {
        settled = true;
        reject(new BodyError('PAYLOAD_TOO_LARGE', `请求体超过上限 ${maxBytes} 字节`, 413));
        req.resume(); // 丢弃剩余数据，保持连接可写 413 响应
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (settled) return;
      settled = true;
      resolve(Buffer.concat(chunks));
    });
    req.on('error', (error) => {
      if (settled) return;
      settled = true;
      reject(new BodyError('BAD_REQUEST', `读取请求体失败：${error?.message ?? 'unknown'}`, 400));
    });
  });
}

async function readJsonBody(req, maxBytes) {
  const contentType = String(req.headers['content-type'] ?? '');
  if (!contentType.toLowerCase().includes('application/json')) {
    throw new BodyError('UNSUPPORTED_MEDIA_TYPE', 'Content-Type 必须是 application/json', 415);
  }
  const buffer = await readBody(req, maxBytes);
  if (buffer.length === 0) throw new BodyError('BAD_REQUEST', '请求体不能为空', 400);
  try {
    return JSON.parse(buffer.toString('utf8'));
  } catch {
    throw new BodyError('BAD_REQUEST', '请求体不是合法 JSON', 400);
  }
}

// ---------------------------------------------------------------------------
// 请求校验（契约 §2.2–2.4）
// ---------------------------------------------------------------------------

const RE_DATA_URL = /^data:image\/(png|jpeg|jpg|webp|svg\+xml);base64,[A-Za-z0-9+/=]+$/;
const RE_MODE = ['collab', 'attest'];
const RE_ROLE = ['tool', 'assistant', 'collaborator'];

const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const isInt = (v) => Number.isInteger(v);
const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
const isNonEmptyStr = (v) => typeof v === 'string' && v.length > 0;
const toInt = (v) => Math.round(v);

function pushIf(errors, condition, path, error) {
  if (condition) errors.push({ path, error });
}

function validateCanvas(canvas, errors) {
  if (!isObj(canvas)) {
    errors.push({ path: 'canvas', error: 'required_object' });
    return null;
  }
  pushIf(errors, !isNonEmptyStr(canvas.dataUrl), 'canvas.dataUrl', 'required_string');
  if (isNonEmptyStr(canvas.dataUrl) && !RE_DATA_URL.test(canvas.dataUrl)) {
    errors.push({ path: 'canvas.dataUrl', error: 'invalid_image_data_url' });
  }
  pushIf(errors, !isNum(canvas.width) || canvas.width < 1 || canvas.width > 8192, 'canvas.width', 'number_1_8192');
  pushIf(errors, !isNum(canvas.height) || canvas.height < 1 || canvas.height > 8192, 'canvas.height', 'number_1_8192');
  if (canvas.layerCount !== undefined) {
    pushIf(errors, !isNum(canvas.layerCount) || canvas.layerCount < 0 || canvas.layerCount > 200, 'canvas.layerCount', 'number_0_200');
  }
  if (canvas.activeLayerId !== undefined) {
    pushIf(errors, typeof canvas.activeLayerId !== 'string', 'canvas.activeLayerId', 'string');
  }
  if (errors.length > 0) return null;
  const width = toInt(canvas.width);
  const height = toInt(canvas.height);
  return {
    dataUrl: canvas.dataUrl,
    width,
    height,
    layerCount: canvas.layerCount === undefined ? undefined : toInt(canvas.layerCount),
    activeLayerId: canvas.activeLayerId,
  };
}

function validateSelection(selection, canvas, errors) {
  if (selection === undefined) return undefined;
  if (!isObj(selection)) {
    errors.push({ path: 'selection', error: 'object' });
    return null;
  }
  if (selection.mode === 'rect') {
    const rect = selection.rect;
    if (!isObj(rect)) {
      errors.push({ path: 'selection.rect', error: 'required_object' });
      return null;
    }
    const fields = ['x', 'y', 'width', 'height'];
    for (const key of fields) {
      pushIf(errors, !isNum(rect[key]), `selection.rect.${key}`, 'number');
    }
    if (errors.length === 0) {
      const x = toInt(rect.x);
      const y = toInt(rect.y);
      const width = toInt(rect.width);
      const height = toInt(rect.height);
      pushIf(errors, width < 1 || height < 1, 'selection.rect', 'positive_size');
      pushIf(errors, x < 0 || y < 0, 'selection.rect', 'non_negative_origin');
      pushIf(errors, x + width > canvas.width, 'selection.rect', 'exceeds_canvas_width');
      pushIf(errors, y + height > canvas.height, 'selection.rect', 'exceeds_canvas_height');
      return errors.length > 0 ? null : { mode: 'rect', rect: { x, y, width, height } };
    }
    return null;
  }
  if (selection.mode === 'mask') {
    if (!isNonEmptyStr(selection.maskDataUrl) || !RE_DATA_URL.test(selection.maskDataUrl)) {
      errors.push({ path: 'selection.maskDataUrl', error: 'invalid_image_data_url' });
      return null;
    }
    return { mode: 'mask', maskDataUrl: selection.maskDataUrl };
  }
  errors.push({ path: 'selection.mode', error: 'must_be_rect_or_mask' });
  return null;
}

function validateContext(context, errors) {
  if (context === undefined) return undefined;
  if (!isObj(context)) {
    errors.push({ path: 'context', error: 'object' });
    return null;
  }
  if (context.mode !== undefined) pushIf(errors, !RE_MODE.includes(context.mode), 'context.mode', 'enum');
  if (context.aiRole !== undefined) pushIf(errors, !RE_ROLE.includes(context.aiRole), 'context.aiRole', 'enum');
  if (context.userNote !== undefined) {
    pushIf(errors, typeof context.userNote !== 'string' || context.userNote.length > 500, 'context.userNote', 'string<=500');
  }
  if (context.archiveSummary !== undefined && context.archiveSummary !== null) {
    pushIf(errors, !isObj(context.archiveSummary), 'context.archiveSummary', 'object');
  }
  return { ...context };
}

function validateAnalyzeRequest(body) {
  const errors = [];
  if (!isObj(body)) return { ok: false, errors: [{ path: '', error: 'body_must_be_object' }] };
  const canvas = validateCanvas(body.canvas, errors);
  const selection = canvas ? validateSelection(body.selection, canvas, errors) : null;
  const context = validateContext(body.context, errors);
  if (errors.length > 0) return { ok: false, errors };
  return { ok: true, value: { canvas, selection, context } };
}

function validateDirectionsRequest(body) {
  const base = validateAnalyzeRequest(body);
  if (!base.ok) return base;
  const errors = [];
  if (body.count !== undefined) pushIf(errors, !isInt(body.count) || body.count < 2 || body.count > 3, 'count', 'int_2_3');
  if (body.observationIds !== undefined) {
    if (!Array.isArray(body.observationIds) || body.observationIds.length > 10 || !body.observationIds.every((v) => typeof v === 'string')) {
      errors.push({ path: 'observationIds', error: 'string_array<=10' });
    }
  }
  if (errors.length > 0) return { ok: false, errors };
  return {
    ok: true,
    value: { ...base.value, count: body.count, observationIds: body.observationIds },
  };
}

function validateGenerateRequest(body) {
  const base = validateDirectionsRequest(body);
  if (!base.ok) return base;
  const errors = [];
  if (!isNonEmptyStr(body.directionId)) errors.push({ path: 'directionId', error: 'required_string' });
  if (body.count !== undefined) pushIf(errors, !isInt(body.count) || body.count < 1 || body.count > 3, 'count', 'int_1_3');
  if (body.size !== undefined) {
    if (!isObj(body.size)) errors.push({ path: 'size', error: 'object' });
    else {
      pushIf(errors, !isInt(body.size.width) || body.size.width < 256 || body.size.width > 2048, 'size.width', 'int_256_2048');
      pushIf(errors, !isInt(body.size.height) || body.size.height < 256 || body.size.height > 2048, 'size.height', 'int_256_2048');
    }
  }
  if (errors.length > 0) return { ok: false, errors };
  return { ok: true, value: { ...base.value, directionId: body.directionId, count: body.count, size: body.size } };
}

// ---------------------------------------------------------------------------
// API 路由
// ---------------------------------------------------------------------------

function elapsedMs(startNs) {
  return Math.max(0, Math.round(Number(process.hrtime.bigint() - startNs) / 1e6));
}

function successBody(requestId, result, latencyMs, extra = {}) {
  return {
    ok: true,
    requestId,
    mode: state.config.provider === 'mock' ? MOCK_MODE : 'provider',
    model: MOCK_MODEL,
    latencyMs,
    serverTime: new Date().toISOString(),
    result,
    ...extra,
  };
}

async function handleApi(req, res, pathname, requestId, maxBodyBytes = MAX_BODY_BYTES) {
  const method = req.method ?? 'GET';

  if (pathname === '/api/health') {
    if (method !== 'GET') {
      res.setHeader('Allow', 'GET');
      return sendError(req, res, 405, requestId, 'METHOD_NOT_ALLOWED', '只允许 GET', undefined);
    }
    return sendJson(req, res, 200, {
      ok: true,
      version: VERSION,
      mode: state.config.provider === 'mock' ? MOCK_MODE : 'provider',
      provider: state.config.provider,
      network: 'none', // 无遥测、无外部请求
      telemetry: false,
      core: { archiveSchema: '0.2.0', hashChain: '0.1.0', mockAi: MOCK_MODEL },
      serverTime: new Date().toISOString(),
      uptimeSec: Math.floor((Date.now() - startedAt) / 1000),
    }, requestId);
  }

  if (pathname === '/api/config') {
    if (method === 'GET') {
      return sendJson(req, res, 200, {
        ok: true,
        requestId,
        config: publicConfig(state.config, state.configSource, state.configUpdatedAt),
      }, requestId);
    }
    if (method === 'PUT') {
      let body;
      try {
        body = await readJsonBody(req, maxBodyBytes);
      } catch (error) {
        if (error instanceof BodyError) {
          return sendError(req, res, error.status, requestId, error.code, error.message);
        }
        throw error;
      }
      const result = sanitizeConfig(body, state.config);
      if (!result.ok) {
        return sendError(req, res, 400, requestId, 'CONFIG_INVALID', '配置不合法', result.errors);
      }
      state.config = result.config;
      state.configSource = 'memory';
      state.configUpdatedAt = new Date().toISOString();
      return sendJson(req, res, 200, {
        ok: true,
        requestId,
        config: publicConfig(state.config, state.configSource, state.configUpdatedAt),
      }, requestId);
    }
    res.setHeader('Allow', 'GET, PUT');
    return sendError(req, res, 405, requestId, 'METHOD_NOT_ALLOWED', '只允许 GET / PUT');
  }

  const aiMatch = /^\/api\/ai\/(analyze|directions|generate)$/.exec(pathname);
  if (aiMatch) {
    const kind = aiMatch[1];
    if (method !== 'POST') {
      res.setHeader('Allow', 'POST');
      return sendError(req, res, 405, requestId, 'METHOD_NOT_ALLOWED', '只允许 POST');
    }
    if (!isMock(state.config)) {
      // 真实 provider 预留位：v0.1 明确不实现网络调用。
      return sendError(req, res, 501, requestId, 'NOT_IMPLEMENTED',
        `provider=${state.config.provider} 尚未接入；请 PUT /api/config 切回 mock`);
    }
    let body;
    try {
      body = await readJsonBody(req, maxBodyBytes);
    } catch (error) {
      if (error instanceof BodyError) {
        return sendError(req, res, error.status, requestId, error.code, error.message);
      }
      throw error;
    }

    const startNs = process.hrtime.bigint();
    if (kind === 'analyze') {
      const validation = validateAnalyzeRequest(body);
      if (!validation.ok) return sendError(req, res, 400, requestId, 'BAD_REQUEST', '参数校验失败', validation.errors);
      const result = mockAnalyze(validation.value);
      return sendJson(req, res, 200, successBody(requestId, result, elapsedMs(startNs)), requestId);
    }
    if (kind === 'directions') {
      const validation = validateDirectionsRequest(body);
      if (!validation.ok) return sendError(req, res, 400, requestId, 'BAD_REQUEST', '参数校验失败', validation.errors);
      const result = mockDirections(validation.value);
      return sendJson(req, res, 200, successBody(requestId, result, elapsedMs(startNs)), requestId);
    }
    const validation = validateGenerateRequest(body);
    if (!validation.ok) return sendError(req, res, 400, requestId, 'BAD_REQUEST', '参数校验失败', validation.errors);
    const result = mockGenerate(validation.value);
    return sendJson(req, res, 200, successBody(requestId, result, elapsedMs(startNs)), requestId);
  }

  return sendError(req, res, 404, requestId, 'NOT_FOUND', `未知 API：${pathname}`);
}

// ---------------------------------------------------------------------------
// 静态资源
// ---------------------------------------------------------------------------

const PLACEHOLDER_HTML = `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>Project One · 本地服务</title>
<style>body{font:15px/1.7 -apple-system,"Segoe UI",sans-serif;max-width:680px;margin:80px auto;padding:0 24px;color:#222}
code{background:#f3f3f3;padding:2px 6px;border-radius:4px}.ok{color:#0a7d32}</style></head>
<body><h1>Project One 本地服务已启动</h1>
<p class="ok">✓ 服务运行中（仅本机 127.0.0.1）</p>
<p>但 <code>product/app/</code> 尚未就绪（前端正在开发）。</p>
<ul><li>健康检查：<a href="/api/health">/api/health</a></li>
<li>接口契约：<code>product/CONTRACT.md</code></li>
<li>前端就绪后刷新本页即可。</li></ul></body></html>`;

async function sendFile(req, res, absPath) {
  const data = await fs.readFile(absPath);
  res.writeHead(200, {
    'Content-Type': mimeOf(absPath),
    'Content-Length': data.length,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(req.method === 'HEAD' ? undefined : data);
}

async function handleStatic(req, res, pathname, requestId) {
  const method = req.method ?? 'GET';
  if (method !== 'GET' && method !== 'HEAD') {
    res.setHeader('Allow', 'GET, HEAD');
    return sendError(req, res, 405, requestId, 'METHOD_NOT_ALLOWED', '静态资源只允许 GET / HEAD');
  }

  // 1) /core/* 只读挂载（仅 .mjs，供前端 import 共享纯逻辑）
  if (pathname === '/core' || pathname.startsWith('/core/')) {
    const rel = pathname.replace(/^\/core\/?/, '');
    if (!rel) return sendError(req, res, 404, requestId, 'NOT_FOUND', '未找到该模块');
    const abs = resolveWithin(CORE_DIR, `/${rel}`);
    if (!abs || path.extname(abs).toLowerCase() !== '.mjs') {
      return sendError(req, res, 404, requestId, 'NOT_FOUND', '未找到该模块');
    }
    const stat = await statFile(abs);
    if (!stat || !stat.isFile()) return sendError(req, res, 404, requestId, 'NOT_FOUND', '未找到该模块');
    return sendFile(req, res, abs);
  }

  // 2) 其他 GET：product/app/
  const rel = pathname === '/' ? '/index.html' : pathname;
  let abs = resolveWithin(APP_DIR, rel);
  if (!abs) return sendError(req, res, 400, requestId, 'BAD_REQUEST', '非法路径');

  let stat = await statFile(abs);
  if (stat && stat.isDirectory()) {
    abs = resolveWithin(APP_DIR, path.posix.join(rel.replace(/\\/g, '/'), 'index.html'));
    stat = abs ? await statFile(abs) : null;
  }
  if (stat && stat.isFile()) return sendFile(req, res, abs);

  // 3) SPA 回退：无扩展名的路径 → app/index.html
  if (!path.extname(pathname)) {
    const fallback = path.join(APP_DIR, 'index.html');
    const fallbackStat = await statFile(fallback);
    if (fallbackStat && fallbackStat.isFile()) return sendFile(req, res, fallback);
    // 4) app 未就绪：返回友好的占位页（M0 验收：空 app 也能打开）
    res.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Request-Id': requestId,
    });
    return res.end(PLACEHOLDER_HTML);
  }

  return sendError(req, res, 404, requestId, 'NOT_FOUND', '未找到该文件');
}

// ---------------------------------------------------------------------------
// 服务器
// ---------------------------------------------------------------------------

/**
 * 创建 http.Server（不监听）。
 * @param {{maxBodyBytes?:number, logger?:false|((line:string)=>void)}} [options]
 */
export function createAppServer(options = {}) {
  const maxBodyBytes = options.maxBodyBytes ?? MAX_BODY_BYTES;
  const logger = options.logger === false ? null : (options.logger ?? ((line) => console.log(line)));

  const server = http.createServer((req, res) => {
    const requestId = `r_${randomUUID().replace(/-/g, '').slice(0, 8)}`;
    const startNs = process.hrtime.bigint();
    const pathname = safeDecodePath(new URL(req.url ?? '/', `http://${HOST}`).pathname) ?? '/';

    applyCors(req, res);
    if (req.method === 'OPTIONS') {
      res.writeHead(204, { 'X-Request-Id': requestId });
      res.end();
      if (logger) logger(`[opt] ${pathname} 204 ${elapsedMs(startNs)}ms ${requestId}`);
      return;
    }

    const finish = () => {
      if (!logger) return;
      const status = res.statusCode;
      // 只记录 method / pathname / status / 耗时 / requestId（不含 query 与请求体）
      logger(`[api] ${req.method} ${pathname} ${status} ${elapsedMs(startNs)}ms ${requestId}`);
    };
    res.on('finish', finish);

    const route = async () => {
      if (pathname === '/api' || pathname.startsWith('/api/')) {
        await handleApi(req, res, pathname, requestId, maxBodyBytes);
        return;
      }
      await handleStatic(req, res, pathname, requestId);
    };

    route().catch((error) => {
      // 不向客户端暴露内部细节；不记录请求体内容。
      const message = error?.name === 'BodyError' ? error.message : '服务内部错误';
      const code = error?.name === 'BodyError' ? error.code : 'INTERNAL';
      const status = error?.name === 'BodyError' ? error.status : 500;
      if (!res.headersSent) sendError(req, res, status, requestId, code, message);
      else res.end();
    });
  });

  server.maxBodyBytes = maxBodyBytes;
  return server;
}

/**
 * 启动服务：只监听 127.0.0.1；端口占用自动 +1（最多 10 次）。
 * @param {{port?:number, host?:string, maxBodyBytes?:number, logger?:false|Function, loadConfigFile?:boolean}} [options]
 * @returns {Promise<{server:import('node:http').Server, port:number, url:string, close:()=>Promise<void>}>}
 */
export async function startServer(options = {}) {
  const requested = Number.isInteger(options.port) ? options.port : (Number(process.env.PORT) || DEFAULT_PORT);
  const host = options.host ?? HOST;
  if (host !== HOST) throw new Error(`只允许监听 ${HOST}（本机）；拒绝 host=${host}`);

  if (options.loadConfigFile !== false) await loadConfigFromFile();

  const previousConfig = state.config;
  const server = createAppServer(options);
  let port = requested;

  const listen = (p) => new Promise((resolve, reject) => {
    const onError = (error) => {
      server.removeListener('listening', onListening);
      reject(error);
    };
    const onListening = () => {
      server.removeListener('error', onError);
      resolve();
    };
    server.once('error', onError);
    server.once('listening', onListening);
    server.listen(p, host);
  });

  if (requested === 0) {
    await listen(0);
    port = server.address().port;
  } else {
    let lastError = null;
    for (let attempt = 0; attempt < MAX_PORT_TRIES; attempt += 1) {
      try {
        await listen(requested + attempt);
        port = server.address().port;
        lastError = null;
        break;
      } catch (error) {
        lastError = error;
        if (error?.code !== 'EADDRINUSE') throw error;
      }
    }
    if (lastError) {
      state.config = previousConfig;
      throw new Error(`端口 ${requested}–${requested + MAX_PORT_TRIES - 1} 都被占用，无法启动`);
    }
  }

  const url = `http://${host}:${port}`;
  return {
    server,
    port,
    url,
    close: () => new Promise((resolve) => {
      server.close(() => resolve());
      server.closeAllConnections?.();
    }),
  };
}

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------

const isMain = (() => {
  const entry = process.argv[1];
  if (!entry) return false;
  try {
    return path.resolve(entry) === fileURLToPath(import.meta.url);
  } catch {
    return false;
  }
})();

if (isMain) {
  startServer()
    .then(({ url, port, close }) => {
      console.log('');
      console.log('  Project One · 本地服务');
      console.log(`  → ${url}`);
      console.log(`  → 仅监听 127.0.0.1:${port}（不对外网开放；无遥测、无外部请求）`);
      console.log('  → mock 模式：完全离线可用；Ctrl+C 退出');
      console.log('');
      const shutdown = () => {
        console.log('\n  正在关闭…');
        close().then(() => process.exit(0));
      };
      process.on('SIGINT', shutdown);
      process.on('SIGTERM', shutdown);
    })
    .catch((error) => {
      console.error(`启动失败：${error?.message ?? error}`);
      process.exitCode = 1;
    });
}
