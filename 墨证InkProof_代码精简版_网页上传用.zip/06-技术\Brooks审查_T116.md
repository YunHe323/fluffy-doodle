# Brooks-Lint Review — T116 结构化文字层 / 调整层原子 undo

**Mode:** PR Review  
**Scope:** 本轮变更文件：`v2/engine/src/v2doc.js`、`v2/engine/src/engine.js`、`v2/app/js/app.js`（调整层/文字层/更多菜单相关段）、`v2/app/index.html`、`v2/app/css/ui-polish.css`、`v2/app/test-adjust-layer.mjs`、`v2/app/test-text-edit.mjs`、`v2/app/test-more-menu.mjs`  
**Health Score:** 87/100

本轮功能可用、测试覆盖了核心路径；但主 UI 逻辑仍在 `app.js` 内部继续膨胀，且新增的“结构化文字/调整层”仍有双重存储与快照语义命名风险。

---

## Findings

### 🟡 Warning

**Cognitive Overload — `applyAdjustmentsFromModal` 承担了过多职责**
Symptom: 该函数约 55 行，同时完成参数读取、调整层/普通层分支、源层查找、像素变换、图层创建/替换、L6 记录、UI 收口；两个分支各自 20+ 行。
Source: Fowler — Refactoring（Long Method · Divergent Change）；McConnell — Code Complete Ch.7
Consequence: 任何调整层逻辑变化都要在长函数里改多处；后续加“蒙版限制范围/实时调整”时会继续膨胀，回归面难以控制。
Remedy: 抽出 `adjustment-service`（纯函数：参数校验、source 解析、生成 adjusted PNG、返回 patch 描述），`app.js` 只保留 `createAdjustmentLayer` / `updateAdjustmentLayer` 两个薄入口。

**Knowledge Duplication — 文字信息同时存 `layer.text` 与 `layer.meta.text`**
Symptom: 创建/编辑文字时同时写 `engine.setLayerInfo({kind:'text',text})` 和 `engine.setLayerMeta({text:{...}})`；`syncTextLayersFromEngine` 读取时以 `l.text || l.meta.text` 兜底。
Source: Hunt & Thomas — The Pragmatic Programmer（DRY）；Fowler — Refactoring（Duplicate Code）
Consequence: 两份文字字段会随时间漂移（例如某次只改 meta 或只改 top-level），二次编辑/保存/加载可能取到旧值；迁移成本随文字功能增长。
Remedy: 明确 `layer.text` 为唯一权威，`meta.text` 只保留一个版本的只读迁移；补一次 `normalizeDoc` 迁移，把旧 `meta.text` 提升到 `text` 并在新写入时移除 meta 副本。

### 🟢 Suggestion

**Domain Model Distortion — “非破坏调整层”实际是快照缓存**
Symptom: 数据是 `kind:'adjust'` + 参数 + 栅格缓存；源层后续变化不会自动更新；UI 文案主要说“参数可重开”，直到 badge title 才说明“源层后续改动不会自动更新”。
Source: Evans — Domain-Driven Design（Ubiquitous Language）
Consequence: 用户可能误以为调整层像 Photoshop 调整层一样实时作用于下方内容，产生“为什么源层改了调整层没变”的预期落差。
Remedy: 在数据中显式记录 `adjust.mode:'snapshot-cache'`（或 `adjustEngine:'raster-cache'`），UI 层名/弹窗副标题直接显示“快照”，并在重开参数时提示“将按当前源层重算”。

**Accidental Complexity — 两个 replace 方法几乎重复**
Symptom: `replaceLayerFromDataUrl` 与 `replaceLayerFromDataUrlWithInfo` 的解码、before/after 快照、undo push、present 流程几乎完全一致，只差 info 快照。
Source: Fowler — Refactoring（Duplicate Code）；Ousterhout — A Philosophy of Software Design（deep module）
Consequence: 修 undo/性能问题时容易只改一个方法，造成文字/调整层与普通替换行为不一致。
Remedy: 抽内部 `_replaceLayerWithEncoded(layerId,img,info?)`，两个公开方法只做参数适配。

**Test Obscurity — 新增 E2E 断言缺少消息/场景名**
Symptom: `test-adjust-layer.mjs` / `test-text-edit.mjs` 的 `page.evaluate` 内一次返回多个布尔字段，最终 `pass` 由一长串 `&&` 组合；失败时只知道整体 false，不知道哪条断言失败。
Source: Meszaros — xUnit Test Patterns（Assertion Roulette）
Consequence: QA 回归失败时定位成本高，容易误判为环境问题。
Remedy: 为每个 case 输出独立 `ok`/`reason`，或把长布尔链拆成命名断言；保留现有 JSON 结构即可。

---

## Summary

本轮最值得做的是把调整/文字逻辑从 `app.js` 长函数中抽成服务，并统一 `layer.text` 单一权威；这两项会直接降低后续“结构化文字 MVP、蒙版调整层”的回归成本。整体趋势是功能在稳步推进，但 `app.js` 的职责密度在上升，建议下一轮先做一次小范围抽取再继续加功能。

**Recommended fix order:** R1 调整服务抽取 → R3 文字字段单一权威 → R6 快照语义 → R4 replace 合并 → 测试断言拆分。
