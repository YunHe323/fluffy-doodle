/**
 * v2 engine · 导出 Worker（T76）
 * 主线程分块 readPixels（RGBA）→ transfer 到本 Worker → OffscreenCanvas.putImageData → convertToBlob('image/png')
 * 零第三方依赖；只在 Worker 内持有 OffscreenCanvas，主线程无大块编码任务。
 */
let canvas = null;
let ctx = null;
let total = 0;
let done = 0;

self.onmessage = async (ev) => {
  const msg = ev.data || {};
  try {
    if (msg.type === 'init') {
      canvas = new OffscreenCanvas(msg.width, msg.height);
      ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('OffscreenCanvas 2D 不可用');
      total = msg.total || 0;
      done = 0;
      self.postMessage({ type: 'ready' });
      return;
    }
    if (msg.type === 'tile') {
      const pixels = new Uint8ClampedArray(msg.buffer);
      const imageData = new ImageData(pixels, msg.width, msg.height);
      ctx.putImageData(imageData, msg.x, msg.y);
      done += 1;
      if (total && (done % 8 === 0 || done === total)) self.postMessage({ type: 'progress', done, total });
      return;
    }
    if (msg.type === 'finish') {
      const blob = await canvas.convertToBlob({ type: 'image/png' });
      self.postMessage({ type: 'done', blob, width: canvas.width, height: canvas.height, tiles: done });
      return;
    }
    if (msg.type === 'doc-tile') {
      // T79：单 tile PNG 编码（保存路径；主线程只 readPixels/组装 JSON）
      const pixels = new Uint8ClampedArray(msg.buffer);
      const tileCanvas = new OffscreenCanvas(msg.width, msg.height);
      const tileCtx = tileCanvas.getContext('2d');
      tileCtx.putImageData(new ImageData(pixels, msg.width, msg.height), 0, 0);
      const blob = await tileCanvas.convertToBlob({ type: 'image/png' });
      const buffer = await blob.arrayBuffer();
      self.postMessage({ type: 'doc-tile-done', id: msg.id, buffer }, [buffer]);
      return;
    }
    if (msg.type === 'cancel') {
      canvas = null; ctx = null; total = 0; done = 0;
      self.postMessage({ type: 'cancelled' });
    }
  } catch (e) {
    self.postMessage({ type: 'error', message: String((e && e.message) || e) });
  }
};
