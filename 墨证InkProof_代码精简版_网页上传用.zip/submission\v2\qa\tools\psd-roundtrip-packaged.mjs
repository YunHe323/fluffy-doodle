// v2/qa/tools/psd-roundtrip-packaged.mjs —— 在干净提交包（submission/，端口 4201）上验证 PSD 导入→导出
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '../node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const BASE = process.env.BASE || 'http://127.0.0.1:4201';
const PSD = path.join(ROOT, 'v2', 'psd', 'results', 'samples', '01-pure-raster-source.psd');
const out = { schema: 'mozheng.psd.packaged.v1', base: BASE, pass: false };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
try {
  const ctx = await b.newContext({ viewport: { width: 1920, height: 1080 }, acceptDownloads: true });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => out.pageError = String(e.message || e).slice(0, 300));
  p.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.consoleError = m.text().slice(0, 300); });
  await p.goto(BASE + '/v2/app/index.html', { waitUntil: 'domcontentloaded' });
  await p.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
  await sleep(900);
  await p.setInputFiles('#psdFileInput', PSD);
  await p.waitForFunction('window.__V2_APP__.engine.getLayers().length > 0', null, { timeout: 60000 });
  await sleep(2500);
  out.imported = await p.evaluate(() => { const a = window.__V2_APP__; return { layers: a.engine.getLayers().map((l) => ({ name: l.name, kind: l.kind })), canvas: [a.engine.width, a.engine.height], groups: a.engine.getGroups().length }; });
  await p.screenshot({ path: path.join(ROOT, 'v2', 'app', 'ui-psd-packaged.png') });
  const [dl] = await Promise.all([p.waitForEvent('download', { timeout: 90000 }), p.evaluate(() => window.__V2_APP__.t81.exportPsdDownload())]);
  const save = path.join(ROOT, 'v2', 'qa', 'tools', 'psd-packaged-export.psd');
  await dl.saveAs(save);
  const buf = fs.readFileSync(save);
  out.exported = { bytes: buf.length, head: String.fromCharCode(...buf.subarray(0, 4)), file: save };
  out.pass = out.imported.layers.length > 0 && out.exported.head === '8BPS' && out.exported.bytes > 1000 && !out.pageError;
  console.log(JSON.stringify(out, null, 2));
  await b.close();
  process.exit(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  console.log(JSON.stringify(out, null, 2));
  try { await b.close(); } catch (err) {}
  process.exit(3);
}
