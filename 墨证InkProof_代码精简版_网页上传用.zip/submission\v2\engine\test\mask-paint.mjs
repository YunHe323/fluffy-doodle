#!/usr/bin/env node
// v2/engine/test/mask-paint.mjs —— T84 蒙版笔触 white/black 测试（零依赖 CDP）
// 用法：node v2/engine/test/mask-paint.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const checks = {};
  async function mkEngine() {
    const canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 512;
    const eng = new Engine({ canvas, width: 512, height: 512, layers: 2 });
    await eng.init(); eng.setBrush({ type: 'hard', sizePx: 90 });
    return eng;
  }
  const drawRow = (eng, y0, y1) => {
    for (let y = y0; y <= y1; y += 40) {
      eng.beginStroke({ x: 20, y, pressure: 0.9, timestamp: performance.now(), pointerType: 'synthetic' });
      for (let i = 1; i < 16; i += 1) eng.appendPoint({ x: 20 + i * 30, y, pressure: 0.9, timestamp: performance.now(), pointerType: 'synthetic' });
      eng.endStroke();
    }
  };
  const regionInk = async (url, x0, y0, x1, y1) => {
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const cx = c.getContext('2d'); cx.drawImage(img, 0, 0);
    const d = cx.getImageData(0, 0, c.width, c.height).data;
    let ink = 0;
    for (let y = y0; y < y1; y += 1) for (let x = x0; x < x1; x += 1) {
      const i = (y * c.width + x) * 4;
      if (d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220) ink += 1;
    }
    return ink;
  };
  const eng = await mkEngine();
  drawRow(eng, 60, 460); await raf(); await raf();
  const layer = eng.getLayers().find((l) => l.id === eng.activeLayerId) || eng.getLayers()[1];
  eng.setActiveLayer(layer.id);
  const beforeInk = await regionInk(await eng.getCompositeDataUrl(), 40, 80, 460, 420);
  // ---- 图层蒙版 black 隐藏 / 白恢复 ----
  eng.addMask(layer.id);
  eng.setActiveTarget('mask');
  eng.setMaskStrokePaint('black');
  eng.beginStroke({ x: 100, y: 120, pressure: 1, timestamp: performance.now(), pointerType: 'synthetic' }, { maskPaint: 'black' });
  for (let i = 1; i < 12; i += 1) eng.appendPoint({ x: 100 + i * 25, y: 120, pressure: 1, timestamp: performance.now(), pointerType: 'synthetic' });
  await raf();
  const liveUrl = await eng.getCompositeDataUrl(); // 实时预览
  const liveHidden = await regionInk(liveUrl, 80, 90, 360, 150);
  eng.endStroke(); await raf(); await raf();
  const afterBlackUrl = await eng.getCompositeDataUrl();
  const blackHidden = await regionInk(afterBlackUrl, 80, 90, 360, 150);
  const blackVisibleElse = await regionInk(afterBlackUrl, 80, 300, 460, 420);
  checks.layerLiveHidden = liveHidden < 200;
  checks.layerBlackHides = blackHidden < 200 && blackVisibleElse > 1000;
  checks.layerKeepsContent = (await regionInk(afterBlackUrl, 40, 80, 460, 420)) > beforeInk * 0.5;
  eng.undo(); await raf();
  checks.layerUndo = (await regionInk(await eng.getCompositeDataUrl(), 80, 90, 360, 150)) > 200;
  eng.setMaskStrokePaint('white');
  eng.beginStroke({ x: 100, y: 120, pressure: 1, timestamp: performance.now(), pointerType: 'synthetic' }, { maskPaint: 'white' });
  for (let i = 1; i < 12; i += 1) eng.appendPoint({ x: 100 + i * 25, y: 120, pressure: 1, timestamp: performance.now(), pointerType: 'synthetic' });
  eng.endStroke(); await raf();
  checks.layerWhiteRestore = (await regionInk(await eng.getCompositeDataUrl(), 80, 90, 360, 150)) > 200;
  // ---- 组蒙版 black / 白 ----
  const g = await mkEngine();
  g.addGroup('G'); const group = g.getGroups()[0];
  g.addLayer({ name: '组内层', group: group.id });
  const gl = g.getLayers().find((l) => l.group === group.id);
  g.setActiveLayer(gl.id); drawRow(g, 60, 460); await raf();
  g.addGroupMask(group.id); g.setActiveGroup(group.id); g.setActiveTarget('group-mask');
  // 预填全白组蒙版（模拟已显示），再用黑色隐藏指定区域
  for (let ty = 0; ty < 2; ty += 1) for (let tx = 0; tx < 2; tx += 1) {
    const tile = g.maskStore.ensureTile(group.id, ty + ',' + tx);
    const c = tile.surface.getCanvas();
    const p = new g.CK.Paint(); p.setColor(g.CK.Color(255, 255, 255, 1)); c.drawRect([0, 0, 256, 256], p); p.delete();
    tile.surface.flush(); tile.image = tile.surface.makeImageSnapshot();
  }
  g.setMaskStrokePaint('black');
  g.beginStroke({ x: 100, y: 120, pressure: 1, timestamp: performance.now(), pointerType: 'synthetic' }, { maskPaint: 'black' });
  for (let i = 1; i < 12; i += 1) g.appendPoint({ x: 100 + i * 25, y: 120, pressure: 1, timestamp: performance.now(), pointerType: 'synthetic' });
  g.endStroke(); await raf(); await raf();
  const gUrl = await g.getCompositeDataUrl();
  const gHiddenInk = await regionInk(gUrl, 150, 105, 250, 135);
  const gVisibleInk = await regionInk(gUrl, 80, 300, 460, 420);
  checks.groupBlackHides = gHiddenInk < 200 && gVisibleInk > 1000;
  const mt = g.maskStore.get(group.id, '0,0');
  let maskA = null;
  if (mt && mt.image) {
    const px = mt.image.readPixels(0, 0, { width: 256, height: 256, colorType: g.CK.ColorType.RGBA_8888, alphaType: g.CK.AlphaType.Unpremul, colorSpace: g.CK.ColorSpace.SRGB });
    maskA = [px[(120 * 256 + 200) * 4 + 3], px[(300 * 256 + 200) * 4 + 3], px[(120 * 256 + 200) * 4], px[(120 * 256 + 200) * 4 + 1]];
  }
  checks.groupInk = { hidden: gHiddenInk, visible: gVisibleInk, groupVisible: g.getGroups()[0].visible, mask: g.getGroups()[0].mask, keys: g.maskStore.listTiles(group.id), alpha: maskA, layers: g.getLayers().map((l) => ({ id: l.id, group: l.group, visible: l.visible })) };
  g.undo(); await raf();
  checks.groupUndo = (await regionInk(await g.getCompositeDataUrl(), 150, 105, 250, 135)) > 200;
  // ---- 序列化 roundtrip ----
  const json = g.serializeDoc();
  const g2 = await mkEngine();
  g2.deserializeDoc(json); await raf();
  checks.serializeTiles = g2.maskStore.listTiles(group.id).length > 0;
  // 黑笔触后再序列化：先重做 black，确认隐藏后保存
  // （undo 后状态为隐藏前；这里重新做 black 并保存）
  g.setMaskStrokePaint('black');
  g.beginStroke({ x: 100, y: 120, pressure: 1, timestamp: performance.now(), pointerType: 'synthetic' }, { maskPaint: 'black' });
  for (let i = 1; i < 12; i += 1) g.appendPoint({ x: 100 + i * 25, y: 120, pressure: 1, timestamp: performance.now(), pointerType: 'synthetic' });
  g.endStroke(); await raf();
  const json2 = g.serializeDoc();
  const g3 = await mkEngine();
  g3.deserializeDoc(json2); await raf();
  checks.serializeRoundtrip = (await regionInk(await g3.getCompositeDataUrl(), 150, 105, 250, 135)) < 100;
  // ---- 普通笔触不受影响 ----
  const n = await mkEngine();
  n.setMaskStrokePaint('black');
  drawRow(n, 200, 200);
  checks.normalStroke = (await regionInk(await n.getCompositeDataUrl(), 20, 180, 500, 220)) > 500;
  eng.dispose(); g.dispose(); g2.dispose(); g3.dispose(); n.dispose();
  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  return { ok: checks.ok, checks, environment: { headless: /HeadlessChrome/.test(navigator.userAgent) } };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 240000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value || !value.checks) { console.error('无返回/异常', JSON.stringify(r).slice(0, 4000)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
