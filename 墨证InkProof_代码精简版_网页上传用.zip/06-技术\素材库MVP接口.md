# 素材库 MVP 接口（T70）

> 项目一 · v2 私人素材库｜作者：tech-architect｜版本 v1.0｜日期 2026-11-07
> 给 **T71（app UI）** 接入；实现：`v2/library/`；测试：`v2/library/test/library.mjs` → `v2/library/results/library.json`。
> 约束：零第三方运行时依赖（IndexedDB / crypto.subtle / Canvas）；mock 反解复用 `v2/app/core/mock-ai.mjs`（`mock-ai@0.1.0`）。

---

## 1. 数据模型：Asset

| 字段 | 说明 |
|---|---|
| `id` | `asset-<sha256 前 16 hex>` |
| `sha256` | 原图字节 SHA-256（去重键，唯一索引） |
| `fileName/mime/bytes/width/height` | 原始文件元数据（L0） |
| `createdAt/updatedAt` | 导入/更新时间 |
| `tags[]` | 自动标签（mood/medium/subject/区域 label）+ 用户编辑 |
| `palette[]` | 主色 hex（抽 32×32 采样，最多 8） |
| `usageCount` | 使用次数（偏好输入） |
| `L0` | 原件记录：`layer:'L0', source:'observed', author:'user', anchor:{type:'whole'}` |
| `L1` | 全局：summary/subject/medium/palette/mood，`source:'inferred'`, confidence, anchor whole |
| `L2[]` | 区域：label/bbox/anchor `{type:'bbox',value:[x,y,w,h]}`/importance，`source:'inferred'` |
| `L4[]` | 开放观察：text/kind/anchor/evidenceRefs/modelVersion，`source:'inferred'`, author 'ai' |
| `L5[]` | 用户决策：`kind:'confirm'|'reject'|'use'`, tags, at, `source:'user-confirmed'` |
| `source[]` | 三态集合 `observed/inferred/user-confirmed` |
| `modelVersion` | `mock-ai@0.1.0`（mock 边界清晰） |
| `projectRefs[]` | 预留（画布项目引用） |

- 字段命名对齐 v0.1 `v2/app/core/archive-schema.mjs`（L0–L6/来源三态/anchor/confidence）；`toArchiveRecords(asset)` 可导出 L0/L1/L2/L4/L5 记录供既有档案流使用。
- **原件不入库**：只存 sha/元数据/缩略图/反解；去重基于 sha256；需要原件可后续用 OPFS/File System（T71+）。

---

## 2. IndexedDB（持久化）

DB：`mozheng-library`（**version 2**，可传 `dbName` 隔离测试；v1→v2 自动新增 `originals` store，旧素材无原图时回退缩略图）

| store | key | 索引/说明 |
|---|---|---|
| `assets` | `id` | `sha256` unique、`tags` multiEntry、`createdAt` |
| `thumbnails` | `id` | `{id,dataUrl,width,height}`（PNG，最长边 320） |
| `originals` | `id` | **T74**：`{id,blob,mime,bytes,width,height,sha256}`（原图 Blob；sha 去重后唯一） |
| `meta` | `key` | 预留（偏好缓存/迁移版本） |

- 导入前按 `sha256` 查重：重复文件计入 `duplicates`，不重复读图/反解/存原图。
- 导入时保存**原图 Blob**（File 直接存，dataURL 重建 Blob）；缩略图/反解仍按原图生成；刷新/重开后可取原图。
- 关闭后重开数据仍在（测试覆盖）；`LibraryAPI.destroy()` 删除整库（测试/重置用）。

---

## 3. API（`v2/library/api.mjs`）

```js
import { createLibrary } from './library/api.mjs';        // 或 new LibraryAPI({dbName}).init()
const api = await createLibrary();

// 导入（批量、去重、缩略图、mock 反解、写库）
const { imported, duplicates, errors, total } = await api.importFiles(fileList, {
  onProgress: ({index,total,imported,duplicates,errors}) => {},
});
// 也可直接传 dataURL（粘贴/测试）：api.importDataUrls([{name,dataUrl,mime}])

const assets = await api.list();
const hits = await api.search({ text: '冷调', tags: ['pencil'], color: '#c030', minWidth: 200 });
const one = await api.get(id);
const thumb = await api.getThumbnail(id);       // {dataUrl,width,height}

// T74：原图（demo 插入画布 / 作为 AI 参考）
const orig = await api.getOriginal(id, { objectUrl: true, imageBitmap: true });
// { blob, mime, bytes, width, height, url?, imageBitmap? }；url 用后 revokeObjectURL，bitmap 用后 close
const assetWithOrig = await api.getAsset(id, { withOriginal: true });

await api.updateTags(id, ['我的标签']);
await api.delete(id);

// 偏好（L5 确认/否决 + 使用次数；不训练）
await api.confirm(id, { tags: ['冷调'] });
await api.reject(id, { tags: ['过于杂乱'] });
await api.markUsed(id);                          // usageCount + L5 use
const prefs = await api.preferences();
// { decisions, uses, topTags:[{tag,score,confirm,reject,uses}], positiveTags, negativeTags, summary }
await api.resetPreferences();

const stats = await api.stats();                 // {total,bySource,layers:{L2,L4,L5},topTags,storage:{originals,originalBytes},modelVersion}
await api.close();
```

- `search` 过滤：`text`（文件名/tag/L1 summary/subject/mood/L2 label）、`tags`（AND）、`color`（palette 前缀）、`min/maxWidth|Height`；MVP 为内存过滤（库小；后续可下推 IndexedDB）。
- 导入串行（`_importing` 锁），进度回调；单张失败进 `errors` 不阻塞其它。
- 偏好权重：`score = confirm*2 + use*1 - reject*2`；`topTags` 排序；`summary` 可直接展示「已读懂偏好…；避免…」。
- mock 边界：`modelVersion='mock-ai@0.1.0'`；L1/L2/L4 标签/观察为**确定性 mock**（按图片 dataURL 种子），不代表真实语义理解；UI 必须标注「mock」。L2 数量 1–3、L4 2–4（mock 实现范围）。

---

## 4. T71 UI 接入清单

1. **导入区**：拖入/选择文件 → `api.importFiles(files,{onProgress})`；进度条展示 imported/duplicates/errors；重复文件提示「已存在（sha 去重）」。
2. **素材网格**：`api.list()` 或 `api.search(filters)`；用 `getThumbnail(id)` 懒加载缩略图；显示 tags/palette 小色块。
3. **详情面板**：L0 元数据、L1 summary/palette/mood、L2 区域（画 bbox 高亮）、L4 观察（text + anchor）、L5 决策历史；标注来源三态与 `confidence`、`mock` 标记。
4. **搜索/筛选栏**：文本、tag chips、颜色、尺寸；调 `api.search`。
5. **偏好条**：`api.preferences()` → 展示 positive/negative tags + summary；确认/否决按钮 → `confirm/reject`；素材使用（插入画布）时 `markUsed`。
6. **刷新/重开**：直接复用 DB（`createLibrary()` 默认 `mozheng-library`）；首次打开需处理空库/迁就旧版本。
7. **画布联动（demo 关键）**：素材卡拖入画布时 `getOriginal(id, {imageBitmap:true})` → 用 ImageBitmap/原图 Blob 绘制到 canvas（不要用 320 缩略图）→ `markUsed(id)`；作为 AI 参考时传原图 Blob/ImageBitmap（mock AI 输入仍可用缩略图，但展示/插入用原图）；项目引记录 `projectRefs` 预留。
8. **清空/重置**：设置里提供 `resetPreferences()`；开发工具用 `destroy()`。

---

## 5. 测试结果（headless Chrome）

`v2/library/test/library.mjs` → `results/library.json`：**ok=true，24 项全过**（T74 新增原图检查）：

- 批量导入 4（3 新 + 1 sha 重复）、去重、错误 0；
- L0 observed / L1 inferred / L2 1–4 / L4 2–5、confidence/anchor 合法、source 三态；
- tags/palette/缩略图/archive 记录；
- 文本/tag/颜色/尺寸搜索；
- 偏好：confirm/reject/use → decisions=2、uses=2、positive/negative/summary；
- **原图**：`getOriginal` 返回 Blob（bytes/type/宽高与源一致、sha 校验一致）、ObjectURL、ImageBitmap（1024×768 校验）；`getAsset({withOriginal})`；关库重开原图仍一致；删除素材同步删原图；`stats.storage.originals` 正确；1024×768 导入耗时 <8s（本机 headless）；测试库清理。

---

## 6. 已知限制

- mock 反解非真实语义（确定性占位）；L2/L4 数量/文本由 mock 规则决定；UI 必须标 mock。
- 原图存 IndexedDB Blob（按 sha 去重）；注意浏览器存储配额（大库需提示/清理策略），原图解码用 `createImageBitmap` 按需、用后 `close()`，不要同时保留大量 bitmap。
- 搜索为内存过滤（MVP）；大库需下推索引/分页。
- 偏好为简单加权，不训练、不学习模型权重；L5 目标可为 region（targetId 预留）但 MVP UI 先按整素材。
- 文件仅支持浏览器可解码图片（png/jpg/webp 等）；PSD 需先经 canvas/engine 导出图。
