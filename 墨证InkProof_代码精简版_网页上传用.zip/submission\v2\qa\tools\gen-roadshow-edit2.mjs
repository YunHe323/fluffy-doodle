// v2/qa/tools/gen-roadshow-edit2.mjs —— 用 base 图生成一张差异更明显的「冷雾 + 晨光」编辑样本
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const OUT = path.join(ROOT, 'v2', 'app', 'demo');
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'v2', '.ai-config.json'), 'utf8'));
const p = cfg.providers && cfg.providers.qwen ? cfg.providers.qwen : {};
const apiKey = p.apiKey || cfg.apiKey;
const base = (p.imageBaseUrl || cfg.imageBaseUrl || 'https://dashscope.aliyuncs.com').replace(/\/$/, '');
const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const PROMPT = '把中景的雾带改为明显的清晨冷雾：浓密、分层、偏冷蓝灰，加入从右侧山口斜射进来的柔和晨光光束；保留远山轮廓、近水的手绘笔触与纸张纹理，前景水体结构不变，不要添加任何文字或水印';
const src = path.join(OUT, 'roadshow-base.png');
if (!fs.existsSync(src)) { console.error('NO_BASE'); process.exit(2); }
const b64 = fs.readFileSync(src).toString('base64');
const dataUrl = 'data:image/png;base64,' + b64;
const model = p.imageEditModel || 'qwen-image-3.0-pro';
const t0 = Date.now();
const res = await fetch(base + '/api/v1/services/aigc/multimodal-generation/generation', {
  method: 'POST',
  headers: { 'content-type': 'application/json', authorization: 'Bearer ' + apiKey },
  body: JSON.stringify({ model, input: { messages: [{ role: 'user', content: [{ image: dataUrl }, { text: PROMPT }] }] }, parameters: { prompt_extend: true, watermark: false, enable_thinking: false } }),
});
if (!res.ok) { console.error('HTTP', res.status, (await res.text()).slice(0, 500)); process.exit(1); }
const data = await res.json();
const urls = [];
for (const ch of ((data.output && data.output.choices) || data.choices || [])) {
  const content = ch && ch.message && ch.message.content;
  for (const part of (Array.isArray(content) ? content : (content ? [content] : []))) if (part && (part.image || part.url || part.image_url)) urls.push(part.image || part.url || part.image_url);
}
if (!urls.length) { console.error('NO_URL', JSON.stringify(data).slice(0, 600)); process.exit(1); }
const dl = await fetch(urls[0]);
if (!dl.ok) { console.error('DL', dl.status); process.exit(1); }
const buf = Buffer.from(await dl.arrayBuffer());
const ext = (dl.headers.get('content-type') || 'image/png').includes('jpeg') ? '.jpg' : '.png';
const file = path.join(OUT, 'roadshow-edit2' + ext);
fs.writeFileSync(file, buf);
const manifestPath = path.join(OUT, 'assets.json');
const m = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
m.assets.edit2 = { file: 'demo/roadshow-edit2' + ext, sha256: sha(buf), bytes: buf.length, model, prompt: PROMPT, generated_at: new Date().toISOString(), source_sha256: sha(fs.readFileSync(src)), request_id: data.request_id || null };
fs.writeFileSync(manifestPath, JSON.stringify(m, null, 2));
console.log('EDIT2_OK', file, sha(buf).slice(0, 12), buf.length, 'MS', Date.now() - t0);
