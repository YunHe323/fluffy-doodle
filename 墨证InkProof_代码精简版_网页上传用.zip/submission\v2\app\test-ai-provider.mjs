// v2/app/test-ai-provider.mjs — T96 模型接入设置 / 手动确认 / provider 接线（本地 mock 代理 + 假上游）
import { spawn } from 'node:child_process';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const TOKEN = 't96-test-token';
const UPSTREAM_PORT = 8161;
const APP_PORT = 8162;
const out = { schema: 'mozheng.app.ai-provider-test.v1', cases: {}, errors: [] };
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mozheng-t96-'));
const configPath = path.join(tmp, 'ai-config.json');
const tokenPath = path.join(tmp, 'ai-token');
const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Z4z8AAAAASUVORK5CYII=';
let fakeMode = 'ok';
const fakeCounts = { chat: 0, image: 0 };
let lastChat = null;
const fake = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => { body += c; });
  req.on('end', () => {
    const send = (code, obj, delay = 0) => setTimeout(() => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); }, delay);
    try { if (req.url && req.url.includes('/chat/completions')) lastChat = JSON.parse(body || '{}'); } catch (e) {}
    if (req.url && req.url.includes('/chat/completions')) {
      fakeCounts.chat += 1;
      if (fakeMode === '401') return send(401, { error: { message: 'bad key' } });
      if (fakeMode === '429') return send(429, { error: { message: 'rate limit' } });
      if (fakeMode === 'timeout') return send(200, { id: 'slow', model: 'fake', choices: [{ message: { content: '{}' } }] }, 1800);
      if (fakeMode === 'badjson') return send(200, { id: 'bad', model: 'kimi-k3.1-pro', choices: [{ message: { content: 'not a json' } }] });
      const payload = {
        global: { summary: '冷灰蓝的低饱和山谷，雾带把远山和近水分成三层。', subject: ['山', '雾'], medium: { kind: 'digital', detail: 'painting' }, palette: ['#7f97a8', '#4f6778', '#e4ebee'], mood: ['安静'] },
        regions: [{ id: 'r-real-1', label: '远山', bbox: [100, 80, 500, 300], importance: 0.8, confidence: 0.7 }],
        observations: [{ id: 'o-real-1', kind: 'observation', text: '雾带是视线停留处。', anchor: { type: 'bbox', value: [100, 80, 500, 300] }, bbox: [100, 80, 500, 300], confidence: 0.7, evidenceRefs: [] }],
        directions: [{ id: 'd-real-1', title: '保留雾带留白', why: '右侧更安静', confidence: 0.7, tags: ['留白'] }],
        candidates: [{ id: 'c-real-1', label: '局部方案 A', why: '保持雾带', imageDataUrl: 'data:image/png;base64,' + PNG, width: 1, height: 1 }],
        confidence: 0.7,
      };
      return send(200, { id: 'chatcmpl-fake', object: 'chat.completion', model: 'kimi-k3.1-pro', choices: [{ index: 0, message: { role: 'assistant', content: JSON.stringify(payload) } }], usage: { prompt_tokens: 120, completion_tokens: 80, total_tokens: 200 } });
    }
    if (req.url && req.url.includes('/images/generations')) {
      fakeCounts.image += 1;
      if (fakeMode === '401') return send(401, { error: { message: 'bad key' } });
      return send(200, { created: 1, model: 'hy-image-v3.0', data: [{ b64_json: PNG }], usage: { images: 1 } });
    }
    send(200, { ok: true });
  });
});
await new Promise((r) => fake.listen(UPSTREAM_PORT, '127.0.0.1', r));
const serve = spawn(process.execPath, [path.join(ROOT, 'v2', 'serve.mjs')], {
  cwd: ROOT,
  env: { ...process.env, PORT: String(APP_PORT), AI_LOCAL_TOKEN: TOKEN, AI_CONFIG_PATH: configPath, AI_TOKEN_PATH: tokenPath, AI_TEST_ALLOW_LOOPBACK_UPSTREAM: '1' },
  stdio: 'ignore',
});
let actualPort = null;
for (let i = 0; i < 80 && !actualPort; i += 1) {
  for (let p = APP_PORT; p <= APP_PORT + 10; p += 1) {
    try { const r = await fetch(`http://127.0.0.1:${p}/health`); if (r.ok) { actualPort = p; break; } } catch (e) { /* ignore */ }
  }
  if (!actualPort) await new Promise((r) => setTimeout(r, 200));
}
if (!actualPort) throw new Error('serve 未启动');
out.cases.server = { port: actualPort, upstream: UPSTREAM_PORT };
let browser = null; let errors = [];
const finish = (code = 0) => { try { fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'test-ai-provider-result.json'), JSON.stringify(out, null, 2), 'utf8'); } catch (e) {} process.exit(code); };
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_300s'; finish(3); }, 300000);
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const context = await browser.newContext({ viewport: { width: 1366, height: 768 }, acceptDownloads: true });
  await context.addInitScript((token) => { window.__AI_LOCAL_TOKEN__ = token; }, TOKEN);
  const page = await context.newPage();
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(`http://127.0.0.1:${actualPort}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(900);
  await page.evaluate(() => window.__V2_APP__.t96.refreshConfig());
  await page.waitForTimeout(500);
  out.cases.defaults = await page.evaluate(() => ({ settings: window.__V2_APP__.t96.getSettings(), state: window.__V2_APP__.t96.getState(), presets: Object.keys(window.__V2_APP__.t96.getPresets()) }));
  // UX-T120：空白画布预检会拦截 runAnalyze；先画一笔让画布非空。
  await page.evaluate(() => {
    const c = window.__V2_APP__.controller;
    c.begin({ x: 300, y: 260, pressure: 0.8, timestamp: performance.now() });
    for (let i = 1; i <= 12; i++) c.append({ x: 300 + i * 20, y: 260 + Math.cos(i / 3) * 40, pressure: 0.7, timestamp: performance.now() + i * 16 });
    c.end();
  });
  await page.waitForTimeout(300);
  // 默认 Mock 调用
  out.cases.mock = await page.evaluate(async () => {
    const app = window.__V2_APP__; const r = await app.runAnalyze({ noRecords: false });
    const meta = app.t96.getLastCall();
    return { ok: !!r, observations: r ? r.observations.length : 0, meta, l6: app.t96.getL6AiCalls().slice(-2), badge: app.t96.providerBadge() };
  });
  // 打开设置并测试连接（无 key → mock ok）
  await page.evaluate(() => document.getElementById('btnMore').click()); await page.waitForTimeout(150); await page.evaluate(() => document.getElementById('btnAbout').click()); await page.waitForTimeout(350);
  out.cases.settingsUi = await page.evaluate(() => ({ section: !!document.getElementById('aiAccessCard'), select: (document.getElementById('aiProviderSelect') || {}).value, keyState: (document.getElementById('aiKeyState') || {}).textContent, allow: !!(document.getElementById('aiAllowReal') || {}).checked, confirm: !!(document.getElementById('aiRequireConfirm') || {}).checked, privacy: !!(document.getElementById('aiPrivacyMode') || {}).checked }));
  await page.click('#btnAiTest'); await page.waitForTimeout(500);
  out.cases.testNoKey = await page.evaluate(() => ({ status: document.getElementById('aiTestStatus').textContent, cls: document.getElementById('aiTestStatus').className }));
  // 保存 Kimi 真实配置（fake upstream）
  await page.selectOption('#aiProviderSelect', 'moonshot');
  await page.fill('#aiBaseUrl', `http://127.0.0.1:${UPSTREAM_PORT}/v1`);
  await page.fill('#aiModel', 'kimi-k3.1-pro');
  await page.fill('#aiKeyInput', 't96-secret-key-123');
  await page.uncheck('#aiPrivacyMode');
  await page.check('#aiAllowReal');
  await page.check('#aiRequireConfirm');
  await page.click('#btnAiSave'); await page.waitForTimeout(800);
  out.cases.save = await page.evaluate(async () => {
    const token = window.__AI_LOCAL_TOKEN__;
    const res = await fetch('/api/ai/config', { headers: { 'x-ai-token': token } });
    const cfg = await res.json();
    return { status: document.getElementById('aiTestStatus').textContent, keyInput: document.getElementById('aiKeyInput').value, keyState: document.getElementById('aiKeyState').textContent, cfg, pageHasSecret: document.documentElement.innerHTML.includes('t96-secret-key-123'), lsHasSecret: JSON.stringify(localStorage).includes('t96-secret-key-123'), settings: window.__V2_APP__.t96.getSettings() };
  });
  await page.click('#btnAiTest'); await page.waitForTimeout(600);
  out.cases.testReal = await page.evaluate(() => ({ status: document.getElementById('aiTestStatus').textContent }));
  // UX-T120：空白画布预检会拦截 runAnalyze；确认框用例前先画一笔让画布非空。
  await page.evaluate(() => {
    const a = window.__V2_APP__; const c = a.controller;
    c.begin({ x: 400, y: 300, pressure: 0.8, timestamp: performance.now() });
    for (let i = 1; i <= 12; i++) c.append({ x: 400 + i * 20, y: 300 + Math.sin(i / 3) * 40, pressure: 0.7, timestamp: performance.now() + i * 16 });
    c.end();
  });
  await page.waitForTimeout(300);
  // 手动确认取消
  const beforeCancelChat = fakeCounts.chat;
  const beforeL6 = await page.evaluate(() => window.__V2_APP__.t96.getL6AiCalls().length);
  await page.evaluate(() => { window.__V2_APP__.closePopovers(); });
  await page.evaluate(() => { window.__V2_APP__.runAnalyze(); });
  await page.waitForTimeout(350);
  out.cases.confirm = await page.evaluate(() => ({ visible: document.getElementById('aiConfirmModal').classList.contains('show'), text: document.getElementById('aiConfirmText').textContent, list: document.querySelector('.ai-confirm-list').textContent }));
  await page.click('#btnAiConfirmCancel'); await page.waitForTimeout(500);
  out.cases.cancel = await page.evaluate((ctx) => ({ chatDelta: 0, l6: window.__V2_APP__.t96.getL6AiCalls().length, modal: document.getElementById('aiConfirmModal').classList.contains('show'), last: window.__V2_APP__.t96.getLastCall(), toast: [...document.querySelectorAll('.toast')].map((x) => x.textContent).join(' ') }), { before: beforeL6 });
  out.cases.cancel.chatDelta = fakeCounts.chat - beforeCancelChat;
  out.cases.cancel.l6Delta = out.cases.cancel.l6 - beforeL6;
  // 确认成功
  const beforeOkChat = fakeCounts.chat;
  await page.evaluate(() => { window.__V2_APP__.runAnalyze(); });
  await page.waitForTimeout(300);
  await page.click('#btnAiConfirmOk'); await page.waitForTimeout(1200);
  out.cases.real = await page.evaluate(() => { const a = window.__V2_APP__; return { analysis: !!a.state.analysis, obs: a.state.analysis ? a.state.analysis.observations.length : 0, meta: a.t96.getLastCall(), badge: a.t96.providerBadge(), l6: a.t96.getL6AiCalls().slice(-1)[0], status: document.getElementById('aiStatus').textContent }; });
  out.cases.real.chatDelta = fakeCounts.chat - beforeOkChat;
  // 方向
  await page.evaluate(() => { window.__V2_APP__.runDirections(); }); await page.waitForTimeout(300);
  if (await page.evaluate(() => window.__V2_APP__.t96.confirmPending())) await page.click('#btnAiConfirmOk');
  await page.waitForTimeout(900);
  out.cases.directions = await page.evaluate(() => ({ dirs: (window.__V2_APP__.state.directions || []).length, meta: window.__V2_APP__.t96.getLastCall(), l6: window.__V2_APP__.t96.getL6AiCalls().slice(-1)[0] }));
  // 切混元生图并生成局部方案
  await page.evaluate(() => document.getElementById('btnMore').click()); await page.waitForTimeout(150); await page.evaluate(() => document.getElementById('btnAbout').click()); await page.waitForTimeout(300);
  await page.selectOption('#aiProviderSelect', 'hunyuan-image');
  await page.fill('#aiBaseUrl', `http://127.0.0.1:${UPSTREAM_PORT}/v1`);
  await page.fill('#aiModel', 'hy-image-v3.0');
  await page.fill('#aiKeyInput', 't96-secret-key-hy');
  await page.check('#aiAllowReal'); await page.uncheck('#aiPrivacyMode');
  await page.click('#btnAiSave'); await page.waitForTimeout(700);
  const beforeImg = fakeCounts.image;
  await page.evaluate(() => { const a = window.__V2_APP__; a.closePopovers(); a.runGenerate(a.state.directions && a.state.directions[0] && a.state.directions[0].id); });
  await page.waitForTimeout(350);
  if (await page.evaluate(() => window.__V2_APP__.t96.confirmPending())) await page.click('#btnAiConfirmOk');
  await page.waitForTimeout(1200);
  out.cases.generate = await page.evaluate(() => { const a = window.__V2_APP__; return { candidates: (a.state.candidates || []).length, meta: a.t96.getLastCall(), badge: a.t96.providerBadge(), l6: a.t96.getL6AiCalls().slice(-1)[0], note: (document.querySelector('.ai-candidate-note') || {}).textContent }; });
  out.cases.generate.imageDelta = fakeCounts.image - beforeImg;
  const beforeLayers = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.evaluate(() => { const b = document.querySelector('[data-cand="0"]'); if (b) b.click(); });
  await page.waitForTimeout(700);
  out.cases.apply = await page.evaluate((before) => { const a = window.__V2_APP__; const gen = [...a.state.records].reverse().find((r) => r.layer === 'L6' && r.kind === 'generation'); return { layers: a.engine.getLayers().length, layerDelta: a.engine.getLayers().length - before, generation: gen }; }, beforeLayers);
  // 错误态：401 / badjson（预期错误：浏览器资源日志与 provider 错误不计入意外 console）
  const expectedBefore = errors.length;
  fakeMode = '401';
  await page.evaluate(() => { const a = window.__V2_APP__; a.closePopovers(); a.runAnalyze(); }); await page.waitForTimeout(300);
  if (await page.evaluate(() => window.__V2_APP__.t96.confirmPending())) await page.click('#btnAiConfirmOk');
  await page.waitForTimeout(900);
  out.cases.error401 = await page.evaluate(() => ({ last: window.__V2_APP__.t96.getLastCall(), l6: window.__V2_APP__.t96.getL6AiCalls().slice(-1)[0], status: document.getElementById('aiTestStatus') ? '' : '' }));
  // 坏 JSON
  fakeMode = 'badjson';
  await page.evaluate(() => { const a = window.__V2_APP__; a.closePopovers(); a.runAnalyze(); }); await page.waitForTimeout(300);
  if (await page.evaluate(() => window.__V2_APP__.t96.confirmPending())) await page.click('#btnAiConfirmOk');
  await page.waitForTimeout(1000);
  out.cases.badjson = await page.evaluate(() => ({ last: window.__V2_APP__.t96.getLastCall(), l6: window.__V2_APP__.t96.getL6AiCalls().slice(-1)[0] }));
  fakeMode = 'ok';
  // 三档设置截图
  const shots = {};
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await page.setViewportSize({ width: w, height: h });
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
    await page.waitForTimeout(600);
    await page.evaluate(() => document.getElementById('btnMore').click()); await page.waitForTimeout(120); await page.evaluate(() => document.getElementById('btnAbout').click()); await page.waitForTimeout(350);
    await page.evaluate(() => document.getElementById('aiAccessCard').scrollIntoView({ block: 'center' }));
    await page.waitForTimeout(200);
    await page.screenshot({ path: path.join(ROOT, 'v2', 'app', 'ui-ai-settings-' + w + '.png') });
    shots[w] = await page.evaluate(() => { const r = document.getElementById('aiAccessCard').getBoundingClientRect(); return { overX: document.documentElement.scrollWidth > innerWidth + 1, overY: document.documentElement.scrollHeight > innerHeight + 1, cardVisible: r.width > 100 && r.height > 50 && r.bottom <= innerHeight + 1 && r.top >= -1, badge: (document.getElementById('aiProviderBadge') || {}).textContent }; });
  }
  out.cases.screenshots = shots;
  out.cases.expectedErrorConsole = errors.slice(expectedBefore, expectedBefore + 10);
  out.errors = errors.slice(0, expectedBefore).slice(0, 10);
  out.pass = {
    defaults: out.cases.defaults.settings.preset !== undefined && out.cases.defaults.settings.privacyMode === true && out.cases.defaults.settings.allowReal === false && out.cases.defaults.presets.includes('moonshot') && out.cases.defaults.presets.includes('hunyuan-image'),
    mock: out.cases.mock.ok && out.cases.mock.meta && out.cases.mock.meta.mock === true && out.cases.mock.badge.includes('Mock'),
    settingsUi: out.cases.settingsUi.section && out.cases.settingsUi.select === 'mock' && out.cases.settingsUi.allow === false && out.cases.settingsUi.confirm === true && out.cases.settingsUi.privacy === true,
    testNoKey: /mock|Mock|成功/.test(out.cases.testNoKey.status),
    // T120 语义：内网/回环上游凭据按安全策略剥离（hasKey=false），以 hasStoredKey 证明 key 确实存了；
    // 公网 HTTPS 上游则 hasKey=true。两种都算「保存成功」；密钥绝不出现在前端页面/localStorage。
    save: /已保存/.test(out.cases.save.status) && out.cases.save.keyInput === '' &&
      (out.cases.save.cfg.hasKey === true || (out.cases.save.cfg.unsafeUpstream && out.cases.save.cfg.hasStoredKey === true)) &&
      !out.cases.save.pageHasSecret && !out.cases.save.lsHasSecret && /已配置/.test(out.cases.save.keyState),
    testReal: /连接成功/.test(out.cases.testReal.status),
    confirm: out.cases.confirm.visible && /base64/.test(out.cases.confirm.text) && /档案摘要/.test(out.cases.confirm.text) && /moonshot|Kimi/.test(out.cases.confirm.text),
    cancel: out.cases.cancel.chatDelta === 0 && out.cases.cancel.l6Delta === 0 && out.cases.cancel.modal === false,
    real: out.cases.real.analysis && out.cases.real.obs > 0 && out.cases.real.meta.mock === false && out.cases.real.meta.provider === 'moonshot' && out.cases.real.chatDelta === 1 && out.cases.real.l6 && out.cases.real.l6.model.provider === 'moonshot' && out.cases.real.badge.includes('Kimi'),
    directions: out.cases.directions.dirs > 0 && out.cases.directions.meta.mock === false,
    generate: out.cases.generate.candidates > 0 && out.cases.generate.imageDelta >= 1 && out.cases.generate.meta.provider === 'hunyuan' && out.cases.generate.meta.mock === false && out.cases.generate.badge.includes('混元'),
    apply: out.cases.apply.layerDelta === 1 && out.cases.apply.generation && out.cases.apply.generation.model.provider === 'hunyuan' && out.cases.apply.generation.cost_cny === 0.2 && out.cases.apply.generation.params.local_patch === true,
    error401: out.cases.error401.last && out.cases.error401.last.status === 'error' && out.cases.error401.l6 && /auth/.test(JSON.stringify(out.cases.error401.l6.params)),
    badjson: out.cases.badjson.last && out.cases.badjson.last.status === 'error' && out.cases.badjson.l6 && /bad_json/.test(JSON.stringify(out.cases.badjson.l6.params)),
    screenshots: Object.values(shots).every((v) => !v.overX && !v.overY && v.cardVisible),
    noConsoleErrors: out.errors.length === 0,
  };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} finally {
  clearTimeout(hard);
  try { await browser.close(); } catch (e) {}
  try { fake.close(); } catch (e) {}
  try { serve.kill(); } catch (e) {}
  finish(0);
}
