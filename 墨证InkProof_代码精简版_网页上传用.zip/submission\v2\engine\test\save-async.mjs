#!/usr/bin/env node
// v2/engine/test/save-async.mjs —— T79 保存 Worker / PSD Worker 测试（零依赖 CDP）
// 用法：node v2/engine/test/save-async.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const checks = {};
  async function makeEngine(width) {
    const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = width;
    const eng = new Engine({ canvas, width, height: width, layers: 2 });
    await eng.init(); eng.setBrush({ type: 'soft', sizePx: 48 });
    for (let s = 0; s < 3; s += 1) {
      const y = 120 + s * 140;
      eng.beginStroke({ x: 120, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
      for (let i = 1; i < 22; i += 1) eng.appendPoint({ x: 120 + i * 30, y: y + Math.sin(i / 5) * 20, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
      eng.endStroke();
    }
    await raf(); await raf();
    return eng;
  }
  const eng = await makeEngine(2048);
  await eng.warmUpSaveAsync();
  await eng.warmUpExportAsync();
  const syncJson = eng.serializeDoc();
  await new Promise((r) => setTimeout(r, 250)); // 让预热任务的尾部长任务结束，避免污染测量窗口
  let syncContainer = JSON.parse(syncJson);
  // F25：组/蒙版/剪贴/alphaLock 文档的异步保存结构对比
  eng.addGroup('G'); const dbgGroup = eng.getGroups()[0];
  eng.addLayer({ name: '组内层', group: dbgGroup.id });
  const dbgLayer = eng.getLayers().find((l) => l.group === dbgGroup.id);
  eng.setActiveLayer(dbgLayer.id);
  eng.addMask(dbgLayer.id);
  eng.setActiveTarget('group-mask'); eng.setActiveGroup(dbgGroup.id);
  eng.addGroupMask(dbgGroup.id); eng.setGroupClip(dbgGroup.id, true);
  eng.setLayerAlphaLock(dbgLayer.id, true);
  const syncStructJson = eng.serializeDoc();
  const syncStructDoc = JSON.parse(syncStructJson).doc;
  const asyncStructJson = await eng.serializeDocAsync({});
  const asyncStructContainer = JSON.parse(asyncStructJson);
  checks.StructureDocSyncVsAsync = JSON.stringify(JSON.parse(syncStructJson).doc) === JSON.stringify(asyncStructContainer.doc);
  checks.StructureTilesSyncVsAsync = JSON.stringify(Object.keys(JSON.parse(syncStructJson).tiles).sort()) === JSON.stringify(Object.keys(asyncStructContainer.tiles).sort());
  checks.StructureMasksSyncVsAsync = JSON.stringify(Object.keys(JSON.parse(syncStructJson).masks || {}).sort()) === JSON.stringify(Object.keys(asyncStructContainer.masks || {}).sort());
  const structBlob = await eng.saveDocAsync({ compress: true });
  const engStruct = await makeEngine(2048);
  await engStruct.deserializeDocAuto(structBlob);
  checks.StructureV2Roundtrip = JSON.stringify(JSON.parse(engStruct.serializeDoc()).doc) === JSON.stringify(syncStructDoc);
  checks.StructureV2Groups = JSON.parse(engStruct.serializeDoc()).doc.groups.length > 0;
  engStruct.dispose();
  // 结构操作后刷新基线，避免后续正常保存对比用到旧 doc
  syncContainer = JSON.parse(eng.serializeDoc());
  // 结构操作会产生新的热路径，重新预热并让尾部长任务结束后再测量保存
  eng._saveWarmed = false;
  await eng.warmUpSaveAsync();
  await new Promise((r) => setTimeout(r, 250));
  // 异步保存（含长任务观测）
  let longTasks = [];
  let observer = null;
  try { observer = new PerformanceObserver((l) => { longTasks = longTasks.concat(l.getEntries().map((e) => e.duration)); }); observer.observe({ entryTypes: ['longtask'] }); } catch (e) { observer = null; }
  const progress = [];
  const tSave = performance.now();
  const asyncJson = await eng.serializeDocAsync({ onProgress: (p) => progress.push(p) });
  const saveMs = Math.round((performance.now() - tSave) * 100) / 100;
  await new Promise((r) => setTimeout(r, 80));
  if (observer) { try { observer.disconnect(); } catch (e) { /* ignore */ } }
  const longTaskMax = longTasks.length ? Math.max(...longTasks) : 0;
  const asyncContainer = JSON.parse(asyncJson);
  checks.saveJsonStructure = JSON.stringify(asyncContainer.doc) === JSON.stringify(syncContainer.doc)
    && JSON.stringify(Object.keys(asyncContainer.tiles).sort()) === JSON.stringify(Object.keys(syncContainer.tiles).sort())
    && JSON.stringify(Object.keys(asyncContainer.tiles).sort().map((k) => Object.keys(asyncContainer.tiles[k]).sort())) ===
       JSON.stringify(Object.keys(syncContainer.tiles).sort().map((k) => Object.keys(syncContainer.tiles[k]).sort()));
  checks.saveProgress = progress.length > 0 && progress.some((p) => p.phase === 'done');
  checks.saveLongTask = longTaskMax < 20 || (longTasks.length <= 1 && longTaskMax < 20);
  const blob = await eng.saveDocAsync({ compress: true });
  checks.saveBlob = !!blob && blob.size > 0 && [0x1f, 0x8b].includes(new Uint8Array(await blob.slice(0, 1).arrayBuffer())[0]);
  // 异步保存 roundtrip（像素一致）
  const eng2 = await makeEngine(2048);
  await eng2.deserializeDocAuto(asyncJson);
  const [inkA, inkB] = [await eng.getCompositeDataUrl(), await eng2.getCompositeDataUrl()];
  const decodeInk = async (url) => { const img = new Image(); img.src = url; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const x = c.getContext('2d'); x.drawImage(img, 0, 0); const d = x.getImageData(0, 0, c.width, c.height).data; let n = 0; for (let i = 0; i < d.length; i += 4) if (d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220) n += 1; return n; };
  checks.saveRoundtrip = Math.abs((await decodeInk(inkA)) - (await decodeInk(inkB))) < 10;
  // 取消保存
  let canceled = false;
  try {
    await eng.serializeDocAsync({ onProgress: (p) => { if (!canceled && p.phase === 'encode' && p.done >= 2) { canceled = true; eng.cancelSave(); } } });
  } catch (e) { checks.saveCancel = e && e.name === 'AbortError' && canceled; }
  const saveAgain = await eng.serializeDocAsync({});
  checks.saveAfterCancel = !!saveAgain && JSON.parse(saveAgain).format === 'mozheng';
  // PSD 异步导出
  let psdLong = [];
  observer = null;
  try { observer = new PerformanceObserver((l) => { psdLong = psdLong.concat(l.getEntries().map((e) => e.duration)); }); observer.observe({ entryTypes: ['longtask'] }); } catch (e) { observer = null; }
  const psdProgress = [];
  const psdBlob = await eng.exportPSDAsync({ onProgress: (p) => psdProgress.push(p) });
  await new Promise((r) => setTimeout(r, 80));
  if (observer) { try { observer.disconnect(); } catch (e) { /* ignore */ } }
  const psdBytes = new Uint8Array(await psdBlob.arrayBuffer());
  const psdLongMax = psdLong.length ? Math.max(...psdLong) : 0;
  checks.psdMagic = psdBytes.length > 26 && psdBytes[0] === 0x38 && psdBytes[1] === 0x42 && psdBytes[2] === 0x50 && psdBytes[3] === 0x53;
  checks.psdProgress = psdProgress.length > 0 && psdProgress.some((p) => p.phase === 'done');
  checks.psdLongTask = psdLongMax < 50;
  // 用 ag-psd 读回验证结构
  try {
    if (!window.agPsd) { await import('/v2/psd/vendor/ag-psd/bundle.js'); }
    const agPsd = window.agPsd;
    const psd = agPsd.readPsd(psdBytes);
    checks.psdReadback = psd.width === 2048 && psd.height === 2048 && psd.children.length >= 2;
  } catch (e) { checks.psdReadback = false; checks.psdReadError = String((e && e.message) || e); }
  // PSD 取消
  let psdCanceled = false;
  try {
    await eng.exportPSDAsync({ onProgress: (p) => { if (!psdCanceled && p.phase === 'render' && p.done >= 1) { psdCanceled = true; eng.cancelPSDExport(); } } });
  } catch (e) { checks.psdCancel = e && e.name === 'AbortError' && psdCanceled; }
  checks.psdAfterCancel = !!(await eng.exportPSDAsync({}));
  // F25：异步保存期间修改 doc，不得进入已保存文件（doc 在 await 前快照）
  const snap = JSON.parse(eng.serializeDoc()).doc;
  const originalName = eng.getLayers()[0].name;
  const pendingSave = eng.serializeDocAsync({});
  await new Promise((r) => setTimeout(r, 30));
  eng.getLayers()[0].name = 'F25-mutated-' + Date.now();
  const savedAfterMutation = JSON.parse(await pendingSave);
  checks.SaveDocSnapshotStable = JSON.stringify(savedAfterMutation.doc) === JSON.stringify(snap);
  eng.getLayers()[0].name = originalName;
  eng.dispose(); eng2.dispose();
  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  return {
    ok: checks.ok, checks,
    data: {
      width: 2048, saveMs, saveLongTaskCount: longTasks.length, saveLongTaskMaxMs: Math.round(longTaskMax * 100) / 100,
      asyncJsonBytes: asyncJson.length, syncJsonBytes: syncJson.length, blobBytes: blob.size,
      psdBytes: psdBytes.length, psdLongTaskCount: psdLong.length, psdLongTaskMaxMs: Math.round(psdLongMax * 100) / 100,
    },
    environment: { headless: /HeadlessChrome/.test(navigator.userAgent) },
  };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 300000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value || !value.checks) { console.error('无返回/异常', JSON.stringify(r).slice(0, 6000)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
