// v2/app/test-mask-eraser.mjs — T85 蒙版橡皮（图层/组蒙版 白显示/黑隐藏）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8121;
const out = { schema: 'mozheng.app.mask-eraser-test.v1', cases: {}, errors: [] };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
let browser = null; let errors = [];
const finish = (code = 0) => { try { fs.writeFileSync(ROOT + '\\v2\\app\\test-mask-eraser-result.json', JSON.stringify(out, null, 2), 'utf8'); } catch (e) {} process.exit(code); };
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_240s'; finish(3); }, 240000);
try {
  await new Promise((r) => setTimeout(r, 800));
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const context = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  const page = await context.newPage();
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  const load = async (w = 1366, h = 768) => {
    await page.setViewportSize({ width: w, height: h });
    await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
    await page.waitForTimeout(500);
  };
  await load();
  const box = await page.locator('#mainCanvas').boundingBox();
  const drag = async (x0, y0, x1, y1) => {
    await page.mouse.move(box.x + box.width * x0, box.y + box.height * y0);
    await page.mouse.down();
    for (let i = 1; i <= 8; i++) await page.mouse.move(box.x + box.width * (x0 + (x1 - x0) * i / 8), box.y + box.height * (y0 + (y1 - y0) * i / 8), { steps: 2 });
    await page.mouse.up();
    await page.waitForTimeout(350);
  };
  // 先画内容
  await page.evaluate(() => { const a = window.__V2_APP__; a.engine.setActiveLayer(a.engine.getLayers()[0].id); a.engine.setLayerLocked(a.engine.getLayers()[0].id, false); a.setTool('brush'); a.engine.setActiveTarget('layer'); });
  await drag(0.28, 0.38, 0.62, 0.55);
  out.cases.content = await page.evaluate(() => ({ url: null, layers: window.__V2_APP__.engine.getLayers().length }));

  // 进入图层蒙版 + 橡皮黑
  out.cases.layerMaskEnter = await page.evaluate(() => {
    const app = window.__V2_APP__; const t = app.t85; const l = app.engine.getLayers()[0];
    app.closePopovers();
    const r = t.enterLayerMask(l.id);
    app.setTool('eraser');
    return { r, tool: app.state.tool, paint: t.getMaskPaint(), hint: document.getElementById('statusHint').textContent, stats: t.maskStats(l.id) };
  });
  await page.evaluate(async () => { window.__maskBefore = await window.__V2_APP__.t85.compositeDataUrl(); });
  await drag(0.3, 0.4, 0.6, 0.52);
  out.cases.layerMaskErase = await page.evaluate(() => {
    const t = window.__V2_APP__.t85; const e = window.__V2_APP__.engine; const l = e.getLayers()[0];
    return { paint: t.getMaskPaint(), target: t.activeTarget(), stats: t.maskStats(l.id), undo: e.getStats().undoDepth };
  });
  out.cases.layerMaskErase.changedPx = await page.evaluate(async () => {
    const decode = async (url) => { const img = new Image(); img.src = url; await img.decode(); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; c.getContext('2d').drawImage(img, 0, 0); return c.getContext('2d').getImageData(0, 0, c.width, c.height).data; };
    const after = await window.__V2_APP__.t85.compositeDataUrl();
    if (after === window.__maskBefore) return 0;
    const a = await decode(window.__maskBefore); const b = await decode(after);
    let n = 0; for (let i = 0; i < a.length; i += 4) if (a[i] !== b[i] || a[i + 1] !== b[i + 1] || a[i + 2] !== b[i + 2] || a[i + 3] !== b[i + 3]) n += 1; return n;
  });
  out.cases.layerMaskErase.changed = out.cases.layerMaskErase.changedPx > 0;
  // undo
  await page.evaluate(() => { const e = window.__V2_APP__.engine; e.undo(); e.presentFull(); });
  await page.waitForTimeout(300);
  out.cases.layerMaskUndo = await page.evaluate(() => { const t = window.__V2_APP__.t85; const l = window.__V2_APP__.engine.getLayers()[0]; return { stats: t.maskStats(l.id), undo: window.__V2_APP__.engine.getStats().undoDepth }; });
  // 画笔白恢复
  await page.evaluate(() => window.__V2_APP__.setTool('brush'));
  await drag(0.31, 0.41, 0.59, 0.51);
  out.cases.layerMaskRestore = await page.evaluate(() => { const t = window.__V2_APP__.t85; const l = window.__V2_APP__.engine.getLayers()[0]; return { paint: t.getMaskPaint(), stats: t.maskStats(l.id) }; });

  // 组蒙版黑色
  out.cases.group = await page.evaluate(() => {
    const app = window.__V2_APP__; const e = app.engine; const t = app.t85;
    app.closePopovers();
    let g = e.getDoc().groups[0];
    if (!g) { g = app.t61.addGroup(); app.t61.assignLayerToGroup(e.getLayers()[0].id, g.id); }
    const r = t.enterGroupMask(g.id);
    app.setTool('eraser');
    return { gid: g.id, r, paint: t.getMaskPaint(), hint: document.getElementById('statusHint').textContent };
  });
  await drag(0.34, 0.42, 0.62, 0.54);
  out.cases.groupMaskErase = await page.evaluate(() => { const app = window.__V2_APP__; const t = app.t85; const g = app.engine.getDoc().groups[0]; return { stats: t.maskStats(g.id), paint: t.getMaskPaint(), target: t.activeTarget(), undo: app.engine.getStats().undoDepth }; });
  await page.evaluate(() => { const e = window.__V2_APP__.engine; e.undo(); e.presentFull(); });
  await page.waitForTimeout(250);
  out.cases.groupMaskUndo = await page.evaluate(() => { const t = window.__V2_APP__.t85; const g = window.__V2_APP__.engine.getDoc().groups[0]; return { stats: t.maskStats(g.id) }; });

  // 再画一笔黑，保存/打开/PSD
  await page.evaluate(() => { const app = window.__V2_APP__; const t = app.t85; const l = app.engine.getLayers()[0]; app.closePopovers(); t.enterLayerMask(l.id); app.setTool('eraser'); });
  await drag(0.32, 0.42, 0.58, 0.52);
  out.cases.saveOpen = await page.evaluate(async () => {
    const app = window.__V2_APP__; const t = app.t61; const th = app.t85; const l = app.engine.getLayers()[0];
    const before = { has: !!(l.mask && l.mask.exists), stats: th.maskStats(l.id) };
    const text = t.saveProjectText();
    await t.loadProjectText(text);
    const afterLayer = app.engine.getLayers()[0];
    const after = { has: !!(afterLayer.mask && afterLayer.mask.exists), stats: th.maskStats(afterLayer.id), masks: app.engine.getDoc().layers.filter((x) => x.mask && x.mask.exists).length };
    return { before, after, bytes: text.length };
  });
  out.cases.psd = await page.evaluate(async () => {
    const t = window.__V2_APP__.t61;
    const exported = await t.psdExportBuffer();
    return { bytes: exported.buffer.byteLength, summary: exported.summary };
  });
  out.cases.final = await page.evaluate(() => { const app = window.__V2_APP__; return { paint: app.t85.getMaskPaint(), target: app.t85.activeTarget(), hint: document.getElementById('statusHint').textContent }; });

  // 三档截图：蒙版编辑状态
  const shots = {};
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await load(w, h);
    await page.evaluate(() => { const app = window.__V2_APP__; const t = app.t85; const e = app.engine; const l = e.getLayers()[0]; e.setActiveLayer(l.id); e.setLayerLocked(l.id, false); t.enterLayerMask(l.id); app.setTool('eraser'); app.openPopover('popLayers'); });
    await page.waitForTimeout(500);
    await page.screenshot({ path: ROOT + '\\v2\\app\\ui-mask-' + w + '.png' });
    shots[w] = await page.evaluate(() => ({ overX: document.documentElement.scrollWidth > innerWidth + 1, overY: document.documentElement.scrollHeight > innerHeight + 1, hint: document.getElementById('statusHint').textContent, paint: window.__V2_APP__.t85.getMaskPaint() }));
  }
  out.cases.screenshots = shots;
  out.errors = errors.slice(0, 10);
  out.pass = {
    layerErase: out.cases.layerMaskEnter.paint === 'black' && out.cases.layerMaskEnter.hint.includes('白=显示') && out.cases.layerMaskErase.stats.darkFraction > 0 && out.cases.layerMaskErase.changed && out.cases.layerMaskErase.changedPx > 20,
    layerUndo: out.cases.layerMaskUndo.stats.darkFraction < out.cases.layerMaskErase.stats.darkFraction,
    layerRestore: out.cases.layerMaskRestore.paint === 'white' && out.cases.layerMaskRestore.stats.darkFraction < out.cases.layerMaskErase.stats.darkFraction,
    groupErase: out.cases.group.paint === 'black' && out.cases.group.hint.includes('组蒙版') && out.cases.groupMaskErase.stats.darkFraction > 0,
    groupUndo: out.cases.groupMaskUndo.stats.darkFraction <= out.cases.groupMaskErase.stats.darkFraction,
    saveOpen: out.cases.saveOpen.before.has && out.cases.saveOpen.after.has && out.cases.saveOpen.after.stats.tiles > 0,
    psd: out.cases.psd.bytes > 100 && out.cases.psd.summary.masks >= 1,
    screenshots: Object.values(shots).every((v) => !v.overX && !v.overY && v.paint === 'black' && v.hint.includes('白=显示')),
  };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} finally {
  clearTimeout(hard);
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  finish(0);
}
