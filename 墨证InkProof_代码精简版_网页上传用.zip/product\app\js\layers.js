// product/app/js/layers.js
// 图层面板：渲染 / 新建 / 删除 / 显隐 / 排序 / 不透明度 / 折叠；所有结构变化进入撤销栈并持久化。
import { state, emit, on, $, uid, nowIso, call } from './state.js';
import { ICON_SVG } from './icons.js';
import {
  activeLayer, findLayer, makeLayer, renderLayerThumb, renderAll, renderCanvas,
  pushHistory, makeActionHistory, markLayerDirty, markProjectDirty, renderOverlay
} from './canvas.js';

let collapsed = false;

export function initLayers() {
  on('layers:changed', renderLayerList);
  on('canvas:changed', () => {
    // 画布内容变化时只刷新缩略图（不重建整表，减少抖动）
    document.querySelectorAll('.layer-row[data-id]').forEach((row) => {
      const layer = findLayer(row.dataset.id);
      const thumb = row.querySelector('canvas.layer-thumb');
      if (layer && thumb) renderLayerThumb(thumb, layer);
    });
    syncControls();
  });
  bindButtons();
  renderLayerList();
}

function bindButtons() {
  $('btnAddLayer').addEventListener('click', addUserLayer);
  $('btnCollapseLayers').addEventListener('click', toggleCollapsed);
  $('btnLayerUp').addEventListener('click', () => moveLayer(1));
  $('btnLayerDown').addEventListener('click', () => moveLayer(-1));
  $('btnLayerDelete').addEventListener('click', deleteActiveLayer);
  const opacity = $('layerOpacity');
  opacity.addEventListener('input', () => setOpacity(true));
  opacity.addEventListener('change', () => setOpacity(false));
}

function toggleCollapsed() {
  collapsed = !collapsed;
  const panel = document.querySelector('.layers-panel');
  if (panel) panel.classList.toggle('collapsed', collapsed);
  $('btnCollapseLayers').textContent = collapsed ? '⌄' : '⌃';
  requestAnimationFrame(() => {
    window.dispatchEvent(new Event('resize'));
    renderOverlay();
  });
}

export function renderLayerList() {
  const list = $('layerList');
  if (!list) return;
  list.innerHTML = '';
  for (const layer of [...state.layers].reverse()) {
    const row = document.createElement('div');
    row.className = 'layer-row' + (layer.id === state.activeLayerId ? ' active' : '');
    row.dataset.id = layer.id;

    const eye = document.createElement('button');
    eye.className = 'eye' + (layer.visible ? '' : ' off');
    eye.title = layer.visible ? '隐藏图层' : '显示图层';
    eye.innerHTML = layer.visible ? ICON_SVG.eye : ICON_SVG['eye-off'];
    eye.addEventListener('click', (e) => { e.stopPropagation(); toggleVisible(layer.id); });

    const thumb = document.createElement('canvas');
    thumb.className = 'layer-thumb';
    thumb.width = 96;
    thumb.height = 64;
    renderLayerThumb(thumb, layer);

    const name = document.createElement('div');
    name.className = 'layer-name';
    name.textContent = layer.name;
    name.title = layer.name;

    const badge = document.createElement('span');
    badge.className = 'badge ' + (layer.kind === 'ai' ? 'ai' : layer.kind === 'base' ? 'base' : 'user');
    badge.textContent = layer.kind === 'ai' ? 'AI' : layer.kind === 'base' ? '底图' : '图层';

    row.append(eye, thumb, name, badge);
    row.addEventListener('click', () => selectLayer(layer.id));
    list.append(row);
  }
  syncControls();
}

function syncControls() {
  const layer = activeLayer();
  const opacity = $('layerOpacity');
  const label = $('layerOpacityVal');
  const has = !!layer;
  opacity.disabled = !has;
  $('btnLayerUp').disabled = !has;
  $('btnLayerDown').disabled = !has;
  $('btnLayerDelete').disabled = !has || state.layers.length <= 1;
  opacity.value = has ? Math.round(layer.opacity * 100) : 100;
  label.textContent = (has ? Math.round(layer.opacity * 100) : 100) + '%';
}

export function selectLayer(id) {
  state.activeLayerId = id;
  const layer = findLayer(id);
  renderLayerList();
  if (layer) {
    emit('log', { type: 'layer_selected', actor: 'user', payload: { layer_id: id, name: layer.name } });
    emit('persist:project');
  }
}

function addUserLayer() {
  const n = state.layers.filter((l) => l.kind === 'user').length + 1;
  const layer = makeLayer(`图层 ${n}`, 'user');
  const index = state.layers.length;
  state.layers.push(layer);
  state.activeLayerId = layer.id;
  pushHistory(makeActionHistory(
    () => { state.layers = state.layers.filter((l) => l.id !== layer.id); renderAll(); emit('layers:changed'); },
    () => { state.layers.splice(Math.min(index, state.layers.length), 0, layer); state.activeLayerId = layer.id; renderAll(); emit('layers:changed'); },
    '新建图层'
  ));
  emit('log', { type: 'layer_added', actor: 'user', payload: { layer_id: layer.id, name: layer.name, kind: 'user' } });
  renderAll();
  emit('layers:changed');
  markLayerDirty(layer.id);
  markProjectDirty();
  clearSelectionHint();
}

export function deleteActiveLayer() {
  const layer = activeLayer();
  if (!layer || state.layers.length <= 1) return;
  const index = state.layers.indexOf(layer);
  state.layers.splice(index, 1);
  state.activeLayerId = state.layers[Math.max(0, index - 1)]?.id || null;
  pushHistory(makeActionHistory(
    () => { state.layers.splice(index, 0, layer); state.activeLayerId = layer.id; renderAll(); emit('layers:changed'); },
    () => { state.layers = state.layers.filter((l) => l.id !== layer.id); renderAll(); emit('layers:changed'); },
    '删除图层'
  ));
  emit('log', { type: 'layer_deleted', actor: 'user', payload: { layer_id: layer.id, name: layer.name, kind: layer.kind } });
  emit('layer:deleted', layer.id);
  if (layer.kind === 'ai') {
    try { call('archive.recordDeleteAiLayer', layer); } catch (e) { console.warn(e); }
  }
  renderAll();
  emit('layers:changed');
  markProjectDirty();
}

function toggleVisible(id) {
  const layer = findLayer(id);
  if (!layer) return;
  const before = layer.visible;
  layer.visible = !layer.visible;
  pushHistory(makeActionHistory(
    () => { const l = findLayer(id); if (l) { l.visible = before; renderAll(); emit('layers:changed'); } },
    () => { const l = findLayer(id); if (l) { l.visible = !before; renderAll(); emit('layers:changed'); } },
    '显隐图层'
  ));
  emit('log', { type: 'layer_visibility', actor: 'user', payload: { layer_id: id, visible: layer.visible } });
  renderAll();
  emit('layers:changed');
  markLayerDirty(id);
  markProjectDirty();
}

function moveLayer(direction) {
  const layer = activeLayer();
  if (!layer) return;
  const i = state.layers.indexOf(layer);
  const j = i + direction;
  if (j < 0 || j >= state.layers.length) return;
  const arr = state.layers;
  [arr[i], arr[j]] = [arr[j], arr[i]];
  pushHistory(makeActionHistory(
    () => { const a = state.layers; const k = a.indexOf(layer); const t = a[k - direction]; a[k] = t; a[k - direction] = layer; renderAll(); emit('layers:changed'); },
    () => { const a = state.layers; const k = a.indexOf(layer); const t = a[k + direction]; a[k] = t; a[k + direction] = layer; renderAll(); emit('layers:changed'); },
    '调整图层顺序'
  ));
  emit('log', { type: 'layer_reordered', actor: 'user', payload: { layer_id: layer.id, direction } });
  renderAll();
  emit('layers:changed');
  markProjectDirty();
}

function setOpacity(live) {
  const layer = activeLayer();
  if (!layer) return;
  const v = Number($('layerOpacity').value) / 100;
  layer.opacity = v;
  $('layerOpacityVal').textContent = Math.round(v * 100) + '%';
  renderCanvas();
  if (!live) {
    emit('log', { type: 'layer_opacity', actor: 'user', payload: { layer_id: layer.id, opacity: v } });
    markLayerDirty(layer.id);
    markProjectDirty();
    emit('layers:changed');
  }
}

function clearSelectionHint() {
  // 新建图层后提示用户开始画
  const el = $('statusHint');
  if (el && state.layers.length) el.textContent = '已新建图层 · 开始画吧（B 硬笔 / N 软笔 / E 橡皮）';
}
