// v2/app/test-library.mjs — T71 素材库 UI + mock AI 串联 + 12 步演示（Playwright/msedge，硬超时）
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8114;
const out = { schema: 'mozheng.app.library-test.v1', cases: {}, errors: [] };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
let browser = null;
const finish = (code = 0) => { try { fs.writeFileSync(ROOT + '\\v2\\app\\test-library-result.json', JSON.stringify(out, null, 2), 'utf8'); } catch (e) {} process.exit(code); };
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_240s'; finish(3); }, 240000);

try {
  await new Promise((r) => setTimeout(r, 800));
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  const load = async () => {
    await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
    await page.waitForTimeout(300);
  };
  await load();
  out.cases.ready = true;

  // 打开素材库 + 示例素材
  await page.evaluate(() => window.__V2_APP__.t71.ensureSampleLibrary());
  await page.evaluate(() => window.__V2_APP__.t71.openLibrarySheet());
  await page.waitForTimeout(900);
  out.cases.open = await page.evaluate(() => ({
    open: window.__V2_APP__.t71.isLibraryOpen(),
    count: window.__V2_APP__.t71.listAssets().length,
    cards: document.querySelectorAll('#libGrid .lib-card').length,
    sheet: (() => { const r = document.getElementById('librarySheet').getBoundingClientRect(); return { w: Math.round(r.width), h: Math.round(r.height), x: Math.round(r.x), y: Math.round(r.y) }; })(),
    thumbs: [...document.querySelectorAll('#libGrid .lib-thumb img')].filter((i) => i.src.startsWith('data:')).length,
    detail: document.getElementById('libDetail').textContent.includes('L0') && document.getElementById('libDetail').textContent.includes('L1') && document.getElementById('libDetail').textContent.includes('L2') && document.getElementById('libDetail').textContent.includes('L4') && document.getElementById('libDetail').textContent.includes('L5'),
  }));
  // P1 打磨检查
  out.cases.p1 = await page.evaluate(() => {
    const sheet = document.getElementById('librarySheet');
    const scrim = document.getElementById('libraryBackdrop');
    const cs = getComputedStyle(scrim);
    let minFont = 99;
    let minEl = '';
    sheet.querySelectorAll('*').forEach((el) => {
      const st = getComputedStyle(el);
      const txt = (el.childElementCount === 0 ? (el.textContent || '') : (el.tagName === 'BUTTON' || el.tagName === 'SELECT' ? (el.textContent || '') : '')).trim();
      if (!txt || el.offsetParent === null || st.visibility === 'hidden') return;
      const fs = parseFloat(st.fontSize) || 99;
      if (fs < minFont) { minFont = fs; minEl = el.className || el.tagName; }
    });
    const d = document.querySelector('#libDetail .lib-detail-body');
    d.scrollTop = d.scrollHeight;
    const secs = d.querySelectorAll('.lib-sec');
    const last = secs[secs.length - 1];
    const actions = document.querySelector('#libDetail .lib-actions');
    const icons = sheet.querySelectorAll('#libGrid .lib-src .lib-src-ico');
    const iconFont = icons.length ? parseFloat(getComputedStyle(icons[0]).fontSize) : 0;
    const pal = [...sheet.querySelectorAll('.lib-palette span')];
    const palTitles = pal.map((x) => x.title);
    const detailText = d.textContent;
    return {
      scrim: cs.backgroundColor, blur: cs.backdropFilter,
      minFont, minEl,
      sourceIcons: icons.length, iconFont,
      palette: palTitles.filter((x) => /^#[0-9a-f]{6}$/i.test(x)).length, palTitles,
      overflowY: getComputedStyle(d).overflowY, scrollable: d.scrollHeight > d.clientHeight,
      lastBottom: last ? Math.round(last.getBoundingClientRect().bottom) : 0,
      actionsTop: actions ? Math.round(actions.getBoundingClientRect().top) : 0,
      detailPadBottom: getComputedStyle(d).paddingBottom,
    };
  });
  // 色板来自真实像素：缩略图采样与 palette 匹配
  out.cases.paletteReal = await page.evaluate(async () => {
    const app = window.__V2_APP__; const a = app.t71.listAssets()[0];
    const thumb = await app.t71.getLibraryApi().getThumbnail(a.id);
    const img = new Image(); img.src = thumb.dataUrl; await img.decode();
    const cv = document.createElement('canvas'); cv.width = img.width; cv.height = img.height;
    cv.getContext('2d').drawImage(img, 0, 0);
    const d = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data;
    const hex2rgb = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
    const pal = (a.palette || []).map(hex2rgb);
    let matched = 0;
    for (let i = 0; i < d.length; i += 4 * 37) {
      for (const c of pal) if (Math.abs(d[i] - c[0]) + Math.abs(d[i + 1] - c[1]) + Math.abs(d[i + 2] - c[2]) < 24) { matched += 1; break; }
    }
    return { matched, palette: (a.palette || []).length };
  });
  // 来源图标的 12px 文案
  out.cases.sourceStates = await page.evaluate(() => {
    const labels = [...document.querySelectorAll('#libGrid .lib-src')].map((x) => x.textContent.trim());
    return { labels: [...new Set(labels)], hasIcon: labels.length > 0 && document.querySelectorAll('#libGrid .lib-src .lib-src-ico').length > 0 };
  });

  // 搜索
  await page.fill('#libSearch', '线稿');
  await page.waitForTimeout(450);
  out.cases.search = await page.evaluate(() => ({ cards: document.querySelectorAll('#libGrid .lib-card').length, state: document.getElementById('libState').hidden }));
  await page.fill('#libSearch', '');
  await page.waitForTimeout(450);
  // 筛选
  await page.click('#libFilters [data-filter="pending"]');
  await page.waitForTimeout(250);
  out.cases.filters = await page.evaluate(() => ({ active: document.querySelector('#libFilters .lib-chip.active')?.dataset.filter, cards: document.querySelectorAll('#libGrid .lib-card').length }));
  await page.click('#libFilters [data-filter="all"]');
  await page.waitForTimeout(250);
  // 选中 + 确认/否决
  out.cases.asset = await page.evaluate(() => { const a = window.__V2_APP__.t71.listAssets()[0]; window.__V2_APP__.t71.selectLibraryAsset(a.id); return { id: a.id, name: a.fileName, l2: a.L2.length, l4: a.L4.length, l5: a.L5.length, confidence: a.L1.confidence }; });
  await page.waitForTimeout(300);
  const l5Before = await page.evaluate(() => window.__V2_APP__.t71.selectedAsset().L5.length);
  await page.evaluate(() => { const a = window.__V2_APP__.t71.selectedAsset(); const obs = a.L4[0]; return window.__V2_APP__.t71.confirmAsset(a.id, { targetId: obs.id, tags: a.tags }); });
  await page.waitForTimeout(500);
  await page.evaluate(() => { const a = window.__V2_APP__.t71.selectedAsset(); const obs = a.L4[1]; return a.L4[1] ? window.__V2_APP__.t71.rejectAsset(a.id, { targetId: obs.id, tags: a.tags }) : null; });
  await page.waitForTimeout(500);
  out.cases.decision = await page.evaluate(() => ({ l5: window.__V2_APP__.t71.selectedAsset().L5.length, prefs: window.__V2_APP__.t71.getPreferences() ? window.__V2_APP__.t71.getPreferences().summary : null }));

  // 导入 + 去重
  out.cases.import = await page.evaluate(async () => {
    const c = document.createElement('canvas'); c.width = 320; c.height = 240; const g = c.getContext('2d'); g.fillStyle = '#c9a87c'; g.fillRect(0, 0, 320, 240); g.fillStyle = '#35667d'; g.beginPath(); g.arc(160, 120, 70, 0, Math.PI * 2); g.fill();
    const dataUrl = c.toDataURL('image/png');
    const r1 = await window.__V2_APP__.t71.importDataUrls([{ name: '测试导入.png', dataUrl, mime: 'image/png' }]);
    const r2 = await window.__V2_APP__.t71.importDataUrls([{ name: '测试导入.png', dataUrl, mime: 'image/png' }]);
    return { imported: r1.imported.length, duplicates: r2.duplicates.length, total: window.__V2_APP__.t71.listAssets().length };
  });
  await page.evaluate(() => window.__V2_APP__.t71.openLibrarySheet());
  await page.waitForTimeout(400);

  // 插入画布 + AI 参考 + 证据 refs
  out.cases.insert = await page.evaluate(async () => {
    const app = window.__V2_APP__; const t = app.t71;
    const a = t.listAssets().find((x) => String(x.fileName || '').includes('雾中山谷')) || t.listAssets()[0]; t.selectLibraryAsset(a.id);
    const layers0 = app.engine.getLayers().length;
    await t.insertAssetLayer(a);
    await new Promise((r) => setTimeout(r, 800));
    return { layers0, layers1: app.engine.getLayers().length, refs: app.state.assetLayerRefs.size, aiRef: !!t.getAIReference(), sheetOpen: t.isLibraryOpen(), layerName: app.engine.getLayers()[app.engine.getLayers().length - 1].name, source: app.state.lastAssetImageSource };
  });
  await page.evaluate(() => window.__V2_APP__.openPopover('popAI'));
  await page.waitForTimeout(200);
  out.cases.aiRef = await page.evaluate(() => ({ bar: !document.getElementById('aiReferenceBar').hidden, text: document.getElementById('aiReferenceBar').textContent }));
  out.cases.p1Chip = await page.evaluate(() => {
    const bar = document.getElementById('aiReferenceBar');
    const rn = bar.querySelector('.rname');
    const btn = bar.querySelector('.ai-ref-remove');
    const st = rn ? getComputedStyle(rn) : null;
    return { bar: !bar.hidden, overflow: st ? st.overflow : null, textOverflow: st ? st.textOverflow : null, maxWidth: st ? st.maxWidth : null, aria: btn ? btn.getAttribute('aria-label') : null, separate: !!(btn && rn && !rn.contains(btn)) };
  });
  out.cases.p1Ref = await page.evaluate(async () => {
    const t = window.__V2_APP__.t71; await t.openLibrarySheet(); await new Promise((r) => setTimeout(r, 500));
    const a = t.listAssets().find((x) => String(x.fileName || '').includes('雾中山谷')) || t.listAssets()[0];
    t.selectLibraryAsset(a.id); await new Promise((r) => setTimeout(r, 200));
    const tag = [...document.querySelectorAll('#libGrid .lib-ref-tag')].map((x) => x.textContent.trim());
    const detail = document.getElementById('libDetail').textContent.includes('本作品引用 1 次') ? '本作品引用 1 次' : null;
    t.closeLibrarySheet();
    return { tags: [...new Set(tag)], detailRef: detail };
  });
  out.cases.analyzeWithRef = await page.evaluate(async () => { const app = window.__V2_APP__; app.state.selection = { x: 400, y: 200, width: 400, height: 300 }; await app.runAnalyze(); return { has: !!app.state.analysis, ref: !!(app.state.analysis && app.state.analysis.libraryRef) }; });
  await page.waitForTimeout(300);
  out.cases.evidenceRefs = await page.evaluate(async () => { const app = window.__V2_APP__; await app.buildEvidence().then((e) => (app.state.evidence = e)); return { refs: app.state.evidence.refs.length, manifest: app.state.evidence.manifest.refs_count, hasAi: app.state.evidence.refs.some((r) => r.usage === 'ai_reference') }; });
  await page.evaluate(() => window.__V2_APP__.t71.clearAIReference());
  await page.waitForTimeout(200);

  // 刷新持久化
  await page.reload();
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.evaluate(() => window.__V2_APP__.t71.openLibrarySheet());
  await page.waitForTimeout(800);
  out.cases.persist = await page.evaluate(() => ({ count: window.__V2_APP__.t71.listAssets().length, cards: document.querySelectorAll('#libGrid .lib-card').length }));

  // 12 步演示
  out.cases.demo = await page.evaluate(async () => {
    const app = window.__V2_APP__;
    app.startDemo(true);
    app.state.demo.paused = true;
    clearTimeout(app.state.demo.timer);
    for (let i = 0; i < 11; i += 1) {
      document.getElementById('btnDemoNext').click();
      await new Promise((r) => setTimeout(r, 650));
    }
    const step = app.state.demo.step;
    const total = app.t71.getDemoStepCount();
    document.getElementById('btnDemoNext').click();
    await new Promise((r) => setTimeout(r, 700));
    const evidenceOpen = document.getElementById('evidenceModal').classList.contains('show');
    return { total, step, evidenceOpen, sheetOpen: app.t71.isLibraryOpen(), hasAnalysis: !!app.state.analysis };
  });
  await page.evaluate(() => window.__V2_APP__.exitDemo().catch(() => {}));
  await page.waitForTimeout(500);

  // 三档截图（素材库打开 + 选中素材）
  const shots = {};
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await page.setViewportSize({ width: w, height: h });
    await load();
    await page.evaluate(() => window.__V2_APP__.t71.ensureSampleLibrary());
    await page.evaluate(async () => { const t = window.__V2_APP__.t71; for (const a of t.listAssets()) if (!String(a.fileName || '').includes('示例')) await t.deleteLibraryAsset(a); });
    await page.evaluate(() => window.__V2_APP__.t71.openLibrarySheet());
    await page.evaluate(() => { const t = window.__V2_APP__.t71; const a = t.listAssets().find((x) => String(x.fileName || '').includes('雾中山谷')); if (a) t.selectLibraryAsset(a.id); });
    await page.waitForTimeout(3000);
    await page.screenshot({ path: ROOT + '\\v2\\app\\ui-library-' + w + '.png' });
    shots[w] = await page.evaluate(() => {
      const r = document.getElementById('librarySheet').getBoundingClientRect();
      return { overX: document.documentElement.scrollWidth > innerWidth + 1, overY: document.documentElement.scrollHeight > innerHeight + 1, sheet: { w: Math.round(r.width), h: Math.round(r.height), x: Math.round(r.x), y: Math.round(r.y) } };
    });
  }
  out.cases.screenshots = shots;
  out.errors = errors.slice(0, 12);
  out.pass = {
    scrim: (() => { const m = String(out.cases.p1.scrim).match(/rgba\(([^)]+)\)/); if (!m || !out.cases.p1.blur.includes('blur(2px)')) return false; const a = Number(String(m[1]).split(',')[3]); return Number.isFinite(a) && a >= 0.55 && a <= 0.75; })(),
    sheetFont12: out.cases.p1.minFont >= 11.5,
    detailNotCovered: out.cases.p1.lastBottom <= out.cases.p1.actionsTop + 1 && out.cases.p1.overflowY === 'auto' && out.cases.p1.scrollable,
    sourceIcons: out.cases.p1.sourceIcons >= 2 && out.cases.p1.iconFont >= 11.5 && out.cases.sourceStates.hasIcon,
    palette: out.cases.p1.palette >= 3 && out.cases.paletteReal.matched >= 2,
    p1Chip: out.cases.p1Chip.bar && out.cases.p1Chip.overflow === 'hidden' && out.cases.p1Chip.textOverflow === 'ellipsis' && out.cases.p1Chip.aria === '移除素材参考' && out.cases.p1Chip.separate,
    p1Ref: out.cases.p1Ref.tags.every((x) => /^被本作品引用 1 次$/.test(x)) && (out.cases.p1Ref.detailRef === '本作品引用 1 次'),
    open: out.cases.open.open && out.cases.open.count >= 3 && out.cases.open.cards >= 3 && out.cases.open.thumbs >= 3 && out.cases.open.detail && out.cases.open.sheet.w >= 1100,
    search: out.cases.search.cards === 1,
    filters: out.cases.filters.active === 'pending',
    decision: out.cases.decision.l5 > l5Before && !!out.cases.decision.prefs,
    import: out.cases.import.imported === 1 && out.cases.import.duplicates === 1,
    insert: out.cases.insert.layers1 === out.cases.insert.layers0 + 1 && out.cases.insert.refs === 1 && out.cases.insert.aiRef && !out.cases.insert.sheetOpen && String(out.cases.insert.source || '').startsWith('original'),
    aiRef: out.cases.aiRef.bar && out.cases.analyzeWithRef.has && out.cases.analyzeWithRef.ref,
    evidenceRefs: out.cases.evidenceRefs.refs > 0 && out.cases.evidenceRefs.hasAi,
    persist: out.cases.persist.count >= 4 && out.cases.persist.cards >= 4,
    demo: out.cases.demo.total === 12 && out.cases.demo.step === 11 && out.cases.demo.evidenceOpen,
    screenshots: Object.values(shots).every((v) => !v.overX && !v.overY),
  };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  out.errors = errors ? errors.slice(0, 12) : [];
  console.log(JSON.stringify(out, null, 2));
} finally {
  clearTimeout(hard);
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  const allPass = !out.fatal && !(out.errors || []).length && Object.values(out.pass || {}).every(Boolean);
  finish(allPass ? 0 : 1);
}
