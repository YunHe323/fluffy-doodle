# T106 最终独立 QA：视图 / 光标 / 文字二次编辑 / 素材批量（T106-F）

> 执行：qa-engineer（独立 QA｜task-113）｜日期：2026-11-07 17:2x｜只写 `v2/qa/tools/`；**未改 app**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、单浏览器串行、小批次（每批 1–3 个，日志落盘 `archive/baseline-t106-final/logs/`）；执行期内存约 2GB。

## 结论

**可交付（Deliverable）——P0/P1/P2 = 0。**
3 个新功能测试 + 5 个模块单测 + 14 项回归全过；6 项重点独立核验（batch 不联网/不写假真实记录、文字编辑 undo 恢复、guides 纯视图层、密钥、残留）全部 PASS；真实证据一致且**未新增付费调用**。

## 1. 新功能测试（全部 PASS）

| 测试 | 结果 | 关键证据 |
|---|---|---|
| `test-text-edit.mjs` | **PASS** | 创建文字层 3 层；双击预填「初始文字」/字号 56；编辑后图层数不变（3）、`text_edited` 记录=1；笔刷光标 alpha=432；0 error |
| `test-guides.mjs` | **PASS** | 网格 alpha=31,340 + 标签「开」；三分线 alpha=35,928；对称轴 alpha=32,685 + 标签「左右」；0 error |
| `test-asset-batch.mjs` | **PASS** | Mock 队列 3/3 成功、0 失败；L6 `mode=mock/total=3/done=3/failed=0/skill=asset.decompose`；0 error |

## 2. 模块单测（Node-only，全部 PASS）

| 单测 | 结果 |
|---|---|
| `asset-batch-test.mjs` | **11/11 passed，0 failed** |
| `guides-test.mjs` | **124 项断言全部通过** |
| `asset-ai-test.mjs` | **10/10 passed** |
| `editor-ops-test.mjs` | **77 项断言全部通过** |
| `skill-runtime-test.mjs` | **PASS**（断言已随集成更新为 5 skills：asset.decompose / canvas.observe / canvas.directions / image.edit / image.generate） |

## 3. 重点独立核验（QA 自建探针，6/6 PASS）

| 检查 | 结果 |
|---|---|
| **batch Mock 不联网** | 点击「AI 批量重读」全程 `/api/ai/*` 请求 **0 次**（Mock 本地路径，不花钱） |
| **batch 不写假真实记录** | `asset_batch_decompose` 记录 `mode=mock`、无 `mode=real`/`mock:false` 记录；素材 `analysisSource=real` 数量 **0** |
| **文字编辑后撤销恢复原图** | 编辑前后像素 diff=14,649；**undo 后与编辑前 diff=0**；图层数不变；`text_edited` 记录=1 |
| **guides 纯视图层（不进导出）** | 开启网格/三分线/对称轴前后：导出 PNG diff=**0**、合成图 diff=**0** |
| **guides 不进 undo / 文档 / 证据** | undoDepth 1→1 不变；`saveProjectText()` 无 guide 字段；`buildEvidence()` JSON 无 guideCanvas/showGrid/showThirds/symmetryAxis；`#guideCanvas` 为 absolute、`pointer-events:none`、z-index:4、父节点 `canvasWrap` |
| **密钥安全** | DOM / localStorage / sessionStorage / 已加载 JS / 静态源码均无 key；config GET 仅 hasKey/keyLast4 |

## 4. 回归（14 项全 PASS，0 console error）

test-app、test-ui、test-library（pass=true）、test-image-workshop、test-multimodal、test-chat、test-canvas-size、test-text、test-editor-basics、test-mask-compare、test-editor-ui、test-ux-p0、test-ai-provider、test-interaction-sequences（**9/9**）——逐项小批次复跑，均 exit 0、0 console error。

## 5. 真实证据核对（未新增付费调用）

| 证据 | 核对 |
|---|---|
| `asset-real-read-results.json`（17:12 最新） | pass=true；**22,955ms**；source=**real**、model=qwen3.8-max、latency=22,225ms、skill=`asset.decompose`、**L2=5 / L4=4** ✅ 与 Lead 口径一致 |
| `qwen-real-e2e-results.json` | pass=true；**21,337ms**；observations=2、regions=2、provider=qwen、**mock=false**、evidence 12/12、real_calls=1 ✅ |
| 新增付费调用 | **0**（仅核对已有证据；未再跑真实批量/生图/编辑） |

## 6. 密钥 / 残留 / 稳定性

- 密钥：无 DOM/localStorage/sessionStorage/已加载 JS/静态源码泄漏；config 脱敏；token 注入正常。全程未打印 key。
- 残留：**Edge 测试进程 0、测试端口 0**；每批后清理。
- 稳定性：全部小批次单浏览器串行（每批 1–3 个），无 OOM/超时 flake。

## 7. 建议（后续新增断言，非阻塞）

1. **保持**：text-edit 增加「undo 后像素 diff=0」断言（当前 QA 已独立验证，建议纳入 owner 测试防回归）。
2. **保持**：guides 增加「导出/undo/证据隔离」断言（本次 QA 独立验证：exportDiff=0、undoDepth 不变、doc/evidence 无 guide 字段）。
3. asset-batch 增加「Mock 路径无 `/api/ai/*` 网络请求」断言（可用 request 监听）。
4. skill-runtime 断言已修为 5 skills，建议后续按 `BUILTIN_SKILLS.length` 动态断言，避免再次过期。

## 8. 产物与归档

- `v2/qa/tools/T106-final-qa.md`（本报告）
- `v2/qa/tools/archive/baseline-t106-final/`：`logs/`（全部原始输出）、各 result JSON、`focus-results.json`（6 项独立核验）、`qwen-real-e2e-results.json`、`asset-real-read-results.json`、README
- GATE：`v2/qa/tools/GATE-pw.md`「T106-F 最终独立 QA」行
