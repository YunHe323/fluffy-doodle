/**
 * v2 engine · IEngine 实现（M4.1 骨架）
 *
 * 编排：loader → tile-store / compositor / stroke / undo → demo / benchmark
 * 设计约束：上层（刷子/图层/选区）只依赖本文件接口，不直接使用 CanvasKit。
 */
import { loadCanvasKit } from './loader.js';
import { TileStore, TILE } from './tile-store.js';
import { Compositor } from './compositor.js';
import { Stroke } from './stroke.js';
import { createDefaultBrushProvider } from './brush-provider.js';
import { UndoManager } from './undo.js';
import {
  BLEND_MODES, blendLabel, createDoc, createLayer, createGroup, normalizeDoc,
  validateDoc, cloneDoc, docStats,
} from './v2doc.js';

const b64encode = (bytes) => {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  return btoa(binary);
};
const b64decode = (str) => {
  const binary = atob(str);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
};

// T77：gzip 容器工具（浏览器原生 CompressionStream；零依赖）
const GZIP_MAGIC = [0x1f, 0x8b];
async function gzipBytes(bytes) {
  if (typeof CompressionStream === 'undefined') throw new Error('浏览器不支持 CompressionStream');
  const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('gzip'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}
async function gunzipBytes(bytes) {
  if (typeof DecompressionStream === 'undefined') throw new Error('浏览器不支持 DecompressionStream');
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}
async function toBytes(input) {
  if (input == null) return null;
  if (input instanceof Uint8Array) return input;
  if (input instanceof ArrayBuffer) return new Uint8Array(input);
  if (typeof Blob !== 'undefined' && input instanceof Blob) return new Uint8Array(await input.arrayBuffer());
  if (typeof input === 'string') return new TextEncoder().encode(input);
  throw new Error('不支持的项目文件类型');
}
const isGzipBytes = (bytes) => !!bytes && bytes.length >= 2 && bytes[0] === GZIP_MAGIC[0] && bytes[1] === GZIP_MAGIC[1];

const raf = () => new Promise((resolve) => requestAnimationFrame(resolve));

/**
 * @param {{canvas:HTMLCanvasElement, width?:number, height?:number, layers?:number,
 *          loaderBase?:string, brush?:{type:string,sizePx:number}}} opts
 */
export class Engine {
  constructor(opts) {
    this.opts = opts;
    this.width = opts.width || 2048;
    this.height = opts.height || 2048;
    this.tileSize = TILE;
    this.brush = opts.brush || { type: 'soft', sizePx: 64 };
    /** @type {any} T41 笔刷注入点（默认 hard/soft） */
    this.brushProvider = opts.brushProvider || createDefaultBrushProvider();
    /** @type {Array<{id:string,name:string,visible:boolean,opacity:number,blend:string}>} */
    this.layers = [];
    this.activeLayerId = null;
    this.currentStroke = null;
    this.flushScheduled = false;
    this._ready = false;
    this.lastCompositeMs = 0;
    // T49：Klecks 式输入平滑（MIT 移植；默认 0 = 关闭，行为与 T41 一致）
    this.inputSmoothing = Math.max(0, Math.min(1, Number(opts.inputSmoothing != null ? opts.inputSmoothing : opts.smoothing) || 0));
    // T49：保留全帧合成纹理（Klecks GpuCompositeCanvas.present / FBO blit 思路）
    // 自适应：显式 opts.presentRetained 优先；否则 ≤2048² 默认开启（正确性优先），≥4096² 自动关闭（内存预算）
    this.presentRetained = opts.presentRetained != null
      ? !!opts.presentRetained
      : this.width * this.height <= 2048 * 2048;
    this.presentSurface = null;
    this.presentCanvas = null;
    this.lastPresentMode = 'none';
    this.presentStrategy = 'full';
    this.lastRedrawArea = 0;
    this.lastRedrawPct = 1;
    this.lastBlitMs = 0;
    // T63：选区约束 / 变换（预览非破坏，提交 1 步 undo）
    this.selectionImage = null;
    this._transform = null;
    this._detachedImages = [];
    // T89：历史图片回收统计
    this._historyImagesReleased = 0; // 结构/变换 detach 的旧 image，供 releaseHistorySnapshots() 释放
    // T76：异步导出 Worker（懒创建；不影响同步 getCompositeDataUrl）
    this._exportWorker = null;
    this._exportJob = null;
    this._exportWarmed = false;
    this._saveWarmed = false;
  }

  async init() {
    const CK = await loadCanvasKit(this.opts.loaderBase || './vendor/');
    this.CK = CK;
    const canvas = this.opts.canvas;
    canvas.width = this.width;
    canvas.height = this.height;
    const glHandle = CK.GetWebGLContext(canvas, { majorVersion: 2, antialias: 0 });
    if (!glHandle) throw new Error('GetWebGLContext 失败（需要 WebGL2）');
    const gr = CK.MakeWebGLContext(glHandle);
    if (!gr) throw new Error('MakeWebGLContext 失败');
    this.gr = gr;
    this.glHandle = glHandle;
    this.store = new TileStore(CK, gr, this.width, this.height);
    this.maskStore = new TileStore(CK, gr, this.width, this.height);
    this.compositor = new Compositor(CK, gr, canvas, this.width, this.height);
    this.undoManager = new UndoManager(this.store);
    this._setupHistoryReclaim();
    if (!this.brushProvider) this.brushProvider = createDefaultBrushProvider();
    // T44：离屏 live layer（当前笔触的确定性别帧重绘来源；不依赖 on-screen framebuffer 跨帧保留）
    this.liveSurface = CK.MakeRenderTarget(gr, this.width, this.height);
    if (!this.liveSurface) throw new Error('live surface 创建失败');
    this.liveCanvas = this.liveSurface.getCanvas();
    this.liveCanvas.clear(CK.TRANSPARENT);
    this._liveEraserPaint = new CK.Paint();
    this._liveEraserPaint.setAntiAlias(true);
    this._liveEraserPaint.setStyle(CK.PaintStyle.Fill);
    this._liveEraserPaint.setColor(CK.Color(255, 255, 255, 1));
    // T49：保留全帧纹理（present = 全帧 blit；脏区只更新保留帧，再整帧上屏）
    if (this.presentRetained) {
      this.presentSurface = CK.MakeRenderTarget(gr, this.width, this.height);
      if (!this.presentSurface) throw new Error('present surface 创建失败');
      this.presentCanvas = this.presentSurface.getCanvas();
      this.presentCanvas.clear(CK.WHITE);
    }

    const n = Math.max(1, this.opts.layers == null ? 2 : this.opts.layers);
    const initialLayers = [];
    for (let i = 0; i < n; i += 1) initialLayers.push(createLayer({ id: `layer-${i + 1}`, name: `图层 ${i + 1}` }));
    this.doc = createDoc({ width: this.width, height: this.height, layers: initialLayers, groups: [], activeLayerId: initialLayers[n - 1].id });
    this.layers = this.doc.layers;
    this.groups = this.doc.groups;
    this.activeLayerId = this.doc.activeLayerId;
    this.activeTarget = 'layer';
    this.activeGroupId = null;
    this.currentMaskStroke = null;
    this._liveMaskPaint = this._liveEraserPaint || null;
    // T84：蒙版笔触白/黑（white=显示/恢复，black=隐藏/橡皮）
    this.maskPaint = 'white';
    this._maskBlackPaint = new CK.Paint();
    this._maskBlackPaint.setAntiAlias(true);
    this._maskBlackPaint.setStyle(CK.PaintStyle.Fill);
    this._maskBlackPaint.setColor(CK.Color(255, 255, 255, 1));
    this._maskBlackPaint.setBlendMode(CK.BlendMode.DstOut);
    this.compositor.setLayers(this.layers);
    this._ready = true;
    this.presentFull();
    return this;
  }

  get ready() { return this._ready; }

  // ---------- 图层 / 组 / 蒙版（T60：V2Doc） ----------
  addGroup(name = '组') {
    return this._withStructureUndo(() => {
      const group = createGroup({ name });
      this.groups.push(group);
      return group;
    });
  }

  setActiveGroup(id) {
    if (this.groups.some((g) => g.id === id)) this.activeGroupId = id;
    return this.activeGroupId;
  }

  getActiveGroup() { return this.activeGroupId; }

  addGroupMask(groupId) {
    return this._withStructureUndo(() => {
      const group = this.groups.find((g) => g.id === groupId);
      if (!group) return null;
      group.mask = { exists: true, enabled: true };
      this.maskStore.ensureLayer(groupId);
      return group.mask;
    });
  }

  removeGroupMask(groupId) {
    return this._withStructureUndo(() => {
      const group = this.groups.find((g) => g.id === groupId);
      if (!group) return false;
      this._detachStoreLayer(this.maskStore, groupId);
      group.mask = { exists: false, enabled: true };
      return true;
    });
  }

  setGroupMaskEnabled(groupId, enabled) {
    return this._withStructureUndo(() => {
      const group = this.groups.find((g) => g.id === groupId);
      if (!group || !group.mask || !group.mask.exists) return false;
      group.mask.enabled = !!enabled;
      return true;
    });
  }

  setGroupClip(groupId, clip) {
    return this._withStructureUndo(() => {
      const group = this.groups.find((g) => g.id === groupId);
      if (!group) return false;
      group.clip = !!clip;
      return true;
    });
  }

  /** 应用组蒙版：把组蒙版烘焙到成员图层像素（最小实现，混合模式为近似） */
  applyGroupMask(groupId) {
    return this._withStructureUndo(() => {
      const group = this.groups.find((g) => g.id === groupId);
      if (!group || !group.mask || !group.mask.exists) return false;
      const members = this.layers.filter((l) => l.group === groupId);
      for (const layer of members) {
        for (const key of this.store.listTiles(layer.id)) {
          const tile = this.store.get(layer.id, key);
          if (!tile) continue;
          const [tx, ty] = key.split(',').map(Number);
          const surface = this.CK.MakeRenderTarget(this.gr, TILE, TILE);
          const c = surface.getCanvas();
          c.clear(this.CK.TRANSPARENT);
          c.drawImage(tile.image, 0, 0);
          const mp = new this.CK.Paint();
          mp.setBlendMode(this.CK.BlendMode.DstIn);
          for (const mk of this.maskStore.listTiles(groupId)) {
            const mTile = this.maskStore.get(groupId, mk);
            if (!mTile) continue;
            const [mx, my] = mk.split(',').map(Number);
            // 仅当 mask tile 与本 tile 重叠时绘制（坐标转换到本 tile）
            const dx = mx * TILE - tx * TILE, dy = my * TILE - ty * TILE;
            c.drawImage(mTile.image, dx, dy, mp);
          }
          mp.delete();
          surface.flush();
          tile.image = surface.makeImageSnapshot();
          surface.delete();
        }
      }
      group.mask = { exists: false, enabled: true };
      return true;
    });
  }

  addLayer(opts = {}) {
    return this._withStructureUndo(() => {
      const id = opts.id || `layer-${this.layers.length + 1}-${Date.now().toString(36)}`;
      const layer = createLayer({ ...opts, id });
      this.layers.push(layer);
      this.activeLayerId = layer.id;
      if (this.doc) this.doc.activeLayerId = layer.id; // P2-1：保存/加载后能恢复活动层
      this.compositor.setLayers(this.layers);
      return layer;
    });
  }

  setActiveLayer(id) {
    if (this.layers.some((l) => l.id === id)) {
      this.activeLayerId = id;
      if (this.doc) this.doc.activeLayerId = id; // P2-1
    }
  }

  setActiveTarget(target) {
    this.activeTarget = target === 'mask' ? 'mask' : target === 'group-mask' ? 'group-mask' : 'layer';
  }
  getActiveTarget() { return this.activeTarget; }

  /** T84：蒙版笔触模式（white=显示/恢复，black=隐藏/橡皮）；普通笔触不受影响 */
  setMaskStrokePaint(mode) {
    this.maskPaint = mode === 'black' ? 'black' : 'white';
    return this.maskPaint;
  }
  getMaskStrokePaint() { return this.maskPaint; }

  setLayerVisible(id, visible) {
    const layer = this.layers.find((l) => l.id === id);
    if (!layer) return;
    layer.visible = !!visible;
    this.presentFull();
  }

  setLayerOpacity(id, opacity) {
    const layer = this.layers.find((l) => l.id === id);
    if (!layer) return;
    layer.opacity = Math.max(0, Math.min(1, Number(opacity)));
    this.presentFull();
  }

  setLayerMeta(id, meta) {
    const layer = this.layers.find((l) => l.id === id);
    if (!layer) return false;
    layer.meta = meta && typeof meta === 'object' ? JSON.parse(JSON.stringify(meta)) : null;
    return true;
  }

  getLayerMeta(id) {
    const layer = this.layers.find((l) => l.id === id);
    return layer && layer.meta ? JSON.parse(JSON.stringify(layer.meta)) : null;
  }

  /** 更新图层类型/调整参数/文字结构（不产生像素 undo；由调用方保证与像素操作配对） */
  setLayerInfo(id, info = {}) {
    const layer = this.layers.find((l) => l.id === id);
    if (!layer) return false;
    if (info.kind != null && ['raster', 'adjust', 'text'].includes(info.kind)) layer.kind = info.kind;
    if (info.adjust !== undefined) layer.adjust = info.adjust && typeof info.adjust === 'object' ? JSON.parse(JSON.stringify(info.adjust)) : null;
    if (info.text !== undefined) layer.text = info.text && typeof info.text === 'object' ? JSON.parse(JSON.stringify(info.text)) : null;
    return true;
  }

  getLayerInfo(id) {
    const layer = this.layers.find((l) => l.id === id);
    if (!layer) return null;
    return { kind: layer.kind || 'raster', adjust: layer.adjust ? JSON.parse(JSON.stringify(layer.adjust)) : null, text: layer.text ? JSON.parse(JSON.stringify(layer.text)) : null };
  }

  setLayerBlend(id, blend) {
    const layer = this.layers.find((l) => l.id === id);
    if (!layer) return false;
    layer.blend = blendLabel(blend);
    this.presentFull();
    return true;
  }

  setLayerClip(id, clip) {
    const layer = this.layers.find((l) => l.id === id);
    if (!layer) return;
    layer.clip = !!clip;
    this.presentFull();
  }

  setLayerLocked(id, locked) {
    const layer = this.layers.find((l) => l.id === id);
    if (layer) layer.locked = !!locked;
  }

  /** T65：Alpha Lock —— 笔刷/擦除只作用于已有不透明像素 alpha 内 */
  setLayerAlphaLock(id, alphaLock) {
    const layer = this.layers.find((l) => l.id === id);
    if (layer) layer.alphaLock = !!alphaLock;
    return !!alphaLock;
  }

  addMask(id) {
    const layer = this.layers.find((l) => l.id === id);
    if (!layer) return null;
    layer.mask = { exists: true, enabled: true };
    this.maskStore.ensureLayer(id);
    this.presentFull();
    return layer.mask;
  }

  /** 未显式传 bbox 时，用 128×128 降采样估算非透明区域，供 tile 级裁剪写入。
   *  返回 [x,y,w,h]（已向外扩 1 个 tile 覆盖降采样误差）；全透明返回 [0,0,0,0]。
   *  只做一次小图解码，不读 4096² 全幅像素。失败时返回 null，退回全画布写入。 */
  async _inferMaskBBox(dataUrl, T) {
    try {
      let bmp = null;
      if (typeof createImageBitmap === 'function') {
        const blob = await (await fetch(String(dataUrl))).blob();
        bmp = await createImageBitmap(blob);
      } else if (typeof document !== 'undefined') {
        const im = new Image(); im.src = String(dataUrl); await im.decode(); bmp = im;
      }
      if (!bmp) return null;
      const N = 128;
      let cv = null, g = null;
      if (typeof OffscreenCanvas !== 'undefined') { cv = new OffscreenCanvas(N, N); g = cv.getContext('2d', { willReadFrequently: true }); }
      else if (typeof document !== 'undefined') { cv = document.createElement('canvas'); cv.width = N; cv.height = N; g = cv.getContext('2d', { willReadFrequently: true }); }
      if (!g) { if (bmp.close) bmp.close(); return null; }
      g.clearRect(0, 0, N, N);
      g.drawImage(bmp, 0, 0, N, N);
      const d = g.getImageData(0, 0, N, N).data;
      let x0 = N, y0 = N, x1 = -1, y1 = -1;
      for (let y = 0; y < N; y += 1) {
        for (let x = 0; x < N; x += 1) {
          if (d[(y * N + x) * 4 + 3] > 8) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
        }
      }
      if (bmp.close) bmp.close();
      if (x1 < x0) return [0, 0, 0, 0];
      const sx = this.width / N, sy = this.height / N;
      const ax = Math.max(0, Math.floor(x0 * sx) - T), ay = Math.max(0, Math.floor(y0 * sy) - T);
      const bx2 = Math.min(this.width, Math.ceil((x1 + 1) * sx) + T), by2 = Math.min(this.height, Math.ceil((y1 + 1) * sy) + T);
      return [ax, ay, Math.max(1, bx2 - ax), Math.max(1, by2 - ay)];
    } catch (e) { return null; }
  }

  /** 用全画布 dataURL 写入图层蒙版（透明=隐藏，白/不透明=显示）
   *  T117 P1-5：支持 opts.bbox（[x,y,w,h] 或 {x,y,width,height}）限定有效区域。
   *  旧版对 4096² 的每个 tile（256 个）都 drawImage 整幅 4096² 图并逐 tile flush/snapshot，
   *  实测 9.4–11s / 页面冻结 14.2s。现在：bbox 外的 tile 只分配空白、跳过绘制；
   *  bbox 内改用 drawImageRect 只取该 tile 对应的源矩形，避免整幅大图变换。
   *  语义不变：所有 tile 仍然存在且非 bbox 区域保持全透明。 */
  async setMaskFromDataUrl(id, dataUrl, opts = {}) {
    const layer = this.layers.find((l) => l.id === id);
    if (!layer) return false;
    const b64 = String(dataUrl || '').split(',')[1];
    if (!b64) throw new Error('setMaskFromDataUrl: 非法 dataURL');
    const bytes = Uint8Array.from(atob(b64), (ch) => ch.charCodeAt(0));
    const img = this.CK.MakeImageFromEncoded(bytes);
    if (!img) throw new Error('setMaskFromDataUrl: 图片解码失败');
    try {
      this._dropStoreLayer(this.maskStore, id);
      this.maskStore.ensureLayer(id);
      const store = this.maskStore;
      const T = store.tileSize;
      let bx = null;
      // 优先用调用方给的精确选区；否则自动降采样推断（QA 直接调用 setMaskFromDataUrl 也能受益）。
      const rawBox = (opts && opts.bbox) || await this._inferMaskBBox(String(dataUrl), T);
      if (rawBox) {
        const x = Array.isArray(rawBox) ? Number(rawBox[0]) : Number(rawBox.x);
        const y = Array.isArray(rawBox) ? Number(rawBox[1]) : Number(rawBox.y);
        const w = Array.isArray(rawBox) ? Number(rawBox[2]) : Number(rawBox.width);
        const h = Array.isArray(rawBox) ? Number(rawBox[3]) : Number(rawBox.height);
        if ([x, y, w, h].every(Number.isFinite) && w >= 0 && h >= 0) {
          bx = (w > 0 && h > 0) ? {
            tx0: Math.max(0, Math.floor(x / T)), ty0: Math.max(0, Math.floor(y / T)),
            tx1: Math.min(store.tilesW - 1, Math.floor((x + w - 1) / T)),
            ty1: Math.min(store.tilesH - 1, Math.floor((y + h - 1) / T)),
          } : { tx0: 1, ty0: 1, tx1: 0, ty1: 0 }; // 全透明 mask：所有 tile 都走空白分支
        }
      }
      for (let ty = 0; ty < store.tilesH; ty += 1) {
        for (let tx = 0; tx < store.tilesW; tx += 1) {
          const key = `${tx},${ty}`;
          if (bx && (tx < bx.tx0 || tx > bx.tx1 || ty < bx.ty0 || ty > bx.ty1)) {
            // 必须保留全画布 tile：实测稀疏 mask 会让 DstIn 未绘制区域保持可见（B7/C5 逐像素失败）。
            // 全透明 tile 只分配、不绘制、不重复快照（省掉整幅大图 drawImageRect 与 encode 开销）。
            store.ensureTile(id, key);
            continue;
          }
          const tile = store.ensureTile(id, key);
          const c = tile.surface.getCanvas();
          const x0 = tx * T, y0 = ty * T;
          const x1 = Math.min(x0 + T, this.width), y1 = Math.min(y0 + T, this.height);
          let drawn = false;
          if (typeof c.drawImageRect === 'function') {
            try {
              c.drawImageRect(img, [x0, y0, x1, y1], [0, 0, x1 - x0, y1 - y0], null, true);
              drawn = true;
            } catch (e) { drawn = false; }
          }
          if (!drawn) c.drawImage(img, -x0, -y0); // 兼容旧 CanvasKit
          tile.surface.flush();
          store.refreshImage(id, key);
        }
      }
      layer.mask = { exists: true, enabled: true };
      this.presentFull();
      return true;
    } finally { try { img.delete(); } catch (e) { /* ignore */ } }
  }

  removeMask(id) {
    const layer = this.layers.find((l) => l.id === id);
    if (!layer) return;
    this._dropStoreLayer(this.maskStore, id);
    layer.mask = { exists: false, enabled: true };
    this.presentFull();
  }

  setMaskEnabled(id, enabled) {
    const layer = this.layers.find((l) => l.id === id);
    if (!layer) return;
    layer.mask.enabled = !!enabled;
    this.presentFull();
  }

  getLayers() {
    return this.layers.map((l) => ({ ...l, mask: { ...l.mask } }));
  }

  getGroups() { return this.groups.map((g) => ({ ...g })); }

  /** 返回 V2Doc（纯 JSON，供 LayerSystem/PSD/serialization 共用） */
  getDoc() { return cloneDoc(this.doc); }

  /** 仅替换元数据文档（tile 保持；用于统一模型/PSD 桥） */
  setDoc(doc) {
    const d = normalizeDoc(doc);
    if (d.width !== this.width || d.height !== this.height) throw new Error('doc 尺寸与 engine 不一致');
    this.doc = d;
    this.layers = d.layers;
    this.groups = d.groups;
    this.activeLayerId = d.activeLayerId;
    this.compositor.setLayers(this.layers);
    this.presentFull();
    return d;
  }

  docStats() { return docStats(this.doc); }

  // ---------- 笔刷 ----------
  /** T41：设置笔刷 Provider（需实现 radiusFor；可选 begin/paintFor/stampFor/end/cancel/dispose） */
  setBrushProvider(provider) {
    if (!provider || typeof provider.radiusFor !== 'function') {
      throw new Error('setBrushProvider: provider.radiusFor(ctx) 必填');
    }
    const prev = this.brushProvider;
    this.brushProvider = provider;
    return prev;
  }

  getBrushProvider() { return this.brushProvider; }

  /** T49：输入平滑系数 0–1（0=关闭；Klecks LineSmoothing MIT 移植，见 input.js/line-smoothing.js） */
  setInputSmoothing(value) {
    const v = Number(value);
    this.inputSmoothing = Number.isFinite(v) ? Math.max(0, Math.min(1, v)) : 0;
    return this.inputSmoothing;
  }

  getInputSmoothing() { return this.inputSmoothing; }

  setBrush(brush) {
    if (!brush) return;
    if (brush.type) this.brush.type = brush.type;
    if (brush.sizePx) this.brush.sizePx = brush.sizePx;
    if (brush.opacity != null) this.brush.opacity = brush.opacity;
  }

  // ---------- 笔触事务 ----------
  beginStroke(p, brush, opts = {}) {
    if (!this._ready) throw new Error('engine 未初始化');
    // T84：支持 beginStroke(p, {maskPaint:'white'|'black'})；普通笔刷参数仍兼容
    if (brush && typeof brush === 'object' && !brush.type && brush.sizePx == null && brush.maskPaint != null) {
      opts = brush;
      brush = undefined;
    }
    const maskPaint = opts && opts.maskPaint === 'black' ? 'black' : (opts && opts.maskPaint === 'white' ? 'white' : this.maskPaint);
    this._cancelPresentBurst();
    if (this.currentMaskStroke) this._finishMaskStroke();
    if (this.currentStroke) this.cancelStroke();
    const layer = this.layers.find((l) => l.id === this.activeLayerId);
    if (!layer) return false;
    if (layer.locked) return false;
    this._clearLiveSurface();
    if (this.activeTarget === 'group-mask') {
      const group = this.groups.find((g) => g.id === this.activeGroupId);
      if (group && group.mask && group.mask.exists) {
        this.currentMaskStroke = { groupId: group.id, points: [p], affected: new Set(), maskPaint };
        this._maskStamp(p);
        this.requestFrame();
        return true;
      }
    }
    if (this.activeTarget === 'mask' && layer.mask && layer.mask.exists) {
      this.currentMaskStroke = { layerId: layer.id, points: [p], affected: new Set(), maskPaint };
      this._maskStamp(p);
      this.requestFrame();
      return true;
    }
    const spec = brush || this.brush;
    this.currentStroke = new Stroke(this.CK, this.store, this.activeLayerId, spec, p, { provider: this.brushProvider });
    // T44：画到离屏 live layer；帧渲染时再确定性合成到主 surface
    this._stampToLive(p);
    this.requestFrame();
    return true;
  }

  appendPoint(p, opts = {}) {
    if (this.currentMaskStroke) {
      this.currentMaskStroke.points.push(p);
      this._maskStamp(p);
      this.requestFrame();
      return;
    }
    if (!this.currentStroke) return;
    this.currentStroke.append(p, opts);
    this._stampToLive(p);
    this.requestFrame();
  }

  endStroke() {
    if (this.currentMaskStroke) return this._finishMaskStroke();
    if (!this.currentStroke) return null;
    const stroke = this.currentStroke;
    this.currentStroke = null;
    this._clearLiveSurface();
    const { entry, dirtyKeys } = stroke.commit();
    stroke.dispose();
    entry.storeKind = 'layer';
    if (this.selectionImage && entry.patches && entry.patches.length) {
      const CK = this.CK;
      for (const pt of entry.patches) {
        const tile = this.store.get(entry.layerId, pt.key);
        if (!tile) continue;
        const [tx, ty] = pt.key.split(',').map(Number);
        const c = tile.surface.getCanvas();
        const paint = new CK.Paint();
        paint.setBlendMode(CK.BlendMode.DstIn);
        c.drawImage(this.selectionImage, -tx * TILE, -ty * TILE, paint);
        paint.delete();
        tile.surface.flush();
        tile.image = tile.surface.makeImageSnapshot();
        pt.after = tile.image;
      }
    }
    const strokeLayer = this.layers.find((l) => l.id === entry.layerId);
    if (strokeLayer && strokeLayer.alphaLock && entry.patches && entry.patches.length) {
      entry.patches = entry.patches.map((pt) => this._alphaLockPatch(entry.layerId, pt));
    }
    this.undoManager.push(entry);
    // T49：脏区更新保留帧 → 整帧 blit 上屏（Klecks present/FBO blit 思路；T46 的“必须整帧上屏”仍成立）
    this.presentDirty(dirtyKeys);
    this._schedulePresentBurst(3);
    return entry;
  }

  cancelStroke() {
    this._clearLiveSurface();
    if (this.currentMaskStroke) {
      this.currentMaskStroke = null;
      this.presentFull();
      this._schedulePresentBurst(2);
      return;
    }
    if (!this.currentStroke) return;
    this.currentStroke.cancel();
    this.currentStroke.dispose();
    this.currentStroke = null;
    if (this.presentSurface) {
      this._blitRetained();
      this.lastPresentMode = 'blit';
    } else {
      this.presentFull();
    }
    this._schedulePresentBurst(2);
  }

  // ---------- T89：历史图片引用回收 / 预算 ----------
  /** TileStore.blankImage() 是跨 tile / 跨层复用的单例，绝不能被历史回收 delete。
   *  否则后续 putBlank() 会拿到失效指针，合成时抛 "Cannot pass deleted object"。 */
  _isSharedImage(img) {
    return !!img && (img === (this.store && this.store._blank) || img === (this.maskStore && this.maskStore._blank));
  }
  _entryImageRefs(entry, out) {
    if (!entry) return out;
    const addSnap = (snap) => {
      if (!snap || typeof snap !== 'object') return;
      for (const store of [snap.tiles, snap.masks]) {
        if (!store) continue;
        for (const tiles of Object.values(store)) for (const img of Object.values(tiles || {})) if (img) out.add(img);
      }
    };
    if (entry.kind === 'image') { if (entry.before) out.add(entry.before); if (entry.after) out.add(entry.after); }
    else if (entry.kind === 'structure') { addSnap(entry.before); addSnap(entry.after); }
    else if (entry.patches) { for (const p of entry.patches) { if (p.before) out.add(p.before); if (p.after) out.add(p.after); } }
    return out;
  }

  _collectImageRefs() {
    const refs = new Set();
    for (const e of this.undoManager.undoStack) this._entryImageRefs(e, refs);
    for (const e of this.undoManager.redoStack) this._entryImageRefs(e, refs);
    for (const store of [this.store, this.maskStore]) {
      for (const map of store.layers.values()) for (const tile of map.values()) if (tile.image) refs.add(tile.image);
    }
    return refs;
  }

  _releaseHistoryEntry(entry) {
    const candidates = this._entryImageRefs(entry, new Set());
    if (!candidates.size) return 0;
    const refs = this._collectImageRefs();
    let released = 0;
    for (const img of candidates) {
      if (refs.has(img) || this._isSharedImage(img)) continue;
      try { img.delete(); released += 1; this._historyImagesReleased += 1; } catch (e) { /* ignore */ }
    }
    return released;
  }

  _setupHistoryReclaim() {
    if (!this.undoManager) return;
    this.undoManager.onEvict = (entry) => this._releaseHistoryEntry(entry);
  }

  /** T89：设置历史步数/内存预算与自动回收（默认开；auto=false 回退旧行为） */
  setHistoryBudget(opts = {}) {
    const r = this.undoManager.setLimits(opts);
    this._setupHistoryReclaim();
    return r;
  }

  getHistoryStats() {
    return {
      steps: this.undoManager.depth(),
      redo: this.undoManager.redoDepth(),
      bytes: this.undoManager.memoryEstimate(),
      maxSteps: this.undoManager.maxSteps,
      maxBytes: this.undoManager.maxBytes,
      auto: this.undoManager.autoEvict,
      evictedSteps: this.undoManager.evictedSteps,
      imagesReleased: this._historyImagesReleased,
      imageRefs: this._collectImageRefs().size,
    };
  }

  undo() {
    this._clearLiveSurface();
    const entry = this.undoManager.popUndo();
    if (!entry) return false;
    if (entry.kind === 'image') {
      this._replaceLayerFromImage(entry.layerId, entry.before);
      this._applyLayerInfoSnapshot(entry.layerId, entry.infoBefore);
      if (entry.maskBefore) this.restoreMaskState(entry.layerId, entry.maskBefore); // T117 P1-2
      this.presentFull();
      this._schedulePresentBurst(3);
      return true;
    }
    if (entry.kind === 'structure') {
      this._restoreStructure(entry.before);
      this._schedulePresentBurst(3);
      return true;
    }
    const dirty = [];
    const store = (entry.storeKind === 'mask' || entry.storeKind === 'group-mask') ? this.maskStore : this.store;
    for (const patch of entry.patches) {
      store.applyImage(entry.layerId, patch.key, patch.before);
      dirty.push(patch.key);
    }
    this.presentDirty(dirty);
    this._schedulePresentBurst(3);
    return true;
  }

  redo() {
    this._clearLiveSurface();
    const entry = this.undoManager.popRedo();
    if (!entry) return false;
    if (entry.kind === 'image') {
      this._replaceLayerFromImage(entry.layerId, entry.after);
      this._applyLayerInfoSnapshot(entry.layerId, entry.infoAfter);
      if (entry.maskAfter) this.restoreMaskState(entry.layerId, entry.maskAfter); // T117 P1-2
      this.presentFull();
      this._schedulePresentBurst(3);
      return true;
    }
    if (entry.kind === 'structure') {
      this._restoreStructure(entry.after);
      this._schedulePresentBurst(3);
      return true;
    }
    const dirty = [];
    const store = (entry.storeKind === 'mask' || entry.storeKind === 'group-mask') ? this.maskStore : this.store;
    for (const patch of entry.patches) {
      store.applyImage(entry.layerId, patch.key, patch.after);
      dirty.push(patch.key);
    }
    this.presentDirty(dirty);
    this._schedulePresentBurst(3);
    return true;
  }

  /** T46 兼容入口：T49 起走“保留帧脏区更新 + 整帧 blit”，任何路径都整帧上屏 */
  compositeDirtySafe(dirty) {
    this.presentDirty(dirty || []);
    this._schedulePresentBurst(2);
  }

  canUndo() { return this.undoManager.canUndo(); }
  canRedo() { return this.undoManager.canRedo(); }
  getHistorySummary(limit = 12) {
    const map = { image: '图像 / 变换', structure: '图层结构', tile: '笔触' };
    const st = this.undoManager.undoStack || [];
    return st.slice(-limit).map((e, i) => ({ depth: st.length - limit + i + 1 >= 1 ? st.length - Math.min(limit, st.length) + i + 1 : i + 1, kind: e.kind, label: map[e.kind] || (e.kind === 'patches' ? '笔触' : (e.kind || '操作')) }));
  }
  undoToDepth(targetDepth) {
    let n = 0;
    while (this.undoManager.undoStack.length > Math.max(0, targetDepth) && this.undo()) n += 1;
    return n;
  }

  // T49：Klecks KlHistory 风格能力（pause / replaceTop / listeners）
  pauseHistory() { return this.undoManager.pause(); }
  resumeHistory() { return this.undoManager.resume(); }
  replaceTopHistory(entry) { return this.undoManager.replaceTop(entry); }

  /** 合并栈顶 n 个 paint 条目（对称笔迹 = 原笔 + 镜像笔，合成 1 步 undo） */
  mergeLastPaintEntries(count = 2) {
    return this.undoManager.mergeTop(count, (entries) => {
      if (!entries.length) return null;
      const first = entries[0];
      if (!entries.every((e) => e && (!e.kind || e.kind === 'paint') && e.layerId === first.layerId && e.storeKind === first.storeKind)) return null;
      const map = new Map();
      for (const e of entries) {
        for (const p of e.patches || []) {
          const ex = map.get(p.key);
          if (!ex) map.set(p.key, { key: p.key, before: p.before, after: p.after });
          else ex.after = p.after;
        }
      }
      if (!map.size) return null;
      return { kind: 'paint', storeKind: first.storeKind, layerId: first.layerId, patches: [...map.values()] };
    });
  }
  onHistoryChange(fn) { return this.undoManager.addListener(fn); }

  // ---------- 实时预览（T44：每帧确定性重绘） ----------
  _clearLiveSurface() {
    if (this.liveCanvas && this.CK) {
      try { this.liveCanvas.clear(this.CK.TRANSPARENT); } catch (e) { /* ignore */ }
    }
  }

  /** 当前 Provider 是否为擦除笔刷（provider.eraser 或 provider.isEraser(ctx)） */
  _isEraserMode() {
    const provider = this.brushProvider;
    if (!provider) return false;
    if (provider.eraser === true) return true;
    if (typeof provider.isEraser === 'function') {
      const rec = this.currentStroke && this.currentStroke.records[this.currentStroke.records.length - 1];
      try { return !!provider.isEraser(rec || {}); } catch (e) { return false; }
    }
    return false;
  }

  /** 把最新点画到 live layer（erase 模式画白色覆盖 mask，供 DstOut） */
  _stampToLive(p) {
    if (!this.liveCanvas) return;
    if (this.currentMaskStroke) {
      const r = this._maskRadius(p);
      this.liveCanvas.drawCircle(p.x, p.y, r, this._liveEraserPaint);
      this.requestFrame();
      return;
    }
    if (!this.currentStroke) return;
    if (this._isEraserMode()) {
      const r = this.currentStroke.radiusFor(p);
      this.liveCanvas.drawCircle(p.x, p.y, r, this._liveEraserPaint);
    } else {
      this.currentStroke.stampTo(this.liveCanvas);
    }
    this.requestFrame();
  }

  /** 当前 live 预览信息（T60：普通笔触 / 擦除 / 蒙版笔触） */
  _liveInfo() {
    if (this.currentMaskStroke) {
      const black = this.currentMaskStroke.maskPaint === 'black';
      if (this.currentMaskStroke.groupId) return { groupId: this.currentMaskStroke.groupId, mode: black ? 'group-mask-erase' : 'group-mask-union' };
      return { layerId: this.currentMaskStroke.layerId, mode: black ? 'mask-erase' : 'mask-union' };
    }
    if (this.currentStroke) return { layerId: this.activeLayerId, mode: this._isEraserMode() ? 'erase' : 'paint' };
    return null;
  }

  /** 把「已提交文档 + 当前 live 笔触」画到给定 canvas（确定性；返回 live 图像用于释放） */
  _drawComposite(c, includeLive) {
    let liveImg = null;
    let live = null;
    const info = includeLive ? this._liveInfo() : null;
    if (info) {
      liveImg = this.liveSurface.makeImageSnapshot();
      live = { ...info, image: liveImg };
    }
    this.compositor.drawDocument(c, this.doc, this.store, this.maskStore, { live });
    return liveImg;
  }

  // ---------- 蒙版笔触（T60） ----------
  _maskRadius(p) {
    const size = (this.brush && this.brush.sizePx) || 64;
    return Math.max(0.5, size * 0.5 * (0.25 + (p.pressure == null ? 0.5 : p.pressure) * 0.75));
  }

  _maskStamp(p) {
    const state = this.currentMaskStroke;
    if (!state || !this.liveCanvas) return;
    const r = this._maskRadius(p);
    this.liveCanvas.drawCircle(p.x, p.y, r, this._liveEraserPaint);
    const tx0 = Math.max(0, Math.floor((p.x - r) / TILE));
    const ty0 = Math.max(0, Math.floor((p.y - r) / TILE));
    const tx1 = Math.min(this.store.tilesW - 1, Math.floor((p.x + r) / TILE));
    const ty1 = Math.min(this.store.tilesH - 1, Math.floor((p.y + r) / TILE));
    for (let ty = ty0; ty <= ty1; ty += 1) for (let tx = tx0; tx <= tx1; tx += 1) state.affected.add(`${tx},${ty}`);
  }

  _finishMaskStroke() {
    const state = this.currentMaskStroke;
    if (!state) return null;
    this.currentMaskStroke = null;
    this._clearLiveSurface();
    const targetId = state.groupId || state.layerId;
    const storeKind = state.groupId ? 'group-mask' : 'mask';
    const patches = [];
    const black = state.maskPaint === 'black';
    for (const key of [...state.affected]) {
      const existed = !!this.maskStore.get(targetId, key);
      const tile = this.maskStore.ensureTile(targetId, key);
      let before = tile.image;
      const { tx, ty } = this.maskStore.keyXY(key);
      const c = tile.surface.getCanvas();
      // 黑色橡皮首次触碰空白 tile：先铺白（未画区域保持可见），before 取铺白后快照，
      // 使 undo 回到可见状态而不是空 tile 的隐藏状态
      if (black && !existed) {
        const wp = new this.CK.Paint();
        wp.setBlendMode(this.CK.BlendMode.Src);
        wp.setColor(this.CK.Color(255, 255, 255, 1));
        c.drawRect([0, 0, TILE, TILE], wp);
        wp.delete();
        tile.surface.flush();
        before = tile.surface.makeImageSnapshot();
        tile.image = before;
      }
      const paint = black ? this._maskBlackPaint : this._liveEraserPaint;
      for (const p of state.points) {
        const r = this._maskRadius(p);
        c.drawCircle(p.x - tx * TILE, p.y - ty * TILE, r, paint);
      }
      tile.surface.flush();
      tile.image = tile.surface.makeImageSnapshot();
      patches.push({ key, before, after: tile.image });
    }
    const entry = { kind: 'paint', storeKind, layerId: targetId, patches };
    this.undoManager.push(entry);
    this.presentFull();
    this._schedulePresentBurst(3);
    return entry;
  }

  _dropStoreLayer(store, layerId) {
    const map = store.layers.get(layerId);
    if (!map) return;
    for (const t of map.values()) {
      try { t.image.delete(); } catch (e) { /* ignore */ }
      try { t.surface.delete(); } catch (e) { /* ignore */ }
    }
    map.clear();
    store.layers.delete(layerId);
  }

  // ---------- V2Doc 序列化（T60：单文件 .mozheng = JSON + tile PNG base64） ----------
  _exportStore(store) {
    const out = {};
    for (const [layerId, map] of store.layers.entries()) {
      const tiles = {};
      for (const [key, tile] of map.entries()) {
        try { tiles[key] = b64encode(tile.image.encodeToBytes()); } catch (e) { /* ignore */ }
      }
      if (Object.keys(tiles).length) out[layerId] = tiles;
    }
    return out;
  }

  _importStore(store, data) {
    if (!data) return;
    for (const [layerId, tiles] of Object.entries(data)) {
      for (const [key, b64] of Object.entries(tiles)) {
        try {
          const img = this.CK.MakeImageFromEncoded(new Uint8Array(b64decode(b64)));
          if (!img) continue;
          store.applyImage(layerId, key, img);
          img.delete();
        } catch (e) { /* ignore 单 tile 损坏不阻塞加载 */ }
      }
    }
  }

  /** 序列化为单文件 .mozheng（JSON string；含 doc JSON + tile PNG base64 + manifest.version） */
  async resizeCanvas(newWidth, newHeight, opts = {}) {
    const CK = this.CK;
    if (!CK) throw new Error('resizeCanvas: engine 未初始化');
    const tw = Math.max(1, Math.floor(Number(newWidth) || this.width));
    const th = Math.max(1, Math.floor(Number(newHeight) || this.height));
    const ox = Math.round(Number(opts.offsetX) || 0);
    const oy = Math.round(Number(opts.offsetY) || 0);
    const layerCaps = [];
    for (const l of this.layers) {
      const img = this._renderLayerImage(l.id);
      const maskImg = (l.mask && l.mask.exists) ? this._renderStoreLayerImage(this.maskStore, l.id) : null;
      layerCaps.push({ meta: JSON.parse(JSON.stringify(l)), img, maskImg });
    }
    const groupCaps = (this.groups || []).map((g) => ({
      meta: JSON.parse(JSON.stringify(g)),
      maskImg: (g.mask && g.mask.exists) ? this._renderStoreLayerImage(this.maskStore, g.id) : null,
    }));
    const activeId = this.activeLayerId;
    try { this.currentStroke && this.currentStroke.cancel && this.currentStroke.cancel(); } catch (e) { /* ignore */ }
    this.currentStroke = null;
    try { this.cancelTransform && this.cancelTransform(); } catch (e) { /* ignore */ }
    this._transform = null;
    this.selectionImage = null;
    try { this.compositor.dispose(); } catch (e) { /* ignore */ }
    try { this.store.dispose(); } catch (e) { /* ignore */ }
    try { this.maskStore.dispose(); } catch (e) { /* ignore */ }
    try { this.liveSurface && this.liveSurface.delete(); } catch (e) { /* ignore */ }
    try { this.presentSurface && this.presentSurface.delete(); } catch (e) { /* ignore */ }
    this.width = tw; this.height = th;
    const canvas = this.opts.canvas;
    canvas.width = tw; canvas.height = th;
    const glHandle = CK.GetWebGLContext(canvas, { majorVersion: 2, antialias: 0 });
    if (!glHandle) throw new Error('resizeCanvas: WebGL context 创建失败');
    this.glHandle = glHandle;
    this.gr = CK.MakeWebGLContext(glHandle);
    if (!this.gr) throw new Error('resizeCanvas: MakeWebGLContext 失败');
    this.store = new TileStore(CK, this.gr, tw, th);
    this.maskStore = new TileStore(CK, this.gr, tw, th);
    this.compositor = new Compositor(CK, this.gr, canvas, tw, th);
    this.liveSurface = CK.MakeRenderTarget(this.gr, tw, th);
    this.liveCanvas = this.liveSurface.getCanvas();
    this.liveCanvas.clear(CK.TRANSPARENT);
    this._liveEraserPaint = new CK.Paint();
    this._liveEraserPaint.setAntiAlias(true);
    this._liveEraserPaint.setStyle(CK.PaintStyle.Fill);
    this._liveEraserPaint.setColor(CK.Color(255, 255, 255, 1));
    this._liveMaskPaint = this._liveEraserPaint;
    this.presentRetained = tw * th <= 2048 * 2048;
    this.presentSurface = null; this.presentCanvas = null;
    if (this.presentRetained) {
      this.presentSurface = CK.MakeRenderTarget(this.gr, tw, th);
      this.presentCanvas = this.presentSurface.getCanvas();
      this.presentCanvas.clear(CK.WHITE);
    }
    this.doc = createDoc({ width: tw, height: th, layers: layerCaps.map((c) => c.meta), groups: groupCaps.map((c) => c.meta), activeLayerId: activeId });
    this.layers = this.doc.layers;
    this.groups = this.doc.groups;
    this.activeLayerId = this.doc.layers.some((l) => l.id === activeId) ? activeId : (this.layers.length ? this.layers[this.layers.length - 1].id : null);
    const blit = (img, store, id) => {
      const surface = CK.MakeRenderTarget(this.gr, tw, th);
      const c = surface.getCanvas();
      c.clear(CK.TRANSPARENT);
      if (img) c.drawImage(img, ox, oy);
      const next = surface.makeImageSnapshot();
      this._replaceStoreFromImage(store, id, next);
      try { next.delete(); } catch (e) { /* ignore */ }
      try { surface.delete(); } catch (e) { /* ignore */ }
    };
    for (const cap of layerCaps) {
      blit(cap.img, this.store, cap.meta.id);
      if (cap.maskImg) blit(cap.maskImg, this.maskStore, cap.meta.id);
    }
    for (const cap of groupCaps) {
      if (cap.maskImg) blit(cap.maskImg, this.maskStore, cap.meta.id);
    }
    for (const cap of layerCaps) { try { cap.img && cap.img.delete(); cap.maskImg && cap.maskImg.delete(); } catch (e) { /* ignore */ } }
    for (const cap of groupCaps) { try { cap.maskImg && cap.maskImg.delete(); } catch (e) { /* ignore */ } }
    this.undoManager = new UndoManager(this.store);
    this._setupHistoryReclaim();
    this.compositor.setLayers(this.layers);
    this.presentFull();
    this._schedulePresentBurst(3);
    return { width: tw, height: th, offsetX: ox, offsetY: oy };
  }

  serializeDoc() {
    return JSON.stringify({
      format: 'mozheng',
      version: 1,
      doc: this.getDoc(),
      tiles: this._exportStore(this.store),
      masks: this._exportStore(this.maskStore),
    });
  }

  /** T77：gzip 压缩保存（.mozheng v2 = gzip(JSON v1)）；返回 Uint8Array（gzip 魔数 1f 8b） */
  async serializeDocGzip() {
    const json = this.serializeDoc();
    return gzipBytes(new TextEncoder().encode(json));
  }

  /** T77：保存为 Blob（compress=true → 压缩 v2；false → v1 JSON） */
  async getDocFileBlob(opts = {}) {
    if (opts.compress === false) {
      return new Blob([this.serializeDoc()], { type: 'application/json' });
    }
    const bytes = await this.serializeDocGzip();
    return new Blob([bytes], { type: 'application/octet-stream' });
  }

  /** T77：加载 gzip v2 文件（Blob/Uint8Array/ArrayBuffer） */
  // ---------- T79：异步保存（tile PNG 编码在 Worker；同步 serializeDoc 保留兜底） ----------
  _newTileEncodeWorker() {
    const worker = new Worker(new URL('./export-worker.js', import.meta.url), { type: 'module' });
    const pending = new Map();
    worker.onmessage = (ev) => {
      const m = ev.data || {};
      if (m.type === 'doc-tile-done' && pending.has(m.id)) {
        const { resolve } = pending.get(m.id);
        pending.delete(m.id);
        resolve(m.buffer);
      }
    };
    worker.onerror = () => { for (const { reject } of pending.values()) reject(new Error('tile 编码 Worker 错误')); pending.clear(); };
    return { worker, pending };
  }

  _readTileRGBA(tile) {
    const T = this.tileSize;
    return tile.image.readPixels(0, 0, {
      width: T, height: T,
      colorType: this.CK.ColorType.RGBA_8888,
      alphaType: this.CK.AlphaType.Unpremul,
      colorSpace: this.CK.ColorSpace.SRGB,
    });
  }

  async _encodeStoreAsync(store, worker, pending, job, onProgress, signal) {
    const out = {};
    let seq = 0;
    for (const [layerId, map] of store.layers.entries()) {
      const tiles = {};
      for (const [key, tile] of map.entries()) {
        if (job.cancelled || (signal && signal.aborted)) throw Object.assign(new Error('保存已取消'), { name: 'AbortError' });
        const pixels = this._readTileRGBA(tile);
        seq += 1;
        const id = `${layerId}:${key}:${seq}`;
        const buf = new Uint8Array(pixels.length); buf.set(pixels);
        const promise = new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
        worker.postMessage({ type: 'doc-tile', id, width: this.tileSize, height: this.tileSize, buffer: buf.buffer }, [buf.buffer]);
        const encoded = await promise;
        tiles[key] = b64encode(new Uint8Array(encoded));
        if (onProgress) onProgress({ phase: 'encode', done: seq, layerId, key });
      }
      if (Object.keys(tiles).length) out[layerId] = tiles;
      await new Promise((r) => requestAnimationFrame(r));
    }
    return out;
  }

  /** T79：预热保存管线（首次 tile readPixels 会等待 GPU 队列，约 ~150ms）。
   *  建议 app 启动空闲时调用一次；之后 saveDocAsync 主线程长任务为 0。 */
  async warmUpSaveAsync() {
    if (!this._ready || this._saveWarmed) return false;
    try {
      for (const [, map] of this.store.layers.entries()) {
        for (const [, tile] of map.entries()) {
          this._readTileRGBA(tile);
          this._saveWarmed = true;
          return true;
        }
      }
      this._saveWarmed = true;
      return true;
    } catch (e) { return false; }
  }

  /** T79：异步序列化（tile PNG 编码在 Worker；主线程只 readPixels/组装 JSON） */
  async serializeDocAsync(opts = {}) {
    if (!this._ready) throw new Error('engine 未初始化');
    if (this._exportJob || this._saveJob) throw new Error('已有导出/保存任务进行中');
    const token = { cancelled: false };
    this._saveJob = token;
    // F25：在 await 之前捕获 doc 快照，避免保存期间 app/自动任务改动 doc 导致结构漂移
    const doc = this.getDoc();
    const { worker, pending } = this._newTileEncodeWorker();
    const t0 = performance.now();
    try {
      // 先让出一帧，等待已排队的 GPU 绘制/呈现完成，避免首次 readPixels 同步阻塞成长任务
      await new Promise((r) => requestAnimationFrame(r));
      await new Promise((r) => requestAnimationFrame(r));
      const tiles = await this._encodeStoreAsync(this.store, worker, pending, token, (p) => opts.onProgress && opts.onProgress({ ...p, store: 'tiles' }), opts.signal);
      const masks = await this._encodeStoreAsync(this.maskStore, worker, pending, token, (p) => opts.onProgress && opts.onProgress({ ...p, store: 'masks' }), opts.signal);
      if (token.cancelled) throw Object.assign(new Error('保存已取消'), { name: 'AbortError' });
      const json = JSON.stringify({ format: 'mozheng', version: 1, doc, tiles, masks });
      if (opts.onProgress) opts.onProgress({ phase: 'done', done: 1, total: 1, ms: Math.round((performance.now() - t0) * 100) / 100 });
      return json;
    } finally {
      this._saveJob = null;
      try { worker.terminate(); } catch (e) { /* ignore */ }
    }
  }

  /** T79：异步 gzip 保存（v2） */
  async serializeDocGzipAsync(opts = {}) {
    const json = await this.serializeDocAsync(opts);
    return gzipBytes(new TextEncoder().encode(json));
  }

  /** T79：保存为 Blob（Worker 编码；compress=true → gzip v2，false → JSON v1） */
  async saveDocAsync(opts = {}) {
    if (opts.compress === false) {
      const json = await this.serializeDocAsync(opts);
      return new Blob([json], { type: 'application/json' });
    }
    const bytes = await this.serializeDocGzipAsync(opts);
    return new Blob([bytes], { type: 'application/octet-stream' });
  }

  /** T79：取消进行中的异步保存 */
  cancelSave() {
    if (!this._saveJob) return false;
    this._saveJob.cancelled = true;
    this._saveJob = null;
    return true;
  }

  // ---------- T79：PSD 导出 Worker（逐层渲染 → worker ag-psd 打包） ----------
  _readStorePixels(store, layerId) {
    const map = store.layers.get(layerId);
    const out = new Uint8ClampedArray(this.width * this.height * 4);
    if (!map) return out;
    const T = this.tileSize;
    for (const [key, tile] of map.entries()) {
      const { tx, ty } = store.keyXY(key);
      const tilePixels = this._readTileRGBA(tile);
      for (let y = 0; y < T; y += 1) {
        const src = y * T * 4;
        const dst = ((ty * T + y) * this.width + tx * T) * 4;
        if (dst + T * 4 > out.length) continue;
        out.set(tilePixels.subarray(src, src + T * 4), dst);
      }
    }
    return out;
  }

  _buildPsdChildren(doc, canvases, maskCanvases) {
    const groupMap = new Map();
    const root = [];
    for (const g of doc.groups) {
      const node = { type: 'group', name: g.name, visible: g.visible !== false, opacity: g.opacity == null ? 1 : g.opacity, children: [] };
      groupMap.set(g.id, node);
      root.push(node);
    }
    for (const l of doc.layers) {
      const node = {
        type: 'layer', name: l.name, visible: l.visible !== false,
        opacity: l.opacity == null ? 1 : l.opacity,
        blendMode: l.blend || 'normal', clip: !!l.clip,
        width: this.width, height: this.height,
        pixels: canvases.get(l.id) || null,
        maskPixels: l.mask && l.mask.exists ? (maskCanvases.get(l.id) || null) : null,
      };
      if (l.group && groupMap.has(l.group)) groupMap.get(l.group).children.push(node);
      else root.push(node);
    }
    return root;
  }

  async exportPSDAsync(opts = {}) {
    if (!this._ready) throw new Error('engine 未初始化');
    if (this._psdJob) throw new Error('已有 PSD 导出进行中');
    if (typeof Worker === 'undefined') throw new Error('当前环境不支持 PSD 导出 Worker');
    const token = { cancelled: false };
    this._psdJob = token;
    const t0 = performance.now();
    const worker = new Worker(new URL('./psd-worker.js', import.meta.url));
    try {
      const doc = this.getDoc();
      const canvases = new Map();
      const maskCanvases = new Map();
      let done = 0;
      for (const l of doc.layers) {
        if (token.cancelled) throw Object.assign(new Error('PSD 导出已取消'), { name: 'AbortError' });
        canvases.set(l.id, this._readStorePixels(this.store, l.id));
        if (l.mask && l.mask.exists) maskCanvases.set(l.id, this._readStorePixels(this.maskStore, l.id));
        done += 1;
        if (opts.onProgress) opts.onProgress({ phase: 'render', done, total: doc.layers.length });
        await new Promise((r) => requestAnimationFrame(r));
      }
      const children = this._buildPsdChildren(doc, canvases, maskCanvases);
      const transfers = [];
      const collect = (nodes) => {
        for (const n of nodes) {
          if (n.pixels) transfers.push(n.pixels.buffer);
          if (n.maskPixels) transfers.push(n.maskPixels.buffer);
          if (n.children) collect(n.children);
        }
      };
      collect(children);
      const result = await new Promise((resolve, reject) => {
        worker.onmessage = (ev) => {
          const m = ev.data || {};
          if (m.type === 'psd-done') resolve(m.buffer);
          else if (m.type === 'psd-error') reject(new Error('PSD Worker: ' + m.message));
        };
        worker.onerror = () => reject(new Error('PSD 导出 Worker 错误'));
        worker.postMessage({ type: 'psd-init', width: this.width, height: this.height, children }, transfers);
      });
      if (opts.onProgress) opts.onProgress({ phase: 'done', done: 1, total: 1, ms: Math.round((performance.now() - t0) * 100) / 100 });
      return new Blob([result], { type: 'image/vnd.adobe.photoshop' });
    } finally {
      this._psdJob = null;
      try { worker.terminate(); } catch (e) { /* ignore */ }
    }
  }

  /** 取消进行中的 PSD 导出 */
  cancelPSDExport() {
    if (!this._psdJob) return false;
    this._psdJob.cancelled = true;
    this._psdJob = null;
    return true;
  }

  async deserializeDocGzip(input) {
    const bytes = await toBytes(input);
    if (!isGzipBytes(bytes)) throw new Error('不是 gzip 压缩的 .mozheng v2 文件');
    let jsonBytes;
    try { jsonBytes = await gunzipBytes(bytes); } catch (e) { throw new Error('gzip 解压失败：文件损坏或非 gzip 格式'); }
    const json = new TextDecoder().decode(jsonBytes);
    return this.deserializeDoc(json);
  }

  /** T77：自动识别 v1（JSON string/bytes）与 v2（gzip bytes）；返回 Promise<doc> */
  async deserializeDocAuto(input) {
    if (typeof input === 'string') {
      const trimmed = input.trim();
      if (trimmed.startsWith('{')) return this.deserializeDoc(trimmed);
      throw new Error('不是 v1 JSON .mozheng 文件');
    }
    const bytes = await toBytes(input);
    if (isGzipBytes(bytes)) return this.deserializeDocGzip(bytes);
    const text = new TextDecoder().decode(bytes);
    try { return this.deserializeDoc(text); } catch (e) { throw new Error('不是有效的 .mozheng（v1/v2）文件：' + ((e && e.message) || e)); }
  }

  /** 从 .mozheng（JSON string/object）加载：tile 还原、doc 恢复、可继续编辑，undo 清空 */
  deserializeDoc(input) {
    const container = typeof input === 'string' ? JSON.parse(input) : input;
    if (!container || container.format !== 'mozheng') throw new Error('不是 .mozheng 文件');
    const doc = normalizeDoc(container.doc);
    const check = validateDoc(doc);
    if (!check.ok) throw new Error('V2Doc 校验失败：' + check.errors.slice(0, 3).join('; '));
    if (doc.width !== this.width || doc.height !== this.height) throw new Error('doc 尺寸与 engine 不一致');
    this.store.dispose();
    this.maskStore.dispose();
    this.store = new TileStore(this.CK, this.gr, this.width, this.height);
    this.maskStore = new TileStore(this.CK, this.gr, this.width, this.height);
    this.undoManager = new UndoManager(this.store);
    this._setupHistoryReclaim();
    this._importStore(this.store, container.tiles);
    this._importStore(this.maskStore, container.masks);
    this.doc = doc;
    this.layers = doc.layers;
    this.groups = doc.groups;
    this.activeLayerId = doc.activeLayerId;
    this.compositor.setLayers(this.layers);
    this._clearLiveSurface();
    this.presentFull();
    this._schedulePresentBurst(2);
    return doc;
  }

  _renderLiveFrame() {
    if (!this._ready || (!this.currentStroke && !this.currentMaskStroke)) return;
    const t0 = performance.now();
    const liveImg = this._drawComposite(this.compositor.canvas, true);
    try { this.compositor.surface.flush(); } catch (e) { /* ignore */ }
    if (liveImg) { try { liveImg.delete(); } catch (e) { /* ignore */ } }
    this.lastCompositeMs = Math.round((performance.now() - t0) * 100) / 100;
  }

  /** T49：运行时开关保留帧（app 可按文档尺寸调用；启用/关闭后立即重绘，行为等价） */
  setPresentRetained(enabled) {
    const want = !!enabled;
    if (!this._ready) { this.presentRetained = want; return want; }
    if (want === !!this.presentSurface) { this.presentRetained = want; return want; }
    if (want) {
      this.presentSurface = this.CK.MakeRenderTarget(this.gr, this.width, this.height);
      if (!this.presentSurface) throw new Error('present surface 创建失败');
      this.presentRetained = true;
      this.presentCanvas = this.presentSurface.getCanvas();
      this.presentCanvas.clear(this.CK.WHITE);
      this.presentFull();
    } else {
      this.presentRetained = false;
      try { this.presentSurface && this.presentSurface.delete(); } catch (e) { /* ignore */ }
      this.presentSurface = null;
      this.presentCanvas = null;
      this.presentFull();
    }
    return this.presentRetained;
  }

  /** T46/T49：全量确定性 present（clear → 全部图层 → live → 保留帧 → 整帧 blit 上屏） */
  setPresentStrategy(mode) {
    this.presentStrategy = mode === 'dirty' ? 'dirty' : 'full';
    return this.presentStrategy;
  }
  getPresentStrategy() { return this.presentStrategy; }
  getPresentStats() {
    return {
      strategy: this.presentStrategy, retained: !!this.presentSurface,
      lastMode: this.lastPresentMode, lastCompositeMs: this.lastCompositeMs,
      lastBlitMs: this.lastBlitMs || 0, lastRedrawArea: this.lastRedrawArea,
      lastRedrawPct: this.lastRedrawPct, width: this.width, height: this.height,
    };
  }
  presentFull() {
    if (!this._ready) return;
    const t0 = performance.now();
    if (this.presentSurface) {
      this.presentCanvas = this.presentSurface.getCanvas();
      const liveImg = this._drawComposite(this.presentCanvas, !!(this.currentStroke || this.currentMaskStroke));
      if (liveImg) { try { liveImg.delete(); } catch (e) { /* ignore */ } }
      this._blitRetained();
    } else {
      const liveImg = this._drawComposite(this.compositor.canvas, !!this.currentStroke);
      if (liveImg) { try { liveImg.delete(); } catch (e) { /* ignore */ } }
      try { this.compositor.surface.flush(); } catch (e) { /* ignore */ }
    }
    this.lastPresentMode = 'full';
    this.lastRedrawArea = this.width * this.height;
    this.lastRedrawPct = 1;
    this.lastCompositeMs = Math.round((performance.now() - t0) * 100) / 100;
  }

  /** T49：保留帧 + 整帧 blit 的 present 入口。
   *  现阶段统一走全量重绘保留帧再 blit（Klecks renderCanvas + present 语义）；
   *  脏区增量更新保留帧作为下一步优化（需先解决 CanvasKit RenderTarget snapshot 语义）。
   */
  presentDirty(keys) {
    if (this.presentStrategy !== 'dirty' || !this.presentSurface || !keys || keys.length === 0) return this.presentFull();
    const T = this.tileSize;
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const key of keys) {
      const [tx, ty] = String(key).split(',').map(Number);
      if (!Number.isFinite(tx) || !Number.isFinite(ty)) continue;
      x0 = Math.min(x0, tx * T); y0 = Math.min(y0, ty * T);
      x1 = Math.max(x1, Math.min(this.width, (tx + 1) * T)); y1 = Math.max(y1, Math.min(this.height, (ty + 1) * T));
    }
    if (!Number.isFinite(x0) || x1 <= x0 || y1 <= y0) return this.presentFull();
    const area = (x1 - x0) * (y1 - y0);
    const full = this.width * this.height;
    if (area > full * 0.5) return this.presentFull();
    const t0 = performance.now();
    this.presentCanvas = this.presentSurface.getCanvas();
    const c = this.presentCanvas;
    c.save();
    // CanvasKit clipRect 参数是 Rect：[left, top, right, bottom]（不是 x,y,w,h）
    c.clipRect([x0, y0, x1, y1], this.CK.ClipOp.Intersect, false);
    c.clear(this.CK.WHITE);
    this.compositor.drawDocument(c, this.doc, this.store, this.maskStore, {});
    c.restore();
    try { this.presentSurface.flush(); } catch (e) { /* ignore */ }
    this._blitRetained();
    this.lastPresentMode = 'dirty';
    this.lastRedrawArea = area;
    this.lastRedrawPct = Math.round(area / full * 1000) / 1000;
    this.lastCompositeMs = Math.round((performance.now() - t0) * 100) / 100;
  }

  /** T49：把保留的全帧纹理一次性画到 on-screen surface（Klecks FBO blit 对应实现） */
  _blitRetained() {
    if (!this.presentSurface) return;
    const t0 = performance.now();
    // 先 flush 保留帧，确保 snapshot 反映最新绘制（否则可能拿到旧帧/空白）
    try { this.presentSurface.flush(); } catch (e) { /* ignore */ }
    const img = this.presentSurface.makeImageSnapshot();
    this.compositor.canvas.drawImage(img, 0, 0);
    try { this.compositor.surface.flush(); } catch (e) { /* ignore */ }
    try { img.delete(); } catch (e) { /* ignore */ }
    this.lastBlitMs = Math.round((performance.now() - t0) * 100) / 100;
  }

  /** T46：present 后补几帧全量重绘，抵消浏览器合成后清空 drawing buffer 的时机差异 */
  _schedulePresentBurst(frames = 2) {
    if (!this._ready || !(frames > 0)) return;
    if (this._presentBurstActive) {
      this._presentBurstExtra = Math.max(this._presentBurstExtra || 0, frames);
      return;
    }
    this._presentBurstActive = true;
    this._presentBurstExtra = 0;
    let remaining = frames;
    const step = () => {
      if (!this._ready) { this._presentBurstActive = false; return; }
      if (this.presentSurface) {
        this._blitRetained();
        this.lastPresentMode = 'burst';
      } else {
        this.presentFull();
      }
      remaining -= 1;
      if (remaining > 0) { requestAnimationFrame(step); return; }
      if (this._presentBurstExtra > 0) {
        remaining = this._presentBurstExtra;
        this._presentBurstExtra = 0;
        requestAnimationFrame(step);
        return;
      }
      this._presentBurstActive = false;
    };
    requestAnimationFrame(step);
  }

  _cancelPresentBurst() {
    this._presentBurstActive = false;
    this._presentBurstExtra = 0;
  }

  // ---------- T63：结构操作 undo（与笔触同一 Undo 栈） ----------
  _snapshotImages(store) {
    const out = {};
    for (const [layerId, map] of store.layers.entries()) {
      const tiles = {};
      for (const [key, tile] of map.entries()) tiles[key] = tile.image;
      if (Object.keys(tiles).length) out[layerId] = tiles;
    }
    return out;
  }

  _snapshotStructure() {
    return { doc: this.getDoc(), tiles: this._snapshotImages(this.store), masks: this._snapshotImages(this.maskStore) };
  }

  /** 还原结构快照：detach 当前 store（不 delete 旧 image，避免历史 undo 悬空引用；M4.5 引用计数） */
  _restoreStructure(snapshot) {
    this._detachStore(this.store);
    this._detachStore(this.maskStore);
    const d = normalizeDoc(snapshot.doc);
    this.doc = d;
    this.layers = d.layers;
    this.groups = d.groups;
    this.activeLayerId = d.activeLayerId;
    for (const [layerId, tiles] of Object.entries(snapshot.tiles || {})) {
      for (const [key, img] of Object.entries(tiles)) this.store.applyImage(layerId, key, img);
    }
    for (const [layerId, tiles] of Object.entries(snapshot.masks || {})) {
      for (const [key, img] of Object.entries(tiles)) this.maskStore.applyImage(layerId, key, img);
    }
    this.compositor.setLayers(this.layers);
    this.presentFull();
  }

  _detachStore(store) {
    // 只清引用，不 delete image/surface：tile patch / 结构快照可能仍引用这些 image。
    // 共享空白 tile（surface=null）不进回收队列：blankImage() 是跨 tile/跨层复用的单例，
    // 一旦被回收 delete，后续 putBlank() 会拿到失效指针。
    for (const map of store.layers.values()) {
      for (const tile of map.values()) if (tile.surface) this._detachedImages.push(tile.image);
      map.clear();
    }
    store.layers.clear();
  }

  _withStructureUndo(fn) {
    if (!this._ready) return fn();
    this._cancelPresentBurst();
    const before = this._snapshotStructure();
    const result = fn();
    const after = this._snapshotStructure();
    this.undoManager.push({ kind: 'structure', before, after });
    this.presentFull();
    this._schedulePresentBurst(2);
    return result;
  }

  deleteLayer(id) {
    return this._withStructureUndo(() => {
      const idx = this.layers.findIndex((l) => l.id === id);
      if (idx < 0) return false;
      this._detachStoreLayer(this.store, id);
      this._detachStoreLayer(this.maskStore, id);
      this.layers.splice(idx, 1);
      if (this.activeLayerId === id) {
        this.activeLayerId = this.layers.length ? this.layers[this.layers.length - 1].id : null;
        if (this.doc) this.doc.activeLayerId = this.activeLayerId; // P2-1
      }
      this.compositor.setLayers(this.layers);
      return true;
    });
  }

  duplicateLayer(id) {
    return this._withStructureUndo(() => {
      const src = this.layers.find((l) => l.id === id);
      if (!src) return null;
      const copy = createLayer({ ...src, id: `layer-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`, name: `${src.name} 副本`, mask: { ...src.mask } });
      const idx = this.layers.findIndex((l) => l.id === id);
      this.layers.splice(idx + 1, 0, copy);
      this.activeLayerId = copy.id;
      const img = this._renderLayerImage(id);
      this._replaceStoreFromImage(this.store, copy.id, img);
      img.delete();
      if (src.mask && src.mask.exists) {
        const mimg = this._renderStoreLayerImage(this.maskStore, id);
        if (mimg) { this._replaceStoreFromImage(this.maskStore, copy.id, mimg); mimg.delete(); }
        copy.mask = { exists: true, enabled: src.mask.enabled !== false };
      }
      this.compositor.setLayers(this.layers);
      return copy;
    });
  }

  moveLayer(id, dir) {
    return this._withStructureUndo(() => {
      const idx = this.layers.findIndex((l) => l.id === id);
      const target = idx + dir;
      if (idx < 0 || target < 0 || target >= this.layers.length) return false;
      [this.layers[idx], this.layers[target]] = [this.layers[target], this.layers[idx]];
      this.compositor.setLayers(this.layers);
      return true;
    });
  }

  moveToGroup(layerId, groupId) {
    return this._withStructureUndo(() => {
      const layer = this.layers.find((l) => l.id === layerId);
      if (!layer) return false;
      if (groupId && !this.groups.some((g) => g.id === groupId)) return false;
      layer.group = groupId || null;
      return true;
    });
  }

  mergeDown(id) {
    return this._withStructureUndo(() => {
      const idx = this.layers.findIndex((l) => l.id === id);
      if (idx <= 0) return false;
      const upper = this.layers[idx];
      const lower = this.layers[idx - 1];
      const lowerImg = this._renderLayerImage(lower.id);
      const upperImg = this._renderLayerImage(upper.id);
      const CK = this.CK;
      const surface = CK.MakeRenderTarget(this.gr, this.width, this.height);
      const c = surface.getCanvas();
      c.clear(CK.TRANSPARENT);
      c.drawImage(lowerImg, 0, 0);
      c.drawImage(upperImg, 0, 0);
      surface.flush();
      const merged = surface.makeImageSnapshot();
      surface.delete();
      lowerImg.delete(); upperImg.delete();
      this._replaceStoreFromImage(this.store, lower.id, merged);
      merged.delete();
      this._detachStoreLayer(this.store, upper.id);
      this._detachStoreLayer(this.maskStore, upper.id);
      this.layers.splice(idx, 1);
      if (this.activeLayerId === upper.id) this.activeLayerId = lower.id;
      this.compositor.setLayers(this.layers);
      return true;
    });
  }

  flattenAll() {
    return this._withStructureUndo(() => {
      const img = this._renderDocImage();
      this._detachStore(this.store);
      this._detachStore(this.maskStore);
      const layer = createLayer({ id: `layer-${Date.now().toString(36)}`, name: '拼合图层' });
      this.doc = createDoc({ width: this.width, height: this.height, layers: [layer], groups: [], activeLayerId: layer.id });
      this.layers = this.doc.layers;
      this.groups = this.doc.groups;
      this.activeLayerId = layer.id;
      this.compositor.setLayers(this.layers);
      this._replaceStoreFromImage(this.store, layer.id, img);
      img.delete();
      return layer;
    });
  }

  /** T62 反馈：按 bbox 快照图层（供涂抹/变换等，避免整画布复制） */
  snapshotRegion(layerId, bbox) { return this.store.snapshotRegion(layerId, bbox); }

  // ---------- T63：选区 ----------
  setSelectionImage(img) { this.selectionImage = img || null; return this.selectionImage; }
  getSelectionImage() { return this.selectionImage; }
  clearSelection() { this.selectionImage = null; }
  hasSelection() { return !!this.selectionImage; }

  _alphaLockPatch(layerId, patch) {
    if (!patch || !patch.after || !patch.before) return patch;
    const tile = this.store.get(layerId || patch.layerId, patch.key);
    if (!tile) return patch;
    const c = tile.surface.getCanvas();
    const paint = new this.CK.Paint();
    paint.setBlendMode(this.CK.BlendMode.DstIn);
    c.drawImage(patch.before, 0, 0, paint); // 用笔触前 alpha 裁掉新增透明区域
    paint.delete();
    tile.surface.flush();
    tile.image = tile.surface.makeImageSnapshot();
    return { ...patch, after: tile.image };
  }

  /** T65：显式释放历史/结构快照中不再被当前 tile 引用的 image（引用计数前的兜底） */
  releaseHistorySnapshots() {
    const live = new Set();
    for (const store of [this.store, this.maskStore]) {
      for (const map of store.layers.values()) for (const tile of map.values()) live.add(tile.image);
    }
    const seen = new Set();
    const collect = (entry) => {
      if (!entry || seen.has(entry)) return;
      seen.add(entry);
      if (entry.kind === 'structure') {
        for (const side of ['before', 'after']) {
          const snap = entry[side];
          if (!snap) continue;
          for (const tiles of [snap.tiles, snap.masks]) {
            if (!tiles) continue;
            for (const t of Object.values(tiles)) for (const img of Object.values(t)) if (img) seen.add(img);
          }
        }
      } else if (entry.kind === 'image') {
        if (entry.before) seen.add(entry.before);
        if (entry.after) seen.add(entry.after);
      } else if (entry.patches) {
        for (const pt of entry.patches) { if (pt.before) seen.add(pt.before); if (pt.after) seen.add(pt.after); }
      }
    };
    for (const e of [...this.undoManager.undoStack, ...this.undoManager.redoStack]) collect(e);
    for (const img of seen) { if (!live.has(img) && !this._isSharedImage(img)) { try { img.delete(); } catch (err) { /* ignore */ } } }
    for (const img of this._detachedImages) { if (!live.has(img) && !this._isSharedImage(img)) { try { img.delete(); } catch (err) { /* ignore */ } } }
    this._detachedImages.length = 0;
    this.undoManager.clear();
    return true;
  }

  _maskPatch(patch) {
    if (!this.selectionImage || !patch || !patch.after) return patch;
    const CK = this.CK;
    const surface = CK.MakeRenderTarget(this.gr, TILE, TILE);
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    c.drawImage(patch.after, 0, 0);
    const [tx, ty] = patch.key.split(',').map(Number);
    const p = new CK.Paint();
    p.setBlendMode(CK.BlendMode.DstIn);
    c.drawImage(this.selectionImage, -tx * TILE, -ty * TILE, p);
    p.delete();
    surface.flush();
    const after = surface.makeImageSnapshot();
    surface.delete();
    return { ...patch, after };
  }

  // ---------- T63：变换（预览非破坏；提交 1 步 undo） ----------
  beginTransform(layerId, opts = {}) {
    if (this._transform) this.cancelTransform();
    if (!this.layers.some((l) => l.id === layerId)) return null;
    const before = this._renderLayerImage(layerId);
    const bb = opts && opts.bounds;
    const base = bb && bb.width > 0 && bb.height > 0
      ? { cx: bb.x + bb.width / 2, cy: bb.y + bb.height / 2, w: bb.width, h: bb.height }
      : { cx: this.width / 2, cy: this.height / 2, w: this.width, h: this.height };
    this._transform = {
      layerId, before, base,
      x: 0, y: 0, scaleX: 1, scaleY: 1, rotate: 0, flipH: false, flipV: false,
      useSelection: this.hasSelection(),
    };
    return this._transform;
  }

  updateTransform(patch) { if (this._transform) Object.assign(this._transform, patch || {}); return this._transform; }

  /** 数值变换：按目标矩形（左上角 x/y + 宽高，文档坐标）+ 旋转角设置变换 */
  setTransformBounds(b = {}) {
    const t = this._transform;
    if (!t) return null;
    const base = t.base || { cx: this.width / 2, cy: this.height / 2, w: this.width, h: this.height };
    const hasRect = Number.isFinite(b.x) && Number.isFinite(b.y) && Number.isFinite(b.width) && Number.isFinite(b.height);
    if (hasRect) {
      const w = Math.max(1, b.width), h = Math.max(1, b.height);
      t.x = (b.x + w / 2) - base.cx;
      t.y = (b.y + h / 2) - base.cy;
      t.scaleX = Math.max(0.05, w / base.w);
      t.scaleY = Math.max(0.05, h / base.h);
    }
    if (Number.isFinite(b.rotate)) t.rotate = b.rotate;
    return this.getTransformBounds();
  }

  cancelTransform() {
    if (!this._transform) return false;
    try { this._transform.before.delete(); } catch (e) { /* ignore */ }
    this._transform = null;
    return true;
  }

  commitTransform() {
    const t = this._transform;
    if (!t) return null;
    const after = this._renderTransformed(t);
    this._replaceLayerFromImage(t.layerId, after);
    this.undoManager.push({ kind: 'image', layerId: t.layerId, before: t.before, after });
    this._transform = null;
    this.presentFull();
    this._schedulePresentBurst(3);
    return after;
  }

  getTransformBounds() {
    const t = this._transform;
    if (!t) return null;
    const base = t.base || { cx: this.width / 2, cy: this.height / 2, w: this.width, h: this.height };
    return {
      cx: base.cx + (t.x || 0), cy: base.cy + (t.y || 0),
      w: base.w * (t.scaleX == null ? 1 : t.scaleX),
      h: base.h * (t.scaleY == null ? 1 : t.scaleY),
      rotate: t.rotate || 0,
    };
  }

  getTransformHandles() {
    const b = this.getTransformBounds();
    if (!b) return null;
    const rad = ((b.rotate || 0) * Math.PI) / 180;
    const local = [['nw', -0.5, -0.5], ['n', 0, -0.5], ['ne', 0.5, -0.5], ['e', 0.5, 0], ['se', 0.5, 0.5], ['s', 0, 0.5], ['sw', -0.5, 0.5], ['w', -0.5, 0], ['rotate', 0, -0.75]];
    const handles = local.map(([id, ux, uy]) => {
      const lx = ux * b.w, ly = uy * b.h;
      return { id, x: b.cx + lx * Math.cos(rad) - ly * Math.sin(rad), y: b.cy + lx * Math.sin(rad) + ly * Math.cos(rad) };
    });
    return { handles, bounds: b };
  }

  dragTransformHandle(handleId, x, y, opts = {}) {
    const t = this._transform;
    if (!t) return null;
    const b = this.getTransformBounds();
    if (handleId === 'rotate') {
      let deg = (Math.atan2(y - b.cy, x - b.cx) * 180) / Math.PI + 90;
      if (opts.snap !== false) deg = Math.round(deg / 15) * 15; // Shift 15° 吸附（默认开启由 app 传 snap）
      t.rotate = deg;
      return t;
    }
    const affectsX = /e|w/.test(handleId) || handleId.length === 2;
    const affectsY = /n|s/.test(handleId) || handleId.length === 2;
    const base = t.base || { cx: this.width / 2, cy: this.height / 2, w: this.width, h: this.height };
    const sx = affectsX ? Math.abs((x - b.cx) / ((base.w / 2) || 1)) : Math.abs(t.scaleX || 1);
    const sy = affectsY ? Math.abs((y - b.cy) / ((base.h / 2) || 1)) : Math.abs(t.scaleY || 1);
    t.scaleX = Math.max(0.05, sx);
    t.scaleY = Math.max(0.05, sy);
    return t;
  }

  /** 生成独立 Image（encode→decode 复制，避免 surface.delete 后懒快照失效） */
  _kitImageFromSurface(surface) {
    surface.flush();
    const snap = surface.makeImageSnapshot();
    const raw = snap.encodeToBytes();
    const copy = new Uint8Array(raw.length);
    copy.set(raw);
    try { snap.delete(); } catch (e) { /* ignore */ }
    try { surface.delete(); } catch (e) { /* ignore */ }
    return this.CK.MakeImageFromEncoded(copy);
  }

  _renderLayerImage(layerId) {
    const CK = this.CK;
    const surface = CK.MakeRenderTarget(this.gr, this.width, this.height);
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    const layer = this.layers.find((l) => l.id === layerId);
    if (layer) this.compositor.drawLayerFull(c, layer, this.layers, this.store, this.maskStore, null);
    return this._kitImageFromSurface(surface);
  }

  /** T117 P1-3：拍「未应用蒙版」的原始像素快照。
   *  _renderLayerImage 经 compositor.drawLayerFull 会把当时的 mask 烘焙进图像，
   *  用它做 undo before/after 会让撤销后只剩旧选区内的像素。
   *  本方法只读 tile store，不经过合成器，保证 undo/redo 恢复完整图层像素。 */
  _renderLayerImageRaw(layerId) {
    return this._renderStoreLayerImage(this.store, layerId);
  }

  /** 图层内容包围盒（用于变换框贴合图片，而不是整张画布）；无内容返回 null */
  getLayerContentBounds(layerId) {
    const CK = this.CK;
    const img = this._renderLayerImage(layerId);
    try {
      const info = { width: this.width, height: this.height, colorType: CK.ColorType.RGBA_8888, alphaType: CK.AlphaType.Unpremul, colorSpace: CK.ColorSpace.SRGB };
      const px = img.readPixels(0, 0, info);
      if (!px) return null;
      let x0 = this.width, y0 = this.height, x1 = -1, y1 = -1;
      for (let y = 0; y < this.height; y += 1) {
        const row = y * this.width * 4;
        for (let x = 0; x < this.width; x += 1) {
          const a = px[row + x * 4 + 3];
          if (a > 8) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
        }
      }
      if (x1 < x0 || y1 < y0) return null;
      return { x: x0, y: y0, width: x1 - x0 + 1, height: y1 - y0 + 1 };
    } finally { try { img.delete(); } catch (e) { /* ignore */ } }
  }

  /** 导出单图层 PNG dataURL（复制选区用；不拍平其他图层） */
  getLayerDataUrl(layerId) {
    const img = this._renderLayerImage(layerId);
    let bytes = null;
    try { bytes = img.encodeToBytes(); } finally { try { img.delete(); } catch (e) { /* ignore */ } }
    return new Promise((resolve, reject) => {
      try {
        const blob = new Blob([bytes], { type: 'image/png' });
        const fr = new FileReader();
        fr.onload = () => resolve(String(fr.result || ''));
        fr.onerror = () => reject(fr.error || new Error('PNG 编码失败'));
        fr.readAsDataURL(blob);
      } catch (e) { reject(e); }
    });
  }

  /** 在指定图层清除一块矩形（剪切/删除选区内容），一步 undo */
  eraseRect(layerId, x, y, w, h) {
    if (!this.layers.some((l) => l.id === layerId)) return false;
    const CK = this.CK;
    const before = this._renderLayerImage(layerId);
    const surface = CK.MakeRenderTarget(this.gr, this.width, this.height);
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    c.drawImage(before, 0, 0);
    c.save();
    const l = Math.max(0, Math.floor(x)), t = Math.max(0, Math.floor(y));
    const r = Math.min(this.width, Math.ceil(x + w)), b = Math.min(this.height, Math.ceil(y + h));
    c.clipRect([l, t, r, b], CK.ClipOp.Intersect, true);
    c.clear(CK.TRANSPARENT);
    c.restore();
    const after = this._kitImageFromSurface(surface);
    this._replaceLayerFromImage(layerId, after);
    this.undoManager.push({ kind: 'image', layerId, before, after });
    this.presentFull();
    this._schedulePresentBurst(3);
    return true;
  }

  _renderStoreLayerImage(store, layerId) {
    const CK = this.CK;
    const surface = CK.MakeRenderTarget(this.gr, this.width, this.height);
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    for (const key of store.listTiles(layerId)) {
      const tile = store.get(layerId, key);
      if (!tile) continue;
      const [tx, ty] = key.split(',').map(Number);
      c.drawImage(tile.image, tx * TILE, ty * TILE);
    }
    return this._kitImageFromSurface(surface);
  }

  _renderDocImage() {
    const CK = this.CK;
    const surface = CK.MakeRenderTarget(this.gr, this.width, this.height);
    const c = surface.getCanvas();
    this.compositor.drawDocument(c, this.doc, this.store, this.maskStore, {});
    return this._kitImageFromSurface(surface);
  }

  _detachStoreLayer(store, layerId) {
    const map = store.layers.get(layerId);
    if (!map) return;
    // 共享空白 tile 不进回收队列（见 _detachStore 注释）
    for (const tile of map.values()) if (tile.surface) this._detachedImages.push(tile.image);
    map.clear();
    store.layers.delete(layerId);
  }

  // ---------- T117 P1-2：把 mask 状态纳入 image undo 事务 ----------
  /** 快照为逐 tile PNG 字节（纯 JS 数据），不持有任何 CanvasKit Image 引用。
   *  原因：引擎有历史 Image 引用计数回收，裸 Image 引用会被 delete，
   *  undo 时触发 "Cannot pass deleted object" BindingError。
   *  共享空白 tile 只记 key，还原时重新 putBlank，避免 4096² 下无谓的 200+ 次解码。 */
  captureMaskState(layerId) {
    const layer = this.layers.find((l) => l.id === layerId);
    const exists = !!(layer && layer.mask && layer.mask.exists);
    const enabled = layer && layer.mask ? layer.mask.enabled !== false : true;
    const tiles = {};
    const blankKeys = [];
    const map = this.maskStore.layers.get(layerId);
    if (map) {
      for (const [key, tile] of map.entries()) {
        if (!tile || !tile.image) continue;
        if (!tile.surface) { blankKeys.push(key); continue; }
        try {
          const raw = tile.image.encodeToBytes();
          const copy = new Uint8Array(raw.length);
          copy.set(raw);
          tiles[key] = copy;
        } catch (e) { blankKeys.push(key); }
      }
    }
    return { exists, enabled, tiles, blankKeys };
  }
  restoreMaskState(layerId, state) {
    if (!state) return false;
    this._dropStoreLayer(this.maskStore, layerId);
    const layer = this.layers.find((l) => l.id === layerId);
    if (layer) layer.mask = { exists: !!state.exists, enabled: state.enabled !== false };
    for (const key of (state.blankKeys || [])) this.maskStore.ensureTile(layerId, key);
    for (const [key, png] of Object.entries(state.tiles || {})) {
      if (!png || !png.length) continue;
      const img = this.CK.MakeImageFromEncoded(png);
      if (!img) continue;
      this.maskStore.applyImage(layerId, key, img);
      try { img.delete(); } catch (e) { /* ignore */ }
    }
    return true;
  }
  /** 在 app 层写完 mask 后调用：把 maskBefore/maskAfter 追加到栈顶 image undo 条目 */
  commitMaskChangeToLastUndo(layerId, maskBefore) {
    const stack = this.undoManager && this.undoManager.undoStack;
    if (!Array.isArray(stack) || !stack.length) return false;
    const e = stack[stack.length - 1];
    if (!e || e.kind !== 'image' || e.layerId !== layerId) return false;
    e.maskBefore = maskBefore || null;
    e.maskAfter = this.captureMaskState(layerId);
    return true;
  }
  /** T117 P1-4：新建图层时 _withStructureUndo 在像素/kind/mask 写入前就拍了 after 快照，
   *  导致 undo→redo 恢复到空 raster 层。写入完成后调用本方法刷新栈顶结构快照。 */
  refreshTrailingStructureSnapshot() {
    const stack = this.undoManager && this.undoManager.undoStack;
    if (!Array.isArray(stack) || !stack.length) return false;
    const e = stack[stack.length - 1];
    if (!e || e.kind !== 'structure') return false;
    e.after = this._snapshotStructure();
    return true;
  }

  _replaceStoreFromImage(store, layerId, image) {
    const CK = this.CK;
    this._detachStoreLayer(store, layerId);
    const map = store.ensureLayer(layerId);
    for (let ty = 0; ty < store.tilesH; ty += 1) {
      for (let tx = 0; tx < store.tilesW; tx += 1) {
        const surface = CK.MakeRenderTarget(this.gr, TILE, TILE);
        const c = surface.getCanvas();
        c.clear(CK.TRANSPARENT);
        c.drawImage(image, -tx * TILE, -ty * TILE);
        surface.flush();
        map.set(`${tx},${ty}`, { surface, image: surface.makeImageSnapshot() });
      }
    }
  }

  _replaceLayerFromImage(layerId, image) {
    this._replaceStoreFromImage(this.store, layerId, image);
    this.presentFull();
  }

  /** 用 dataURL 替换某图层内容（文字二次编辑等），一步 undo */
  async replaceLayerFromDataUrl(layerId, dataUrl) {
    return this.replaceLayerFromDataUrlWithInfo(layerId, dataUrl, null);
  }

  /** 替换像素并把 kind/adjust/text 作为同一 undo 条目原子回滚 */
  async replaceLayerFromDataUrlWithInfo(layerId, dataUrl, info = {}) {
    const layer = this.layers.find((l) => l.id === layerId);
    if (!layer) return false;
    info = info && typeof info === 'object' ? info : {};
    const b64 = String(dataUrl || '').split(',')[1];
    if (!b64) throw new Error('replaceLayerFromDataUrlWithInfo: 非法 dataURL');
    const bytes = Uint8Array.from(atob(b64), (ch) => ch.charCodeAt(0));
    const img = this.CK.MakeImageFromEncoded(bytes);
    if (!img) throw new Error('replaceLayerFromDataUrlWithInfo: 图片解码失败');
    // T117 P1-3：用 raw 像素快照（不经过合成器/不应用 mask），避免旧 mask 被烘焙进 undo 快照。
    const before = this._renderLayerImageRaw(layerId);
    const infoBefore = this.getLayerInfo(layerId);
    this._replaceLayerFromImage(layerId, img);
    this.setLayerInfo(layerId, info);
    const after = this._renderLayerImageRaw(layerId);
    const infoAfter = this.getLayerInfo(layerId);
    this.undoManager.push({ kind: 'image', layerId, before, after, infoBefore, infoAfter });
    try { img.delete(); } catch (e) { /* ignore */ }
    this.presentFull();
    this._schedulePresentBurst(3);
    return true;
  }

  _applyLayerInfoSnapshot(layerId, info) {
    if (!info) return;
    const layer = this.layers.find((l) => l.id === layerId);
    if (!layer) return;
    if (info.kind) layer.kind = info.kind;
    layer.adjust = info.adjust ? JSON.parse(JSON.stringify(info.adjust)) : null;
    layer.text = info.text ? JSON.parse(JSON.stringify(info.text)) : null;
  }

  _extractSelected(before) {
    const CK = this.CK;
    const surface = CK.MakeRenderTarget(this.gr, this.width, this.height);
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    c.drawImage(before, 0, 0);
    const p = new CK.Paint();
    p.setBlendMode(CK.BlendMode.DstIn);
    c.drawImage(this.selectionImage, 0, 0, p);
    p.delete();
    return this._kitImageFromSurface(surface);
  }

  _renderTransformed(t) {
    const CK = this.CK;
    const base = t.base || { cx: this.width / 2, cy: this.height / 2, w: this.width, h: this.height };
    const surface = CK.MakeRenderTarget(this.gr, this.width, this.height);
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    const src = t.useSelection && this.hasSelection() ? this._extractSelected(t.before) : t.before;
    c.save();
    c.translate(base.cx + (t.x || 0), base.cy + (t.y || 0));
    c.rotate(t.rotate || 0, 0, 0); // CanvasKit: rotate(degrees, cx, cy)
    c.scale((t.scaleX == null ? 1 : t.scaleX) * (t.flipH ? -1 : 1), (t.scaleY == null ? 1 : t.scaleY) * (t.flipV ? -1 : 1));
    c.drawImage(src, -base.cx, -base.cy);
    c.restore();
    if (t.useSelection && this.hasSelection()) {
      const base = CK.MakeRenderTarget(this.gr, this.width, this.height);
      const bc = base.getCanvas();
      bc.clear(CK.TRANSPARENT);
      bc.drawImage(t.before, 0, 0);
      const cut = new CK.Paint();
      cut.setBlendMode(CK.BlendMode.DstOut);
      bc.drawImage(this.selectionImage, 0, 0, cut);
      cut.delete();
      const final = CK.MakeRenderTarget(this.gr, this.width, this.height);
      const fc = final.getCanvas();
      fc.clear(CK.TRANSPARENT);
      const baseImg = this._kitImageFromSurface(base);
      fc.drawImage(baseImg, 0, 0);
      baseImg.delete();
      const surfImg = this._kitImageFromSurface(surface);
      fc.drawImage(surfImg, 0, 0);
      surfImg.delete();
      const out = this._kitImageFromSurface(final);
      if (src !== t.before) { try { src.delete(); } catch (e) { /* ignore */ } }
      return out;
    }
    const img = this._kitImageFromSurface(surface);
    if (src !== t.before) { try { src.delete(); } catch (e) { /* ignore */ } }
    return img;
  }

  // ---------- 帧/输出 ----------
  requestFrame() {
    if (this.flushScheduled) return;
    this.flushScheduled = true;
    requestAnimationFrame(() => {
      this.flushScheduled = false;
      if (!this.currentStroke) return;
      try { this._renderLiveFrame(); } catch (e) { /* ignore */ }
    });
  }

  async getCompositeDataUrl() {
    // T44：离屏全量合成（含 live），避免 on-screen framebuffer snapshot 不稳定
    const surface = this.CK.MakeRenderTarget(this.gr, this.width, this.height);
    const c = surface.getCanvas();
    const liveImg = this._drawComposite(c, !!(this.currentStroke || this.currentMaskStroke));
    surface.flush();
    const img = surface.makeImageSnapshot();
    const bytes = img.encodeToBytes();
    try { img.delete(); } catch (e) { /* ignore */ }
    try { surface.delete(); } catch (e) { /* ignore */ }
    if (liveImg) { try { liveImg.delete(); } catch (e) { /* ignore */ } }
    if (!bytes) throw new Error('snapshot 编码失败');
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return `data:image/png;base64,${btoa(binary)}`;
  }

  // ---------- T76：异步导出（Worker + 分块；不改同步默认路径） ----------
  _getExportWorker() {
    if (this._exportWorker) return this._exportWorker;
    if (typeof Worker === 'undefined' || typeof OffscreenCanvas === 'undefined') return null;
    try {
      const url = new URL('./export-worker.js', import.meta.url);
      const worker = new Worker(url, { type: 'module' });
      worker.onmessage = (ev) => {
        const job = this._exportJob;
        if (!job) return;
        const m = ev.data || {};
        if (m.type === 'progress') {
          try { job.onProgress && job.onProgress({ phase: 'encode', done: m.done, total: m.total }); } catch (e) { /* ignore */ }
        } else if (m.type === 'ready') {
          try { job.onProgress && job.onProgress({ phase: 'ready', done: 0, total: job.totalTiles }); } catch (e) { /* ignore */ }
        } else if (m.type === 'done') {
          job.resolve(m.blob);
          this._exportJob = null;
        } else if (m.type === 'error') {
          job.reject(new Error('导出 Worker 失败: ' + m.message));
          this._exportJob = null;
        }
      };
      worker.onerror = (e) => {
        const job = this._exportJob;
        if (job) { job.reject(new Error('导出 Worker 错误: ' + ((e && e.message) || 'unknown'))); this._exportJob = null; }
      };
      this._exportWorker = worker;
      return worker;
    } catch (e) {
      this._exportWorker = null;
      return null;
    }
  }

  /** T76：预热导出管线（Worker/OffscreenCanvas/GPU readback/PNG 编码）。
   *  建议 app 在启动空闲时调用一次：之后用户导出不会出现首次 ~80–190ms 长任务；
   *  未预热时首次导出仍正确，仅包含一次暖机长任务。 */
  async warmUpExportAsync(opts = {}) {
    if (!this._ready || this._exportWarmed) return false;
    try {
      await this.exportPNGAsync({ tileSize: opts.tileSize || 128, onProgress: opts.onProgress });
      this._exportWarmed = true;
      return true;
    } catch (e) {
      return false;
    }
  }

  /** 取消进行中的异步导出 */
  cancelExport() {
    const job = this._exportJob;
    if (!job) return false;
    job.cancelled = true;
    this._exportJob = null;
    try { if (this._exportWorker) { this._exportWorker.terminate(); this._exportWorker = null; } } catch (e) { /* ignore */ }
    try { job.reject(Object.assign(new Error('导出已取消'), { name: 'AbortError' })); } catch (e) { /* ignore */ }
    return true;
  }

  _releaseExportWorker() {
    try { if (this._exportWorker) this._exportWorker.terminate(); } catch (e) { /* ignore */ }
    this._exportWorker = null;
  }

  /**
   * T76：分块异步导出 PNG（主线程只做 tile readPixels，编码在 Worker；每 tile yield）。
   * @param {{onProgress?:Function, tileSize?:number, signal?:AbortSignal}} opts
   * @returns {Promise<Blob>}
   */
  async exportPNGAsync(opts = {}) {
    if (!this._ready) throw new Error('engine 未初始化');
    if (this._exportJob) throw new Error('已有导出任务进行中');
    const token = {
      cancelled: false,
      onProgress: typeof opts.onProgress === 'function' ? opts.onProgress : null,
      totalTiles: 0,
      resolve: null,
      reject: null,
    };
    const promise = new Promise((resolve, reject) => { token.resolve = resolve; token.reject = reject; });
    promise.catch(() => { /* 取消时避免未处理拒绝；调用方仍会收到 throw */ });
    this._exportJob = token;
    const tStart = performance.now();
    const tileSize = Math.max(128, Math.floor(opts.tileSize || 256));
    const tilesX = Math.ceil(this.width / tileSize);
    const tilesY = Math.ceil(this.height / tileSize);
    token.totalTiles = tilesX * tilesY;
    const CK = this.CK;
    let liveImg = null;
    try {
      const worker = this._getExportWorker();
      if (!worker) {
        // 降级：无 Worker/OffscreenCanvas 时同步路径（仅旧浏览器）
        if (token.onProgress) token.onProgress({ phase: 'fallback', done: 0, total: 1 });
        const url = await this.getCompositeDataUrl();
        const blob = await (await fetch(url)).blob();
        this._exportJob = null;
        return blob;
      }
      const liveInfo = this._liveInfo();
      if (liveInfo) liveImg = this.liveSurface.makeImageSnapshot();
      const live = liveInfo ? { ...liveInfo, image: liveImg } : null;
      const info = {
        width: tileSize, height: tileSize,
        colorType: CK.ColorType.RGBA_8888,
        alphaType: CK.AlphaType.Unpremul,
        colorSpace: CK.ColorSpace.SRGB,
      };
      worker.postMessage({ type: 'init', width: this.width, height: this.height, total: token.totalTiles });
      if (token.onProgress) token.onProgress({ phase: 'read', done: 0, total: token.totalTiles });
      for (let ty = 0; ty < tilesY; ty += 1) {
        for (let tx = 0; tx < tilesX; tx += 1) {
          if (token.cancelled || (opts.signal && opts.signal.aborted)) {
            if (!token.cancelled) this.cancelExport();
            throw Object.assign(new Error('导出已取消'), { name: 'AbortError' });
          }
          const x = tx * tileSize;
          const y = ty * tileSize;
          const w = Math.min(tileSize, this.width - x);
          const h = Math.min(tileSize, this.height - y);
          // 分块合成：每 tile 独立 RenderTarget（避免整幅 GPU readback 长任务）
          const tileSurface = CK.MakeRenderTarget(this.gr, w, h);
          const c = tileSurface.getCanvas();
          c.clear(CK.WHITE);
          c.save();
          c.translate(-x, -y);
          this.compositor.drawDocument(c, this.doc, this.store, this.maskStore, { live });
          c.restore();
          tileSurface.flush();
          const tileImg = tileSurface.makeImageSnapshot();
          const tileInfo = { ...info, width: w, height: h };
          const pixels = tileImg.readPixels(0, 0, tileInfo);
          try { tileImg.delete(); } catch (e) { /* ignore */ }
          try { tileSurface.delete(); } catch (e) { /* ignore */ }
          if (!pixels || !pixels.length) throw new Error(`readPixels 失败 @${x},${y}`);
          const copy = new Uint8Array(pixels.length);
          copy.set(pixels);
          worker.postMessage({ type: 'tile', x, y, width: w, height: h, buffer: copy.buffer }, [copy.buffer]);
          if (token.onProgress) token.onProgress({ phase: 'read', done: ty * tilesX + tx + 1, total: token.totalTiles });
          // 让出一帧，等 GPU 队列完成，避免 readPixels 在单个长任务里阻塞
          await new Promise((r) => requestAnimationFrame(r));
        }
      }
      worker.postMessage({ type: 'finish' });
      const blob = await promise;
      if (token.onProgress) token.onProgress({ phase: 'done', done: token.totalTiles, total: token.totalTiles, ms: Math.round((performance.now() - tStart) * 100) / 100 });
      return blob;
    } catch (e) {
      if (this._exportJob === token) this._exportJob = null;
      throw e;
    } finally {
      if (this._exportJob === token) this._exportJob = null;
      if (liveImg) { try { liveImg.delete(); } catch (e) { /* ignore */ } }
    }
  }

  getStats() {
    const byLayer = {};
    for (const l of this.layers) byLayer[l.id] = this.store.count(l.id);
    const wasm = this.CK && this.CK.HEAPU8 ? this.CK.HEAPU8.length : 0;
    const tileBytes = this.store.memoryBytes() + this.maskStore.memoryBytes();
    const historyBytes = this.undoManager.bytes;
    const jsHeap = performance.memory ? performance.memory.usedJSHeapSize : null;
    return {
      width: this.width, height: this.height, tileSize: this.tileSize,
      layers: this.layers.length, groups: this.groups.length, activeLayerId: this.activeLayerId,
      activeTarget: this.activeTarget,
      masks: this.layers.filter((l) => l.mask && l.mask.exists).length,
      groupMasks: this.groups.filter((g) => g.mask && g.mask.exists).length,
      tileCount: this.store.allKeys().length + this.maskStore.allKeys().length,
      tilesByLayer: byLayer,
      brushProvider: this.brushProvider && this.brushProvider.id ? this.brushProvider.id : 'custom',
      undoDepth: this.undoManager.depth(), redoDepth: this.undoManager.redoDepth(),
      historyBytes,
      memoryEstimateMB: Math.round((tileBytes + historyBytes + wasm + (this.presentSurface ? this.width * this.height * 4 : 0)) / 1048576 * 10) / 10,
      jsHeapMB: jsHeap == null ? null : Math.round(jsHeap / 1048576 * 10) / 10,
      gpuRenderer: this._gpuRenderer || (this._gpuRenderer = readGpu(this.canvas || this.opts.canvas)),
      lastCompositeMs: this.lastCompositeMs,
      lastPresentMode: this.lastPresentMode,
      lastBlitMs: this.lastBlitMs,
      inputSmoothing: this.inputSmoothing,
      presentSurfaceMB: this.presentSurface ? Math.round(this.width * this.height * 4 / 1048576 * 10) / 10 : 0,
    };
  }

  // ---------- 简易 benchmark（复用 bench 指标口径） ----------
  async runBench(opts = {}) {
    const durationMs = opts.durationMs || 3000;
    const eventHz = opts.eventHz || 120;
    const frames = [], latencies = [];
    let pending = [];
    const w = this.width, h = this.height;
    let f = 0;
    const start = performance.now();
    const loopStart = start;
    this.beginStroke({ x: w * 0.1, y: h * 0.5, pressure: 0.5, timestamp: start, pointerType: 'synthetic' });
    let lastTs = start;
    while (performance.now() - loopStart < durationMs) {
      const ft = await raf();
      frames.push(ft - lastTs); lastTs = ft;
      for (const item of pending.splice(0)) latencies.push(ft - item.ts);
      const t = Math.min(1, (performance.now() - loopStart) / durationMs);
      const p = {
        x: w * (0.1 + 0.8 * t),
        y: h * (0.5 + 0.25 * Math.sin(t * Math.PI * 4)),
        pressure: 0.35 + 0.6 * Math.abs(Math.sin(t * Math.PI * 3)),
        timestamp: performance.now(), pointerType: 'synthetic',
      };
      this.appendPoint(p, { flush: false });
      pending.push({ ts: p.timestamp });
      f += 1;
    }
    this.endStroke();
    const endTs = await raf();
    for (const item of pending.splice(0)) latencies.push(endTs - item.ts);

    const undoStart = performance.now();
    let undos = 0;
    while (this.canUndo() && undos < 80) { this.undo(); undos += 1; }
    const undoMs = performance.now() - undoStart;

    const stat = (arr) => {
      const a = arr.slice().sort((x, y) => x - y);
      const q = (p) => a.length ? a[Math.min(a.length - 1, Math.floor((a.length - 1) * p))] : null;
      return { p50: q(0.5), p95: q(0.95), max: a.length ? a[a.length - 1] : null };
    };
    const lat = stat(latencies);
    const fps = stat(frames.map((ms) => (ms > 0 ? 1000 / ms : 0)));
    const stats = this.getStats();
    const env = {
      ua: navigator.userAgent,
      browser: (navigator.userAgent.match(/Chrome\/[\d.]+/) || [])[0] || '',
      gpuRenderer: stats.gpuRenderer,
      pointerType: 'synthetic',
      headless: /HeadlessChrome/.test(navigator.userAgent),
      hardware: { hasPressureHardware: false, note: '鼠标/无压感硬件；延迟为帧提交代理' },
    };
    return {
      schema: 'mozheng.bench.v1',
      createdAt: new Date().toISOString(),
      adapter: { id: 'v2-engine', version: '0.1.0-m4.1', license: 'MIT (自研) + BSD-3 (CanvasKit vendor)' },
      engine: { name: 'v2-engine', notes: 'T35 简易 benchmark；指标口径同 bench/README.md' },
      environment: env,
      cases: [{
        id: 'M4.1-runBench',
        description: `${this.width}²×${this.layers.length} 层，合成笔迹 ${durationMs}ms（事件 ${eventHz}Hz 目标）`,
        config: { canvas: [this.width, this.height], layers: this.layers.length, brush: { ...this.brush } },
        runs: 1,
        samples: { latencyMs: latencies.slice(0, 500), frameMs: frames.slice(0, 500) },
        summary: {
          latencyP50: round2(lat.p50), latencyP95: round2(lat.p95), latencyMax: round2(lat.max),
          fpsP50: round2(fps.p50), fpsP95: round2(fps.p95),
          frames: frames.length, points: f,
          undoSteps: undos, undoTotalMs: round2(undoMs), undoAvgMs: undos ? round2(undoMs / undos) : null,
          tileCount: stats.tileCount, memoryEstimateMB: stats.memoryEstimateMB, lastCompositeMs: stats.lastCompositeMs,
        },
        pass: {
          latency: lat.p50 != null && lat.p50 <= 16 && lat.p95 <= 33,
          fps: fps.p95 != null && fps.p95 >= 55,
        },
      }],
      verdict: { hardFail: [], notes: [
        '延迟为「输入→帧提交」代理指标；144Hz 下 1 帧≈6.9ms。',
        '无压感硬件：压感为程序生成序列，不代表真实手感（P3 待硬件）。',
        '内存为估算（tile surface+image + undo 历史 + WASM 堆），未含 GPU 驱动/缓存。',
      ] },
    };
  }

  dispose() {
    this.cancelStroke();
    try { this.cancelExport(); } catch (e) { /* ignore */ }
    try { this.cancelSave(); } catch (e) { /* ignore */ }
    try { this.cancelPSDExport(); } catch (e) { /* ignore */ }
    this._releaseExportWorker();
    try { this.releaseHistorySnapshots(); } catch (e) { /* ignore */ }
    try { this._maskBlackPaint && this._maskBlackPaint.delete(); } catch (e) { /* ignore */ }
    try { this._liveEraserPaint && this._liveEraserPaint.delete(); } catch (e) { /* ignore */ }
    try { this.liveSurface && this.liveSurface.delete(); } catch (e) { /* ignore */ }
    this.liveSurface = null;
    this.liveCanvas = null;
    try { this.presentSurface && this.presentSurface.delete(); } catch (e) { /* ignore */ }
    this.presentSurface = null;
    this.presentCanvas = null;
    if (this.brushProvider && typeof this.brushProvider.dispose === 'function') {
      try { this.brushProvider.dispose(); } catch (e) { /* ignore */ }
    }
    try { this.compositor.dispose(); } catch (e) { /* ignore */ }
    try { this.store.dispose(); } catch (e) { /* ignore */ }
    try { this.maskStore.dispose(); } catch (e) { /* ignore */ }
    try { this.gr.delete(); } catch (e) { /* ignore */ }
  }
}

function round2(n) { return typeof n === 'number' && Number.isFinite(n) ? Math.round(n * 100) / 100 : null; }

function readGpu(canvas) {
  try {
    const gl = canvas.getContext('webgl2');
    if (!gl) return null;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    return ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
  } catch (e) { return null; }
}

export { TILE };
