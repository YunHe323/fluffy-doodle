// v2/qa/tools/asset-ai-test.mjs — T105-A asset-ai.mjs 单测（零依赖 Node）
// 运行：node v2/qa/tools/asset-ai-test.mjs   （exit 0 = 全过）
import assert from 'node:assert/strict';
import {
  ASSET_AI_VERSION,
  buildAssetKnowledge,
  scoreAssetForQuery,
  rankAssetsForQuery,
  rankAssetsForSelection,
  selectAssetsForBatchRead,
  mergeRealAnalysis,
  summarizeProvenance,
  normalizeText,
} from '../../app/core/asset-ai.mjs';

const results = [];
function test(name, fn) {
  try { fn(); results.push({ name, pass: true }); }
  catch (e) { results.push({ name, pass: false, error: String(e && (e.stack || e.message || e)) }); }
}
const SHA = (c) => c.repeat(64).slice(0, 64);
function mkAsset(id, extra = {}) {
  return {
    id: `asset-${id}`,
    sha256: SHA(id === 'a' ? 'a' : id === 'b' ? 'b' : id === 'c' ? 'c' : 'd'),
    fileName: `${id}.png`, mime: 'image/png', bytes: 1000, width: 800, height: 600,
    createdAt: '2026-11-01T00:00:00.000Z', updatedAt: '2026-11-02T00:00:00.000Z',
    tags: [], palette: [], usageCount: 0,
    L0: { layer: 'L0', source: 'observed', author: 'user', fileName: `${id}.png`, importedAt: '2026-11-01T00:00:00.000Z' },
    L1: { layer: 'L1', source: 'inferred', confidence: 0.6, anchor: { type: 'whole', value: null }, summary: '', subject: [], medium: null, palette: [], mood: [] },
    L2: [], L4: [], L5: [],
    source: ['observed', 'inferred'], modelVersion: 'mock-ai@0.1.0', analysisSource: 'mock',
    projectRefs: [],
    ...extra,
  };
}
const assetA = mkAsset('a', {
  fileName: '雾中山谷.png',
  tags: ['水墨', '雾', '冷灰', '我的标签'],
  palette: ['#7f97a8', '#4f6778'],
  L1: { layer: 'L1', source: 'inferred', confidence: 0.7, anchor: { type: 'whole', value: null }, summary: '冷灰蓝的山谷，雾带穿过远山', subject: ['远山', '雾'], medium: { kind: '水墨' }, palette: ['#7f97a8'], mood: ['安静'] },
  L2: [{ id: 'L2-1', layer: 'L2', source: 'inferred', confidence: 0.7, label: '远山', bbox: [10, 20, 300, 200], importance: 0.8, anchor: { type: 'bbox', value: [10, 20, 300, 200] } }, { id: 'L2-2', layer: 'L2', source: 'inferred', confidence: 0.6, label: '雾带', bbox: [100, 100, 500, 80], importance: 0.7, anchor: { type: 'bbox', value: [100, 100, 500, 80] } }],
  L4: [{ id: 'L4-1', layer: 'L4', kind: 'observation', source: 'inferred', author: 'ai', confidence: 0.7, text: '雾带把视线引向左侧远山', anchor: { type: 'bbox', value: [100, 100, 500, 80] }, evidenceRefs: [], modelVersion: 'mock-ai@0.1.0' }],
  usageCount: 3,
});
const assetB = mkAsset('b', {
  fileName: '暖色庭院.jpg',
  tags: ['暖色', '建筑', '庭院'],
  palette: ['#d08a5a', '#e8c9a0'],
  L1: { layer: 'L1', source: 'inferred', confidence: 0.8, anchor: { type: 'whole', value: null }, summary: '暖橙色的庭院与建筑，午后阳光', subject: ['庭院', '建筑'], medium: { kind: '水彩' }, palette: ['#d08a5a'], mood: ['温暖'] },
  L2: [{ id: 'L2-b1', layer: 'L2', source: 'inferred', confidence: 0.8, label: '屋檐', bbox: [1, 2, 3, 4], importance: 0.6, anchor: { type: 'bbox', value: [1, 2, 3, 4] } }],
  L4: [{ id: 'L4-b1', layer: 'L4', kind: 'observation', source: 'inferred', author: 'ai', confidence: 0.8, text: '暖色来自右上方光斑', anchor: { type: 'bbox', value: [1, 2, 3, 4] }, evidenceRefs: [], modelVersion: 'qwen3.8-max' }],
  modelVersion: 'qwen3.8-max', analysisSource: 'real', analysis: { source: 'real', provider: 'qwen', model: 'qwen3.8-max' },
});
const assetC = mkAsset('c', {
  fileName: '深蓝海面.png',
  tags: ['海', '蓝色', '冷色'],
  palette: ['#2f5d8a', '#1d3550'],
  L1: { layer: 'L1', source: 'inferred', confidence: 0.65, anchor: { type: 'whole', value: null }, summary: '深蓝色海面与远处潮线', subject: ['海面'], medium: { kind: '数字绘画' }, palette: ['#2f5d8a'], mood: ['平静'] },
  L2: [{ id: 'L2-c1', layer: 'L2', source: 'inferred', confidence: 0.6, label: '海面', bbox: [0, 100, 800, 500], importance: 0.9, anchor: { type: 'bbox', value: [0, 100, 800, 500] } }],
  L4: [{ id: 'L4-c1', layer: 'L4', kind: 'observation', source: 'inferred', author: 'ai', confidence: 0.6, text: '海面反光形成一条亮线', anchor: { type: 'bbox', value: [0, 100, 800, 500] }, evidenceRefs: [], modelVersion: 'mock-ai@0.1.0' }],
});
const assetD = mkAsset('d', {
  fileName: '未读素材.png',
  L1: { layer: 'L1', source: 'inferred', confidence: 0.4, anchor: { type: 'whole', value: null }, summary: '', subject: [], medium: null, palette: [], mood: [] },
  modelVersion: null, analysisSource: null, updatedAt: '2026-10-01T00:00:00.000Z',
});
const assets = [assetA, assetB, assetC, assetD];

test('0 模块版本 + 无浏览器全局依赖', () => {
  assert.match(ASSET_AI_VERSION, /^asset-ai@/);
  assert.equal(typeof window, 'undefined');
  assert.equal(typeof document, 'undefined');
  assert.equal(normalizeText('  Ｑwen3.8-max，雾  '), 'qwen3 8 max 雾');
});

test('1 buildAssetKnowledge：精简 L1/L2/L4/来源', () => {
  const k = buildAssetKnowledge(assetA);
  assert.equal(k.fileName, '雾中山谷.png');
  assert.ok(k.summary.includes('雾带'));
  assert.deepEqual(k.subject, ['远山', '雾']);
  assert.deepEqual(k.regionLabels, ['远山', '雾带']);
  assert.ok(k.observationTexts[0].includes('雾带'));
  assert.equal(k.tags.includes('我的标签'), true);
  assert.equal(k.sourceInfo.l0.sha256, assetA.sha256);
  assert.equal(k.analysisSource, 'mock');
  assert.ok(k.searchText.includes('雾带'));
  assert.equal(k.bytes, 1000);
});

test('2 scoreAssetForQuery：中文标签/L1/区域命中 + 无关为 0', () => {
  assert.ok(scoreAssetForQuery(assetA, '雾') > 0.5);
  assert.ok(scoreAssetForQuery(assetA, '远山') > 0.3);
  assert.ok(scoreAssetForQuery(assetA, '雾中山谷') > 0.4);
  assert.equal(scoreAssetForQuery(assetA, '完全不存在xyz'), 0);
  assert.equal(scoreAssetForQuery(assetB, '雾'), 0);
  assert.equal(scoreAssetForQuery(null, '雾'), 0);
});

test('3 中文同义词/模糊：雾气→雾带、山峦→远山', () => {
  assert.ok(scoreAssetForQuery(assetA, '雾气') > 0.3, '雾气应通过同义词命中雾');
  assert.ok(scoreAssetForQuery(assetA, '山峦') > 0.3, '山峦应通过同义词命中远山/山');
  assert.ok(scoreAssetForQuery(assetA, '雾带') > 0.5);
});

test('4 色板：蓝色查询/hex 查询命中冷蓝素材', () => {
  const blue = rankAssetsForQuery(assets, '蓝色', 8);
  assert.equal(blue[0].asset.id, assetC.id);
  assert.ok(blue[0].score > 0);
  const hex = rankAssetsForQuery(assets, '#2f5d8a', 8);
  assert.equal(hex[0].asset.id, assetC.id);
  assert.ok(hex[0].score > 0.2);
  const warm = rankAssetsForQuery(assets, '暖色', 8);
  assert.equal(warm[0].asset.id, assetB.id);
});

test('5 rankAssetsForQuery：排序/limit/不修改资产', () => {
  const before = JSON.stringify(assetA);
  const r = rankAssetsForQuery(assets, '雾', 8);
  assert.ok(r.length >= 1 && r[0].asset.id === assetA.id);
  assert.equal(JSON.stringify(assetA), before);
  const limited = rankAssetsForQuery(assets, '雾', 1);
  assert.equal(limited.length, 1);
  const emptyQuery = rankAssetsForQuery(assets, '', 3);
  assert.equal(emptyQuery.length, 3);
  assert.equal(rankAssetsForQuery([], '雾').length, 0);
  assert.equal(rankAssetsForQuery(assets, '雾', 0).length, 0);
  for (const item of r) assert.ok(Array.isArray(item.reasons));
});

test('6 rankAssetsForSelection：意图+色板+常用权重', () => {
  const r = rankAssetsForSelection(assets, { intent: '雾', palette: ['#7f97a8'], selection: { label: '远山' }, limit: 4 });
  assert.equal(r[0].asset.id, assetA.id);
  assert.ok(r[0].reasons.some((x) => x.includes('意图') || x.includes('色板')));
  const warm = rankAssetsForSelection(assets, { intent: '暖色庭院', palette: ['#d08a5a'], limit: 1 });
  assert.equal(warm.length, 1);
  assert.equal(warm[0].asset.id, assetB.id);
  assert.equal(rankAssetsForSelection([], {}).length, 0);
});

test('7 selectAssetsForBatchRead：mock/未知排队，真实排除，缺 L1 优先', () => {
  const def = selectAssetsForBatchRead(assets);
  const ids = def.map((a) => a.id);
  assert.equal(ids.includes(assetB.id), false, 'real 不应重读');
  assert.ok(ids.includes(assetA.id) && ids.includes(assetC.id) && ids.includes(assetD.id));
  assert.equal(def[0].id, assetD.id, '缺 L1 的优先级最高');
  const onlyMock = selectAssetsForBatchRead(assets, { onlyMock: true });
  assert.deepEqual(onlyMock.map((a) => a.id), [assetA.id, assetC.id]);
  assert.equal(onlyMock.some((a) => a.id === assetB.id), false);
  assert.equal(selectAssetsForBatchRead([], {}).length, 0);
});

test('8 mergeRealAnalysis：更新 L1/L2/L4/tags/model，保留旧标签+用户确认 L4，不修改入参', () => {
  const oldTags = JSON.stringify(assetA.tags);
  const oldSummary = assetA.L1.summary;
  const withConfirmed = { ...assetA, L4: [...assetA.L4, { id: 'L4-user-1', layer: 'L4', kind: 'observation', source: 'user-confirmed', author: 'user', confidence: 1, text: '我确认：这是雾带', anchor: { type: 'bbox', value: [100, 100, 500, 80] }, evidenceRefs: [] }] };
  const analysis = {
    global: { summary: '真实 Qwen：冷灰蓝雾中山谷，远山与湖面形成层次', subject: ['远山', '雾', '湖'], medium: { kind: '水墨' }, palette: [{ hex: '#7f97a8' }, { hex: '#4f6778' }], mood: ['安静'] },
    regions: [{ id: 'L2-real-1', label: '远山', bbox: [10, 20, 300, 200], importance: 0.85, confidence: 0.8 }, { label: '湖面', bbox: [0, 300, 800, 200], confidence: 0.7 }],
    observations: [{ id: 'L4-real-1', kind: 'observation', text: '雾带横贯山谷，湖面留白', bbox: [100, 100, 500, 80], confidence: 0.82 }],
    confidence: 0.8,
  };
  const merged = mergeRealAnalysis(withConfirmed, analysis, { provider: 'qwen', model: 'qwen3.8-max', modelVersion: 'qwen3.8-max', latencyMs: 8700, usage: { total_tokens: 927 }, at: '2026-11-07T05:24:47.572Z' });
  assert.equal(merged.analysisSource, 'real');
  assert.equal(merged.modelVersion, 'qwen3.8-max');
  assert.ok(merged.L1.summary.includes('真实 Qwen'));
  assert.equal(merged.L2.length, 2);
  assert.equal(merged.L2[1].label, '湖面');
  assert.equal(merged.L4.filter((o) => o.source === 'user-confirmed').length, 1, '用户确认 L4 应保留');
  assert.equal(merged.L4.filter((o) => o.id === 'L4-real-1').length, 1);
  assert.ok(merged.tags.includes('我的标签') && merged.tags.includes('水墨') && merged.tags.includes('湖'));
  assert.equal(merged.tags.length <= 32, true);
  assert.deepEqual(merged.palette, ['#7f97a8', '#4f6778']);
  assert.equal(merged.analysis.source, 'real');
  assert.equal(merged.analysis.provider, 'qwen');
  assert.equal(merged.analysis.latency_ms, 8700);
  assert.deepEqual(merged.analysis.usage, { total_tokens: 927 });
  assert.equal(JSON.stringify(assetA.tags), oldTags, '不修改入参 tags');
  assert.equal(assetA.L1.summary, oldSummary, '不修改入参 L1');
  assert.equal(assetA.analysisSource, 'mock');
});

test('9 summarizeProvenance：AI 生成/引用/模型/确认摘要', () => {
  const ai = { ...assetB, tags: [...assetB.tags, 'AI生成'], provenance: { source: 'ai-generated', provider: 'qwen', model: 'qwen-image-3.0', prompt: '雾带留白', refs: [{ asset_id: assetA.id, fileName: assetA.fileName, sha256: assetA.sha256 }], candidate_sha256: 'f'.repeat(64), generated_at: '2026-11-07T05:25:00.000Z' }, L5: [{ id: 'L5-1', layer: 'L5', kind: 'confirm', targetId: 'L4-b1', tags: ['确认'], at: '2026-11-07T05:26:00.000Z', source: 'user-confirmed' }, { id: 'L5-2', layer: 'L5', kind: 'reject', targetId: 'L4-x', tags: [], at: '2026-11-07T05:27:00.000Z', source: 'user-confirmed' }] };
  const p = summarizeProvenance(ai);
  assert.equal(p.source, 'ai-generated');
  assert.equal(p.sourceLabel, 'AI 生成');
  assert.equal(p.provider, 'qwen');
  assert.equal(p.model, 'qwen-image-3.0');
  assert.equal(p.refCount, 1);
  assert.equal(p.confirmations, 1);
  assert.equal(p.rejections, 1);
  assert.ok(p.summary.includes('AI 生成') && p.summary.includes('qwen'));
  const imported = summarizeProvenance(assetA);
  assert.equal(imported.source, 'imported');
  assert.ok(imported.summary.includes('本地导入'));
  assert.equal(imported.sha256, assetA.sha256);
});

const failed = results.filter((r) => !r.pass);
const summary = {
  module: ASSET_AI_VERSION,
  total: results.length,
  passed: results.length - failed.length,
  failed: failed.length,
  cases: results,
};
console.log(JSON.stringify(summary, null, 2));
if (failed.length) process.exit(1);
