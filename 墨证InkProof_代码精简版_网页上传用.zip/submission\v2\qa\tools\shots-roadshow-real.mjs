// v2/qa/tools/shots-roadshow-real.mjs —— 真实模式下拍两张路演配图（观察 / 落层对比），供 PPT/README 使用
import { chromium } from '../node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
await page.goto('http://127.0.0.1:4200/v2/app/index.html', { waitUntil: 'domcontentloaded' });
await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
await sleep(1000);
await page.click('#btnRoadshow'); await sleep(400);
await page.click('#btnRoadshowStart');
await page.waitForFunction('(() => { const t = window.__V2_APP__ && window.__V2_APP__.t122; if (!t) return false; return t.state().prepared === true; })()', null, { timeout: 60000 });
await sleep(600);
await page.evaluate(() => window.__V2_APP__.t122.goto(2)); await sleep(300);
await page.click('#btnRoadshowExec');
await page.waitForFunction('!!window.__V2_APP__.state.analysis', null, { timeout: 120000 });
await sleep(1500);
await page.screenshot({ path: ROOT + '\\v2\\app\\ui-roadshow-observe-real.png' });
console.log('SHOT_OBSERVE');
await page.evaluate(() => window.__V2_APP__.t122.goto(3)); await sleep(300);
await page.click('#btnRoadshowExec'); await sleep(1200);
await page.evaluate(() => window.__V2_APP__.t122.goto(4)); await sleep(300);
await page.click('#btnRoadshowExec'); await sleep(2200);
// 把对比比例拉到 55%
await page.evaluate(() => { const el = document.querySelector('#roadshowBody input[type=range]'); if (el) { el.value = '55'; el.dispatchEvent(new Event('input', { bubbles: true })); } });
await sleep(800);
await page.screenshot({ path: ROOT + '\\v2\\app\\ui-roadshow-apply-real.png' });
console.log('SHOT_APPLY');
// 第 6 拍：证据包（不含 AI 调用，只做本地哈希/复核）
await page.evaluate(() => window.__V2_APP__.t122.goto(5)); await sleep(300);
await page.click('#btnRoadshowExec');
await page.waitForFunction('!!document.querySelector("#evidenceModal.show")', null, { timeout: 90000 }).catch(() => {});
await sleep(1200);
await page.screenshot({ path: ROOT + '\\v2\\app\\ui-roadshow-evidence-real.png' });
console.log('SHOT_EVIDENCE');
const meta = await page.evaluate(() => ({ badge: (document.getElementById('roadshowBadge') || {}).textContent, meta: (document.getElementById('roadshowMeta') || {}).textContent, step: window.__V2_APP__.t122.state().step }));
console.log(JSON.stringify(meta));
await browser.close();
