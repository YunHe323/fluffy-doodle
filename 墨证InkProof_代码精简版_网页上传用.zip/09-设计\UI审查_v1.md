# T105-C 独立 UI 审查 v1.0

> 审查者：ux-designer｜日期：2026-11-07｜范围：当前 v2 app（只读）｜方法：headless Edge 单页面顺序截图 + DOM 尺寸/样式探针
> 只写：本报告 + `09-设计/audit/` 截图；未改 `v2/app`、engine、qa 任何文件。

## 0. 结论

**有 2 个 P0，当前不建议直接上线；先修 §5 的 5 处，可达上线级。**

- 优点：暖纸 token 已统一；画布/纸台层次成立；素材库、演示、AI 面板整体语言一致；120–240ms 动效克制；无 console error。
- 阻断：**1366 顶栏标题与工具图标碰撞**；**变换工具状态不退出（Esc/开 AI 后仍驻留）**。
- 高级感主要流失点：深色未纸化的变换工具条/设置 footer、AI 面板密度与 11/11.5px 小字、设置弹窗滚动与调试信息、详情页被操作条遮挡。

## 1. 审查范围与方法

- 环境：Edge headless（Playwright-core 1.65），单页面顺序拍摄，**不并发**。
- 尺寸：**1920×1080**、**1366×768**。
- 状态：首屏、AI 观察/生成/模型、素材库、设置弹窗、变换工具条、tooltip、toast；共 22 张新截图 + 3 张复用截图（目录共 25 张 PNG）。
- 复用：`v2/app/ui-asset-real-read-1920.png`（1366 真实观察）、`ui-model-console-1920.png`、`ui-image-workshop-1920.png` 作为补充证据。
- 探针：DOM 尺寸、滚动高度、计算样式、min font、层级；截图后关闭浏览器。
- 结果：**0 条 console/page error**（`audit/console-errors.json` 为 `[]`）。

## 2. “第一次使用 10 秒看懂”测试

| 问题 | 结论 |
|---|---|
| 当前工具？ | ✅ 能：画笔为墨块 active |
| 当前图层？ | ⚠️ 不能：底栏只有“图层 2”，没有层名/缩略图，左侧图层浮层默认关闭 |
| AI 模型/状态？ | ❌ 不能：首屏只有“AI 待命”，模型（Qwen/真实/Mock）藏在 AI 面板内 |
| 下一步？ | ⚠️ 部分：底栏“框选后让 AI 看看”可读，但顶栏 14 个 icon 无文字，不知道哪个入口 |

结论：**工具状态合格，项目/图层/AI 模型/入口不合格**。首屏需要一行“当前层 + 模型 + 下一步”的文字，或一次性的三步提示。

---

## 3. Top 13 问题清单

| # | P | 问题 | 截图 | 影响 | 建议（CSS/组件值） |
|---|---|---|---|---|---|
| 01 | **P0** | 1366 顶栏标题与工具图标碰撞 | `audit/1366-default.png`、`audit/1366-tooltip.png` | 标题不可读、像坏布局；直接毁掉高级感 | ≤1499px 隐藏 `.pro-doc`，顶栏 58→52；或把标题下移到底栏 |
| 02 | **P0** | 变换状态不退出：Esc/开 AI 后 `#toolOptions` 仍显示，状态栏仍是“变换” | `audit/1366-ai-panel.png`、`audit/1366-ai-model.png`、`audit/1366-transform.png` | 用户不知道当前是变换还是 AI；可能误操作；违反 T91 I1 | Esc/开任何浮层先 `cancelTransformUI()`；`#toolOptions.hidden = state.tool!=='transform'` |
| 03 | P1 | 变换工具条仍是深蓝未纸化（`rgba(10,16,25,.97)`），select/手柄蓝色 | `audit/1920-transform.png`、`audit/1366-transform.png` | 暖纸 UI 中突兀，像两套产品；遮挡顶栏 | 见 §4.3 的 paper token 覆盖；手柄改 `--focus` |
| 04 | P1 | AI 面板过密：392×675、5 tab、3 个入口 CTA、两个输入区、footer 4 按钮；无关闭 ×；正文 11/11.5px | `audit/1366-ai-panel-clean.png`、`audit/1920-ai-panel-clean.png` | 第一次不知从哪开始；小字不专业；面板像调试器 | 合并输入区；加 28×28 ×；正文 ≥12；主 CTA sticky |
| 05 | P1 | AI 观察/生成前看不到模型成本/耗时；模型页被 Provider/Key/Skill/用量 等技术信息占据 | `audit/1366-ai-model-clean.png`、`audit/1920-model-console-reference.png` | 真实调用前不可预期；信任/高级感流失 | header/CTA 固定一行 `Qwen3.8 · 真实 · ~30–120s · ¥0.2/张` 或 `本地 Mock · 0 网络 · ~1s` |
| 06 | P1 | 设置弹窗：1366 内部滚动 727/538 无可见滚动条；footer 仍是深蓝；标题仅 14px；调试信息首屏 | `audit/1366-settings.png`、`audit/1920-settings.png` | 关键配置像被截断；深色 footer 破坏纸感；像开发页 | `.modal-foot` 纸化；可见 8px 滚动条；标题 18；调试信息折叠 |
| 07 | P1 | tooltip 遮挡左栏数值（`画笔（B）` 黑块压住 `36px`） | `audit/1366-tooltip.png`、`audit/1920-tooltip.png` | 悬停反而遮信息；首屏显乱 | 左栏 tooltip 放到按钮右侧 8px；字号 11.5→12 |
| 08 | P1 | 素材库详情被固定操作条遮挡：body 558/1514，L2 行 703–764，操作条 663–719，padding-bottom:0 | `audit/1366-library.png`、`audit/1920-library.png` | L2/L4/L5 看不到，像“截断的详情”；操作条压内容 | `.lib-detail-body{padding-bottom:96px}`；操作条 sticky + 上下渐变 |
| 09 | P1 | 底栏提示/toast 与 AI 面板 footer 叠层（1366 画布 hint 被遮；`已取消变换` toast 压“让 AI 看看”） | `audit/1366-ai-panel-clean.png`、`audit/1366-ai-panel.png` | 主操作被挡；界面像图层错位；错误反馈和操作争层级 | toast 固定安全区；AI 打开时隐藏画布 hint/把 toast 移到顶部 |
| 10 | P1 | 首屏缺“当前层名 / AI 模型 / 下一步”文字；顶栏 icon-only；底栏哈希/计数噪音 | `audit/1920-default.png`、`audit/1366-default.png` | 10 秒测试不合格；新用户找不到 AI 入口 | 底栏改为“画笔 B · 雾中山谷 图层2 · AI 本地 Mock · 框选后 AI 看看”；首次提示 3 步 |
| 11 | P1 | 顶栏信息架构过密：14 个 icon-only 操作、组间距弱、`书本/形状/更多` 难辨；1366 直接碰撞 | `audit/1920-default.png`、`audit/1366-default.png` | 专业工具应有清晰分组/快捷键；现在像一排按钮 | 保留 6 核心工具 + 3 入口；`文字/形状/移动` 收进更多；工具 hover 加“名称 + 快捷键” |
| 12 | P2 | 设置里的原生 select/checkbox 与纸感控件不统一；`M4.2/哈希后端/显存策略` 等开发信息首屏 | `audit/1920-settings.png`、`audit/1366-settings.png` | 控件像浏览器默认；信息层级偏工程 | `appearance:none` + 纸底/墨边；checkbox `accent-color:var(--seal)`；开发信息移“关于/高级” |
| 13 | P2 | 底栏信息同权重：事件/图层/笔触/AI 待命/哈希/协作/存证 全 11px；哈希抢占注意力 | `audit/1920-default.png` | 关键状态读不出来；高级感被“状态流水账”拉低 | 主状态 12/500，计数 11/400；哈希移 tooltip 或证据面板 |

---

## 4. 关键问题详情

### P0-01 1366 顶栏标题与工具图标碰撞

- **证据**：`audit/1366-default.png`、`audit/1366-tooltip.png`。DOM 实测：`.pro-doc` x=622、w=123、right=744；最后一个 `.pro-tools` right=680；**重叠 58px**，标题文字直接压过素材/AI 图标。顶栏实际高度 **58px**（探针），不是设计系统 56 / T58 48。
- **为什么破坏高级感**：1366 是验收尺寸，标题被图标穿过，第一眼就是“没做完”；同时 58px 顶栏吃掉画布高度。
- **建议（CSS）**：
  ```css
  @media (max-width: 1499px) {
    .pro-doc { display: none; }          /* 或移到底栏显示作品名 */
    .pro-topbar { height: 52px; }
    .pro-btn { width: 34px; height: 34px; }
  }
  ```
  若必须保留标题：将顶栏工具改为 6 核心 + “更多”收纳，并在 1366 下把 `.pro-doc` 左移/降级为 tooltip；不要靠 `max-width` 硬截断（会出现省略号 + 图标重叠）。

### P0-02 变换状态不退出（Esc / 打开 AI）

- **证据**：`audit/1366-ai-panel.png`、`audit/1366-ai-model.png`、`audit/1366-transform.png`。探针：点击变换后按 Esc，`#toolOptions.hidden=false`、`display:flex`，状态栏仍“变换：…”；再开 AI 后仍保持；`toolOptions` 背景 `rgba(10,16,25,.97)` 压在顶栏/AI 面板上。
- **影响**：用户看到“变换工具条 + AI 面板”同时存在，违反 T91 I1/I2；按 Esc 不退出会让人以为界面卡住；AI 面板主操作容易被误认为作用于变换。
- **建议**：
  1. 全局 Esc 处理优先级：`transform → cancelTransformUI(); setTool('brush'); return;`（在 popover 关闭之前判断）。
  2. `openPopover('popAI' | 'popLayers' | ...)`/开素材库/开演示前：若 `state.tool==='transform'`，先 `cancelTransformUI()` 并 toast「已取消变换」。
  3. `setTool()` 统一：`$('toolOptions').hidden = (tool !== 'transform' && tool !== 'select')`，不要只设置不回收。
  4. 补一条回归序列：`transform → Esc`、`transform → AI`、`transform → Library`。

### P1-03 变换工具条未纸化

- **证据**：`audit/1920-transform.png`、`audit/1366-transform.png`。`#toolOptions` 计算背景 `rgba(10, 16, 25, 0.97)`，select 深底浅字；变换框/手柄为蓝色。
- **影响**：暖纸 UI 里出现一条“暗色 IDE 工具条”，视觉断裂；在 1366 还和标题/AI 面板叠层。
- **建议**：
  ```css
  html[data-theme="paper"] .tool-options {
    top: calc(var(--top-h) + 6px);
    background: var(--paper-100);
    border: 1px solid var(--line-strong);
    border-radius: 10px;
    box-shadow: var(--e-2);
    color: var(--ink-900);
  }
  html[data-theme="paper"] .tool-options select {
    background: var(--paper-200);
    color: var(--ink-900);
    border: 1px solid var(--line-strong);
  }
  html[data-theme="paper"] .tool-options .to-chip.active,
  html[data-theme="paper"] .tool-options button.active {
    background: var(--ink-900); color: var(--paper-text);
  }
  ```
  变换框/手柄：边框 `1.5px solid var(--focus)`，手柄 `10px` 纸底 + `2px var(--focus)`；不要再使用默认蓝色。

### P1-04 AI 面板密度 / 关闭 / 小字

- **证据**：`audit/1366-ai-panel-clean.png`、`audit/1920-ai-panel-clean.png`。实测 1366：`392×675`，header 44、body 535（scroll 611）、footer 53；5 个 tab；探针找到 11px/11.5px 文本 4 处（hint 三处、`.ai-section-title`）；**无任何 close button**。
- **影响**：第一屏同时出现“正在与谁协作 / 先做一件事 / 告诉 AI 意图 / 和 AI 说 / 底部 4 按钮”，用户不知道唯一主行动；11px 小字与“高级感”矛盾；无 × 让关闭靠猜 Esc/点外。
- **建议**：
  - header 右侧加 28×28 `button.ai-close`（`data-close="popAI"`），保留模型 pill 作为信息而非按钮；
  - 合并“告诉 AI 你的意图”和“和 AI 说”为**一个** composer；保留 chips；
  - “AI 模型接入 / 接口状态 / AI 图像工作台”三个按钮收成一行 `模型与接入 ›`，或移入模型 tab；
  - 正文/提示 `.hint/.ai-section-title` **最小 12px/18px**；footer 主 CTA 固定，body 独立滚动（`max-height:calc(100vh - 160px); overflow:auto`）；
  - 只保留一个 primary：`让 AI 看看`；其余 `取消请求/不参与档案/档案记录` 降级 ghost/tiny。

### P1-05 AI 成本 / 耗时 / 模型不可见

- **证据**：`audit/1366-ai-model-clean.png`、`audit/1920-model-console-reference.png`、`audit/1920-ai-generate.png`。当前 header 只有 `Qwen · 真实`，模型/延迟/价格在“模型”tab 的 Provider/Model/Key/Skill/用量 中；观察/生成 CTA 旁无预估。
- **影响**：真实调用前用户无法判断“点下去要等多久/花多少钱”，这是 AI 产品信任与高级感的核心。
- **建议**：在 AI header 或主 CTA 上方固定一行 12px 次级信息：
  - Mock：`本地 Mock · 0 网络 · ~1s`
  - 真实：`Qwen3.8 · 真实 · ~30–120s · ¥0.2/张`（值来自现有配置/说明，不伪造）
  - 点击该行打开“模型与隐私”卡；模型 console 移到设置或折叠到“高级”。

### P1-06 设置弹窗：滚动、footer、标题、调试信息

- **证据**：`audit/1366-settings.png`、`audit/1920-settings.png`。实测 1366：modal 920×676，body client 538 / scroll 727，`overflow-y:auto` 但无可见滚动条；footer 背景 `rgb(12,18,28)`；标题 14px；首屏出现 `M4.2/哈希后端/显存策略 dirty`。
- **影响**：用户以为 AI 配置段落被截断；深色 footer 是第二个“未纸化”破绽；调试信息降低专业感；14px 标题撑不起 920px 宽弹窗。
- **建议**：
  ```css
  html[data-theme="paper"] .modal { display:flex; flex-direction:column; max-height:calc(100vh - 48px); }
  html[data-theme="paper"] .modal-body { overflow:auto; scrollbar-width:thin; scrollbar-color:var(--line-strong) transparent; }
  html[data-theme="paper"] .modal-body::-webkit-scrollbar { width:8px; }
  html[data-theme="paper"] .modal-body::-webkit-scrollbar-thumb { background:var(--line-strong); border-radius:8px; }
  html[data-theme="paper"] .modal-head h3 { font-size:18px; line-height:26px; }
  html[data-theme="paper"] .modal-foot { background:var(--paper-200); border-top:1px solid var(--line-2); color:var(--ink-900); }
  ```
  并把“版本与运行”中的版本/哈希后端/渲染策略折叠到“关于 / 高级”；首屏只留用户可行动项（模式、AI 接入、数据）。

### P1-07 tooltip 遮挡左栏数值

- **证据**：`audit/1366-tooltip.png`、`audit/1920-tooltip.png`。`#uiTooltip` 字号 11.5px，定位逻辑是按钮底部下方 10px；最左画笔按钮在 x≈59，tooltip 居中后覆盖 x≈43–113，正好压住左栏 `36px` 数值。
- **影响**：用户为了看工具名反而遮住当前参数；首个 hover 就显乱。
- **建议**：`initTooltips` 对 `r.left < 80 && r.top < 70` 的元素改为 `x = r.right + 8; y = r.top + (r.height - tr.height)/2`；字号 `12px/18px`；最大宽 240；保留 380ms 延迟与 `prefers-reduced-motion:0`。
  ```css
  #uiTooltip { font-size:12px; line-height:18px; padding:6px 9px; border-radius:7px; }
  ```

### P1-08 素材库详情被固定操作条遮挡

- **证据**：`audit/1366-library.png`、`audit/1920-library.png`。实测 1366：`.lib-detail-body` client 558 / scroll 1514；`.lib-actions` y=663–719；`.lib-l2-row` y=703–764，**101px 落在操作条下**；`padding-bottom:0`。
- **影响**：详情页 L2/L4/L5 内容被遮，用户以为素材库只到 L1；是“截断”的典型低质信号。
- **建议**：
  ```css
  html[data-theme="paper"] .lib-detail-body { padding-bottom:96px; overscroll-behavior:contain; }
  html[data-theme="paper"] .lib-actions {
    position:sticky; bottom:0; background:linear-gradient(180deg, rgba(251,246,236,.86), var(--paper-100) 24%);
    border-top:1px solid var(--line-2);
  }
  ```
  同时给 body 可见 8px 滚动条；保证 1366 下 L2/L4/L5 可达、操作条不遮最后一行。

### P1-09 底栏提示 / toast 与 AI 面板 footer 叠层

- **证据**：`audit/1366-ai-panel-clean.png`（底部居中“画几笔，或从更多…”提示被 AI 面板 footer 遮住一半）、`audit/1366-ai-panel.png`（`已取消变换` toast 压在 AI footer 主按钮上）。两者都是固定底层反馈与浮层争 z-index。
- **影响**：AI 面板底部的“让 AI 看看”主 CTA 被遮/被抢注意力；用户以为按钮不可用；界面像图层没对齐。
- **建议**：toast/画布 hint 固定到不与浮层重叠的安全区；AI 面板打开时移至顶部或隐藏：
  ```css
  #toastWrap { bottom: calc(var(--h-statusbar,28px) + 16px); }
  .canvas-hint { z-index: 30; } /* 低于浮层 */
  body:has(#popAI.open) .canvas-hint { opacity: 0; pointer-events: none; }
  body.ai-open #toastWrap { top: calc(var(--top-h) + 12px); bottom:auto; }
  ```
  或取消变换时不 toast（状态栏提示即可），AI 面板 footer 始终置顶。

### P1-10 首屏 10 秒信息不完整

- **证据**：`audit/1920-default.png`、`audit/1366-default.png`。当前只有工具 active 明确；底栏“事件1 图层2 笔触0 AI 待命 哈希…”没有层名/模型；AI 入口是 sparkle 图标，无文字；没有“下一步”主 CTA。
- **影响**：第一次使用不知道 AI 在哪、当前在哪个图层；这是“10 秒看懂”验收的直接失败项。
- **建议**：底栏左侧/中间改为一句可读状态：
  `画笔 B · 图层 2（背景） · AI 本地 Mock · 框选后点 AI 看看`
  首次进入显示一次 3 步条（可关闭、不阻塞）；顶栏 AI 按钮 hover 显示“AI 观察 / 生成（本地 Mock）”；哈希与事件计数降为 tooltip/证据面板。

### P1-11 顶栏信息架构过密

- **证据**：`audit/1920-default.png`、`audit/1366-default.png`。14 个 icon-only 按钮、4 个分组、无文字标签；`书本/形状/更多` 难辨；1366 直接碰撞。
- **影响**：Procreate 式布局应是“少而准”，现在像功能清单；每次找工具靠记忆/hover。
- **建议**：保留高频 6 个（画笔/橡皮/选区/变换/图层/颜色）+ 3 入口（素材/演示/AI）；`涂抹/移动/文字/形状` 收进“更多”或右键/长按；每组加更明显 1px 分隔；hover tooltip 统一“名称（快捷键）”。

### P2-12 设置原生控件 / 开发信息

- **证据**：`audit/1920-settings.png`。`select` 原生样式、checkbox 默认蓝、M4.2/哈希后端等工程信息首屏。
- **影响**：控件与纸感系统脱节；信息暴露过度，降低“产品已打磨”感。
- **建议**：`appearance:none` + `--paper-200`/`--line-strong`；checkbox `accent-color:var(--seal)`；开发信息折叠到“关于 / 高级”。

### P2-13 底栏状态同权重

- **证据**：`audit/1920-default.png`。事件/图层/笔触/AI 待命/哈希/协作/存证 全 11px，同色同权。
- **影响**：用户不知道哪个是“当前状态”，哈希抢注意力；底栏像调试条。
- **建议**：主状态 12px/500（工具、层、AI 状态）；计数 11px/400；哈希只在证据/悬停；模式 chip 保留但降对比。

---

## 5. 只改 5 处（建议按此顺序）

1. **1366 顶栏收口**（P0-01）：`@media (max-width:1499px){ .pro-doc{display:none} .pro-topbar{height:52px} .pro-btn{width:34px;height:34px} }`；验收 1366 无重叠、4 组工具与标题不再打架。
2. **变换状态收尾 + 工具条纸化**（P0-02 + P1-03）：Esc/开浮层先取消 transform；`#toolOptions` 用 `--paper-100/--line-strong/--ink-900` 覆盖；手柄改 `--focus`。
3. **AI 面板第一屏收口**（P1-04 + P1-05）：加关闭 ×；合并两个输入区；正文/提示 ≥12px；footer 固定；header/CTA 显示模型 + 耗时/成本一行。
4. **设置弹窗纸化与可达性**（P1-06 + P2-12）：footer 纸色、可见滚动条、标题 18；调试信息折叠；原生 select/checkbox 换纸感样式。
5. **素材库详情底部留白/操作条**（P1-08）：`padding-bottom:96px` + sticky action；1366 验证 L2/L4/L5 全部可达。

> 修完这 5 处，剩余 P1（tooltip 定位、toast 层级、首屏状态、顶栏 IA）可作为第二轮 polish；不阻塞主视觉验收。

---

## 6. 证据与复现

- 截图目录：`09-设计/audit/`
  - 1920：`1920-default.png`、`1920-tooltip.png`、`1920-transform.png`、`1920-ai-panel-clean.png`、`1920-ai-model-clean.png`、`1920-ai-generate.png`、`1920-library.png`、`1920-settings.png`、`1920-toast.png`、`1920-model-console-reference.png`、`1920-ai-image-workshop-reference.png`
  - 1366：`1366-default.png`、`1366-tooltip.png`、`1366-transform.png`、`1366-ai-panel-clean.png`、`1366-ai-model-clean.png`、`1366-ai-generate.png`、`1366-library.png`、`1366-settings.png`、`1366-toast.png`、`1366-ai-observation-real.png`
- 控制台：`09-设计/audit/console-errors.json` = `[]`
- 复现：`http://127.0.0.1:4200/v2/app/index.html`；headless Edge，单页面顺序；1920/1366。
- 限制：本报告为只读审查；未跑功能回归；未触发真实 AI 调用（只有面板/模型/生成 UI 状态，观察态复用已有截图）。

---

## 7. 已验证正常（不作为问题）

- 暖纸 token/纸纹/暖阴影/圆角整体一致；画布仍为白纸；无 console error。
- 素材库 scrim、卡片/详情纸感层级成立；来源三态有图形+文字；字号总体 ≥12（AI 面板除外）。
- 演示说明卡/spotlight/控制条在纸底上可读；120–240ms 动效与 reduced-motion 规则存在。
- 设置/素材库/AI 均为现有功能，未发现本次审查范围内的崩溃或数据丢失。
