#!/usr/bin/env node
// product/scripts/package.mjs
// 零第三方依赖的 Release 打包脚本（v0.1）。
//
// 功能：
//   1) 读取 product/package.json 的 version，生成 dist/inkproof-v<version>/
//   2) 只复制运行时所需：app/ core/ server/ config/provider.example.json + 根文档/启动脚本
//      排除：reference/ test/ .github/ scripts/ dist/ node_modules/ .tmp-* / *.log / 真实 config/provider.json
//   3) 打 zip（优先系统 tar -a；其次 zip；再 PowerShell Compress-Archive；最后 tar.gz fallback）
//   4) 输出 zip 的 SHA-256 与逐文件清单 manifest
//   5) 干净目录验证：解压到临时目录 → node server/server.mjs → /api/health 与 / 均 200
//      并确认包内无 reference/、无 config/provider.json、无 sk- 形态密钥；结束后清理进程与临时目录
//
// 用法：
//   node scripts/package.mjs              # 打包 + 验证
//   node scripts/package.mjs --no-verify  # 只打包
//   node scripts/package.mjs --keep-temp  # 保留解压验证目录（调试）
//
// 约束：零第三方依赖；只写 dist/ 与临时目录；不修改 app/server/core/test。

import { promises as fs, statSync as fsStatSync, existsSync as fsExistsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import os from 'node:os';
import net from 'node:net';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const PRODUCT_ROOT = path.resolve(SCRIPT_DIR, '..');
const DIST_DIR = path.join(PRODUCT_ROOT, 'dist');

const ARTIFACT_BASENAME = 'inkproof';
const INCLUDE_FILES = [
  'package.json',
  'README.md',
  'LICENSE',
  'CONTRACT.md',
  'CHANGELOG.md',
  'CONTRIBUTING.md',
  'CODE_OF_CONDUCT.md',
  'start.bat',
  'start.sh',
];
const INCLUDE_DIRS = ['app', 'core', 'server', 'docs'];
const INCLUDE_SPECIAL = ['config/provider.example.json'];
const EXCLUDED_TOP_DIRS = ['reference', 'test', '.github', 'node_modules', 'dist', 'scripts'];
const EXCLUDE_PATTERNS = [
  /^\.tmp-/,
  /\.log$/,
  /\.screen\.tmp\.png$/,
  /^provider\.json$/, // 真实配置（可能含 key）绝不入包
  /^\.DS_Store$/,
  /^Thumbs\.db$/,
];
const TEXT_EXTS = new Set(['.js', '.mjs', '.json', '.md', '.txt', '.html', '.css', '.bat', '.sh', '.yml', '.yaml']);
const SECRET_PATTERNS = [/sk-[A-Za-z0-9]{16,}/, /-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/];

const argv = new Set(process.argv.slice(2));
const OPTIONS = {
  verify: !argv.has('--no-verify'),
  keepTemp: argv.has('--keep-temp'),
  help: argv.has('--help') || argv.has('-h'),
};

let step = 0;
const t0 = Date.now();
function log(msg = '') { console.log(msg); }
function stepStart(title) { step += 1; log(`\n[${String(step).padStart(2, '0')}] ${title}`); }
function ok(msg) { log(`     ✓ ${msg}`); }
function warn(msg) { log(`     ! ${msg}`); }
function fail(msg) { log(`     ✗ ${msg}`); }

// ---------------------------------------------------------------------------
// 基础工具
// ---------------------------------------------------------------------------

async function exists(p) {
  try { await fs.access(p); return true; } catch { return false; }
}

async function sha256File(file) {
  const buf = await fs.readFile(file);
  return createHash('sha256').update(buf).digest('hex');
}

function humanBytes(n) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

async function readJson(file) {
  return JSON.parse(await fs.readFile(file, 'utf8'));
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function walkFiles(root, relDir = '') {
  const absDir = path.join(root, relDir);
  const entries = await fs.readdir(absDir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const rel = relDir ? path.posix.join(relDir, entry.name) : entry.name;
    if (EXCLUDE_PATTERNS.some((rx) => rx.test(entry.name))) continue;
    if (entry.isDirectory()) files.push(...await walkFiles(root, rel));
    else if (entry.isFile()) files.push(rel);
  }
  return files;
}

async function walkAll(dir, relDir = '') {
  const absDir = path.join(dir, relDir);
  let entries;
  try { entries = await fs.readdir(absDir, { withFileTypes: true }); } catch { return []; }
  const files = [];
  for (const entry of entries) {
    const rel = relDir ? path.posix.join(relDir, entry.name) : entry.name;
    if (entry.isDirectory()) files.push(...await walkAll(dir, rel));
    else if (entry.isFile()) files.push(rel);
  }
  return files;
}

function run(command, args, options = {}) {
  const result = spawnSync(command, args, { encoding: 'utf8', windowsHide: true, ...options });
  return { status: result.status, stdout: result.stdout ?? '', stderr: result.stderr ?? '', error: result.error };
}

// ---------------------------------------------------------------------------
// 1. 复制产物
// ---------------------------------------------------------------------------

async function buildArtifact(artifactName) {
  stepStart(`生成产物目录 dist/${artifactName}/`);
  const artifactDir = path.join(DIST_DIR, artifactName);

  // 只清理 dist 内的同名产物（不碰其它目录）
  await fs.rm(artifactDir, { recursive: true, force: true });
  await fs.mkdir(artifactDir, { recursive: true });

  const copied = [];

  for (const dir of INCLUDE_DIRS) {
    const src = path.join(PRODUCT_ROOT, dir);
    if (!await exists(src)) { warn(`跳过不存在的目录：${dir}/`); continue; }
    const files = await walkFiles(src);
    for (const rel of files) {
      const from = path.join(src, rel);
      const to = path.join(artifactDir, dir, rel);
      await fs.mkdir(path.dirname(to), { recursive: true });
      await fs.copyFile(from, to);
      copied.push(`${dir}/${rel}`);
    }
  }

  for (const rel of INCLUDE_FILES) {
    const from = path.join(PRODUCT_ROOT, rel);
    if (!await exists(from)) { warn(`跳过不存在的文件：${rel}`); continue; }
    const to = path.join(artifactDir, rel);
    await fs.mkdir(path.dirname(to), { recursive: true });
    await fs.copyFile(from, to);
    copied.push(rel);
  }

  for (const rel of INCLUDE_SPECIAL) {
    const from = path.join(PRODUCT_ROOT, rel);
    if (!await exists(from)) { warn(`跳过不存在的文件：${rel}`); continue; }
    const to = path.join(artifactDir, rel);
    await fs.mkdir(path.dirname(to), { recursive: true });
    await fs.copyFile(from, to);
    copied.push(rel);
  }

  // 明确排除项自检（防止未来 include 变动把敏感文件带进来）
  const forbidden = [
    'config/provider.json',
    'reference',
  ];
  for (const rel of forbidden) {
    assert(!await exists(path.join(artifactDir, rel)), `产物中不应存在 ${rel}`);
  }

  const files = await walkAll(artifactDir);
  const listed = [];
  for (const rel of files) {
    const abs = path.join(artifactDir, rel);
    const stat = await fs.stat(abs);
    listed.push({ path: rel, sizeBytes: stat.size, sha256: await sha256File(abs) });
  }

  // RELEASE.json（产物内元信息）
  const pkg = await readJson(path.join(PRODUCT_ROOT, 'package.json'));
  const releaseInfo = {
    name: ARTIFACT_BASENAME,
    product: 'Mozheng InkProof',
    version: pkg.version,
    builtAt: new Date().toISOString(),
    node: process.version,
    platform: `${process.platform}-${process.arch}`,
    source: 'product/',
    notes: [
      'Mock AI is the default: offline, deterministic, no API key required.',
      'Real provider is not implemented in v0.1; config/provider.example.json shows the shape (leave apiKey empty).',
      'Do not commit config/provider.json (it may contain API keys).',
    ],
  };
  await fs.writeFile(path.join(artifactDir, 'RELEASE.json'), `${JSON.stringify(releaseInfo, null, 2)}\n`, 'utf8');
  const releaseStat = await fs.stat(path.join(artifactDir, 'RELEASE.json'));
  listed.push({ path: 'RELEASE.json', sizeBytes: releaseStat.size, sha256: await sha256File(path.join(artifactDir, 'RELEASE.json')) });

  listed.sort((a, b) => a.path.localeCompare(b.path));
  ok(`复制 ${listed.length} 个文件（${humanBytes(listed.reduce((s, f) => s + f.sizeBytes, 0))}）`);
  ok(`排除：${EXCLUDED_TOP_DIRS.join('/, ')}/、.tmp-*、*.log、config/provider.json`);

  return { artifactDir, files: listed, releaseInfo };
}

// ---------------------------------------------------------------------------
// 2. 结构与密钥自检
// ---------------------------------------------------------------------------

async function verifyArtifact(artifactDir, files) {
  stepStart('产物结构与密钥自检');
  const mustHave = [
    'package.json', 'README.md', 'LICENSE', 'CONTRACT.md', 'CHANGELOG.md', 'CONTRIBUTING.md',
    'CODE_OF_CONDUCT.md', 'start.bat', 'start.sh',
    'server/server.mjs', 'server/ai-proxy.mjs',
    'core/hash-chain.mjs', 'core/archive-schema.mjs', 'core/mock-ai.mjs',
    'config/provider.example.json', 'app/index.html',
  ];
  for (const rel of mustHave) {
    assert(files.some((f) => f.path === rel), `产物缺少必需文件：${rel}`);
  }
  ok(`必需文件齐全（${mustHave.length} 项）`);

  for (const badDir of EXCLUDED_TOP_DIRS) {
    assert(!files.some((f) => f.path === badDir || f.path.startsWith(`${badDir}/`)), `产物不应包含 ${badDir}/`);
  }
  assert(!files.some((f) => f.path === 'config/provider.json'), '产物不应包含 config/provider.json');
  assert(!files.some((f) => f.path.split('/').some((seg) => seg.startsWith('.tmp-'))), '产物不应包含 .tmp-*');
  ok('排除项确认：无 reference/、无 test/、无 config/provider.json、无 .tmp-*');

  const example = JSON.parse(await fs.readFile(path.join(artifactDir, 'config/provider.example.json'), 'utf8'));
  assert(example.apiKey === '', 'provider.example.json 的 apiKey 必须为空');
  ok('provider.example.json：apiKey 为空');

  // 文本文件密钥形态扫描
  let hits = 0;
  let scanned = 0;
  for (const file of files) {
    if (!TEXT_EXTS.has(path.extname(file.path).toLowerCase())) continue;
    const abs = path.join(artifactDir, file.path);
    const stat = await fs.stat(abs);
    if (stat.size > 2 * 1024 * 1024) continue;
    const text = await fs.readFile(abs, 'utf8');
    scanned += 1;
    for (const rx of SECRET_PATTERNS) {
      if (rx.test(text)) {
        hits += 1;
        fail(`疑似密钥形态：${file.path}`);
      }
    }
  }
  assert(hits === 0, `发现 ${hits} 处疑似密钥，拒绝打包`);
  ok(`密钥扫描：${scanned} 个文本文件，无 sk-*/私钥形态命中`);

  await verifyStartScripts(artifactDir);
  return true;
}

// ---------------------------------------------------------------------------
// 2b. 启动脚本文本校对
// ---------------------------------------------------------------------------

async function verifyStartScripts(artifactDir) {
  stepStart('启动脚本校对（start.bat / start.sh）');
  const batPath = path.join(artifactDir, 'start.bat');
  const shPath = path.join(artifactDir, 'start.sh');
  const bat = await fs.readFile(batPath, 'utf8');
  const sh = await fs.readFile(shPath, 'utf8');

  const batChecks = [
    ['Node 未安装提示', '没有找到 Node.js'],
    ['Node 版本要求', 'Node.js 22'],
    ['启动命令', 'server\\server.mjs'],
    ['端口说明', '4173'],
    ['端口自动 +1 说明', '自动 +1'],
    ['停止方式', 'Ctrl+C'],
  ];
  for (const [label, needle] of batChecks) {
    assert(bat.includes(needle), `start.bat 缺少「${label}」（${needle}）`);
  }
  assert(bat.includes('\r\n'), 'start.bat 应使用 CRLF 行尾（Windows 兼容）');
  assert(/\bstart\s+"[^"]+"\s+cmd\s+\/k/i.test(bat), 'start.bat 应以可读日志窗口启动服务（便于查看实际端口）');
  ok(`start.bat：${batChecks.length} 项检查通过（CRLF，可见服务器窗口）`);

  const shChecks = [
    ['shebang', '#!/usr/bin/env bash'],
    ['Node 检测', 'command -v node'],
    ['Node 版本要求', '22'],
    ['启动命令', 'node server/server.mjs'],
    ['默认端口', '4173'],
    ['停止方式', 'Ctrl+C'],
    ['实际端口解析', 'grep -o'],
    ['退出清理', 'trap cleanup'],
  ];
  for (const [label, needle] of shChecks) {
    assert(sh.includes(needle), `start.sh 缺少「${label}」（${needle}）`);
  }
  const crlf = sh.includes('\r\n');
  if (crlf) warn('start.sh 含 CRLF（建议 LF；macOS/Linux 下 CRLF 可能导致 bad interpreter）');
  ok(`start.sh：${shChecks.length} 项检查通过（LF：${crlf ? '否' : '是'}）`);
  return true;
}

// ---------------------------------------------------------------------------
// 3. 打 zip
// ---------------------------------------------------------------------------

function tryZipTar(artifactName, zipPath) {
  const result = run('tar', ['-a', '-c', '-f', zipPath, '-C', DIST_DIR, artifactName]);
  return result.status === 0 && requireExistsSync(zipPath) ? 'tar -a' : null;
}

function tryZipZip(artifactName, zipPath) {
  const result = run('zip', ['-r', '-q', zipPath, artifactName], { cwd: DIST_DIR });
  return result.status === 0 && requireExistsSync(zipPath) ? 'zip' : null;
}

function tryZipPowerShell(artifactName, zipPath) {
  if (process.platform !== 'win32') return null;
  const artifactDir = path.join(DIST_DIR, artifactName);
  const ps = [
    '$ErrorActionPreference = "Stop";',
    `Compress-Archive -LiteralPath '${artifactDir.replace(/'/g, "''")}' -DestinationPath '${zipPath.replace(/'/g, "''")}' -Force`,
  ].join(' ');
  for (const exe of ['pwsh', 'powershell']) {
    const result = run(exe, ['-NoProfile', '-NonInteractive', '-Command', ps]);
    if (result.status === 0 && requireExistsSync(zipPath)) return 'Compress-Archive';
  }
  return null;
}

function tryTarGz(artifactName) {
  if (process.platform === 'win32') return null;
  const tgzPath = path.join(DIST_DIR, `${artifactName}.tar.gz`);
  const result = run('tar', ['-czf', tgzPath, '-C', DIST_DIR, artifactName]);
  if (result.status === 0 && requireExistsSync(tgzPath)) return { path: tgzPath, method: 'tar.gz' };
  return null;
}

function requireExistsSync(p) {
  return fsExistsSync(p) && fsStatSync(p).size > 0;
}

async function createZip(artifactName) {
  stepStart('打包 zip');
  const zipPath = path.join(DIST_DIR, `${artifactName}.zip`);
  await fs.rm(zipPath, { force: true });

  const strategies = [
    { name: 'tar -a（Windows bsdtar / 部分平台）', fn: () => tryZipTar(artifactName, zipPath) },
    { name: 'zip -r', fn: () => tryZipZip(artifactName, zipPath) },
    { name: 'PowerShell Compress-Archive', fn: () => tryZipPowerShell(artifactName, zipPath) },
  ];
  for (const strategy of strategies) {
    try {
      const method = strategy.fn();
      if (method) {
        const stat = await fs.stat(zipPath);
        assert(stat.size > 0, 'zip 为空');
        ok(`使用 ${method} 生成：${path.relative(PRODUCT_ROOT, zipPath)}（${humanBytes(stat.size)}）`);
        return { zipPath, method, sizeBytes: stat.size, format: 'zip' };
      }
      warn(`${strategy.name} 不可用或失败，尝试下一种`);
    } catch (error) {
      warn(`${strategy.name} 失败：${error.message}`);
    }
    await fs.rm(zipPath, { force: true });
  }

  const tgz = tryTarGz(artifactName);
  if (tgz) {
    const stat = await fs.stat(tgz.path);
    warn('系统无 zip 能力，已回退 tar.gz（跨平台可解压；如发布需要 zip 请安装 zip 或使用 Windows）');
    ok(`使用 tar.gz 生成：${path.relative(PRODUCT_ROOT, tgz.path)}（${humanBytes(stat.size)}）`);
    return { zipPath: tgz.path, method: tgz.method, sizeBytes: stat.size, format: 'tar.gz' };
  }

  throw new Error('无法生成压缩包：tar / zip / PowerShell 均不可用');
}

// ---------------------------------------------------------------------------
// 4. 解压验证（干净目录）
// ---------------------------------------------------------------------------

function getFreePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.unref();
    srv.on('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const { port } = srv.address();
      srv.close(() => resolve(port));
    });
  });
}

async function extractPackage(archive, tempDir) {
  const archiveExt = path.extname(archive).toLowerCase();
  const attempts = [];
  if (archiveExt === '.zip') {
    attempts.push({ name: 'tar -x（bsdtar 解 zip）', fn: () => run('tar', ['-x', '-f', archive, '-C', tempDir]) });
    attempts.push({ name: 'unzip', fn: () => run('unzip', ['-q', archive, '-d', tempDir]) });
    if (process.platform === 'win32') {
      attempts.push({
        name: 'PowerShell Expand-Archive',
        fn: () => run('powershell', ['-NoProfile', '-NonInteractive', '-Command',
          `Expand-Archive -LiteralPath '${archive.replace(/'/g, "''")}' -DestinationPath '${tempDir.replace(/'/g, "''")}' -Force`]),
      });
    }
  } else {
    attempts.push({ name: 'tar -xzf', fn: () => run('tar', ['-xzf', archive, '-C', tempDir]) });
  }
  for (const attempt of attempts) {
    const result = attempt.fn();
    if (result.status === 0) {
      ok(`解压方式：${attempt.name}`);
      return;
    }
  }
  throw new Error(`解压失败（已尝试：${attempts.map((a) => a.name).join(' / ')}）`);
}

async function waitForHealth(port, timeoutMs = 20000) {
  const deadline = Date.now() + timeoutMs;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/api/health`);
      if (response.ok) return await response.json();
      lastError = new Error(`health HTTP ${response.status}`);
    } catch (error) {
      lastError = error;
    }
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error(`等待健康检查超时（20s）：${lastError?.message ?? 'unknown'}`);
}

async function killChild(child) {
  if (!child || child.exitCode !== null) return;
  await new Promise((resolve) => {
    const timer = setTimeout(() => {
      try {
        if (process.platform === 'win32') run('taskkill', ['/PID', String(child.pid), '/T', '/F']);
        else child.kill('SIGKILL');
      } catch { /* ignore */ }
      resolve();
    }, 2500);
    child.once('exit', () => { clearTimeout(timer); resolve(); });
    try { child.kill(); } catch { clearTimeout(timer); resolve(); }
  });
  if (child.exitCode === null) {
    try { child.kill('SIGKILL'); } catch { /* ignore */ }
  }
}

async function verifyCleanStart(archive, artifactName) {
  stepStart('干净目录启动验证（解压 → 启动 → 请求 → 清理）');
  const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), 'inkproof-verify-'));
  let child = null;
  try {
    await extractPackage(archive, tempRoot);
    const entries = await fs.readdir(tempRoot);
    let extractedRoot = tempRoot;
    if (entries.length === 1) {
      const candidate = path.join(tempRoot, entries[0]);
      const stat = await fs.stat(candidate);
      if (stat.isDirectory()) extractedRoot = candidate;
    }
    ok(`解压目录：${path.basename(extractedRoot)}`);

    // 目录/密钥再确认
    assert(!await exists(path.join(extractedRoot, 'reference')), '解压包内不应有 reference/');
    assert(!await exists(path.join(extractedRoot, 'config/provider.json')), '解压包内不应有 config/provider.json');
    const tmpFiles = (await walkAll(extractedRoot)).filter((f) => path.basename(f).startsWith('.tmp-'));
    assert(tmpFiles.length === 0, `解压包内不应有 .tmp-*：${tmpFiles.join(', ')}`);
    ok('解压包结构：无 reference/、无 config/provider.json、无 .tmp-*');

    const port = await getFreePort();
    child = spawn(process.execPath, [path.join(extractedRoot, 'server', 'server.mjs')], {
      cwd: extractedRoot,
      env: { ...process.env, PORT: String(port) },
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
    });
    let stderr = '';
    child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });

    const health = await waitForHealth(port);
    ok(`GET /api/health → 200，ok=${health.ok} mode=${health.mode} network=${health.network} telemetry=${health.telemetry}`);
    assert(health.ok === true, 'health.ok 必须为 true');
    assert(health.mode === 'mock', '干净启动应为 mock 模式');
    assert(health.network === 'none' && health.telemetry === false, '干净启动应无网络/遥测');

    const rootResponse = await fetch(`http://127.0.0.1:${port}/`);
    const rootText = await rootResponse.text();
    assert(rootResponse.status === 200, `GET / 应 200，实际 ${rootResponse.status}`);
    assert(/<!doctype html>/i.test(rootText), 'GET / 应返回 HTML（app/index.html）');
    ok(`GET / → ${rootResponse.status} ${rootResponse.headers.get('content-type')}（${rootText.length} chars）`);

    const config = await (await fetch(`http://127.0.0.1:${port}/api/config`)).json();
    assert(config.ok === true && config.config.provider === 'mock', 'config 应为 mock');
    assert(config.config.apiKeySet === false, '包内不应带 apiKey');
    ok('GET /api/config → mock，apiKeySet=false');

    const core = await fetch(`http://127.0.0.1:${port}/core/hash-chain.mjs`);
    assert(core.status === 200, 'GET /core/hash-chain.mjs 应 200');
    ok('GET /core/hash-chain.mjs → 200');

    if (stderr.trim()) warn(`服务端 stderr（非致命）：${stderr.trim().slice(0, 300)}`);
    ok('干净目录启动验证：PASS');
    return { pass: true, port };
  } finally {
    await killChild(child);
    if (OPTIONS.keepTemp) {
      warn(`--keep-temp：保留临时目录 ${tempRoot}`);
    } else {
      await new Promise((r) => setTimeout(r, 300));
      await fs.rm(tempRoot, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }).catch((error) => {
        warn(`临时目录清理失败（可手动删除）：${tempRoot}（${error.message}）`);
      });
    }
  }
}

// ---------------------------------------------------------------------------
// 主流程
// ---------------------------------------------------------------------------

function printHelp() {
  log(`用法：node scripts/package.mjs [选项]

  --no-verify   只打包，不做解压启动验证
  --keep-temp   保留解压验证用的临时目录（调试用）
  -h, --help    显示本帮助
`);
}

async function main() {
  log('==============================================');
  log('  Mozheng InkProof · Release packager (v0.1)');
  log('  zero-dependency · local-first · mock AI');
  log('==============================================');

  const nodeMajor = Number(process.versions.node.split('.')[0]);
  assert(nodeMajor >= 22, `需要 Node.js 22+（当前 ${process.version}）`);

  const pkg = await readJson(path.join(PRODUCT_ROOT, 'package.json'));
  const artifactName = `${ARTIFACT_BASENAME}-v${pkg.version}`;
  log(`\n产物：dist/${artifactName}/   版本：${pkg.version}   Node：${process.version}`);

  await fs.mkdir(DIST_DIR, { recursive: true });
  const { artifactDir, files, releaseInfo } = await buildArtifact(artifactName);
  await verifyArtifact(artifactDir, files);
  const archive = await createZip(artifactName);
  const zipSha256 = await sha256File(archive.zipPath);

  // 验证（解压 + 启动）
  let verification = { cleanStart: false, skipped: !OPTIONS.verify };
  if (OPTIONS.verify) {
    verification = { cleanStart: true, ...(await verifyCleanStart(archive.zipPath, artifactName)) };
  } else {
    warn('--no-verify：跳过干净目录启动验证');
  }

  // 清单与校验文件
  stepStart('写出 manifest 与 SHA-256');
  const archiveName = path.basename(archive.zipPath);
  const manifest = {
    name: ARTIFACT_BASENAME,
    product: 'Mozheng InkProof',
    version: pkg.version,
    builtAt: releaseInfo.builtAt,
    node: process.version,
    platform: `${process.platform}-${process.arch}`,
    package: {
      file: archiveName,
      format: archive.format,
      sizeBytes: archive.sizeBytes,
      sha256: zipSha256,
      createdAt: new Date().toISOString(),
    },
    budget: {
      cleanStartVerified: verification.cleanStart,
    },
    notes: releaseInfo.notes,
    files,
  };
  const manifestPath = path.join(DIST_DIR, `${artifactName}.manifest.json`);
  await fs.writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
  const shaPath = path.join(DIST_DIR, `${archiveName}.sha256`);
  await fs.writeFile(shaPath, `${zipSha256}  ${archiveName}\n`, 'utf8');
  ok(`清单：${path.relative(PRODUCT_ROOT, manifestPath)}（${files.length} 个文件）`);
  ok(`校验：${path.relative(PRODUCT_ROOT, shaPath)}`);

  // 汇总
  log('\n==============================================');
  log('  Release 打包完成');
  log('==============================================');
  log(`  目录：dist/${artifactName}/`);
  log(`  压缩包：dist/${archiveName}`);
  log(`  大小：${humanBytes(archive.sizeBytes)}`);
  log(`  SHA-256：${zipSha256}`);
  log(`  清单：dist/${artifactName}.manifest.json（${files.length} files）`);
  log(`  干净启动验证：${verification.cleanStart ? 'PASS（health + root + config + core 均 200）' : 'SKIP'}`);
  log(`  用时：${((Date.now() - t0) / 1000).toFixed(1)}s`);
  log('');
}

if (OPTIONS.help) {
  printHelp();
  process.exit(0);
}

main().catch((error) => {
  console.error('\n✗ 打包失败：', error?.stack ?? error);
  process.exitCode = 1;
});
