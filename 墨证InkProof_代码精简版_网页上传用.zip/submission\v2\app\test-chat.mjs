// v2/app/test-chat.mjs —— 自由对话（Mock）：基于选区/实时状态
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8153;
const out = { schema: 'mozheng.app.chat.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  fs.writeFileSync(ROOT + '\\v2\\app\\test-chat-result.json', JSON.stringify(out, null, 2), 'utf8');
  process.exit(code);
};
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  await page.evaluate(() => { const a = window.__V2_APP__; a.t96.setToggles({ allowReal: false, privacyMode: true }); a.state.selection = { x: 300, y: 240, width: 380, height: 260 }; a.drawSelection(); });
  await page.evaluate(() => window.__V2_APP__.openPopover('popAI'));
  await page.waitForTimeout(300);
  const hasForm = await page.evaluate(() => ({ form: !!document.getElementById('aiChatForm'), input: !!document.getElementById('aiChatInput'), quick: document.querySelectorAll('[data-chat-quick]').length }));
  await page.fill('#aiChatInput', '这里为什么显得平？');
  await page.click('#btnAiChatSend');
  await page.waitForTimeout(1200);
  const chat = await page.evaluate(() => ({ len: window.__V2_APP__.aiChat.length, roles: window.__V2_APP__.aiChat.map((m) => m.role), text: (window.__V2_APP__.aiChat[1] || {}).content || '', rows: document.querySelectorAll('#aiBody .ai-chat-msg').length, meta: (window.__V2_APP__.aiChat[1] || {}).meta || null }));
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-chat-1920.png' });
  out.cases.form = hasForm;
  out.cases.chat = chat;
  out.cases.ok = hasForm.form && hasForm.input && hasForm.quick >= 2 && chat.len === 2 && chat.roles[0] === 'user' && chat.roles[1] === 'assistant' && chat.text.length > 10 && chat.rows >= 2;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.ok && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  await finish(3);
}
