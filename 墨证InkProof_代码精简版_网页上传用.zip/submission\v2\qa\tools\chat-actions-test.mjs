// v2/qa/tools/chat-actions-test.mjs — T112-A chat-actions.mjs 单测（Node，零依赖）
// 运行：node v2/qa/tools/chat-actions-test.mjs   exit 0 = 全过
import assert from 'node:assert/strict';
import {
  CHAT_ACTIONS_VERSION,
  ACTIONS,
  ACTION_TYPES,
  normalizeChatActions,
  validateAction,
  describeAction,
  buildMockActions,
} from '../../app/core/chat-actions.mjs';

const results = [];
function test(name, fn) {
  try { fn(); results.push({ name, pass: true }); }
  catch (e) { results.push({ name, pass: false, error: String(e && (e.stack || e.message || e)) }); }
}
const T = (type, extra = {}) => ({ type, label: extra.label, reason: extra.reason, params: extra.params });

test('0 模块版本/ACTIONS 枚举完整且冻结', () => {
  assert.match(CHAT_ACTIONS_VERSION, /^chat-actions@/);
  assert.deepEqual(ACTION_TYPES, ['observe', 'generate', 'edit', 'adjust', 'reference', 'annotate', 'export']);
  for (const type of ACTION_TYPES) {
    const def = ACTIONS[type];
    assert.ok(def, type);
    assert.equal(def.type, type);
    assert.ok(def.label && typeof def.label === 'string');
    assert.ok(def.description && typeof def.description === 'string');
    assert.ok(def.paramsSchema && typeof def.paramsSchema === 'object');
    assert.ok(Object.keys(def.paramsSchema).length > 0, type + ' 需要白名单');
  }
  assert.equal(Object.isFrozen(ACTIONS), true);
});

test('1 normalize 合法 action：补默认 label、保留 reason/params', () => {
  const out = normalizeChatActions([
    T('observe'),
    { type: 'generate', label: '生成候选', reason: '框外不动', params: { prompt: '保留笔触', count: 2 } },
  ]);
  assert.equal(out.length, 2);
  assert.equal(out[0].type, 'observe');
  assert.equal(out[0].label, '让 AI 看看');
  assert.deepEqual(out[0].params, {});
  assert.equal(out[1].params.count, 2);
  assert.equal(out[1].params.prompt, '保留笔触');
  assert.ok(out.every((a) => typeof a.reason === 'string' && Number.isFinite(a.params ? 1 : NaN)));
});

test('2 normalize 截断 label≤24 / reason≤160；空值安全', () => {
  const longLabel = '一'.repeat(40);
  const longReason = '很'.repeat(300);
  const out = normalizeChatActions([T('observe', { label: longLabel, reason: longReason })], { max: 3 });
  assert.equal(out.length, 1);
  assert.equal(Array.from(out[0].label).length <= 24, true);
  assert.equal(Array.from(out[0].reason).length, 160);
  assert.deepEqual(normalizeChatActions([]), []);
  assert.deepEqual(normalizeChatActions(null), []);
  assert.deepEqual(normalizeChatActions(undefined), []);
  assert.deepEqual(normalizeChatActions('not-array'), []);
  assert.deepEqual(normalizeChatActions({ actions: [] }), []);
});

test('3 normalize 过滤非法类型/缺 type/未知枚举/非对象', () => {
  const out = normalizeChatActions([
    T('hack'),
    T('unknown_action'),
    { label: '缺 type' },
    null,
    'x',
    T('observe'),
  ]);
  assert.deepEqual(out.map((a) => a.type), ['observe']);
  assert.deepEqual(normalizeChatActions([T('script')]), []);
});

test('4 normalize 去重（同 type 只留第一个）与 max=3 硬上限', () => {
  const out = normalizeChatActions([
    T('observe', { reason: '第一次' }),
    T('observe', { reason: '第二次' }),
    T('generate'), T('edit'), T('adjust'), T('reference'), T('annotate'), T('export'),
  ], { max: 10 });
  assert.equal(out.length, 3);
  assert.deepEqual(out.map((a) => a.type), ['observe', 'generate', 'edit']);
  assert.equal(out[0].reason, '第一次');
  assert.deepEqual(normalizeChatActions([T('observe')], { max: 0 }), []);
  assert.equal(normalizeChatActions([T('observe'), T('generate'), T('edit'), T('adjust')], { max: 2 }).length, 2);
});

test('5 normalize 拒绝脚本注入（label/reason/params）', () => {
  const cases = [
    T('observe', { label: '<script>alert(1)</script>' }),
    T('observe', { reason: '点我 javascript:alert(1)' }),
    T('generate', { params: { prompt: '<img src=x onerror=alert(1)>' } }),
    T('generate', { params: { prompt: '<iframe src="x">' } }),
    T('edit', { params: { prompt: 'javascript:alert(1)' } }),
  ];
  for (const c of cases) assert.deepEqual(normalizeChatActions([c]), [], JSON.stringify(c));
});

test('6 normalize 拒绝 URL / 未知 params / 非对象 params', () => {
  assert.deepEqual(normalizeChatActions([T('generate', { params: { prompt: '参考 https://evil.example/a.png' } })]), []);
  assert.deepEqual(normalizeChatActions([T('reference', { params: { fileName: 'www.evil.example/x.png' } })]), []);
  assert.deepEqual(normalizeChatActions([T('generate', { params: { prompt: 'ok', evil: 'xss' } })]), []);
  assert.deepEqual(normalizeChatActions([T('adjust', { params: JSON.parse('{"brightness":0.2,"__proto__":1}') })]), []);
  assert.deepEqual(normalizeChatActions([T('generate', { params: ['not', 'object'] })]), []);
});

test('7 params 白名单/类型/clamp/enum/boolean', () => {
  const out = normalizeChatActions([
    T('adjust', { params: { brightness: 2, contrast: -2, saturation: 9, hue: -999 } }),
    T('export', { params: { format: 'evidence', includeProject: true } }),
    T('generate', { params: { scope: 'selection', count: 99, prompt: 'ok' } }),
    T('generate', { params: { scope: 'bad-scope' } }),
    T('adjust', { params: { brightness: 'NaN' } }),
  ], { max: 5 });
  assert.equal(out.length, 3);
  assert.deepEqual(out[0].params, { brightness: 1, contrast: -1, saturation: 2, hue: -180 });
  assert.equal(out[1].params.format, 'evidence');
  assert.equal(out[1].params.includeProject, true);
  assert.equal(out[2].params.count, 2);
  assert.equal(out[2].params.scope, 'selection');
  // 非法 scope / 非数字参数会使 action 被丢弃（不产生半合法对象）
  assert.equal(out.some((a) => a.params.scope === 'bad-scope'), false);
});

test('8 validateAction：合法/非法/长度/注入/未知 params', () => {
  assert.deepEqual(validateAction({ type: 'observe', label: '让 AI 看看', reason: 'ok', params: {} }), { ok: true, errors: [] });
  assert.deepEqual(validateAction({ type: 'generate', params: { prompt: 'ok', count: 1 } }), { ok: true, errors: [] });
  assert.equal(validateAction({ type: 'hack' }).ok, false);
  assert.equal(validateAction(null).ok, false);
  assert.equal(validateAction({ type: 'observe', label: '一'.repeat(25) }).ok, false);
  assert.equal(validateAction({ type: 'observe', reason: '一'.repeat(161) }).ok, false);
  assert.equal(validateAction({ type: 'observe', label: '<script>x</script>' }).ok, false);
  assert.equal(validateAction({ type: 'generate', params: { prompt: 'https://x.test' } }).ok, false);
  assert.equal(validateAction({ type: 'generate', params: { evil: 1 } }).ok, false);
  assert.equal(validateAction({ type: 'observe', label: 123 }).ok, false);
  const v = validateAction({ type: 'generate', params: { prompt: 'x', evil: 1, foo: 2 } });
  assert.equal(v.errors.length >= 2, true);
  assert.ok(v.errors.every((e) => typeof e === 'string'));
});

test('9 describeAction：可读文案（不执行），非法安全返回', () => {
  const text = describeAction({ type: 'generate', label: '生成局部候选', reason: '框外不动', params: { prompt: '保留笔触', scope: 'selection', count: 2 } });
  assert.ok(text.includes('生成局部候选'));
  assert.ok(text.includes('框外不动'));
  assert.ok(text.includes('保留笔触'));
  assert.ok(text.includes('当前选区'));
  const adj = describeAction({ type: 'adjust', params: { brightness: 0.2, hue: -15 } });
  assert.ok(adj.includes('调整'));
  assert.ok(adj.includes('亮度'));
  assert.ok(adj.includes('色相'));
  const ref = describeAction({ type: 'reference', params: { fileName: '雾中山谷.png' } });
  assert.ok(ref.includes('素材'));
  assert.ok(ref.includes('雾中山谷'));
  assert.equal(describeAction({ type: 'hack' }), '无法执行的建议');
  assert.equal(describeAction({ type: 'generate', params: { prompt: '<script>x</script>' } }), '无法执行的建议');
});

test('10 buildMockActions：observe/generate/reference，截断与安全', () => {
  const withAll = buildMockActions({
    selection: { x: 10, y: 20, width: 300, height: 200 },
    libraryCount: 3,
    referenced: [{ id: 'asset-abc123', fileName: '雾中山谷.png' }],
  });
  assert.equal(withAll.length, 3);
  assert.deepEqual(withAll.map((a) => a.type), ['observe', 'generate', 'reference']);
  assert.ok(withAll[0].params.scope === 'selection');
  assert.equal(withAll[1].params.count, 2);
  assert.equal(withAll[2].params.assetId, 'asset-abc123');
  assert.ok(withAll.every((a) => Array.from(a.label).length <= 24));
  assert.ok(withAll.every((a) => validateAction(a).ok));
  const noSel = buildMockActions({ libraryCount: 2 });
  assert.deepEqual(noSel.map((a) => a.type), ['observe', 'reference']);
  assert.equal(noSel[0].params.scope, 'canvas');
  const empty = buildMockActions({});
  assert.equal(empty.length, 1);
  assert.equal(empty[0].type, 'observe');
  const longName = buildMockActions({ selection: { width: 1, height: 1 }, referenced: [{ id: 'asset-ok', fileName: '超长素材名'.repeat(10) }] });
  assert.ok(longName.every((a) => Array.from(a.label).length <= 24));
});

const failed = results.filter((r) => !r.pass);
console.log(JSON.stringify({ module: CHAT_ACTIONS_VERSION, total: results.length, passed: results.length - failed.length, failed: failed.length, cases: results }, null, 2));
if (failed.length) process.exit(1);
