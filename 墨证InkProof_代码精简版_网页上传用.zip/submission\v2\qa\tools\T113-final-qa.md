# T113 最终独立 QA：素材批量重读 review 闭环

> 执行：qa-engineer（独立 QA｜task-127）｜日期：2026-11-07 22:0x｜只写 `v2/qa/tools/`；**未改 app**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、单浏览器串行、小批次（日志 `archive/baseline-t113-final/logs/`）。

## 结论

**可交付（Deliverable）——P0/P1/P2 = 0。**
新测试 `test-asset-batch` PASS（含 Lead keepAll 修复后复跑）、`asset-batch` 单测 **11/11**、8 项回归全 PASS、0 console error；独立焦点核验 **14/14 PASS + keepAll 修复复核 5/5 PASS**：preflight 不发请求、Mock 0 网络、**真实模式 confirm 后取消 0 请求/0 记录**、keep 恢复快照、adopt 保持新结果、retry 单跑、**adoptAll→keepAll 语义（adopted 也恢复为 kept）**、stop 剩余、按钮显隐、L5 不被覆盖、L6 计数一致、素材库功能正常、密钥无泄漏；证据 mtime 未变、无付费调用、残留 0。

## 1. 新测试与单测

| 测试 | 结果 | 关键证据 |
|---|---|---|
| `test-asset-batch.mjs`（Lead 修复后复跑） | **PASS** | preflight 3 项（`待读`×3、开始按钮可见）；L6 `asset_batch_decompose{mode:mock,total:3,done:3,failed:0,skill:asset.decompose}`；keep 项 L1/tags/source 恢复；adoptAll 后 review `[kept,adopted,adopted]`；0 error |
| `asset-batch-test.mjs`（Node 单测） | **PASS 11/11** | 0 failed |

## 2. 独立焦点核验（14/14 PASS）

| # | 检查 | 结果 |
|---|---|---|
| 1 | **preflight 不发请求** | 打开 review 后 `/api/ai/*` **0**、records 不变、items 全 `planned`、只显示开始按钮 ✅ |
| 2 | **Mock 路径 0 网络** | 开始→完成全程 `/api/ai` **0 次** ✅ |
| 3 | **L6 与 UI 一致** | `mode=mock、total=3、done=3、failed=0、skill=asset.decompose` ✅ |
| 4 | **按钮显隐** | 运行中开始 hidden+disabled、停止可见；完成后停止 hidden、全部采用/全部保留可见 ✅ |
| 5 | **keep 恢复 before** | 批量前变异（L1=`QA-MUTATED-BEFORE`/tags/palette/source）→ 运行覆盖（changed=true）→ keep 后 L1/L2/L4/tags/palette/source **完全恢复** ✅ |
| 6 | **adopt 保持新结果** | adopt 后素材 L1/tags/L2/L4 与 item.result 完全一致 ✅ |
| 7 | **retry 只重跑该项** | 重试完成、**不新增 L6**（records 不变）✅ |
| 8 | **L5 不被覆盖** | 批量前确认的 L5 confirm 决策在运行/采用/保留后数量保持 ✅ |
| 9 | **停止剩余** | 运行中停止：cancelled=true、部分 done/部分 planned、L6 `done=2/total=3`、停止 hidden ✅ |
| 10 | **停止后「全部保留」** | done 项→kept ✅ |
| 11 | **真实模式 confirm→取消** | 4200 页面（config real）：preflight `mode=real`；开始→确认弹窗「按队列串行…Qwen / qwen3.8-max…是否继续？」；点「取消，不发送」→ `/api/ai/*` **0 请求**、records 不变、items 仍 `planned` ✅ |
| 12 | **素材库不回退** | review 关闭后搜索「山」有结果、详情可打开 ✅ |
| 13 | **密钥** | DOM/LS/SS/已加载 JS 无 key ✅ |
| 14 | **console** | 全程 **0 error** ✅ |

### 2.1 Lead keepAll 修复复核（5/5 PASS）

| 检查 | 结果 |
|---|---|
| 全部采用 → 全部保留 | `afterAdoptAll=[adopted×3]` → keepAll → **`[kept×3]`** ✅ |
| keepAll 恢复 before | 每个 adopted 项 L1/tags **精确恢复为 before 快照**（逐项字符串比较一致）✅ |
| keepAll 按钮显隐 | adoptAll 后可见（有 adopted+before）→ keepAll 后隐藏 ✅ |
| keepAll 不新增记录 | records 2→2 ✅ |
| 关闭后重开 | review 可重开、新 plan 全 `planned` ✅ |

## 3. 回归（8 项全 PASS，0 console error）

test-library、test-library-ai、test-app、test-ui、test-ux-p0、test-chat-actions、test-ai-provider、test-interaction-sequences（单跑 9/9）；连同新测试共 **9/9 PASS**。

## 4. 真实证据 / 费用（无新增付费调用）

| 证据 | 核对 |
|---|---|
| `asset-real-read-results.json`（mtime 17:12 未变） | pass=true；22,955ms；real / L2=5 / L4=4 |
| `qwen-real-e2e-results.json`（mtime 16:53 未变） | pass=true；21,337ms；obs=2、regions=2、mock=false |
| 本轮真实请求 | **0**：Mock 全程离线；真实模式仅到 confirm 层并**取消**（0 请求）✅ |

## 5. 密钥 / 残留 / 本地服务

- 密钥：无 DOM/LS/SS/已加载 JS 泄漏；未打印 key。
- 残留：**Edge 0、测试端口 0**。
- `.runtime-port` = **4200**；`http://127.0.0.1:4200/health` → **200** `{ok:true,port:4200,pid:38452}`。

## 6. 问题清单

| # | 级别 | 内容 | 状态 |
|---|---|---|---|
| — | — | P0 / P1 / P2 | **均无**（keepAll 语义问题由 Lead 修复，QA 已复核通过） |

## 7. 产物与归档

- `v2/qa/tools/T113-final-qa.md`（本报告）
- `v2/qa/tools/archive/baseline-t113-final/`：`logs/`、各 result JSON、`focus-results-v2.json`（14 项）、`keepall-results.json`（keepAll 修复复核 5 项）、真实证据 JSON、README
- GATE：`v2/qa/tools/GATE-pw.md`「T113 最终独立 QA」行
