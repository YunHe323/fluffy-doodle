// product/app/js/state.js
// 全局状态 + 轻量工具 + 事件总线（模块间解耦；不依赖任何第三方）。
export const APP_VERSION = '0.1.0';
export const CONTRACT_VERSION = '0.1.0';
export const SCHEMA_VERSION = '0.2.0';
export const DOC_W = 1200;
export const DOC_H = 800;

/** 全局应用状态（唯一可变数据源；模块通过事件总线响应变化） */
export const state = {
  // 项目
  projectId: null,
  projectName: '《雾中山谷》',
  projectCreatedAt: null,
  sessionId: '',
  // 画布 / 图层
  layers: [],
  activeLayerId: null,
  tool: 'brush-hard',
  color: '#e8d7a8',
  size: 18,
  // 交互临时态
  selection: null,
  stroke: null,
  drag: null,
  undoStack: [],
  redoStack: [],
  strokeCount: 0,
  // AI
  mode: 'collab',          // 'collab' | 'attest'
  aiRole: 'assistant',     // 'tool' | 'assistant'
  aiBusy: false,
  generating: false,
  ignoreArchive: false,
  aiReview: null,          // { analyze, directions, model, latencyMs }
  observations: [],        // 展示用观察（含 observed 派生卡）
  directions: [],
  proposals: [],
  selectedDirectionId: null,
  previewProposalId: null,
  committedProposalId: null,
  highlightObsId: null,
  hoverObsId: null,
  // 档案 / 证据
  archive: [],             // L0/L1/L2/L4/L5/L6 记录
  decisions: [],           // L5 记录（UI 便捷视图）
  events: [],              // 哈希链事件
  generations: [],         // L6 AI 派生记录
  modeStartedAt: null,
  // 环境
  hashBackend: '检测中',
  hashAvailable: false,
  loaded: false,
  dirtyLayers: new Set(),
  saveState: 'saved'       // saved | saving | error
};

/* ---------------- 事件总线 ---------------- */
const bus = new EventTarget();
/** 广播应用内事件（detail 任意） */
export function emit(type, detail) {
  bus.dispatchEvent(new CustomEvent(type, { detail }));
}
/** 订阅应用内事件，返回取消订阅函数 */
export function on(type, fn) {
  const handler = (e) => fn(e.detail);
  bus.addEventListener(type, handler);
  return () => bus.removeEventListener(type, handler);
}

/* ---------------- 基础工具 ---------------- */
export const $ = (id) => document.getElementById(id);
let uidCounter = 0;
export function uid(prefix = 'id') {
  uidCounter += 1;
  return `${prefix}-${Date.now().toString(36)}${uidCounter.toString(36)}`;
}
export const nowIso = () => new Date().toISOString();
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function fmtTime(d) {
  const x = d instanceof Date ? d : new Date(d);
  const p = (n) => String(n).padStart(2, '0');
  return `${p(x.getHours())}:${p(x.getMinutes())}:${p(x.getSeconds())}`;
}
export function fmtDateTime(d) {
  const x = d instanceof Date ? d : new Date(d);
  const p = (n) => String(n).padStart(2, '0');
  return `${x.getFullYear()}-${p(x.getMonth() + 1)}-${p(x.getDate())} ${p(x.getHours())}:${p(x.getMinutes())}`;
}
export function fileStamp() {
  const x = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${x.getFullYear()}${p(x.getMonth() + 1)}${p(x.getDate())}_${p(x.getHours())}${p(x.getMinutes())}`;
}
export function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
export function hexToRgba(hex, alpha) {
  let h = String(hex || '#ffffff').replace('#', '').trim();
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  const n = parseInt(h, 16) || 0xffffff;
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${alpha})`;
}
export function bboxArray(rect) {
  return [Math.round(rect.x), Math.round(rect.y), Math.round(rect.w), Math.round(rect.h)];
}
export function normalizeRect(a, b) {
  return {
    x: Math.min(a.x, b.x),
    y: Math.min(a.y, b.y),
    w: Math.abs(a.x - b.x),
    h: Math.abs(a.y - b.y)
  };
}

/* ---------------- UI 轻交互 ---------------- */
export function toast(msg, type = '', ms = 2800) {
  const wrap = $('toastWrap');
  if (!wrap) return;
  const el = document.createElement('div');
  el.className = 'toast ' + (type || '');
  el.textContent = msg;
  wrap.append(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .25s'; }, Math.max(200, ms - 260));
  setTimeout(() => el.remove(), ms);
}
export function setStatusHint(text) {
  const el = $('statusHint');
  if (el) el.textContent = text;
}
export function showCanvasToast(msg, ms = 3200) {
  const el = $('canvasToast');
  if (!el) return;
  el.textContent = msg;
  el.style.display = 'block';
  clearTimeout(showCanvasToast._t);
  showCanvasToast._t = setTimeout(() => { el.style.display = 'none'; }, ms);
}
export function setSaveState(kind, text) {
  state.saveState = kind;
  const el = $('saveState');
  if (!el) return;
  el.className = 'save-state ' + (kind === 'saving' ? 'saving' : kind === 'error' ? 'error' : 'saved');
  el.textContent = text || (kind === 'saving' ? '保存中…' : kind === 'error' ? '保存失败' : '已保存');
}

/* ---------------- 文件 / 画布工具 ---------------- */
export function downloadBlob(filename, blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.append(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1600);
}
export function canvasToBlob(canvas, type = 'image/png') {
  return new Promise((resolve, reject) => {
    try {
      canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error('toBlob 返回空'))), type);
    } catch (e) { reject(e); }
  });
}
export async function canvasToArrayBuffer(canvas) {
  const blob = await canvasToBlob(canvas);
  return blob.arrayBuffer();
}

/* ---------------- 跨模块动作注册（避免循环依赖） ---------------- */
// canvas/layers/archive/evidence/ui 在 init 时把自身函数注册到这里，供其它模块调用。
export const actions = {};
export function register(name, fn) { actions[name] = fn; }
export function call(name, ...args) {
  const fn = actions[name];
  if (typeof fn !== 'function') throw new Error(`action 未注册: ${name}`);
  return fn(...args);
}
