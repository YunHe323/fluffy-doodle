// v2/app/test-roadshow-real.mjs — 真实调用彩排（T119，2026-11-08）
// 与 test-roadshow.mjs 的区别：页面挂在 Node 服务（默认 4211）上，/api/ai/* 代理可用，
// 因此第 3 拍走真实视觉（qwen3.8-max / enable_thinking=false），第 5 拍走 roadshowRealEdit()
// 真实图像编辑（异步 image-generation 带选区参考图），不再使用 Mock 或预置样本。
// 断言：aiRealEligible=true / step3 lastCall.mock=false / step5 appliedReal=true /
//       真实落层 mask 框外像素不变 / 证据包可复核 / 0 console error & pageerror。
// 产物：v2/app/rehearsal-real-{1..6}-*.png、v2/app/test-roadshow-real-result.json
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = Number(process.env.SERVE_PORT || 4211);
const RESULT = path.join(ROOT, 'v2', 'app', 'test-roadshow-real-result.json');
const SHOT = (n, name) => path.join(ROOT, 'v2', 'app', `rehearsal-real-${n}-${name}.png`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = { schema: 'mozheng.app.roadshow-real-test.v1', port: PORT, cases: {}, pass: {}, errors: [], pageErrors: [], consoleErrors: [], aiApiConsole: [] };
let browser = null;
let finished = false;
const finish = (code) => {
  if (finished) return;
  finished = true;
  out.timestamp = new Date().toISOString();
  try { fs.writeFileSync(RESULT, JSON.stringify(out, null, 2), 'utf8'); } catch (e) { /* ignore */ }
  try { if (browser) browser.close(); } catch (e) { /* ignore */ }
  console.log('[REAL-REHEARSAL] pass=' + Object.values(out.pass).filter(Boolean).length + '/' + Object.keys(out.pass).length,
    'failed=' + Object.entries(out.pass).filter(([, v]) => !v).map(([k]) => k).join(','),
    'errors=' + out.errors.length, 'consoleErrors=' + out.consoleErrors.length, 'pageErrors=' + out.pageErrors.length);
  process.exit(code);
};
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_420s'; finish(3); }, 420000);

try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const context = await browser.newContext({ viewport: { width: 1920, height: 1080 }, acceptDownloads: true });
  const page = await context.newPage();
  page.on('pageerror', (e) => out.pageErrors.push(String(e)));
  page.on('console', (m) => {
    if (m.type() !== 'error') return;
    const loc = (m.location && m.location() && m.location().url) || '';
    if (/\/api\/ai\//.test(loc) || /\/api\/ai\//.test(m.text())) { out.aiApiConsole.push(m.text() + (loc ? ' @ ' + loc : '')); return; }
    out.consoleErrors.push(m.text() + (loc ? ' @ ' + loc : ''));
  });

  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
  await page.waitForTimeout(900);

  // 0) 真实调用资格：必须有 token、mode!=mock、hasKey、非隐私模式
  out.cases.eligible = await page.evaluate(() => {
    const app = window.__V2_APP__;
    const st = app.t96.getState();
    return {
      preset: st.preset, config: st.config ? { mode: st.config.mode, hasKey: st.config.hasKey, provider: st.config.provider, model: st.config.model, supports: st.config.supports } : null,
      allowReal: st.allowReal, requireConfirm: st.requireConfirm, privacyMode: st.privacyMode,
      realEligible: st.realEligible, label: st.label,
    };
  });
  out.pass.eligible = !!(out.cases.eligible.realEligible && out.cases.eligible.config && out.cases.eligible.config.mode !== 'mock' && out.cases.eligible.config.hasKey);
  if (!out.pass.eligible) { out.errors.push('真实调用资格不满足：' + JSON.stringify(out.cases.eligible)); finish(2); }

  // 1) 进入路演 → 预置项目
  await page.click('#btnRoadshow');
  await page.waitForFunction("document.getElementById('roadshowBrief') && document.getElementById('roadshowBrief').classList.contains('show')", null, { timeout: 10000 });
  await page.click('#btnRoadshowStart');
  await page.waitForFunction('(() => { const t = window.__V2_APP__ && window.__V2_APP__.t122; if (!t) return false; const s = t.state(); return s.prepared === true || !!s.error; })()', null, { timeout: 180000 });
  await page.waitForTimeout(600);
  out.cases.project = await page.evaluate(() => {
    const s = window.__V2_APP__.t122.state();
    return { prepared: s.prepared, error: s.error, canvas: s.canvas, layers: s.layers, libCount: s.libCount, l6Preset: s.l6Preset, engineHasSelection: s.engineHasSelection, badge: s.badge };
  });
  out.pass.project = !!(out.cases.project.prepared && !out.cases.project.error);
  await page.screenshot({ path: SHOT(1, 'brief'), fullPage: false });

  // 2) 第 1 拍：素材库
  await page.click('#btnRoadshowExec');
  await page.waitForTimeout(900);
  out.cases.step1 = await page.evaluate(() => {
    const s = window.__V2_APP__.t122.state();
    return { step: s.step, libraryOpen: !document.getElementById('librarySheet').hidden, selectedId: window.__V2_APP__.state.library.selectedId };
  });
  out.pass.step1 = !!(out.cases.step1.libraryOpen && out.cases.step1.selectedId);

  // 3) 第 2 拍：真实选区
  await page.evaluate(() => { try { window.__V2_APP__.t71.closeLibrarySheet(); } catch (e) {} });
  await page.waitForTimeout(300);
  await page.click('#btnRoadshowNext');
  await page.waitForTimeout(250);
  await page.click('#btnRoadshowExec');
  await page.waitForTimeout(900);
  out.cases.step2 = await page.evaluate(() => {
    const s = window.__V2_APP__.t122.state();
    return { step: s.step, engineHasSelection: s.engineHasSelection, selection: s.selection };
  });
  out.pass.step2 = !!(out.cases.step2.engineHasSelection && out.cases.step2.selection && out.cases.step2.selection.width > 0);
  await page.screenshot({ path: SHOT(2, 'select'), fullPage: false });

  // 4) 第 3 拍：真实视觉观察（核心：mock 必须为 false）
  await page.evaluate(() => window.__V2_APP__.t122.goto(2));
  await page.waitForTimeout(300);
  const t3 = Date.now();
  await page.click('#btnRoadshowExec');
  await page.waitForFunction('!!window.__V2_APP__.state.analysis', null, { timeout: 120000 });
  await page.waitForTimeout(500);
  out.cases.step3 = await page.evaluate(() => {
    const app = window.__V2_APP__;
    const l6 = app.state.records.filter((r) => r.layer === 'L6' && r.params && r.params.task === 'analyze').slice(-1)[0];
    return {
      observations: ((app.state.analysis && app.state.analysis.observations) || []).length,
      obsTexts: ((app.state.analysis && app.state.analysis.observations) || []).slice(0, 3).map((o) => String(o.text || '').slice(0, 80)),
      lastCall: app.state.aiLastCall ? { mock: app.state.aiLastCall.mock, model: app.state.aiLastCall.model, latencyMs: app.state.aiLastCall.latencyMs, usage: app.state.aiLastCall.usage || null, mode: app.state.aiLastCall.mode } : null,
      l6: l6 ? { l5_refs: (l6.params || {}).l5_refs, memory_used: (l6.params || {}).memory_used, model: l6.model, synthetic: !!l6.synthetic } : null,
    };
  });
  out.cases.step3.wallMs = Date.now() - t3;
  out.pass.step3 = !!(out.cases.step3.observations > 0 && out.cases.step3.lastCall && out.cases.step3.lastCall.mock === false && out.cases.step3.l6 && out.cases.step3.l6.memory_used === true);
  await page.screenshot({ path: SHOT(3, 'observe'), fullPage: false });

  // 5) 第 4 拍：L5 写回（脚本代点，已打标 synthetic，不进正式证据链）
  await page.evaluate(() => window.__V2_APP__.t122.goto(3));
  await page.waitForTimeout(300);
  await page.click('#btnRoadshowExec');
  await page.waitForTimeout(900);
  out.cases.step4 = await page.evaluate(() => {
    const s = window.__V2_APP__.t122.state();
    return { decisions: (s.decisions || []).length, l5Ids: (s.l5Ids || []).length };
  });
  out.pass.step4 = !!(out.cases.step4.decisions > 0 && out.cases.step4.l5Ids > 0);
  await page.screenshot({ path: SHOT(4, 'decide'), fullPage: false });

  // 6) 第 5 拍：走用户真实路径 —— 点「执行本步」触发 rsStepEdit（真实编辑优先、失败显式降级）
  await page.evaluate(() => window.__V2_APP__.t122.goto(4));
  await page.waitForTimeout(300);
  const t5 = Date.now();
  await page.click('#btnRoadshowExec');
  await page.waitForFunction('!!window.__V2_APP__.t122.state().editLayerId', null, { timeout: 180000 });
  await page.waitForTimeout(500);
  out.cases.step5 = await page.evaluate(async () => {
    const app = window.__V2_APP__;
    await new Promise((r) => setTimeout(r, 400));
    const before = await app.engine.getCompositeDataUrl();
    const gen = (app.state.records || []).filter((r) => r.layer === 'L6' && r.kind === 'generation' && r.params && !r.params.preset_sample && !r.params.cached_sample).slice(-1)[0];
    const st = app.t122.state();
    const editLayer = (app.engine.layers || []).find((l) => l.id === st.editLayerId) || null;
    // mask 验证：隐藏编辑层前后合成对比，选区外必须 0 像素变化
    let maskCheck = null;
    if (editLayer) {
      const after = await app.engine.getCompositeDataUrl();
      app.engine.setLayerVisible(editLayer.id, false);
      await new Promise((r) => setTimeout(r, 200));
      const hidden = await app.engine.getCompositeDataUrl();
      app.engine.setLayerVisible(editLayer.id, true);
      await new Promise((r) => setTimeout(r, 200));
      const load = async (u) => { const i = new Image(); i.src = u; await i.decode(); return i; };
      const iA = await load(after), iH = await load(hidden);
      const W = app.engine.width, H = app.engine.height;
      const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
      const ctx = cv.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(iA, 0, 0);
      const dA = ctx.getImageData(0, 0, W, H).data;
      ctx.clearRect(0, 0, W, H); ctx.drawImage(iH, 0, 0);
      const dH = ctx.getImageData(0, 0, W, H).data;
      const sel = st.selection;
      let outside = 0, inside = 0, sampled = 0;
      for (let y = 0; y < H; y += 2) {
        for (let x = 0; x < W; x += 2) {
          sampled += 1;
          const i = (y * W + x) * 4;
          const diff = Math.abs(dA[i] - dH[i]) + Math.abs(dA[i + 1] - dH[i + 1]) + Math.abs(dA[i + 2] - dH[i + 2]) + Math.abs(dA[i + 3] - dH[i + 3]);
          if (diff <= 6) continue;
          const inSel = sel && x >= sel.x && x < sel.x + sel.width && y >= sel.y && y < sel.y + sel.height;
          if (inSel) inside += 1; else outside += 1;
        }
      }
      maskCheck = { outsideChanged: outside, insideChanged: inside, sampled, selection: sel };
    }
    return {
      ok: true,
      appliedReal: !!st.appliedReal,
      appliedPreset: !!st.appliedPreset,
      editSource: st.editSource || null,
      editLayerId: st.editLayerId,
      editLayerName: editLayer ? editLayer.name : null,
      hasMask: !!(editLayer && editLayer.mask && editLayer.mask.exists),
      maskPolicy: st.maskPolicy,
      lastCall: app.state.aiLastCall ? { mock: app.state.aiLastCall.mock, model: app.state.aiLastCall.model, latencyMs: app.state.aiLastCall.latencyMs } : null,
      gen: gen ? {
        id: gen.id, model: gen.model && (gen.model.model || gen.model),
        masked: (gen.params || {}).masked, mask_policy: (gen.params || {}).mask_policy,
        candidate_id: (gen.params || {}).candidate_id, source: (gen.params || {}).source,
        sha256: (gen.params || {}).sha256 || (gen.params || {}).candidate_sha256 || null,
        taskId: (gen.params || {}).task_id || (gen.params || {}).taskId || null,
        bytes: (gen.params || {}).bytes || null, usage: gen.usage || (gen.params || {}).usage || null,
        cost_cny: gen.cost_cny, credits: gen.credits,
      } : null,
      maskCheck,
      layerCount: (app.engine.layers || []).length,
      beforeBytes: Math.round(String(before).length * 0.75),
    };
  });
  out.cases.step5.wallMs = Date.now() - t5;
  const s5 = out.cases.step5;
  out.pass.step5 = !!(
    s5.ok && s5.appliedReal && !s5.appliedPreset && s5.editSource === 'real' &&
    s5.lastCall && s5.lastCall.mock === false &&
    s5.gen && s5.gen.masked === true && s5.gen.mask_policy === 'selection_alpha' &&
    s5.maskCheck && s5.maskCheck.outsideChanged === 0 && s5.maskCheck.insideChanged > 0
  );
  await page.waitForTimeout(600);
  await page.screenshot({ path: SHOT(5, 'apply'), fullPage: false });

  // 7) 第 6 拍：证据包 + 包内复核（PNG 字节哈希）
  await page.evaluate(() => window.__V2_APP__.t122.goto(5));
  await page.waitForTimeout(300);
  await page.click('#btnRoadshowExec');
  await page.waitForFunction('!!window.__V2_APP__.t122.state().verify', null, { timeout: 180000 });
  await page.waitForTimeout(500);
  out.cases.step6 = await page.evaluate(async () => {
    const app = window.__V2_APP__;
    const t = app.t122;
    const s = t.state();
    const pkg = app.state.evidence;
    const reVerify = await t.verifyEvidence();
    const demo = (app.state.records || []).filter((r) => r.synthetic === true || r.preset === true || (r.params || {}).preset_sample === true || (r.params || {}).scripted === true).length;
    const realGen = (app.state.records || []).filter((r) => r.layer === 'L6' && r.kind === 'generation' && r.params && !r.params.preset_sample && !r.params.cached_sample && !r.synthetic);
    return {
      step: s.step,
      verify: s.verify,
      reVerify,
      evidence: s.evidence,
      demoRecordsTotal: demo,
      realGenCount: realGen.length,
      hashPolicy: pkg ? pkg.manifest.hash_policy : null,
      demoExcluded: pkg && pkg.manifest ? pkg.manifest.demo_events_excluded : null,
      layers: pkg ? (pkg.manifest.layers || []).map((l) => ({ name: l.name, png_sha256: l.png_sha256 })) : [],
    };
  });
  const s6 = out.cases.step6;
  out.pass.step6 = !!(
    s6.verify && s6.verify.ok === true &&
    s6.reVerify && s6.reVerify.ok === true &&
    s6.evidence && s6.evidence.eventCount > 0 &&
    s6.realGenCount >= 1
  );
  await page.screenshot({ path: SHOT(6, 'evidence'), fullPage: false });

  // 8) 汇总：真实调用成本与耗时
  out.cases.cost = await page.evaluate(() => {
    const recs = (window.__V2_APP__.state.records || []).filter((r) => r.layer === 'L6' && !r.synthetic && !r.preset && !(r.params || {}).preset_sample && !(r.params || {}).scripted);
    return recs.map((r) => ({ kind: r.kind, task: (r.params || {}).task || null, model: r.model && (r.model.model || r.model), usage: r.usage || (r.params || {}).usage || null, latency_ms: r.latency_ms || null, created_at: r.created_at }));
  });
  out.pass.summary = Object.entries(out.pass).filter(([k]) => k !== 'summary').every(([, v]) => v);
  clearTimeout(hard);
  finish(out.pass.summary ? 0 : 1);
} catch (e) {
  out.errors.push(String(e && e.stack || e));
  clearTimeout(hard);
  finish(2);
}
