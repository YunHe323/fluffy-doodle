// v2/qa/tools/rehearse-final.mjs —— 最终验收彩排：6 拍全流程 + 每拍耗时 + 框外像素 + 证据哈希
import fs from 'node:fs';
import { chromium } from '../node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const out = { schema: 'mozheng.roadshow.final-rehearsal.v1', steps: [], errors: [], pass: false };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto('http://127.0.0.1:4200/v2/app/index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
  await sleep(900);
  await page.click('#btnRoadshow'); await sleep(350);
  await page.click('#btnRoadshowStart');
  await page.waitForFunction('(() => { const t = window.__V2_APP__ && window.__V2_APP__.t122; return !!(t && t.state().prepared); })()', null, { timeout: 60000 });
  await sleep(500);

  const snap = async (i, name) => {
    await page.screenshot({ path: ROOT + '\\v2\\app\\rehearsal-' + String(i + 1) + '-' + name + '.png' });
    const s = await page.evaluate(() => { const t = window.__V2_APP__.t122; const st = t.state(); return { step: st.step, badge: (document.getElementById('roadshowBadge') || {}).textContent, title: (document.getElementById('roadshowStepTitle') || {}).textContent, meta: (document.getElementById('roadshowMeta') || {}).textContent }; });
    return s;
  };

  // 第 1 拍
  let t0 = Date.now();
  await page.evaluate(() => window.__V2_APP__.t122.goto(0));
  await page.click('#btnRoadshowExec'); await sleep(1000);
  out.steps.push({ n: 1, ms: Date.now() - t0, ui: await snap(0, 'brief'), log: '打开档案' });
  // 素材库是模态：看完关闭，再进入下一拍（真实演示由主持人点 ✕ / 空白处）
  await page.evaluate(() => { try { window.__V2_APP__.t71.closeLibrarySheet(); } catch (e) {} });
  await sleep(300);
  // 第 2 拍
  t0 = Date.now();
  await page.evaluate(() => window.__V2_APP__.t122.goto(1));
  await page.click('#btnRoadshowExec'); await sleep(1200);
  out.steps.push({ n: 2, ms: Date.now() - t0, ui: await snap(1, 'select'), log: '真实选区 + 打开 AI' });
  // 第 3 拍（真实视觉）
  t0 = Date.now();
  await page.evaluate(() => window.__V2_APP__.t122.goto(2));
  await page.click('#btnRoadshowExec');
  await page.waitForFunction('!!window.__V2_APP__.state.analysis', null, { timeout: 120000 });
  await sleep(1200);
  const obs = await page.evaluate(() => { const a = window.__V2_APP__.state.analysis; const last = window.__V2_APP__.state.aiLastCall || {}; return { count: (a.observations || []).length, texts: (a.observations || []).map((o) => String(o.text || '').slice(0, 120)), anchors: (a.observations || []).map((o) => o.anchor), mock: last.mock, model: last.model, latency: last.latencyMs }; });
  out.steps.push({ n: 3, ms: Date.now() - t0, ui: await snap(2, 'observe'), obs });
  // 第 4 拍（决定）
  t0 = Date.now();
  await page.evaluate(() => window.__V2_APP__.t122.goto(3));
  await page.click('#btnRoadshowExec'); await sleep(1500);
  const decide = await page.evaluate(() => { const a = window.__V2_APP__; const l5 = (a.state.records || []).filter((r) => r.layer === 'L5'); return { l5: l5.length, kinds: l5.map((r) => r.kind) }; });
  out.steps.push({ n: 4, ms: Date.now() - t0, ui: await snap(3, 'decide'), decide });
  // 第 5 拍（预置样本局部落层 + 框外像素）
  await page.evaluate(async () => {
    const app = window.__V2_APP__;
    const url = await app.engine.getCompositeDataUrl();
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = app.engine.width; c.height = app.engine.height;
    c.getContext('2d').drawImage(img, 0, 0);
    window.__RS_BEFORE2__ = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
  });
  t0 = Date.now();
  await page.evaluate(() => window.__V2_APP__.t122.goto(4));
  await page.click('#btnRoadshowExec'); await sleep(1800);
  const preset = await page.evaluate(() => { const st = window.__V2_APP__.t122.state(); const layers = window.__V2_APP__.engine.getLayers(); const l = layers.find((x) => x.id === st.editLayerId); return { appliedPreset: st.appliedPreset, layerName: l && l.name, layers: layers.length, badge: (document.getElementById('roadshowBadge') || {}).textContent }; });
  const pixels = await page.evaluate(async () => {
    const app = window.__V2_APP__;
    const before = window.__RS_BEFORE2__;
    const url = await app.engine.getCompositeDataUrl();
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = app.engine.width; c.height = app.engine.height;
    c.getContext('2d').drawImage(img, 0, 0);
    const after = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    const s = app.state.selection; let inside = 0, outside = 0, sampled = 0;
    for (let y = 0; y < c.height; y += 4) for (let x = 0; x < c.width; x += 4) {
      const i = (y * c.width + x) * 4;
      const d = Math.abs(after[i] - before[i]) + Math.abs(after[i+1] - before[i+1]) + Math.abs(after[i+2] - before[i+2]);
      const isIn = x >= s.x && x < s.x + s.width && y >= s.y && y < s.y + s.height;
      sampled += 1; if (d > 6) { if (isIn) inside += 1; else outside += 1; }
    }
    return { sampled, insideChanged: inside, outsideChanged: outside };
  });
  out.steps.push({ n: 5, ms: Date.now() - t0, ui: await snap(4, 'apply'), preset, pixels });
  // 第 6 拍（证据）
  t0 = Date.now();
  await page.evaluate(() => window.__V2_APP__.t122.goto(5));
  await page.click('#btnRoadshowExec');
  await page.waitForFunction('!!document.querySelector("#evidenceModal.show")', null, { timeout: 90000 });
  await sleep(1200);
  const ev = await page.evaluate(() => { const p = window.__V2_APP__.state.evidence; return p ? { events: p.manifest.event_count, head: p.manifest.head_hash, png_sha256: p.project.canvas.png_sha256, png_bytes: p.project.canvas.png_bytes, real: p.manifest.ai.real_calls, mock: p.manifest.ai.mock_calls, tokens: p.manifest.ai.total_tokens } : null; });
  out.steps.push({ n: 6, ms: Date.now() - t0, ui: await snap(5, 'evidence'), evidence: ev });
  out.totalMs = out.steps.reduce((n, s) => n + s.ms, 0);
  out.pass = out.steps.length === 6 && out.steps[2].obs && out.steps[2].obs.count >= 2 && out.steps[3].decide.l5 >= 2 && out.steps[4].preset.appliedPreset === true && out.steps[4].pixels.outsideChanged === 0 && out.steps[5].evidence && out.steps[5].evidence.events > 0 && out.errors.length === 0;
  fs.writeFileSync(ROOT + '\\v2\\qa\\tools\\rehearse-final-result.json', JSON.stringify(out, null, 2));
  console.log(JSON.stringify(out, null, 2));
  await browser.close();
  process.exit(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  console.log(JSON.stringify(out, null, 2));
  try { await browser.close(); } catch (err) {}
  process.exit(3);
}
