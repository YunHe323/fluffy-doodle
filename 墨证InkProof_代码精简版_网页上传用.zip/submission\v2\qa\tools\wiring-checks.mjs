// v2/qa/tools/wiring-checks.mjs —— 多模态接线轻量校验（本地假上游，全部 Mock/回环，无真实付费调用）
//
// 覆盖本次修改：
//  1) validateImageRequest：输出 512²–2048²、参考图上限按 2.1 系（10）/其它（3）分支
//  2) dashscopeImageEdit：超过 3 张输入 → 400 too_many_images（不静默截断）
//  3) chat 图片预算：4 张放行、5 张拒绝
//  4) dashscopeImage：seed / negative_prompt / prompt_extend 透传到 DashScope parameters
//
// 只启动一个临时 serve.mjs（PORT=8171 起找空闲端口 + 临时 AI_CONFIG_PATH/AI_TOKEN_PATH），
// 不读写真实 key、不碰 4200 服务、不写 v2/.runtime-port。
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const TOOLS_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(TOOLS_DIR, '..', '..', '..');
const TOKEN = 'wiring-check-token';
const BASE_PORT = 8171;
const RESULT_PATH = path.join(TOOLS_DIR, 'wiring-checks-result.json');

const PNG_B64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Z4z8AAAAASUVORK5CYII=';
const PNG_BUF = Buffer.from(PNG_B64, 'base64');
const IMG = 'data:image/png;base64,' + PNG_B64;

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mozheng-wiring-'));
const configPath = path.join(tmp, 'ai-config.json');
const tokenPath = path.join(tmp, 'ai-token');

const checks = [];
const errors = [];
function check(name, pass, detail) { checks.push({ name, pass: !!pass, detail }); }

// ---------- 假 DashScope 上游（127.0.0.1 only） ----------
let fakePort = 0;
let lastSubmit = null;
const fake = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => { body += c; });
  req.on('end', () => {
    const send = (code, obj) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); };
    if (req.method === 'POST' && String(req.url).includes('/image-generation/generation')) {
      try { lastSubmit = JSON.parse(body || '{}'); } catch (e) { lastSubmit = null; }
      return send(200, { request_id: 'fake-req-1', output: { task_id: 'fake-task-1', task_status: 'PENDING' } });
    }
    if (req.method === 'GET' && String(req.url).startsWith('/api/v1/tasks/')) {
      return send(200, { request_id: 'fake-req-1', output: { task_status: 'SUCCEEDED', results: [{ url: 'http://127.0.0.1:' + fakePort + '/fake-result.png' }] } });
    }
    if (req.method === 'GET' && String(req.url).includes('/fake-result.png')) {
      res.writeHead(200, { 'content-type': 'image/png' });
      return res.end(PNG_BUF);
    }
    send(404, { error: { message: 'not found' } });
  });
});
await new Promise((resolve) => fake.listen(0, '127.0.0.1', resolve));
fakePort = fake.address().port;

const MOCK_CONFIG = { mode: 'mock' };
const FAKE_REAL_CONFIG = {
  mode: 'real',
  provider: 'qwen',
  privacyMode: false,
  dashscopePollMs: 20,
  dashscopeMaxPolls: 5,
  providers: {
    qwen: {
      apiKey: 'fake-key-for-local-wiring-check', // 假 key：imageBaseUrl 指向本地回环，不会产生真实调用
      baseUrl: 'http://127.0.0.1:' + fakePort + '/compatible-mode/v1',
      model: 'qwen3.8-max',
      imageModel: 'qwen-image-3.0',
      imageEditModel: 'qwen-image-3.0-pro',
      imageBaseUrl: 'http://127.0.0.1:' + fakePort,
      imageProtocol: 'dashscope-async',
    },
  },
};
function writeConfig(cfg) { fs.writeFileSync(configPath, JSON.stringify(cfg), 'utf8'); }
writeConfig(MOCK_CONFIG);

// ---------- 临时 serve.mjs ----------
const serve = spawn(process.execPath, [path.join(ROOT, 'v2', 'serve.mjs')], {
  cwd: ROOT,
  env: { ...process.env, PORT: String(BASE_PORT), AI_LOCAL_TOKEN: TOKEN, AI_CONFIG_PATH: configPath, AI_TOKEN_PATH: tokenPath },
  stdio: 'ignore',
});
let actualPort = null;
for (let i = 0; i < 100 && !actualPort; i += 1) {
  for (let p = BASE_PORT; p <= BASE_PORT + 10; p += 1) {
    try { const r = await fetch('http://127.0.0.1:' + p + '/health'); if (r.ok) { actualPort = p; break; } } catch (e) { /* not up */ }
  }
  if (!actualPort) await new Promise((r) => setTimeout(r, 150));
}
if (!actualPort) throw new Error('临时 serve.mjs 未启动（port ' + BASE_PORT + '..' + (BASE_PORT + 10) + '）');

async function api(pathname, payload, opts = {}) {
  const headers = { 'content-type': 'application/json', 'x-ai-token': TOKEN };
  if (opts.confirm) headers['x-ai-confirm'] = 'true';
  const res = await fetch('http://127.0.0.1:' + actualPort + pathname, { method: 'POST', headers, body: JSON.stringify(payload) });
  let json = null;
  try { json = await res.json(); } catch (e) { /* ignore */ }
  return { status: res.status, json };
}

try {
  // ---- 1) 输出尺寸：2048² 通过（mock 路径），SVG 内嵌 Mock 标识 ----
  writeConfig(MOCK_CONFIG);
  const ok2048 = await api('/api/ai/image', { prompt: 'wiring check', size: '2048x2048', count: 1 });
  const cand = ok2048.json && ok2048.json.candidates && ok2048.json.candidates[0];
  let svgText = '';
  try { svgText = Buffer.from(String(cand && cand.imageDataUrl || '').split(',')[1] || '', 'base64').toString('utf8'); } catch (e) { /* ignore */ }
  check('image.2048x2048.accepted', ok2048.status === 200 && ok2048.json && ok2048.json.mock === true && !!cand, { status: ok2048.status, code: ok2048.json && ok2048.json.error && ok2048.json.error.code });
  check('mock.candidate.flags', !!cand && cand.mock === true && /^Mock 占位·未调用模型/.test(String(cand.why || '')) && svgText.includes('MOCK 占位 · 未调用模型'), { why: cand && cand.why, svgHasText: svgText.includes('MOCK 占位 · 未调用模型') });

  // ---- 2) 输出尺寸边界：2049² 拒绝、500×500 拒绝；文案中性 ----
  const over = await api('/api/ai/image', { prompt: 'x', size: '2049x2049' });
  const overErr = over.json && over.json.error || {};
  check('image.2049x2049.rejected', over.status === 400 && overErr.code === 'size_too_large' && /512×512/.test(String(overErr.message)) && /2048×2048/.test(String(overErr.message)) && !/混元/.test(String(overErr.message)), { status: over.status, code: overErr.code, message: overErr.message });
  const under = await api('/api/ai/image', { prompt: 'x', size: '500x500' });
  const underErr = under.json && under.json.error || {};
  check('image.500x500.rejected', under.status === 400 && underErr.code === 'size_too_small' && !/混元/.test(String(underErr.message)), { status: under.status, code: underErr.code, message: underErr.message });

  // ---- 3) 参考图上限：3.0 默认 3 张（4 张拒绝）；2.1 系 10 张（4 张通过） ----
  const refs4 = [IMG, IMG, IMG, IMG];
  const refs30 = await api('/api/ai/image', { prompt: 'x', size: '1024x1024', model: 'qwen-image-3.0', images: refs4, count: 1 });
  const refs30Err = refs30.json && refs30.json.error || {};
  check('refs.3.0.max3', refs30.status === 400 && refs30Err.code === 'too_many_refs' && !/混元/.test(String(refs30Err.message)) && /3/.test(String(refs30Err.message)), { status: refs30.status, code: refs30Err.code, message: refs30Err.message });
  const refs21 = await api('/api/ai/image', { prompt: 'x', size: '1024x1024', model: 'qwen-image-2.1-turbo', images: refs4, count: 1 });
  check('refs.2.1.max10', refs21.status === 200 && refs21.json && refs21.json.mock === true, { status: refs21.status, code: refs21.json && refs21.json.error && refs21.json.error.code });

  // ---- 4) 图像编辑送 4 张 → 400 too_many_images（校验放行 2.1 的 10 张后，编辑自身卡 3 张） ----
  writeConfig(FAKE_REAL_CONFIG);
  const edit4 = await api('/api/ai/image', { task: 'edit', prompt: 'x', size: '1024x1024', model: 'qwen-image-2.1-turbo', images: refs4, count: 1 }, { confirm: true });
  const edit4Err = edit4.json && edit4.json.error || {};
  check('edit.4images.rejected', edit4.status === 400 && edit4Err.code === 'too_many_images' && /最多 3 张输入/.test(String(edit4Err.message)), { status: edit4.status, code: edit4Err.code, message: edit4Err.message, billed: edit4.json && edit4.json.billed });

  // ---- 5) dashscopeImage 参数透传：seed / negative_prompt / prompt_extend=false ----
  lastSubmit = null;
  const genParams = await api('/api/ai/image', { task: 'generate', prompt: 'wiring param check', size: '1024x1024', seed: 1234, negative_prompt: '模糊, 低清', prompt_extend: false, count: 1 }, { confirm: true });
  const p1 = lastSubmit && lastSubmit.parameters || {};
  check('dashscope.parameters.passthrough', genParams.status === 200 && p1.seed === 1234 && p1.negative_prompt === '模糊, 低清' && p1.prompt_extend === false && p1.size === '1024*1024' && p1.watermark === false, { status: genParams.status, parameters: p1, mode: genParams.json && genParams.json.mode });
  check('dashscope.result.candidate', !!(genParams.json && genParams.json.candidates && genParams.json.candidates.length >= 1), { candidates: genParams.json && genParams.json.candidates && genParams.json.candidates.length });

  // ---- 6) prompt_extend 默认 true（不改变现有默认行为） ----
  lastSubmit = null;
  const genDefault = await api('/api/ai/image', { task: 'generate', prompt: 'wiring default check', size: '1024x1024', count: 1 }, { confirm: true });
  const p2 = lastSubmit && lastSubmit.parameters || {};
  check('dashscope.prompt_extend.default_true', genDefault.status === 200 && p2.prompt_extend === true && p2.seed === undefined && p2.negative_prompt === undefined, { status: genDefault.status, parameters: p2 });

  // ---- 7) chat 图片预算：4 张放行、5 张拒绝 ----
  writeConfig(MOCK_CONFIG);
  const chatMsg = (n) => ({ messages: [{ role: 'user', content: [{ type: 'text', text: '看图' }, ...Array.from({ length: n }, () => ({ type: 'image_url', image_url: { url: IMG } }))] }], task: 'chat' });
  const chat4 = await api('/api/ai/chat', chatMsg(4));
  check('chat.4images.accepted', chat4.status === 200 && chat4.json && chat4.json.ok === true, { status: chat4.status, code: chat4.json && chat4.json.error && chat4.json.error.code });
  const chat5 = await api('/api/ai/chat', chatMsg(5));
  const chat5Err = chat5.json && chat5.json.error || {};
  check('chat.5images.rejected', chat5.status === 413 && chat5Err.code === 'budget' && /4张图/.test(String(chat5Err.message)), { status: chat5.status, code: chat5Err.code, message: chat5Err.message });

  // ---- 8) 全程只打本地假上游 / Mock，确认没有真实 DashScope 调用 ----
  check('local.fake.upstream.only', !!(genParams.json && genParams.json.billed === true) && String(genParams.json && genParams.json.provider) === 'qwen', { note: '假上游 127.0.0.1，非真实 DashScope 调用', billed: genParams.json && genParams.json.billed });
} catch (e) {
  errors.push(String(e && e.stack || e));
} finally {
  try { serve.kill(); } catch (e) { /* ignore */ }
  try { fake.close(); } catch (e) { /* ignore */ }
  try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) { /* ignore */ }
}

const failed = checks.filter((c) => !c.pass);
const result = {
  schema: 'mozheng.wiring-checks.v1',
  at: new Date().toISOString(),
  servePort: actualPort,
  checks,
  errors,
  pass: checks.length > 0 && failed.length === 0 && errors.length === 0,
};
fs.writeFileSync(RESULT_PATH, JSON.stringify(result, null, 2), 'utf8');
console.log(JSON.stringify({ pass: result.pass, total: checks.length, failed: failed.map((f) => f.name), errors }, null, 2));
for (const c of checks) console.log((c.pass ? 'PASS' : 'FAIL') + '  ' + c.name + (c.pass ? '' : '  ' + JSON.stringify(c.detail)));
process.exit(result.pass ? 0 : 1);
