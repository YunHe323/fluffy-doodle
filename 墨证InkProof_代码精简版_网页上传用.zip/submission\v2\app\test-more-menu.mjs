// v2/app/test-more-menu.mjs —— 更多菜单 4 组结构 + 关键动作可达
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8170;
const out = { schema: 'mozheng.app.more-menu.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-more-menu-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(900);
  await page.click('#btnMore'); await page.waitForTimeout(300);
  out.cases.menu = await page.evaluate(() => {
    const m = document.getElementById('popMore'); const r = m.getBoundingClientRect();
    const groups = [...document.querySelectorAll('#popMore .more-group')].map((g) => g.querySelector('.more-group-title').textContent.trim());
    const buttons = [...document.querySelectorAll('#popMore .more-group-body button')].map((b) => b.id).filter(Boolean);
    return { groups, buttons, width: Math.round(r.width), height: Math.round(r.height), bottom: Math.round(r.bottom), viewport: innerHeight, scrollable: (() => { const b = m.querySelector('.pro-pop-body'); return b.scrollHeight > b.clientHeight + 1; })() };
  });
  await page.click('#btnAdjustLayer'); await page.waitForTimeout(300);
  out.cases.adjust = await page.evaluate(() => ({ modal: !!document.querySelector('#adjustModal.show') }));
  await page.click('[data-close="adjustModal"]');
  await page.click('#btnMore'); await page.waitForTimeout(200);
  await page.click('#btnCanvasResize'); await page.waitForTimeout(300);
  out.cases.resize = await page.evaluate(() => ({ modal: !!document.querySelector('#canvasResizeModal.show'), title: (document.getElementById('canvasResizeTitle') || {}).textContent }));
  await page.click('[data-close="canvasResizeModal"]');
  out.cases.quick = await page.evaluate(() => ({ visible: !document.getElementById('quickStart').hidden, actions: [...document.querySelectorAll('#quickStart [data-qs]')].map((b) => b.dataset.qs) }));
  out.cases.ok = out.cases.menu.groups.length === 4 && out.cases.menu.buttons.length >= 16 && out.cases.menu.width === 440 && out.cases.menu.bottom <= out.cases.menu.viewport + 1 && out.cases.adjust.modal && out.cases.resize.modal && out.cases.resize.title === '画布尺寸' && out.cases.quick.actions.length === 2;
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.ok && out.cases.noErrors;
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-more-menu-1366.png' });
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
