# v2/brushes · 10 种笔刷 + 动态 + 纹理 + Brush Studio（T36 → T43 手感版）

> 交付：T36（初版）｜**T43（笔刷手感专项：接管 / 真实浏览器验收 / 手感调优 / Klecks 对照）**
> 写入范围：`v2/brushes/`（**未修改** `v2/engine/`、`v2/app/`，只读使用其 Stroke / StrokePaintProvider 接口）
> 手感报告（问题/改法/前后对比/剩余限制）：[`手感报告.md`](./手感报告.md)

## 0. 运行（必须 HTTP，WASM 不支持 file://）

```powershell
# 项目根目录
node v2/serve.mjs          # 或 python -m http.server 4200 --bind 127.0.0.1
# Brush Studio demo：
#   http://127.0.0.1:4200/v2/brushes/demo.html
#   http://127.0.0.1:4200/v2/brushes/demo.html?debug=1   ← 右下角实时状态角标（CanvasKit/provider/pointerdown/undo/画布尺寸）
```

- 零第三方运行时依赖（CanvasKit 来自 `v2/engine/vendor/`，BSD-3，见其 LICENSE/NOTICES）。
- 直接双击 `demo.html` 会显示红色「请用 start.bat / http 打开」横幅（file:// 下 ESM/WASM 被浏览器拦截，属预期）。
- 真实浏览器要求：Edge/Chrome（WebGL2 + WASM）。

## 1. 交付清单

```
v2/brushes/
├─ demo.html                     # 一页画布：10 笔刷切换 + Brush Studio 11 项参数 + 绘制/undo/redo/清空/导出 PNG
│                                # + file:// 红色横幅 + ?debug=1 状态角标 + window.__BRUSH_DEBUG__()
├─ samples.html + build-samples.mjs  # 样例图生成（零依赖 CDP；headless Chrome + 真实 GPU）
├─ test-demo.mjs                 # demo 冒烟（10 按钮/11 滑杆/pointer 绘制/截图，零 console error）
├─ src/brush-controller.js       # 动态引擎：StrokePaintProvider（radiusFor/paintFor/stampFor）+ BrushController + 输入接入
├─ src/mouse-pressure.js         # T54：鼠标模拟压感（速度+加速度+方向→pressure；可配置；pen 时真实压力优先）
├─ schema/brush.schema.json      # 笔刷预设 JSON Schema（T43 texture.roll/tip.followStroke；T52 pathEngine/perfectFreehand）
├─ presets/defaults.json         # 10 种笔刷默认参数（T43 手感重调；生成脚本 tools/tune-presets.mjs）
├─ textures/                     # 8 张自制 tileable 灰度纹理 + alpha-mask 变体 + manifest + 生成脚本
├─ samples/                      # sheet.png（10 画笔总览）+ smudge-compare.png + 各测试 JSON/截图
├─ THIRD_PARTY_NOTICES.md        # 第三方登记（T52 perfect-freehand MIT / 参考未复制清单）
├─ vendor/
│  ├─ perfect-freehand.js        # T52：perfect-freehand 1.2.3 ESM（MIT，原样 vendor + 版权头）
│  └─ perfect-freehand.LICENSE.txt
├─ tools/
│  ├─ validate-presets.mjs       # 零依赖校验：schema 子集 + 压力曲线单调 + 纹理引用 + 10 笔刷
│  ├─ tune-presets.mjs           # T43 调参表（生成 presets/defaults.json，含每笔刷调参注释）
│  ├─ make-sample-sheet.py       # 样例裁切/拼标签（Pillow）
│  ├─ real-browser-smoke.mjs     # 默认 headless：10 笔刷可绘 + 墨迹像素 + 截图（--headed 才开窗且移出屏幕）
│  ├─ live-render-test.mjs       # T44 验收：拖动中可见（live shot）/松手提交/再画不白板/橡皮 live-vs-commit（默认 headless）
│  ├─ visibility-probe.mjs       # 数据 ink / WebGL backbuffer / 截图 present 三口径定位「画了看不见」（默认 headless）
│  ├─ continuity-ab.mjs + .html  # T41 旧实现 vs T43 新实现 的连续性 A/B（默认 headless）
│  ├─ klecks-compare.mjs         # 与 Klecks(MIT) 参考实现同场景对照（默认 headless）
│  ├─ path-engine-ab.mjs + .html # T52：bezier vs perfect-freehand 同场景 A/B（默认 headless）
│  ├─ mouse-pressure-ab.mjs + .html # T54：鼠标模拟压感 on/off 对照（默认 headless）
│  ├─ make-continuity-sheet.py   # A/B sheet + 断点/覆盖/粗细跳变指标
│  ├─ make-klecks-sheet.py       # Klecks 对照 sheet + 指标
│  ├─ make-path-engine-sheet.py  # T52 对照 sheet + 指标（samples/perfect-freehand-compare.png）
│  ├─ make-mouse-pressure-sheet.py # T54 对照 sheet + 指标（samples/mouse-pressure-compare.png）
│  ├─ uniformity-harness.mjs     # T59：Playwright 复测（S1/S2 密度 CV + 真线宽 CV；复用 v2/qa/node_modules）
│  ├─ uniformity-probe.mjs       # T59：多参数诊断（CDP headless）
│  ├─ make-uniformity-sheet.py   # T59 对照 sheet + metrics（samples/uniformity-ab.png）
│  ├─ smudge-test.mjs           # T62 涂抹验收：像素拖动/live/undo/切回画笔 + 样例（headless）
│  ├─ make-smudge-sheet.py      # T62 涂抹对照 sheet + metrics（samples/smudge-compare.png）
│  └─ legacy/brush-controller.t41.js  # 归档：T43 改写前实现，仅用于 A/B
├─ 手感报告.md                    # T43/T52/T54 主交付报告
└─ README.md
```

验证命令：

```bash
node v2/brushes/tools/validate-presets.mjs        # ✓ 10 brushes / curves valid
node v2/brushes/build-samples.mjs                 # 生成 samples/_sheet-raw.png（需本地 Chrome）
<bundled python> v2/brushes/tools/make-sample-sheet.py   # 裁切 + 标签 → samples/sheet.png
node v2/brushes/tools/real-browser-smoke.mjs       # 真实 Edge：10 笔刷可绘 + 截图 + JSON（需先起服务）
node v2/brushes/tools/live-render-test.mjs         # 真实 Edge：拖动中可见/提交/不白板（T44 验收）
node v2/brushes/tools/continuity-ab.mjs            # 旧 vs 新 连续性 A/B
node v2/brushes/tools/klecks-compare.mjs           # 与 Klecks 同场景对照（headless）
node v2/brushes/tools/path-engine-ab.mjs           # T52：bezier vs perfect-freehand A/B（headless）
node v2/brushes/tools/mouse-pressure-ab.mjs        # T54：鼠标模拟压感 on/off + 指标（headless）
node v2/brushes/tools/uniformity-harness.mjs       # T59：S1/S2 均匀度 Playwright 复测（headless，需 v2/qa/node_modules）
node v2/brushes/test-demo.mjs                      # headless demo 冒烟
```

> 自动化规范：以上浏览器测试**默认 headless=new + 真实 GPU（不弹窗）**；确需可见证据时加 `--headed`，
> 窗口会自动移到屏幕外 (`--window-position=-3000,-3000`) + 最小化，跑完 `taskkill /T` 清理。

## 2. 11 种笔刷（T43 调参后；T62 新增涂抹）

| # | id | 中文名 | 类型 | 关键参数（size / spacing / hardness / flow / 纹理） | 手感要点 |
|---|---|---|---|---|---|
| 1 | hard-round | 硬边圆笔 | 基础 | 36 / 0.05 / 0.92 / 1.0 / — | 压力主要影响尺寸，轻压细而实；起笔收锋 5%/14% |
| 2 | soft-round | 软边圆笔 | 基础 | 56 / 0.07 / 0.40 / 0.66 / — | 软边过渡，叠色可控 |
| 3 | pencil | 铅笔 | 纹理 | 8 / 0.035 / 0.66 / 0.90 / pencil-noise（1:1，滚动 0.35） | 纸张颗粒、倾斜加宽、速度变淡 |
| 4 | airbrush | 喷枪 | 空气 | 110 / 0.10 / 0.02 / 0.22 / — | 低流量慢叠色，3 dab 散射，长收锋 30% |
| 5 | chalk | 粉笔 | 干画 | 46 / 0.09 / 0.58 / 0.65 / chalk（滚动 0.5） | 干颗粒、倾斜/速度动态 |
| 6 | charcoal | 炭笔 | 干画 | 64 / 0.10 / 0.52 / 0.68 / grain-coarse（滚动 0.6） | 椭圆笔尖随笔画方向 + 粗颗粒 multiply |
| 7 | ink-liner | 墨水线稿 | 基础 | 4 / 0.03 / 1.0 / 1.0 / — | 稳定化 0.5 + 追尾；速度→线宽；收锋 16% |
| 8 | marker | 马克笔 | 基础 | 34 / 0.06 / 0.80 / 0.60 / canvas-weave（stationary） | 扁椭圆笔尖、叠色半透明 |
| 9 | watercolor | 水彩 | 湿画 | 96 / 0.12 / 0.12 / 0.42 / watercolor-granulation（1:1 + 滚动 0.15） | 沉淀颗粒 + 软边 + 3 dab 散射（近似湿边） |
| 10 | eraser | 橡皮 | 基础 | 44 / 0.07 / 0.92 / 1.0 / — | 压感尺寸；T44 引擎 live 白 mask + DstOut |
| 11 | smudge | 涂抹 | 工具 | 64 / 0.035 / — / 0.55 / — | T62：当前图层 tile 快照取样 + 按笔触方向拖动像素 + 湿边；参数 `smudge.strength/flow/softness/drag` |

参数模型（完整字段见 `schema/brush.schema.json`）：`size/opacity/flow/hardness/spacing/tip/scatter/colorDynamics/texture/smoothing/taper/dynamics/performance`。
压力曲线固定 5 点（x=[0,.25,.5,.75,1]），要求 0–1 非递减。
T43 新增：`texture.roll`（0–2，纹理随笔画滚动强度）、`tip.followStroke`（椭圆笔尖是否随笔画方向）。
T52 新增：`pathEngine`（`'bezier'` 默认 / `'perfect-freehand'` opt-in）、`perfectFreehand`（thinning/smoothing/streamline/size，见 §8）。
T62 新增：`engine.smudge`（涂抹模式）、`smudge.{enabled,strength,flow,softness,drag}`、`category:'tool'`（见 §11）。

## 3. 动态引擎实现要点（`src/brush-controller.js`）

- **T41 注入接口**：`createProviderFromPreset()` 实现 `radiusFor/paintFor/stampFor` + `begin/end/cancel/dispose`，
  由 `engine.setBrushProvider()` 注入；笔画事务 / tile patch / undo 全由 engine 负责。
  T44 起额外暴露 `eraser === true` 与 `isEraser()`，让引擎用 live layer + DstOut 做橡皮实时预览。
- **输入预处理**（controller）：
  - 原始 pointer 速度 EMA（`noteInputSpeed` 注入 provider；鼠标权重 0.35，避免与速度压感模拟重复）；
  - 位置 EMA 稳定化（`stabilizer` 越大越平滑），**收笔追尾**把最后一段补到真实笔尖；
  - **贝塞尔路径平滑 + 弧长间距重采样**：相邻点用过点相切方向 + 1/4 弦长控制点连三次贝塞尔
    （思路参考 Klecks MIT `BezierLine`，自研实现未复制代码），stamp 沿曲线按弧长分布，间距在段间线性过渡；
  - 散射：每 dab α 按 1/√count 归一，位置抖动按当前半径；
  - 收笔收锋：engine `provider.end` 无 canvas → 在 `endStroke()` 前缩放本笔 `records` 尾部 radius（+taperAlpha），
    只操作本笔临时对象，不改 engine；README/报告记为「待引擎正式接口替代」的临时方案。
- **provider 每 stamp**：压力/速度/倾斜 → 尺寸/不透明度/流量；硬度 → MaskFilter blur；
  椭圆笔尖 rotate+scale；纹理按 alpha-mask shader + ColorFilter Modulate 着色；
  **纹理 tile 坐标补偿**（`ctx.isTile` 时 shader 矩阵加 tile 偏移）保证「实时/提交」纹理一致；
  `texture.roll` 时按累计距离/方向平移纹理采样（8px 量化 + 环形缓存）。
- **确定性**：每 dab 角度/亮度抖动用 `hash01(index)`（同一 stamp 在 live 与提交重放中一致）。

## 4. 与引擎接口的对齐（T41/T44）

- `StrokePaintProvider` ctx 透传字段全部使用：`pressure/tiltX/tiltY/velocity/distance/timestamp/elapsed/index/pointerType/isTile/tileX/tileY/radius`。
  其中 **`ctx.velocity` 由引擎按重采样点计算（段内 dt=0 → 恒为 0）**，故速度动态改由 controller 注入（见 §3）。
- 引擎 live 与 tile 两套 canvas：provider 对 shader 做 tile 偏移补偿；blur 用 device 空间（`respectCTM=false`），
  两套 1:1 坐标下表现一致（`手感报告.md` §6 有实测）。
- **仍需引擎侧改动（已报 Lead，未自行改 engine）**：
  1. `provider.end(ctx)` 无 canvas / 无 per-record 覆盖能力 → 收笔收锋只能用 records 临时方案；
  2. 引擎 `_renderLiveFrame` 每帧全量合成（T44/T46 进行中）时，live 层与提交层的一致性依赖本模块的确定性；
  3. 若引擎后续提供「提交前回调/离屏 canvas」，收锋与涂抹（smudge）可正式实现。

## 5. 纹理素材（自制，许可清晰）

- 8 张 256×256 8-bit 灰度、**严格 tileable**（FFT 周期滤波/环绕绘制，seed=20261106）；另有 8 张 `*-mask.png`（RGBA alpha=颗粒）。
- 来源/生成：`textures/generate_textures.py`（numpy+Pillow；仅资产生成时用）；清单：`textures/manifest.json`。
- **许可：随项目 MIT（自制，无第三方素材、无 GPL）**。
- T43 纹理 scale 语义改为「1 = 1 纹素/画布像素」（T36 为 0.22/scale 的 4.5× 放大，颗粒会糊成大斑块）。

## 6. 已知限制（T43 范围内）

1. **收笔收锋为临时方案**：`provider.end` 接口限制，通过 engine `currentStroke.records` 缩放尾部 radius 实现；
   若引擎改 `Stroke` 内部结构需同步（已在报告风险里列出）。上游已提议提供提交前 canvas 回调。
2. **水彩仍为近似湿边**（软边 + 沉淀纹理 + 散射），非流体扩散；`wetness` 参数已建模但引擎无湿边算法。
3. **涂抹笔刷未交付**（`smudge` 字段预留）；需要引擎提供像素采样/混合接口。
4. **橡皮为 tile 层 Clear**，不擦其他图层（符合预期）；跨图层擦除/Alpha Lock 需图层/选区模块。
5. **P3 真实手绘板未验证**（用户暂无可测设备）：pressure/tilt 代码路径已在 CDP pen 事件下验证透传，
   真实手感（压感曲线、倾斜角）待硬件回归。
6. **纹理 shader 缓存**：滚动模式按 8px 量化缓存（上限 512，超限清空重来）；极端长笔画+大颗粒纹理时有重建开销。
7. **纹理笔刷的实时光栅化与提交重放**：默认采用同一确定性 hash；如未来引擎改变 live 合成路径（如抽帧），需回归。
8. 真实浏览器性能未做正式 bench（stamp 数随 spacing 增加）；引擎 tile/undo 内存限制继承。

## 7. 真实浏览器验收（T43）

| 测试 | 结论 |
|---|---|
| `real-browser-smoke.mjs`（Edge 156 非 headless，RTX 4060 D3D11） | 10/10 笔刷可绘；mouse 墨迹 +28,164 px；0 console error；截图与 JSON 见 `samples/` |
| `live-render-test.mjs`（T44 拖动中可见） | 10/10 live 可见、10/10 提交可见、再画不白板、无卡死；橡皮 live 擦除可见、提交一致；ok=true |
| `continuity-ab.mjs`（旧 vs 新，同一输入） | 快速 S 形断块 1/1、覆盖 97.5%→**100%**；线宽 CV 0.030→0.032（持平）；慢速曲线 100%/100% |
| `klecks-compare.mjs`（Klecks MIT 参考） | 快速 S 覆盖 100% vs 92.2%；线宽 CV 0.090–0.140 vs 0.205–0.375；短点 100%；见 `samples/klecks-compare.png` |
| `path-engine-ab.mjs`（T52 bezier vs perfect-freehand） | 覆盖/断块持平，慢速曲线 CV 略优；append CPU 成本同量级；见 `samples/perfect-freehand-compare.png` |
| `mouse-pressure-ab.mjs`（T54 模拟压感 on/off） | 慢/中/快均值 22.3 / 13.7 / 6.3px（ON）vs 15.9 / 15.9 / 15.9px（OFF）；见 `samples/mouse-pressure-compare.png` |
| `smudge-test.mjs`（T62 涂抹） | 8/8：拖动 diff 24,967px（白→墨 24,832）、拖动中 live 可见（截图 diff 968）、undo diff=0、切回画笔可画、0 error；见 `samples/smudge-compare.png` |
| `file://` 直接打开 | 引擎不初始化（停在「加载 CanvasKit…」）、红色横幅正常显示、0 console error → 预期行为 |

## 8. T52 · perfect-freehand(MIT) 可选路径引擎（**默认关闭**）

> 背景：用户要求「用好 GitHub 宝库」。perfect-freehand 1.2.3（MIT，~5KB ESM 零依赖）专做带压感自由笔迹轮廓。
> **默认仍走 bezier（T43 自研），不改变现有默认笔刷观感**；用户试用 + 重新过 GATE 后才决定是否把
> hard-round / pencil / ink-liner 默认切到 perfect-freehand。

### 8.1 接入

- **vendor**：`vendor/perfect-freehand.js`（npm `perfect-freehand@1.2.3` 的 `dist/esm/index.mjs` 原样 + 来源/版权头），
  `vendor/perfect-freehand.LICENSE.txt`，登记 `THIRD_PARTY_NOTICES.md`。核⼼代码未修改。
- **开关**：
  - `new BrushController(engine, preset, { pathEngine: 'perfect-freehand' })`；
  - 运行中：`controller.setPathEngine('perfect-freehand' | 'bezier')`；
  - demo：Brush Studio 底部「PF 轮廓」勾选框（默认不勾 = bezier）；
  - preset 字段：`pathEngine`（默认 `'bezier'`）+ `perfectFreehand: { thinning, smoothing, streamline, size? }`（已登记在
    hard-round / pencil / ink-liner，切换时生效）。
- **实现要点（provider 轮廓模式）**：
  - `getStroke(points, {size, thinning, smoothing, streamline, start/end taper, last})` 生成轮廓多边形；
  - live：节流重绘（每 ~3 点或移动 >10px 才 `clear`+整笔重画），控制 O(n²) 开销；
  - 提交：按 tile 重放时每个 tile 只画一次完整轮廓，世界坐标→tile 局部平移；纹理 shader 已做 tile 偏移补偿；
  - 宽度归一：`sizeScale=0.62`，使 PF 中压力线宽≈bezier；起收锋由 PF `start/end.taper` 原生实现
    （不再依赖 records 临时方案）；橡皮仍走 stamp 模式（live DstOut）。
- **回退**：`pathEngine:'bezier'`（默认）或 preset 缺省即旧行为；`--headed`/离线均零影响。

### 8.2 A/B 对照（同一输入：慢速曲线 / 快速 S 形 / 轻压 / 重压 / 短点）

数据：`samples/pf/metrics.json` + `samples/pf/ab-data.json`；图：`samples/perfect-freehand-compare.png`。

| 笔刷 | 指标（慢速曲线 / 快速 S / 轻压 / 重压） | bezier | perfect-freehand |
|---|---|---|---|
| hard-round | 覆盖 / 断块 | 100% / 3 / 1 / 1 | 100% / 3 / 1 / 1 |
| hard-round | 线宽 CV | 0.212 / 0.140 / 0.084 / 0.028 | **0.172** / 0.170 / 0.076 / 0.073 |
| pencil | 线宽 CV | 0.252 / 0.123 / 0.191 / 0.081 | **0.177** / 0.143 / **0.173** / 0.114 |
| ink-liner | 线宽 CV | 0.213 / 0.182 / 0.203 / 0.153 | 0.237 / 0.217 / **0.166** / 0.155 |
| 全部 | `controller.append()` 总 CPU（5 场景） | 55.6 / 180.8 / 107.7 ms | 64.8 / 121.6 / 78.1 ms |
| 全部 | live vs commit 像素差（慢速曲线） | 0.06–0.17% | 0.02–0.60% |

结论：**覆盖/断块持平**，慢速曲线与铅笔的线宽稳定性略优（CV 更低），append CPU 成本同量级；
PF 的起收锋为短锥/斜切、圆点略大，live/commit 差略高（来自收锋与节流）。
→ 综合判断「值得作为可选引擎，但暂不改默认」；默认仍 bezier，等用户试用 + GATE 复测后决定。

### 8.3 T52 限制

1. 轮廓为**单次填充**：不透明度不随压力分段（对比度主要靠宽度），与 stamp 叠加观感略有差异；
2. live 重绘有节流（每 ~3 点或 10px），极端快速笔画实时预览最多滞后 ~10px；
3. 纹理在一整条轮廓上单次采样（无 stamp 重叠累积），颗粒观感与 bezier 模式不同；
4. 端点形态（短锥/斜切）可通过 `start/end.taper`、`cap` 调整，尚未做成 Brush Studio 参数；
5. 橡皮不走 PF（保持 live DstOut）；如后续要 PF 橡皮需引擎提供路径擦除合成。

## 9. T54 · 鼠标模拟压感（**默认开启**）

> 用户试用反馈：「可以，不过因为是鼠标，不能很好体现粗细变化。」用户已确认采用「速度模拟压感增强」，
> 手绘板（P3）暂缓。

### 9.1 接口（app 面板由 demo-builder T55 接）

```js
controller.setSimulatedPressure({
  enabled: true,        // 开关（关闭=常量 0.5，不做速度映射）
  strength: 1.0,        // 强度 0–2（越大粗细差越明显）
  curve: 'soft',        // 'linear' | 'soft' | 'strong'（strong 更快变细）
  smoothingMs: 45,      // 压力 EMA 时间常数（0–300ms）
}); // → 返回归一化后的完整配置
controller.getSimulatedPressure(); // 读取当前配置
```

- **pen 优先**：`pointerType === 'pen'` 时直接使用真实 `e.pressure`，不经过模拟器（CDP pen force 回归：0.72→0.72）。
- 模型：`speed(px/ms)` 归一 → 曲线 → `1 - strength*shape(s)`；叠加加速度（加速略细 / 减速略粗）与方向变化（急转略细）；
  起笔 90ms 缓入；时间常数 EMA（与事件率无关）。实现：`src/mouse-pressure.js`（纯函数，无 DOM 依赖）。

### 9.2 Demo 调参 + 粗细演示

- Brush Studio 新增：**模拟压感开/关、强度 0–2、曲线（线性/柔和/强烈）、平滑 0–300ms**；
- **「粗细演示」按钮**：自动用合成 PointerEvent 画 3 条不同速度的线（慢/中/快），直观看到粗细变化
  （示例：慢 ~22px / 中 ~14px / 快 ~6px）。

### 9.3 A/B 对照（同一组鼠标轨迹）

产物：`samples/mouse-pressure-on.png` / `samples/mouse-pressure-off.png` / `samples/mouse-pressure-compare.png`
+ `samples/mouse-pressure/metrics.json`；工具：`tools/mouse-pressure-ab.mjs`（headless）。

| 轨迹 | ON 均值线宽 | ON CV | OFF 均值线宽 | OFF CV |
|---|---|---|---|---|
| 慢速直线 | **22.3 px** | 0.111 | 15.9 px | 0.061 |
| 中速直线 | **13.6 px** | 0.139 | 15.9 px | 0.061 |
| 快速直线 | **6.3 px** | 0.124 | 15.9 px | 0.061 |
| 变速 S 形 | **18.6 px** | **0.235** | 16.0 px | 0.061 |

结论：ON 时慢/快线宽差 **3.5×**（22.3 vs 6.3px），OFF 几乎恒定（15.9 vs 15.9px）；S 形 CV 0.235 vs 0.061。
满足「慢粗快细、起收笔缓入缓出」，且 pen 真实压力不被覆盖。

### 9.4 限制

1. 是**模拟**压感，不替代真实手绘板压感；倾斜（tilt）仍只对 pen 生效。
2. 鼠标速度由事件采样估计，极低事件率（<30Hz）或远程桌面下粗细会略显块状（平滑参数可调）。
3. 关闭时压力为常量 0.5（不是回到旧的速度映射），保证「关=完全中性」。
4. 与 app 面板的持久化（localStorage）由 T55 负责；本目录只暴露接口。

## 10. T59 · 均匀度（S1/S2 线宽 CV）——**默认行为不变，改进为 opt-in**

> QA T51 Playwright 对比发现 ours-brushes 的 S1/S2 密度 CV 高于 Klecks（0.34/1.70 vs 0.16/1.25）。
> **用户试用期间默认笔刷行为/接口保持不变**，T59 改进只作为 `setSimulatedPressure` 的可选内部开关。

### 10.1 诊断结论

1. **主因是模拟压感的瞬时速度估计**：Playwright 事件间隔抖动（12ms 目标实际 28–47ms）被 `dt` 除法放大成速度噪声，
   再映射到线宽 → 线宽沿笔画 ripple（T59 trace：压力 0.08–0.52 波动）。
2. **QA 的 `thicknessCV` 口径跨笔刷宽度不可比**：它用 12 个 ±44px 窗口的「非背景像素密度」，
   把抗锯齿/中灰都算作墨；我们的硬边圆笔默认 36px（实测线宽约 16–20px），Klecks 默认笔约 3–4.5px。
3. **S1 密度 CV 本身噪声大**：QA 最新 3 轮 ours-brushes S1 CV = 0.317/0.194/0.236（同配置），
   目标 0.20 处于测量噪声内；ink 体量 3 轮仅 1.3% 波动（1382–1400），29% 波动未能复现（见 §10.3）。

### 10.2 可选改进开关（默认不启用）

```js
// T54 默认（保持不动）= startPressure .55 / catchUp false / speedTauMs 0
// T59 可选模式：
controller.setSimulatedPressure({
  enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 65,
  startPressure: 0.30,   // 起笔低压力，防「胖头」
  catchUp: true,         // 快速笔画起笔追赶稳态
  speedTauMs: 120,       // 速度时间平滑，抑制时间戳抖动 → 线宽 ripple
});
```
（另有两个预设级诊断旋钮：`size.floorScale` 高速段宽度下限、`smoothing.radiusSmooth` 半径距离域平滑，默认 0=关。）

### 10.3 A/B 数据（Playwright，headless，4 轮中位；产物 `samples/uniformity-ab.png`）

| 指标 | T54 默认 | T59 opt-in | Klecks | 目标 |
|---|---|---|---|---|
| S1 密度 CV（QA 口径） | 0.377 | 0.372 | 0.160 | ≤0.20 ❌ |
| S2 密度 CV（QA 口径） | 1.660 | **1.476** | 1.250 | ≤1.40（接近） |
| S1 真实线宽 CV（替代指标） | 0.306 | **0.259** | 0.183 | — |
| S2 真实线宽 CV（替代指标） | 0.230 | **0.182** | 0.214 | — |
| S1/S2 断点 | 0 / 6 | 0 / 7 | 0 / 7 | 不增加 ✅ |
| S1 ink 轮间波动 | 10.1% | 10.3% | — | — |

结论：**S2 明显改善（1.66→1.48，真实线宽 CV 已优于 Klecks）**；S1 密度 CV 未达 0.20（口径不可比 + 噪声），
但真实线宽 CV 从 0.306→0.259（改善 15%）。→ 保持 opt-in；等用户试用 + 重新过 GATE 后再决定是否默认启用。

### 10.4 ink 波动分析（Lead 关注）

- QA 最新 `round-*.json`：ours-brushes S1 ink = 1393/1400/1382 → 波动 1.3%（不是 29%）；
  **CV 轮间波动大**（0.194–0.317）才是噪声来源。
- 本机 4 轮复测：默认 T54 S1 ink 波动 10.1%，**关闭模拟压感后 11.9%** → ink 波动不是 T54 独有，
  主要来自页面加载/渲染与 Playwright 事件时序（commit/undo 抽样时刻）。
- 建议：QA 报告轮间原始 ink/CV（round-*.json 已有）；CV 目标建议用多轮中位 + 真线宽 CV 辅助判定。

## 11. T62 · 涂抹笔刷（smudge）

> 补齐 Procreate 三工具（画笔/橡皮/涂抹）。app 顶栏「涂抹」由 demo-builder 接 `controller.setMode('smudge')`；
> 本任务未改 `v2/engine/`、`v2/app/`。

### 11.1 接口

```js
controller.setMode('smudge');   // 切涂抹（内置 SMUDGE_PRESET，可传第 2 参自定义预设）
controller.setMode('brush');    // 切回画笔（恢复切换前预设）
controller.getMode();           // 'brush' | 'smudge'
// 自定义预设：new BrushController(engine, preset, { smudgePreset }) 或 setMode('smudge', preset)
```
预设：`presets/defaults.json` 新增 `id:'smudge'`（`engine.smudge:true`、`smudge.{strength,flow,softness,drag}`；schema 已扩展）；
demo 笔刷列表可直接选「涂抹」，Brush Studio 自动出现 4 个涂抹参数滑杆。

### 11.2 实现（图层隔离 + live/commit 一致 + undo）

- **取样**：`provider.begin` 时把 **当前图层已提交 tile 的 image 快照**复制到一张离屏暂存 surface
  （`CK.MakeSurface(w,h)`，零 engine 改动；只读 `engine.store` 公开接口）。不读 live/合成层、不读其它图层 → 图层隔离不破坏。
- **拖动**：每个 stamp 从暂存图取「笔触后方几 px」的方形区域 → 画到 live/目标 tile，并**写回暂存图**（反馈），
  颜色因此沿笔画连续传播（若位移按半径取会复制出周期条纹，已改为固定 2–4px/stamp）。
- **湿边**：中心区域二次叠加（`softness` 控制中心更实、边缘更柔）。
- **提交**：`provider.end` 时暂存图即最终结果；提交阶段每个受影响 tile 一次性把暂存图对应区域落回（先 clear），
  保证 live 与 commit 是同一结果；undo 由 engine 的 tile before/after 快照负责（实测 undo diff=0）。
- 压力/速度沿用 T54（`radiusFor` 用压力曲线，模拟压感/真实 pen 同一路径）。

### 11.3 验收（`tools/smudge-test.mjs`，headless 真实 GPU；`samples/smudge-compare.png` + `samples/smudge/metrics.json`）

| 检查 | 结果 |
|---|---|
| 涂抹改变像素 | diff 24,967 px（白→墨 24,832，bbox 76×345） |
| 拖动方向 / 颜色传播 | 硬边线颜色被沿纵向拖出连续条带（见对照图 ③） |
| 拖动中 live 可见 | 截图 diff 968 px（提交前已可见） |
| undo 恢复 | diff **0** px（完全恢复） |
| 模式往返 | smudge → brush，画笔继续可画（diff 5,854） |
| 错误 | console/runtime **0** |

### 11.4 限制 / 接口需求（未改 engine，按约定报 Lead）

1. 取样基于**笔画开始前**的当前图层快照 + 离屏反馈；跨笔画连续涂抹会在下一笔重新取样（符合直觉）。
2. 暂存 surface 为整画布尺寸（1600×1000 约 6.4MB/笔，用完在下一笔 begin 释放）；大文档可改为按笔画 bbox 分配。
3. **建议 engine 后续提供官方取样 API**（如 `store.snapshotRegion(layerId, bbox)` 或提交前离屏 canvas），
   可省掉整画布暂存、支持更大文档与更复杂湿边；当前实现只依赖公开只读字段，不改 engine。
4. 涂抹参数（strength/flow/softness/drag）已在 demo 可调；app 面板接线由 demo-builder 负责。

## 12. T69 · 涂抹 snapshotRegion 优化 + 模拟压感默认参数 A/B

> 默认参数**未改**（等 Lead 决策 + demo-builder 改 app 默认 + QA 复测）；本任务只做落地评估与建议。

### 12.1 涂抹接 `engine.snapshotRegion`（T69）

- 暂存从「整画布 raster」改为「笔触 bbox + 余量」的小区域 raster（`engine.snapshotRegion(layerId, bbox)`）；
  笔画变长时按需增长（旧暂存图叠回新区域快照，重叠区一致）。`opts.smudgeFullCanvas` 可切回旧版做 A/B。
- 4096×4096 实测（`tools/smudge-perf.mjs`，headless 真实 GPU，3 笔中位）：

| 指标 | 整画布（T62） | snapshotRegion（T69） | 收益 |
|---|---|---|---|
| 暂存内存 | 64 MB (67,108,864 B) | **14.76 MB**（调优后 2 次增长；调优前 10.28MB/4 次增长） | **−78%（−84.7%）** |
| 涂抹笔触耗时（4096²，50 点） | 16.08 s | **2.14 s** | **−86.7%** |
| 暂存初始化 | 132 ms（整画布） | 681 ms 累计（1 建 + 2 增长） | 首帧小降级，后续快 |
- live/commit 一致 + undo：`smudge-test` 8/8 通过（涂抹 diff 24,722、拖动中 live 可见、undo diff=0、切回画笔可画、0 error）；
  提交仍是最终暂存图按 tile 落回，与 live 同一份数据。

### 12.2 模拟压感默认参数 A/B（`samples/pressure-default-ab.png` + `samples/pressure-ab/metrics.json`）

场景：慢 S / 快 S / 轻压（极慢）/ 重压（快），合成 PointerEvent 走真实输入管线；真线宽 CV 沿路径法向直接测量。

| 场景 | 默认（T54） 真线宽 CV | opt-in（建议） 真线宽 CV | 备注 |
|---|---|---|---|
| 慢 S 形 | 0.022 | 0.022 | 持平（都极稳） |
| 快 S 形 | **0.432** | **0.084** | **−81%** |
| 轻压（极慢） | 0.0 | 0.0 | 持平 |
| 重压（快） | 0.0 | 0.032 | 轻微（视觉不可辨） |

- 延迟/掉帧：opt-in 同场景耗时持平或略快（快 S 373→333ms）；>32ms 长帧 0.5→0；压力轨迹更平滑。
- Playwright 复测（S1/S2 密度口径，真实事件时序）：S2 **1.60–1.66 → 1.40–1.43**（中位≈1.42，接近/达到 1.40 目标）；
  S1 0.28–0.30 → 0.25–0.29（噪声内，口径问题见 §10）。

### 12.3 建议（供 Lead 决策）

```js
// 建议设为默认（demo-builder 在 app 里 setSimulatedPressure 生效）：
controller.setSimulatedPressure({ enabled: true, strength: 1.0, curve: 'soft',
  smoothingMs: 65, startPressure: 0.30, catchUp: true, speedTauMs: 50 });
```
- 建议采用；`speedTauMs` 从 T59 的 120 降到 **50**：fast-S 真线宽 CV 0.084（tau120 时 0.195）、重压 CV 0.032（tau120 时 0.241），
  Playwright S2 同样最好；tau120 也可但快速笔画速度跟随更慢。
- 风险：快笔画更细（S2 ink 约 1053→675），视觉更「快细」，需用户/QA 确认；默认笔刷观感有可见变化 → 必须 QA 复测后切换。
- 回退：`setSimulatedPressure({startPressure:0.55, catchUp:false, speedTauMs:0, smoothingMs:45})` 即回到 T54 默认。

## 13. T80 · S1 慢速曲线均匀度诊断 + 组蒙版橡皮状态

> 默认参数未改；本任务结论用于 Lead 决策与 QA 口径修订。

### 13.1 S1 粗细波动来源（诊断结论）

1. **慢速曲线的真实线宽已经很均匀**：同一 S1 路径 3 笔刷 × 3 速度真线宽 CV（`samples/uniformity-s1-ab.png`）：
   hard-round 慢 0.040 / 中 0.073 / 快 0.109；铅笔 0.119/0.278/0.349、墨水 0.177/0.291/0.392（细笔 1–2px 量化占比大）。
2. **QA 的 S1 CV（12 个 ±44px 窗口的「非背景像素密度」）噪声很大**：同一配置 3 轮 CV 在 0.21–0.31 间波动，
   dens 曲线呈随机逐段尖峰，无起笔/收笔/固定段模式 → 主要是窗口几何 + 抗锯齿/颜色启发式 + 事件时序噪声；
   我们的笔画比 Klecks 默认笔粗（16–20px vs 3–4.5px）进一步放大该口径差异。
3. **已排查且不显著**：spacing 加密 0.03、半径距离域平滑 `smoothing.radiusSmooth 1.5`、压感平滑 100/150/250ms、
   关闭 records 收锋（`taper.end=0`）对 S1 密度 CV 均无稳定改善（矩阵见 `tools/uniformity-harness.mjs` 变体表）；
   T69 opt-in 能把 S1 密度 CV 中位从 ~0.29 拉到 ~0.25（单次最好 0.213），但**无法稳定 ≤0.20**；断点不增加（S1=0/S2=7）。
4. **结论**：S1 的 0.235 vs Klecks 0.173 主要是**口径不可比 + 测量噪声**，不是可低成本消除的手感缺陷；
   建议 QA 以「真线宽 CV」或放宽阈值作为 S1 判据（真线宽 CV 已接近/优于 Klecks 的 0.18–0.21 量级）。

### 13.2 组蒙版橡皮「切黑」：需 engine 接口（未改 engine）

- 现状：蒙版笔触由 app 直接调 `engine.beginStroke/appendPoint`；engine `_maskStamp/_finishMaskStroke` 用固定
  **白色 paint** 画 mask tile（白显示/黑隐藏），brushes 的 StrokePaintProvider 完全不参与 → **brushes 层无法实现橡皮切黑**。
- 建议 engine 最小接口（已报 Lead，等 engine owner 实现）：
  - `engine.setMaskStrokePaint({ mode: 'show' | 'hide', opacity?: 1 })`（内部 `_liveMaskPaint`/finish 用白/黑），或
  - `beginStroke(p, { maskPaint: 'white' | 'black' })`；
  - app 侧：`tool==='brush'` → show，`tool==='eraser'` → hide；radius 继续用 engine.brush.sizePx（后续可接 provider）。
- 现状下蒙版显示/undo 正常，仅缺「橡皮涂黑隐藏」；未在 brushes 内硬改 engine。

### 13.3 建议

- **默认参数不变**；T69 opt-in 建议保留（S2 改善明确，见 §12.3）。S1 按真线宽/放宽口径验收。
- 组蒙版橡皮需 engine 接口（above）；接口就绪后 brushes 可按 preset/工具决定白/黑 paint。

## 14. 许可

- CanvasKit / Skia：**BSD-3-Clause**，来自 `v2/engine/vendor/`（vendor LICENSE 必须保留）。
- **perfect-freehand 1.2.3**：**MIT**，Copyright (c) 2021 Stephen Ruiz Ltd；vendor 于 `vendor/perfect-freehand.js`，
  LICENSE 保留在 `vendor/perfect-freehand.LICENSE.txt`，登记于 `THIRD_PARTY_NOTICES.md`；核心代码未修改。
- **Klecks**：MIT，仅作为行为/观感参考与算法思路借鉴（BezierLine 的过点相切思路）；**未复制其代码**；
  对照测试通过浏览器公开 UI/输入事件驱动，`spike/klecks/vendor/klecks/LICENSE` 保留。
- GPL 项目（Krita/MyPaint/Drawpile）仅阅读算法思想，未复制代码。
- 本目录自制代码与纹理：随项目 LICENSE 统一（MIT 待定）。
