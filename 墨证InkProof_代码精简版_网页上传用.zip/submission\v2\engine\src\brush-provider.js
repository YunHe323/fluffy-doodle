/**
 * v2/engine · 默认笔刷 Provider（hard / soft）
 *
 * T41：引擎不再写死 hard/soft；默认实现由本 Provider 提供，
 * 自定义笔刷（T36 等）实现同一接口即可，无需子类化 Stroke。
 *
 * StrokePaintProvider 接口：
 *   id, name?
 *   begin?(ctx)                 // 一次笔触开始（ctx 见下，canvas=null）
 *   radiusFor(ctx): number      // 必填：本 stamp 半径（px）
 *   paintFor?(ctx): Paint|null  // 可选：返回配置好的 CanvasKit Paint（provider 负责缓存/释放）
 *   stampFor?(ctx): void        // 可选：完整自定义绘制；缺省且 paintFor 存在时引擎画圆
 *   end?(ctx)                   // 一次笔触结束（commit 前）
 *   dispose?()
 *
 * ctx 字段（每次 stamp 都会带上）：
 *   CK, provider, brush {type,sizePx,opacity?}, layerId,
 *   canvas (CanvasKit Canvas；实时=主 surface，提交=tile surface),
 *   x,y (绘制坐标；提交时是 tile 本地坐标), worldX,worldY (画布坐标),
 *   pressure (0–1), tiltX,tiltY, velocity (px/ms), distance (px),
 *   timestamp, elapsed (ms), index (点序号), coalescedIndex, coalescedCount,
 *   pointerType, isTile, tileX, tileY, radius, paint (paintFor 结果)
 */

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export function createDefaultBrushProvider() {
  const CKHolder = { CK: null };
  const paints = new Map();
  const masks = new Map();

  function paintFor(ctx) {
    const CK = ctx.CK;
    if (CKHolder.CK !== CK) {
      CKHolder.CK = CK;
      paints.clear();
      masks.clear();
    }
    const type = (ctx.brush.type || 'soft') === 'hard' ? 'hard' : 'soft';
    let paint = paints.get(type);
    if (!paint) {
      paint = new CK.Paint();
      paint.setAntiAlias(true);
      paint.setStyle(CK.PaintStyle.Fill);
      paints.set(type, paint);
    }
    const pressure = ctx.pressure == null ? 0.5 : clamp(ctx.pressure, 0, 1);
    const opacity = ctx.brush.opacity == null ? 1 : clamp(ctx.brush.opacity, 0, 1);
    paint.setBlendMode(CK.BlendMode.SrcOver);
    paint.setColor(CK.Color(31, 35, 40, opacity));
    if (type === 'soft') {
      const sigma = ctx.radius * 0.35;
      const key = sigma.toFixed(2);
      let mask = masks.get(key);
      if (!mask) {
        mask = CK.MaskFilter.MakeBlur(CK.BlurStyle.Normal, Math.max(0.5, sigma), true);
        masks.set(key, mask);
      }
      paint.setMaskFilter(mask);
    } else {
      paint.setMaskFilter(null);
    }
    // 压力影响透明度（保持原 demo 观感：软/硬都随压力变淡）
    paint.setAlphaf(0.85 * (0.35 + 0.65 * pressure) * opacity);
    return paint;
  }

  return {
    id: 'engine-default',
    name: 'hard/soft default',
    begin(ctx) { /* 无状态 */ },
    radiusFor(ctx) {
      const pressure = ctx.pressure == null ? 0.5 : clamp(ctx.pressure, 0, 1);
      const size = ctx.brush && ctx.brush.sizePx ? ctx.brush.sizePx : 64;
      return Math.max(0.5, size * 0.5 * (0.25 + pressure * 0.75));
    },
    paintFor,
    stampFor(ctx) {
      if (!ctx.paint) return;
      ctx.canvas.drawCircle(ctx.x, ctx.y, ctx.radius, ctx.paint);
    },
    end(ctx) { /* 无状态 */ },
    dispose() {
      for (const p of paints.values()) { try { p.delete(); } catch (e) { /* ignore */ } }
      for (const m of masks.values()) { try { m.delete(); } catch (e) { /* ignore */ } }
      paints.clear(); masks.clear();
    },
  };
}
