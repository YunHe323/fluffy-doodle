// v2/qa/tools/demo-preflight.mjs —— 录屏前 1 分钟自检（不调用 AI、不花钱）
// 检查：4200 健康 / AI 配置（不打印 key）/ 预置素材 sha256 / 路演 UI 能否进入 / 徽章是否「实时」
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { chromium } from '../node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const BASE = process.env.BASE || 'http://127.0.0.1:4200';
const out = { schema: 'mozheng.roadshow.preflight.v1', checks: {}, pass: false, warnings: [] };
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function json(url, opts) { const r = await fetch(url, opts); const t = await r.text(); try { return { status: r.status, body: JSON.parse(t) }; } catch (e) { return { status: r.status, body: t }; } }
try {
  const health = await json(BASE + '/health');
  out.checks.health = { ok: health.status === 200 && health.body && health.body.ok === true, status: health.status, pid: health.body && health.body.pid };
  const aiHealth = await json(BASE + '/api/ai/health');
  const h = aiHealth.body || {};
  out.checks.aiConfig = { ok: aiHealth.status === 200 && h.ok === true, mode: h.mode || null, provider: h.provider || null, hasKey: !!h.hasKey, privacyMode: !!h.privacyMode, model: h.model || null };
  if (!out.checks.aiConfig.hasKey) out.warnings.push('未配置真实 key：路演会走 Mock；录制前请在「模型」里配置或检查 v2/.ai-config.json');
  if (out.checks.aiConfig.privacyMode) out.warnings.push('privacyMode=true：会强制 Mock；录制前关闭隐私模式');
  const assetsPath = path.join(ROOT, 'v2', 'app', 'demo', 'assets.json');
  const manifest = JSON.parse(fs.readFileSync(assetsPath, 'utf8'));
  const assetChecks = [];
  for (const [k, a] of Object.entries(manifest.assets || {})) {
    const p = path.join(ROOT, 'v2', 'app', a.file.replace(/^demo\//, 'demo/'));
    const ok = fs.existsSync(p);
    let actual = null;
    if (ok) actual = sha(fs.readFileSync(p));
    assetChecks.push({ key: k, file: a.file, exists: ok, shaOk: ok && actual === a.sha256, bytes: ok ? fs.statSync(p).size : 0 });
  }
  out.checks.assets = { ok: assetChecks.every((a) => a.exists && a.shaOk), files: assetChecks };

  let browser = null;
  try {
    browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
    const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
    const errors = [];
    page.on('pageerror', (e) => errors.push(String(e.message || e).slice(0, 200)));
    page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) errors.push(m.text().slice(0, 200)); });
    await page.goto(BASE + '/v2/app/index.html', { waitUntil: 'domcontentloaded' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
    await sleep(900);
    await page.click('#btnRoadshow'); await sleep(350);
    await page.click('#btnRoadshowStart');
    await page.waitForFunction('(() => { const t = window.__V2_APP__ && window.__V2_APP__.t122; return !!(t && t.state().prepared); })()', null, { timeout: 60000 });
    await sleep(500);
    const ui = await page.evaluate(() => {
      const t = window.__V2_APP__.t122; const s = t.state();
      const b = document.getElementById('roadshowBadge');
      return { badge: b && b.textContent, badgeTitle: b && b.getAttribute('title'), canvas: s.canvas, layers: (s.layers || []).length, libCount: s.libCount, l6Preset: s.l6Preset, selection: s.selection, prepared: s.prepared, realEligible: s.realEligible, aiSettings: s.aiSettings };
    });
    await page.screenshot({ path: path.join(ROOT, 'v2', 'app', 'ui-roadshow-preflight.png') });
    await page.evaluate(() => { try { window.__V2_APP__.t122.exit(); } catch (e) {} });
    out.checks.roadshow = { ok: ui.prepared && ui.canvas && ui.canvas.width === 1600 && ui.layers >= 3 && ui.libCount >= 3 && ui.l6Preset >= 6, ...ui, errors };
    if (ui.badge !== '实时') out.warnings.push('路演徽章当前是「' + ui.badge + '」而不是「实时」；录制前请确认模型配置');
    if (errors.length) out.warnings.push('页面有 console/page 错误：' + errors.join(' | ').slice(0, 300));
    out.pass = out.checks.health.ok && out.checks.aiConfig.ok && out.checks.assets.ok && out.checks.roadshow.ok;
  } finally { try { await browser.close(); } catch (e) {} }
  console.log(JSON.stringify(out, null, 2));
  process.exit(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  console.log(JSON.stringify(out, null, 2));
  process.exit(3);
}
