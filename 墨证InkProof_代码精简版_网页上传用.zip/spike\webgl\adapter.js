// spike/webgl/adapter.js
// T30/T29 · 统一 bench adapter：把自研 WebGL2 tile 渲染器接入 bench/index.html。
// 实现契约：bench/README.md §3（mozheng.bench.v1 / window.BenchAdapter）。
// 许可：自研代码，MIT；无第三方依赖。通过 URL 参数加载：
//   bench/index.html?adapter=../spike/webgl/adapter.js&autorun=B1,B2,B3,B6
// 说明：本文件由 spike/webgl/index.html 抽取（渲染器 + adapter），二者行为一致。
(function () {
'use strict';
const TILE = 256;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const now = () => performance.now();

class TileRenderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.gl = canvas.getContext('webgl2', { antialias: false, alpha: false, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
    if (!this.gl) throw new Error('WebGL2 不可用（请用 Chrome/Edge 现代版本）');
    this.docW = 2048; this.docH = 2048;
    this.cols = 8; this.rows = 8;
    this.layers = [];
    this.activeLayer = 0;
    this.undoStack = []; this.redoStack = []; this.undoLimit = 50;
    this.view = { scale: 0.3, panX: 1024, panY: 1024 };
    this.cw = 800; this.ch = 600;
    this.stroke = null;
    this.stats = { drawCalls: 0, frameMs: 0 };
    this.ready = false;
  }

  /* ---------- 初始化 ---------- */
  init({ docW = 2048, docH = 2048, layers = 3 } = {}) {
    const gl = this.gl;
    this.docW = docW; this.docH = docH;
    this.cols = Math.ceil(docW / TILE); this.rows = Math.ceil(docH / TILE);
    this.layers = [];
    const names = ['背景', '线稿', '上色', '图层 4', '图层 5'];
    for (let i = 0; i < layers; i += 1) {
      this.layers.push({ id: i, name: names[i] || ('图层 ' + (i + 1)), visible: true, opacity: 1, tiles: new Map() });
    }
    this.activeLayer = layers - 1;
    this.undoStack = []; this.redoStack = [];
    this._buildPrograms();
    this._buildGeometry();
    this.resize();
    this.fitView();
    this.ready = true;
    this.render();
    this._coldStartDone = now();
  }

  _buildPrograms() {
    const gl = this.gl;
    const compile = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('shader: ' + gl.getShaderInfoLog(s));
      return s;
    };
    const program = (vs, fs) => {
      const p = gl.createProgram();
      gl.attachShader(p, compile(gl.VERTEX_SHADER, vs));
      gl.attachShader(p, compile(gl.FRAGMENT_SHADER, fs));
      gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('link: ' + gl.getProgramInfoLog(p));
      return p;
    };
    // 合成 program：把 tile 纹理画到屏幕
    this.tileProg = program(`#version 300 es
      in vec2 a_unit;
      uniform vec2 u_cam; uniform float u_scale; uniform vec2 u_res;
      uniform vec2 u_origin; uniform vec2 u_size;
      out vec2 v_uv;
      void main(){
        vec2 world = u_origin + a_unit * u_size;
        vec2 screen = (world - u_cam) * u_scale + u_res * 0.5;
        vec2 clip = vec2(screen.x / u_res.x * 2.0 - 1.0, 1.0 - screen.y / u_res.y * 2.0);
        gl_Position = vec4(clip, 0.0, 1.0);
        v_uv = vec2(a_unit.x, 1.0 - a_unit.y);
      }`, `#version 300 es
      precision highp float;
      in vec2 v_uv; uniform sampler2D u_tex; uniform float u_opacity;
      out vec4 outColor;
      void main(){
        vec4 c = texture(u_tex, v_uv);
        outColor = vec4(c.rgb, c.a * u_opacity);
      }`);
    // 实色 program：画布白底 / 选中框
    this.solidProg = program(`#version 300 es
      in vec2 a_unit;
      uniform vec2 u_cam; uniform float u_scale; uniform vec2 u_res;
      uniform vec2 u_origin; uniform vec2 u_size;
      void main(){
        vec2 world = u_origin + a_unit * u_size;
        vec2 screen = (world - u_cam) * u_scale + u_res * 0.5;
        vec2 clip = vec2(screen.x / u_res.x * 2.0 - 1.0, 1.0 - screen.y / u_res.y * 2.0);
        gl_Position = vec4(clip, 0.0, 1.0);
      }`, `#version 300 es
      precision highp float;
      uniform vec4 u_color; out vec4 outColor;
      void main(){ outColor = u_color; }`);
    // 笔刷 program：在 tile FBO 内画一个 dab
    this.brushProg = program(`#version 300 es
      in vec2 a_unit;
      uniform vec2 u_dab; uniform vec2 u_quadOrigin; uniform vec2 u_quadSize;
      out vec2 v_pos;
      void main(){
        vec2 p = u_quadOrigin + a_unit * u_quadSize;
        v_pos = p;
        vec2 clip = vec2(p.x / 256.0 * 2.0 - 1.0, 1.0 - p.y / 256.0 * 2.0);
        gl_Position = vec4(clip, 0.0, 1.0);
      }`, `#version 300 es
      precision highp float;
      in vec2 v_pos;
      uniform vec2 u_dab; uniform float u_radius; uniform float u_hardness;
      uniform vec4 u_color; uniform float u_alpha;
      out vec4 outColor;
      void main(){
        float d = length(v_pos - u_dab);
        float inner = u_radius * clamp(u_hardness, 0.0, 0.99);
        float a = 1.0 - smoothstep(inner, u_radius, d);
        if (a <= 0.001) discard;
        outColor = vec4(u_color.rgb, u_color.a * u_alpha * a);
      }`);
    this.loc = {
      tile: {
        cam: gl.getUniformLocation(this.tileProg, 'u_cam'), scale: gl.getUniformLocation(this.tileProg, 'u_scale'),
        res: gl.getUniformLocation(this.tileProg, 'u_res'), origin: gl.getUniformLocation(this.tileProg, 'u_origin'),
        size: gl.getUniformLocation(this.tileProg, 'u_size'), tex: gl.getUniformLocation(this.tileProg, 'u_tex'),
        opacity: gl.getUniformLocation(this.tileProg, 'u_opacity')
      },
      solid: {
        cam: gl.getUniformLocation(this.solidProg, 'u_cam'), scale: gl.getUniformLocation(this.solidProg, 'u_scale'),
        res: gl.getUniformLocation(this.solidProg, 'u_res'), origin: gl.getUniformLocation(this.solidProg, 'u_origin'),
        size: gl.getUniformLocation(this.solidProg, 'u_size'), color: gl.getUniformLocation(this.solidProg, 'u_color')
      },
      brush: {
        dab: gl.getUniformLocation(this.brushProg, 'u_dab'), quadOrigin: gl.getUniformLocation(this.brushProg, 'u_quadOrigin'),
        quadSize: gl.getUniformLocation(this.brushProg, 'u_quadSize'), radius: gl.getUniformLocation(this.brushProg, 'u_radius'),
        hardness: gl.getUniformLocation(this.brushProg, 'u_hardness'), color: gl.getUniformLocation(this.brushProg, 'u_color'),
        alpha: gl.getUniformLocation(this.brushProg, 'u_alpha')
      }
    };
  }
  _buildGeometry() {
    const gl = this.gl;
    this.vao = gl.createVertexArray();
    gl.bindVertexArray(this.vao);
    this.vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vbo);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);
  }
  resize() {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = Math.max(1, this.canvas.clientWidth);
    const h = Math.max(1, this.canvas.clientHeight);
    this.cw = w; this.ch = h;
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.gl.viewport(0, 0, this.canvas.width, this.canvas.height);
  }
  fitView() {
    const s = Math.min(this.cw / this.docW, this.ch / this.docH) * 0.92;
    this.view.scale = s;
    this.view.panX = this.docW / 2;
    this.view.panY = this.docH / 2;
  }
  screenToWorld(clientX, clientY) {
    const r = this.canvas.getBoundingClientRect();
    const sx = clientX - r.left, sy = clientY - r.top;
    return { x: (sx - this.cw / 2) / this.view.scale + this.view.panX, y: (sy - this.ch / 2) / this.view.scale + this.view.panY };
  }
  zoomAt(clientX, clientY, factor) {
    const before = this.screenToWorld(clientX, clientY);
    this.view.scale = clamp(this.view.scale * factor, 0.02, 8);
    const after = this.screenToWorld(clientX, clientY);
    this.view.panX += before.x - after.x;
    this.view.panY += before.y - after.y;
  }

  /* ---------- Tile 管理 ---------- */
  _ensureTile(layer, tx, ty) {
    const key = ty * this.cols + tx;
    let tile = layer.tiles.get(key);
    if (tile) return tile;
    const gl = this.gl;
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, TILE, TILE, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    const fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    tile = { key, tx, ty, tex, fbo };
    layer.tiles.set(key, tile);
    return tile;
  }
  _bindTileFBO(tile) { const gl = this.gl; gl.bindFramebuffer(gl.FRAMEBUFFER, tile.fbo); gl.viewport(0, 0, TILE, TILE); }
  _readTile(tile) {
    const gl = this.gl;
    this._bindTileFBO(tile);
    const data = new Uint8Array(TILE * TILE * 4);
    gl.readPixels(0, 0, TILE, TILE, gl.RGBA, gl.UNSIGNED_BYTE, data);
    return data;
  }
  _writeTile(tile, data) {
    const gl = this.gl;
    gl.bindTexture(gl.TEXTURE_2D, tile.tex);
    gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, TILE, TILE, gl.RGBA, gl.UNSIGNED_BYTE, data);
  }
  /* ---------- GPU 侧 tile 快照（避免 readPixels 同步停顿） ---------- */
  _createCopy() {
    const gl = this.gl;
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, TILE, TILE, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    const fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    return { tex, fbo };
  }
  _blit(srcFbo, dstFbo) {
    const gl = this.gl;
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER, srcFbo);
    gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, dstFbo);
    gl.blitFramebuffer(0, 0, TILE, TILE, 0, 0, TILE, TILE, gl.COLOR_BUFFER_BIT, gl.NEAREST);
    gl.bindFramebuffer(gl.READ_FRAMEBUFFER, null);
    gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER, null);
  }
  _snapshotTile(tile) { const copy = this._createCopy(); this._blit(tile.fbo, copy.fbo); return copy; }
  _destroyCopy(copy) { if (!copy) return; const gl = this.gl; gl.deleteTexture(copy.tex); gl.deleteFramebuffer(copy.fbo); }
  tileCount() {
    let n = 0;
    for (const l of this.layers) n += l.tiles.size;
    return n;
  }
  getStats() {
    const tiles = this.tileCount();
    return { tiles, layers: this.layers.length, tileSize: TILE, docW: this.docW, docH: this.docH, textureEstimateMB: mb(tiles * TILE * TILE * 4), drawCalls: this.stats.drawCalls };
  }

  /* ---------- 合成渲染 ---------- */
  render() {
    const gl = this.gl;
    const { cw, ch } = this;
    const cam = [this.view.panX, this.view.panY];
    const scale = this.view.scale * (this.canvas.width / this.cw); // 设备像素
    const res = [this.canvas.width, this.canvas.height];
    this.stats.drawCalls = 0;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.clearColor(0.03, 0.04, 0.06, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.disable(gl.BLEND);
    gl.useProgram(this.solidProg);
    gl.bindVertexArray(this.vao);
    gl.uniform2fv(this.loc.solid.cam, cam);
    gl.uniform1f(this.loc.solid.scale, scale);
    gl.uniform2fv(this.loc.solid.res, res);
    // 文档白底 + 外框
    gl.uniform2f(this.loc.solid.origin, 0, 0);
    gl.uniform2f(this.loc.solid.size, this.docW, this.docH);
    gl.uniform4f(this.loc.solid.color, 1, 1, 1, 1);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    this.stats.drawCalls += 1;
    // 图层（可见 tile 才画；稀疏）
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.useProgram(this.tileProg);
    gl.uniform2fv(this.loc.tile.cam, cam);
    gl.uniform1f(this.loc.tile.scale, scale);
    gl.uniform2fv(this.loc.tile.res, res);
    gl.activeTexture(gl.TEXTURE0);
    gl.uniform1i(this.loc.tile.tex, 0);
    const viewRect = {
      x0: (0 - this.cw / 2) / this.view.scale + this.view.panX,
      y0: (0 - this.ch / 2) / this.view.scale + this.view.panY,
      x1: (this.cw - this.cw / 2) / this.view.scale + this.view.panX,
      y1: (this.ch - this.ch / 2) / this.view.scale + this.view.panY
    };
    for (const layer of this.layers) {
      if (!layer.visible || layer.opacity <= 0) continue;
      gl.uniform1f(this.loc.tile.opacity, layer.opacity);
      for (const tile of layer.tiles.values()) {
        const ox = tile.tx * TILE, oy = tile.ty * TILE;
        if (ox + TILE < viewRect.x0 || oy + TILE < viewRect.y0 || ox > viewRect.x1 || oy > viewRect.y1) continue;
        gl.bindTexture(gl.TEXTURE_2D, tile.tex);
        gl.uniform2f(this.loc.tile.origin, ox, oy);
        gl.uniform2f(this.loc.tile.size, TILE, TILE);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        this.stats.drawCalls += 1;
      }
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.bindVertexArray(null);
  }

  /* ---------- 笔刷 ---------- */
  paintDab(x, y, opts) {
    const gl = this.gl;
    const layer = this.layers[this.activeLayer];
    if (!layer || !layer.visible) return;
    const radius = Math.max(0.6, opts.radius);
    const color = opts.color || [0.18, 0.25, 0.36];
    const alpha = opts.alpha == null ? 1 : opts.alpha;
    const hardness = opts.hardness == null ? 0.9 : opts.hardness;
    const erase = !!opts.erase;
    const tx0 = clamp(Math.floor((x - radius) / TILE), 0, this.cols - 1);
    const tx1 = clamp(Math.floor((x + radius) / TILE), 0, this.cols - 1);
    const ty0 = clamp(Math.floor((y - radius) / TILE), 0, this.rows - 1);
    const ty1 = clamp(Math.floor((y + radius) / TILE), 0, this.rows - 1);
    gl.useProgram(this.brushProg);
    gl.bindVertexArray(this.vao);
    gl.enable(gl.BLEND);
    gl.blendFunc(erase ? gl.ZERO : gl.SRC_ALPHA, erase ? gl.ONE_MINUS_SRC_ALPHA : gl.ONE_MINUS_SRC_ALPHA);
    gl.uniform4f(this.loc.brush.color, color[0], color[1], color[2], 1);
    gl.uniform1f(this.loc.brush.alpha, alpha);
    gl.uniform1f(this.loc.brush.hardness, hardness);
    for (let ty = ty0; ty <= ty1; ty += 1) {
      for (let tx = tx0; tx <= tx1; tx += 1) {
        const tile = this._ensureTile(layer, tx, ty);
        this._bindTileFBO(tile);
        gl.clearColor(0, 0, 0, 0);
        // 只在首次分配时清空（tile 创建时未 clear）
        const qx = x - tx * TILE, qy = y - ty * TILE;
        const pad = radius * 1.25;
        gl.uniform2f(this.loc.brush.dab, qx, qy);
        gl.uniform2f(this.loc.brush.quadOrigin, qx - pad, qy - pad);
        gl.uniform2f(this.loc.brush.quadSize, pad * 2, pad * 2);
        gl.uniform1f(this.loc.brush.radius, radius);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      }
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }
  _stampSegment(a, b, brush, pressureA, pressureB) {
    const dist = Math.hypot(b.x - a.x, b.y - a.y);
    const radius = brush.sizePx / 2;
    const spacing = Math.max(0.8, radius * (brush.type === 'soft' ? 0.18 : 0.28));
    const steps = Math.max(1, Math.ceil(dist / spacing));
    for (let i = 1; i <= steps; i += 1) {
      const t = i / steps;
      const p = pressureA + (pressureB - pressureA) * t;
      const pr = radius * (0.35 + 0.65 * p);
      this.paintDab(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, {
        radius: pr,
        hardness: brush.type === 'soft' ? 0.18 : 0.92,
        alpha: brush.type === 'soft' ? 0.22 + 0.2 * p : 0.94,
        color: brush.color,
        erase: brush.erase
      });
      if (this.stroke && !this.stroke.patches.has(this._patchKey(brush, a, b, i))) { /* 占位：见 _recordPatches */ }
    }
  }
  _patchKey() { return ''; }
  _recordTilePatches(x, y, radius) {
    // 在动 tile 前记录 before 数据（一 stroke 一 tile 只记一次）
    if (!this.stroke) return;
    const layer = this.layers[this.activeLayer];
    const tx0 = clamp(Math.floor((x - radius) / TILE), 0, this.cols - 1);
    const tx1 = clamp(Math.floor((x + radius) / TILE), 0, this.cols - 1);
    const ty0 = clamp(Math.floor((y - radius) / TILE), 0, this.rows - 1);
    const ty1 = clamp(Math.floor((y + radius) / TILE), 0, this.rows - 1);
    for (let ty = ty0; ty <= ty1; ty += 1) {
      for (let tx = tx0; tx <= tx1; tx += 1) {
        const key = ty * this.cols + tx;
        if (this.stroke.patches.has(key)) continue;
        const tile = this._ensureTile(layer, tx, ty);
        this.stroke.patches.set(key, { layerId: layer.id, tx, ty, before: this._snapshotTile(tile) });
      }
    }
  }

  /* ---------- 笔画生命周期（BenchAdapter 契约） ---------- */
  currentBrush = { type: 'soft', sizePx: 48, color: [0.16, 0.23, 0.34], erase: false };
  beginStroke(point) {
    this.stroke = { patches: new Map(), last: { x: point.x, y: point.y }, lastPressure: point.pressure ?? 0.5 };
    this._recordTilePatches(point.x, point.y, this.currentBrush.sizePx);
    this.paintDab(point.x, point.y, {
      radius: Math.max(0.6, this.currentBrush.sizePx / 2 * (0.35 + 0.65 * (point.pressure ?? 0.5))),
      hardness: this.currentBrush.type === 'soft' ? 0.18 : 0.92,
      alpha: this.currentBrush.type === 'soft' ? 0.3 : 0.95,
      color: this.currentBrush.color,
      erase: this.currentBrush.erase
    });
  }
  moveStroke(point) {
    if (!this.stroke) this.beginStroke(point);
    const s = this.stroke;
    const pressure = point.pressure == null ? 0.5 : point.pressure;
    this._recordTilePatches(point.x, point.y, this.currentBrush.sizePx);
    this._stampSegment(s.last, { x: point.x, y: point.y }, this.currentBrush, s.lastPressure, pressure);
    s.last = { x: point.x, y: point.y };
    s.lastPressure = pressure;
  }
  endStroke() {
    if (!this.stroke) return;
    const patches = [...this.stroke.patches.values()];
    this.stroke = null;
    if (!patches.length) return;
    this.undoStack.push({ patches });
    if (this.undoStack.length > this.undoLimit) this.undoStack.shift();
    this.redoStack.length = 0;
  }
  _swapPatches(entry) {
    const layerById = new Map(this.layers.map((l) => [l.id, l]));
    for (const p of entry.patches) {
      const layer = layerById.get(p.layerId);
      if (!layer) continue;
      const tile = this._ensureTile(layer, p.tx, p.ty);
      // 交换：当前 tile → 新快照；旧快照 → tile（全程 GPU blit，无 readPixels）
      const cur = this._createCopy();
      this._blit(tile.fbo, cur.fbo);
      this._blit(p.before.fbo, tile.fbo);
      this._destroyCopy(p.before);
      p.before = cur;
    }
  }
  undo() {
    const entry = this.undoStack.pop();
    if (!entry) return false;
    this._swapPatches(entry);
    this.redoStack.push(entry);
    return true;
  }
  redo() {
    const entry = this.redoStack.pop();
    if (!entry) return false;
    this._swapPatches(entry);
    this.undoStack.push(entry);
    return true;
  }
  getCompositeDataUrl() {
    this.render();
    const gl = this.gl;
    const w = this.canvas.width, h = this.canvas.height;
    const pixels = new Uint8Array(w * h * 4);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
    const cv = document.createElement('canvas');
    cv.width = w; cv.height = h;
    const ctx = cv.getContext('2d');
    const img = ctx.createImageData(w, h);
    // 上下翻转
    for (let y = 0; y < h; y += 1) img.data.set(pixels.subarray((h - 1 - y) * w * 4, (h - y) * w * 4), y * w * 4);
    ctx.putImageData(img, 0, 0);
    return cv.toDataURL('image/png');
  }
  dispose() {
    const gl = this.gl;
    for (const layer of this.layers) for (const tile of layer.tiles.values()) { gl.deleteTexture(tile.tex); gl.deleteFramebuffer(tile.fbo); }
    for (const entry of [...this.undoStack, ...this.redoStack]) {
      for (const p of entry.patches) this._destroyCopy(p.before);
    }
    this.undoStack = []; this.redoStack = [];
    this.layers = [];
  }
  gpuInfo() {
    const gl = this.gl;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    if (!ext) return { vendor: 'unknown', renderer: String(gl.getParameter(gl.RENDERER)) };
    return { vendor: String(gl.getParameter(ext.UNMASKED_VENDOR_WEBGL)), renderer: String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) };
  }
}

window.BenchAdapter = {
  id: 'webgl2-tile',
  version: '0.1.0',
  license: 'MIT',
  _r: null,
  async init(config) {
    this._r = new TileRenderer(config.canvas);
    this._r.init({ docW: config.width || 2048, docH: config.height || 2048, layers: config.layers || 3 });
    this._r.currentBrush = { type: (config.brush && config.brush.type) || 'soft', sizePx: (config.brush && config.brush.sizePx) || 48, color: [0.16, 0.23, 0.34], erase: false };
    return this._r;
  },
  beginStroke(p) { this._r.beginStroke(p); },
  moveStroke(p) { this._r.moveStroke(p); this._r.render(); },
  endStroke() { this._r.endStroke(); },
  async undo(steps = 1) { for (let i = 0; i < steps; i += 1) { this._r.undo(); this._r.render(); } },
  async getCompositeDataUrl() { return this._r.getCompositeDataUrl(); },
  getStats() { return this._r.getStats(); },
  dispose() { if (this._r) this._r.dispose(); this._r = null; }
};

console.info('[adapter:webgl2-tile] loaded · ' + (window.BenchAdapter && window.BenchAdapter.version));
})();
