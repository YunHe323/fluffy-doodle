/**
 * v2 engine · PSD 导出 Worker（T79）
 * 主线程逐层渲染 RGBA → OffscreenCanvas → 转移给本 Worker；
 * Worker 用已 vendor 的 ag-psd（UMD，MIT）writePsd 打包，避免主线程同步编码。
 */
importScripts('../../psd/vendor/ag-psd/bundle.js');

function toBuffer(buffer) {
  if (buffer instanceof ArrayBuffer) return buffer;
  if (buffer && buffer.buffer) {
    const start = buffer.byteOffset || 0;
    const len = buffer.byteLength || buffer.length || buffer.buffer.byteLength;
    return buffer.buffer.slice(start, start + len);
  }
  throw new Error('PSD Worker: 不支持的 buffer 类型');
}

function buildNodes(children) {
  return (children || []).map((n) => {
    if (n.type === 'group') {
      return {
        name: n.name,
        hidden: !n.visible,
        opacity: n.opacity == null ? 1 : n.opacity,
        blendMode: 'pass through',
        opened: false,
        children: buildNodes(n.children || []),
      };
    }
    const layer = {
      name: n.name,
      hidden: !n.visible,
      opacity: n.opacity == null ? 1 : n.opacity,
      blendMode: n.blendMode || 'normal',
      clipping: n.clip || undefined,
      top: 0,
      left: 0,
      bottom: n.height,
      right: n.width,
    };
    if (n.pixels) {
      const c = new OffscreenCanvas(n.width, n.height);
      c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(n.pixels), n.width, n.height), 0, 0);
      layer.canvas = c;
    }
    if (n.maskPixels) {
      const mc = new OffscreenCanvas(n.width, n.height);
      mc.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(n.maskPixels), n.width, n.height), 0, 0);
      layer.mask = {
        top: 0, left: 0, bottom: n.height, right: n.width,
        defaultColor: 0, canvas: mc,
      };
    }
    return layer;
  });
}

self.onmessage = (ev) => {
  const msg = ev.data || {};
  try {
    if (msg.type !== 'psd-init') return;
    const psd = {
      width: msg.width,
      height: msg.height,
      bitsPerChannel: 8,
      colorMode: 3,
      children: buildNodes(msg.children || []),
    };
    const buffer = self.agPsd.writePsd(psd, {
      generateThumbnail: false,
      noBackground: true,
      trimImageData: false,
    });
    const out = toBuffer(buffer);
    self.postMessage({ type: 'psd-done', buffer: out }, [out]);
  } catch (e) {
    self.postMessage({ type: 'psd-error', message: String((e && e.message) || e) });
  }
};
