// product/test/security.test.mjs
// 开源/离线约束的静态守卫（用户已确认：无遥测、无静默网络请求、密钥不硬编码）。
import test from 'node:test';
import assert from 'node:assert/strict';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PRODUCT_ROOT = path.resolve(__dirname, '..');

async function readSource(relPath) {
  return fs.readFile(path.join(PRODUCT_ROOT, relPath), 'utf8');
}

const FORBIDDEN_OUTBOUND = [
  { pattern: /\bfetch\s*\(/, label: 'fetch(' },
  { pattern: /\bhttps?\.request\s*\(/, label: 'http(s).request(' },
  { pattern: /\bnet\.connect\s*\(/, label: 'net.connect(' },
  { pattern: /\bdns\.(lookup|resolve)\s*\(/, label: 'dns.lookup/resolve(' },
  { pattern: /XMLHttpRequest/, label: 'XMLHttpRequest' },
  { pattern: /\bnew\s+WebSocket\s*\(/, label: 'new WebSocket(' },
];

test('服务端与 core 没有任何出站网络调用（无遥测/无静默外联）', async () => {
  const files = [
    'server/server.mjs',
    'server/ai-proxy.mjs',
    'core/hash-chain.mjs',
    'core/archive-schema.mjs',
    'core/mock-ai.mjs',
  ];
  for (const rel of files) {
    const source = await readSource(rel);
    for (const { pattern, label } of FORBIDDEN_OUTBOUND) {
      assert.ok(!pattern.test(source), `${rel} 出现出站调用 ${label}（违反无网络约束）`);
    }
  }
});

test('只监听 127.0.0.1；拒绝其它 host', async () => {
  const source = await readSource('server/server.mjs');
  assert.ok(source.includes("export const HOST = '127.0.0.1'"));
  assert.ok(source.includes('if (host !== HOST) throw'));
});

test('零第三方运行时依赖 + 无 devDependencies', async () => {
  const pkg = JSON.parse(await readSource('package.json'));
  assert.deepEqual(pkg.dependencies ?? {}, {});
  assert.deepEqual(pkg.devDependencies ?? {}, {});
  assert.equal(pkg.type, 'module');
  assert.match(pkg.engines.node, />=22/);
});

test('示例配置 apiKey 留空；仓库内不得出现明显密钥形态', async () => {
  const example = JSON.parse(await readSource('config/provider.example.json'));
  assert.equal(example.apiKey, '');
  assert.equal(example.provider, 'mock');

  const files = ['server/server.mjs', 'server/ai-proxy.mjs', 'config/provider.example.json', 'package.json'];
  for (const rel of files) {
    const source = await readSource(rel);
    assert.ok(!/sk-[A-Za-z0-9]{16,}/.test(source), `${rel} 疑似硬编码密钥`);
  }
});

test('ai-proxy 只抛 NotImplemented，不含真实调用实现', async () => {
  const source = await readSource('server/ai-proxy.mjs');
  assert.ok(source.includes('NotImplementedError'));
  assert.ok(!source.includes('await fetch'));
  assert.ok(!source.includes('http.request('));
});
