# T117 最终独立 QA：调整层「仅作用到当前选区」蒙版

> 执行：qa-engineer（独立 QA）｜日期：2026-11-07 23:14（Asia/Shanghai）
> 背景：黑客松提交截止 2026-11-08 12:00；按 Lead 指示用已跑出的证据收口，**不再扩大测试范围**。
> 工作目录：`C:\Users\xiao1\Desktop\项目一`（Windows / Node v24.21.0 / Python 3.14.7 / headless Edge）。
> 纪律：**只写 `v2/qa/tools/`（QA 脚本、结果 JSON、报告、截图），未修改任何产品源码与现有测试**。
> 产品文件 mtime：`app.js` 22:48:32、`engine.js` 22:48:01、`index.html` 22:48:15（均早于本轮 QA 开始 22:56）；`test-adjust-layer.mjs` 22:49:04、`test-text-edit.mjs` 22:44:24 未改。

## 结论

**不可交付（Not deliverable）——P0 = 0，P1 = 5，P2 = 1（另有 1 条设计口径建议）。**

A（UI 状态）、B（创建、框外像素严格不变）、C（更新、mask 跟随选区、预填）、F（保存/加载）、H（0 console error / 0 pageerror / 0 外部请求 / Mock 无 key / 无残留）均通过；指定回归 `test-adjust-layer`、`test-text-edit` 均 exit 0、pass=true。
但 D（取消勾选不生效）、E（undo/redo 与 mask/像素不一致、创建 redo 丢失内容）、G（4096² 性能超验收阈值且页面明显冻结）共 14/48 项断言失败，其中 5 项达到 P1。建议修复 D 与 E 后再签收；若比赛时间不允许，4096² 蒙版性能应作为已知风险明确限制/降级。

## 1. 测试命令与结果

| 命令 | 退出码 | 结果 |
|---|---|---|
| `node v2/qa/tools/T117-mask-qa.mjs` | **1**（有失败项） | 48 项检查：**34 pass / 14 fail**；fatal/脚本错误 **0**；console error **0**、pageerror **0**；gpu=ANGLE-D3D11；耗时约 **96s** |
| `node v2/app/test-adjust-layer.mjs` | **0** | result JSON `pass=true`；`ok/maskOk/prefillOk/updateOk/undoOk/persistOk/noErrors` 全 true；`create.maskTiles=20` |
| `node v2/app/test-text-edit.mjs` | **0** | result JSON `pass=true`；`errors=[]`；create/open/edit/undo/keyboardUndo/keyboardRedo/persist/cursor 全 true |
| 残留检查（PowerShell） | — | headless Edge **0**、端口 8181/8171/8161 监听 **0**、`python http.server` **0** |

结果 JSON：`v2/qa/tools/T117-mask-qa-result.json`（本轮最终证据；截图在 `v2/qa/tools/shots/t117-*.png`）。
说明：QA 脚本在前几轮自检中修过 4 处**测试代码**问题（slider 入参、像素比对口径、加载后需显式选中调整层、license 文案误报），最终报告只采用最终一轮数据；被测产品代码未改。

## 2. 问题清单（P0/P1/P2）

### P0（无）

无崩溃、无数据文件损坏、无安全/密钥泄漏；指定回归未回退。

### P1（5）

| # | 级别 | 问题 | 现象 / 复现步骤 | 证据（最终一轮数值） | 期望行为 | 严重度理由 |
|---|---|---|---|---|---|---|
| P1-1 | **P1** | **D：取消勾选「仅作用到当前选区」后应用，mask 未移除** | 对已有 mask 的调整层（选区 2）重开「图像调整」→ 取消勾选 → 亮度改 30 → 应用。画面仍只在新选区（选区 2）内变化，选区 1 的像素完全不恢复 | `maskExists=true`、`maskTiles=20`、白区 bbox=`[700,440,220,180]`（选区 2）；L6 最新 update 记录 `params.masked=false`（与实际 mask 状态矛盾）；像素 diff（vs 初始源图）：选区 1 `strict=0`（仍被限制），选区 2 `changed=5566, visible=5370, maxΔ=50`。截图 `t117-D-uncheck.png`：左笔迹（选区外）保持原色、右笔迹（选区内）被提亮 | 取消勾选 = 移除 mask，整层恢复全画幅调整；同时 L6 `masked` 与实际 mask 状态一致 | 功能语义未生效 + 元数据自相矛盾；用户在该弹窗内无法去掉旧限制（只能另找蒙版面板），且没有任何错误提示。注：`#adjMaskHint` 现文案「已有限制可沿用；勾选则替换为当前选区」暗示"不勾选=保留"，与验收口径冲突，需同时澄清文案/记录口径（见 P2-2） |
| P1-2 | **P1** | **E-更新：mask 不参与 undo/redo** | 创建勾选 mask 的调整层（选区 1，亮度 20）→ 改选区 2、亮度 45 应用 → `engine.undo()` | undo 后**参数已回到 0.20**（E-u1 pass），但 mask 白区仍为 bbox=`[700,440,220,180]`（选区 2，应回到选区 1）；整幅合成 vs「创建后」：选区 1 `changed=11277, visible=10810, maxΔ=45`，选区 2 `0`（E-u3/E-u4 fail） | undo 后 mask 与像素/参数一同回到创建后状态（选区 1）；redo 后回到选区 2 | mask 写入 `engine.setMaskFromDataUrl` 不进 undo 栈；`replaceLayerFromDataUrlWithInfo` 的 image undo 条目只含像素+info（engine.js:1879-1899、628-653）。用户 undo 后得到"旧像素 + 新 mask"的混合状态，且无法通过再 undo 修正 |
| P1-3 | **P1** | **E-更新：undo/redo 像素快照被旧 mask 烘焙裁剪** | 同上更新（选区 1→2）后 undo / redo；直读图层 tile 像素（剥离 mask）对比 | undo 后原始像素 vs 创建后：`5400 px changed, maxΔ=96`；redo 后原始像素 vs 更新后：`5450 px changed, maxΔ=170`。redo 后整幅 vs「更新后」：选区 2 `changed=5485, visible=5261, maxΔ=57`（E-u2/E-u5 fail） | undo 恢复完整图层像素，redo 恢复更新后的完整像素 | `replaceLayerFromDataUrlWithInfo` 用 `_renderLayerImage` 拍 before/after，而该函数经 `compositor.drawLayerFull` **应用了当时的 mask**（engine.js:1752-1759、compositor.js:150-165）。旧 mask 被"烘焙"进快照，导致 undo/redo 后只保留旧选区内像素，换 mask 后大面积丢失。与 P1-2 同属 E，建议一起修 |
| P1-4 | **P1** | **E-创建：undo 后再 redo，调整层内容/参数/mask 全部丢失** | 有选区+勾选创建调整层（亮度 20）→ `engine.undo()`（层消失，通过）→ `engine.redo()` | redo 后层数恢复为 3，但该层 `kind='raster'`、`adjustLayers=[]`（无 adjust/参数）、`maskTiles=0`、mask=null；整幅 vs「创建后」：选区 1 `changed=9437, visible=9050, maxΔ=45`（E-c3~E-c6 fail）。**对照实验（无 mask 的调整层）同样 redo 后变 raster/丢参数**，说明根因是通用"新建图层"结构 undo：`addLayer` 在像素/kind/mask 写入前就拍了结构快照（engine.js:253-262、1453-1463），redo 恢复到空 raster 层；非 T117 引入 | redo 完整恢复新建的调整层（像素、kind、adjust 参数、mask） | redo 属于用户常规操作，当前会静默丢内容；虽为既有引擎级问题，但直接导致 T117 验收 E 不通过（T117 的 mask 部分额外丢失）。建议至少为"创建调整层"补一步结构/像素快照，或把像素写入纳入同一 undo 事务 |
| P1-5 | **P1（性能）** | **G：4096×4096 蒙版写入严重超阈值、页面明显冻结** | 新建 4096²（`?new=1&w=4096&h=4096`）→ 设选区 `[1024,768,1536,1024]` → 勾选应用（亮度 20）；另直接 `engine.setMaskFromDataUrl` 计时（同一 mask 写 2 次） | 直接 mask 写入：**9419.4ms / 11044.0ms**（阈值 2000ms，约 **4.7–5.5×**）；构建 mask dataURL 仅 73.4ms；按钮端到端 **20462ms**；主线程 longtask：**max 14220ms、总计 20188ms**（5 条：4998/758/14220/124/88）；`maskTiles=256`、内存估算 492MB。三次运行区间：mask 写入 **6275–11044ms**、e2e **14544–20462ms**、longtask max **10622–14220ms**（均为同一脚本 headless Edge + ANGLE-D3D11） | mask 写入 ≤2000ms（验收口径），且应用过程中页面不出现秒级冻结 | 4096 是产品允许的画布上限（clamp 4096），单次应用冻结 10–14 秒接近"无响应"；虽无数据损坏且常规 ≤2048 画布不受影响，但已明显超出验收阈值。根因：`setMaskFromDataUrl` 对**全画布所有 tile**（16×16=256）逐个 `drawImage` 整幅 4096² 图 + flush + 快照（engine.js:359-385），`importImageAsLayer` 同样全画布写 256 tile。建议：只遍历与选区 bbox 相交的 tile（本用例 7×5=35 个）、按 tile 源矩形 `drawImage`、flush 合并/批量快照、必要时分帧；补充 4096 性能用例。若产品明确 4096 只是 best-effort，可将本条降为 P2 |

### P2（1 + 1 条口径建议）

| # | 级别 | 问题 | 证据 / 说明 | 建议 |
|---|---|---|---|---|
| P2-1 | **P2（既有问题，非 T117 阻塞）** | 保存/加载后 `activeLayerId` 不恢复：加载后默认选中"图层 2"，而非保存时的调整层 | F 用例 `loadedActiveBeforeSelect='layer-2'`；必须显式 `engine.setActiveLayer(adjustId)` 后重开 modal 才预填 brightness=30、checkbox 勾选。根因：`doc.activeLayerId` 不随 `addLayer`/`setActiveLayer` 同步（engine.js:253-265、973-981），属既有序列化口径问题 | 另立任务：`setActiveLayer`/创建层时同步 `doc.activeLayerId`（或保存时取 engine 当前值）。本轮不阻塞 T117 |
| P2-2 | **P2（口径建议，与 P1-1 相关）** | 取消勾选语义与文案/记录口径冲突 | `#adjMaskHint` 文案为「已有限制可沿用；勾选则替换为当前选区」，暗示"不勾选=保留旧 mask"；但验收要求"取消勾选=移除 mask"，且 L6 记录写 `masked=false` 与实际 mask=true 矛盾 | 明确定义：A) 取消勾选=移除 mask（则 hint 改为"取消勾选将移除蒙版限制"、记录与状态一致）；或 B) 保留旧 mask（则 hint 明确、`masked` 记录反映"保留"而非 false，并给用户显式移除入口） |

## 3. 已通过项（证据摘要）

| 组 | 结果 | 关键证据（最终一轮） |
|---|---|---|
| A1 无选区 | ✅ | modal：`disabled=true`、`checked=false`、hint=「先框选一块区域」 |
| A2 有选区 | ✅ | `disabled=false`、`checked=false`、hint=「只影响选框内像素」、按钮「应用为新图层」；截图 `t117-A2-modal.png` |
| A3 已有 mask 重开 | ✅ | `checked=true`、`disabled=false`、参数预填 25/10/8/5、hint=「已有限制可沿用；勾选则替换为当前选区」 |
| B1–B8 创建 | ✅ 8/8 | 新层数 3、kind=adjust、参数 `{brightness:0.25, contrast:0.10, saturation:1.08, hue:5}`；`mask.exists=true`、`maskTiles=20`、白区 bbox=`[320,240,260,200]`；L6 create 记录 `masked=true` 且 `validateRecord.ok=true`；像素对比（勾选前 vs 创建后，960000 px）：**选区 1 改变 8546、选区 1 外全部区域 `strict=0`**（其中选区 2 `strict=0`）；源层 dataURL 不变；采样：笔迹 A `(34,42,51)→(60,68,80)`，笔迹 B/空白不变；应用耗时 976ms |
| C1–C8 更新 | ✅ 8/8 | 层数仍 3、adjustId 不变；brightness=0.40；mask 白区 bbox=`[700,440,220,180]`；L6 update `masked=true`；新选区外 vs 初始源图 `strict=0`；新选区 2 内 changed=5566/visible=5370；重开预填 25→40；旧选区 1 相对创建后 changed>0（恢复原图） |
| D5 反向证据 | ✅ | 取消勾选后选区 1 vs 源图 `strict=0`，即仍被旧 mask 限制（证明 P1-1） |
| E-u1 | ✅ | 更新后 undo：参数 45→20 |
| E-c1 / E-c2 | ✅ | 创建后 undo：层数 3→2、adjust 层消失；整幅 vs 创建前 `strict=0` |
| F1–F5 保存/加载 | ✅ 5/5 | serialize 97.7KB，doc 中 kind=adjust+参数 0.30，`masks` 含该层 20 tiles；`loadProjectText` 后 kind/adjust/mask 保留，白区 bbox=`[700,440,220,180]`；整幅 roundtrip `visible=0`（36 px 为 tile PNG 重编码 ±1 噪声、maxΔ=1，判定非 mask 语义问题）；显式选中调整层后重开 modal：brightness=30、checked=true、disabled=true |
| G1 | ✅ | 4096² 成功创建 adjust 层 + mask（256 tiles），无异常 |
| H1 / H2 / H3 / H4 / H5 | ✅ 5/5 | 全程 **0 console error、0 pageerror**；外部请求 **0**、`.ai-token/.ai-config` 请求 **0**；Mock：`hasKey=false / realEligible=false / preset='mock'`；DOM/LS/SS/已加载脚本明文密钥命中 **0**（DOM 仅 license 文案提到 `v2/.ai-config.json`，非密钥）；浏览器 close、临时服务 kill、残留 0 |
| I 回归 | ✅ | `test-adjust-layer` exit 0 pass=true（maskOk/updateOk/undoOk/persistOk/noErrors=true）；`test-text-edit` exit 0 pass=true（keyboardUndo/keyboardRedo 等全 true） |

## 4. 未验证 / 因比赛时间放弃

以下项**未验证**，不计入本轮结论；除特别说明外均因比赛收口与时间限制放弃：

1. **UI 文件级保存/打开**：未走「保存 .mozheng 下载 → 选择文件打开」真实文件对话框路径；F 用 `engine.serializeDoc()` + `t61.loadProjectText()` 的等价序列化路径验证（同数据通道）。
2. **PSD 导出与 mask 的交互**、调整层 mask 的 PSD 导出表现：未验证（T117 文档已列风险）。
3. **独立"调整蒙版"画笔入口 / 图层蒙版面板编辑**：未验证（当前产品只有创建/更新时的"仅作用选区"入口）。
4. **组蒙版、剪贴、画布 resize/crop 后 mask 行为、mask enabled 切换**：未验证。
5. **源图层在调整层创建后继续变化、再重开调整层的交互**：未验证。
6. **4096² 其他路径**（撤销/保存/PSD、headed 浏览器、无 GPU fallback）：未验证；G 仅为 headless Edge + ANGLE-D3D11、空白源层（调整计算便宜），e2e 包含 import+mask，直接 mask 计时为隔离值。
7. **全量回归**：按 Lead 指示只跑指定的 2 个回归脚本，未跑其余测试套件（避免范围扩大/时间不足）。
8. **多浏览器 / 多 DPI / 触控**：未验证。
9. **F roundtrip ±1 噪声**：36/960000 px、maxΔ=1、visible=0，判定为 tile PNG 序列化往返特性，未计缺陷；若要求逐像素 bit-exact 保存，需另立口径。
10. **修复后复核**：本轮**未**修复任何产品代码，因此 P1-1~P1-5 均为"发现即报告"，未做修复回归。

## 5. 产物

| 文件 | 说明 |
|---|---|
| `v2/qa/tools/T117-mask-qa.mjs` | 独立 QA 脚本（headless Edge，端口 8181，python 静态服务，跑完 close+kill） |
| `v2/qa/tools/T117-mask-qa-result.json` | 最终一轮机器可读证据（48 checks / 14 failed / 0 console+page errors） |
| `v2/qa/tools/T117-final-qa.md` | 本报告 |
| `v2/qa/tools/shots/t117-A1-no-selection.png` | A1 无选区 disabled/hint |
| `v2/qa/tools/shots/t117-A2-modal.png` | A2 有选区、未勾选、hint |
| `v2/qa/tools/shots/t117-B-create.png` | B 创建后画面 |
| `v2/qa/tools/shots/t117-C-update.png` | C 更新后画面 |
| `v2/qa/tools/shots/t117-D-uncheck.png` | D 取消勾选后仍受旧选区限制（左笔迹原色、右笔迹提亮） |
| `v2/qa/tools/shots/t117-E-create-redo.png` | E 创建 undo/redo 后的空 raster 层 |
| `v2/qa/tools/shots/t117-E-update-undo.png` | E 更新 undo 后混合状态 |
| `v2/qa/tools/shots/t117-F-roundtrip.png` | F 保存/加载后 |
| `v2/qa/tools/shots/t117-G-4096.png` | G 4096² 创建后 |

## 6. 建议（按比赛剩余时间排序）

1. **先修 P1-1（D）**：`applyAdjustmentsFromModal` 在 `wantMask=false` 且 `l.mask.exists` 时调用 `engine.removeMask(l.id)`（或把"取消勾选"明确为保留并改文案+记录）——改动小、用户语义直接。
2. **再修 P1-2/P1-3（E）**：把 mask 状态纳入 image undo 条目（before/after mask 快照或 mask 版本号），并让 `replaceLayerFromDataUrlWithInfo` 拍像素快照时**不应用 mask**（改用 raw store 渲染，必要时单独合成层）。
3. **P1-4（创建 redo）**：把 importImageAsLayer 的像素/kind/mask 写入与 `addLayer` 合并为同一结构 undo 事务（或在写入完成后替换栈顶结构快照）——属既有引擎问题，至少为调整层路径兜底。
4. **P1-5（4096 性能）**：`setMaskFromDataUrl` 改为按选区 bbox 只写相交 tile + 每 tile 源矩形绘制；`importImageAsLayer` 同样按目标区域裁剪；写完后一次性 flush；加 4096 性能回归阈值。
5. P2-1（activeLayerId 持久化）、P2-2（D 口径）可下一轮处理，不阻塞 T117 比赛演示（≤2048 画布 + 不取消勾选场景功能正常）。
