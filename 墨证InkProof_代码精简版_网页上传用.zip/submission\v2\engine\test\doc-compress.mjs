#!/usr/bin/env node
// v2/engine/test/doc-compress.mjs —— T77 .mozheng gzip v2 + v1 兼容测试（零依赖 CDP）
// 用法：node v2/engine/test/doc-compress.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const checks = {};
  async function makeEngine(width) {
    const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = width;
    const eng = new Engine({ canvas, width, height: width, layers: 2 });
    await eng.init(); eng.setBrush({ type: 'soft', sizePx: 48 });
    for (let s = 0; s < 3; s += 1) {
      const y = 120 + s * 140;
      eng.beginStroke({ x: 120, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
      for (let i = 1; i < 22; i += 1) eng.appendPoint({ x: 120 + i * 30, y: y + Math.sin(i / 5) * 20, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
      eng.endStroke();
    }
    await raf(); await raf();
    return eng;
  }
  async function inkOf(url) {
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const x = c.getContext('2d'); x.drawImage(img, 0, 0);
    const d = x.getImageData(0, 0, c.width, c.height).data;
    let ink = 0; for (let i = 0; i < d.length; i += 4) if (d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220) ink += 1;
    return ink;
  }
  const eng = await makeEngine(2048);
  const json = eng.serializeDoc();
  const docBefore = eng.getDoc();
  const tileCount = eng.store.allKeys().length + eng.maskStore.allKeys().length;
  // 目标引擎提前创建（排除建引擎/绘制的耗时）
  const eng2 = await makeEngine(2048);
  const eng3 = await makeEngine(2048);
  const engBad = await makeEngine(2048);
  // gzip API（含 serializeDoc，耗时单独记录）
  const tSave = performance.now();
  const gz = await eng.serializeDocGzip();
  const saveMs = Math.round((performance.now() - tSave) * 100) / 100;
  const blob = await eng.getDocFileBlob({ compress: true });
  // 纯压缩阶段耗时（CompressionStream 原生）
  const tGzip = performance.now();
  const cs = new CompressionStream('gzip');
  const gzStream = new Blob([new TextEncoder().encode(json)]).stream().pipeThrough(cs);
  const gzBytes = new Uint8Array(await new Response(gzStream).arrayBuffer());
  const gzipMs = Math.round((performance.now() - tGzip) * 100) / 100;
  // 打开阶段长任务观测
  let longTasks = [];
  let observer = null;
  try { observer = new PerformanceObserver((l) => { longTasks = longTasks.concat(l.getEntries().map((e) => e.duration)); }); observer.observe({ entryTypes: ['longtask'] }); } catch (e) { observer = null; }
  const tOpen = performance.now();
  const doc2 = await eng2.deserializeDocAuto(gz);
  const openMs = Math.round((performance.now() - tOpen) * 100) / 100;
  await raf(); await raf();
  if (observer) { try { observer.disconnect(); } catch (e) { /* ignore */ } }
  const longTaskMax = longTasks.length ? Math.max(...longTasks) : 0;
  const ratio = Math.round((1 - gz.length / json.length) * 1000) / 10;
  checks.gzipRatio25 = ratio >= 25;
  checks.gzipHeader = gz.length > 2 && gz[0] === 0x1f && gz[1] === 0x8b;
  checks.blobFile = !!blob && blob.size === gz.length && blob.type === 'application/octet-stream';
  checks.roundtripDoc = JSON.stringify(doc2) === JSON.stringify(docBefore);
  checks.roundtripTiles = eng2.store.allKeys().length + eng2.maskStore.allKeys().length === tileCount;
  checks.roundtripInk = (await inkOf(await eng2.getCompositeDataUrl())) > 0;
  // v1 明文兼容
  const doc3 = await eng3.deserializeDocAuto(json);
  checks.v1Compat = JSON.stringify(doc3) === JSON.stringify(docBefore) && (await inkOf(await eng3.getCompositeDataUrl())) > 0;
  // 损坏 gzip
  let corruptRejected = false;
  try {
    const bad = gz.slice(); bad[bad.length - 8] = 0; bad[bad.length - 7] = 0; bad[bad.length - 6] = 0; bad[bad.length - 5] = 0;
    await engBad.deserializeDocAuto(bad);
  } catch (e) { corruptRejected = true; }
  checks.corruptRejected = corruptRejected;
  checks.saveNotFreeze = gzipMs < 50;
  checks.openNotFreeze = longTaskMax < 50;
  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  eng.dispose(); eng2.dispose(); eng3.dispose();
  return {
    ok: checks.ok, checks,
    data: {
      width: 2048, jsonBytes: json.length, gzipBytes: gz.length, ratioPct: ratio,
      saveMs, openMs, longTaskCount: longTasks.length, longTaskMaxMs: Math.round(longTaskMax * 100) / 100,
      tileCount, docLayers: docBefore.layers.length,
      blobBytes: blob ? blob.size : 0, gzipMs, gzDirectBytes: gzBytes.length,
    },
    environment: { headless: /HeadlessChrome/.test(navigator.userAgent) },
  };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 240000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1800)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
