#!/usr/bin/env node
// v2/engine/test/doc.mjs —— T60 统一 V2Doc / 组/蒙版/剪贴/16 混合 / 序列化往返测试（零依赖 CDP）
// 用法：node v2/engine/test/doc.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const { BLEND_MODES, validateDoc } = await import('/v2/engine/src/v2doc.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const checks = {};
  async function inkOf(dataUrl) {
    const img = new Image(); img.src = dataUrl; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const cx = c.getContext('2d'); cx.drawImage(img, 0, 0);
    const d = cx.getImageData(0, 0, c.width, c.height).data;
    let ink = 0; for (let i = 0; i < d.length; i += 4) if (d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220) ink += 1;
    return ink;
  }
  function drawStroke(eng, x0, y0, n = 18) {
    eng.beginStroke({ x: x0, y: y0, pressure: 0.7, timestamp: performance.now(), pointerType: 'synthetic' });
    for (let i = 1; i < n; i += 1) eng.appendPoint({ x: x0 + i * 8, y: y0 + Math.sin(i / 4) * 8, pressure: 0.7, timestamp: performance.now(), pointerType: 'synthetic' });
    return eng.endStroke();
  }
  const makeEngine = async () => {
    const canvas = document.createElement('canvas');
    canvas.width = 512; canvas.height = 512;
    const eng = new Engine({ canvas, width: 512, height: 512, layers: 2 });
    await eng.init();
    eng.setBrush({ type: 'soft', sizePx: 24 });
    return eng;
  };

  const eng = await makeEngine();
  // 1) 组 + 图层
  const group = eng.addGroup('G1');
  const l1 = eng.addLayer({ name: 'L1' });
  drawStroke(eng, 80, 160);
  const l2 = eng.addLayer({ name: 'L2', group: group.id });
  drawStroke(eng, 80, 300);
  await raf(); await raf();
  checks.groupAndLayers = eng.getGroups().length >= 1 && eng.getLayers().filter((l) => l.group === group.id).length === 1;

  // 2) 16 混合模式
  let blendOk = true;
  for (const b of BLEND_MODES) { if (eng.setLayerBlend(l2.id, b) !== true || eng.getLayers().find((l) => l.id === l2.id).blend !== b) blendOk = false; }
  eng.setLayerBlend(l2.id, 'multiply');
  await raf();
  checks.blend16 = BLEND_MODES.length >= 16 && blendOk;

  // 3) 不透明度/可见性/剪贴/锁定
  eng.setLayerOpacity(l2.id, 0.6);
  eng.setLayerClip(l2.id, true);
  eng.setLayerVisible(l2.id, true);
  eng.setLayerLocked(l2.id, true);
  const lockedBegin = eng.beginStroke({ x: 100, y: 320, pressure: 0.7, timestamp: performance.now(), pointerType: 'synthetic' });
  checks.lockedBlocks = lockedBegin === false && eng.currentStroke == null;
  eng.setLayerLocked(l2.id, false);
  const inkAfterClip = await inkOf(await eng.getCompositeDataUrl());
  checks.clipRenders = inkAfterClip > 0;

  // 4) 蒙版：新建 → 画蒙版 → undo 恢复
  eng.setActiveLayer(l1.id);
  eng.addMask(l1.id);
  checks.maskExists = eng.getLayers().find((l) => l.id === l1.id).mask.exists === true;
  eng.setActiveTarget('mask');
  drawStroke(eng, 80, 160, 10);
  await raf(); await raf();
  const maskTilesAfter = eng.maskStore.listTiles(l1.id).length;
  const inkMasked = await inkOf(await eng.getCompositeDataUrl());
  eng.undo(); await raf();
  const maskTilesAfterUndo = eng.maskStore.listTiles(l1.id).length;
  checks.maskPaintAndUndo = maskTilesAfter > 0 && inkMasked > 0 && maskTilesAfterUndo <= maskTilesAfter;
  eng.setActiveTarget('layer');

  // 5) 文档结构 + 序列化往返
  const doc = eng.getDoc();
  const v = validateDoc(doc);
  checks.docValid = v.ok === true && doc.layers.length >= 3 && doc.groups.length === 1;
  const json = eng.serializeDoc();
  const container = JSON.parse(json);
  checks.serializeFormat = container.format === 'mozheng' && container.version === 1 && !!container.doc && !!container.tiles && json.length > 1000;

  const eng2 = await makeEngine();
  const loaded = eng2.deserializeDoc(json);
  await raf(); await raf();
  const countTiles = (st) => { let n = 0; for (const m of st.layers.values()) n += m.size; return n; };
  checks.deserializeDocEqual = JSON.stringify(loaded) === JSON.stringify(doc);
  checks.deserializeTiles = countTiles(eng2.store) === countTiles(eng.store)
    && countTiles(eng2.maskStore) === countTiles(eng.maskStore);
  const inkLoaded = await inkOf(await eng2.getCompositeDataUrl());
  checks.deserializeRenders = inkLoaded > 0;
  const deserializeDetail = { srcLayerTiles: countTiles(eng.store), dstLayerTiles: countTiles(eng2.store), srcMaskTiles: countTiles(eng.maskStore), dstMaskTiles: countTiles(eng2.maskStore), inkLoaded, jsonTilesKeys: Object.keys(JSON.parse(json).tiles || {}).length, jsonMaskKeys: Object.keys(JSON.parse(json).masks || {}).length };
  // 加载后继续编辑 + undo
  eng2.setActiveLayer(eng2.getLayers()[0].id);
  const entry = drawStroke(eng2, 200, 200, 12);
  await raf();
  const inkAfterContinue = await inkOf(await eng2.getCompositeDataUrl());
  const undone = eng2.undo();
  await raf();
  const inkAfterUndo = await inkOf(await eng2.getCompositeDataUrl());
  checks.loadContinueEditable = !!entry && undone === true && inkAfterContinue > 0 && inkAfterUndo <= inkAfterContinue;

  // 6) LayerSystem 共用 V2Doc（T60）
  const { LayerSystem } = await import('/v2/layers/layer-system.js');
  const engLS = await makeEngine();
  const ls = new LayerSystem(engLS);
  const lsDoc = ls.getDoc();
  const applied = ls.applyDoc(eng.getDoc());
  checks.layerSystemSharedDoc = lsDoc.schema === 'mozheng.doc.v1'
    && applied.layers.length === doc.layers.length
    && applied.groups.length === doc.groups.length
    && applied.layers.every((l) => l.mask && typeof l.mask.exists === 'boolean');
  engLS.dispose();

  eng.dispose(); eng2.dispose();
  checks.ok = Object.entries(checks).every(([k, val]) => typeof val !== 'boolean' || val);
  return { ok: checks.ok, checks, deserializeDetail, statsBefore: { layers: doc.layers.length, groups: doc.groups.length, masks: doc.layers.filter((l) => l.mask.exists).length }, jsonBytes: json.length, environment: { browser: (navigator.userAgent.match(/Chrome\\/[\\d.]+/) || [])[0] || '', headless: /HeadlessChrome/.test(navigator.userAgent) } };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1500)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
