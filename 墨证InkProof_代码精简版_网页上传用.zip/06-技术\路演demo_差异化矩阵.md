# 路演 demo 差异化矩阵（竞品 / 开源 / 墨证）

> 项目一 · 路演 demo v2｜作者：oss-scout｜版本：**v1.0**｜调研快照：**2026-11-07**（Asia/Shanghai）
> 任务：t4「竞品与开源项目差异化矩阵」。本文件回答四个问题：**别人已经做到哪、我们凭什么不一样、哪些做法可以借、评委怎么质疑。**
> 上游材料：`02-情报/竞品矩阵.md`（S1，15 产品）、`06-技术/开源杠杆清单.md`（T49）、`06-技术/GitHub开源采用清单.md`（T50）、`06-技术/多模态融合与开源借鉴.md`、`07-构想展开/03_技术架构与证据链.md`、`10-产品战略/项目创新点与技能架构.md`。
> 本文件不重复上述文档的逐产品长表，只保留**与路演 demo 直接相关的判据**，并补上 2026-11-07 的 GitHub / 官方文档核验。

---

## 0. 结论速览（给 Lead 与 t5）

1. **单点能力都不是全球唯一。** 选区局部重绘有 Photoshop 生成式填充、Krita AI Diffusion、InvokeAI、ComfyUI；读画布有 Krita AI Diffusion 的 Live Painting；对话有 Photoshop AI Assistant / Krea Agent / Recraft Agent；内容凭证有 Adobe Content Credentials（C2PA）。任何「只有我们做」的说法都会被评委一句话击穿。
2. **我们的差异是「同一条工作流里的三件事同时成立」**：① AI 的输入是编辑器状态、输出是**原生图层**（框外像素 0 变化、可撤销）；② AI 用的是**结构化、可确认、可回指的视觉记忆**（L0/L1/L2/L4/L5/L6 + 画像），不是风格码；③ 每次 AI 调用与人的决策都进**本地 SHA-256 事件链**，可第三方离线复核，且提供 **zero_generation 存证模式**。
3. **这三件事都能在 30–60 秒内当场证明**，不靠 PPT：`outsideDiff=0`、`verify-evidence 12/12`、`tamper → 失败`、`zero_generation=true`。证据文件与命令见 §3.5。
4. **最像我们的不是某一个产品，而是四个产品各占一角**：Photoshop AI Assistant（对话+读文档+局部改+Content Credentials）、Krita AI Diffusion（绘画软件内局部生成+本地+新图层）、InvokeAI（Unified Canvas+本地工作流）、Krea（实时画布+Agent+训练/上下文）。**没有一个是「绘画画布 + 结构化记忆 + 过程证据 + 开箱即用」的合体。**
5. **对外话术基调**：不比模型、不比实时、不比价格；只比「专业创作者卡住时，AI 能不能在画布里帮上忙，并且事后说得清」。

### 0.1 30 秒电梯稿（可直接背）

> 专业插画师真正卡住的时候，不是缺一张图，是不知道下一步往哪画。Photoshop 帮你改这一块，Krita 插件帮你重绘这一块，但没人把你的素材、你的决定、你的画布状态连起来。墨证把 AI 放进画布：它读你的选区、素材档案和你确认过的决定，给你方向；结果只落在选区里的新图层，框外一个像素不动；每一次调用和你的每个决定都进本地证据链，改一个字节就验不过。我们不是又一个生图工具，是画布原生的 AI 共创系统。

---

## 1. 方法与口径

### 1.1 采集方式与证据等级

| 等级 | 含义 | 本次用法 |
|---|---|---|
| **● 官方核验** | GitHub REST API（license/stars/pushed_at）、官方帮助中心/产品文档 | 许可、活跃度、功能存在性 |
| **◐ 官方文档部分/第三方** | 官方页受 JS/地域限制，或第三方评测 | 功能细节，标注不确定 |
| **○ observed absence** | 在 2026-11-07 可访问的官方文档/产品页上**未发现** | **不等于产品一定没有**；只用于「我们未发现」的表述 |
| **— 不适用** | 基础设施/标准，不是创作产品 | 避免误比 |

**限制（必须对评委诚实）**：
- 商业产品未逐一试用，功能以官方帮助中心为准；部分页面（Canva/Figma/Framer）本次抓取受地域跳转或 JS 渲染限制，已标注。
- GitHub stars / pushed_at 是 **2026-11-07 快照**，会变；只用于判断活跃度，不作为优劣证据。
- 本矩阵不比较价格与模型数量（demo 现场不比这些）；价格信息见 `02-情报/竞品矩阵.md`。

### 1.2 六个判据的定义

| 判据 | 判定标准（本矩阵口径） |
|---|---|
| **画布原生** | AI 的输入/输出是否直接工作在**可编辑的绘画/图层文档**上；不是「聊天框里出图」或「节点图」 |
| **结构化记忆** | 是否跨会话保存**可查看、可修改、可被 AI 引用的结构化创作记忆**（区域/观察/决策/偏好）；风格码、图集、LoRA 只算 ◐ |
| **过程证据** | 是否记录**创作过程中的事件与 AI 调用**并可复核；C2PA/Content Credentials 算 ●，但它是发布端内容凭证，不是本地过程审计（见 §3.3） |
| **本地** | 编辑器、档案、证据是否在本机；模型是否可本地/离线；仅桌面客户端但 AI 全云只算 ◐ |
| **PSD** | 是否能导入/导出 PSD 并保留图层/组/蒙版等结构；只支持导入或只支持扁平化算 ◐ |
| **多模态对话** | 是否支持**以图像/画布/选区/标注为输入的对话**，而不是纯文本 prompt 或纯节点连线 |

### 1.3 三条阅读规则

1. **「有」不等于「好用」**：Photoshop 有 Content Credentials，但它不是绘画工作流；Krita AI Diffusion 有局部生成，但要 GPU + ComfyUI + 模型下载。
2. **「没有」只代表本次未发现**：尤其是商业产品的 Agent 功能迭代很快；对外说「未发现」而不是「他们没有」。
3. **差异必须可现场证明**：本文件每条硬差异都配「现场动作 + 屏幕证据 + 量化结果 + 失败降级」，否则不进路演脚本。

---

## 2. 能力 / 定位对比总表

图例：**● 有/原生｜◐ 部分/近似｜○ 未发现/不具备｜— 不适用**。
「结构化记忆」「过程证据」按 §1.2 的严格口径；商业产品的「记忆」多为品牌资产/风格/文档上下文，故多为 ◐。

### 2.1 开源 / 可借鉴项目

| 产品/项目 | 类型 · 创作对象 | 画布原生 | 结构化记忆 | 过程证据 | 本地 | PSD | 多模态对话 | 关键事实与限制 |
|---|---|---|---|---|---|---|---|---|
| **Krita AI Diffusion**（Acly） | Krita 插件 · 绘画 | ● | ○ | ○ | ● | ◐ | ○ | GPL-3.0；选区 inpainting/outpaint、Live Painting、Regions、ControlNet/IP-Adapter、任务队列/历史；**本地推荐 6GB VRAM + Krita 5.2+ + ComfyUI 后端**；云生成可选 |
| **ComfyUI** | 节点工作流 · 生成/编辑 | ○ | ◐ | ○ | ● | ○ | ◐ | GPL-3.0；节点图不是绘画画布；可搭出 mask/对比/区域；工作流与 LoRA 是「资产」不是创作记忆；Comfy Agent 是「描述→建流程」，不是创作对话 |
| **InvokeAI** | SD 工作台 · 生成/编辑 | ● | ○ | ○ | ● | ○（未核实） | ○ | Apache-2.0；Unified Canvas（图层、inpaint/outpaint、区域提示、队列/画廊）；强在模型与批量，本地 GPU；无对话/档案/证据 |
| **Fooocus** | 简化 SDXL · 生成 | ○ | ○ | ○ | ● | ○ | ○ | GPL-3.0；离线、SDXL、inpaint/outpaint、image prompt、风格预设；官方已进入 LTS（只修 bug）；无绘画画布/记忆/证据 |
| **Krita** | 绘画软件 · 绘画 | ● | ○ | ○ | ● | ◐ | ○ | GPL-3.0；笔刷/图层/选区/动画；PSD 导入强、导出有限；无原生生成式 AI |
| **GIMP** | 图像编辑 · 修图/合成 | ● | ○ | ○ | ● | ● | ○ | GPL-3.0；3.2.8（2026-11-02）；PSD 导入/导出；无原生生成式 AI |
| **Penpot** | 设计平台 · UI/矢量 | ● | ◐ | ○ | ● | ○ | ○ | MPL-2.0；自托管；设计资产/令牌是「设计系统记忆」，不是 AI 创作记忆；无绘画/PSD |
| **tldraw** | 无限画布 SDK · 白板 | ● | ○ | ○ | ◐ | ○ | ○ | **自定义许可**：无商业授权不得用于生产、不得禁用 License Key、不得作为独立产品分发；只能读思路，**不采用代码** |
| **Excalidraw** | 白板 · 手绘图表 | ● | ○ | ○ | ◐ | ○ | ○ | MIT；轻量白板/协作；无绘画图层/PSD/AI 记忆 |
| **Graphite** | 节点式 2D 创作 · 设计/动效 | ● | ○ | ○ | ● | ○ | ○ | Apache-2.0；Rust/WASM、程序化节点；节点图是文档不是 AI 记忆；无对话/证据 |
| **Loro** | CRDT 库 · 协作基础设施 | — | — | — | ● | — | — | MIT；给「多人/多端共创 + 版本」用；不是创作产品 |
| **Yjs** | CRDT 库 · 协作基础设施 | — | — | — | ● | — | — | **MIT**（已核 LICENSE 原文；GitHub API 误报 Other）；同上 |
| **C2PA / Content Credentials** | 内容凭证标准 · 发布/分发 | — | ○ | ● | ● | — | — | 开放标准（C2PA 2.x），`c2pa-rs` 为 Apache-2.0；记录来源/编辑动作/签名，**不是创作工具**；本地 SDK 可验，但信任依赖签名与证书链 |

**开源快照（2026-11-07）**

| 项目 | 许可 | Stars | 最近 push | 备注 |
|---|---|---:|---|---|
| Acly/krita-ai-diffusion | GPL-3.0 | 10,850 | 2026-11-06 | 活跃 |
| Comfy-Org/ComfyUI | GPL-3.0 | 145,545 | 2026-11-07 | 非常活跃 |
| invoke-ai/InvokeAI | Apache-2.0 | 29,014 | 2026-11-07 | 活跃 |
| lllyasviel/Fooocus | GPL-3.0 | 53,833 | 2025-12-01 | LTS，只修 bug |
| KDE/krita | GPL-3.0 | 10,708 | 2026-11-07 | 活跃 |
| penpot/penpot | MPL-2.0 | 62,156 | 2026-11-07 | 活跃 |
| tldraw/tldraw | 自定义（NOASSERTION） | 51,399 | 2026-11-07 | **生产需授权** |
| excalidraw/excalidraw | MIT | 135,281 | 2026-11-07 | 活跃 |
| GraphiteEditor/Graphite | Apache-2.0 | 27,855 | 2026-11-07 | 活跃 |
| loro-dev/loro | MIT | 6,279 | 2026-11-07 | 活跃 |
| yjs/yjs | MIT（LICENSE 原文） | 23,031 | 2026-11-05 | 维护中 |
| contentauth/c2pa-rs | Apache-2.0 | 440 | 2026-11-07 | 标准 SDK |

> 说明：GIMP 官方仓库不在 GitHub，未列 stars；Krita AI Diffusion / ComfyUI / Fooocus / Krita / GIMP 为 **GPL 红线**，只可读文档/行为，不复制代码。

### 2.2 商业产品

| 产品 | 类型 · 创作对象 | 画布原生 | 结构化记忆 | 过程证据 | 本地 | PSD | 多模态对话 | 关键事实与限制 |
|---|---|---|---|---|---|---|---|---|
| **Adobe Photoshop**（生成式填充 + AI Assistant + Content Credentials） | 专业图像编辑 · 修图/合成/插画 | ● | ◐ | ● | ◐ | ● | ● | 选区生成→新图层、非破坏；AI Assistant 可读文档、给分步建议/自动执行、AI Markup 圈画+提示；Content Credentials（C2PA）；**AI 在云、需账号；目标修图效率，不是绘画方向/素材档案** |
| **Adobe Firefly** | 创意 AI Studio · 生成/品牌 | ◐ | ◐ | ● | ○ | ○ | ◐ | Firefly Boards（画板/评论/变体）、Custom Models（自训风格）、Gen Fill/Expand/Remove/Upscale、partner models；支持 Content Credentials（C2PA）；**云、非绘画画布、无结构化创作记忆** |
| **Recraft** | 品牌/矢量设计 · 设计 | ◐ | ◐ | ○ | ○ | ○ | ● | Studio 空白画布 + Chat/Create 双 tab + Agent；Custom Styles（≤10 参考图、权重）；编辑保留原图生成新版本；**设计白板，不是绘画；无证据链** |
| **Krea** | 实时 AI 创作 · 设计/概念 | ◐ | ◐ | ○ | ○ | ○ | ● | Realtime 双栏画布（左画/右输出，512/1024px）；Training（≥3 张→style code）；Agent + Context Library（Session/My Context/Workspace）；**实时渲染不是可编辑绘画图层；无证据链** |
| **Midjourney** | 生成器 · 审美/概念 | ○ | ◐ | ○ | ○ | ○ | ◐ | 无绘画画布；Personalization（评分）+ Moodboards（图集→code）+ sref/oref；V8.2 Edit Model；**图片级/风格码，无结构化记忆；Conversational Mode 细节待核实** |
| **Canva Magic Studio** | 在线设计 · 平面/营销 | ◐ | ◐ | ○ | ○ | ○ | ◐ | Magic Edit/Expand/Grab/Write/Switch、Brand Kit；设计画布+模板；**云 only；品牌资产不是创作过程记忆；无 PSD/过程证据** |
| **Figma AI**（含 Figma Make / Figma Weave） | 设计协作 · UI/工作流 | ◐ | ◐ | ○ | ○ | ○ | ◐ | Figma AI agents、Figma Make（prompt→code）、Figma Weave（图像/视频/音频节点工作流，Figma node 可选「哪些图层可被 AI 改」）；**云、设计画布/节点，不是绘画；无过程证据** |
| **Framer AI** | 网站搭建 · 网页 | ○ | ○ | ○ | ○ | ○ | ◐ | AI agents「design, build, manage websites」；**品类不同（网站生成），不是图像/绘画创作** |
| **墨证 InkProof（本项目）** | 画布原生 AI 共创 · 专业绘画 | ● | ● | ● | ◐ | ● | ● | 编辑器/档案/证据本地；模型 API 可选（Qwen），Mock 完全离线；L0/L1/L2/L4/L5/L6 + 画像；选区 mask 局部落层；SHA-256 事件链 + `zero_generation` 存证；PSD 6 样本结构/像素 100%（文字层明确报告不支持） |

> 商业产品「过程证据」列：Photoshop/Firefly 记 ● 是因为 **Content Credentials（C2PA）**；但它记录的是「内容凭证/编辑动作/签名」，不记录本地 AI 调用的 provider/model/token/latency，也不提供「零生成」声明。详见 §3.3。

### 2.3 六判据小结：谁最接近我们

| 对手 | 它已经有的（不能否认） | 它没有的（我们的空档） | 对我们的威胁等级 |
|---|---|---|---|
| **Photoshop AI Assistant + Gen Fill** | 对话、读文档状态、分步建议/自动执行、AI Markup、局部非破坏、Content Credentials、PSD | 绘画画布与笔刷工作流；**结构化素材档案/决策记忆**；本地无账号；**AI 调用的过程级证据**；卡住时的「方向建议」 | **高**（最容易说「这不就是 PS」） |
| **Krita AI Diffusion** | 绘画软件内选区生成、Live Painting、Regions、本地、新图层、历史/队列、PSD 导入 | **对话**；**素材档案/偏好记忆**；**证据链**；开箱即用（无需 GPU/ComfyUI/模型下载）；跨会话「记得你」 | **高**（最容易说「开源早就有」） |
| **InvokeAI** | Unified Canvas（图层/inpaint/outpaint/区域提示）、本地、队列/画廊、Apache-2.0 | **对话**；**记忆**；**证据**；绘画手感/PSD；开箱即用（GPU） | 中高 |
| **Krea** | 实时画布、Agent、Training、Context Library | **可编辑绘画图层**；PSD；**证据**；本地；**结构化可确认记忆** | 中 |
| **C2PA / Content Credentials** | 内容凭证标准、签名、编辑动作、生态（Adobe/Google/OpenAI/Meta…） | 创作工具本身；**本地过程审计**；**零生成声明**；素材档案/决策 | 中（是「标准」不是「产品」，应合作/兼容） |

**一句话**：最接近的是 Photoshop（对话+证据）与 Krita AI Diffusion（画布+局部），但它们各占一半；**把两半接起来、再加「结构化记忆」和「本地过程证据」，就是我们**。

---

## 3. 我们凭什么不一样：3 条硬差异 + 现场证明

> 原则：**不吹「全球唯一」**。每条都按「对手到哪 → 我们多什么 → 现场怎么证明 → 量化证据 → 失败降级」写，t5 可直接改成分镜。

### 3.1 硬差异 D1：空间意图 → 原生图层（AI 在画布里工作，不在聊天框里）

**差异表述**
> AI 的输入不是一段 prompt，而是**编辑器状态**：选区/当前图层/画布标注/素材引用/最近决策；输出不是聊天里的一张图，而是**带 mask 的新图层**——可变换、可蒙版、可撤销，**框外像素严格不变**。

**对手到哪**
- Photoshop 生成式填充：选区→生成→新图层，非破坏；但它面向「改这里」，不读你的素材档案/决策，也不给「画到一半往哪走」的方向。
- Krita AI Diffusion：选区→局部重绘→新图层，本地；但它是 Krita 插件，需 GPU/ComfyUI/模型，且无对话/记忆/证据。
- InvokeAI/ComfyUI：有 mask/局部，但工作台/节点图，不是「一张画布 + 对话」的创作体验。

**我们多什么**
1. **选区 + 画布图像 + 标注 + 素材 + 档案一起进上下文**（不是只传一段 prompt）；
2. **候选先画布原位预览**，可「对比原图」滑杆，再决定落层；
3. **落层按选区 alpha 裁切**，`mask_policy=selection_alpha`，框外 `outsideDiff=0`；
4. 落层自动进变换框，**一步 undo**；AI 从不直接改原画；
5. AI 的观察**锚定回画布**（可定位、可确认/否决），而不是只给一段文字。

**现场 30–60 秒怎么演**
1. 打开示例画布 → 框选「卡住的地方」（例如雾带与远山交界）；
2. 让 AI 看看 → 观察带定位框 → 确认一条；
3. 选一个方向 → 生成候选 → 画布原位预览 + 对比滑杆；
4. 落为新图层 → 隐藏新层（原画完全回来）→ Ctrl+Z（一步撤销）→ 再落层；
5. 口播：「框外一个像素都没动；这不是贴图，是图层。」

**屏幕证据 / 量化**
- `v2/app/test-mask-compare-result.json`（2026-11-07 21:22）：
  - `cases.mask.outsideDiff = 0`，`insideDiff = 62,245,096`，`pixels = 960,000`；
  - `cases.apply.layers = 3`，`transformActive = true`，`records[0].masked = true`，`mask_policy = selection_alpha`，`skill = image.generate`；
  - `maskOk/compareOk/applyOk/noErrors = true`，`pass = true`。
- `v2/qa/tools/qwen-image-edit-app-results.json`：真实 Qwen 图像编辑 51.1s、2416×1728、sha256 `b8790a18…`；落层后 `layers 2→3`、`transformActive=true`、`undo=1`；`pass=true`。
- 代码路径：`v2/app/js/app.js` 的 `applyCandidate`（mask 裁切/落层/变换）、`v2/qa/tools/verify-evidence.mjs`（证据链复核）。

**失败降级**
- 网络/模型失败：自动降级 Mock 同流程（界面明确标 Mock），仍能演示「预览→落层→框外不变→undo」；
- 候选不满意：重试/换方向/丢弃，不落层；
- 大图慢：demo 用 1200×800 示例，避免 4096²（当前 4096² mask 写入与长任务有已知性能问题，见 §7.3）。

**一句话话术**
> 「Photoshop 帮你改这一块；我们让 AI 看懂你为什么卡在这一块，并且只动这一块。」

---

### 3.2 硬差异 D2：结构化视觉记忆（AI 记得的不是风格，是你的决定）

**差异表述**
> 素材不是缩略图，而是**可被 AI 读取、可被人确认/否决、可被对话回指的结构化档案**：L0 原件、L1 整体、L2 区域、L4 观察、L5 决策、L6 事件 + 偏好画像；记忆在本地、可见、可改、可清空。

**对手到哪**
- Midjourney Personalization/Moodboards、Krea Training、Recraft Custom Styles、Firefly Custom Models：都是**图片集 → 风格码/黑箱模型**，解决「像不像我」，不解决「我为什么这样画、我做过什么决定」。
- Photoshop CC Libraries / AI Assistant 文档上下文：有文档级上下文，但没有跨项目的「素材观察 + 人的确认/否决」档案。
- Krea Context Library（Session/My Context/Workspace）：有偏好/工作区记忆，但仍是文件/偏好级，不是可逐条确认的结构化视觉档案。

**我们多什么**
1. **L1/L2/L4 锚定在图上**：区域 bbox、观察可定位；确认/否决写回 L5，成为下次 AI 的依据；
2. **素材可作 0–3 张参考进入生成/编辑**；AI 结果可回库，带 provenance（model/refs/prompt/sha256）；
3. **对话上下文显式携带**：选区、整幅画布、素材库、档案/证据、画像（可开关）；真实 provider 侧 history `slice(-30)`、单条 4000 字符；
4. **画像可查看/可编辑/可清空**，建议写入前标「建议·尚未写入」；清空 AI 记忆只删对话+画像，保留素材/档案；
5. **行动建议 chips 只导航/预填，不自动执行、不自动加参考**（T112 独立 QA 19/19）。

**现场 30–60 秒怎么演**
1. 打开素材库 → 选「雾中山谷」→ 展示 L1（冷灰蓝/几何山脊/雾带/水面）、L2 五个区域框、L4 四条观察；
2. 点「确认」一条观察（例如「雾带把远山与近水分成三层」）→ 写回档案；
3. 打开 AI 对话 → 指给观众看上下文条：选区图 / 整幅画布 / 素材库 3 / 档案 / 画像；
4. 问：「按我确认过的观察，给我三个下一步方向」→ AI 回复**回指**那条观察与画像（风格「冷灰蓝、留白、颗粒」）；
5. 口播：「这不是‘AI 记得你’的玄学，是左边这些可查看、可修改、可清空的字段。」

**屏幕证据 / 量化**
- `v2/qa/tools/asset-real-read-results.json`：Qwen 真实重读 **22,955ms**，`L1` 摘要、`L2=5`、`L4=4`、`confidence=0.96`、`skill=asset.decompose`、`source=real`、`model=qwen3.8-max`、`3332 tokens`，`pass=true`。
- `v2/qa/tools/T111-final-qa.md` 焦点 #6：对话 payload 含「选区 300×200、素材库 3 张、档案 0 条、我记住的你是：风格『冷灰蓝、留白、颗粒』、结合画面和对话上下文（images 已传）」；L6 `context_flags{selection,canvas,library,archive}` 全 true，`images=2`。
- `v2/qa/tools/T112-final-qa.md`：画像建议「建议·尚未写入」；行动 chips 执行面只导航/prefill，`/api/ai/*` 请求 0；清空 AI 记忆删 chat+profile、素材/档案不变；13 项回归 + 19 项焦点全 PASS。
- 代码路径：`v2/app/js/app.js` 的 `buildChatContext`（library/archive/recent_events/profile/flags）、`renderProfile`（画像）、`confirmObservation`（L5 写回）。

**失败降级**
- 真实视觉重读 20–25s：可先用本地即时初读（L1/L2/L4 的 Mock/本地分析）撑住画面，再点「真实读」补真实结果；
- 网络失败：明确标 Mock/失败，不伪造「真实已读」；证据包会区分 real/mock；
- 记忆不想展示：一键关闭画像 chip / 清空对话；素材与档案保留。

**一句话话术**
> 「Midjourney 记住的是你的图集，我们记住的是你确认过的那句话。」

---

### 3.3 硬差异 D3：过程证据（创作现场可复核，且能证明「没用 AI」）

**差异表述**
> 每次 AI 调用、素材引用、观察确认/否决、落层/变换/文字修改，都写成 L6 事件；事件用 SHA-256 链串起来，证据包带画布哈希、图层哈希、AI manifest（provider/model/calls/tokens/latency/network_requests）与素材引用；**零依赖 CLI 可离线复核；改一个字节就失败**。另有**存证模式**（AI 禁用），证据包标记 `zero_generation=true`，用于「这幅画没有用生成式 AI」的交付声明。

**对手到哪**
- Adobe Content Credentials / C2PA：**行业标准**，记录内容来源、编辑动作、AI 使用与签名，生态强（Adobe/Google/OpenAI/Meta/Sony…）；但它是**发布端内容凭证**，依赖签名/证书链，通常与账号/云服务绑定；不记录本地每次 AI 调用的 token/latency，也不提供「零生成」模式。
- 开源工作流（ComfyUI/InvokeAI/Krita AI Diffusion）：PNG 元数据/工作流 JSON 可留存，但没有**跨事件哈希链 + 第三方复核器 + 人/AI 决策分层**。
- 其他商业产品：未见原生「创作过程证据包」；多为文件元数据或平台内历史。

**我们多什么**
1. **事件链**：`genesis=64×0` → `chain_hash = SHA-256(prev + canonicalJson(record))`；任一事件被改，该条及之后全部失配；
2. **证据包 `inkproof.evidence.v1`**：`project.canvas.sha256`、`manifest.layers[].sha256`、`manifest.ai`（real/mock 拆分）、`refs`（素材→L1/L2）、`events`（含 chain_prev/chain_hash）、`canvas_png_data_url`；
3. **第三方复核器**：`node v2/qa/tools/verify-evidence.mjs <json>`，12 项检查，退出码 0/1；
4. **篡改可检出**：事件/链头/画布/AI 计数四类篡改全部按预期失败（`verify-evidence-test-results.json`）；
5. **存证模式**：AI 禁用，画布/档案/证据照常记录，`attest.zero_generation=true`；这是「专业交付/约稿合规」的强差异；
6. **边界诚实**：证据证明「过程记录与像素一致、未被篡改」，**不证明法律意义上的作者身份**；对外必须区分（`07-构想展开/03_技术架构与证据链.md` §8）。

**现场 30–60 秒怎么演**
1. 正常协作后导出证据包 → 屏幕显示：事件数、链头哈希、画布 SHA-256、AI 调用（provider/model/tokens/latency）、网络请求数、图层哈希；
2. 在终端跑 `node v2/qa/tools/verify-evidence.mjs inkproof-evidence.json` → `ok:true`、12 项 checks 全 true；
3. 复制一份 JSON，改一个字符（例如某事件的 note）→ 再跑 → `ok:false`、`chainHash: 事件 N 链哈希不匹配`；
4. 切到「存证模式」→ 画一笔 → 导出 → `zero_generation=true`，再复核通过；
5. 口播：「这不是一张带水印的图，是一份可以离线验的过程记录；改一个字节就露馅。」

**屏幕证据 / 量化**
- `v2/qa/tools/qwen-real-e2e-results.json`：真实 Qwen 视觉 **21,337ms / 1271 tokens / 1 次真实调用**；证据 `ok=true`，12 项 checks 全 true；`events=6`、`head_hash=4862f79b…`。
- `v2/qa/tools/verify-evidence-test-results.json`：合法包 12/12；`tamperEvent` → `chainHash: 事件 2 链哈希不匹配`；`tamperHead` → `headHash` 不一致；`tamperCanvas` → 画布 SHA-256 不匹配；`tamperAiCalls` → `aiCalls`/`aiSplit` 失败；`pass=true`。
- `v2/qa/tools/qwen-real-evidence.json`：真实证据包样例（schema `inkproof.evidence.v1`，canvas sha256、layer sha256、manifest.ai、events）。
- 代码：`v2/qa/tools/verify-evidence.mjs`、`v2/app/core/hash-chain.mjs`、`v2/app/js/app.js` 的 `buildEvidence`。

**失败降级**
- 现场终端不可用：把复核器输出预先截屏/录屏，但**必须标注「预生成证据」**，并同时展示证据包 JSON 的哈希字段；
- 网络失败：使用已生成的 Mock 证据包演示「链 + 篡改失败」，明确标 Mock（`manifest.ai.mock_calls>0`、`network_requests=0`）；
- 不要在现场改生产证据包做篡改演示：复制一份临时副本，避免污染交付证据。

**一句话话术**
> 「C2PA 告诉别人这张图从哪来；我们告诉创作者，这一笔到底是人画的还是 AI 画的、用了哪个模型、你确认过什么。」

---

### 3.4 支撑差异（不 wow，但能挡追问）

| 支撑点 | 事实 | 为什么能挡追问 |
|---|---|---|
| **模型无关的 Skill Runtime** | 5 个平台 Skill：`asset.decompose` / `canvas.observe` / `canvas.directions` / `image.generate` / `image.edit`；Qwen/Kimi/混元预设；Skill 负责上下文构建/ schema 校验/ fallback/ L6 记录 | 回应「不就是套壳 Qwen」：换模型，体验与证据字段不变 |
| **本地优先 + 密钥不进前端** | `v2/serve.mjs` 只监听 `127.0.0.1`；密钥只在本地 `.ai-config.json`/代理；前端只看 `hasKey/keyLast4`；Mock 离线 | 回应「隐私/安全」：作品、档案、证据、密钥都在本机 |
| **PSD 互通** | 6 样本往返：结构 100%、像素 100%、蒙版 6/6；文字层不支持时生成 `fidelity_report`，不静默丢弃 | 回应「专业交付」：不是另起格式；但别吹「PSD 全兼容」 |
| **非破坏 + 结构化图层** | 调整层 `kind:'adjust'`（参数化栅格层）、文字层 `kind:'text'`、落层/变换/文字/粘贴均一步 undo | 回应「和 Procreate/PS 比」：编辑基本功可继续用 |
| **Mock/真实双模式** | Mock 离线可复现；真实调用手动确认、失败可读、证据区分 real/mock | 回应「演示是不是假的」：每个数字都能对上证据字段 |

---

### 3.5 现场证据清单（可直接照做）

| # | 证据 | 路径 | 现场命令/动作 | 期望输出 |
|---|---|---|---|---|
| E1 | 框外像素不变 | `v2/app/test-mask-compare-result.json` | 落层→隐藏新层→Ctrl+Z；或运行 `node v2/app/test-mask-compare.mjs`（需 Edge + python） | `outsideDiff:0`、`masked:true`、`mask_policy:selection_alpha`、`pass:true` |
| E2 | 真实视觉 + 证据复核 | `v2/qa/tools/qwen-real-e2e-results.json`、`qwen-real-evidence.json` | 导出证据包 → 终端复核 | `ok:true`，12/12 checks，21.3s，1271 tokens |
| E3 | 篡改失败 | `v2/qa/tools/verify-evidence-test-results.json` | 复制 JSON 改 1 字符 → 复核 | `ok:false`，`chainHash` 不匹配 |
| E4 | 素材结构化记忆 | `v2/qa/tools/asset-real-read-results.json` | 素材库「真实读」→ 看 L1/L2/L4/标签/模型 | 22.955s，L2=5，L4=4，`source=real` |
| E5 | 对话上下文/画像 | `v2/qa/tools/T111-final-qa.md`、`T112-final-qa.md` | 对话 → 看上下文条/画像 → 问「按我确认过的观察…」 | payload 含选区/素材/档案/画像；回复回指 |
| E6 | PSD 往返 | `v2/psd/results/fidelity.json` | 导入 PSD → 导出 → 看 `fidelity` 报告 | 结构 100%、像素 100%、蒙版 6/6；文字层报告 |
| E7 | 存证模式 | 同 E2 | 切存证模式 → 画一笔 → 导出证据 | `zero_generation:true`，复核通过 |

> 注意：E1 的 `test-mask-compare.mjs` 会启动 `python -m http.server 8158` 并写 `v2/app/test-mask-compare-result.json`；现场跑之前先在备份环境试一遍，避免端口/Edge 版本问题。E2/E3 的复核器零依赖，只要有 Node 即可。

---

## 4. 可借鉴的交互 / 工程做法（含 license 边界）

> 总原则（与 T49/T50 一致）：**MIT/BSD/Apache 可移植（保留版权/NOTICE）；MPL 文件级 copyleft；GPL 只读思路、clean-room 重写、不复制/不链接/不随产品分发；tldraw 自定义许可不采用代码；商业产品只参考行为，不复制资产/UI。**

### 4.1 借鉴清单

| 来源 | 许可 | 值得借鉴的具体做法 | 我们怎么用（现状/下一步） | 禁止动作 |
|---|---|---|---|---|
| **Krita AI Diffusion** | GPL-3.0 | ① 选区优先、强度滑杆、结果预览再应用；② Regions（用图层定义区域→各自文本）；③ Live Painting「AI 实时看画布」；④ 历史/任务队列；⑤ 本地/云双模式 | ①②⑤ 已落地（选区/候选/多方向/本地+云）；③ 不做实时（延迟 20–50s），改成「AI 观察锚点」；④ 已落地（素材批量重读队列 T113） | 不复制代码；不把插件代码嵌入产品；不随包分发 |
| **ComfyUI** | GPL-3.0 | ① mask 编辑器 + 结果对比；② 队列/历史；③ 工作流可保存/复用；④ 描述→建流程（Comfy Agent） | ① 已落地（对比滑杆/原位预览）；② 已落地（串行队列/进度/失败不阻塞）；③ 可借鉴为「Skill 工作流模板」（下一步）；④ 不做（我们是对话/画布，不是节点） | 不复制节点/执行引擎；不嵌入；若未来独立进程 HTTP 调用，先法务确认 |
| **InvokeAI** | Apache-2.0 | ① Unified Canvas：图层 + inpaint/outpaint + 区域提示；② 队列/画廊；③ 参数/元数据随图 | ① 大部分已有（图层/选区/局部）；可借鉴「区域提示」的 UI（下一步）；② 已有队列；③ 已有 L6/AI manifest | 代码可用但需保留 LICENSE/NOTICE；当前无需引入 |
| **Fooocus** | GPL-3.0 | ① 用预设隐藏参数、降低门槛；② inpaint/outpaint 的简单入口；③ 性能模式 | ① 可借鉴为 demo 的「一键方向」预设；② 已有；③ 不做（我们模型在云） | 不复制代码；不复制风格模板/资产 |
| **Krita / GIMP** | GPL-3.0 | ① 笔刷/选区/图层/变换的产品范式；② 非破坏调整/滤镜层；③ PSD 工作流 | ① 已参考（交互/手感）；② 已有调整层（T115）；③ 已有 PSD（T39） | 不复制 GPL 代码/图标/笔刷资产 |
| **Photoshop AI Assistant** | 商业 | ① 「do it for me / show me how」两种模式；② AI Markup 圈画+提示；③ 选区→新图层；④ Content Credentials 的「凭证 pin」UI | ① 已有「观察/方向/行动建议」；可加「分步建议」；② 已有画布标注（红圈/箭头）；③ 已有；④ 证据面板可借鉴「pin/摘要」表达（下一步） | 不复制 UI/图标/文案；不做「PS 兼容」承诺 |
| **Firefly Boards** | 商业 | ① 参考板/情绪板 → 生成；② Custom Models 的「风格训练」入口；③ Content Credentials（C2PA） | ① 已有「素材引用 ≤3 张」；② 不做训练（用素材档案替代）；③ 已有证据包（更细） | 不复制资产/模型；不宣称「商用授权」 |
| **Figma Weave** | 商业 | ① 明确「哪些图层可被 AI 改」；② 节点工作流与设计文件双向关联 | ① 已有「选区/当前图层/整图」范围；可加「AI 可改范围锁」（下一步）；② 不做节点 | 不复制节点/工作流资产 |
| **Excalidraw** | MIT | ① 轻量工具/撤销栈/本地持久化；② 协作房间 | ① 已参考；② 多人协作暂不做（见 Loro/Yjs） | MIT 可代码复用，但需署名；当前不整包引入（体积/风格） |
| **tldraw** | 自定义 | 无限画布/相机/shape utils/undo manager 的**架构思路** | 仅阅读，不采用代码 | **禁止**：生产使用、禁用 License Key、作为独立产品分发、复制代码 |
| **Graphite** | Apache-2.0 | ① 节点式程序化、非破坏；② Rust/WASM 性能架构 | ① 已借鉴「参数化调整层」（T115）；② 暂不引入 Rust/WASM | 代码可用但需 NOTICE；当前不引入 |
| **Loro / Yjs** | MIT | CRDT：多人/多端同步、离线合并、版本 | **未来**「共创会话/跨设备撤销」的候选；当前不做（demo 不需要） | 无（MIT），但别把协作复杂度带进 demo |
| **C2PA / Content Credentials** | Apache-2.0（c2pa-rs） | ① `c2pa.actions` 记录编辑/AI 动作；② ingredient hash；③ 凭证展示方式 | **兼容而非替代**：证据 schema 可映射到 C2PA actions（下一步 PoC）；对外明确「尚未做 C2PA 签名/一致性认证」 | 不宣称「C2PA 兼容/认证」；不使用未授权签名证书 |

### 4.2 许可红线执行规则

| 许可类型 | 代表项目 | 可以做 | 必须做 | 禁止 |
|---|---|---|---|---|
| **MIT / BSD-3 / ISC** | Excalidraw、Yjs、Loro、Klecks、perfect-freehand、ag-psd | 复制、修改、商用、分发 | 保留版权声明与许可全文；写 `THIRD_PARTY_NOTICES`；BSD-3 不得用作者名背书 | 移除版权头；用作者名做推广 |
| **Apache-2.0** | InvokeAI、Graphite、c2pa-rs、Playwright、Comlink | 复制、修改、商用、专利授权 | 保留 LICENSE + NOTICE；修改文件注明 | 移除 NOTICE；暗示作者背书 |
| **MPL-2.0** | Penpot | 用于 larger work；修改 MPL 文件需开源该文件 | 保留许可；修改文件源码可得 | 修改 MPL 文件后不公开该文件源码 |
| **GPL-3.0** | **Krita、Krita AI Diffusion、ComfyUI、Fooocus、GIMP** | 阅读文档/代码、参考行为、独立进程 HTTP 调用（需法务） | 若分发衍生作品，整体 GPL 兼容 | **复制、修改、链接进产品、随产品分发、把代码片段贴进仓库** |
| **自定义** | **tldraw** | 阅读思路 | — | **生产使用（无商业授权）、禁用 License Key、作为独立产品分发、复制代码** |
| **商业** | Photoshop/Firefly/Recraft/Krea/Canva/Figma/Framer/Procreate | 行为参考、公开文档引用 | 标注来源 | 复制 UI/图标/资产/文案；反向工程；宣称兼容/授权 |

### 4.3 明确禁止（写死，防止后人误引）

- **GPL 代码**：Krita、Krita AI Diffusion、ComfyUI、Fooocus、GIMP——**一行都不进仓库**；只允许读文档/行为，clean-room 重写并在文档注明来源。
- **tldraw 代码**：不采用；其许可明确「不得用于生产环境、不得禁用 License Key、不得作为独立产品分发」。
- **模型权重/素材**：不下载/不分发 Qwen、SDXL、Flux 等权重；不复制商业产品的示例图/笔刷/纹理；字体/笔刷/纹理单独核许可。
- **「兼容」话术**：不做「PSD 全兼容」「C2PA 认证」「Photoshop 插件」这类未实现的承诺。

### 4.4 本项目已用开源台账（勿重复造轮子）

| 项目 | 许可 | 用途 | 状态 |
|---|---|---|---|
| CanvasKit / Skia | BSD-3 | 渲染/合成/编解码 | 已 vendor |
| Klecks | MIT | present/整帧 blit、tile undo、LineSmoothing | 已 clean-room 改写（T49） |
| ag-psd | MIT | PSD 导入/导出 | 已 vendor |
| perfect-freehand | MIT | 笔迹轮廓 | 已接（T52） |
| Playwright-core | Apache-2.0 | QA 自动化 | 已用（仅 dev） |
| 本项目自有 | — | 档案/证据/哈希链/Skill | 持续 |

> 许可登记与 NOTICES 以 `v2/engine/vendor/THIRD_PARTY_NOTICES.md` 与 `06-技术/开源杠杆清单.md` 为准；新增依赖前先更新 NOTICES。

---

## 5. 评委可能提出的「这不就是 XX 吗」

> 用法：每条先给**一句话回答**（现场就说这句），再给「追问备答」。回答原则：先承认对方说得对的部分，再指出「同一条工作流里缺的那一环」。

| # | 质疑 | 一句话回答 | 追问备答 |
|---|---|---|---|
| Q1 | 这不就是 **Photoshop 生成式填充**？ | PS 解决「改这里」；我们解决「画到一半不知道往哪画」，而且 AI 读的是你的素材档案和确认过的决定。 | PS 的 AI Assistant 确实能读文档、给步骤；但它没有「素材 L1/L2/L4 + L5 决策」这层记忆，也不给你「三个方向」；我们的结果落层后还能继续画、继续改、进证据链。 |
| Q2 | 这不就是 **Krita AI Diffusion**？ | 它是 Krita 的本地重绘插件，强在选区/局部；我们是「画布 + 对话 + 记忆 + 证据」的完整工作台，且不需要 GPU/ComfyUI。 | 它确实有 Live Painting/Regions/本地；但无对话、无素材档案、无证据链；装它要 Krita 5.2+、6GB VRAM、ComfyUI 和后端模型。 |
| Q3 | 这不就是 **ComfyUI**？ | ComfyUI 是给专家的节点工作流；我们让创作者在一张画布上「框一下、说一句」，不用搭流程。 | 我们能导出/记录 Skill 调用；未来可以把 Skill 映射成工作流模板，但 demo 不比节点数量。 |
| Q4 | 这不就是 **InvokeAI**？ | InvokeAI 是 SD 工作台，强在模型/批量/Unified Canvas；我们强在「读你的画 + 记得你的决定 + 可举证」，且不要求本地 GPU。 | 它的 Canvas 有图层/区域提示，确实强；但没有对话记忆和过程证据；我们的目标用户是画到一半的插画师，不是模型调参玩家。 |
| Q5 | 这不就是 **Krea 实时画布**？ | Krea 是你画草图、它实时渲染；我们不让 AI 覆盖你的画，AI 只在选区里给候选、落新图层、可撤销。 | Krea 的 Realtime 是双栏生成，不是可编辑绘画图层；Training/Context Library 是风格/偏好级记忆；没有 PSD/证据。 |
| Q6 | 这不就是 **Midjourney 的 moodboard/风格训练**？ | 那是「像不像我」的图片级黑箱；我们是「我为什么这样画」的结构化档案，能逐条确认/否决/回指。 | Moodboard 是图集→code；我们的 L2 是区域 bbox、L4 是可确认观察、L5 是人的决策；这些字段在证据包里可复核。 |
| Q7 | 这不就是 **Adobe 的 Content Credentials / C2PA**？ | 对，C2PA 是好标准；但它是发布端的内容凭证，我们记录的是创作现场的每次 AI 调用与人的决策，本地离线可验。 | 我们不宣称 C2PA 认证；未来可把事件映射成 C2PA actions。它证明「内容从哪来」，我们证明「这一笔谁做的、用了什么模型、你确认了什么」。 |
| Q8 | 这不就是 **Canva / Figma 的 AI**？ | 它们服务平面/UI 交付，画布是排版/设计画布；我们服务绘画创作，图层/笔刷/选区/PSD 是原生对象。 | Figma Weave 的「选哪些图层可被 AI 改」很像我们的范围控制；但它是节点工作流、云、设计文件，不是绘画过程。 |
| Q9 | 这不就是 **ChatGPT 生图**？ | 聊天框看不到你的画布状态，也不能「只改这里、框外不动、落层继续画」；我们不把意图压成一段文字。 | 通用助手的对话/多模态确实强；但它没有编辑器状态（选区/图层/undo/素材档案），也没有过程证据。 |
| Q10 | 这不就是 **套壳 Qwen**？ | Qwen 是能力供给；我们的护城河是 Skill Runtime（上下文/校验/降级/证据）+ 画布/素材/图层/证据的深度集成；换模型体验不变。 | 同一 Skill 可跑 Qwen/Kimi/混元；证据里记录 provider/model；真实/Mock 可区分。模型会变，工作流和证据不会。 |
| Q11 | 这不就是 **Framer AI**？ | Framer 生成网站，我们生成/修改绘画作品；品类不同。 | 它的 AI agents 面向网页设计/搭建；没有笔刷画布、PSD、素材档案。 |
| Q12 | 你们是不是**抄开源**？ | 我们站在成熟项目肩膀上：MIT/BSD/Apache 的复用都登记在 NOTICES；GPL 项目只读思路、clean-room 重写，不复制代码。 | 可以现场打开 `THIRD_PARTY_NOTICES` 与 `开源杠杆清单`；Klecks/ag-psd/CanvasKit 的许可动作都有记录。 |
| Q13 | 你们的**证据能当法律证据吗**？ | 不能；它证明「过程记录与像素一致、未被篡改」，不证明法律意义上的作者身份。 | 我们明确区分「过程完整性」与「法律鉴定」；如果要做法律级，需要签名/时间戳/公证，这是下一步。 |
| Q14 | **离网能用吗**？ | 编辑器、档案、证据、Mock 完全离线；真实模型需要联网，密钥只在本机。 | 现场可以先演示 Mock 全流程，再联网跑一次真实 Qwen；界面会标 Mock/真实。 |
| Q15 | **延迟 20–50 秒**怎么路演？ | 我们不装实时；等待期用阶段进度 + 叙事 + 可取消，结果先预览再落层。 | 真实数据：视觉 21.3s、素材重读 22.955s、图像编辑 51.1s；demo 只安排 1 次视觉 + 1 次编辑，其余用 Mock/缓存并标注。 |

---

## 6. 不要说的话（反例 / 改口）

| 不要说 | 为什么危险 | 改说 |
|---|---|---|
| 「全球唯一/没人做过」 | 评委举出 Krita AI Diffusion/PS 就翻车 | 「在我们调研的 20+ 产品中，未发现同时具备画布原生 + 结构化记忆 + 过程证据的；最接近的是 PS 和 Krita AI Diffusion，各占一半」 |
| 「完全本地/完全离线」 | 真实模型是云 API | 「编辑器、档案、证据、密钥本地；模型 API 可选，Mock 完全离线」 |
| 「实时 AI」 | 真实延迟 20–50s | 「候选先预览，落层可继续改；不做实时渲染」 |
| 「C2PA 兼容/认证」 | 未做签名/一致性认证 | 「证据 schema 可映射 C2PA actions；目前不做签名/认证，C2PA 是互补标准」 |
| 「法律级证据/版权证明」 | 过度承诺 | 「过程完整性可复核；法律鉴定需签名/时间戳/公证」 |
| 「AI 记得你」 | 容易被当成玄学 | 「AI 读取你确认过的 L4/L5 与画像；字段可见、可改、可清空」 |
| 「PSD 全兼容」 | 文字层/智能对象不支持 | 「6 样本结构/像素 100%；文字层会明确报告不支持，不静默丢弃」 |
| 「零生成」泛用 | 只在存证模式成立 | 「存证模式下 AI 禁用，证据包标记 zero_generation=true」 |
| 「我们比 PS 强」 | 引战且不真实 | 「PS 是修图标准；我们补的是绘画创作中的「卡住时刻」与过程证据」 |
| 「开源项目都是我们的」 | 许可/原创性质疑 | 「MIT/BSD/Apache 复用已登记；GPL 只读思路、clean-room；自研部分是画布/档案/证据/Skill」 |

---

## 7. 给 t5 / t6 的输入：必演 / 备选 / 不要演

### 7.1 必演 3 个瞬间（与 §3 三条硬差异一一对应）

| 瞬间 | 时长 | 画面 | 量化证据 | 失败降级 |
|---|---|---|---|---|
| **M1 卡住→局部协作→落层** | 2.5–3 min | 框选 → AI 观察（定位框）→ 确认 → 方向 → 候选原位预览/对比 → 落层 → 隐藏/undo | `outsideDiff=0`、`masked=true`、`transformActive=true`、`undo=1` | Mock 同流程；候选不满意重试 |
| **M2 记忆回指** | 1.5–2 min | 素材 L1/L2/L4 → 确认一条 → 对话上下文条 → 问方向 → AI 回指观察/画像 | 22.955s、L2=5、L4=4；payload 含选区/素材/档案/画像 | 本地初读先撑住；真实读失败标 Mock |
| **M3 证据包 + 篡改 + 存证** | 2–2.5 min | 导出证据 → 终端复核 12/12 → 改 1 字符 → 失败 → 存证模式 zero_generation | `ok:true`→`ok:false`；`zero_generation:true` | 预生成证据（标注）+ JSON 字段展示 |

剩余 2–3 分钟：开场人设/作品（30s）、PSD/编辑基本功（30–45s）、收尾（30s）、Q&A 缓冲。

### 7.2 备选 2 个（时间富余或评委追问时）

- **B1 模型无关**：同一 Skill 切换 Qwen → Mock（或另一 provider），界面/证据字段不变；30 秒，适合回应「套壳」。
- **B2 PSD 往返**：打开 PSD → 改一层 → 导出 → 看 fidelity 报告；45 秒，适合回应「专业交付」。

### 7.3 不要演 4 个（当前风险）

1. **4096² 大图 + mask**：T117 实测 `maskWriteMs 7.3–9.7s`、e2e 14.7s、longtask 10.7s；现场会卡。
2. **调整层「仅作用选区」的边界用例**：T117 仍在集成/QA 收口中（结果文件在更新，取消勾选后 mask 残留、undo/redo mask 恢复等仍有未过项）；修复并独立 QA 通过前，不作为 wow 点。
3. **大批量真实素材重读**：真实单张 22.955s，批量会超时/烧钱；用 Mock 批量 + 单张真实。
4. **复杂 PSD/智能对象/文字层可编辑**：文字层不支持，复杂智能对象不保证；只演已知 6 样本。

### 7.4 时间与 API 预算（供 t5 排分镜）

| 动作 | 真实耗时 | 成本口径 | demo 建议 |
|---|---|---|---|
| 画布视觉观察（canvas.observe） | 21.3s | 1271 tokens | 1 次（M1） |
| 素材真实重读（asset.decompose） | 22.955s | 3332 tokens | 1 次或预生成（M2） |
| 图像编辑（qwen-image-3.0-pro） | 51.1s | billed=true（按次） | 1 次（M1 后段）；可用缓存候选 |
| 对话（qwen3.8-max） | 2.689s / 端到端 3.108s（`qwen-chat-real-results.json`） | 330 tokens | 1–2 次（M2） |
| Mock | 0 网络 | ¥0 | 兜底全流程 |

> 现场建议：**真实调用 ≤3 次**（视觉 + 编辑 + 对话），其余 Mock/预生成真实缓存；每次真实调用前界面确认，失败可读、可取消。

### 7.5 真实 / 缓存 / Mock 标注规则（不伪造）

- **真实**：证据里 `mock=false`、`network_requests>0`、有 `request_id`/`latency`/`usage`；界面显示 provider/model。
- **预生成真实缓存**：由真实调用产生，带 `request_id`/sha256；界面必须标「预生成（真实调用录制）」，不能假装现场。
- **Mock**：`mock=true`、`network_requests=0`；界面标 Mock/¥0/不联网；不能把 Mock 说成真实。
- **失败**：写 L6 `status=error`，界面可读；不隐藏、不重试成假成功。

---

## 8. 待核实清单（交给后续/红队）

| # | 事项 | 为什么重要 | 建议核实方式 |
|---|---|---|---|
| 1 | Photoshop AI Assistant 的地区/版本可用性、AI Markup 细节 | 评委可能追问「PS 不是也有」 | 官方帮助 + 实测（有账号环境） |
| 2 | Firefly 是否有「创作对话」（非 Boards/agentic） | 影响 Q1/Q8 答法 | Adobe 官方帮助/发布说明 |
| 3 | Canva Magic Studio 当前功能与 Brand Kit 记忆边界 | 影响 Q8 | canva.com 官方页（本次受地域跳转） |
| 4 | Figma AI agents / Weave 的「图层可改范围」细节 | 影响 D1 的「范围控制」对比 | Figma Help / Weave FAQ |
| 5 | InvokeAI 是否支持 PSD 导出 | 表格中标 ○（未核实），需确认 | InvokeAI 官方文档/仓库 |
| 6 | Krita PSD 导出能力边界 | 表格 ◐ 的依据 | Krita 官方文档 |
| 7 | C2PA 2.3 `c2pa.actions` / `digitalSourceType` 与 AI 生成声明 | 未来映射证据 schema | C2PA spec 2.3 |
| 8 | Midjourney Conversational Mode 现状 | 表格 ◐ 的依据 | Midjourney 官方 docs |
| 9 | Krea 定价/套餐（非 demo 重点） | 商业假设 | Krea 官方 pricing（本次失败） |
| 10 | 各产品「过程证据」是否有未公开功能 | 避免 observed absence 误判 | 官方帮助中心/实测 |

---

## 9. 参考链接（GitHub / 官方文档）

### 9.1 开源项目与许可

- Krita AI Diffusion：https://github.com/Acly/krita-ai-diffusion （GPL-3.0）；文档 https://docs.interstice.cloud/
- ComfyUI：https://github.com/Comfy-Org/ComfyUI （GPL-3.0）；官网 https://www.comfy.org/
- InvokeAI：https://github.com/invoke-ai/InvokeAI （Apache-2.0）；Canvas 文档 https://invoke-ai.github.io/InvokeAI-7/users-guide/canvas/introduction/
- Fooocus：https://github.com/lllyasviel/Fooocus （GPL-3.0）
- Krita：https://github.com/KDE/krita （GPL-3.0）；官网 https://krita.org/
- GIMP：https://www.gimp.org/ （GPL-3.0）
- Penpot：https://github.com/penpot/penpot （MPL-2.0）；官网 https://penpot.app/
- tldraw：https://github.com/tldraw/tldraw （自定义许可，生产需授权）；许可原文 https://github.com/tldraw/tldraw/blob/main/LICENSE.md
- Excalidraw：https://github.com/excalidraw/excalidraw （MIT）
- Graphite：https://github.com/GraphiteEditor/Graphite （Apache-2.0）；官网 https://graphite.art/
- Loro：https://github.com/loro-dev/loro （MIT）；官网 https://loro.dev/
- Yjs：https://github.com/yjs/yjs （MIT，LICENSE 原文已核）；文档 https://docs.yjs.dev/
- c2pa-rs：https://github.com/contentauth/c2pa-rs （Apache-2.0）

### 9.2 C2PA / Content Credentials

- C2PA 官网：https://c2pa.org/
- C2PA 规范 2.3：https://spec.c2pa.org/specifications/specifications/2.3/specs/C2PA_Specification.html
- Content Credentials：https://contentcredentials.org/
- 验证入口：https://verify.contentauthenticity.org/
- Photoshop 帮助：为图像添加 Content Credentials https://helpx.adobe.com/photoshop/desktop/save-and-export/metadata-content-credentials/use-content-credentials.html

### 9.3 商业产品官方文档

- Photoshop 生成式填充：https://helpx.adobe.com/photoshop/desktop/create-open-import-images/create-images/edit-images-with-generative-fill.html
- Photoshop AI Assistant：https://helpx.adobe.com/photoshop/desktop/get-started/set-up-toolbars-panels/edit-images-with-ai-assistant.html
- Photoshop AI Assisted Editor：https://helpx.adobe.com/photoshop/desktop/generative-ai/use-ai-assisted-mode.html
- Adobe 博客（AI in Photoshop/Firefly，2026-03-10）：https://blog.adobe.com/en/publish/2026/03/10/image-editing-just-got-smarter-with-ai-photoshop-firefly
- Firefly 帮助：https://helpx.adobe.com/firefly/web.chromeless.html
- Firefly Custom Models：https://helpx.adobe.com/firefly/web/custom-models/get-started-with-custom-models/custom-models-overview.chromeless.html
- Recraft Studio 文档：https://www.recraft.ai/docs/recraft-studio/overview
- Recraft Custom Styles：https://www.recraft.ai/docs/recraft-studio/styles/custom-styles/how-to-create-a-custom-style.md
- Krea 文档：https://krea.mintlify.dev/docs
- Krea Realtime：https://krea.mintlify.dev/docs/user-guide/features/realtime.md
- Krea Training：https://krea.mintlify.dev/docs/user-guide/features/training.md
- Krea Agent Context Library：https://krea.mintlify.dev/docs/user-guide/agent/context-library-and-skills.md
- Midjourney Moodboards：https://docs.midjourney.com/hc/en-us/articles/39193335040013-Moodboards
- Midjourney Edit Model：https://docs.midjourney.com/hc/en-us/articles/48495453462797-Edit-Model
- Canva Magic Studio：https://www.canva.com/magic-studio/
- Figma AI 帮助：https://help.figma.com/hc/en-us/sections/24369548041111
- Figma Weave FAQ：https://help.figma.com/hc/en-us/articles/35965787376919-Figma-Weave-FAQ
- Framer AI：https://www.framer.com/ai/

### 9.4 本项目证据（现场可复核）

- `v2/app/test-mask-compare-result.json`（outsideDiff=0）
- `v2/qa/tools/qwen-real-e2e-results.json`（21.337s / 12/12）
- `v2/qa/tools/qwen-real-evidence.json`（证据包样例）
- `v2/qa/tools/verify-evidence-test-results.json`（4 类篡改失败）
- `v2/qa/tools/asset-real-read-results.json`（22.955s / L2=5 / L4=4）
- `v2/qa/tools/qwen-image-edit-app-results.json`（51.1s / 落层/undo）
- `v2/psd/results/fidelity.json`（6 样本结构/像素 100%）
- `v2/qa/tools/T111-final-qa.md`、`T112-final-qa.md`（上下文/画像/行动 chips）
- `v2/qa/tools/T117-mask-qa-result.json`（调整层蒙版 QA 进行中；修复前勿用于 demo）

---

## 10. 变更记录

| 版本 | 日期 | 变更 |
|---|---|---|
| 1.0 | 2026-11-07 | 建立开源/商业/标准 22 项对比矩阵（6 判据）；3 条硬差异 + 现场证明（E1–E7）；可借鉴做法与许可红线（GPL/tldraw/商业）；15 条评委 Q&A；10 条禁止话术；t5 必演/备选/不要演与 API 预算；10 项待核实；参考链接 |
