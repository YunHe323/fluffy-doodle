#!/usr/bin/env node
// v2/engine/test/doc-size.mjs —— T66 测量：.mozheng 体积 / tile 整块 vs bbox 裁剪 PNG（仅测量，不改格式）
// 用法：node v2/engine/test/doc-size.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));

  function draw(eng, n, y, len) {
    eng.beginStroke({ x: 100, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
    for (let i = 1; i < n; i += 1) eng.appendPoint({ x: 100 + len * i / (n - 1), y: y + Math.sin(i / 5) * 20, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
    eng.endStroke();
  }

  async function bboxPngBytes(dataUrl) {
    const img = new Image(); img.src = dataUrl; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    let x0 = c.width, y0 = c.height, x1 = 0, y1 = 0, found = false;
    for (let y = 0; y < c.height; y += 1) for (let x = 0; x < c.width; x += 1) {
      if (d[(y * c.width + x) * 4 + 3] > 0) { found = true; if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y; }
    }
    if (!found) return { bytes: 0, bbox: null };
    const w = Math.max(1, x1 - x0 + 1), h = Math.max(1, y1 - y0 + 1);
    const cc = document.createElement('canvas'); cc.width = w; cc.height = h;
    cc.getContext('2d').drawImage(c, -x0, -y0);
    const out = cc.toDataURL('image/png');
    return { bytes: Math.ceil((out.length - 'data:image/png;base64,'.length) * 3 / 4), bbox: { x: x0, y: y0, w, h }, full: { w: c.width, h: c.height } };
  }

  async function gzipLen(str) {
    try {
      const enc = new TextEncoder().encode(str);
      const cs = new CompressionStream('gzip');
      const stream = new Blob([enc]).stream().pipeThrough(cs);
      const buf = await new Response(stream).arrayBuffer();
      return buf.byteLength;
    } catch (e) { return null; }
  }

  async function probe(width) {
    const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = width;
    const eng = new Engine({ canvas, width, height: width, layers: 1, presentRetained: false });
    await eng.init();
    eng.setBrush({ type: 'soft', sizePx: 32 });
    draw(eng, 40, 100, 300); draw(eng, 40, 400, 300); draw(eng, 40, 700, 200);
    await raf(); await raf();
    const json = eng.serializeDoc();
    const container = JSON.parse(json);
    const tiles = [];
    for (const [layerId, map] of Object.entries(container.tiles || {})) {
      for (const [key, b64] of Object.entries(map)) {
        const dataUrl = 'data:image/png;base64,' + b64;
        const fullBytes = Math.ceil(b64.length * 3 / 4);
        const cropped = await bboxPngBytes(dataUrl);
        tiles.push({ key, fullBytes, croppedBytes: cropped.bytes, bbox: cropped.bbox, full: cropped.full });
      }
    }
    const fullTileBytes = tiles.reduce((s, t) => s + t.fullBytes, 0);
    const croppedTileBytes = tiles.reduce((s, t) => s + t.croppedBytes, 0);
    const gz = await gzipLen(json);
    eng.dispose();
    return {
      width,
      jsonBytes: json.length,
      jsonGzipBytes: gz,
      tileCount: tiles.length,
      fullTileBytes,
      croppedTileBytes,
      bboxSavedPct: fullTileBytes ? Math.round((1 - croppedTileBytes / fullTileBytes) * 1000) / 10 : 0,
      tileSamples: tiles.slice(0, 8),
      serializeMB: Math.round(json.length / 1048576 * 100) / 100,
    };
  }

  const out = {};
  out.d1024 = await probe(1024);
  out.d2048 = await probe(2048);
  return {
    schema: 'mozheng.doc-size.v1',
    generatedAt: new Date().toISOString(),
    env: { headless: /HeadlessChrome/.test(navigator.userAgent) },
    results: out,
    notes: [
      '当前 .mozheng 每 tile 存整块 256² PNG base64（未裁剪/未压缩容器）',
      'bbox 数值为 PNG 裁剪后再编码（不含 tile 边界 padding，实际可加 1–2px 防接缝）',
      'gzip 仅估算容器 JSON 压缩；fflate/UPNG 未安装（按 T66 要求只评估）',
    ],
  };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 240000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1500)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(0);
