// v2/app/test-qwen-real.mjs — T101 真实 Qwen 生图候选（使用 4200 现有 serve + 本机 .ai-config，不打印/不改 key）
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const URL = 'http://127.0.0.1:4200/v2/app/index.html';
const out = { schema: 'mozheng.app.qwen-real.v1', at: new Date().toISOString(), cases: {}, errors: [] };
const hard = setTimeout(() => { out.fatal = 'HARD_TIMEOUT_300s'; write(); process.exit(3); }, 300000);
function write() { try { fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'test-qwen-real-result.json'), JSON.stringify(out, null, 2), 'utf8'); } catch (e) {} }
let browser = null;
try {
  const health = await fetch('http://127.0.0.1:4200/api/ai/health').then((r) => r.json());
  out.cases.health = { provider: health.provider, hasKey: health.hasKey, mode: health.mode };
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await ctx.addInitScript(() => {
    try { localStorage.setItem('mozheng.ai.settings.v1', JSON.stringify({ preset: 'qwen', allowReal: true, requireConfirm: false, privacyMode: false })); } catch (e) { /* ignore */ }
  });
  const page = await ctx.newPage();
  page.setDefaultTimeout(120000);
  page.on('pageerror', (e) => out.errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') out.errors.push(m.text()); });
  await page.goto(URL, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
  await page.waitForTimeout(1200);
  await page.evaluate(() => window.__V2_APP__.t96.refreshConfig());
  await page.waitForTimeout(600);
  out.cases.settings = await page.evaluate(() => ({ token: !!window.__AI_LOCAL_TOKEN__, settings: window.__V2_APP__.t96.getSettings(), state: window.__V2_APP__.t96.getState() }));
  // 框选（默认选择工具 + 鼠标拖拽）
  await page.evaluate(() => window.__V2_APP__.setTool('select'));
  const box = await page.locator('#mainCanvas').boundingBox();
  await page.mouse.move(box.x + box.width * 0.34, box.y + box.height * 0.30);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width * 0.64, box.y + box.height * 0.70, { steps: 8 });
  await page.mouse.up();
  await page.waitForTimeout(400);
  out.cases.selection = await page.evaluate(() => window.__V2_APP__.state.selection);
  // 真实 analyze
  const tA = Date.now();
  await page.evaluate(async () => { await window.__V2_APP__.runAnalyze({ noRecords: false }); });
  out.cases.analyze = await page.evaluate(() => { const a = window.__V2_APP__; return { ms: 0, analysis: !!a.state.analysis, observations: a.state.analysis ? a.state.analysis.observations.length : 0, meta: a.t96.getLastCall(), badge: a.t96.providerBadge(), l6: a.t96.getL6AiCalls().slice(-1)[0] }; });
  out.cases.analyze.ms = Date.now() - tA;
  // 真实 directions
  const tD = Date.now();
  await page.evaluate(async () => { await window.__V2_APP__.runDirections(); });
  out.cases.directions = await page.evaluate(() => { const a = window.__V2_APP__; return { dirs: (a.state.directions || []).length, meta: a.t96.getLastCall(), l6: a.t96.getL6AiCalls().slice(-1)[0] }; });
  out.cases.directions.ms = Date.now() - tD;
  // 真实 generate（Qwen-Image）
  const tG = Date.now();
  await page.evaluate(async () => { const a = window.__V2_APP__; await a.runGenerate(a.state.directions[0].id); });
  out.cases.generate = await page.evaluate(() => { const a = window.__V2_APP__; const c = (a.state.candidates || [])[0]; return { candidates: (a.state.candidates || []).length, meta: a.t96.getLastCall(), badge: a.t96.providerBadge(), candidate: c ? { id: c.id, label: c.label, sha256: c.sha256, bytes: c.bytes, width: c.width, height: c.height, imagePrefix: String(c.imageDataUrl || '').slice(0, 30), imageLen: String(c.imageDataUrl || '').length } : null, l6: a.t96.getL6AiCalls().slice(-1)[0], note: (document.querySelector('.ai-candidate-note') || {}).textContent }; });
  out.cases.generate.ms = Date.now() - tG;
  const dataUrl = await page.evaluate(() => { const a = window.__V2_APP__; const c = (a.state.candidates || [])[0]; return c ? c.imageDataUrl : null; });
  if (dataUrl && dataUrl.startsWith('data:image/png;base64,')) {
    fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'qwen-real-candidate.png'), Buffer.from(dataUrl.split(',')[1], 'base64'));
    out.cases.generate.sampleFile = 'v2/app/qwen-real-candidate.png';
  }
  // 三档候选截图
  await page.evaluate(() => window.__V2_APP__.openPopover('popAI'));
  const candidateShots = [];
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await page.setViewportSize({ width: w, height: h });
    await page.waitForTimeout(250);
    await page.screenshot({ path: path.join(ROOT, 'v2', 'app', 'ui-ai-qwen-real-candidate-' + w + '.png') });
    candidateShots.push('v2/app/ui-ai-qwen-real-candidate-' + w + '.png');
  }
  // 落层
  const beforeLayers = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.evaluate(() => { const b = document.querySelector('[data-cand="0"]'); if (b) b.click(); });
  for (let i = 0; i < 40; i += 1) { await page.waitForTimeout(250); const n = await page.evaluate((b) => window.__V2_APP__.engine.getLayers().length - b, beforeLayers); if (n > 0) break; }
  out.cases.apply = await page.evaluate((before) => { const a = window.__V2_APP__; const gen = [...a.state.records].reverse().find((r) => r.layer === 'L6' && r.kind === 'generation'); return { layerDelta: a.engine.getLayers().length - before, layers: a.engine.getLayers().length, generation: gen, note: (document.querySelector('.ai-candidate-note') || {}).textContent }; }, beforeLayers);
  // 三档落层截图
  const applyShots = [];
  for (const [w, h] of [[1920, 1080], [1536, 864], [1366, 768]]) {
    await page.setViewportSize({ width: w, height: h });
    await page.waitForTimeout(250);
    await page.screenshot({ path: path.join(ROOT, 'v2', 'app', 'ui-ai-qwen-real-applied-' + w + '.png') });
    applyShots.push('v2/app/ui-ai-qwen-real-applied-' + w + '.png');
  }
  // undo
  await page.evaluate(() => window.__V2_APP__.engine.undo());
  await page.waitForTimeout(500);
  out.cases.undo = await page.evaluate(() => ({ layers: window.__V2_APP__.engine.getLayers().length, canUndo: window.__V2_APP__.engine.canUndo() }));
  out.cases.undo.delta = out.cases.undo.layers - out.cases.apply.layers;
  // 证据 manifest
  await page.evaluate(async () => { window.__evidence = await window.__V2_APP__.buildEvidence(); });
  out.cases.evidence = await page.evaluate(() => { const m = window.__evidence && window.__evidence.manifest; return { event_count: m && m.event_count, ai: m && m.ai, zero_generation: m && m.attest && m.attest.zero_generation, real_calls: m && m.ai && m.ai.real_calls }; });
  out.cases.screenshots = { candidates: candidateShots, applied: applyShots };
  out.pass = {
    settings: out.cases.settings.state.realEligible === true && out.cases.settings.state.preset === 'qwen' && out.cases.settings.state.label === 'Qwen' && out.cases.settings.settings.preset === 'qwen',
    analyze: out.cases.analyze.analysis && out.cases.analyze.meta && out.cases.analyze.meta.provider === 'qwen' && out.cases.analyze.meta.mock === false && out.cases.analyze.ms > 3000,
    directions: out.cases.directions.dirs > 0 && out.cases.directions.meta && out.cases.directions.meta.provider === 'qwen' && out.cases.directions.meta.mock === false,
    generate: out.cases.generate.candidates > 0 && out.cases.generate.meta && out.cases.generate.meta.provider === 'qwen' && out.cases.generate.meta.mock === false && out.cases.generate.candidate && /^[0-9a-f]{64}$/i.test(String(out.cases.generate.candidate.sha256)) && out.cases.generate.candidate.imageLen > 10000,
    apply: out.cases.apply.layerDelta === 1 && out.cases.apply.generation && out.cases.apply.generation.model.provider === 'qwen' && out.cases.apply.generation.model.model === 'qwen-image-3.0' && out.cases.apply.generation.params.candidate_sha256 && out.cases.apply.generation.cost_cny === 0,
    undo: out.cases.undo.delta === -1,
    evidence: out.cases.evidence.real_calls >= 2 && out.cases.evidence.zero_generation === false,
    screenshots: candidateShots.length === 3 && applyShots.length === 3,
    noConsoleErrors: out.errors.length === 0,
  };
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && (e.stack || e));
  out.errors = out.errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} finally {
  clearTimeout(hard);
  try { await browser.close(); } catch (e) {}
  write();
  process.exit(0);
}
