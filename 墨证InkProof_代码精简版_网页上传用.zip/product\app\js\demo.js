// product/app/js/demo.js
// 一键演示（Demo Tour）· 按 05-交互/产品v0.1设计系统.md §11 实现。
// 真实驱动 UI：调用与手动操作相同的处理函数；支持暂停/继续、上一步/下一步、退出（Esc）、接管；
// 页面级聚光 + 旁白卡；数据隔离（演示沙盒不写用户作品）；尊重 prefers-reduced-motion。
import { state, emit, $, sleep, toast, showCanvasToast, setStatusHint, clamp } from './state.js';
import {
  askAi, decideObservation, selectDirection, generateProposals, previewProposal,
  acceptProposal, setMode, revealObservations, flashLayerRow, renderAiPanel, updateStatusBar
} from './ui.js';
import { renderOverlay, pulseRect } from './canvas.js';
import { openEvidenceModal } from './evidence.js';

const STEP_COUNT = 8;
const REDUCED = () => !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
let actions = {};
const demo = {
  active: false,
  paused: false,
  aborted: false,
  fast: false,
  index: 0,
  bound: false,
  userProjectId: null,
  narrVisible: false
};

/* ---------------- 八步定义（§11.3） ---------------- */
const STEPS = [
  {
    title: '加载内置示例项目',
    narr: '先看一张示例作品——全程本地模拟，不上传任何东西。',
    target: ['#canvasWrap'],
    stay: 3000,
    async run() {
      await actions.beginSandbox();
      await pace(900);
      setStatusHint('演示：已加载内置示例项目（3 个图层）');
      await pace(1500);
    }
  },
  {
    title: '自动框选「卡住」区域',
    narr: '画到一半卡住？用框选圈出觉得别扭的地方。',
    target: ['#canvasWrap', '[data-tool="select"]'],
    stay: 5000,
    async run() {
      const rect = { x: 300, y: 430, w: 440, h: 250 };
      state.selection = rect;
      emit('selection:changed', rect);
      emit('log', { type: 'selection_set', actor: 'user', payload: { selection: { mode: 'rect', rect: { x: rect.x, y: rect.y, width: rect.w, height: rect.h } }, demo: true } });
      renderOverlay();
      if (!REDUCED()) pulseRect(rect);
      showCanvasToast('演示：已自动框选一块「卡住」区域', 2600);
      setStatusHint('演示：已框选卡住区域 · 下一步让 AI 看看');
      await pace(4200);
    }
  },
  {
    title: '让 AI 看看 → 观察卡逐条出现',
    narr: '点「让 AI 看看」——它只读你框选的区域和你的档案。',
    target: ['#aiBody'],
    stay: 8000,
    async run() {
      await askAi();
      const total = state.observations.length;
      if (REDUCED()) {
        revealObservations(total);
        await pace(2400);
      } else {
        for (let n = 1; n <= total; n += 1) {
          revealObservations(n);
          await pace(800);
        }
        await pace(2200);
      }
    }
  },
  {
    title: '确认一条 · 否决一条（写回档案）',
    narr: '观察带锚点、置信度、三态标记。不对就点「不对」，下次它会记住。',
    target: ['#aiBody .obs-list', '#aiBody'],
    stay: 7000,
    async run() {
      const obs = state.observations;
      if (obs[0]) decideObservation(obs[0].id, 'confirm');
      await pace(2400);
      if (obs[1]) decideObservation(obs[1].id, 'reject');
      await pace(2600);
      setStatusHint('演示：确认 → 写入 user-confirmed + L5；否决 → 写入 L5 reject_ai');
      await pace(1200);
    }
  },
  {
    title: '选方向 → 生成模拟方案 → 落为新图层',
    narr: '选一个方向，模拟方案会落成新图层：可隐藏、可删除、可撤销。',
    target: ['#aiBody .dir-list', '#aiBody'],
    stay: 8000,
    async run() {
      if (state.directions[0]) selectDirection(state.directions[0].id);
      await pace(1000);
      await generateProposals();
      await pace(1400);
      const proposal = state.proposals[0];
      if (proposal) {
        previewProposal(proposal.id);
        await pace(1800);
        const layer = await acceptProposal();
        await pace(1000);
        if (layer) {
          flashLayerRow(layer.id);
          setStatusHint('演示：AI 方案已落为独立图层（可移动 / 隐藏 / 删除 / 撤销）');
        }
      }
      await pace(1400);
    }
  },
  {
    title: '导出证据包（时间线 / 哈希链 / 零生成）',
    narr: '导出证据包：时间线、哈希、AI 事件清单；AI 事件不可隐藏。',
    target: ['#evidenceModal .modal', '#btnMenuExport'],
    stay: 7000,
    async run() {
      await openEvidenceModal();
      await pace(4200);
      setStatusHint('演示：证据包含时间线事件、AI 事件、图层 SHA-256、manifest 与零生成声明');
      await pace(1200);
    }
  },
  {
    title: '切到存证模式 → AI 禁用态',
    narr: '切到存证模式：AI 关闭，证据包输出「零生成」声明。',
    target: ['.mode-switch'],
    stay: 6000,
    async run() {
      actions.closeModal('evidenceModal');
      await pace(700);
      setMode('attest');
      await pace(2800);
      setStatusHint('演示：存证模式下 AI 已关闭，证据包输出零生成声明');
      await pace(1200);
    }
  },
  {
    title: '演示结束 · 自己试试',
    narr: '演示结束。你可以自己试试，或回到你的作品。',
    target: ['#demoEnd'],
    stay: 0,
    async run() {
      await pace(500);
      showEndCard();
      setStatusHint('演示结束 · 可以自己试试，或回到你的作品');
    }
  }
];

/* ---------------- 节奏 / 暂停闸门 ---------------- */
async function pace(ms) {
  const actual = demo.fast ? Math.min(100, Math.round(ms * 0.12)) : ms;
  await sleep(actual);
  await gate();
  if (demo.aborted) throw new Error('DEMO_ABORT');
}
async function gate() {
  while (demo.paused && demo.active) await sleep(150);
  if (demo.aborted || !demo.active) throw new Error('DEMO_ABORT');
}

/* ---------------- 聚光 / 旁白（§11.5） ---------------- */
function targetRect(step) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  for (const sel of step.target || []) {
    const el = document.querySelector(sel);
    if (!el) continue;
    const r = el.getBoundingClientRect();
    if (r.width < 8 || r.height < 8) continue;
    const ratio = (r.width * r.height) / (vw * vh);
    if (ratio > 0.55) {
      const wrap = document.getElementById('canvasWrap').getBoundingClientRect();
      return { x: wrap.left + 24, y: wrap.top + 24, w: wrap.width - 48, h: wrap.height - 48 };
    }
    return { x: r.left, y: r.top, w: r.width, h: r.height };
  }
  const wrap = document.getElementById('canvasWrap').getBoundingClientRect();
  return { x: wrap.left + 24, y: wrap.top + 24, w: Math.max(120, wrap.width - 48), h: Math.max(120, wrap.height - 48) };
}
function renderSpotlight(step) {
  const spot = $('demoSpotlight');
  if (!spot) return;
  if (demo.fast) { spot.style.display = 'none'; return; }
  const pad = 8;
  const r = targetRect(step);
  spot.style.display = 'block';
  spot.style.left = Math.round(r.x - pad) + 'px';
  spot.style.top = Math.round(r.y - pad) + 'px';
  spot.style.width = Math.round(r.w + pad * 2) + 'px';
  spot.style.height = Math.round(r.h + pad * 2) + 'px';
}
function clearSpotlight() {
  const spot = $('demoSpotlight');
  if (spot) spot.style.display = 'none';
}
function renderNarration(step) {
  const card = $('demoNarr');
  if (!card) return;
  if (demo.fast) { card.style.display = 'none'; return; }
  card.style.display = 'block';
  $('demoNarrStep').textContent = String(demo.index + 1).padStart(2, '0') + ' / 08';
  $('demoNarrText').textContent = step.narr || step.title;
  $('demoNarrHint').textContent = demo.paused ? '已暂停 · 按空格继续' : '按 → 继续 · 点任意界面位置切换手动';
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const r = targetRect(step);
  const cw = 320;
  const ch = card.offsetHeight || 120;
  const gap = 16;
  let left;
  let top;
  const big = (r.w * r.h) / (vw * vh) > 0.55;
  if (big) {
    left = 20;
    top = vh - 44 - 56 - 12 - ch;
  } else if (r.x + r.w + gap + cw + 16 <= vw) {
    left = r.x + r.w + gap;
    top = clamp(r.y, 66, vh - ch - 120);
  } else if (r.x - gap - cw - 16 >= 0) {
    left = r.x - gap - cw;
    top = clamp(r.y, 66, vh - ch - 120);
  } else if (r.y + r.h + gap + ch + 100 <= vh) {
    left = clamp(r.x + r.w / 2 - cw / 2, 16, vw - cw - 16);
    top = r.y + r.h + gap;
  } else {
    left = clamp(r.x + r.w / 2 - cw / 2, 16, vw - cw - 16);
    top = Math.max(66, r.y - ch - gap);
  }
  card.style.left = Math.round(left) + 'px';
  card.style.top = Math.round(top) + 'px';
}

/* ---------------- 控制条 ---------------- */
function updateBar() {
  const bar = $('demoBar');
  if (!bar) return;
  const step = STEPS[demo.index];
  $('demoStepLabel').textContent = `${demo.index + 1} / ${STEP_COUNT}`;
  const barFill = $('demoProgressBar');
  if (barFill) barFill.style.width = Math.round(((demo.index + 1) / STEP_COUNT) * 100) + '%';
  const pauseBtn = $('btnDemoPause');
  if (pauseBtn) pauseBtn.textContent = demo.paused ? '▶ 继续' : '⏸ 暂停';
  const prev = $('btnDemoPrev');
  const next = $('btnDemoNext');
  if (prev) prev.disabled = demo.index <= 0;
  if (next) next.textContent = demo.index >= STEP_COUNT - 1 ? '完成' : '下一步 →';
  if (step && demo.active) {
    renderSpotlight(step);
    renderNarration(step);
  }
}
function showEndCard() {
  const end = $('demoEnd');
  if (end) end.style.display = '';
  const bar = $('demoBar');
  if (bar) bar.classList.add('done');
  clearSpotlight();
  const card = $('demoNarr');
  if (card) card.style.display = 'none';
  const fab = $('btnDemoEndTry');
  if (fab) fab.focus();
}
function hideEndCard() {
  const end = $('demoEnd');
  if (end) end.style.display = 'none';
  const bar = $('demoBar');
  if (bar) bar.classList.remove('done');
}
function setDemoRunning(on) {
  document.body.classList.toggle('demo-running', on);
}

/* ---------------- 生命周期 ---------------- */
export function initDemo(appActions) {
  actions = appActions || {};
  if (demo.bound) return;
  demo.bound = true;
  const startBtn = $('btnDemo');
  if (startBtn) startBtn.addEventListener('click', () => startDemo());
  $('btnDemoPause').addEventListener('click', togglePause);
  $('btnDemoPrev').addEventListener('click', () => jumpTo(Math.max(0, demo.index - 1)));
  $('btnDemoNext').addEventListener('click', () => {
    if (demo.index >= STEP_COUNT - 1) { demo.paused = true; showEndCard(); updateBar(); return; }
    jumpTo(demo.index + 1);
  });
  $('btnDemoExit').addEventListener('click', () => exitDemo({ restore: true }));
  $('btnDemoEndTry').addEventListener('click', () => takeOver());
  $('btnDemoReplay').addEventListener('click', () => { exitDemo({ restore: true, silent: true }).then(() => startDemo()); });
  const restoreBtn = $('btnDemoEndRestore');
  if (restoreBtn) restoreBtn.addEventListener('click', () => exitDemo({ restore: true }));
  document.addEventListener('pointerdown', onUserInteract, true);
  document.addEventListener('keydown', onUserKey, true);
  window.addEventListener('resize', () => {
    if (!demo.active) return;
    clearTimeout(initDemo._resizeTimer);
    initDemo._resizeTimer = setTimeout(() => {
      if (demo.active && STEPS[demo.index]) { renderSpotlight(STEPS[demo.index]); renderNarration(STEPS[demo.index]); }
    }, 100);
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && demo.active && !demo.paused) { demo.paused = true; updateBar(); }
  });
}

function onUserInteract(e) {
  if (!demo.active) return;
  if (e.target.closest && (e.target.closest('#demoBar') || e.target.closest('#demoEnd') || e.target.closest('#demoNarr'))) return;
  takeOver({ silent: false });
}
function onUserKey(e) {
  // Shift + D：全局演示入口（§11.2）
  if (e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey && (e.key === 'D' || e.key === 'd')) {
    const tag = (e.target && e.target.tagName) || '';
    if (tag !== 'INPUT' && tag !== 'TEXTAREA' && tag !== 'SELECT' && !document.querySelector('.modal-mask.open') && !demo.active) {
      e.preventDefault();
      startDemo();
    }
    return;
  }
  if (!demo.active) return;
  const tag = (e.target && e.target.tagName) || '';
  const typing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';
  if (typing) return;
  if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); exitDemo({ restore: true }); return; }
  if (e.key === 'ArrowRight' || e.key === 'Enter') {
    e.preventDefault(); e.stopPropagation();
    if (demo.index >= STEP_COUNT - 1) { demo.paused = true; showEndCard(); updateBar(); }
    else jumpTo(demo.index + 1);
    return;
  }
  if (e.key === 'ArrowLeft') { e.preventDefault(); e.stopPropagation(); jumpTo(Math.max(0, demo.index - 1)); return; }
  if (e.key === ' ') { e.preventDefault(); e.stopPropagation(); togglePause(); return; }
  if (e.key === 'Tab') return;
  takeOver({ silent: false });
}

export async function startDemo() {
  if (demo.active) return;
  try {
    demo.active = true;
    demo.aborted = false;
    demo.fast = false;
    demo.index = 0;
    demo.userProjectId = state.projectId;
    demo.paused = REDUCED(); // 尊重减少动态：默认手动步进
    hideEndCard();
    setDemoRunning(true);
    const bar = $('demoBar');
    if (bar) bar.style.display = '';
    updateBar();
    const tip = REDUCED()
      ? '演示已就绪（系统「减少动态效果」已开启 → 手动步进：按 → 或点「下一步」）'
      : '演示开始 · 可暂停 / 上一步 / 下一步；点任意界面位置即切换为手动操作';
    toast(tip, '', 4200);
    await runCurrentStep();
  } catch (e) {
    if (e.message !== 'DEMO_ABORT') {
      console.error('[demo]', e);
      toast('演示中断：' + e.message, 'warn');
      exitDemo({ restore: true, silent: true });
    }
  }
}

async function runCurrentStep() {
  if (!demo.active) return;
  updateBar();
  const step = STEPS[demo.index];
  if (!step) return;
  await step.run();
  if (!demo.active) return;
  if (demo.index >= STEP_COUNT - 1) {
    demo.paused = true;
    updateBar();
    return;
  }
  demo.index += 1;
  await runCurrentStep();
}

/* ---------------- 控制 ---------------- */
function togglePause() {
  if (!demo.active) return;
  demo.paused = !demo.paused;
  updateBar();
  if (demo.paused) toast('已暂停 · 空格继续 / ← → 步进 / Esc 退出');
  else toast('继续演示');
}

async function jumpTo(index) {
  if (!demo.active) return;
  demo.paused = true;
  updateBar();
  try {
    demo.fast = true;
    demo.aborted = false;
    await actions.beginSandbox();
    demo.index = 0;
    for (let i = 0; i < index; i += 1) {
      demo.index = i;
      updateBar();
      await STEPS[i].run();
    }
    demo.index = index;
    demo.fast = false;
    clearSpotlight();
    demo.paused = false;
    updateBar();
    toast(`已跳到第 ${index + 1} / ${STEP_COUNT} 步`);
    await runCurrentStep();
  } catch (e) {
    if (e.message !== 'DEMO_ABORT') {
      console.error('[demo:jump]', e);
      exitDemo({ restore: true, silent: true });
    }
  }
}

/** 手动接管：停止自动播放、移除聚光/旁白，保留演示场景，恢复持久化 */
export async function takeOver(opts = {}) {
  if (!demo.active) return;
  const wasSilent = !!opts.silent;
  demo.active = false;
  demo.paused = false;
  demo.aborted = true;
  clearSpotlight();
  hideEndCard();
  setDemoRunning(false);
  const bar = $('demoBar');
  if (bar) bar.style.display = 'none';
  const card = $('demoNarr');
  if (card) card.style.display = 'none';
  try { await actions.takeOverSandbox(); } catch (e) { console.warn(e); }
  if (!wasSilent) {
    toast('已切换为手动操作 · 示例作品可随便改；「回到我的作品」会还原你原来的作品', '', 4200);
  }
  setStatusHint('已切换为手动操作 · 可以继续画 / 框选 / 让 AI 看看');
  emit('demo:changed', { active: false });
}

/** 退出演示并恢复进入前作品 */
export async function exitDemo(opts = {}) {
  const restore = opts.restore !== false;
  const silent = !!opts.silent;
  if (!demo.active && !restore) return;
  demo.active = false;
  demo.paused = false;
  demo.aborted = true;
  clearSpotlight();
  hideEndCard();
  setDemoRunning(false);
  const bar = $('demoBar');
  if (bar) bar.style.display = 'none';
  const card = $('demoNarr');
  if (card) card.style.display = 'none';
  try {
    if (restore) await actions.restoreSandbox();
    else await actions.takeOverSandbox();
  } catch (e) { console.warn('[demo] exit', e); }
  if (!silent) toast(restore ? '已退出演示 · 回到你的作品' : '已退出演示');
  emit('demo:changed', { active: false });
}

export function isDemoActive() { return demo.active; }
