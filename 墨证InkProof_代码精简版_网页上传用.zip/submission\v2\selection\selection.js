/**
 * v2/selection · 选区与变换（T37）
 *
 * - 工具：矩形 / 套索 / 魔棒（基于合成图像 flood fill）
 * - 布尔：add / subtract / intersect（Canvas2D globalCompositeOperation）
 * - 羽化：0–50px（绘制到临时 canvas 时 blur）
 * - 蚂蚁线：独立覆盖 canvas，虚线动画（rect/lasso 轮廓；魔棒用掩码边缘点近似）
 * - 约束：`getMaskImage(CK)` 交给 LayerSystem.setSelectionImage()，笔触提交时按选区位图裁剪
 * - 变换：移动/缩放/旋转/翻转；有选区时只变换选区内像素；提交 = 1 步 undo（整层图像快照）
 */
const MAX_FEATHER = 50;

export class SelectionManager {
  constructor({ width, height, overlayCanvas, layerSystem }) {
    this.width = width;
    this.height = height;
    this.layerSystem = layerSystem;
    this.CK = layerSystem.CK;
    this.overlay = overlayCanvas;
    this._antsScale = 0.5;
    this.overlay.width = Math.max(512, Math.round(width * this._antsScale));
    this.overlay.height = Math.max(512, Math.round(height * this._antsScale));
    this.ctx2d = this.overlay.getContext('2d');

    this.mask = document.createElement('canvas');
    this.mask.width = width;
    this.mask.height = height;
    this.mctx = this.mask.getContext('2d');
    this.featherPx = 0;
    this.hasSelection = false;
    this._lastShape = null; // {type:'rect'|'lasso'|'wand', ...}
    this._antsOffset = 0;
    this._antsRaf = null;

    this.transform = null;
    this._transformPreview = null;
    this._startAnts();
  }

  // ---------- 选区创建 ----------
  _applyMode(mode) {
    const op = mode === 'subtract' ? 'destination-out'
      : mode === 'intersect' ? 'destination-in'
        : mode === 'replace' ? 'copy'
          : 'source-over';
    this.mctx.globalCompositeOperation = op;
    this.mctx.globalAlpha = 1;
    this.mctx.filter = 'none';
    this.mctx.fillStyle = '#fff';
    this.mctx.strokeStyle = '#fff';
    this.mctx.lineWidth = 2;
  }

  rect(x0, y0, x1, y1, mode = 'add', featherPx = this.featherPx) {
    this._applyMode(mode);
    const x = Math.min(x0, x1), y = Math.min(y0, y1);
    const w = Math.abs(x1 - x0), h = Math.abs(y1 - y0);
    if (featherPx > 0) {
      this.mctx.save();
      this.mctx.filter = `blur(${featherPx}px)`;
    }
    this.mctx.fillRect(x, y, w, h);
    if (featherPx > 0) this.mctx.restore();
    this._lastShape = { type: 'rect', x, y, w, h };
    this._afterChange();
  }

  /** 椭圆选区（T63）：x0,y0→x1,y1 为外接框；布尔/羽化与矩形一致 */
  ellipse(x0, y0, x1, y1, mode = 'add', featherPx = this.featherPx) {
    this._applyMode(mode);
    const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
    const rx = Math.abs(x1 - x0) / 2, ry = Math.abs(y1 - y0) / 2;
    if (featherPx > 0) { this.mctx.save(); this.mctx.filter = `blur(${featherPx}px)`; }
    this.mctx.beginPath();
    this.mctx.ellipse(cx, cy, Math.max(0.5, rx), Math.max(0.5, ry), 0, 0, Math.PI * 2);
    this.mctx.fill();
    if (featherPx > 0) this.mctx.restore();
    this._lastShape = { type: 'ellipse', x: Math.min(x0, x1), y: Math.min(y0, y1), w: Math.abs(x1 - x0), h: Math.abs(y1 - y0) };
    this._afterChange();
  }

  lasso(points, mode = 'add', featherPx = this.featherPx) {
    if (!points || points.length < 3) return;
    this._applyMode(mode);
    if (featherPx > 0) { this.mctx.save(); this.mctx.filter = `blur(${featherPx}px)`; }
    this.mctx.beginPath();
    this.mctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i += 1) this.mctx.lineTo(points[i].x, points[i].y);
    this.mctx.closePath();
    this.mctx.fill();
    if (featherPx > 0) this.mctx.restore();
    this._lastShape = { type: 'lasso', points };
    this._afterChange();
  }

  /** 魔棒：从合成图取样，flood fill（降采样 512 提速，再放大到全分辨率） */
  async wandAt(x, y, mode = 'add', tolerance = 32) {
    const url = await this.layerSystem.getCompositeDataUrl();
    const img = new Image();
    img.src = url;
    await img.decode();
    const smallW = 512, smallH = Math.round(512 * this.height / this.width);
    const sc = document.createElement('canvas');
    sc.width = smallW; sc.height = smallH;
    const sctx = sc.getContext('2d');
    sctx.drawImage(img, 0, 0, smallW, smallH);
    const data = sctx.getImageData(0, 0, smallW, smallH).data;
    const sx = Math.floor(x / this.width * smallW);
    const sy = Math.floor(y / this.height * smallH);
    const idx0 = (sy * smallW + sx) * 4;
    const target = [data[idx0], data[idx0 + 1], data[idx0 + 2], data[idx0 + 3]];
    const visited = new Uint8Array(smallW * smallH);
    const out = sctx.createImageData(smallW, smallH);
    const stack = [sy * smallW + sx];
    const match = (i) => {
      const o = i * 4;
      return Math.abs(data[o] - target[0]) <= tolerance && Math.abs(data[o + 1] - target[1]) <= tolerance && Math.abs(data[o + 2] - target[2]) <= tolerance && Math.abs(data[o + 3] - target[3]) <= tolerance;
    };
    while (stack.length) {
      const i = stack.pop();
      if (visited[i]) continue;
      visited[i] = 1;
      if (!match(i)) continue;
      const px = i % smallW, py = Math.floor(i / smallW);
      out.data[i * 4] = 255; out.data[i * 4 + 1] = 255; out.data[i * 4 + 2] = 255; out.data[i * 4 + 3] = 255;
      if (px > 0) stack.push(i - 1);
      if (px < smallW - 1) stack.push(i + 1);
      if (py > 0) stack.push(i - smallW);
      if (py < smallH - 1) stack.push(i + smallW);
    }
    sc.getContext('2d').putImageData(out, 0, 0);
    this._applyMode(mode);
    this.mctx.imageSmoothingEnabled = false;
    this.mctx.drawImage(sc, 0, 0, this.width, this.height);
    this._lastShape = { type: 'wand' };
    this._afterChange();
    return true;
  }

  selectAll(mode = 'add') {
    this._applyMode(mode);
    this.mctx.fillRect(0, 0, this.width, this.height);
    this._lastShape = { type: 'rect', x: 0, y: 0, w: this.width, h: this.height };
    this._afterChange();
  }

  resize(width, height) {
    this.width = Math.max(1, Math.floor(Number(width) || 1));
    this.height = Math.max(1, Math.floor(Number(height) || 1));
    this.mask.width = this.width;
    this.mask.height = this.height;
    this.clear();
  }

  clear() {
    this.mctx.clearRect(0, 0, this.width, this.height);
    this.hasSelection = false;
    this._lastShape = null;
    this.layerSystem.setSelectionImage(null);
    this._renderAnts();
  }

  setFeather(px) { this.featherPx = Math.max(0, Math.min(MAX_FEATHER, Number(px) || 0)); }

  _afterChange() {
    this.hasSelection = this._hasAnyPixel();
    const maskImg = this.getMaskImage();
    this.layerSystem.setSelectionImage(maskImg);
    this._renderAnts();
  }

  _hasAnyPixel() {
    const d = this.mctx.getImageData(0, 0, this.width, this.height).data;
    for (let i = 3; i < d.length; i += 16) if (d[i] > 0) return true;
    return false;
  }

  /** 返回 CanvasKit Image（alpha 掩码）；羽化在 2D 侧处理 */
  getMaskImage() {
    this.mctx.save();
    this.mctx.globalCompositeOperation = 'source-over';
    const c = document.createElement('canvas');
    c.width = this.width; c.height = this.height;
    const ctx = c.getContext('2d');
    if (this.featherPx > 0) ctx.filter = `blur(${this.featherPx}px)`;
    ctx.drawImage(this.mask, 0, 0);
    this.mctx.restore();
    const img = this.CK.MakeImageFromCanvasImageSource(c);
    this._maskImg = img; // 旧图可能仍被 LayerSystem 引用，M4.5 做引用计数后再释放
    return img;
  }

  // ---------- 蚂蚁线 ----------
  _startAnts() {
    const tick = () => {
      this._antsOffset = (this._antsOffset + 1) % 16;
      this._renderAnts();
    };
    this._antsRaf = setInterval(tick, 120);
  }

  setTransformPreview(preview) {
    this._transformPreview = preview;
    this._renderAnts();
  }

  _renderAnts() {
    const ctx = this.ctx2d;
    const k = this._antsScale;
    ctx.clearRect(0, 0, this.overlay.width, this.overlay.height);
    ctx.save();
    ctx.scale(k, k);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2 / k;
    ctx.setLineDash([6 / k, 6 / k]);
    ctx.lineDashOffset = -this._antsOffset;
    let drawn = false;
    if (this.hasSelection && this._lastShape) {
      const shape = this._lastShape;
      if (shape.type === 'rect') {
        ctx.strokeRect(shape.x, shape.y, shape.w, shape.h);
        drawn = true;
      } else if (shape.type === 'ellipse') {
        ctx.beginPath();
        ctx.ellipse(shape.x + shape.w / 2, shape.y + shape.h / 2, Math.max(0.5, shape.w / 2), Math.max(0.5, shape.h / 2), 0, 0, Math.PI * 2);
        ctx.stroke();
        drawn = true;
      } else if (shape.type === 'lasso' && shape.points && shape.points.length > 2) {
        ctx.beginPath();
        ctx.moveTo(shape.points[0].x, shape.points[0].y);
        for (let i = 1; i < shape.points.length; i += 1) ctx.lineTo(shape.points[i].x, shape.points[i].y);
        ctx.closePath();
        ctx.stroke();
        drawn = true;
      }
    }
    if (this._transformPreview) {
      const pv = this._transformPreview;
      ctx.save();
      ctx.translate(this.width / 2 + pv.x, this.height / 2 + pv.y);
      ctx.rotate((pv.rotate * Math.PI) / 180);
      ctx.strokeStyle = '#5b8cff';
      ctx.strokeRect((-this.width / 2) * pv.scaleX, (-this.height / 2) * pv.scaleY, this.width * pv.scaleX, this.height * pv.scaleY);
      ctx.restore();
      drawn = true;
    }
    ctx.restore();
  }

  dispose() {
    if (this._antsRaf) clearInterval(this._antsRaf);
    this._antsRaf = null;
    try { this._maskImg && this._maskImg.delete(); } catch (e) { /* ignore */ }
  }

  // ---------- 变换手柄（T63：自由手柄 8 点 + 旋转柄；供 app T64） ----------
  /** 当前变换包围盒（中心/尺寸/旋转角） */
  getTransformBounds() {
    const t = this.transform;
    if (!t) return null;
    return {
      cx: this.width / 2 + (t.x || 0),
      cy: this.height / 2 + (t.y || 0),
      w: this.width * (t.scaleX == null ? 1 : t.scaleX),
      h: this.height * (t.scaleY == null ? 1 : t.scaleY),
      rotate: t.rotate || 0,
    };
  }

  /** 8 个缩放手柄 + 1 个旋转柄（世界坐标）；app 可画在 overlay 上 */
  getTransformHandles() {
    const b = this.getTransformBounds();
    if (!b) return null;
    const rad = (b.rotate * Math.PI) / 180;
    const local = [
      ['nw', -0.5, -0.5], ['n', 0, -0.5], ['ne', 0.5, -0.5],
      ['e', 0.5, 0], ['se', 0.5, 0.5], ['s', 0, 0.5],
      ['sw', -0.5, 0.5], ['w', -0.5, 0],
      ['rotate', 0, -0.75],
    ];
    const handles = local.map(([id, ux, uy]) => {
      const lx = ux * b.w, ly = uy * b.h;
      return { id, x: b.cx + lx * Math.cos(rad) - ly * Math.sin(rad), y: b.cy + lx * Math.sin(rad) + ly * Math.cos(rad) };
    });
    return { handles, bounds: b };
  }

  /** 命中测试（返回 handle id；app 用于 pointerdown） */
  hitTestHandle(x, y, radius = 12) {
    const h = this.getTransformHandles();
    if (!h) return null;
    let best = null; let bestD = radius;
    for (const hd of h.handles) {
      const d = Math.hypot(x - hd.x, y - hd.y);
      if (d <= bestD) { bestD = d; best = hd.id; }
    }
    return best;
  }

  /** 手柄拖拽：rotate=旋转（Shift 15° 吸附）；n/s/e/w/ne/...=缩放；返回更新后的 transform */
  dragHandle(handleId, x, y, opts = {}) {
    const t = this.transform;
    if (!t) return null;
    const b = this.getTransformBounds();
    if (handleId === 'rotate') {
      let deg = (Math.atan2(y - b.cy, x - b.cx) * 180) / Math.PI + 90;
      if (opts.snap) deg = Math.round(deg / 15) * 15;
      t.rotate = deg;
      this.setTransformPreview({ x: t.x, y: t.y, rotate: t.rotate, scaleX: t.scaleX, scaleY: t.scaleY });
      return t;
    }
    const affectsX = /e|w/.test(handleId) || handleId.length === 2;
    const affectsY = /n|s/.test(handleId) || handleId.length === 2;
    const signX = handleId.includes('e') ? 1 : handleId.includes('w') ? -1 : 1;
    const signY = handleId.includes('s') ? 1 : handleId.includes('n') ? -1 : 1;
    const sx = affectsX ? Math.abs((x - b.cx) / (this.width / 2 || 1)) : Math.abs(t.scaleX || 1);
    const sy = affectsY ? Math.abs((y - b.cy) / (this.height / 2 || 1)) : Math.abs(t.scaleY || 1);
    t.scaleX = Math.max(0.05, signX * (affectsX ? sx : (t.scaleX || 1)));
    t.scaleY = Math.max(0.05, signY * (affectsY ? sy : (t.scaleY || 1)));
    this.setTransformPreview({ x: t.x, y: t.y, rotate: t.rotate, scaleX: t.scaleX, scaleY: t.scaleY });
    return t;
  }

  // ---------- 变换 ----------
  beginTransform(layerId, opts = {}) {
    const ls = this.layerSystem;
    const before = ls.renderLayerToImage(layerId, true);
    this.transform = {
      layerId,
      before,
      x: 0, y: 0, scaleX: 1, scaleY: 1, rotate: 0, flipH: false, flipV: false,
      useSelection: !!this.hasSelection && opts.useSelection !== false,
    };
    return this.transform;
  }

  updateTransform(patch) {
    if (!this.transform) return;
    Object.assign(this.transform, patch);
  }

  /** 提交变换：生成 after 图像 → 替换图层 → 1 步 undo */
  commitTransform() {
    const t = this.transform;
    if (!t) return null;
    const ls = this.layerSystem;
    const after = this._renderTransformed(t);
    ls.replaceLayerFromImage(t.layerId, after);
    ls._pushUndo({ kind: 'image', layerId: t.layerId, before: t.before, after });
    ls.composite();
    this.transform = null;
    return after;
  }

  cancelTransform() {
    if (this.transform) { try { this.transform.before.delete(); } catch (e) { /* ignore */ } this.transform = null; }
  }

  _renderTransformed(t) {
    const ls = this.layerSystem;
    const CK = ls.CK;
    const surface = CK.MakeRenderTarget(ls.gr, ls.width, ls.height);
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    const src = t.useSelection && this.hasSelection ? this._extractSelected(t.before) : t.before;
    const ctx = c;
    ctx.save();
    ctx.translate(ls.width / 2 + t.x, ls.height / 2 + t.y);
    ctx.rotate(t.rotate || 0, 0, 0); // CanvasKit: 角度 + 旋转中心
    ctx.scale((t.scaleX || 1) * (t.flipH ? -1 : 1), (t.scaleY || 1) * (t.flipV ? -1 : 1));
    ctx.drawImage(src, -ls.width / 2, -ls.height / 2);
    ctx.restore();
    // 若有选区：保留选区外原像素（先画 before，再覆盖变换后的选中区）
    if (t.useSelection && this.hasSelection) {
      const base = CK.MakeRenderTarget(ls.gr, ls.width, ls.height);
      const bc = base.getCanvas();
      bc.clear(CK.TRANSPARENT);
      bc.drawImage(t.before, 0, 0);
      // 从 base 中挖掉选区
      const mask = this.getMaskImage();
      const cut = new CK.Paint();
      cut.setBlendMode(CK.BlendMode.DstOut);
      bc.drawImage(mask, 0, 0, cut);
      cut.delete();
      // 合成
      const final = CK.MakeRenderTarget(ls.gr, ls.width, ls.height);
      const fc = final.getCanvas();
      fc.clear(CK.TRANSPARENT);
      fc.drawImage(base.makeImageSnapshot(), 0, 0);
      const layerImg = surface.makeImageSnapshot();
      // 变换后的选中内容画在 base 之上
      fc.drawImage(layerImg, 0, 0);
      base.delete();
      surface.delete();
      const out = final.makeImageSnapshot();
      final.delete();
      if (src !== t.before) { try { src.delete(); } catch (e) { /* ignore */ } }
      return out;
    }
    surface.flush();
    const img = surface.makeImageSnapshot();
    surface.delete();
    if (src !== t.before) { try { src.delete(); } catch (e) { /* ignore */ } }
    return img;
  }

  _extractSelected(beforeImage) {
    const ls = this.layerSystem;
    const CK = ls.CK;
    const surface = CK.MakeRenderTarget(ls.gr, ls.width, ls.height);
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    c.drawImage(beforeImage, 0, 0);
    const paint = new CK.Paint();
    paint.setBlendMode(CK.BlendMode.DstIn);
    c.drawImage(this.getMaskImage(), 0, 0, paint);
    paint.delete();
    surface.flush();
    const img = surface.makeImageSnapshot();
    surface.delete();
    return img;
  }
}

export { MAX_FEATHER };
