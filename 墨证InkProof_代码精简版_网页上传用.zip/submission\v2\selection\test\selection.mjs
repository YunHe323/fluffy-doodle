#!/usr/bin/env node
// v2/selection/test/selection.mjs —— T63 选区/变换测试（零依赖 CDP）
// 用法：node v2/selection/test/selection.mjs <layersDemoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/layers/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || join(dirname(fileURLToPath(import.meta.url)), '..', 'results', 'selection.json');
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/layers/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 layers demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__LAYERS_READY__) { if (Date.now() - t0 > 30000) throw new Error('layers timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { SelectionManager } = await import('/v2/selection/selection.js');
  const ls = window.__LAYERS__;
  const overlay = document.createElement('canvas');
  const sm = new SelectionManager({ width: ls.width, height: ls.height, overlayCanvas: overlay, layerSystem: ls });
  const checks = {};
  const alphaStats = () => {
    const d = sm.mctx.getImageData(0, 0, sm.width, sm.height).data;
    let full = 0, partial = 0, empty = 0;
    for (let i = 3; i < d.length; i += 4) { if (d[i] > 240) full += 1; else if (d[i] > 0) partial += 1; else empty += 1; }
    return { full, partial, empty };
  };
  // 1) 矩形 + 精灵
  sm.clear(); sm.rect(100, 100, 400, 400, 'replace'); const r1 = alphaStats();
  checks.rect = sm.hasSelection && r1.full > 0;
  sm.ellipse(600, 100, 900, 400, 'add'); const r2 = alphaStats();
  checks.ellipse = sm.hasSelection && r2.full > r1.full;
  // 2) 套索 + 布尔
  sm.clear(); sm.rect(100, 100, 500, 500, 'replace');
  const beforeBool = alphaStats().full;
  sm.rect(300, 100, 500, 500, 'subtract');
  const afterSub = alphaStats().full;
  sm.ellipse(100, 100, 500, 500, 'intersect');
  const afterInt = alphaStats().full;
  checks.boolean = beforeBool > 0 && afterSub < beforeBool && afterInt <= afterSub && afterInt > 0;
  sm.clear(); sm.lasso([{x:50,y:50},{x:400,y:80},{x:350,y:450},{x:80,y:400}], 'replace');
  checks.lasso = sm.hasSelection;
  // 3) 羽化
  sm.clear(); sm.rect(100, 100, 500, 500, 'replace', 0); const noFeather = alphaStats();
  sm.clear(); sm.rect(100, 100, 500, 500, 'replace', 20); const feathered = alphaStats();
  checks.feather = noFeather.partial === 0 && feathered.partial > 0;
  // 4) 魔棒（图层系统有内容）
  try {
    const img = ls.renderLayerToImage(ls.activeLayerId, true);
    ls.replaceLayerFromImage(ls.activeLayerId, img); ls.composite();
    await new Promise((r) => setTimeout(r, 100));
    const okWand = await sm.wandAt(ls.width / 2, ls.height / 2, 'replace', 48);
    checks.wand = okWand === true && sm.hasSelection;
  } catch (e) { checks.wand = false; }
  // 5) 变换手柄 + 旋转吸附 + 提交/undo
  sm.beginTransform(ls.activeLayerId);
  const hs = sm.getTransformHandles();
  checks.handles = !!hs && hs.handles.length === 9 && sm.hitTestHandle(hs.handles[0].x, hs.handles[0].y) !== null;
  const rotated = sm.dragHandle('rotate', 0, 0, { snap: true });
  checks.snap15 = rotated && Math.abs(rotated.rotate % 15) < 1e-6;
  sm.updateTransform({ x: 30, y: 20, scaleX: 1.2, scaleY: 1.2, rotate: rotated ? rotated.rotate : 15 });
  const depthBefore = ls.undoStack.length;
  sm.commitTransform();
  checks.transformCommit = ls.undoStack.length === depthBefore + 1;
  const okUndo = ls.undo();
  checks.transformUndo = okUndo === true;
  sm.dispose();
  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  return { ok: checks.ok, checks, alpha: { rect: r1, rectEllipse: r2, noFeather, feathered }, environment: { headless: /HeadlessChrome/.test(navigator.userAgent) } };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1200)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
try { mkdirSync(dirname(outPath), { recursive: true }); writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); }
ws.close();
process.exit(value.ok ? 0 : 1);
