#!/usr/bin/env node
// v2/engine/test/selection-transform.mjs —— T63 选区约束/变换/结构 undo 测试（零依赖 CDP）
// 用法：node v2/engine/test/selection-transform.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const checks = {};
  const mkEngine = async () => {
    const canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 512;
    const eng = new Engine({ canvas, width: 512, height: 512, layers: 1 });
    await eng.init(); eng.setBrush({ type: 'soft', sizePx: 24 });
    return eng;
  };
  const draw = (eng, x0, y0, x1, y1, n = 20) => {
    eng.beginStroke({ x: x0, y: y0, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
    for (let i = 1; i < n; i += 1) {
      const t = i / (n - 1);
      eng.appendPoint({ x: x0 + (x1 - x0) * t, y: y0 + (y1 - y0) * t, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
    }
    return eng.endStroke();
  };
  const halves = async (url) => {
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const cx = c.getContext('2d'); cx.drawImage(img, 0, 0);
    const d = cx.getImageData(0, 0, c.width, c.height).data;
    let left = 0, right = 0, ink = 0;
    for (let y = 0; y < c.height; y += 1) for (let x = 0; x < c.width; x += 1) {
      const i = (y * c.width + x) * 4;
      if (d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220) { ink += 1; if (x < c.width / 2) left += 1; else right += 1; }
    }
    return { ink, left, right };
  };

  const eng = await mkEngine();
  const layerId = eng.getLayers()[0].id;
  // 1) 选区约束笔触：左半选区，画穿整幅 → 只能落左半
  const maskCv = document.createElement('canvas'); maskCv.width = 512; maskCv.height = 512;
  const mctx = maskCv.getContext('2d'); mctx.fillStyle = '#fff'; mctx.fillRect(0, 0, 256, 512);
  const selImg = eng.CK.MakeImageFromCanvasImageSource(maskCv);
  eng.setSelectionImage(selImg);
  draw(eng, 40, 260, 470, 260); await raf(); await raf();
  const constrained = await halves(await eng.getCompositeDataUrl());
  checks.selectionConstrainsStroke = constrained.left > 100 && constrained.right < 20;
  // undo 选区笔触
  eng.undo(); await raf();
  const cleared = await halves(await eng.getCompositeDataUrl());
  checks.selectionStrokeUndo = cleared.ink < constrained.ink * 0.2;
  eng.clearSelection();

  // 2) 变换：commit 写 tile + 1 步 undo/redo
  draw(eng, 120, 300, 380, 300); await raf(); await raf();
  const beforeTransform = await halves(await eng.getCompositeDataUrl());
  const t = eng.beginTransform(layerId);
  eng.updateTransform({ x: 40, y: -20, scaleX: 1.1, scaleY: 1.1, rotate: 30 });
  const handles = eng.getTransformHandles();
  checks.transformHandles = !!handles && handles.handles.length === 9 && typeof handles.bounds.rotate === 'number';
  const snapT = eng.dragTransformHandle('rotate', 512, 0, { snap: true });
  checks.transformSnap15 = snapT && Math.abs(snapT.rotate % 15) < 1e-6;
  eng.updateTransform({ scaleX: 1.1, scaleY: 1.1, rotate: 30, x: 40, y: -20 });
  const commitBeforeUndoDepth = eng.getStats().undoDepth;
  const after = eng.commitTransform(); await raf();
  const transformed = await halves(await eng.getCompositeDataUrl());
  const transformDebug = { beforeInk: beforeTransform.ink, transformedInk: transformed.ink, undoBefore: commitBeforeUndoDepth, undoAfter: eng.getStats().undoDepth, afterExists: !!after, mode: eng.lastPresentMode };
  checks.transformCommit = !!after && transformed.ink > 0 && eng.getStats().undoDepth === commitBeforeUndoDepth + 1;
  eng.undo(); await raf();
  const undone = await halves(await eng.getCompositeDataUrl());
  checks.transformUndo = undone.ink > 0;
  eng.redo(); await raf();
  checks.transformRedo = eng.getStats().undoDepth === commitBeforeUndoDepth + 1;

  // 3) 结构操作 undo（同一栈）
  const n0 = eng.getLayers().length, g0 = eng.getGroups().length;
  const grp = eng.addGroup('G');
  checks.structAddGroup = eng.getGroups().length === g0 + 1;
  eng.undo(); checks.structAddGroupUndo = eng.getGroups().length === g0;
  eng.redo(); checks.structAddGroupRedo = eng.getGroups().length === g0 + 1;
  const l2 = eng.addLayer({ name: 'L2', group: grp.id });
  checks.structAddLayer = eng.getLayers().length === n0 + 1;
  eng.undo(); checks.structAddLayerUndo = eng.getLayers().length === n0;
  eng.redo();
  const dup = eng.duplicateLayer(l2.id);
  checks.structDuplicate = !!dup && eng.getLayers().length === n0 + 2;
  eng.undo(); checks.structDuplicateUndo = eng.getLayers().length === n0 + 1;
  eng.redo();
  const orderBefore = eng.getLayers().map((l) => l.id).join(',');
  eng.moveLayer(l2.id, -1);
  const orderMoved = eng.getLayers().map((l) => l.id).join(',') !== orderBefore;
  eng.undo();
  checks.structMoveUndo = orderMoved && eng.getLayers().map((l) => l.id).join(',') === orderBefore;
  eng.redo();
  const beforeMerge = eng.getLayers().length;
  const mergeTarget = eng.getLayers()[eng.getLayers().length - 1].id;
  eng.mergeDown(mergeTarget);
  checks.structMerge = eng.getLayers().length === beforeMerge - 1;
  eng.undo(); checks.structMergeUndo = eng.getLayers().length === beforeMerge;
  const beforeFlat = eng.getLayers().length;
  eng.flattenAll();
  checks.structFlatten = eng.getLayers().length === 1 && eng.getGroups().length === 0;
  eng.undo(); checks.structFlattenUndo = eng.getLayers().length === beforeFlat;
  // 4) T60 序列化兼容
  const json = eng.serializeDoc();
  const container = JSON.parse(json);
  checks.serializeCompat = container.format === 'mozheng' && container.doc.schema === 'mozheng.doc.v1' && container.doc.layers.length === eng.getLayers().length;
  // 5) 画笔 undo 与结构 undo 同栈：再画一笔 → undo（笔触）→ undo（结构）
  eng.setActiveLayer(eng.getLayers()[eng.getLayers().length - 1].id);
  draw(eng, 100, 100, 250, 180); await raf();
  const depthAfterPaint = eng.getStats().undoDepth;
  eng.undo(); const depthAfterUndo1 = eng.getStats().undoDepth;
  checks.sameStackPaintThenStructure = depthAfterPaint >= 1 && depthAfterUndo1 === depthAfterPaint - 1;

  eng.dispose();
  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  return { ok: checks.ok, checks, transformDebug, environment: { browser: (navigator.userAgent.match(/Chrome\\/[\\d.]+/) || [])[0] || '', headless: /HeadlessChrome/.test(navigator.userAgent) } };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1600)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
