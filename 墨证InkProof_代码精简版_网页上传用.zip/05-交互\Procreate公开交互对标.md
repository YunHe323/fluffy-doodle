# Procreate 公开交互对标（画布 v2 参考）

> 作者：ux-designer｜日期：2026-11-06｜版本：v1.0
> 用途：为「画布引擎 v2」的交互设计提供**可核验的公开对标**，回答「Procreate 有 → 我们抄不抄、抄到什么程度」。
> 边界：**只使用 Procreate 官方 Handbook（help.procreate.com，版本 5.3/5.2）等公开信息**；未下载/反编译其 App、未复制其笔刷文件或图片资产；本文不承诺、不宣称「还原 Procreate」或「像素级一致」，只说「参考/对标/简化」。
> 配套：[`画布v2交互规范.md`](画布v2交互规范.md)｜来源编号见 §11。

**读法**
- 每条含：**Procreate 公开行为**（官方文档原意改写）→ **公开来源** → **v2 决策**（采纳 / 简化 / 不做）→ **理由与用户价值** → **v2 落点**。
- **采纳** = 交互与能力对齐（不代表逐像素一致，也不代表 v2 一次做完）；**简化** = 保留用户价值但换桌面 Web 的更低成本实现；**不做** = 明确不做，写清原因，避免研发误以为要做。
- 标 `【P0/P1/P2】` 是 **v2 内部优先级**：P0 = v2 首发必须；P1 = v2.x；P2 = 观察/更后。

---

## 0. 一页结论（给 Lead / 技术）

1. **Procreate 的护城河不是功能清单，而是「笔感 + 少打断」**：压感/倾斜曲线、稳定化、笔刷参数、滑杆精细控制、全屏手势、QuickMenu、图层手势——本质是让手不离开画布。v2 的优先级应按这个排序，而不是堆功能。
2. **v2 采纳「能力形态」，不采纳「iPad 专属交互」**：双指/三指/四指手势、Apple Pencil 挤压/滚转/悬停，在「桌面 Web + 手绘板」上要么不可靠、要么不可用，必须映射成键盘/笔杆键/径向菜单，并保留触摸屏/触控板降级路径。
3. **v2 对标范围**：笔刷质量（压感/倾斜/稳定化/笔尖形态/涂抹）、图层工作流（组/蒙版/剪贴/Alpha Lock/锁定/混合模式）、选区与变换、径向快捷菜单、颜色、画布/对称/参考线、键盘与全屏。**明确不做**：动画、3D、延时视频、文本排版、液化/克隆、CMYK 印刷流程、专有 `.brush` 导入、iPad 原生 App（后续评估）。
4. **最大差异不在「有没有」，而在「桌面 Web 的输入模型」**：鼠标/触控板没有压力与多指触摸，浏览器无法可靠区分三指/四指轻点，Web 内存/GPU 限制画布与图层上限；因此 v2 的交互必须**键盘优先 + 笔优先 + 径向菜单兜底**，且所有「手感」参数要能在低端设备降级。
5. **与「墨证」主线的关系**：v2 画布仍是「创作记忆与过程证据层」的底座；AI 面板、档案、证据链不得因画布升级而降级（D1 红线保持不变）。

---

## 1. 工具与笔刷

| ID | 能力 | Procreate 公开行为（官方文档改写） | 来源 | v2 决策 | 理由 / 用户价值 | v2 落点 |
|---|---|---|---|---|---|---|
| B01 | 画笔库组织 | 画笔按主题 Set 分组（18 组、数百支）；左侧 Set、右侧画笔缩略与笔触预览；点击选中即可画 | S5 | **采纳（简化规模）** | 分类是找到笔的最快方式；但 v2 首发不需要数百支 | 内置 12–20 支、4–6 组；`BrushLibrary` 抽屉 |
| B02 | 最近 / 固定画笔 | 最近最多 8 支；可 Pin 固定到最近顶部；可 Clear/Find 回原 Set | S5 | **采纳** | 高频笔刷 1 次可达，减少面板往返 | 最近 8 + 固定 4【P0】 |
| B03 | 画笔大小 / 不透明度 | 侧栏双滑杆；每个滑杆可**拖离滑杆**上下移动做精细调节（离得越远越精细） | S4、S7 | **采纳** | 「精细调节」是专业手感关键；实现成本低 | 滑杆拖离精细模式【P0】 |
| B04 | 笔刷尺寸记忆 | 每支笔可存最多 4 个大小/不透明度记忆点，滑杆上显示刻度 | S4 | **简化** | 有价值但非首发；先做「每支笔记住上次参数」 | 每笔刷记住参数【P0】；4 记忆点【P2】 |
| B05 | 画笔工作室（12 属性） | Stroke Path / Stabilization / Taper / Shape / Grain / Rendering / Wet Mix / Color Dynamics / Dynamics / Apple Pencil / Properties / About | S6、S7 | **简化** | 数百设置对 90% 用户过重；v2 先给「可感知的 6 组」 | `BrushStudio`：6 组 / ≤24 参数【P0→P1】 |
| B06 | 形状与纹理源 | Shape Source 可导入图片；Source Library 150+ 内置形状；Grain 为形状内纹理 | S7 | **简化** | 自定义笔尖是差异化，但先支持导入 PNG 笔尖 + 内置形状 | 导入 PNG 笔尖 + 20 内置【P1】；不做专有 `.brush` |
| B07 | 稳定化 | StreamLine（Amount/Pressure）、Stabilization（移动平均，随速度变化）、Motion Filtering（去除抖动极值） | S7 | **采纳（简化三合一）** | 抖动是手绘板用户第一痛点；三套参数可合并 | 一个 Smoothing 滑杆（0–100）+ 高级「运动滤波」【P0/P1】 |
| B08 | 压感 / 倾斜响应 | Apple Pencil 压力、倾斜、方位角、Pro 滚转均可映射到大小/不透明度/散布/颜色等 | S3、S7 | **采纳（能力探测）** | Wacom/XP-Pen 等桌面手绘板支持压力与倾斜（Pointer Events） | 压力→大小/不透明度曲线；倾斜→可选【P0】；滚转/方位角【P2/不支持】 |
| B09 | 涂抹 Smudge | 与 Paint/Erase 共享同一画笔库；强度随工具强度/不透明度变化；可保留同一支笔快速切换 paint/smudge/erase | S4 | **采纳** | 混合颜色是绘画刚需，但引擎成本高；列为 v2 首发关键冒险项 | Smudge 工具 + 共享笔刷【P0，若引擎不达标降级为 P1】 |
| B10 | 橡皮 | 共享画笔库；用不透明度控制擦除强度 | S4 | **采纳** | 已是 v0.1 基线；v2 需支持「橡皮笔尖形状/纹理」 | 橡皮 = 笔刷模式【P0】 |
| B11 | 悬停预演 | Apple Pencil 悬停显示笔刷大小/形状/纹理预览；悬停捏合调大小、滑动调不透明度 | S1、S3 | **简化** | 浏览器/设备支持不一（PointerEvent 无标准 hover 画笔语义） | 笔悬停时显示光标轮廓【P1】；悬停手势不做 |
| B12 | 笔杆双击 / 挤压 / 滚转 | 双击切换工具/取色；Apple Pencil Pro 挤压/滚转可绑定快捷功能 | S3 | **不做（Apple 专属）** | 桌面手绘板无此硬件语义；用笔杆按键映射替代 | 笔杆按键=橡皮/吸管（可配置）【P0】 |
| B13 | 颜色面板 | Disc / Classic / Harmony / Value / Palettes 五种模式；历史 10 色；主/副色 | S15 | **采纳（简化 Harmony）** | 专业用户要 disc + 数值；Harmony 属加分项 | 色盘/数值/调色板 + 历史 10 色【P0】；Harmony【P2】 |
| B14 | 取色器 | 长按画布取色（放大镜、上下半屏对比）；Modify 按钮触发浮窗取色 | S15、S1 | **采纳** | 高频操作；桌面用 Alt+点击最顺 | Alt/笔杆键取色 + 放大镜【P0】 |
| B15 | 调色板 | 内置调色板 + 自定义 + 导入调色板 | S15 | **简化** | 自有调色板 JSON + 5 套内置；ASE 导入后再评估 | 调色板 CRUD【P1】；ASE【P2】 |
| B16 | 参考图层 | 将某层设为 Reference Layer，ColorDrop 按该层线稿填充 | S10 | **采纳（简化）** | 线稿上色刚需；先做「参考层」标记 + 填充逻辑 | 参考层 + 填充【P1】 |
| B17 | 参考图浮窗 | Reference Companion 可把参考图置于画布旁 | S2（QuickMenu 功能列表） | **简化** | 桌面可直接开侧栏；不做独立浮窗 | 参考图侧栏（可拖入）【P1】 |
| B18 | ColorDrop 填充 | 拖颜色到闭合区域填充，可拖动调阈值 | S1（手势）·S10（Reference） | **采纳（简化）** | 平涂效率关键；阈值调节可后置 | 颜料桶 + 阈值【P1】 |
| B19 | QuickShape | 画完保持按住，自动吸附为直线/弧/折线/椭圆/三角/四边形；第二指完美化；15° 磁旋转；可进 Edit Shape | S1、S18 | **采纳（桌面映射）** | 线条/图形效率高，桌面可用「画后按住 + 快捷键」 | 画后按住→吸附；Shift 约束 15°【P1】 |
| B20 | 对称 | 垂直/水平/象限/径向（径向 8 段）；镜像 vs 旋转；可移/旋转/颜色/透明度/厚度；Drawing Assist 默认开 | S17 | **采纳** | 角色/图案/花纹高频；v2 差异化亮点 | 4 种对称 + 旋转/镜像切换【P1】 |
| B21 | 2D 网格 / 等距 / 透视辅助 | 2D Grid、Isometric、Perspective 三类绘图指引；Drawing Assist 让笔迹贴合指引 | S19 及 guides 目录 | **简化** | 2D 网格最快落地；等距/透视 P2 | 2D 网格【P1】；等距/透视【P2】 |
| B22 | 画布创建 | 预设（Screen/Square/4K/A4/4×6/US Paper）+ 自定义：名称、宽高、DPI、色彩配置、背景、时间-lapse | S16 | **采纳（简化）** | 尺寸/DPI/背景是刚需；色彩配置先 sRGB | 新建画布：预设 6 + 自定义宽高/DPI/背景【P0】 |
| B23 | 画布上限 | 最大 1×1 到单边 16K（取决于设备）；画布越大可用图层越少 | S16、S9 | **采纳（换算 Web 限制）** | Web 内存是硬约束，必须显式提示 | 单边 ≤8192、总像素按设备探测；动态图层上限并提示【P0】 |
| B24 | 缩放 / 旋转 / 适配 | 双指捏合缩放、双指扭转旋转画布、快速捏合 fit to screen | S1 | **采纳（桌面映射）** | 旋转画布是勾线习惯；桌面用 R 键+拖/触控板 | 缩放/旋转/0 适配；R 旋转【P0】 |
| B25 | 全屏 | 四指轻点进入全屏（UI 滑出）；再点四指或左上角指示器退出 | S1 | **采纳（F 键）** | 投屏/专注；桌面用 F/快捷键 | 全屏 + 隐藏 UI【P0】 |
| B26 | 撤销/重做 | 双指轻点撤销、长按快速连续撤销；三指轻点重做、长按快速重做；最多 250 步；离开画布后撤销清空 | S1 | **采纳（桌面映射 + 步数按内存）** | 撤销是最高频操作；桌面 Ctrl+Z 更可靠 | Ctrl+Z / Ctrl+Shift+Z；长按连续；目标 ≥100 步【P0】 |
| B27 | 三指清扫清空图层 / 三指下滑剪贴菜单 / 四指全屏 | 三指左右清扫清空图层；三指下滑呼出 Cut/Copy/Paste 菜单；四指切换全屏 | S1 | **简化** | 多指手势在桌面浏览器不可靠；用快捷键/菜单替代 | 清空层 Ctrl+Shift+Del（确认）；剪贴菜单用顶栏/右键【P1】 |
| B28 | QuickMenu | 6 键径向菜单；点击打开或按住拖动快速选；长按按钮改动作；可多 Profile | S2 | **采纳（简化）** | 减少面板往返，是 Procreate 效率核心；桌面用右键/笔杆/长按空格 | 径向 6 键，可自定义；右键/笔杆/长按空格呼出【P0】 |
| B29 | 手势自定义 | Gesture Controls 可开关/多绑定/延迟；不能把同一手势绑两个功能（冲突黄标） | S1 | **简化** | 桌面 Web 手势有限；v2 先做快捷键自定义 + 冲突检测 | 快捷键设置 + 冲突提示【P1】 |
| B30 | 手感相关快捷键 | 键盘快捷键沿用行业标准；按住 Cmd 显示速查映射 | S20 | **采纳（桌面核心优势）** | 桌面用户键盘效率远高于手势 | 全量快捷键表 + 按住 `?`/Cmd 显示速查【P0】 |
| B31 | 滑杆精细控制 | 任意滑杆可拖离滑杆方向做更精细调节 | S1 | **采纳** | 专业手感细节，成本低 | 通用滑杆组件规范【P0】 |
| B32 | 涂抹/橡皮共享笔刷切换 | 按住未选中的 Paint/Smudge/Erase 图标可把当前笔刷设置带过去 | S4 | **采纳** | 一支笔三用，避免重复设置 | 长按工具按钮继承当前笔刷【P1】 |
| B33 | 颜色历史/主副色 | 历史 10 色；主色/副色并排；长按当前色切换主副色 | S15 | **采纳** | 高频换色；X 切换主副色 | 历史 10 + X 交换【P0】 |

---

## 2. 图层

| ID | 能力 | Procreate 公开行为（官方文档改写） | 来源 | v2 决策 | 理由 / 用户价值 | v2 落点 |
|---|---|---|---|---|---|---|
| L01 | 图层面板结构 | 缩略图/名称/混合模式字母/显隐/选中高亮；双击层名进选项菜单 | S8 | **采纳** | 结构成熟，直接对齐 | 图层面板 v2【P0】 |
| L02 | 新建 / 删除 / 复制 / 重命名 / 排序 | 新建（+）；滑动出现锁/复制/删除；拖动排序；重命名 | S8、S9 | **采纳** | 基本功 | 全部【P0】 |
| L03 | 图层组 | 多选后 Group；组可展开/折叠、作为主/次选择；组操作影响全部子层（除绘制/Adjustments）；可 Ungroup | S9 | **采纳** | 复杂插画必需；v0.1 明确没做 | 组 CRUD/拖拽入组/展开【P0】 |
| L04 | 图层蒙版 | 附加蒙版；灰度编辑（黑隐藏/白显示/灰半透明）；可锁/变换/复制；蒙版选中时颜色面板忽略色相 | S12 | **采纳** | 非破坏编辑核心；D1 可撤销的一部分 | 蒙版 + 黑白画笔 + Shift 启用/停用【P0】 |
| L05 | 剪贴蒙版 | 上层剪贴到下层（形状/透明度由下层决定）；可切换开关；移动后按下方层重新剪贴 | S12 | **采纳** | 上色/阴影高频；实现成本中 | Clipping Mask 开关【P1】 |
| L06 | Alpha Lock | 锁定层透明度，只画在有像素处；缩略图棋盘提示；快捷：双指右滑 | S12 | **采纳** | 纹理/细化高频；v2 必须 | Alpha Lock 按钮 + 快捷【P0】 |
| L07 | 图层锁定 | 完全锁定：不可编辑/移动/剪切/变换/删除 | S9 | **采纳** | 防误触 | Lock + 图标【P0】 |
| L08 | 混合模式 | Normal + Multiply/Darken/Color Burn/Linear Burn/Darker Color/Lighten/Screen/Color Dodge/Add/Lighter Color/Overlay/Soft Light/Hard Light/Vivid Light/Linear Light/Pin Light/Hard Mix/Difference/Exclusion/Subtract/Divide/Hue/Saturation/Color/Luminosity | S11 | **简化（16 核心）** | 26 种实现/PSD 映射成本高；16 覆盖绝大多数插画 | 16 种（见规范 §4.4）【P0】 |
| L09 | 不透明度 | 层不透明度滑杆；两指点按层后左右拖画布调整（选区存在时只影响选区内） | S11、S1 | **采纳（简化手势）** | 常用；选区局部调透明度价值高但可后置 | 层滑杆 + 选区内透明度【P1】 |
| L10 | 可见性 / Solo | 眼睛切换显隐；长按眼睛 Solo 单独显示（再长按恢复；隐藏层保持隐藏） | S8 | **采纳（Solo P1）** | 检查单层很实用 | 显隐【P0】；Solo【P1】 |
| L11 | 主/次图层选择 | 点选 Primary（唯一，绘制目标）；右滑加选 Secondary（可多选）；Group/Delete 影响所有选中 | S9 | **简化** | 主/次概念对「多选变换」有价值，但桌面 Shift/Ctrl 多选已够用 | Ctrl/Shift 多选 + 主层高亮【P1】 |
| L12 | 图层选择（画布取层） | Layer Select：画布上触摸内容高亮关联层，抬起选中；多层重叠弹层选择 | S9 | **简化** | 深层画布取层是效率神器；桌面用 Alt+点击 | Alt+点击画布选层【P1】 |
| L13 | 背景色层 | 每个作品自带背景色层，可改色/隐藏（隐藏=透明背景） | S8 | **采纳** | 与 v0.1 一致；导出透明 PNG 需要 | 背景色层【P0】 |
| L14 | 合并 / 向下合并 / 拼合 | Merge Down；多选合并；Group 操作；层数上限时提示合并 | S9、S8 | **采纳** | 层数与性能管理必需 | 合并下/合并选中/拼合【P0】 |
| L15 | 图层数上限 | 上限随画布尺寸/设备变化；达上限须合并 | S9、S16 | **采纳（Web 动态）** | Web 内存硬限制，必须显式化 | 动态上限提示 + 一键合并建议【P0】 |
| L16 | 图层选项菜单 | 重命名/选择内容/复制/填充/清除/Alpha Lock/蒙版/剪贴/参考/绘图辅助 | S10、S12 | **采纳（裁剪）** | 菜单是能力入口；按 v2 范围裁剪 | 层右键菜单（含 v2 功能）【P0】 |
| L17 | 选区局部图层操作 | 有选区时，落笔/调整只影响选区内 | S13 | **采纳** | 与选区系统联动，D1 可撤销 | 选区约束绘制/变换/透明度【P0】 |

---

## 3. 手势（iPad vs 桌面 Web）

| ID | 能力 | Procreate 公开行为 | 来源 | v2 决策 | 桌面 Web 的替代 | 理由 |
|---|---|---|---|---|---|---|
| G01 | 捏合缩放 | 双指捏合缩放画布 | S1 | **采纳（条件）** | 滚轮/触控板捏合缩放；触摸屏双指 | 浏览器可接收 wheel + touch；统一到 viewport 组件 |
| G02 | 双指扭转旋转 | 捏合同时旋转画布 | S1 | **采纳（条件）** | `R` + 拖 / 触控板旋转（可用时） | 勾线习惯；桌面必须有等价键 |
| G03 | 快速捏合适配 | 快速捏合 → 画布适配窗口；反向恢复 | S1 | **采纳** | `0` / 双击抓手 / 状态栏适配按钮 | 桌面键盘更快 |
| G04 | 双指轻点撤销 | 双指轻点画布撤销；长按快速撤销（最多 250 步） | S1 | **简化** | `Ctrl/Cmd+Z`；长按 `Ctrl+Z` 连续撤销 | 浏览器无法可靠识别双指轻点；键盘更稳 |
| G05 | 三指轻点重做 | 三指轻点重做；长按快速重做 | S1 | **简化** | `Ctrl/Cmd+Shift+Z` | 同上 |
| G06 | 三指清扫清空图层 | 三指左右清扫清空当前层 | S1 | **不做（改快捷键）** | `Ctrl+Shift+Delete`（确认） | 手势误触风险高；桌面用快捷键+确认 |
| G07 | 三指下滑剪贴菜单 | 三指下滑呼出 Cut/Copy/Copy All/Duplicate/Cut&Paste/Paste | S1 | **简化** | `Ctrl+X/C/V` + 右键菜单 | 系统剪贴板已足够 |
| G08 | 四指轻点全屏 | 四指轻点隐藏/显示界面；左上角指示器退出 | S1 | **简化** | `F` / `Tab` 隐藏 UI | 桌面 F 键更直接 |
| G09 | 图层双指点按调透明度 | 层上双指点按 → 拖动画布改透明度 | S1 | **简化** | 层不透明度滑杆 + `[` `]`? | 桌面滑杆更快 |
| G10 | 双指右滑 Alpha Lock | 层上双指右滑锁定透明度 | S1 | **简化** | `Alt+点击 Alpha Lock 按钮` / 菜单 | 保留能力，不用手势 |
| G11 | 双指按住选层内容 | 双指按住层选中该层内容（选区） | S1 | **简化** | `Ctrl+点击层缩略图` 生成选区 | 桌面组合键等价 |
| G12 | 捏合合并图层 | 层面板捏合两层合并 | S1 | **简化** | 多选 → 合并（右键/Ctrl+E） | 桌面多选合并更可控 |
| G13 | QuickMenu | 6 键径向；点击/长按拖动；长按按钮改动作；Profile | S2 | **采纳（简化）** | 右键/笔杆键/长按空格呼出；6 键可自定义 | 桌面效率核心，成本可控 |
| G14 | 手势自定义与冲突检测 | Gesture Controls 开关/延迟/多绑定；冲突黄标 | S1、S21 | **简化** | 快捷键设置 + 冲突提示 | 桌面 Web 手势有限；键盘映射更值 |
| G15 | 绘图手势 | 绘制时双指可用于撤销/重做/缩放；四指全屏；QuickShape 第二指触发 | S1 | **简化** | 笔画期间只用键盘/笔杆；避免误触 | 桌面绘画时手在笔上，不在屏幕 |
| G16 | 全屏与 UI 隐藏 | 全屏模式 UI 滑走，只留画布 | S1 | **采纳** | `F` 全屏 + `Tab` 隐藏 UI | 投屏/专注；与 v0.1 设计系统一致 |

**桌面 Web 的现实约束（写进规范，不写进营销）**
- 浏览器 **无法可靠识别多指轻点/三指/四指**（需 Touch Events + 设备支持；鼠标/触控板完全无）。
- 触控板捏合在 Chrome/Edge 表现为 `wheel + ctrlKey`（可识别），但旋转手势基本不可得。
- 手绘板（Wacom 等）通过 Pointer Events 提供 `pressure/tiltX/tiltY`，**不提供 Apple Pencil 的 squeeze/barrel roll**。
- 因此 v2 手势策略：**键盘完整等价 + 笔杆按键 + 径向菜单**；触摸屏/触控板手势作为「有则更好」的增强，不作为唯一路径。

---

## 4. 选区与变换

| ID | 能力 | Procreate 公开行为 | 来源 | v2 决策 | 理由 / 用户价值 | v2 落点 |
|---|---|---|---|---|---|---|
| S01 | 选区入口 | 顶栏选区按钮打开选区工具条；默认 Freehand | S13 | **采纳** | 与绘画工具并列，随时可调 | 选区工具条【P0】 |
| S02 | 自由手绘 / 多边形 | 自由线/点击落点连直线；可混合；可提笔继续画；起点灰圈闭合 | S13·freehand | **采纳** | 精细选区；多边形适合硬边 | Freehand + Polygon【P0】 |
| S03 | 矩形 / 椭圆 | 拖出矩形/椭圆；可多个组合（Add）；导航手势仍可用 | S13·shape | **采纳** | 最常用选区 | Rect / Ellipse【P0】 |
| S04 | 自动选区 | 单点选择色块/区域；按住拖动调阈值；反色显示；继续点按可 Add | S13·automatic | **简化** | 技术上依赖色彩分割质量；先 P1 | Auto（颜色阈值）【P1】 |
| S05 | 加选 / 减选 / 反选 | Add/Remove；Invert；可混合模式构建复杂选区 | S13 | **采纳** | 选区组合是专业刚需 | Shift 加选 / Alt 减选 / Ctrl+Shift+I【P0】 |
| S06 | 选区提交语义 | 虚线蚂蚁线为编辑态；点其他工具=提交，选外覆盖半透明斜线 | S13 | **采纳** | 状态可见，减少误操作 | 同一套状态机【P0】 |
| S07 | 羽化 | 选区羽化滑杆 0–100%，实时预览 | S13 | **采纳** | 柔和边缘；与 T7 羽化 0–8px 对齐需重定范围 | 0–100px? 按引擎；规范给 0–50px【P0】 |
| S08 | 复制粘贴 | Copy&Paste 把选中内容复制到新层「From selection」 | S13 | **采纳** | 高频 | Ctrl+C/V 到新层【P0】 |
| S09 | 保存/载入选区 | 保存选区列表、缩略图、载入 | S13·advanced | **简化** | 高阶；v2 先「重载上次选区」 | 重载上次【P1】；保存列表【P2】 |
| S10 | 清除/填充选区 | Clear；Color Fill（选区模式内直接填充当前色，可连续填充） | S13 | **采纳（简化）** | 平涂效率 | Delete 清空 / Alt+Delete 填充【P0】 |
| S11 | 选区视觉 | 移动虚线边界；提交后半透明移动斜线遮罩 | S13 | **采纳** | 状态清楚 | 与设计 token 对齐【P0】 |
| T01 | 变换入口 | 顶栏箭头按钮；自动选中当前层内容，显示虚线 bounding box | S14 | **采纳** | 基础 | 变换工具【P0】 |
| T02 | 变换节点 | 角/边中点蓝色节点缩放拉伸；黄节点调整框；绿节点旋转；实时角度/尺寸读数 | S14 | **采纳（简化读数）** | 精确变换必需 | 节点 + 读数【P0】 |
| T03 | 自由变换 | 四向拉伸（不保比例）；角节点同时缩放；拖任意处移动 | S14·freeform | **采纳** | 基础 | Freeform【P0】 |
| T04 | 等比变换 | Uniform 保比例；角/边节点；双指从中心缩放 | S14·uniform | **采纳** | 基础 | Shift 约束比例【P0】 |
| T05 | 吸附 / 磁吸 | Snapping 开关；对齐画布中心/其他层元素；移动时出现参考线 | S14 | **采纳** | 排版/对位效率 | 吸附开关 + 参考线【P1】 |
| T06 | 微移（nudge） | 点按框外方向按步进微移；放大后步进更小 | S14 | **采纳** | 精确定位 | 方向键 1px / Shift 10px【P0】 |
| T07 | 旋转 | 旋转节点/中心旋转；实时角度 | S14 | **采纳** | 基础 | Shift 15° 步进【P0】 |
| T08 | 扭曲（Distort） | 4 角自由变形，做透视/倾斜 | S14·distort | **简化（P1）** | 插画修形有价值，先自由/等比 | Distort【P1】 |
| T09 | 变形网格（Warp） | 网格拖拽折叠/包裹；节点前后层级；Advanced Mesh | S14·warp | **不做（v2）** | 实现成本高、使用频率低 | v3 评估【P2】 |
| T10 | 插值方式 | 多种插值算法可选，影响缩放锐利度 | S14·interpolate | **简化（P1）** | 技术项，UI 只给「平滑/锐利」两档 | 两档【P1】 |
| T11 | 提交/取消语义 | 点变换按钮提交；未提交时其他操作按取消处理 | S14 | **采纳** | 避免半提交状态 | Enter 提交 / Esc 取消【P0】 |

---

## 5. 颜色、参考与画布

| ID | 能力 | Procreate 公开行为 | 来源 | v2 决策 | 理由 / 用户价值 | v2 落点 |
|---|---|---|---|---|---|---|
| C01 | 颜色面板五模式 | Disc / Classic / Harmony / Value / Palettes；主/副色；历史 10 色 | S15 | **采纳（Harmony P2）** | 专业用户习惯 Disc/Value；Harmony 加分 | Disc/Value/Palettes/Hex【P0】 |
| C02 | 取色器 | 长按画布取色；Modify 按钮浮窗；设置手势 | S15 | **采纳** | 高频 | Alt+点击 / 笔杆键【P0】 |
| C03 | 参考图层 | 指定层为 Reference，填充按线稿 | S10 | **简化（P1）** | 上色效率 | 参考层 + 填充【P1】 |
| C04 | 参考图 | Reference Companion 浮窗参考 | S2 | **简化（P1）** | 桌面侧栏即可 | 参考图侧栏（拖入/置顶）【P1】 |
| C05 | 画布预设 | Screen/Square/4K/A4/4×6/US Paper | S16 | **采纳（选 6 个）** | 常用尺寸 | 6 预设【P0】 |
| C06 | 自定义画布 | 名称/宽高/DPI/色彩配置/背景/时间-lapse；单位 mm/cm/inch/px | S16 | **简化** | 色彩配置 v2 只 sRGB；单位支持 px/mm；延时不做 | 自定义画布【P0】 |
| C07 | 色彩管理 | 17 个配置，默认 Display P3 / Generic CMYK；可导入 | S16 | **简化** | Web 端先 sRGB；P3 仅显示层支持 | sRGB 固定 + P3 显示提示【P1】 |
| C08 | 画布旋转/全屏/适配 | 见手势 | S1 | **采纳** | 勾线习惯 | R 旋转 / F 全屏 / 0 适配【P0】 |
| C09 | 对称 | 垂直/水平/象限/径向；镜像/旋转；可移位/旋转/颜色/透明度/厚度 | S17 | **采纳（P1）** | 角色/图案 | 4 模式 + 参数【P1】 |
| C10 | 绘图辅助 | Drawing Assist 让笔迹贴合格线；按层开关；图层显示 Assisted 标签 | S19 | **简化（P2）** | 与对称/网格联动，先做对称 | P2 |
| C11 | 背景色 | 画布背景色可改/隐藏（导出透明） | S16、S8 | **采纳** | 与 v0.1 一致 | 背景色层【P0】 |
| C12 | 时间-lapse | 自动录制过程视频，可导出 1080p–4K、HEVC 透明 | S16 | **不做（v2）** | 墨证以事件/证据链替代；视频另立项 | v3 评估；证据链不受影响 |

---

## 6. Procreate 有、但 v2 明确不做（写清避免误解）

| ID | 能力 | 来源 | 决策 | 理由 |
|---|---|---|---|---|
| X01 | 动画辅助（Animation Assist） | Handbook 目录（Animation） | 不做 | 非插画核心；v2 范围外 |
| X02 | 3D 绘画（3D Painting） | Handbook 目录（3D Painting） | 不做 | 与本产品无关 |
| X03 | 文本工具（Add Text） | Handbook 目录（Text） | 不做（v2）；v3 评估 | 画布 v2 先做笔与图层；文字可后置 |
| X04 | 页面辅助（Page Assist） | Handbook 目录 | 不做 | 漫画分页场景不在 v2 |
| X05 | 液化 / 克隆 / 调整（Liquify/Clone/Adjustments） | S2 功能列表 | 不做（v2）；P2 评估 | 依赖引擎后处理；先稳定绘制 |
| X06 | 笔刷文件导入（.brush/.brushset） | S5 | 不做 | 专有格式；v2 用自己的 JSON+PNG 格式 |
| X07 | Apple Pencil 专属（挤压/滚转/悬停调参/双击） | S3 | 不做 | iPad 后续评估；桌面用键盘/笔杆 |
| X08 | CMYK / ICC 导入 | S16 | 不做 | Web 印刷流程非目标用户刚需 |
| X09 | 多画布拖放图层 / Gallery 分屏 | S9 | 不做（v2） | 文件管理后续 |
| X10 | 手势自定义 UI（完整 Gesture Controls） | S1、S21 | 简化（快捷键设置） | Web 手势有限 |

---

## 7. 采纳 / 简化 / 不做 统计

| 决策 | 条目数 | 说明 |
|---|---|---|
| **采纳** | 65 | 笔刷/图层/选区/变换/颜色/画布核心形态（含「采纳但桌面映射简化」的条目） |
| **简化** | 31 | 手势换键盘、Brush Studio 6 组、混合模式 16 种、色彩 sRGB、选区自动 P1 等 |
| **不做（明细表）** | 4 | B12 Apple 专属手势、G06 三指清扫（改快捷键）、T09 Warp（v2）、C12 时间-lapse |
| **不做（§6 单列）** | 10 | 动画/3D/文本/页面辅助/液化/CMYK/多画布拖放/完整手势自定义 UI 等 |
| **合计** | **110** | 100 条明细（B33 + L17 + G16 + S11 + T11 + C12）+ 10 条明确不做（X01–X10） |

> 统计口径：§1–§5 明细表共 100 条；「采纳/简化」为决策列的首个决策词，未把「采纳（简化）」重复计入简化。P0/P1/P2 是 v2 内部优先级，不改变决策类别。


---

## 8. 桌面 Web + 手绘板 vs iPad Procreate：差异与机会

| 维度 | Procreate（iPad） | 我们（桌面 Web + 手绘板） | 对 v2 交互的影响 |
|---|---|---|---|
| 输入 | 手指 + Apple Pencil（压感/倾斜/滚转/挤压/悬停） | 鼠标、触控板、数位板笔（压感/倾斜，无 Apple 私有语义）、键盘 | 「笔优先 + 键盘等价 + 径向菜单」三通道；不赌多指手势 |
| 多指手势 | 系统级可靠 | 浏览器能力参差，鼠标/触控板无 | 手势列「增强」，键盘列「主路径」 |
| 性能/内存 | 原生 Metal、共享内存 | WebGL/WebGPU + JS；受浏览器内存上限 | 画布/图层动态上限 + 降级提示；图层 tile 化（技术 T24/T28 决策） |
| 延迟 | 系统级低延迟 | Pointer Events + 预测；WebGPU 可改善 | 笔刷延迟预算必须写入验收（≤1 帧） |
| 生态 | 封闭但完整（PSD 导出受限） | 开放 Web，PSD 往返需自建 | PSD 子集 + fidelity report；不做「Procreate 级 PSD 保真」承诺 |
| 文件 | .procreate 私有 | 自有项目 JSON + PSD | 不做私有格式逆向；导出 PSD 子集 |
| 优势 | 手感、生态、成熟度 | 键盘快捷键、AI/证据链、跨设备、可脚本/可扩展 | 差异化做「创作记忆 + 过程证据」；画布做到「够专业」 |

---

## 9. 对标结论（给 v2 的范围建议）

1. **手感四件套先做**：压感/倾斜曲线、稳定化、笔尖形态（Shape/Grain 简化）、涂抹。没有这四样，Procreate 用户 5 分钟就会流失。
2. **图层工作流补齐到「专业可用」**：组、蒙版、剪贴、Alpha Lock、锁定、16 混合模式、合并、Solo。这是 v0.1 与 Procreate 最大差距，也是插画师迁移的第一道门槛。
3. **选区/变换做到「不别扭」**：四种选区 + 加减反选羽化 + 复制粘贴 + 自由/等比变换 + 吸附 + 微移；Warp/Distort 放 P1/P2。
4. **桌面效率三件套**：完整快捷键、径向 QuickMenu（右键/笔杆/长按空格）、全屏隐藏 UI。这是桌面 Web 相对 iPad 的真优势。
5. **对称/参考线按 P1**：对角色/图案用户价值高，但不影响主流程。
6. **不做清单要守死**：动画、3D、文本、液化、CMYK、专有笔刷格式、Apple 专属手势——否则 v2 永远发不了。

---

## 10. 不确定与待核实

| # | 问题 | 处理 |
|---|---|---|
| Q1 | Procreate 边界框「黄节点调框、绿节点旋转」在 v2 是否同构？ | v2 规范用「角/边缩放 + 顶部旋转柄」简化，避免节点认知负担（见规范 §5.2） |
| Q2 | 混合模式 16 种是否够？ | 以 PSD 常见插画工作流覆盖率为准；缺失的 10 种进 P2，按用户请求排序 |
| Q3 | Smudge 在 Web 引擎能否达到 Procreate 手感？ | 技术预研 T24 的 spike 项；不达标则 v2 首发降为「基础涂抹」并明示 |
| Q4 | 手势在触控屏笔记本上是否值得完整实现？ | 先做 wheel/触控板缩放 + 触摸屏双指缩放/旋转；多指轻点不做 |
| Q5 | 笔刷参数暴露到什么深度？ | v2 公开 6 组 ≤24 参数；其余参数内部化，避免「设置地狱」 |
| Q6 | 是否支持 iPad Safari？ | v2 不承诺；T24 评估后另立任务（Web 版可跑但不优化触摸笔手感） |

---

## 11. 来源清单（Procreate 官方 Handbook，访问日期 2026-11-06）

> 说明：Procreate 官方 Handbook 在页面上提示「正在查看旧版本（5.3）」；以下引用为公开页面内容，仅用于交互对标，不复制其图片/笔刷等资产。官方页面为单页应用，正文按章节读取。

| 编号 | 页面 | URL | 一句话摘要 |
|---|---|---|---|
| S1 | Gestures | https://help.procreate.com/procreate/handbook/5.3/interface-gestures/gestures | 撤销/重做/缩放/旋转/全屏/图层手势/QuickShape/滑杆精细控制/手势自定义 |
| S2 | QuickMenu | https://help.procreate.com/procreate/handbook/5.3/interface-gestures/quickmenu | 6 键径向菜单、调用方式、自定义与 Profile |
| S3 | Apple Pencil | https://help.procreate.com/procreate/handbook/5.3/interface-gestures/pencil | 压感/倾斜/滚转/挤压/双击/悬停/压力曲线 |
| S4 | Paint, Smudge, Erase | https://help.procreate.com/procreate/handbook/5.3/brushes/paint-smudge-erase | 三者共享笔刷库、强度控制、笔刷切换继承、尺寸记忆 |
| S5 | Brush Library | https://help.procreate.com/procreate/handbook/5.3/brushes/brush-library | Set 分类、最近/固定笔刷、导入 `.brush/.brushset` |
| S6 | Brush Studio | https://help.procreate.com/procreate/handbook/5.3/brushes/brush-studio | 12 属性、Drawing Pad 实时预览、数值/Tilt/Pressure 高级调整 |
| S7 | Brush Studio Settings | https://help.procreate.com/procreate/handbook/5.3/brushes/brush-studio-settings | Stroke Path/Stabilization/Taper/Shape/Grain/Rendering/Wet Mix/Color Dynamics/Dynamics/Apple Pencil/Properties |
| S8 | Layers Interface | https://help.procreate.com/procreate/handbook/5.3/layers/layers-interface | 图层面板结构、缩略图/名称/混合模式/显隐/Solo/背景色层/层选项 |
| S9 | Layers Organize | https://help.procreate.com/procreate/handbook/5.3/layers/layers-organize | 主/次层、组、拖放排序、锁/复制/删除、层数上限、跨画布拖放 |
| S10 | Layers Options | https://help.procreate.com/procreate/handbook/5.3/layers/layers-options | 重命名/选择内容/复制/填充/清除/Alpha/Mask/Reference/Merge |
| S11 | Blend Modes | https://help.procreate.com/procreate/handbook/5.3/layers/layers-blend | 26 种混合模式说明、不透明度与两指点按调透明度 |
| S12 | Mask | https://help.procreate.com/procreate/handbook/5.3/layers/layers-mask | Layer Lock / Alpha Lock / Layer Mask / Clipping Mask |
| S13 | Selections | https://help.procreate.com/procreate/handbook/5.3/selections | 选区四种模式、加减反选、羽化、复制粘贴、保存载入、填充 |
| S14 | Transform | https://help.procreate.com/procreate/handbook/5.3/transform/transform-interface-gestures | 变换框/节点/旋转/吸附/微移；Freeform/Uniform/Distort/Warp/插值 |
| S15 | Colors Interface | https://help.procreate.com/procreate/handbook/5.3/colors/colors-interface | 五种颜色面板、历史 10 色、取色器、调色板 |
| S16 | Canvas Create | https://help.procreate.com/procreate/handbook/5.3/gallery/gallery-create | 画布预设/自定义尺寸/DPI/色彩配置/背景/时间-lapse/层数上限 |
| S17 | Symmetry Guide | https://help.procreate.com/procreate/handbook/5.3/guides/guides-symmetry | 垂直/水平/象限/径向对称、镜像 vs 旋转、外观参数 |
| S18 | QuickShape | https://help.procreate.com/procreate/handbook/5.3/guides/quickshape | 画后吸附形状、二指完美化、15° 磁旋转、Edit Shape |
| S19 | Drawing Assist | https://help.procreate.com/procreate/handbook/5.3/guides/guides-drawing-assist | 笔迹贴合格线、按层开关、Assisted 标签 |
| S20 | Keyboard Shortcuts | https://help.procreate.com/procreate/handbook/5.3/interface-gestures/keyboard | 快捷键沿用行业标准、按住 Cmd 查看映射 |
| S21 | Actions / Preferences（Gesture Controls） | https://help.procreate.com/procreate/handbook/5.3/actions/actions-preferences | 手势开关/延迟/多绑定/冲突提示 |

---

## 12. 变更记录

| 版本 | 日期 | 变更 | 作者 |
|---|---|---|---|
| v1.0 | 2026-11-06 | 首版：100 条明细对标（笔刷/图层/手势/选区变换/颜色画布）+ 10 条明确不做 + 桌面 Web 差异 + 采纳/简化/不做统计 + 21 条官方来源；配套《画布v2交互规范》 | ux-designer |
