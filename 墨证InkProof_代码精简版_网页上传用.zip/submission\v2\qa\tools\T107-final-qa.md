# T107 最终独立 QA：文字持久化 / 对称笔迹 / 形状吸附

> 执行：qa-engineer（独立 QA｜task-115）｜日期：2026-11-07 17:3x｜只写 `v2/qa/tools/`；**未改 app**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、单浏览器串行、小批次（每批 1–3 个，日志落盘 `archive/baseline-t107-final/logs/`）；执行期内存约 2.4GB。

## 结论

**可交付（Deliverable）——P0/P1 = 0；P2 = 1（形状吸附记录值 1px 偏差，记录性；对称 undo 步数为事实记录）。**
新功能 3 项、模块单测 5 项、回归 16 项全过；3 大重点独立核验（文字 meta 持久化/旧 doc 兼容、对称 x/y/both + 关闭不重放、形状网格吸附）均完成并有数据；真实证据一致且**未新增付费调用**。

## 1. 新功能测试（全部 PASS）

| 测试 | 结果 | 关键证据 |
|---|---|---|
| `test-text-edit.mjs` | **PASS** | create/open/edit/**persist**/cursor 全 true；`metaCount=1`、`text="修改后的文字\n第二行"`、双击预填一致、`hasMetaInDoc=true`；`text_edited=1`；光标 alpha>100；0 error |
| `test-symmetry.mjs` | **PASS** | axis=x；leftInk **531**、rightInk **864**（左右两半均有墨）；records=1；0 error |
| `test-guides.mjs` | **PASS** | 网格 alpha=21,898/标签「开」；三分线 24,670；对称轴 26,107/「左右」；0 error |

## 2. 模块单测（Node-only，全部 PASS）

`guides-test` **124 断言**、`asset-batch-test` **11/11**、`asset-ai-test` **10/10**、`editor-ops-test` **77 断言**、`skill-runtime-test` **PASS**（5 skills：asset.decompose / canvas.observe / canvas.directions / image.edit / image.generate）。

## 3. 重点独立核验（QA 自建探针，全部 PASS）

### 3.1 文字 metadata 持久化 + 旧 doc 兼容
| 检查 | 结果 |
|---|---|
| 编辑 → `serializeDoc()` 含 meta | ✅ `"meta":{"text":…}` 存在 |
| `loadProjectText(json)` 后恢复 | ✅ `state.textLayers=1`、`meta.text="持久化文字·修改"`、图层 3 |
| 双击预填 | ✅ 预填「持久化文字·修改」 |
| L6 `text_edited` | ✅ =1 |
| undo 像素还原 | ✅ 编辑前后 diff=3,983；**undo 后 diff=0**；图层数不变 |
| **旧 doc 无 meta** | ✅ 删除全部 meta 后 `loadProjectText` 正常：ready=true、textLayers=0、layers=3、无崩溃 |

### 3.2 对称笔迹（x / y / both）与 undo 事实
| 轴 | 象限新增墨（lt/rt/lb/rb） | 判定 | **undo 步数（事实记录）** |
|---|---|---|---|
| `x`（左右） | 745 / 814 / 0 / 0 | ✅ 左右均有墨、上下无 | **2 步** |
| `y`（上下） | 395 / 0 / 813 / 0 | ✅ 上下均有墨、左右无 | **2 步** |
| `both`（中心） | 400 / 813 / 813 / 857 | ✅ 四象限均有墨 | **4 步** |
| 关闭对称后 | 356 / 0 / 0 / 0 | ✅ **不重放**（仅原笔迹半区） | — |

> 结论：镜像是延迟到原笔迹结束后重放（与 Lead 描述一致）；**x/y 各耗 2 步 undo，both 耗 4 步**——记录事实，不阻塞（建议后续在文档中说明或在一次撤销内合并）。

### 3.3 形状网格吸附（80px / 阈值 6）
- `showGrid=true` 后用形状工具拖拽（起点/终点位于 240/160→480/320 网格附近 1px）：
- 最新 `shape_inserted` params：`{shape:'rect', x:239, y:159, width:242, height:162}`、图层 4。
- **吸附生效**：x/y 距 80 倍数仅 **1px**（239 vs 240、159 vs 160）；非精确整除 → **P2 记录**（疑为形状包围盒含 1px 描边内缩/取整），建议 owner 核实或在断言中用 ±1px 容差。

## 4. 回归（16 项全 PASS，0 console error）

test-app、test-ui、test-library、test-image-workshop、test-multimodal、test-chat、test-canvas-size、test-text、test-editor-basics、test-mask-compare、test-editor-ui、test-ux-p0、test-ai-provider、test-interaction-sequences（**9/9**）、test-asset-batch、test-symmetry（新）——逐项小批次复跑，exit 0、0 console error。

## 5. 真实证据核对（未新增付费调用）

| 证据 | 核对 |
|---|---|
| `asset-real-read-results.json`（17:12 最新） | pass=true；**22,955ms**；source=real、qwen3.8-max、latency=22,225ms、skill=asset.decompose、**L2=5 / L4=4**、records=1 ✅ |
| `qwen-real-e2e-results.json` | pass=true；**21,337ms**；obs=2、regions=2、provider=qwen、**mock=false**、evidence 12/12、real_calls=1 ✅ |
| 新增付费调用 | **0**（仅核对已有证据） |

## 6. 密钥 / 残留 / 稳定性

- 密钥：DOM/localStorage/sessionStorage/已加载 JS 无 key；config GET 仅 hasKey/keyLast4（核验 `configMasked=true`）；未打印 key。
- 残留：**Edge 0、测试端口 0**；每批后清理。
- 稳定性：全部单浏览器串行、小批次；无 OOM/超时 flake。

## 7. 问题清单

| # | 级别 | 问题 | owner | 建议 |
|---|---|---|---|---|
| 1 | **P2** | 形状吸附后 `shape_inserted` 记录坐标 239/159（距 80 倍数 1px），非精确整除 | demo-builder/lead | 核实包围盒 1px 内缩来源；或在测试/文档中使用 ±1px 容差并注明 |
| 2 | 记录事实 | 对称 undo 步数：x/y=2 步、both=4 步 | lead | 不阻塞；建议文档说明（或未来合并为单步） |
| — | ~~P2~~ | skill-runtime 断言已更新为 5 skills（本轮 PASS） | — | 已关闭 |

## 8. 产物与归档

- `v2/qa/tools/T107-final-qa.md`（本报告）
- `v2/qa/tools/archive/baseline-t107-final/`：`logs/`（全部原始输出）、各 result JSON、`focus-results.json`（文字持久化/对称/吸附/密钥 4 项核验）、`qwen-real-e2e-results.json`、`asset-real-read-results.json`、README
- GATE：`v2/qa/tools/GATE-pw.md`「T107-F 最终独立 QA」行
