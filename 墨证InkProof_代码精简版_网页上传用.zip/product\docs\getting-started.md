# Getting Started

This guide takes you from zero to your first evidence package. Total time: about 3 minutes.

> **Platform:** Windows / macOS / Linux, Node.js **22+**, Chrome/Edge. No `npm install`, no cloud account.

---

## 1. Start the app

### Windows

Double-click **`start.bat`**. A terminal window opens and your browser should open automatically.

### macOS / Linux

```bash
chmod +x start.sh   # first time only
./start.sh
```

### Manual start

```bash
node server/server.mjs
# or: npm start
```

Open **http://127.0.0.1:4173** (the terminal prints the actual URL; if the port is busy it uses 4174, 4175, …).

> Do not open `app/index.html` directly via `file://` — browsers block ES modules and local API calls there.

---

## 2. First run: sample project + one-click demo

1. Click **“Load Sample Project”** — a deterministic sample artwork with several layers opens instantly.
2. Click **“Demo Demo / 演示 Demo”** in the top bar (or “Watch once” in the onboarding) to play the **one-click demo**: 8 automated steps on the real UI, about 2.5–3 minutes.
   - Controls: pause/resume, previous/next, exit (`Esc`); progress shows `n/8`.
   - Any manual action on the underlying canvas/toolbar exits auto mode and lets you take over.
   - The demo is labeled **“Simulated demo · AI is Mock”** and makes no network requests.
3. Or skip the demo and continue manually with the steps below.

> **Demo rule:** the sample project *is* the demo. We do not ship a separate demo app or page. All screenshots/videos use: open product → load sample project (or one-click demo) → walk the main flow.

---

## 3. The main workflow

1. **Draw / import** — use the brush or import an image as a layer.
2. **Build archive** — importing an image triggers a **mock** AI pass that produces:
   - L0 original, L1 global notes, L2 regions, L4 observations;
   - confirm / reject / edit each card → L5 decision records; AI actions → L6 derivation events.
3. **Stuck moment** — press **`K`** or click **“Let AI take a look”**, select a region (rect/lasso/brush), and submit without typing. You get 2–4 observations + 2 directions + simulated candidates. Apply one → it becomes a **new editable layer** (move/hide/delete/undo). AI never edits your existing pixels.
4. **Evidence package** — open **“Export Evidence Package”**:
   - preview timeline, AI event list, per-file SHA-256, hash-chain validity, attestation statement;
   - export `*-evidence-*.json` + `canvas-*.png`;
   - verify: compute SHA-256 of the PNG and compare with `manifest.files[].sha256`; the event chain uses `prev_hash` → `hash`.
5. **Attestation mode** — switch in the top bar. In v0.1 all AI is disabled in this mode; export again and the package states **zero generation** for the scope since you entered the mode. Prior AI events (if any) remain visible and are **never hidden**.
6. **Save / export project** — data lives in IndexedDB and autosaves; use **Export Project** to get a portable JSON (layers, archive, events, mode) and **Import Project** to restore it elsewhere.

---

## Keyboard shortcuts

| Action | Shortcut |
|---|---|
| Brush / eraser | `B` / `E` |
| Undo / redo | `Ctrl/Cmd+Z` / `Ctrl/Cmd+Shift+Z` |
| Stuck panel | `K` |
| Pan | `Space` + drag, or middle mouse |
| Zoom | `Ctrl/Cmd + wheel`, `+` / `-` |
| Cancel region selection | `Esc` |
| Export evidence | `Ctrl/Cmd+Shift+E` |
| Demo: pause/resume | `Space` |
| Demo: previous / next | `←` / `→` |
| Demo: exit | `Esc` |

---

## Mock AI and test hooks

- Default AI is **Mock**: deterministic, offline, no API key. The UI labels results as simulated.
- For QA, append a query parameter to the app URL:
  - `?mock=low` → low-confidence responses
  - `?mock=fail` → simulated failures
  - `?mock=slow` → slow responses/timeouts
- Real model providers are **not implemented in v0.1**. The provider interface and config shape are reserved; keys, if ever used, stay local and are never committed.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| “Local service not started” | Double-click `start.bat` / run `./start.sh`; make sure port 4173+ is not blocked by another app |
| Node not found / too old | Install Node.js 22+ from nodejs.org; reopen the terminal |
| Page is blank | Do not open `app/index.html` directly; use the start script. Check the terminal for errors |
| Data seems missing | Check that you are in the same browser profile and site data is not cleared; export a project JSON as backup |
| Wrong port | Use the URL printed in the terminal (ports auto-increment) |
| Demo mode ended unexpectedly | Any manual action on the canvas/toolbar exits auto mode by design; restart from the top bar |
| Need to reset everything | Browser DevTools → Application → Storage → Clear site data (export first!) |

More: [architecture](architecture.md) · [privacy](privacy.md) · [README](../README.md) · [CONTRIBUTING](../CONTRIBUTING.md)
