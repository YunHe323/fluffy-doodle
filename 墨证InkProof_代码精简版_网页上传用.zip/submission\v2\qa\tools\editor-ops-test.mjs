#!/usr/bin/env node
/**
 * v2/qa/tools/editor-ops-test.mjs — T105-B 自测（Node，无浏览器、无第三方依赖）
 * 运行：node v2/qa/tools/editor-ops-test.mjs
 * 覆盖：颜色矩阵/像素调整单调性/透明像素/形状 bounds+SVG path/文本空行/fitRect/浏览器包装降级报错。
 */
import {
  COLOR_MATRIX_SIZE,
  ADJUSTMENT_DEFAULTS,
  identityColorMatrix,
  getAdjustmentMatrix,
  applyAdjustmentsToPixels,
  computeAdjustedDataUrl,
  computeShapeBounds,
  shapeToSvgPath,
  computeShapeRasterPlan,
  rasterizeShapeToDataUrl,
  splitTextLines,
  computeTextLayout,
  rasterizeTextToDataUrl,
  fitRectIntoCanvas,
} from '../../app/core/editor-ops.mjs';

let pass = 0;
const failures = [];
function ok(name, cond, detail = '') {
  if (cond) { pass += 1; return; }
  failures.push(`${name}${detail ? ` :: ${detail}` : ''}`);
}
function eq(name, actual, expected) {
  ok(name, Object.is(actual, expected), `expected ${String(expected)}, got ${String(actual)}`);
}
function near(name, actual, expected, tol = 1) {
  ok(name, Math.abs(actual - expected) <= tol, `expected ≈${expected}±${tol}, got ${actual}`);
}
function throws(name, fn, ctor = Error) {
  try { fn(); failures.push(`${name} :: 未抛错`); } catch (e) {
    if (e instanceof ctor) { pass += 1; return; }
    failures.push(`${name} :: 抛错类型 ${e.constructor.name}（期望 ${ctor.name}）: ${e.message}`);
  }
}
async function rejects(name, fn, ctor = Error) {
  try { await fn(); failures.push(`${name} :: 未 reject`); } catch (e) {
    if (e instanceof ctor) { pass += 1; return; }
    failures.push(`${name} :: reject 类型 ${e.constructor.name}（期望 ${ctor.name}）: ${e.message}`);
  }
}
const px = (...vals) => new Uint8ClampedArray(vals);

/* ---------------- 1. 颜色矩阵 ---------------- */
const identity = getAdjustmentMatrix({});
eq('矩阵长度=20', identity.length, COLOR_MATRIX_SIZE);
eq('默认参数归一化', JSON.stringify(ADJUSTMENT_DEFAULTS), JSON.stringify({ brightness: 0, contrast: 0, saturation: 1, hue: 0 }));
near('默认矩阵=R单位阵(0,0)', identity[0], 1);
near('默认矩阵 offset=0', identity[4], 0);
eq('identityColorMatrix 与默认一致', JSON.stringify(identity), JSON.stringify(identityColorMatrix()));
eq('矩阵元素均为有限数', identity.every((v) => Number.isFinite(v)), true);

const brightUp = getAdjustmentMatrix({ brightness: 0.5 });
near('亮度 +0.5 offset=0.25', brightUp[4], 0.25, 1e-9);
const contrastUp = getAdjustmentMatrix({ contrast: 0.5 });
near('对比度 +0.5 factor=1.5', contrastUp[0], 1.5, 1e-9);
const satZero = getAdjustmentMatrix({ saturation: 0 });
const hue120 = getAdjustmentMatrix({ hue: 120 });
eq('hue 矩阵长度=20', hue120.length, 20);
ok('hue 120 对红→绿：G 行非零', Math.abs(hue120[5]) > 0.1, JSON.stringify(hue120.slice(5, 8)));

/* ---------------- 2. 像素调整（纯函数） ---------------- */
const gray = px(128, 128, 128, 255);
const brightened = applyAdjustmentsToPixels(gray, 1, 1, { brightness: 0.2 });
ok('亮度+：变亮', brightened[0] > 128, `${brightened[0]}`);
const darkened = applyAdjustmentsToPixels(gray, 1, 1, { brightness: -0.2 });
ok('亮度-：变暗', darkened[0] < 128, `${darkened[0]}`);
eq('alpha 保持 255', brightened[3], 255);

const hi = px(192, 192, 192, 255);
const lo = px(64, 64, 64, 255);
const hiC = applyAdjustmentsToPixels(hi, 1, 1, { contrast: 0.5 });
const loC = applyAdjustmentsToPixels(lo, 1, 1, { contrast: 0.5 });
ok('对比度+：亮更亮', hiC[0] > 192, `${hiC[0]}`);
ok('对比度-：暗更暗（差变大）', loC[0] < 64, `${loC[0]}`);

const redish = px(200, 60, 40, 255);
const grayed = applyAdjustmentsToPixels(redish, 1, 1, { saturation: 0 });
near('饱和度0：R≈G', grayed[0], grayed[1], 1);
near('饱和度0：G≈B', grayed[1], grayed[2], 1);
const sat2 = applyAdjustmentsToPixels(redish, 1, 1, { saturation: 2 });
ok('饱和度2：R-G 差更大', (sat2[0] - sat2[1]) >= (redish[0] - redish[1]), `${sat2[0]}-${sat2[1]}`);

const pureRed = px(255, 0, 0, 255);
const greenish = applyAdjustmentsToPixels(pureRed, 1, 1, { hue: 120 });
ok('hue120：绿分量最高', greenish[1] > greenish[0] && greenish[1] > greenish[2], `${greenish[0]},${greenish[1]},${greenish[2]}`);

const transparent = px(10, 20, 30, 0);
const outT = applyAdjustmentsToPixels(transparent, 1, 1, { brightness: 0.9, contrast: 0.9, saturation: 2, hue: 90 });
eq('透明像素 RGBA 原样保持', JSON.stringify(Array.from(outT)), JSON.stringify(Array.from(transparent)));

const arr = px(10, 20, 30, 255, 40, 50, 60, 255);
const outArr = applyAdjustmentsToPixels(arr, 2, 1, { brightness: 0.1 });
eq('返回新数组（不改入参）', JSON.stringify(Array.from(arr)), JSON.stringify([10, 20, 30, 255, 40, 50, 60, 255]));
eq('返回长度正确', outArr.length, 8);
ok('返回类型 Uint8ClampedArray', outArr instanceof Uint8ClampedArray);
throws('非法宽度抛错', () => applyAdjustmentsToPixels(arr, 0, 1, {}), TypeError);
throws('长度不足抛错', () => applyAdjustmentsToPixels(px(1, 2, 3, 4), 2, 2, {}), RangeError);
throws('非数组入参抛错', () => applyAdjustmentsToPixels(null, 1, 1, {}), TypeError);
eq('NaN 参数按默认处理', JSON.stringify(Array.from(applyAdjustmentsToPixels(gray, 1, 1, { brightness: NaN }))), JSON.stringify([128, 128, 128, 255]));

/* ---------------- 3. 形状几何 / SVG path ---------------- */
const rect = { type: 'rect', x: 10, y: 20, width: 100, height: 50 };
const rectB = computeShapeBounds(rect);
eq('rect bounds', JSON.stringify(rectB), JSON.stringify({ x: 10, y: 20, width: 100, height: 50 }));

const ellipse = { type: 'ellipse', x: 0, y: 0, width: 80, height: 40 };
eq('ellipse bounds', JSON.stringify(computeShapeBounds(ellipse)), JSON.stringify({ x: 0, y: 0, width: 80, height: 40 }));
const ellipseC = { type: 'ellipse', cx: 50, cy: 50, rx: 30, ry: 10 };
eq('ellipse(cx/rx) bounds', JSON.stringify(computeShapeBounds(ellipseC)), JSON.stringify({ x: 20, y: 40, width: 60, height: 20 }));

const line = { type: 'line', x1: 100, y1: 50, x2: 20, y2: 10 };
eq('line bounds 归一化', JSON.stringify(computeShapeBounds(line)), JSON.stringify({ x: 20, y: 10, width: 80, height: 40 }));

const rect45 = computeShapeBounds({ ...rect, rotation: 45 });
near('rect 旋转45° bbox 扩大', rect45.width, (100 + 50) / Math.SQRT2, 2);
near('rect 旋转45° 中心不变', rect45.x + rect45.width / 2, 60, 1);
const rect90 = computeShapeBounds({ type: 'rect', x: 0, y: 0, width: 100, height: 40, rotation: 90 });
near('rect 旋转90° 宽高互换(w)', rect90.width, 40, 1);
near('rect 旋转90° 宽高互换(h)', rect90.height, 100, 1);

const rectPath = shapeToSvgPath(rect);
ok('rect path 含 H/V/Z', rectPath.includes('H') && rectPath.includes('V') && rectPath.endsWith('Z'), rectPath);
ok('rect path 起点 M 10 20', rectPath.startsWith('M 10 20'), rectPath);
const ellipsePath = shapeToSvgPath(ellipse);
ok('ellipse path 含 A 弧', /A\s/.test(ellipsePath), ellipsePath);
const linePath = shapeToSvgPath(line);
ok('line path 含 L', linePath.includes('L'), linePath);
ok('line path 起止正确', linePath.startsWith('M 100 50') && linePath.endsWith('L 20 10'), linePath);
throws('未知 shape 抛错', () => computeShapeBounds({ type: 'star' }), TypeError);
throws('未知 shape path 抛错', () => shapeToSvgPath({ type: 'star' }), TypeError);
throws('rect 零宽 path 抛错', () => shapeToSvgPath({ type: 'rect', x: 0, y: 0, width: 0, height: 10 }), RangeError);

const plan = computeShapeRasterPlan(rect, { pixelWidth: 200, pixelHeight: 200 });
eq('shape plan 宽', plan.width, 200);
eq('shape plan 高', plan.height, 200);
near('shape plan scale=min(2,4)=2', plan.scale, 2, 1e-9);
near('shape plan 水平居中 offsetX', plan.offsetX, 0, 1e-6);
ok('shape plan offsetY>0（居中留边）', plan.offsetY > 0, `${plan.offsetY}`);

/* ---------------- 4. 文本布局（纯函数） ---------------- */
eq('空文本 → 0 行', splitTextLines('').length, 0);
eq('纯空白 → 0 行', splitTextLines('   \n\t').length, 0);
eq('null → 0 行', splitTextLines(null).length, 0);
eq('多行切分', JSON.stringify(splitTextLines('a\nb\nc')), JSON.stringify(['a', 'b', 'c']));
eq('Windows 换行', JSON.stringify(splitTextLines('a\r\nb')), JSON.stringify(['a', 'b']));

const layEmpty = computeTextLayout({ text: '', fontSize: 40, padding: 10 });
eq('空文本 lines=[]', layEmpty.lines.length, 0);
eq('空文本 width=2*padding', layEmpty.width, 20);
eq('空文本 height=2*padding', layEmpty.height, 20);

const lay = computeTextLayout({ text: 'ab\ncd', fontSize: 20, lineHeight: 1.5, padding: 8 }, () => 40);
eq('两行文本行数', lay.lines.length, 2);
near('文本宽=40+2*8', lay.width, 56, 0.001);
near('文本高=2*20*1.5+2*8', lay.height, 76, 0.001);
ok('字体字符串含 px', lay.font.includes('20px'), lay.font);

/* ---------------- 5. fitRect ---------------- */
const fit1 = fitRectIntoCanvas(200, 100, 100, 100);
near('fit1 scale=0.5', fit1.scale, 0.5, 1e-9);
eq('fit1 宽 100', fit1.width, 100);
eq('fit1 高 50', fit1.height, 50);
eq('fit1 水平 x=0', fit1.x, 0);
eq('fit1 垂直居中 y=25', fit1.y, 25);
const fit2 = fitRectIntoCanvas(100, 200, 100, 100);
eq('fit2 高 100', fit2.height, 100);
eq('fit2 宽 50', fit2.width, 50);
eq('fit2 水平居中 x=25', fit2.x, 25);
const fit3 = fitRectIntoCanvas(100, 100, 100, 100);
near('fit3 scale=1', fit3.scale, 1, 1e-9);
eq('fit3 居中 x=0/y=0', `${fit3.x},${fit3.y}`, '0,0');
eq('fit 零尺寸返回 zeros', JSON.stringify(fitRectIntoCanvas(0, 100, 100, 100)), JSON.stringify({ x: 0, y: 0, width: 0, height: 0, scale: 0 }));
eq('fit 非法返回 zeros', JSON.stringify(fitRectIntoCanvas(NaN, 1, 1, 1)), JSON.stringify({ x: 0, y: 0, width: 0, height: 0, scale: 0 }));

/* ---------------- 6. 浏览器包装：Node 下应明确 reject ---------------- */
eq('computeAdjustedDataUrl 是函数', typeof computeAdjustedDataUrl, 'function');
await rejects('Node 下调 computeAdjustedDataUrl 明确报错', () => computeAdjustedDataUrl('data:image/png;base64,AAAA', {}), Error);
await rejects('computeAdjustedDataUrl 非法入参', () => computeAdjustedDataUrl('not-a-data-url', {}), TypeError);
await rejects('Node 下 rasterizeShapeToDataUrl 明确报错', () => rasterizeShapeToDataUrl(rect, { pixelWidth: 10, pixelHeight: 10 }), Error);
await rejects('Node 下 rasterizeTextToDataUrl 明确报错', () => rasterizeTextToDataUrl({ text: 'hi', fontSize: 12 }), Error);

/* ---------------- summary ---------------- */
if (failures.length) {
  console.error(`✗ editor-ops self-test failed: ${failures.length} 项失败 / ${pass + failures.length} 项`);
  for (const f of failures) console.error('  - ' + f);
  process.exit(1);
}
console.log(`✓ editor-ops self-test passed: ${pass} 项断言全部通过（Node，无浏览器）`);
process.exit(0);
