﻿﻿# AI 接入 / 交互 / 最终回归 · 独立 QA 报告（T97）

> 执行：qa-engineer（独立于 owner 自测）｜环境：headless Edge（playwright-core `channel:'msedge'`）、独立端口、0 残留
> 约束：只写 `v2/qa/`；不依赖真实 key（假上游 + mock）；不给 app/engine/library 打补丁

## A. AI 代理 QA（T95，已完成）

### A1. 独立复跑 owner 测试：`v2/qa/tools/ai-proxy-test.mjs`

**结果：26/26 PASS，0 error**（数据 `ai-proxy-test-results.json`）。覆盖：health/mock、token 缺失与错误、config 读取/写入/脱敏、chat 转发与 Authorization 透传、SSE、Kimi base64 图片、image URL → 代理下载 + sha256、过期 URL 失败路径、并发 1、401/429/超时、无 key mock、跨响应与 serve 日志不泄漏 key。

### A2. 补充对抗用例（QA 新增）：`v2/qa/tools/ai-proxy-adversarial.mjs`

**结果：31/31 PASS，0 error**（数据 `ai-proxy-adversarial-results.json`）。新增覆盖：

| 类别 | 用例 | 结果 |
|---|---|---|
| token | config GET/POST、chat、image、test 缺 token/错 token → 401；cookie 方式正确放行、错误 401 | ✅ |
| 手动确认 | `x-ai-confirm` 缺失（chat/image）→ 200 mock `reason=needs-confirm`，**上游调用数不增加**；带确认 → real | ✅ |
| Origin | `http://evil.example.com`、`http://127.0.0.1:<其他端口>` → 403；同源 → 放行 | ✅ |
| 请求体 | >8MB body → 拒绝（socket-destroy；见已知点） | ✅ |
| 图片限制 | `2048x2048` 面积超限 400、非法 size 400、参考图 4 张 400、3 张通过 | ✅ |
| 并发 | 2 个 image 请求 → 上游 `maxActive=1`（串行队列） | ✅ |
| 12h URL | 过期 URL 404 → 502 `image_download` + `billed:false` | ✅ |
| 密钥泄漏 | SECRET 不在 config/chat/image/test 响应、不在 serve 日志、config GET 仅 `hasKey/keyLast4`、前端可读位置无 key；配置文件含 key（设计如此） | ✅ |
| 其它 | 非法 JSON → 400；清空 key 后 `hasKey=false`（降级 mock） | ✅ |

### A3. 已知限制 / 低风险问题（不阻塞，列 owner）

| # | 问题 | 严重度 | owner | 说明/建议 |
|---|---|---|---|---|
| 1 | ~~Origin 未校验 scheme~~ | ~~P2~~ | tech-architect | **已修复（T98）**：QA 复核 `https://127.0.0.1:<port>` → 403；对抗套件 35/35 通过 |
| 2 | ~~`.ai-config.json` Windows 权限~~ | ~~P2~~ | tech-architect | **已修复（T98）**：QA 用 `icacls` 复核 — 仅 `SYSTEM / Administrators / 当前用户` 可访问（无 Everyone/Users）；NTFS 下 `stat.mode` 显示 0o666 属平台语义，实际 ACL 已收紧 |
| 3 | ~~>8MB 请求体直接断连、无 413~~ | ~~P2~~ | tech-architect | **已修复（T98）**：QA 复核 >8MB → **413 JSON**（`code=body_too_large`） |
| 4 | ~~仓库无根 `.gitignore`~~ | ~~P2~~ | lead | **已关闭**（2026-11-07：Lead 已补根 `.gitignore`，含 `v2/.ai-config.json`、`v2/.ai-token`、`.runtime-port`、node_modules、pw/log 等） |

> **T98 复核（2026-11-07）**：对抗套件重跑 **35/35 PASS**（原 31 项 + T98 新用例），已知限制 1–3 全部关闭；第 4 项（根 `.gitignore`）由 Lead 关闭。
>
> 以上均**不影响**「AI 代理可用 + 安全基线达标」结论：核心校验（token/confirm/Origin host-port/尺寸/参考图/并发/密钥不泄漏）全部通过。

## B0. 集成早发现（T96 进行中，供 owner 参考，待完成后复核）

- **`window.__AI_LOCAL_TOKEN__` 无注入点**：`v2/serve.mjs` 仅从 env/`v2/.ai-token` 读取 token 用于校验，但**未把 token 注入 app 页面**；`v2/app/js/app.js` 的 `aiToken()` 读 `window.__AI_LOCAL_TOKEN__` → 用 `v2/serve.mjs` 正常打开 demo 时 app 永远拿不到 token，设置保存/测试连接/真实调用会提示「本地代理 token 未注入」（mock 本地路径不受影响）。
- owner 自测 `v2/app/test-ai-provider.mjs` 用 `context.addInitScript` 自行注入 token，掩盖了该集成缺口。
- 建议（owner tech/demo）：serve.mjs 在返回 `v2/app/index.html` 时注入 `<script>window.__AI_LOCAL_TOKEN__="…"</script>`（同源、仅本机、禁止缓存），或提供 `GET /api/ai/token`（仅同源 + 一次性/短时），app 启动时拉取。

## B. app 模型接入 QA（已完成）

### B 结果（app 模型接入，2026-11-07 12:4x，**正常 serve（T99 注入 token）**）

**独立 QA：18/18 PASS**（`app-ai-qa-results.json`；使用正常 `v2/serve.mjs`，**未用 addInitScript**，验证 T99 token 注入生效）。

| 检查 | 结果 |
|---|---|
| defaultMockAnalyze | ✅ |
| defaultMockL6 | ✅ |
| settingsUiVisible | ✅ |
| settingsSaved | ✅ |
| keyRedacted | ✅ |
| keyLast4Shown | ✅ |
| testConnectionReal | ✅ |
| confirmModalShown | ✅ |
| confirmCancelNoRequest | ✅ |
| confirmCancelNoRecord | ✅ |
| realCallSucceeded | ✅ |
| l6Fields | ✅ |
| privacyForcesMock | ✅ |
| noKeyFallsBackMock | ✅ |
| error401Notice | ✅ |
| error429Notice | ✅ |
| timeoutNotice | ✅ |
| noConsoleErrors | ✅ |

- 设置保存/脱敏：`aiTestStatus` 已保存；key 输入框清空、DOM/localStorage 无密钥；config 仅 `hasKey/keyLast4`（末 4 位 `-3f9`）；文件权限 `filePermissions={mode:0o0, acl:ok}`。
- 测试连接：真实（fake 上游）→ `连接成功 · real · moonshot · Nms · vision ✓`。
- 手动确认：**取消** → 上游 chatDelta=0、L6 delta=0、toast「已取消：没有发送图片或档案摘要，也没有写入 AI 记录」；**确认** → 真实调用成功（upstream chatDelta=1，obs=1）。
- L6：`model.provider=moonshot / model=kimi-k3.1-pro / params.latency_ms=数字 / params.usage.total_tokens=200 / mock=false` 全部落库。
- 降级：默认无 key/隐私模式 → Mock（chatDelta=0、badge 本地 Mock、confirm 不弹）；清 key 后回退 Mock。
- 错误提示：401→「模型未配置或密钥无效」、429→「模型繁忙，请稍后重试」、超时→「模型服务暂时不可用」；均不崩溃、可继续用 Mock。


待 T96（app 接真实模型）完成通知后执行：

- [ ] 设置面板：保存 / 脱敏显示 / 测试连接（mock 与 real 路径）
- [ ] 手动确认：取消 → 不发请求、不写假记录；确认后 mock provider 调用成功
- [ ] provider/model/latency/usage 写入 L6 记录（字段核对）
- [ ] 无 key / 隐私模式 → 自动降级 Mock（ui 提示、不报错）
- [ ] 401 / 429 / 超时 → 用户可见错误提示与重试（不崩溃、keep 当前画布）
- [ ] 密钥不出现在前端可读 DOM/localStorage/网络响应

## C. 交互回归（已完成）
### C 结果（交互，2026-11-07 12:47）

- owner `test-interaction-sequences.mjs`：**9/9 PASS**（errors=0）。
- QA 新增组合 `interaction-combos.mjs`：**6/6 PASS** — AI 调用中改选区/关面板/切工具 ✅；设置模态打开时快捷键隔离 ✅；手动确认弹窗 Esc ✅（**首轮发现 P2：Esc 不取消 → 反馈后 demo-builder 已修，复跑转绿**）；保存中导出 ✅；About/档案/证据模态 `.show` 可见性 ✅。


- [ ] `v2/app/test-interaction-sequences.mjs` 独立复跑 9/9
- [ ] 新增组合：AI 调用中改选区 / 关面板 / 切工具；设置模态打开时快捷键隔离；手动确认弹窗 Esc；保存中导出

## D. 最终回归（已完成）
### D 结果（最终回归，2026-11-07 12:5x）

- 三页冒烟：**3/3 PASS**（app/brushes/engine：ready/绘制/拖动保留/帧稳定/undo）。
- 4×3 GATE：**全部闸门通过**（T80 真线宽 CV 口径）。
- 功能回归：**25/25 PASS**（含保存→刷新→打开、PSD、素材库、12 步演示、v2 gzip 往返）。
- app 全量测试：12/13 PASS（test-app / test-ui / test-layer-doc / test-demo / test-mask-eraser / test-paper / test-tools / test-async-export / test-eraser / test-pressure-panel / test-present / test-save-psd 均 PASS；owner `test-ai-provider` 16/16 PASS）。
  - ~~`test-library`：`scrim=false`~~ → **已修复并复核通过（2026-11-07 12:57）**：根因是测试写死 `0.72`（T75 旧值），paper 主题实际为 `rgba(35,27,18,.62)`（符合 T87）；断言已改为 alpha `0.55–0.75` + `blur(2px)`。复核：`test-library` **19/19 全项通过（scrim=true）**、`test-ui` **0 error**。
- 模态 `.show` 修复：About / 档案 / 证据弹层打开后 `classList.show` + 可见（组合回归 `modalVisibility` ✅）。


- [ ] 三页冒烟 3/3 + 4×3 GATE（T80 真线宽 CV 口径）
- [ ] 功能回归 25/25
- [ ] app 全量测试（含模态 `.show` 修复后的 About/档案/证据弹层可见性）

### E 总结论

**可交付（Deliverable）——AI 接入与交互独立 QA 通过。**

- 无阻塞项（P0/P1 = 0）；核心链路：AI 代理安全基线（26/26 + 35/35 对抗）、app 模型接入 18/18、手动确认/取消、L6 计量字段、Mock/隐私降级、401/429/超时提示、交互 9/9 + 组合 6/6、冒烟 3/3、GATE 全绿、功能 25/25。
- 遗留 P2：**0 项**。scrim P2 已由 demo-builder 修复并经 QA 复核关闭（`test-library` 19/19、`test-ui` 0 error）；T98/T99 已关闭 Origin scheme / 413 / Windows ACL / token 注入，详见 A3/B0。
- 数据/证据：`app-ai-qa-results.json`、`interaction-combos-results.json`、`ai-proxy-test-results.json`（26）、`ai-proxy-adversarial-results.json`（35）、`results.json`（GATE）、`functional-regression.json`（25）。
