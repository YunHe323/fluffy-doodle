#!/usr/bin/env node
// v2/qa/tools/ai-proxy-qwen-test.mjs —— T100 Qwen-Image DashScope 异步协议测试（假上游，不依赖真实 key）
import http from 'node:http';
import { spawn } from 'node:child_process';
import { promises as fs } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPO = path.resolve(__dirname, '..', '..', '..');
const TOKEN = 'local-token-QWEN';
const SECRET = 'sk-qwen-test-SECRET';
const TINY_PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
const checks = {};
let successResp = null;
const errors = [];
const allTexts = [];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function fakeUpstream() {
  const state = { submits: 0, polls: 0, active: 0, maxActive: 0, tasks: new Map() };
  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => { raw += c; });
    req.on('end', () => {
      let body = {}; try { body = JSON.parse(raw || '{}'); } catch (e) { /* ignore */ }
      if (req.url.startsWith('/dash-img.png')) { const png = Buffer.from(TINY_PNG, 'base64'); res.writeHead(200, { 'content-type': 'image/png' }); res.end(png); return; }
      if (req.url.startsWith('/dash-missing.png')) { res.writeHead(404); res.end('expired'); return; }
      if (req.headers.authorization !== 'Bearer ' + SECRET) { res.writeHead(401); res.end('{"error":"invalid key"}'); return; }
      if (req.method === 'POST' && req.url === '/api/v1/services/aigc/image-generation/generation') {
        state.submits += 1;
        state.active += 1; state.maxActive = Math.max(state.maxActive, state.active);
        const text = JSON.stringify(body);
        if (!req.headers['x-dashscope-async'] || String(req.headers['x-dashscope-async']) !== 'enable') { state.active -= 1; res.writeHead(400); res.end('{"error":"missing async header"}'); return; }
        const id = 'task-' + state.submits;
        let mode = 'SUCCEEDED';
        if (text.includes('qwen-fail')) mode = 'FAILED';
        if (text.includes('qwen-timeout')) mode = 'RUNNING';
        if (text.includes('qwen-missing')) mode = 'MISSING_URL';
        state.tasks.set(id, { mode, polls: 0, model: body.model, size: body.parameters && body.parameters.size, body });
        setTimeout(() => {
          state.active -= 1;
          res.writeHead(200, { 'content-type': 'application/json' });
          res.end(JSON.stringify({ output: { task_id: id, task_status: 'PENDING' }, model: body.model, usage: { images: 1 } }));
        }, 40);
        return;
      }
      if (req.method === 'GET' && req.url.startsWith('/api/v1/tasks/')) {
        state.polls += 1;
        const id = decodeURIComponent(req.url.split('/').pop());
        const task = state.tasks.get(id);
        if (!task) { res.writeHead(404); res.end('{"error":"task not found"}'); return; }
        task.polls += 1;
        if (task.mode === 'RUNNING') { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ output: { task_id: id, task_status: 'RUNNING' } })); return; }
        if (task.mode === 'FAILED') { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ output: { task_id: id, task_status: 'FAILED', code: 'InternalError', message: 'fake failed' } })); return; }
        const url = 'http://127.0.0.1:' + server.address().port + (task.mode === 'MISSING_URL' ? '/dash-missing.png' : '/dash-img.png');
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify({ output: { task_id: id, task_status: 'SUCCEEDED', results: [{ url }] }, model: task.model, usage: { image_count: 1 } }));
        return;
      }
      res.writeHead(404); res.end('not found');
    });
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve({ server, state, port: server.address().port })));
}
async function waitServe(port) {
  for (let i = 0; i < 100; i += 1) {
    try { const r = await fetch(`http://127.0.0.1:${port}/health`); if (r.ok) return; } catch (e) { /* wait */ }
    await sleep(100);
  }
  throw new Error('serve 未启动');
}
async function req(port, method, pathName, body, headers = {}) {
  const res = await fetch(`http://127.0.0.1:${port}${pathName}`, { method, headers: { ...(body ? { 'content-type': 'application/json' } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text(); allTexts.push(text);
  let json = null; try { json = JSON.parse(text); } catch (e) { /* ignore */ }
  return { status: res.status, text, json, headers: Object.fromEntries(res.headers.entries()) };
}

const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'ai-qwen-'));
let upstream = null, serve = null;
try {
  upstream = await fakeUpstream();
  const port = 4500 + Math.floor(Math.random() * 80);
  serve = spawn(process.execPath, [path.join(REPO, 'v2', 'serve.mjs')], {
    cwd: REPO, env: { ...process.env, PORT: String(port), AI_CONFIG_PATH: path.join(tmp, '.ai-config.json'), AI_TOKEN_PATH: path.join(tmp, '.ai-token'), AI_LOCAL_TOKEN: TOKEN },
    stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true,
  });
  let out = ''; serve.stdout.on('data', (d) => { out += d; }); serve.stderr.on('data', (d) => { out += d; });
  await waitServe(port);
  const H = { 'x-ai-token': TOKEN };
  const CONF = { ...H, 'x-ai-confirm': 'true' };
  let r = await req(port, 'POST', '/api/ai/config', {
    mode: 'real', provider: 'qwen', model: 'qwen3.8-max', timeoutMs: 8000, dashscopePollMs: 20, dashscopeMaxPolls: 4,
    providers: { qwen: { baseUrl: `http://127.0.0.1:${upstream.port}/v1`, imageBaseUrl: `http://127.0.0.1:${upstream.port}`, apiKey: SECRET, imageModel: 'qwen-image-3.0', imageProtocol: 'dashscope-async' } },
  }, H);
  checks.configQwen = r.status === 200 && r.json.config.hasKey === true && r.json.config.provider === 'qwen';
  r = await req(port, 'GET', '/api/ai/config', null, H);
  checks.redactedQwen = !r.text.includes(SECRET) && r.json.providers.qwen && r.json.providers.qwen.keyLast4 === 'CRET';
  // 成功：submit→poll→SUCCEEDED→下载+sha256，前端无上游 URL
  r = await req(port, 'POST', '/api/ai/image', { prompt: 'qwen ok', size: '1024x1024', count: 1 }, CONF);
  successResp = r;
  checks.qwenSuccess = r.status === 200 && r.json.mode === 'real' && r.json.candidates && r.json.candidates.length && r.json.candidates[0].imageDataUrl.startsWith('data:image/png;base64,') && /^[0-9a-f]{64}$/.test(r.json.candidates[0].sha256 || '');
  checks.qwenNoUrlLeak = !r.text.includes('/dash-img.png') && !r.text.includes('http://127.0.0.1:' + upstream.port);
  checks.qwenSubmitPoll = upstream.state.submits >= 1 && upstream.state.polls >= 1;
  r = await req(port, 'POST', '/api/ai/image', { prompt: 'qwen star size', size: '1024*1024', count: 1 }, CONF);
  checks.qwenStarSize = r.status === 200 && r.json.billed === true;
  // FAILED 任务
  r = await req(port, 'POST', '/api/ai/image', { prompt: 'qwen-fail', size: '1024x1024' }, CONF);
  checks.qwenFailed = r.status === 502 && r.json.billed === false && r.json.error && r.json.error.code === 'dashscope_failed' && r.json.error.billed === false;
  // 超时（假上游一直 RUNNING，代理 maxPolls=4 * 20ms）
  r = await req(port, 'POST', '/api/ai/image', { prompt: 'qwen-timeout', size: '1024x1024' }, CONF);
  checks.qwenTimeout = r.status === 504 && r.json.billed === false && r.json.error && r.json.error.code === 'dashscope_timeout';
  // 结果 URL 失效
  r = await req(port, 'POST', '/api/ai/image', { prompt: 'qwen-missing', size: '1024x1024' }, CONF);
  checks.qwenUrlExpired = r.status === 502 && r.json.billed === false && r.json.error && r.json.error.code === 'image_download';
  // 串行队列：两个请求并发，假上游 submit 最大并发 1
  await Promise.all([
    req(port, 'POST', '/api/ai/image', { prompt: 'qwen-serial-a', size: '1024x1024' }, CONF),
    req(port, 'POST', '/api/ai/image', { prompt: 'qwen-serial-b', size: '1024x1024' }, CONF),
  ]);
  checks.qwenSerial = upstream.state.maxActive === 1;
  checks.noKeyLeak = !allTexts.some((t) => t.includes(SECRET)) && !out.includes(SECRET);
  checks.pass = Object.values(checks).every(Boolean);
} catch (e) { errors.push(String((e && e.stack) || e)); checks.pass = false; }
finally {
  try { upstream && upstream.server.close(); } catch (e) { /* ignore */ }
  try { serve && serve.kill(); } catch (e) { /* ignore */ }
  await fs.rm(tmp, { recursive: true, force: true }).catch(() => {});
}
const result = { schema: 'mozheng.qa.ai-proxy-qwen.v1', success: !successResp ? null : { status: successResp.status, json: successResp.json, text: successResp.text.slice(0, 1200) }, at: new Date().toISOString(), checks, errors, pass: !!checks.pass, stats: upstream ? { submits: upstream.state.submits, polls: upstream.state.polls, maxActive: upstream.state.maxActive } : null };
console.log(JSON.stringify(result, null, 2));
await fs.writeFile(path.join(__dirname, 'ai-proxy-qwen-results.json'), JSON.stringify(result, null, 2), 'utf8');
process.exit(result.pass ? 0 : 1);
