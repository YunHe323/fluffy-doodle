// v2/qa/tools/verify-evidence-bytes.mjs —— 验证「下载的画布 PNG 字节 SHA-256 = 证据包 canvas.png_sha256」+ CLI verify
// 不起 AI 调用：路演模式 → 直接用预置样本落层 → 导出证据包 → 下载 JSON/PNG → 本地比对
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { chromium } from '../node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const OUT = path.join(ROOT, 'v2', 'qa', 'tools', 'evidence-bytes');
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(OUT, { recursive: true });
const out = { schema: 'mozheng.evidence.bytes.v1', checks: {}, pass: false };
let browser = null;
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 }, acceptDownloads: true });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => out.pageError = String(e.message || e).slice(0, 200));
  await page.goto('http://127.0.0.1:4200/v2/app/index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
  await sleep(900);
  await page.click('#btnRoadshow'); await sleep(300);
  await page.click('#btnRoadshowStart');
  await page.waitForFunction('(() => { const t = window.__V2_APP__ && window.__V2_APP__.t122; return !!(t && t.state().prepared); })()', null, { timeout: 60000 });
  await sleep(500);
  // 第 5 拍：预置样本落层（0 元，不调模型）
  await page.evaluate(() => window.__V2_APP__.t122.goto(4)); await sleep(300);
  await page.click('#btnRoadshowExec'); await sleep(1800);
  // 第 6 拍：生成证据包
  await page.evaluate(() => window.__V2_APP__.t122.goto(5)); await sleep(300);
  await page.click('#btnRoadshowExec');
  await page.waitForFunction('!!document.querySelector("#evidenceModal.show")', null, { timeout: 90000 });
  await sleep(1200);
  const expected = await page.evaluate(() => {
    const ev = window.__V2_APP__.state.evidence;
    return ev && ev.project && ev.project.canvas ? { png_sha256: ev.project.canvas.png_sha256, png_bytes: ev.project.canvas.png_bytes, dataurl_sha256: ev.project.canvas.sha256, events: ev.manifest.event_count, head: ev.manifest.head_hash } : null;
  });
  out.checks.expected = expected;
  // 下载 JSON
  const [dlJson] = await Promise.all([page.waitForEvent('download'), page.click('#btnDownloadJson')]);
  const jsonPath = path.join(OUT, 'inkproof-evidence.json');
  await dlJson.saveAs(jsonPath);
  const pkg = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
  // 下载 PNG
  const [dlPng] = await Promise.all([page.waitForEvent('download'), page.click('#btnDownloadPng')]);
  const pngPath = path.join(OUT, 'inkproof-canvas.png');
  await dlPng.saveAs(pngPath);
  const pngBuf = fs.readFileSync(pngPath);
  const pngSha = sha(pngBuf);
  out.checks.downloaded = { jsonBytes: fs.statSync(jsonPath).size, pngBytes: pngBuf.length, pngSha };
  out.checks.hashMatch = !!(expected && expected.png_sha256 === pngSha);
  out.checks.sizeMatch = !!(expected && Number(expected.png_bytes) === pngBuf.length);
  out.checks.jsonHasPngSha = pkg && pkg.project && pkg.project.canvas && pkg.project.canvas.png_sha256 === pngSha;
  out.checks.pkgEvents = pkg && pkg.manifest && pkg.manifest.event_count === expected.events;
  // 旧口径 CLI verify（dataURL 哈希）
  const cli = spawnSync(process.execPath, [path.join(ROOT, 'v2', 'qa', 'tools', 'verify-evidence.mjs'), jsonPath], { encoding: 'utf8', timeout: 60000 });
  out.checks.cli = { status: cli.status, stdout: String(cli.stdout || '').slice(0, 600), stderr: String(cli.stderr || '').slice(0, 400) };
  out.pass = out.checks.hashMatch && out.checks.sizeMatch && out.checks.jsonHasPngSha && out.checks.pkgEvents && !out.pageError;
  console.log(JSON.stringify(out, null, 2));
  await browser.close();
  process.exit(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  console.log(JSON.stringify(out, null, 2));
  try { await browser.close(); } catch (err) {}
  process.exit(3);
}
