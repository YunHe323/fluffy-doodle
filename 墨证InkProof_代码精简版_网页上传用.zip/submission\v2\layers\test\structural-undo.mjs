#!/usr/bin/env node
// v2/layers/test/structural-undo.mjs —— T63 LayerSystem 结构操作 undo（零依赖 CDP）
// 用法：node v2/layers/test/structural-undo.mjs <layersDemoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/layers/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || join(dirname(fileURLToPath(import.meta.url)), '..', 'results', 'structural-undo.json');
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/layers/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 layers demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__LAYERS_READY__) { if (Date.now() - t0 > 30000) throw new Error('layers timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const ls = window.__LAYERS__;
  const checks = {};
  const n0 = ls.layers.length;
  const g0 = ls.groups.length;
  // 画笔一笔（与结构共享栈）
  ls.beginStroke({ x: 200, y: 200, pressure: 0.7, timestamp: performance.now(), pointerType: 'synthetic' });
  for (let i = 1; i < 12; i += 1) ls.appendPoint({ x: 200 + i * 12, y: 200, pressure: 0.7, timestamp: performance.now(), pointerType: 'synthetic' });
  ls.endStroke();
  const paintDepth = ls.undoStack.length;
  checks.paintUndoExists = paintDepth > 0;
  // addGroup
  const g = ls.addGroup('结构组');
  checks.addGroup = ls.groups.length === g0 + 1;
  ls.undo(); checks.addGroupUndo = ls.groups.length === g0;
  // addLayer（在组内）
  const l = ls.addLayer({ name: '结构层', group: g.id });
  checks.addLayer = ls.layers.length === n0 + 1 && l.group === g.id;
  ls.undo(); checks.addLayerUndo = ls.layers.length === n0;
  const l2 = ls.addLayer({ name: 'L2' });
  // duplicate
  const dup = ls.duplicateLayer(l2.id);
  checks.duplicate = !!dup && ls.layers.length === n0 + 2;
  ls.undo(); checks.duplicateUndo = ls.layers.length === n0 + 1;
  ls.redo(); checks.duplicateRedo = ls.layers.length === n0 + 2;
  // move
  const order0 = ls.layers.map((x) => x.id).join(',');
  ls.moveLayer(l2.id, -1);
  const moved = ls.layers.map((x) => x.id).join(',') !== order0;
  ls.undo();
  checks.moveUndo = moved && ls.layers.map((x) => x.id).join(',') === order0;
  ls.redo();
  // delete
  const dcount = ls.layers.length;
  ls.deleteLayer(l2.id);
  checks.delete = ls.layers.length === dcount - 1;
  ls.undo(); checks.deleteUndo = ls.layers.length === dcount;
  // merge
  const top = ls.layers[ls.layers.length - 1];
  const mcount = ls.layers.length;
  const merged = ls.mergeDown(top.id);
  checks.merge = merged === true && ls.layers.length === mcount - 1;
  ls.undo(); checks.mergeUndo = ls.layers.length === mcount;
  // flatten
  const fcount = ls.layers.length;
  ls.flattenAll();
  checks.flatten = ls.layers.length === 1 && ls.groups.length === 0;
  ls.undo(); checks.flattenUndo = ls.layers.length === fcount;
  // 结构 undo 后 doc 结构可序列化
  const doc = ls.getDoc();
  checks.docCompatible = doc.schema === 'mozheng.doc.v1' && doc.layers.length === ls.layers.length;
  ls.dispose && ls.dispose();
  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v === true);
  return { ok: checks.ok, checks, counts: { n0, g0, final: { layers: doc.layers.length, groups: doc.groups.length } }, environment: { headless: /HeadlessChrome/.test(navigator.userAgent) } };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1200)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
try { mkdirSync(dirname(outPath), { recursive: true }); writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); }
ws.close();
process.exit(value.ok ? 0 : 1);
