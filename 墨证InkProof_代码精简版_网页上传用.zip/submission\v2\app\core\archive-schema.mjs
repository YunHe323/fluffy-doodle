// product/core/archive-schema.mjs
// 七层素材档案记录校验（L0–L6），零依赖、同步、跨运行时（浏览器 + Node 22+）。
// 对齐：06-技术/数据模型_schema.json v0.2.0（Draft 2020-12 的运行时轻量实现）
// 注意：这里只做"记录级"校验；跨记录引用完整性（如 evidenceRefs 指向真实记录）由调用方保证。

export const SCHEMA_VERSION = '0.2.0';
/** 兼容 0.1.x 旧记录（迁移期），新写入应为 0.2.x */
export const SUPPORTED_SCHEMA_VERSIONS = /^0\.[12]\.\d+$/;

export const LAYERS = Object.freeze(['L0', 'L1', 'L2', 'L3', 'L4', 'L5', 'L6']);
export const MVP_LAYERS = Object.freeze(['L0', 'L1', 'L2', 'L4', 'L5', 'L6']);
export const SOURCES = Object.freeze(['observed', 'inferred', 'user-confirmed']);
export const AUTHORS = Object.freeze(['ai', 'user', 'ai-suggested-user-accepted']);
export const MODES = Object.freeze(['collab', 'attest']);
export const AI_ROLES = Object.freeze(['tool', 'assistant', 'collaborator']);
export const ANCHOR_TYPES = Object.freeze(['whole', 'bbox', 'mask', 'point', 'region']);
export const L6_KINDS = Object.freeze([
  'generation', 'critique', 'import', 'export', 'canvas_snapshot', 'canvas_resized',
  'mode_change', 'role_change', 'reference_used', 'cancelled',
  'asset_inserted', 'reference_added', 'reference_removed', 'pixel_paste', 'text_inserted',
  'adjust_layer', 'shape_inserted', 'text_edited',
]);
export const L4_KINDS = Object.freeze(['observation', 'association', 'question', 'teaching']);
export const L5_KINDS = Object.freeze([
  'keep', 'delete', 'recolor', 'reshape', 'accept_ai', 'reject_ai',
  'deviate_from_archive', 'switch_style',
]);
export const L2_L3_RELATIONS = Object.freeze([
  'echo', 'contrast', 'gaze', 'rhythm', 'negative_space', 'repetition_variation', 'other',
]);
export const FORMATS = Object.freeze(['psd', 'png', 'jpg', 'webp', 'tiff', 'other']);
export const COLOR_SPACES = Object.freeze(['sRGB', 'DisplayP3', 'Gray', 'CMYK', 'AdobeRGB', 'other']);
export const MEDIUM_KINDS = Object.freeze([
  'digital_painting', 'watercolor', 'oil', 'ink', 'pencil', 'lineart', 'mixed', 'photography', '3d', 'other',
]);

const RE_RECORD_ID = /^L[0-6]-[A-Za-z0-9._-]{1,80}$/;
const RE_ASSET_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$/;
const RE_SHA256 = /^[a-f0-9]{64}$/;
const RE_HEX_COLOR = /^#[0-9a-f]{6}$/;
const RE_ISO = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,3})?(Z|[+-]\d{2}:\d{2})$/;
const RE_ASPECT = /^\d{1,2}:\d{1,2}$/;

const COMMON_REQUIRED = Object.freeze([
  'id', 'asset_id', 'layer', 'anchor', 'source', 'author', 'mode', 'ai_role',
  'created_at', 'schema_version',
]);

class Ctx {
  constructor() { this.errors = []; }
  add(path, error, message) { this.errors.push({ path, error, message }); }
  has(errors) { return this.errors.length === 0; }
}

const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const isStr = (v) => typeof v === 'string';
const isNonEmptyStr = (v) => typeof v === 'string' && v.length > 0;
const isInt = (v) => Number.isInteger(v);
const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
const isBool = (v) => typeof v === 'boolean';

function checkEnum(ctx, path, value, allowed) {
  if (!allowed.includes(value)) {
    ctx.add(path, 'invalid_enum', `应为 ${allowed.join(' | ')}`);
  }
}

function checkAnchor(ctx, anchor) {
  if (!isObj(anchor)) { ctx.add('anchor', 'invalid_type', 'anchor 必须是对象'); return; }
  if (!ANCHOR_TYPES.includes(anchor.type)) {
    ctx.add('anchor.type', 'invalid_enum', `应为 ${ANCHOR_TYPES.join(' | ')}`);
    return;
  }
  const v = anchor.value;
  switch (anchor.type) {
    case 'whole':
      if (v !== null && v !== undefined) ctx.add('anchor.value', 'invalid', 'whole 的 value 必须为 null');
      break;
    case 'bbox':
      if (!Array.isArray(v) || v.length !== 4 || !v.every(isNum)) {
        ctx.add('anchor.value', 'invalid_bbox', 'bbox 必须为 [x, y, w, h] 四个数字');
      }
      break;
    case 'point':
      if (!Array.isArray(v) || v.length !== 2 || !v.every(isNum)) {
        ctx.add('anchor.value', 'invalid_point', 'point 必须为 [x, y] 两个数字');
      }
      break;
    case 'region':
      if (!isStr(v) || !/^L2-[A-Za-z0-9._-]{1,80}$/.test(v)) {
        ctx.add('anchor.value', 'invalid_region_ref', 'region 锚点必须指向 L2 记录 ID');
      }
      break;
    case 'mask':
      if (!isNonEmptyStr(v) && !isNonEmptyStr(anchor.mask_ref)) {
        ctx.add('anchor.value', 'invalid_mask', 'mask 锚点需要 value 或 mask_ref 字符串');
      }
      break;
    default:
      break;
  }
}

function checkCommon(ctx, record) {
  for (const field of COMMON_REQUIRED) {
    if (record[field] === undefined) ctx.add(field, 'required', '缺少必填字段');
  }
  if (record.id !== undefined && !RE_RECORD_ID.test(record.id)) {
    ctx.add('id', 'invalid_pattern', '记录 ID 必须形如 L{0-6}-xxxx');
  }
  if (record.asset_id !== undefined && !RE_ASSET_ID.test(record.asset_id)) {
    ctx.add('asset_id', 'invalid_pattern', 'asset_id 不合法');
  }
  if (record.layer !== undefined) checkEnum(ctx, 'layer', record.layer, LAYERS);
  if (record.source !== undefined) checkEnum(ctx, 'source', record.source, SOURCES);
  if (record.author !== undefined) checkEnum(ctx, 'author', record.author, AUTHORS);
  if (record.mode !== undefined) checkEnum(ctx, 'mode', record.mode, MODES);
  if (record.ai_role !== undefined && record.ai_role !== null) {
    checkEnum(ctx, 'ai_role', record.ai_role, AI_ROLES);
  }
  if (record.confidence !== undefined && record.confidence !== null) {
    if (!isNum(record.confidence) || record.confidence < 0 || record.confidence > 1) {
      ctx.add('confidence', 'out_of_range', 'confidence 必须为 0–1 的数字或 null');
    }
  }
  if (record.created_at !== undefined && !RE_ISO.test(record.created_at)) {
    ctx.add('created_at', 'invalid_datetime', 'created_at 必须是带时区的 ISO 8601');
  }
  if (record.updated_at !== undefined && record.updated_at !== null && !RE_ISO.test(record.updated_at)) {
    ctx.add('updated_at', 'invalid_datetime', 'updated_at 必须是带时区的 ISO 8601');
  }
  if (record.schema_version !== undefined && !SUPPORTED_SCHEMA_VERSIONS.test(record.schema_version)) {
    ctx.add('schema_version', 'invalid_version', '应为 0.1.x 或 0.2.x');
  }
  if (record.anchor !== undefined) checkAnchor(ctx, record.anchor);
  if (record.supersedes !== undefined && record.supersedes !== null && !RE_RECORD_ID.test(record.supersedes)) {
    ctx.add('supersedes', 'invalid_pattern', 'supersedes 必须指向记录 ID 或 null');
  }
}

function checkL0(ctx, r) {
  for (const f of ['file_path', 'sha256', 'format', 'width', 'height', 'color_space', 'imported_at', 'consent']) {
    if (r[f] === undefined) ctx.add(f, 'required', 'L0 缺少必填字段');
  }
  if (r.anchor?.type !== 'whole') ctx.add('anchor.type', 'invalid', 'L0 锚点必须为 whole');
  if (r.source !== undefined && r.source !== 'observed') ctx.add('source', 'invalid', 'L0 来源必须为 observed');
  if (r.author !== undefined && r.author !== 'user') ctx.add('author', 'invalid', 'L0 只能由用户导入');
  if (isStr(r.sha256) && !RE_SHA256.test(r.sha256)) ctx.add('sha256', 'invalid_pattern', 'sha256 必须为 64 位小写 hex');
  if (r.format !== undefined) checkEnum(ctx, 'format', r.format, FORMATS);
  if (r.color_space !== undefined) checkEnum(ctx, 'color_space', r.color_space, COLOR_SPACES);
  if (r.width !== undefined && (!isInt(r.width) || r.width < 1)) ctx.add('width', 'invalid_int', 'width 必须是正整数');
  if (r.height !== undefined && (!isInt(r.height) || r.height < 1)) ctx.add('height', 'invalid_int', 'height 必须是正整数');
  if (r.consent !== undefined) {
    if (!isObj(r.consent)) { ctx.add('consent', 'invalid_type', 'consent 必须是对象'); return; }
    if (!isBool(r.consent.allow_training)) ctx.add('consent.allow_training', 'required', '必须显式 false');
    else if (r.consent.allow_training !== false) ctx.add('consent.allow_training', 'invalid', 'MVP 默认不训练，必须 false');
    if (!isBool(r.consent.allow_ai_processing)) ctx.add('consent.allow_ai_processing', 'required', '必须为 boolean');
    if (!isBool(r.consent.allow_display)) ctx.add('consent.allow_display', 'required', '必须为 boolean');
  }
}

function checkL1(ctx, r) {
  for (const f of ['subject', 'scene', 'medium', 'palette']) {
    if (r[f] === undefined) ctx.add(f, 'required', 'L1 缺少必填字段');
  }
  if (r.subject !== undefined && (!Array.isArray(r.subject) || !r.subject.every(isStr))) {
    ctx.add('subject', 'invalid_type', 'subject 必须是字符串数组');
  }
  if (r.scene !== undefined && !isNonEmptyStr(r.scene)) ctx.add('scene', 'invalid_type', 'scene 必须是非空字符串');
  if (r.medium !== undefined) {
    if (!isObj(r.medium)) ctx.add('medium', 'invalid_type', 'medium 必须是对象');
    else if (r.medium.kind !== undefined) checkEnum(ctx, 'medium.kind', r.medium.kind, MEDIUM_KINDS);
    else ctx.add('medium.kind', 'required', 'medium.kind 必填');
  }
  if (r.palette !== undefined) {
    if (!Array.isArray(r.palette)) ctx.add('palette', 'invalid_type', 'palette 必须是数组');
    else r.palette.forEach((c, i) => {
      if (!isObj(c) || !isStr(c.hex) || !RE_HEX_COLOR.test(c.hex.toLowerCase())) {
        ctx.add(`palette[${i}].hex`, 'invalid_pattern', '色值必须形如 #rrggbb（小写 hex）');
      }
    });
  }
  if (r.aspect_ratio !== undefined && !RE_ASPECT.test(r.aspect_ratio)) {
    ctx.add('aspect_ratio', 'invalid_pattern', '宽高比必须形如 5:7');
  }
}

function checkL2(ctx, r) {
  for (const f of ['label', 'crop_path']) {
    if (r[f] === undefined) ctx.add(f, 'required', 'L2 缺少必填字段');
  }
  if (r.label !== undefined && !isNonEmptyStr(r.label)) ctx.add('label', 'invalid_type', 'label 必须是非空字符串');
  if (r.crop_path !== undefined && !isNonEmptyStr(r.crop_path)) ctx.add('crop_path', 'invalid_type', 'crop_path 必须是非空字符串');
  if (r.anchor && !['bbox', 'mask'].includes(r.anchor.type)) {
    ctx.add('anchor.type', 'invalid', 'L2 锚点必须为 bbox 或 mask');
  }
  if (r.importance !== undefined && (!isNum(r.importance) || r.importance < 0 || r.importance > 1)) {
    ctx.add('importance', 'out_of_range', 'importance 必须为 0–1');
  }
}

function checkL3(ctx, r) {
  for (const f of ['a_region', 'b_region', 'relation_type']) {
    if (r[f] === undefined) ctx.add(f, 'required', 'L3 缺少必填字段');
  }
  if (r.a_region !== undefined && !/^L2-[A-Za-z0-9._-]{1,80}$/.test(r.a_region)) {
    ctx.add('a_region', 'invalid_pattern', 'a_region 必须指向 L2 记录');
  }
  if (r.b_region !== undefined && !/^L2-[A-Za-z0-9._-]{1,80}$/.test(r.b_region)) {
    ctx.add('b_region', 'invalid_pattern', 'b_region 必须指向 L2 记录');
  }
  if (r.relation_type !== undefined) checkEnum(ctx, 'relation_type', r.relation_type, L2_L3_RELATIONS);
}

function checkL4(ctx, r) {
  for (const f of ['text', 'kind']) {
    if (r[f] === undefined) ctx.add(f, 'required', 'L4 缺少必填字段');
  }
  if (r.text !== undefined && !isNonEmptyStr(r.text)) ctx.add('text', 'invalid_type', 'text 必须是非空字符串');
  if (r.kind !== undefined) checkEnum(ctx, 'kind', r.kind, L4_KINDS);
  if (r.evidence_refs !== undefined) {
    if (!Array.isArray(r.evidence_refs)) ctx.add('evidence_refs', 'invalid_type', 'evidence_refs 必须是数组');
  }
  const evidence = r.evidence_refs ?? r.evidenceRefs ?? [];
  if (r.author === 'ai' && (!Array.isArray(evidence) || evidence.length === 0)) {
    ctx.add('evidence_refs', 'required', 'AI 写的 L4 观察必须附证据锚点（至少 1 条）');
  }
}

function checkL5(ctx, r) {
  for (const f of ['kind', 'session_id', 'created_by']) {
    if (r[f] === undefined) ctx.add(f, 'required', 'L5 缺少必填字段');
  }
  if (r.kind !== undefined) checkEnum(ctx, 'kind', r.kind, L5_KINDS);
  if (r.created_by !== undefined) checkEnum(ctx, 'created_by', r.created_by, ['user', 'ai-suggested-user-accepted']);
  if (r.session_id !== undefined && !isNonEmptyStr(r.session_id)) ctx.add('session_id', 'invalid_type', 'session_id 必须是非空字符串');
}

function checkL6(ctx, r) {
  for (const f of ['kind', 'model', 'params', 'input_refs', 'assertions']) {
    if (r[f] === undefined) ctx.add(f, 'required', 'L6 缺少必填字段');
  }
  if (r.kind !== undefined) checkEnum(ctx, 'kind', r.kind, L6_KINDS);
  if (r.model !== undefined) {
    if (!isObj(r.model)) ctx.add('model', 'invalid_type', 'model 必须是对象');
    else {
      if (!isNonEmptyStr(r.model.provider)) ctx.add('model.provider', 'required', 'model.provider 必填');
      if (!isNonEmptyStr(r.model.model)) ctx.add('model.model', 'required', 'model.model 必填');
    }
  }
  if (r.params !== undefined && !isObj(r.params)) ctx.add('params', 'invalid_type', 'params 必须是对象');
  if (r.input_refs !== undefined && !Array.isArray(r.input_refs)) ctx.add('input_refs', 'invalid_type', 'input_refs 必须是数组');
  if (r.assertions !== undefined && !Array.isArray(r.assertions)) ctx.add('assertions', 'invalid_type', 'assertions 必须是数组');
  if (r.credits !== undefined && (!isInt(r.credits) || r.credits < 0)) {
    ctx.add('credits', 'invalid_int', 'credits 必须是非负整数（展示积分）');
  }
  if (r.cost_cny !== undefined && (!isNum(r.cost_cny) || r.cost_cny < 0)) {
    ctx.add('cost_cny', 'invalid_number', 'cost_cny 必须是非负数字（人民币成本）');
  }

  if (r.kind === 'generation') {
    if (!isNonEmptyStr(r.output_asset_id)) ctx.add('output_asset_id', 'required', 'generation 必须记录 output_asset_id');
    if (r.cost_cny === undefined) ctx.add('cost_cny', 'required', 'generation 必须记录 cost_cny');
    if (r.credits === undefined) ctx.add('credits', 'required', 'generation 必须记录展示积分 credits');
  }
  if (r.kind === 'mode_change') {
    for (const f of ['from_mode', 'to_mode', 'actor']) {
      if (r[f] === undefined) ctx.add(f, 'required', 'mode_change 必须记录 from_mode/to_mode/actor');
    }
    if (r.from_mode !== undefined) checkEnum(ctx, 'from_mode', r.from_mode, MODES);
    if (r.to_mode !== undefined) checkEnum(ctx, 'to_mode', r.to_mode, MODES);
  }
  if (r.kind === 'role_change') {
    for (const f of ['from_role', 'to_role', 'actor']) {
      if (r[f] === undefined) ctx.add(f, 'required', 'role_change 必须记录 from_role/to_role/actor');
    }
    if (r.from_role !== undefined) checkEnum(ctx, 'from_role', r.from_role, AI_ROLES);
    if (r.to_role !== undefined) checkEnum(ctx, 'to_role', r.to_role, AI_ROLES);
  }
  // AI 参与的产生类记录必须能追溯到角色（D8/C-12）
  if (['generation', 'critique'].includes(r.kind) && (r.ai_role === null || r.ai_role === undefined)) {
    ctx.add('ai_role', 'required', '生成/评估类 L6 必须记录 ai_role');
  }
}

const LAYER_VALIDATORS = Object.freeze({
  L0: checkL0, L1: checkL1, L2: checkL2, L3: checkL3, L4: checkL4, L5: checkL5, L6: checkL6,
});

/**
 * 校验单条档案记录。
 * @param {object} record
 * @returns {{ok:boolean, errors:Array<{path:string,error:string,message:string}>}}
 */
export function validateArchiveRecord(record) {
  const ctx = new Ctx();
  if (!isObj(record)) {
    ctx.add('', 'invalid_type', '记录必须是对象');
    return { ok: false, errors: ctx.errors };
  }
  checkCommon(ctx, record);
  if (typeof record.layer === 'string' && LAYER_VALIDATORS[record.layer]) {
    LAYER_VALIDATORS[record.layer](ctx, record);
  } else if (record.layer !== undefined) {
    ctx.add('layer', 'invalid_enum', `未知层：${String(record.layer)}`);
  }
  return { ok: ctx.errors.length === 0, errors: ctx.errors };
}

/**
 * 批量校验。
 * @param {object[]} records
 * @returns {{ok:boolean, total:number, invalidCount:number, errors:Array<{index:number, errors:object[]}>}}
 */
export function validateMany(records) {
  if (!Array.isArray(records)) {
    return { ok: false, total: 0, invalidCount: 0, errors: [{ index: -1, errors: [{ path: '', error: 'not_an_array', message: 'records 必须是数组' }] }] };
  }
  const errors = [];
  records.forEach((record, index) => {
    const result = validateArchiveRecord(record);
    if (!result.ok) errors.push({ index, errors: result.errors });
  });
  return { ok: errors.length === 0, total: records.length, invalidCount: errors.length, errors };
}

/** 便捷断言：不合法则抛出，message 汇总前 5 条错误（供服务端/前端复用）。 */
export function assertArchiveRecord(record) {
  const result = validateArchiveRecord(record);
  if (!result.ok) {
    const detail = result.errors.slice(0, 5).map((e) => `${e.path}:${e.error}`).join(', ');
    const err = new Error(`档案记录不合法（${result.errors.length} 处）：${detail}`);
    err.name = 'ArchiveSchemaError';
    err.errors = result.errors;
    throw err;
  }
  return record;
}
