/**
 * v2/app · T40 应用接回主控
 * - 画布：v2/engine（CanvasKit tile 位图层）+ v2/brushes（10 笔刷/动态/纹理）
 * - 档案：L0/L1/L2/L4/L5 + 最小 L6（复用 product/core 的 archive-schema / hash-chain / mock-ai，已注明来源）
 * - 卡住协作 mock：框选 → 观察 → 方向 → 生成 → 落新图层 → L6
 * - 证据包：JSON + PNG + manifest + SHA-256 链 + 存证模式 zero_generation
 * - 一键演示：8 步（可暂停/上一步/下一步/退出；手动操作即接管）
 * - 持久化：localStorage 档案 + 画布快照（刷新不丢）
 */
import { Engine } from '../../engine/src/engine.js';
import { BrushController, loadTextures, attachBrushInput } from '../../brushes/src/brush-controller.js';
import { SelectionManager } from '../../selection/selection.js';
import { applyIcons } from './icons.js';
import { validateArchiveRecord, SCHEMA_VERSION } from '../core/archive-schema.mjs';
import { sha256Hex, canonicalJson, GENESIS_HASH } from '../core/hash-chain.mjs';
import { mockAnalyze, mockDirections, mockGenerate } from '../core/mock-ai.mjs';
import { createProvider, loadAiConfig, AIProviderError } from '../core/ai-provider.mjs';
import { rankAssetsForQuery, rankAssetsForSelection, mergeRealAnalysis, selectAssetsForBatchRead, summarizeProvenance } from '../core/asset-ai.mjs';
import { gridLines, thirdsLines, snapPoint, mirrorStroke } from '../core/guides.mjs';
import { normalizeChatActions, validateAction, describeAction } from '../core/chat-actions.mjs';

const $ = (id) => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const iso = () => new Date().toISOString();
const fmtPct = (v) => `${Math.round(clamp(v, 0, 1) * 100)}%`;
const shortHash = (h) => (h ? String(h).slice(0, 10) + '…' : '—');
const uid = (p) => `${p}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;

const LS_RECORDS = 'mozheng.v2.records.v1';const LS_SNAPSHOT = 'mozheng.v2.snapshot.v1';
const LS_QUICKSTART = 'mozheng.quickstart.dismissed.v1';
const LS_AI_CHAT = 'mozheng.ai.chat.v1';
const LS_AI_PROFILE = 'mozheng.ai.profile.v1';
const LS_SIM_PRESSURE = 'mozheng.v2.simPressure.v2';
const LS_SIM_PRESSURE_LEGACY = 'mozheng.v2.simPressure.v1';
// 新建画布通过 URL 参数传入尺寸（?new=1&w=1600&h=1000）；默认 1200×800
const START_PARAMS = new URLSearchParams(location.search);
const START_W = clamp(parseInt(START_PARAMS.get('w'), 10) || 1200, 256, 4096);
const START_H = clamp(parseInt(START_PARAMS.get('h'), 10) || 800, 256, 4096);
const IS_NEW_DOC = START_PARAMS.get('new') === '1';
// T69 新默认（brush tau50 版本）：快笔更细、起笔/追笔更跟手；旧默认回退值见 README。
const DEFAULT_SIM_PRESSURE = { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 65, startPressure: 0.30, catchUp: true, speedTauMs: 50 };
const ROLLBACK_SIM_PRESSURE = { enabled: true, strength: 1.0, curve: 'soft', smoothingMs: 45, startPressure: 0.55, catchUp: false, speedTauMs: 0 };
function normalizeSimPressure(v) {
  const d = DEFAULT_SIM_PRESSURE;
  const n = (x, lo, hi, fb) => { const num = Number(x); return Number.isFinite(num) ? Math.max(lo, Math.min(hi, num)) : fb; };
  return {
    enabled: v && v.enabled === false ? false : true,
    strength: n(v && v.strength, 0, 2, d.strength),
    curve: v && ['linear', 'soft', 'strong'].includes(v.curve) ? v.curve : d.curve,
    smoothingMs: n(v && v.smoothingMs, 0, 300, d.smoothingMs),
    startPressure: n(v && v.startPressure, 0.05, 1, d.startPressure),
    catchUp: v && v.catchUp === true,
    speedTauMs: n(v && v.speedTauMs, 0, 600, d.speedTauMs),
  };
}
function isLegacyDefaultPressure(v) {
  if (!v) return true;
  return v.enabled !== false && Number(v.strength) === 1 && v.curve === 'soft' && Number(v.smoothingMs) === 45
    && (v.catchUp == null || v.catchUp === false) && (v.speedTauMs == null || Number(v.speedTauMs) === 0);
}
function loadSimPressure() {
  // v2 key 优先
  try {
    const raw = localStorage.getItem(LS_SIM_PRESSURE);
    if (raw) return normalizeSimPressure(JSON.parse(raw));
  } catch (e) { /* fall through */ }
  // 旧 key 迁移：旧默认升级到 T69 新默认；自定义值保留并补齐新字段
  try {
    const legacyRaw = localStorage.getItem(LS_SIM_PRESSURE_LEGACY);
    if (legacyRaw) {
      const legacy = JSON.parse(legacyRaw);
      const next = isLegacyDefaultPressure(legacy)
        ? { ...DEFAULT_SIM_PRESSURE }
        : normalizeSimPressure({ ...DEFAULT_SIM_PRESSURE, ...legacy });
      try { localStorage.setItem(LS_SIM_PRESSURE, JSON.stringify(next)); } catch (e) { /* ignore */ }
      return next;
    }
  } catch (e) { /* ignore */ }
  return { ...DEFAULT_SIM_PRESSURE };
}
function saveSimPressure() {
  try { localStorage.setItem(LS_SIM_PRESSURE, JSON.stringify(state.simPressure)); } catch (e) { /* ignore */ }
}
function simPressureSupported() {
  return !!(controller && typeof controller.setSimulatedPressure === 'function');
}
function applySimPressure() {
  if (!controller) return;
  const supported = simPressureSupported();
  if (supported) {
    try { controller.setSimulatedPressure({ ...state.simPressure }); } catch (e) { console.warn('[app] setSimulatedPressure failed', e); }
  }
  const panel = document.getElementById('simPressurePanel');
  if (panel) panel.classList.toggle('disabled', !supported);
  const hint = document.getElementById('simPressureHint');
  if (hint) {
    hint.textContent = supported
      ? '鼠标无压感，用速度模拟粗细；连接手绘板后自动用真实压感。'
      : '当前笔刷模块尚未提供模拟压感接口（等待 T54）；以下设置会保存在本地。';
  }
}
function updateSimPressureUI() {
  const v = state.simPressure;
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
  set('simPressureEnabled', v.enabled ? 'on' : '');
  const en = document.getElementById('simPressureEnabled'); if (en) en.checked = v.enabled;
  set('simPressureStrength', v.strength);
  const stv = document.getElementById('simPressureStrengthVal'); if (stv) stv.textContent = Number(v.strength).toFixed(2);
  const curve = document.getElementById('simPressureCurve'); if (curve) curve.value = v.curve;
  set('simPressureSmoothing', v.smoothingMs);
  const smv = document.getElementById('simPressureSmoothingVal'); if (smv) smv.textContent = Math.round(v.smoothingMs) + 'ms';
  applySimPressure();
}
function bindSimPressureControls() {
  const enabled = document.getElementById('simPressureEnabled');
  const strength = document.getElementById('simPressureStrength');
  const curve = document.getElementById('simPressureCurve');
  const smoothing = document.getElementById('simPressureSmoothing');
  if (!enabled) return;
  enabled.addEventListener('change', () => { state.simPressure.enabled = enabled.checked; saveSimPressure(); applySimPressure(); });
  strength.addEventListener('input', () => {
    state.simPressure.strength = Math.max(0, Math.min(2, parseFloat(strength.value) || 0));
    document.getElementById('simPressureStrengthVal').textContent = Number(state.simPressure.strength).toFixed(2);
    saveSimPressure(); applySimPressure();
  });
  curve.addEventListener('change', () => { state.simPressure.curve = curve.value; saveSimPressure(); applySimPressure(); });
  smoothing.addEventListener('input', () => {
    state.simPressure.smoothingMs = Math.max(0, Math.min(300, parseFloat(smoothing.value) || 0));
    document.getElementById('simPressureSmoothingVal').textContent = Math.round(state.simPressure.smoothingMs) + 'ms';
    saveSimPressure(); applySimPressure();
  });
}

  const DEBUG = new URLSearchParams(location.search).has('debug');
  function showFatalBar(msg) {
    const bar = document.getElementById('fatalBar');
    const txt = document.getElementById('fatalMsg');
    if (!bar || !txt) return;
    txt.textContent = ' ' + String(msg || '');
    bar.style.display = 'block';
  }
  window.addEventListener('error', (e) => showFatalBar((e && (e.message || e.error && e.error.message)) || 'window error'));
  window.addEventListener('unhandledrejection', (e) => showFatalBar(e && e.reason && (e.reason.message || e.reason) || 'unhandled rejection'));
const SESSION_ID = 'v2-' + Date.now().toString(36);
const MOCK_MODEL = 'mock-ai@0.1.0';

const state = {
  mode: 'collab',
  aiRole: 'assistant',
  sessionId: SESSION_ID,
  records: [],
  tool: 'brush',
  brushIndex: 0,
  activePresetId: null,
  color: '#232a33',
  strokes: 0,
  aiCalls: 0,
  aiBusy: false,
  aiAbort: null,
  aiSession: [],
  aiIntent: '',
  aiChat: [],
  aiChatContext: { selection: true, canvas: false, library: true, archive: true, profile: true },
  aiProfile: { style: '', avoid: '', medium: '', notes: '' },
  batchReview: null,
  annotationMode: false,
  annotationDirty: false,
  voiceRec: null,
  shapeType: 'rect',
  previewCandidateIndex: null,
  compareCandidateIndex: null,
  aiOverlayVisible: false,
  aiImageScope: 'selection',
  aiImagePrompt: '',
  aiWorkshopRefs: [],
  selection: null,
  analysis: null,
  directions: null,
  selectedDirection: null,
  candidates: null,
  generatedCandidateId: null,
  ignoreArchive: false,
  simPressure: loadSimPressure(),
  pointerdowns: 0,
  lastPointer: null,
  lastError: null,
  strokeActive: false,
  spaceDown: false,
  demo: { active: false, step: 0, paused: false, timer: null, snapshot: null, savedRecords: null, savedMode: null, historyPaused: false },
  selectionMode: 'rect', selectionBool: 'replace', feather: 0, transformActive: false,
  library: { api: null, assets: [], selectedId: null, filter: 'all', query: '', tag: null, prefs: null, thumbs: new Map(), open: false, importing: false, seeded: false, deleteConfirm: null, highlightRegion: -1, savedUi: null },
  aiReference: null,
  textLayers: new Map(),
  assetLayerRefs: new Map(),
  showGrid: false,
  showThirds: false,
  customGuides: [],
  symmetryAxis: null,
  pendingResize: null,
};

let engine = null;
let controller = null;
let presets = null;
let textures = {};
let brushDetach = null;
let maskDetach = null;
let overlayCtx = null;
let mainCanvas = null;
let overlayCanvas = null;
let selectionOverlay = null;
let transformOverlay = null;
let selectionManager = null;
let toolInputBound = false;
let saveTimer = null;
let hashTimer = null;

/* ---------------- 持久化 ---------------- */
function loadStored() {
  try {
    const raw = localStorage.getItem(LS_RECORDS);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (!data || !Array.isArray(data.records)) return null;
    state.records = data.records;
    state.mode = data.mode === 'attest' ? 'attest' : 'collab';
    state.aiRole = data.aiRole || 'assistant';
    return data;
  } catch (e) { console.warn('[app] load failed', e); return null; }
}
function loadAiMemory() {
  try {
    const rawChat = localStorage.getItem(LS_AI_CHAT);
    if (rawChat) {
      const arr = JSON.parse(rawChat);
      if (Array.isArray(arr)) state.aiChat = arr.filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string').slice(-60);
    }
    const rawProfile = localStorage.getItem(LS_AI_PROFILE);
    if (rawProfile) {
      const p = JSON.parse(rawProfile);
      if (p && typeof p === 'object') state.aiProfile = { style: String(p.style || '').slice(0, 500), avoid: String(p.avoid || '').slice(0, 500), medium: String(p.medium || '').slice(0, 200), notes: String(p.notes || '').slice(0, 800) };
    }
  } catch (e) { console.warn('[app] AI memory load failed', e); }
}
function saveAiChat() {
  try { localStorage.setItem(LS_AI_CHAT, JSON.stringify((state.aiChat || []).slice(-60))); } catch (e) { /* ignore */ }
}
function saveAiProfile() {
  try { localStorage.setItem(LS_AI_PROFILE, JSON.stringify(state.aiProfile || {})); } catch (e) { /* ignore */ }
}
function clearAiChat() {
  const btn = document.getElementById('btnAiChatClear');
  if (!state.aiClearArmed) {
    state.aiClearArmed = true;
    if (btn) btn.textContent = '再点一次确认';
    showToast('再点一次「清空对话」确认；画像不会被删除');
    setTimeout(() => { state.aiClearArmed = false; const b = document.getElementById('btnAiChatClear'); if (b) b.textContent = '清空对话'; }, 3500);
    return;
  }
  state.aiClearArmed = false;
  state.aiChat = [];
  try { localStorage.removeItem(LS_AI_CHAT); } catch (e) { /* ignore */ }
  const hs = document.getElementById('aiStatus'); if (hs) hs.textContent = '待指示';
  const hs2 = document.getElementById('statusAiState'); if (hs2) hs2.textContent = 'AI 待命';
  renderAIPanel();
  showToast('对话记忆已清空（素材/档案记忆不受影响）');
}
function clearAiMemory() {
  state.aiChat = [];
  state.aiProfile = { style: '', avoid: '', medium: '', notes: '' };
  try { localStorage.removeItem(LS_AI_CHAT); localStorage.removeItem(LS_AI_PROFILE); } catch (e) { /* ignore */ }
  renderAIPanel();
  showToast('AI 对话与画像记忆已清空；素材档案与证据记录保留');
}
function saveNow() {
  try {
    localStorage.setItem(LS_RECORDS, JSON.stringify({ records: state.records, mode: state.mode, aiRole: state.aiRole, savedAt: iso() }));
    const ss = $('saveState');
    if (ss) ss.title = '已保存 · ' + new Date().toLocaleTimeString('zh-CN', { hour12: false });
  } catch (e) { console.warn('[app] save failed', e); }
}
function scheduleSave() { clearTimeout(saveTimer); saveTimer = setTimeout(saveNow, 350); scheduleProjectAutosave(); }

async function saveSnapshot() {
  if (!engine || !engine.ready) return;
  try {
    engine.compositor.compositeAll(engine.store);
    const url = await engine.getCompositeDataUrl();
    try { localStorage.setItem(LS_SNAPSHOT, url); } catch (e) { /* 容量满则忽略快照 */ }
  } catch (e) { /* ignore */ }
}

/* ---------------- 档案记录 ---------------- */
function baseRecord(layer, extra) {
  return {
    id: extra.id || uid(layer),
    asset_id: 'asset-mist-valley-v2',
    layer,
    anchor: { type: 'whole', value: null },
    source: 'inferred',
    author: 'ai',
    mode: state.mode,
    ai_role: state.aiRole,
    created_at: iso(),
    schema_version: '0.2.0',
    ...extra,
  };
}
function addRecord(record) {
  const v = validateArchiveRecord(record);
  if (!v.ok) {
    console.warn('[archive] invalid record', record.layer, v.errors.slice(0, 4));
    showToast('档案记录校验失败：' + (v.errors[0]?.message || 'unknown'), true);
    return false;
  }
  state.records.push(record);
  scheduleSave();
  renderArchiveCount();
  scheduleHashUpdate();
  return true;
}
function ensureL0() {
  if (state.records.some((r) => r.layer === 'L0')) return;
  const rec = baseRecord('L0', {
    source: 'observed', author: 'user', ai_role: null,
    anchor: { type: 'whole', value: null },
    file_path: 'live://v2/canvas',
    sha256: '',
    format: 'png', width: engine ? engine.width : 1200, height: engine ? engine.height : 800, color_space: 'sRGB',
    imported_at: iso(),
    consent: { allow_training: false, allow_ai_processing: true, allow_display: true },
  });
  sha256Hex(`v2-canvas-${Date.now()}`).then((h) => { rec.sha256 = h; addRecord(rec); });
}

/* ---------------- 画布 / 引擎 ---------------- */
function presentPolicyForSize(w = engine ? engine.width : 1200, h = engine ? engine.height : 800) {
  const area = Math.max(1, Number(w) || 0) * Math.max(1, Number(h) || 0);
  const large = area > 2048 * 2048;
  return { area, width: w, height: h, strategy: large ? 'full' : 'dirty', retained: !large, limit: 2048 * 2048 };
}
function refreshPresentStatusUI() {
  const el = document.getElementById('aboutPresent');
  if (!el || !engine) return;
  const p = presentPolicyForSize(engine.width, engine.height);
  const cur = typeof engine.getPresentStrategy === 'function' ? engine.getPresentStrategy() : p.strategy;
  el.textContent = cur + (p.retained ? ' · 保留帧' : ' · 全帧') + ' · ' + engine.width + '×' + engine.height;
  el.title = '≤2048² 默认 dirty（低延迟、少量内存）；>2048² 自动 full 以控制内存；可设 engine.setPresentStrategy("full") 回退';
}
function applyPresentStrategyForSize(w = engine ? engine.width : 1200, h = engine ? engine.height : 800) {
  const p = presentPolicyForSize(w, h);
  if (!engine || typeof engine.setPresentStrategy !== 'function') { refreshPresentStatusUI(); return p; }
  try { engine.setPresentStrategy(p.strategy); } catch (e) { console.warn('[app] setPresentStrategy failed', e); }
  try { if (typeof engine.setPresentRetained === 'function') engine.setPresentRetained(p.retained); } catch (e) { console.warn('[app] setPresentRetained failed', e); }
  try { engine.presentFull(); } catch (e) { /* ignore */ }
  refreshPresentStatusUI();
  return { ...p, current: typeof engine.getPresentStrategy === 'function' ? engine.getPresentStrategy() : p.strategy, retainedNow: !!engine.presentSurface };
}
function applyDocCanvasSizeUI() {
  if (!engine) return;
  const w = engine.width, h = engine.height;
  for (const id of ['overlayCanvas', 'transformOverlay', 'selectionOverlay', 'annotationCanvas', 'candidatePreviewCanvas', 'aiSuggestionCanvas', 'brushCursorCanvas', 'guideCanvas']) {
    const c = document.getElementById(id);
    if (!c) continue;
    if (id !== 'selectionOverlay') { c.width = w; c.height = h; }
    c.style.width = w + 'px'; c.style.height = h + 'px';
  }
  const ds = document.getElementById('docSize'); if (ds) ds.textContent = w + ' × ' + h;
  document.title = '墨证 InkProof v2 · ' + w + '×' + h;
}
/* ---------------- 画布标注（给 AI 的第二种语言） ---------------- */
let annotationCtx = null;
let annotationLastPoint = null;
let textComposerEl = null;
let textInputDetach = null;
function closeTextComposer() {
  if (textComposerEl) { try { textComposerEl.remove(); } catch (e) { /* ignore */ } textComposerEl = null; }
}
function attachTextInput() {
  if (textInputDetach) return;
  const cv = document.getElementById('mainCanvas');
  if (!cv) return;
  const onDown = (e) => {
    if (state.tool !== 'text' || state.demo.active) return;
    e.preventDefault(); e.stopPropagation();
    openTextComposer(e);
  };
  cv.addEventListener('pointerdown', onDown, { capture: true });
  textInputDetach = () => { cv.removeEventListener('pointerdown', onDown, { capture: true }); textInputDetach = null; };
}
function openTextComposer(e, opts = {}) {
  closeTextComposer();
  const p = opts.docPoint || canvasPoint(e);
  const wrap = document.getElementById('canvasWrap');
  const rect = wrap ? wrap.getBoundingClientRect() : { left: 0, top: 0 };
  const mainRect = mainCanvas ? mainCanvas.getBoundingClientRect() : null;
  let left = e ? e.clientX - rect.left : 80;
  let top = e ? e.clientY - rect.top + 10 : 80;
  if (!e && mainRect) {
    left = mainRect.left - rect.left + (p.x / Math.max(1, engine.width)) * mainRect.width;
    top = mainRect.top - rect.top + (p.y / Math.max(1, engine.height)) * mainRect.height + 10;
  }
  const color = opts.color || state.color;
  const el = document.createElement('div');
  el.className = 'text-composer';
  el.style.left = clamp(left, 80, Math.max(80, (rect.width || 500) - 80)) + 'px';
  el.style.top = clamp(top, 40, Math.max(40, (rect.height || 300) - 80)) + 'px';
  el.innerHTML = '<div class="tc-row"><label>字号 <input id="tcSize" type="number" min="8" max="400" step="1" value="' + (opts.fontSize || 48) + '" style="width:54px"></label><span class="tc-color" style="background:' + escapeHtml(color) + '"></span><span class="hint">' + (opts.layerId ? '编辑文字图层' : '颜色随当前色') + '</span></div>' +
    '<textarea id="tcText" rows="2" placeholder="输入文字…（Ctrl+Enter 提交）">' + escapeHtml(opts.text || '') + '</textarea>' +
    '<div class="tc-foot"><button class="btn tiny" id="tcCancel">取消</button><button class="btn tiny primary" id="tcOk">' + (opts.layerId ? '更新' : '提交') + '</button></div>';
  wrap.appendChild(el);
  textComposerEl = el;
  const ta = el.querySelector('#tcText');
  const size = el.querySelector('#tcSize');
  setTimeout(() => { try { ta.focus(); ta.select(); } catch (err) {} }, 20);
  const cancel = () => closeTextComposer();
  const commit = async () => {
    const text = (ta.value || '').trim();
    if (!text) { closeTextComposer(); return; }
    const fontSize = clamp(parseInt(size.value, 10) || 48, 8, 400);
    closeTextComposer();
    try {
      const lines = text.split(/\r?\n/);
      const pad = Math.round(fontSize * 0.35);
      const font = '600 ' + fontSize + 'px "Microsoft YaHei", "Segoe UI", sans-serif';
      const c = document.createElement('canvas');
      const g0 = c.getContext('2d');
      g0.font = font;
      let maxW = 0;
      for (const ln of lines) maxW = Math.max(maxW, g0.measureText(ln || ' ').width);
      c.width = Math.max(1, Math.ceil(maxW + pad * 2));
      c.height = Math.max(1, Math.ceil(lines.length * fontSize * 1.25 + pad * 2));
      const g = c.getContext('2d');
      g.clearRect(0, 0, c.width, c.height);
      g.font = font; g.fillStyle = color; g.textBaseline = 'top';
      lines.forEach((ln, i) => { g.fillText(ln, pad, pad + i * fontSize * 1.25); });
      if (opts.layerId) {
        const meta = state.textLayers.get(opts.layerId) || {};
        const x = clamp(Math.round(Number(meta.x) || p.x), 0, Math.max(0, engine.width - c.width));
        const y = clamp(Math.round(Number(meta.y) || p.y), 0, Math.max(0, engine.height - c.height));
        const full = document.createElement('canvas');
        full.width = engine.width; full.height = engine.height;
        full.getContext('2d').drawImage(c, x, y);
        const ok = await engine.replaceLayerFromDataUrlWithInfo(opts.layerId, full.toDataURL('image/png'), { kind: 'text', text: { content: text, fontSize, color, fontFamily: 'Microsoft YaHei', x, y, width: c.width, height: c.height } });
        if (!ok) throw new Error('文字图层替换失败');
        const textInfo = { layerId: opts.layerId, text, content: text, fontSize, color, fontFamily: 'Microsoft YaHei', x, y, width: c.width, height: c.height, updatedAt: iso() };
        state.textLayers.set(opts.layerId, textInfo);
        addRecord(baseRecord('L6', { kind: 'text_edited', anchor: { type: 'bbox', value: [x, y, c.width, c.height] }, model: { provider: 'mock', model: MOCK_MODEL }, params: { text: text.slice(0, 200), font_size: fontSize, color, layer_id: opts.layerId }, input_refs: [], assertions: [{ type: 'user_operation', value: true }], ai_role: null, source: 'observed', author: 'user', note: '文字图层二次编辑' }));
        renderAll(); renderLayers(); scheduleProjectAutosave();
        showToast('文字图层已更新：' + text.slice(0, 20));
      } else {
        const url = c.toDataURL('image/png');
        const x = clamp(Math.round(p.x), 0, Math.max(0, engine.width - c.width));
        const y = clamp(Math.round(p.y), 0, Math.max(0, engine.height - c.height));
        const layer = await importImageAsLayer(url, '文字 · ' + (lines[0] || '文本').slice(0, 14), { x, y, width: c.width, height: c.height });
        const textInfo = { layerId: layer.id, text, content: text, fontSize, color, fontFamily: 'Microsoft YaHei', x, y, width: c.width, height: c.height, updatedAt: iso() };
        state.textLayers.set(layer.id, textInfo);
        engine.setLayerInfo(layer.id, { kind: 'text', text: textInfo });
        addRecord(baseRecord('L6', { kind: 'text_inserted', anchor: { type: 'bbox', value: [x, y, c.width, c.height] }, model: { provider: 'mock', model: MOCK_MODEL }, params: { text: text.slice(0, 200), font_size: fontSize, color }, input_refs: [], assertions: [{ type: 'user_operation', value: true }], ai_role: null, source: 'observed', author: 'user', note: '文字图层' }));
        renderAll(); scheduleProjectAutosave();
        showToast('已插入文字图层：' + text.slice(0, 20));
      }
    } catch (err) { console.error(err); showToast('文字插入失败：' + (err.message || err), true); }
  };
  el.querySelector('#tcCancel').addEventListener('click', cancel);
  el.querySelector('#tcOk').addEventListener('click', () => commit());
  ta.addEventListener('keydown', (ev) => {
    ev.stopPropagation();
    if (ev.key === 'Escape') { ev.preventDefault(); cancel(); }
    else if (ev.key === 'Enter' && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); commit(); }
  });
}
/* ---------------- 形状工具 ---------------- */
let shapeDetach = null;
let shapeDrag = null;
function drawShapePreview(a, b) {
  if (!overlayCtx) return;
  drawSelection();
  const ctx = overlayCtx;
  const type = state.shapeType;
  const x = Math.min(a.x, b.x), y = Math.min(a.y, b.y);
  const w = Math.abs(a.x - b.x), h = Math.abs(a.y - b.y);
  ctx.save();
  ctx.strokeStyle = state.color; ctx.lineWidth = 2; ctx.setLineDash([6, 4]);
  if (type === 'line') { ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
  else if (type === 'ellipse') { ctx.beginPath(); ctx.ellipse(x + w / 2, y + h / 2, Math.max(0.5, w / 2), Math.max(0.5, h / 2), 0, 0, Math.PI * 2); ctx.stroke(); }
  else ctx.strokeRect(x + 0.5, y + 0.5, w, h);
  ctx.restore();
}
function attachShapeInput() {
  if (shapeDetach) return;
  const cv = document.getElementById('mainCanvas');
  if (!cv) return;
  const onDown = (e) => {
    if (state.tool !== 'shape' || state.demo.active) return;
    e.preventDefault(); e.stopPropagation();
    const p = snapDocPoint(canvasPoint(e));
    shapeDrag = { start: p, current: p, pointerId: e.pointerId };
    cv.setPointerCapture && cv.setPointerCapture(e.pointerId);
    drawShapePreview(p, p);
  };
  const onMove = (e) => {
    if (!shapeDrag) return;
    e.preventDefault(); e.stopPropagation();
    shapeDrag.current = snapDocPoint(canvasPoint(e));
    drawShapePreview(shapeDrag.start, shapeDrag.current);
  };
  const onUp = async (e) => {
    if (!shapeDrag) return;
    e.preventDefault(); e.stopPropagation();
    const end = snapDocPoint(canvasPoint(e));
    const start = shapeDrag.start;
    shapeDrag = null;
    try { drawSelection(); } catch (err) { /* ignore */ }
    const x = Math.min(start.x, end.x), y = Math.min(start.y, end.y);
    const w = Math.abs(end.x - start.x), h = Math.abs(end.y - start.y);
    if (w < 3 && h < 3) return;
    try {
      const ops = await import('../core/editor-ops.mjs');
      const type = state.shapeType;
      const shape = type === 'line' ? { type: 'line', x1: start.x, y1: start.y, x2: end.x, y2: end.y } : { type, x, y, width: w, height: h };
      const opts = type === 'line'
        ? { fill: 'none', stroke: state.color, strokeWidth: Math.max(2, 6), padding: 3 }
        : { fill: state.color, stroke: 'none', strokeWidth: 0, padding: 0 };
      const r = await ops.rasterizeShapeToDataUrl(shape, opts);
      const plan = r.plan || {};
      const px = Math.round((plan.bounds ? plan.bounds.x : x) - (plan.padding || 0) - (plan.strokeWidth || 0) / 2);
      const py = Math.round((plan.bounds ? plan.bounds.y : y) - (plan.padding || 0) - (plan.strokeWidth || 0) / 2);
      const layer = await importImageAsLayer(r.dataUrl, '形状 · ' + ({ rect: '矩形', ellipse: '椭圆', line: '直线' }[type]), { x: px, y: py, width: r.width, height: r.height });
      const sx = Math.round(x), sy = Math.round(y), sw = Math.round(w), sh = Math.round(h);
      addRecord(baseRecord('L6', { kind: 'shape_inserted', anchor: { type: 'bbox', value: [sx, sy, sw, sh] }, model: { provider: 'mock', model: MOCK_MODEL }, params: { shape: type, color: state.color, x: sx, y: sy, width: sw, height: sh, layer_x: px, layer_y: py, layer_width: r.width, layer_height: r.height }, input_refs: [], assertions: [{ type: 'user_operation', value: true }], ai_role: null, source: 'observed', author: 'user', note: '形状图层' }));
      renderAll(); scheduleProjectAutosave();
      showToast('已插入形状图层：' + (layer.name || ''));
    } catch (err) { console.error(err); showToast('形状绘制失败：' + (err.message || err), true); }
  };
  cv.addEventListener('pointerdown', onDown);
  cv.addEventListener('pointermove', onMove);
  cv.addEventListener('pointerup', onUp);
  cv.addEventListener('pointercancel', () => { shapeDrag = null; });
  shapeDetach = () => {
    cv.removeEventListener('pointerdown', onDown);
    cv.removeEventListener('pointermove', onMove);
    cv.removeEventListener('pointerup', onUp);
    shapeDetach = null;
  };
}
function snapDocPoint(p) {
  if (!state.showGrid && !state.showThirds && !(state.customGuides || []).length) return p;
  try {
    const guides = [];
    if (state.showGrid) {
      const g = gridLines(engine.width, engine.height, { spacing: 80, majorEvery: 4 });
      guides.push(...g.vertical.map((v) => ({ axis: 'x', value: v.value })), ...g.horizontal.map((v) => ({ axis: 'y', value: v.value })));
    }
    if (state.showThirds) {
      const t = thirdsLines(engine.width, engine.height);
      guides.push(...t.vertical.map((v) => ({ axis: 'x', value: v })), ...t.horizontal.map((v) => ({ axis: 'y', value: v })));
    }
    for (const g of (state.customGuides || [])) guides.push({ axis: g.axis, value: g.value });
    const s = snapPoint(p, { guides, threshold: 6, width: engine.width, height: engine.height });
    return { x: s.x, y: s.y };
  } catch (e) { return p; }
}
/* ---------------- 对称绘制（在原始笔迹结束后重放镜像笔迹） ---------------- */
let symmetryBound = false;
let symmetryPoints = null;
function initSymmetryInput() {
  if (symmetryBound) return;
  const cv = document.getElementById('mainCanvas');
  if (!cv) return;
  const canDraw = () => ['brush', 'eraser', 'smudge'].includes(state.tool) && !state.annotationMode && !state.transformActive && !state.demo.active;
  const down = (e) => {
    if (!canDraw() || !state.symmetryAxis || (e.button != null && e.button !== 0)) return;
    symmetryPoints = [{ x: canvasPoint(e).x, y: canvasPoint(e).y, pressure: e.pressure || 0.5, timestamp: performance.now() }];
  };
  const move = (e) => {
    if (!symmetryPoints) return;
    const p = canvasPoint(e);
    symmetryPoints.push({ x: p.x, y: p.y, pressure: e.pressure || 0.5, timestamp: performance.now() });
  };
  const up = () => {
    if (!symmetryPoints) return;
    const pts = symmetryPoints;
    symmetryPoints = null;
    if (!state.symmetryAxis || pts.length === 0) return;
    // 等原始笔迹 pointerup 提交后再重放镜像，避免与 BrushController 当前笔冲突
    setTimeout(async () => {
      try {
        const strokes = mirrorStroke(pts, { axis: state.symmetryAxis, width: engine.width, height: engine.height });
        for (const stroke of strokes) {
          if (!stroke.length) continue;
          controller.begin(stroke[0]);
          for (let i = 1; i < stroke.length; i += 1) controller.append(stroke[i]);
          controller.end();
        }
        try { engine.mergeLastPaintEntries(strokes.length + 1); } catch (e) { console.warn('[symmetry] merge undo failed', e); }
        renderAll();
        showToast('对称笔迹已镜像（' + ({ x: '左右', y: '上下', both: '中心' }[state.symmetryAxis]) + '）');
      } catch (e) { console.error(e); }
    }, 0);
  };
  const cancel = () => { symmetryPoints = null; };
  cv.addEventListener('pointerdown', down);
  cv.addEventListener('pointermove', move);
  cv.addEventListener('pointerup', up);
  cv.addEventListener('pointercancel', cancel);
  symmetryBound = true;
}
/* ---------------- 笔刷光标轮廓 ---------------- */
let brushCursorBound = false;
function clearBrushCursor() {
  const c = document.getElementById('brushCursorCanvas');
  if (!c) return;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
}
function renderBrushCursor(e) {
  const c = document.getElementById('brushCursorCanvas');
  if (!c || !state.tool || !['brush', 'eraser', 'smudge'].includes(state.tool)) { clearBrushCursor(); return; }
  if (state.annotationMode || state.transformActive) { clearBrushCursor(); return; }
  const p = canvasPoint(e);
  const range = document.getElementById('leftSizeRange');
  const size = clamp(Number(range && range.value) || 18, 1, 256);
  const r = Math.max(2, size / 2);
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  ctx.save();
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = 'rgba(255,255,255,.88)';
  ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.stroke();
  ctx.lineWidth = 1;
  ctx.strokeStyle = 'rgba(20,28,38,.72)';
  ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(1, r - 1.6), 0, Math.PI * 2); ctx.stroke();
  if (r > 5) { ctx.fillStyle = state.color; ctx.globalAlpha = 0.75; ctx.beginPath(); ctx.arc(p.x, p.y, 1.6, 0, Math.PI * 2); ctx.fill(); }
  ctx.restore();
}
function initBrushCursor() {
  if (brushCursorBound) return;
  const cv = document.getElementById('mainCanvas');
  if (!cv) return;
  cv.addEventListener('pointermove', renderBrushCursor);
  cv.addEventListener('pointerleave', clearBrushCursor);
  brushCursorBound = true;
}
function initAnnotationCanvas() {
  const c = document.getElementById('annotationCanvas');
  if (!c) return;
  annotationCtx = c.getContext('2d');
  const point = (e) => { const r = c.getBoundingClientRect(); return { x: clamp((e.clientX - r.left) * c.width / Math.max(1, r.width), 0, c.width), y: clamp((e.clientY - r.top) * c.height / Math.max(1, r.height), 0, c.height) }; };
  c.addEventListener('pointerdown', (e) => {
    if (!state.annotationMode) return;
    e.preventDefault(); e.stopPropagation();
    annotationLastPoint = point(e);
    c.setPointerCapture && c.setPointerCapture(e.pointerId);
    annotationCtx.strokeStyle = '#ef4444'; annotationCtx.fillStyle = '#ef4444'; annotationCtx.lineWidth = 5; annotationCtx.lineCap = 'round'; annotationCtx.lineJoin = 'round';
    annotationCtx.beginPath(); annotationCtx.arc(annotationLastPoint.x, annotationLastPoint.y, 2.5, 0, Math.PI * 2); annotationCtx.fill();
    state.annotationDirty = true;
  });
  c.addEventListener('pointermove', (e) => {
    if (!state.annotationMode || !annotationLastPoint) return;
    e.preventDefault(); e.stopPropagation();
    const p = point(e);
    annotationCtx.beginPath(); annotationCtx.moveTo(annotationLastPoint.x, annotationLastPoint.y); annotationCtx.lineTo(p.x, p.y); annotationCtx.stroke();
    annotationLastPoint = p;
  });
  const end = () => { annotationLastPoint = null; };
  c.addEventListener('pointerup', end); c.addEventListener('pointercancel', end); c.addEventListener('pointerleave', end);
  const done = document.getElementById('btnAnnotationDone'); if (done) done.addEventListener('click', () => toggleAnnotationMode(false));
  const clr = document.getElementById('btnAnnotationClearBar'); if (clr) clr.addEventListener('click', () => { clearAnnotationInk(); });
}
function annotationInk() {
  const c = document.getElementById('annotationCanvas');
  if (!c || !state.annotationDirty) return false;
  try { const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; for (let i = 3; i < d.length; i += 4) { if (d[i] > 8) return true; } } catch (e) { return !!state.annotationDirty; }
  return false;
}
function toggleAnnotationMode(force) {
  state.annotationMode = force == null ? !state.annotationMode : !!force;
  clearBrushCursor();
  const c = document.getElementById('annotationCanvas');
  if (c) c.classList.toggle('active', state.annotationMode);
  const bar = document.getElementById('annotationBar');
  if (bar) bar.hidden = !state.annotationMode;
  const btn = document.getElementById('btnAnnotateToggle');
  if (btn) { btn.classList.toggle('primary', state.annotationMode); btn.textContent = state.annotationMode ? '✅ 完成标注' : '✏️ 在画布上标注'; }
  if (state.annotationMode) {
    showToast('标注模式：直接在画布上圈/画箭头给 AI 看；点顶部「完成」或 Esc 退出');
  } else if (annotationInk()) {
    showToast('已保留标注，会随下次图片一起发送给 AI');
  }
}
function clearAnnotationInk() {
  const c = document.getElementById('annotationCanvas');
  if (c) c.getContext('2d').clearRect(0, 0, c.width, c.height);
  state.annotationDirty = false;
  showToast('标注已清空');
}
async function initEngine() {
  mainCanvas = $('mainCanvas');
  overlayCanvas = $('overlayCanvas');
  overlayCtx = overlayCanvas.getContext('2d');
  for (const c of [mainCanvas, overlayCanvas, $('selectionOverlay'), $('transformOverlay'), $('annotationCanvas'), $('candidatePreviewCanvas'), $('aiSuggestionCanvas'), $('brushCursorCanvas'), $('guideCanvas')]) { if (c) { c.width = START_W; c.height = START_H; } }
  if (IS_NEW_DOC) {
    try { localStorage.removeItem(LS_RECORDS); localStorage.removeItem(LS_SNAPSHOT); } catch (e) { /* ignore */ }
    try { await idbDelete('current'); } catch (e) { /* ignore */ }
    state.records = [];
    try { history.replaceState(null, '', location.pathname); } catch (e) { /* ignore */ }
  }
  engine = new Engine({ canvas: mainCanvas, width: START_W, height: START_H, layers: 2, loaderBase: new URL('../../engine/vendor/', import.meta.url).href });
  await engine.init();
  presets = await (await fetch(new URL('../../brushes/presets/defaults.json', import.meta.url))).json();
  const manifest = await (await fetch(new URL('../../brushes/textures/manifest.json', import.meta.url))).json();
  textures = await loadTextures(engine.CK, manifest, new URL('../../brushes/textures/', import.meta.url).href);
  controller = new BrushController(engine, presets.brushes[state.brushIndex], { textures, color: hexToRgb(state.color) });
  state.activePresetId = presets.brushes[state.brushIndex].id;
  applySimPressure();
  window.__V2__ = engine;
  selectionOverlay = $('selectionOverlay');
  transformOverlay = $('transformOverlay');
  if (selectionOverlay) {
    selectionManager = new SelectionManager({ width: engine.width, height: engine.height, overlayCanvas: selectionOverlay, layerSystem: engine });
  }
  applyDocCanvasSizeUI();
  initAnnotationCanvas();
  initBrushCursor();
  initSymmetryInput();
  window.__V2_APP__ = { engine, get controller() { return controller; }, state, records: () => state.records };
  fitView();
  if (!IS_NEW_DOC) await restoreProject();
  else { state.selection = null; state.analysis = null; state.directions = null; state.candidates = null; drawSelection(); }
  applyPresentStrategyForSize(engine.width, engine.height);
  setTool('brush');
  ensureL0();
  if (state.mode === 'attest') applyAttestUI(true);
}

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '#232a33');
  if (!m) return { r: 35, g: 42, b: 51 };
  const n = parseInt(m[1], 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function fitView() {
  if (!engine) return;
  const wrap = $('canvasWrap');
  const availW = Math.max(240, wrap.clientWidth - 2);
  const availH = Math.max(200, wrap.clientHeight - 2);
  const scale = Math.min(availW / engine.width, availH / engine.height);
  const w = Math.round(engine.width * scale) + 'px';
  const h = Math.round(engine.height * scale) + 'px';
  // T120 修复：brushCursorCanvas/guideCanvas 此前漏缩放——主画布适配为 987×658 时它们仍是 1200×800，
  // 导致笔刷圆圈偏离鼠标（离中心越远偏越多、zoom 越大越严重）。必须与主画布同一 CSS 尺寸。
  for (const c of [mainCanvas, overlayCanvas, selectionOverlay, transformOverlay, document.getElementById('annotationCanvas'), document.getElementById('candidatePreviewCanvas'), document.getElementById('aiSuggestionCanvas'), document.getElementById('brushCursorCanvas'), document.getElementById('guideCanvas')]) { if (c) { c.style.width = w; c.style.height = h; } }
  view.baseScale = scale;
  const zoomEl = $('statusZoom');
  if (zoomEl) zoomEl.textContent = Math.round(scale * 100) + '%';
  applyView();
}

async function getCanvasDataUrl() {
  engine.compositor.compositeAll(engine.store);
  return engine.getCompositeDataUrl();
}

function clearAllTiles() {
  const store = engine.store;
  for (const [layerId, map] of store.layers.entries()) {
    for (const tile of map.values()) { try { tile.image.delete(); } catch (e) {} try { tile.surface.delete(); } catch (e) {} }
    map.clear();
    void layerId;
  }
  store.layers.clear();
}

function syncTextLayersFromEngine() {
  state.textLayers.clear();
  for (const l of engine.getLayers()) {
    const m = l.text || (l.meta && l.meta.text);
    const content = m && (m.content || m.text);
    if (content) state.textLayers.set(l.id, { ...m, layerId: l.id, text: content, content });
  }
}
async function wipeCanvas() {
  clearAllTiles();
  engine.layers.length = 0;
  state.textLayers.clear();
  const layer = engine.addLayer({ name: '图层 1' });
  engine.activeLayerId = layer.id;
  engine.compositor.setLayers(engine.layers);
  engine.compositor.compositeAll(engine.store);
  state.selection = null;
  state.analysis = null; state.directions = null; state.candidates = null;
  drawSelection();
  renderAll();
  setTimeout(maybeShowQuickStart, 400);
}

/* ---------------- 首次空画布 quick-start ---------------- */
function quickStartBlank() {
  try {
    return (engine.getLayers() || []).every((l) => {
      const b = engine.getLayerContentBounds(l.id);
      return !b || !(b.width > 1) || !(b.height > 1);
    });
  } catch (e) { return true; }
}
function hideQuickStart(dismiss = false) {
  const el = document.getElementById('quickStart');
  if (el) el.hidden = true;
  if (dismiss) { try { localStorage.setItem(LS_QUICKSTART, '1'); } catch (e) { /* ignore */ } }
}
function maybeShowQuickStart() {
  const el = document.getElementById('quickStart');
  if (!el) return;
  let dismissed = false;
  try { dismissed = localStorage.getItem(LS_QUICKSTART) === '1'; } catch (e) { /* ignore */ }
  if (dismissed || state.demo.active || ROADSHOW.active || !quickStartBlank()) { hideQuickStart(false); return; }
  el.hidden = false;
}
function bindQuickStart() {
  const el = document.getElementById('quickStart');
  if (!el || el.dataset.bound === '1') return;
  el.dataset.bound = '1';
  el.querySelector('#qsClose').addEventListener('click', () => hideQuickStart(true));
  el.querySelectorAll('[data-qs]').forEach((b) => b.addEventListener('click', () => {
    const action = b.dataset.qs;
    hideQuickStart(true);
    if (action === 'draw') { setTool('brush'); showToast('画一笔开始；之后框选一块，让 AI 只改这里'); }
    else if (action === 'example') { const btn = document.getElementById('btnLoadExample'); if (btn) btn.click(); }
    else if (action === 'import') { const btn = document.getElementById('btnImportImage'); if (btn) btn.click(); }
    else if (action === 'ai') { setTool('select'); showToast('先框选一块，再点选区旁「✨ AI 看这里」'); }
  }));
  const main = document.getElementById('mainCanvas');
  if (main) main.addEventListener('pointerdown', () => { if (!el.hidden) hideQuickStart(false); }, true);
}

async function rasterizeToPng(dataUrl, width, height) {
  const img = new Image();
  img.src = dataUrl;
  await img.decode();
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(width));
  c.height = Math.max(1, Math.round(height));
  const ctx = c.getContext('2d');
  ctx.drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL('image/png');
}

/** 把一张 PNG/SVG dataURL 画进指定图层的指定区域（app 级图片导入/快照恢复） */
async function importImageAsLayer(dataUrl, name, opts = {}) {
  const targetW = opts.width || engine.width;
  const targetH = opts.height || engine.height;
  // 统一缩放到目标框：即使源是 PNG 也要缩放，否则会按原始像素溢出到整块 tile，页面/变换框都会变大
  const png = await rasterizeToPng(dataUrl, targetW, targetH);
  const b64 = png.split(',')[1];
  const bytes = Uint8Array.from(atob(b64), (ch) => ch.charCodeAt(0));
  const img = engine.CK.MakeImageFromEncoded(bytes);
  if (!img) throw new Error('图片解码失败');
  const layer = engine.addLayer({ name });
  engine.activeLayerId = layer.id;
  const x = opts.x || 0, y = opts.y || 0;
  const store = engine.store;
  const tileSize = store.tileSize;
  const tx0 = Math.floor(x / tileSize), ty0 = Math.floor(y / tileSize);
  const tx1 = Math.min(store.tilesW - 1, Math.floor((x + targetW - 1) / tileSize));
  const ty1 = Math.min(store.tilesH - 1, Math.floor((y + targetH - 1) / tileSize));
  for (let ty = ty0; ty <= ty1; ty += 1) {
    for (let tx = tx0; tx <= tx1; tx += 1) {
      const key = `${tx},${ty}`;
      store.ensureTile(layer.id, key);
      const c = store.get(layer.id, key).surface.getCanvas();
      c.save();
      c.clipRect([0, 0, tileSize, tileSize], engine.CK.ClipOp.Intersect, false);
      c.drawImage(img, x - tx * tileSize, y - ty * tileSize);
      c.restore();
      store.get(layer.id, key).surface.flush();
      store.refreshImage(layer.id, key);
    }
  }
  try { img.delete(); } catch (e) { /* ignore */ }
  engine.compositor.setLayers(engine.layers);
  engine.compositor.compositeAll(store);
  // T117 P1-4：addLayer 的结构快照拍在像素写入之前，redo 会恢复到空 raster 层。
  // 像素写完后刷新栈顶结构快照，使 redo 能完整恢复内容。
  try { engine.refreshTrailingStructureSnapshot(); } catch (e) { /* ignore */ }
  renderAll();
  return layer;
}

async function restoreSnapshot() {
  const snap = localStorage.getItem(LS_SNAPSHOT);
  if (!snap) return;
  try { await importImageAsLayer(snap, '恢复快照 · 上次会话'); } catch (e) { console.warn('[app] restore snapshot failed', e); }
}

/** 新插入的图片图层：选中并进入贴合内容的手柄变换 */
function enterImageTransformUI(layer, x, y, w, h) {
  if (!layer || state.demo.active) return;
  engine.setActiveLayer(layer.id);
  state.selection = { x: Math.round(x), y: Math.round(y), width: Math.round(w), height: Math.round(h) };
  try { drawSelection(); } catch (e) { /* overlay optional */ }
  setTool('transform');
}
function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result || ''));
    r.onerror = () => reject(r.error || new Error('读取文件失败'));
    r.readAsDataURL(file);
  });
}
async function importImageFileToCanvas(file) {
  if (!file) return null;
  if (!/^image\/(png|jpeg|webp)$/i.test(file.type || '')) { showToast('请选择 PNG / JPG / WebP 图片', true); return null; }
  try {
    const dataUrl = await fileToDataUrl(file);
    const img = new Image(); img.src = dataUrl; await img.decode();
    const maxW = engine.width * 0.6, maxH = engine.height * 0.6;
    const sc = Math.min(maxW / img.width, maxH / img.height);
    const w = Math.max(1, Math.round(img.width * sc)), h = Math.max(1, Math.round(img.height * sc));
    const x = Math.round((engine.width - w) / 2), y = Math.round((engine.height - h) / 2);
    const layer = await importImageAsLayer(dataUrl, '图片 · ' + (file.name || 'image').replace(/\.[^.]+$/, ''), { x, y, width: w, height: h });
    renderAll();
    enterImageTransformUI(layer, x, y, w, h);
    scheduleProjectAutosave();
    showToast('图片已插入为图层并进入变换：拖手柄缩放/旋转，Enter 提交；H / 空格拖动画布');
    return layer;
  } catch (e) { console.error(e); showToast('图片导入失败：' + (e.message || e), true); return null; }
}
/* ---------------- 选区像素复制 / 剪切 / 粘贴 ---------------- */
const pixelClipboard = { dataUrl: null, width: 0, height: 0, x: 0, y: 0, label: '' };
async function copySelectionPixels(cut = false) {
  const b = state.selection;
  if (!b || b.width < 1 || b.height < 1) { showToast('先框选一块区域再复制', true); return false; }
  const l = activeLayer();
  if (!l) { showToast('没有可复制内容的图层', true); return false; }
  try {
    const url = await engine.getLayerDataUrl(l.id);
    const img = new Image(); img.src = url; await img.decode();
    const cw = Math.max(1, Math.round(b.width)), ch = Math.max(1, Math.round(b.height));
    const c = document.createElement('canvas'); c.width = cw; c.height = ch;
    const ctx = c.getContext('2d');
    ctx.drawImage(img, Math.round(b.x), Math.round(b.y), cw, ch, 0, 0, cw, ch);
    pixelClipboard.dataUrl = c.toDataURL('image/png');
    pixelClipboard.width = cw; pixelClipboard.height = ch;
    pixelClipboard.x = Math.round(b.x); pixelClipboard.y = Math.round(b.y);
    pixelClipboard.label = (l.name || '图层') + ' 选区';
    if (cut) {
      if (typeof engine.eraseRect !== 'function') throw new Error('当前引擎不支持剪切');
      engine.eraseRect(l.id, b.x, b.y, b.width, b.height);
      renderAll();
    }
    showToast((cut ? '已剪切' : '已复制') + '选区 ' + cw + '×' + ch + '（Ctrl+V 粘贴为新图层）');
    return true;
  } catch (e) { console.error(e); showToast((cut ? '剪切' : '复制') + '失败：' + (e.message || e), true); return false; }
}
async function pasteClipboardPixels() {
  if (!pixelClipboard.dataUrl) { showToast('剪贴板为空：先框选并 Ctrl+C', true); return null; }
  try {
    const x = Math.min(Math.max(0, pixelClipboard.x), Math.max(0, engine.width - pixelClipboard.width));
    const y = Math.min(Math.max(0, pixelClipboard.y), Math.max(0, engine.height - pixelClipboard.height));
    const layer = await importImageAsLayer(pixelClipboard.dataUrl, '粘贴 · ' + pixelClipboard.label, { x, y, width: pixelClipboard.width, height: pixelClipboard.height });
    addRecord(baseRecord('L6', { kind: 'pixel_paste', anchor: { type: 'bbox', value: [x, y, pixelClipboard.width, pixelClipboard.height] }, model: { provider: 'mock', model: MOCK_MODEL }, params: { from_layer: pixelClipboard.label, width: pixelClipboard.width, height: pixelClipboard.height }, input_refs: [], assertions: [{ type: 'user_operation', value: true }], ai_role: null, source: 'observed', author: 'user', note: '选区像素粘贴为新图层' }));
    renderAll();
    enterImageTransformUI(layer, x, y, pixelClipboard.width, pixelClipboard.height);
    scheduleProjectAutosave();
    showToast('已粘贴为新图层：可移动/缩放，Ctrl+Z 撤销');
    return layer;
  } catch (e) { console.error(e); showToast('粘贴失败：' + (e.message || e), true); return null; }
}

/* ---------------- 工具 / 输入 ---------------- */
function setupBrushInput() {
  if (brushDetach) { brushDetach(); brushDetach = null; }
  if (maskDetach) { maskDetach(); maskDetach = null; }
  if (state.tool !== 'brush' && state.tool !== 'eraser' && state.tool !== 'smudge') return;
  const target = engine ? engine.getActiveTarget() : 'layer';
  if ((target === 'mask' || target === 'group-mask') && state.tool !== 'smudge') { maskDetach = attachMaskInput(); return; }
  brushDetach = attachBrushInputImpl();
}
/** 蒙版笔触（图层蒙版/组蒙版）：直接调用 engine.beginStroke/appendPoint/endStroke，绕开 brush-controller 的 currentStroke 门控。 */
function attachMaskInput() {
  let active = false;
  const maskHint = () => { const isEr = state.tool === 'eraser'; return '蒙版编辑：白=显示 / 黑=隐藏 · ' + (isEr ? '橡皮=隐藏' : '画笔=显示') + (engine.getActiveTarget() === 'group-mask' ? '（组蒙版）' : '（图层蒙版）'); };
  const down = (e) => {
    if (active || (e.button != null && e.button !== 0)) return;
    e.preventDefault(); active = true;
    try { mainCanvas.setPointerCapture && mainCanvas.setPointerCapture(e.pointerId); } catch (err) {}
    if (controller && engine.brush) engine.brush.sizePx = controller.preset.size.base;
    const p = canvasPoint(e); p.pressure = e.pressure > 0 ? e.pressure : 0.5; p.timestamp = e.timeStamp || performance.now();
    const maskPaint = state.tool === 'eraser' ? 'black' : 'white'; if (typeof engine.setMaskStrokePaint === 'function') engine.setMaskStrokePaint(maskPaint); engine.beginStroke(p, { maskPaint });
    engine.requestFrame && engine.requestFrame();
  };
  const move = (e) => {
    if (!active) return;
    e.preventDefault();
    const list = typeof e.getCoalescedEvents === 'function' ? e.getCoalescedEvents() : [e];
    for (const ev of (list && list.length ? list : [e])) {
      const p = canvasPoint(ev); p.pressure = ev.pressure > 0 ? ev.pressure : 0.5; p.timestamp = ev.timeStamp || performance.now();
      engine.appendPoint(p);
    }
    engine.requestFrame && engine.requestFrame();
  };
  const up = (e) => {
    if (!active) return;
    active = false;
    try { mainCanvas.releasePointerCapture && mainCanvas.releasePointerCapture(e.pointerId); } catch (err) {}
    engine.endStroke();
    engine.presentFull();
    renderLayers();
    scheduleProjectAutosave();
    $('statusHint').textContent = maskHint();
  };
  const cancel = () => { if (active) { active = false; try { engine.cancelStroke(); } catch (e) {} } };
  mainCanvas.addEventListener('pointerdown', down);
  mainCanvas.addEventListener('pointermove', move);
  mainCanvas.addEventListener('pointerup', up);
  mainCanvas.addEventListener('pointercancel', cancel);
  return () => {
    mainCanvas.removeEventListener('pointerdown', down);
    mainCanvas.removeEventListener('pointermove', move);
    mainCanvas.removeEventListener('pointerup', up);
    mainCanvas.removeEventListener('pointercancel', cancel);
  };
}
function attachBrushInputImpl() {
  const detach = attachBrushInput(controller, mainCanvas);
  const origEnd = controller.end.bind(controller);
  controller.end = function patchedEnd(...args) {
    const r = origEnd(...args);
    state.strokes += 1;
    $('statusStrokes').textContent = `笔触 ${state.strokes}`;
    scheduleSave();
    setTimeout(saveSnapshot, 600);
    return r;
  };
  return detach;
}
// 全局停止位（抬笔/取消）与手动接管：只绑定一次，避免切换工具后重复监听
let canvasGuardsBound = false;
function bindCanvasGuards() {
  if (canvasGuardsBound) return;
  canvasGuardsBound = true;
  mainCanvas.addEventListener('pointerdown', onTakeover, { capture: true });
  mainCanvas.addEventListener('pointerdown', (e) => {
    state.pointerdowns += 1;
    state.lastPointer = { type: e.pointerType || '?', x: Math.round(e.clientX), y: Math.round(e.clientY), tool: state.tool, ts: Date.now() };
    if (state.tool === 'brush' || state.tool === 'eraser' || state.tool === 'smudge') state.strokeActive = true;
  }, { capture: true });
  window.addEventListener('pointerup', () => { state.strokeActive = false; }, true);
  window.addEventListener('pointercancel', () => { state.strokeActive = false; }, true);
  // 演示中用户点任何非演示控件 → 退出自动播放并接管
  document.addEventListener('pointerdown', (e) => {
    if (!state.demo.active) return;
    if (e.target && e.target.closest && e.target.closest('#demoBar,#demoNarr,#demoEnd')) return;
    takeoverDemo();
  }, true);
}
function onTakeover() {
  if (state.demo.active) takeoverDemo();
}


/* ---------------- T58 浮层 / 视图 / 颜色 ---------------- */
const POPOVER_IDS = ['popLayers', 'popBrush', 'popColor', 'popAI', 'popMore'];
let activePopoverId = null;
function positionPopover(el) {
  const anchorMap = {
    popLayers: 'btnPanelLayers', popBrush: 'btnToolBrush', popColor: 'btnPanelColor',
    popAI: 'btnAiPanel', popMore: 'btnMore',
  };
  const anchor = document.getElementById(anchorMap[el.id]);
  const rect = anchor ? anchor.getBoundingClientRect() : { left: 80, bottom: 60 };
  const w = el.offsetWidth || 320;
  const left = Math.max(10, Math.min(window.innerWidth - w - 10, rect.left));
  const top = Math.min(window.innerHeight - 60, rect.bottom + 8);
  el.style.left = Math.round(left) + 'px';
  el.style.top = Math.round(top) + 'px';
  const bb = document.querySelector('.pro-bottombar');
  const bottomReserve = (bb ? bb.getBoundingClientRect().height : 28) + 12;
  el.style.maxHeight = Math.max(180, window.innerHeight - top - bottomReserve) + 'px';
}
let lastPopoverAnchor = null;
function closePopovers() {
  POPOVER_IDS.forEach((id) => { const el = document.getElementById(id); if (el) el.classList.remove('open'); });
  document.querySelectorAll('.pro-topbar .pro-btn').forEach((b) => b.classList.remove('pop-active'));
  document.querySelectorAll('.pro-topbar [aria-expanded="true"]').forEach((b) => b.setAttribute('aria-expanded', 'false'));
  if (lastPopoverAnchor && document.contains(lastPopoverAnchor)) { try { lastPopoverAnchor.focus({ preventScroll: true }); } catch (e) {} }
  lastPopoverAnchor = null;
  activePopoverId = null;
  try { updateSelectionAiChip(); } catch (e) { /* ignore */ }
}
function openPopover(id) {
  if (!POPOVER_IDS.includes(id)) return;
  if (id === 'popAI' && state.transformActive) cancelTransformUI();
  const el = document.getElementById(id);
  if (!el) return;
  closePopovers();
  el.classList.add('open');
  positionPopover(el);
  activePopoverId = id;
  const anchorMap = { popLayers: 'btnPanelLayers', popBrush: 'btnToolBrush', popColor: 'btnPanelColor', popAI: 'btnAiPanel', popMore: 'btnMore' };
  const anchor = document.getElementById(anchorMap[id]);
  if (anchor) { anchor.setAttribute('aria-expanded', 'true'); anchor.classList.add('pop-active'); lastPopoverAnchor = anchor; }
  const first = el.querySelector('button:not([disabled]), input, select, [tabindex="0"]');
  if (first) setTimeout(() => { try { first.focus({ preventScroll: true }); } catch (e) {} }, 30);
  if (id === 'popMore') { try { renderHistoryMenu(); } catch (e) { /* ignore */ } }
  try { updateSelectionAiChip(); } catch (e) { /* ignore */ }
}
function togglePopover(id) {
  if (activePopoverId === id) closePopovers();
  else openPopover(id);
}

/* 视图：适配缩放 + 滚轮缩放 + 空格拖移 */
const view = { zoom: 1, tx: 0, ty: 0, baseScale: 1 };
function applyView() {
  if (!mainCanvas) return;
  const t = 'translate(calc(-50% + ' + view.tx + 'px), calc(-50% + ' + view.ty + 'px)) scale(' + view.zoom + ')';
  for (const c of [mainCanvas, overlayCanvas, selectionOverlay, transformOverlay, document.getElementById('annotationCanvas'), document.getElementById('candidatePreviewCanvas'), document.getElementById('aiSuggestionCanvas'), document.getElementById('brushCursorCanvas'), document.getElementById('guideCanvas')]) { if (c) { c.style.transform = t; } }
  const el = document.getElementById('statusZoom');
  if (el && view.baseScale) el.textContent = Math.round(view.baseScale * view.zoom * 100) + '%';
  try { updateSelectionAiChip(); } catch (e) { /* ignore */ }
}
function resetView() { view.zoom = 1; view.tx = 0; view.ty = 0; applyView(); }
function setZoom(z) { view.zoom = clamp(z, 0.15, 8); applyView(); }
function zoomTo100() { view.zoom = 1 / (view.baseScale || 1); view.tx = 0; view.ty = 0; applyView(); }
function zoomBy(f) { setZoom(view.zoom * f); }
function bindViewControls() {
  const wrap = document.getElementById('canvasWrap');
  if (!wrap) return;
  wrap.addEventListener('wheel', (e) => {
    e.preventDefault();
    const rect = wrap.getBoundingClientRect();
    const cx = e.clientX - rect.left - rect.width / 2;
    const cy = e.clientY - rect.top - rect.height / 2;
    const oldZoom = view.zoom;
    const newZoom = Math.max(0.15, Math.min(8, oldZoom * Math.exp(-e.deltaY * 0.0015)));
    const base = view.baseScale || 1;
    const docX = engine.width / 2 + (cx - view.tx) / (base * oldZoom);
    const docY = engine.height / 2 + (cy - view.ty) / (base * oldZoom);
    view.tx = cx - (docX - engine.width / 2) * base * newZoom;
    view.ty = cy - (docY - engine.height / 2) * base * newZoom;
    view.zoom = newZoom;
    applyView();
  }, { passive: false });
  wrap.addEventListener('dblclick', () => resetView());
  let spaceDown = false;
  let panning = null;
  window.addEventListener('keydown', (e) => { if (e.code === 'Space' && !e.repeat && !state.demo.active) { spaceDown = true; state.spaceDown = true; wrap.style.cursor = 'grab'; } });
  window.addEventListener('keyup', (e) => { if (e.code === 'Space') { spaceDown = false; state.spaceDown = false; wrap.style.cursor = state.tool === 'move' ? 'grab' : ''; } });
  window.addEventListener('blur', () => { spaceDown = false; state.spaceDown = false; });
  wrap.addEventListener('pointerdown', (e) => {
    if (!spaceDown && e.button !== 1 && state.tool !== 'move') return;
    e.preventDefault(); e.stopPropagation();
    panning = { x: e.clientX, y: e.clientY, tx: view.tx, ty: view.ty };
    wrap.setPointerCapture && wrap.setPointerCapture(e.pointerId);
    wrap.style.cursor = 'grabbing';
  }, { capture: true });
  wrap.addEventListener('pointermove', (e) => {
    if (!panning) return;
    e.preventDefault(); e.stopPropagation();
    view.tx = panning.tx + (e.clientX - panning.x);
    view.ty = panning.ty + (e.clientY - panning.y);
    applyView();
  }, { capture: true });
  const endPan = () => { if (panning) { panning = null; wrap.style.cursor = (spaceDown || state.tool === 'move') ? 'grab' : ''; } };
  wrap.addEventListener('pointerup', endPan, { capture: true });
  wrap.addEventListener('pointercancel', endPan, { capture: true });
}

/* ---------------- 笔刷面板 ---------------- */
function applyPreset(preset, statusText) {
  if (!preset || !presets) return;
  const changed = !controller.preset || controller.preset.id !== preset.id;
  if (changed) controller.setPreset(preset);
  state.activePresetId = preset.id;
  $('brushStatus').textContent = statusText || preset.name;
  if (changed) syncBrushControls();
  syncLeftSliders();
  applySimPressure();
  renderBrushGrid();
}
function setTool(tool) {
  if (state.transformActive && tool !== 'transform') cancelTransformUI({ keepTool: true });
  state.tool = tool;
  document.querySelectorAll('.pro-topbar [data-tool]').forEach((b) => b.classList.toggle('active', b.dataset.tool === tool));
  if (!['brush', 'eraser', 'smudge'].includes(tool)) clearBrushCursor();
  if (tool !== 'shape' && shapeDetach) { try { shapeDetach(); } catch (e) { /* ignore */ } }
  const wrapEl = document.getElementById('canvasWrap');
  if (wrapEl && tool !== 'move') wrapEl.style.cursor = '';
  if (tool === 'move') {
    setupBrushInput();
    const w = document.getElementById('canvasWrap'); if (w) w.style.cursor = 'grab';
    updateToolOptions();
    $('statusHint').textContent = '移动画面：拖拽平移（放大后也可拖）· 中键拖拽 / 空格+拖拽 · 滚轮缩放 · 0 适应 / 1 100%';
    return;
  }
  if (tool === 'text') {
    closeTextComposer();
    setupBrushInput();
    attachTextInput();
    updateToolOptions();
    $('statusHint').textContent = '文字：点击画布放置文字；Enter 换行 · Ctrl+Enter 提交 · Esc 取消';
    const w = document.getElementById('canvasWrap'); if (w) w.style.cursor = 'text';
    return;
  }
  if (tool === 'shape') {
    closeTextComposer();
    setupBrushInput();
    attachShapeInput();
    updateToolOptions();
    $('statusHint').textContent = '形状：拖拽绘制；矩形/椭圆/直线在顶部工具条切换；颜色随当前色';
    const w = document.getElementById('canvasWrap'); if (w) w.style.cursor = 'crosshair';
    return;
  }
  closeTextComposer();
  if (tool === 'smudge') {
    if (controller && controller.setMode) controller.setMode('smudge');
    setupBrushInput();
    updateToolOptions();
    $('statusHint').textContent = '涂抹：拖动拉像素；再点画笔切回（S）';
    return;
  }
  if (controller && controller.getMode && controller.getMode() === 'smudge') controller.setMode('brush');
  if (tool === 'brush') applyPreset(presets.brushes[state.brushIndex] || presets.brushes[0]);
  else if (tool === 'eraser') {
    const eraser = presets.brushes.find((b) => b.engine && b.engine.eraser);
    if (eraser) applyPreset(eraser, eraser.name + '（擦除）');
  }
  if (tool === 'select' || tool === 'transform') attachSelectionInput();
  setupBrushInput();
  const target = engine.getActiveTarget();
  let hint = tool === 'brush' ? (engine.hasSelection() ? '画笔：选区约束中（仅选区内落笔）· [ ] 调大小' : '就绪：拖动绘制 · [ ] 调大小 · Ctrl+[ ] 调透明度')
    : tool === 'eraser' ? '橡皮：按住拖动擦除' + (engine.hasSelection() ? '（选区约束）' : '')
    : tool === 'select' ? '选区：拖动框选；M 矩形 / Shift+M 椭圆 / L 套索 / W 魔棒；Ctrl+D 取消'
    : tool === 'transform' ? '变换：拖手柄缩放/旋转（Shift 15° 吸附）；Enter 提交 / Esc 取消'
    : tool === 'eyedropper' ? '吸管：点击画布取色'
    : tool === 'move' ? '移动：空格拖动画布'
    : '就绪';
  if ((tool === 'brush' || tool === 'eraser') && (target === 'mask' || target === 'group-mask')) {
    const paint = tool === 'eraser' ? 'black' : 'white';
    if (typeof engine.setMaskStrokePaint === 'function') engine.setMaskStrokePaint(paint);
    hint = '蒙版编辑：白=显示 / 黑=隐藏 · ' + (paint === 'black' ? '橡皮=隐藏' : '画笔=显示') + (target === 'group-mask' ? '（组蒙版）' : '（图层蒙版）');
  }
  if (tool === 'transform') beginTransformUI();
  updateToolOptions();
  $('statusHint').textContent = hint;
}
const SWATCHES = ['#232a33', '#4a4038', '#7c2d12', '#b45309', '#c9a87c', '#d6c7a1', '#e8e2d4', '#3f5a54', '#2e6be6', '#60a5fa', '#7c3aed', '#db2777'];
function setBrushColor(hex) {
  state.color = hex;
  if (controller) controller.setColor(hexToRgb(hex));
  const input = document.getElementById('colorInput'); if (input) input.value = hex;
  const hexEl = document.getElementById('colorHex'); if (hexEl) hexEl.textContent = hex;
  const rail = document.getElementById('railColor'); if (rail) rail.style.background = hex;
  document.querySelectorAll('#swatches button').forEach((b) => b.classList.toggle('active', b.dataset.color === hex));
}
function renderSwatches() {
  const host = document.getElementById('swatches');
  if (!host) return;
  host.innerHTML = '';
  SWATCHES.forEach((hex) => {
    const b = document.createElement('button'); b.style.background = hex; b.dataset.color = hex; b.title = hex;
    b.addEventListener('click', () => setBrushColor(hex)); host.append(b);
  });
}

function renderGuideCanvas() {
  const c = document.getElementById('guideCanvas');
  if (!c) return;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  const paper = document.documentElement.dataset.theme === 'paper';
  const line = paper ? 'rgba(120,98,70,.14)' : 'rgba(186,200,214,.14)';
  const strong = paper ? 'rgba(120,98,70,.24)' : 'rgba(96,165,250,.28)';
  const w = engine.width, h = engine.height;
  ctx.save();
  if (state.showGrid) {
    try {
      const g = gridLines(w, h, { spacing: 80, majorEvery: 4 });
      for (const l of g.vertical) { ctx.strokeStyle = l.major ? strong : line; ctx.lineWidth = l.major ? 1.2 : 1; ctx.beginPath(); ctx.moveTo(l.value + 0.5, 0); ctx.lineTo(l.value + 0.5, h); ctx.stroke(); }
      for (const l of g.horizontal) { ctx.strokeStyle = l.major ? strong : line; ctx.lineWidth = l.major ? 1.2 : 1; ctx.beginPath(); ctx.moveTo(0, l.value + 0.5); ctx.lineTo(w, l.value + 0.5); ctx.stroke(); }
    } catch (e) { /* ignore */ }
  }
  if (state.showThirds) {
    try {
      const t = thirdsLines(w, h);
      ctx.setLineDash([7, 5]); ctx.strokeStyle = strong; ctx.lineWidth = 1.2;
      for (const v of t.vertical) { ctx.beginPath(); ctx.moveTo(v + 0.5, 0); ctx.lineTo(v + 0.5, h); ctx.stroke(); }
      for (const v of t.horizontal) { ctx.beginPath(); ctx.moveTo(0, v + 0.5); ctx.lineTo(w, v + 0.5); ctx.stroke(); }
      ctx.setLineDash([]);
    } catch (e) { /* ignore */ }
  }
  if (state.customGuides && state.customGuides.length) {
    ctx.setLineDash([4, 4]); ctx.strokeStyle = paper ? 'rgba(47,94,99,.62)' : 'rgba(125,211,252,.62)'; ctx.lineWidth = 1.2;
    for (const g of state.customGuides) {
      if (g.axis === 'x') { ctx.beginPath(); ctx.moveTo(g.value + 0.5, 0); ctx.lineTo(g.value + 0.5, h); ctx.stroke(); }
      else { ctx.beginPath(); ctx.moveTo(0, g.value + 0.5); ctx.lineTo(w, g.value + 0.5); ctx.stroke(); }
    }
    ctx.setLineDash([]);
  }
  if (state.symmetryAxis) {
    ctx.setLineDash([10, 6]); ctx.strokeStyle = paper ? 'rgba(162,63,42,.42)' : 'rgba(251,113,133,.45)'; ctx.lineWidth = 1.3;
    if (state.symmetryAxis === 'x' || state.symmetryAxis === 'both') { ctx.beginPath(); ctx.moveTo(w / 2 + 0.5, 0); ctx.lineTo(w / 2 + 0.5, h); ctx.stroke(); }
    if (state.symmetryAxis === 'y' || state.symmetryAxis === 'both') { ctx.beginPath(); ctx.moveTo(0, h / 2 + 0.5); ctx.lineTo(w, h / 2 + 0.5); ctx.stroke(); }
    ctx.setLineDash([]);
  }
  ctx.restore();
}
function syncGuideUI() {
  const g = document.getElementById('gridStateLabel'); if (g) g.textContent = state.showGrid ? '开' : '关';
  const t = document.getElementById('thirdsStateLabel'); if (t) t.textContent = state.showThirds ? '开' : '关';
  const s = document.getElementById('btnToggleSymmetry');
  if (s) s.textContent = '对称轴：' + ({ x: '左右', y: '上下', both: '中心' }[state.symmetryAxis] || '关');
  const cg = document.getElementById('btnCustomGuides');
  if (cg) cg.textContent = '自定义参考线…' + ((state.customGuides && state.customGuides.length) ? ' (' + state.customGuides.length + ')' : '');
}
function renderGuideList() {
  const host = document.getElementById('guideList');
  if (!host) return;
  const list = state.customGuides || [];
  if (!list.length) { host.innerHTML = '<div class="hint">还没有参考线。添加 X（竖向）或 Y（横向）坐标。</div>'; return; }
  host.innerHTML = list.map((g, i) => '<div class="guide-row"><span>' + (g.axis === 'x' ? '竖向 X = ' : '横向 Y = ') + Math.round(g.value) + ' px</span><button data-guide-remove="' + i + '" title="删除">删除</button></div>').join('');
  host.querySelectorAll('[data-guide-remove]').forEach((b) => b.addEventListener('click', () => { state.customGuides.splice(parseInt(b.dataset.guideRemove, 10), 1); renderGuideList(); renderGuideCanvas(); syncGuideUI(); }));
}
function openCustomGuidesModal() {
  closePopovers();
  renderGuideList();
  openModal('guidesModal');
}
function addCustomGuide(axis) {
  const input = document.getElementById(axis === 'x' ? 'guideXInput' : 'guideYInput');
  const value = Number(input && input.value);
  if (!Number.isFinite(value)) { showToast('输入参考线坐标', true); return; }
  const limit = axis === 'x' ? engine.width : engine.height;
  const v = clamp(Math.round(value), 0, limit);
  if ((state.customGuides || []).some((g) => g.axis === axis && Math.abs(g.value - v) < 0.5)) { showToast('这条参考线已存在'); return; }
  state.customGuides.push({ axis, value: v });
  if (input) input.value = '';
  renderGuideList(); renderGuideCanvas(); syncGuideUI();
}
function clearCustomGuides() {
  state.customGuides = [];
  renderGuideList(); renderGuideCanvas(); syncGuideUI();
}
function renderBrushGrid() {
  const host = $('brushGrid');
  if (!host || !presets) return;
  host.innerHTML = '';
  presets.brushes.forEach((b, i) => {
    const btn = document.createElement('button');
    const activeId = state.activePresetId || (presets.brushes[state.brushIndex] && presets.brushes[state.brushIndex].id);
    btn.className = 'brush-chip' + (b.id === activeId ? ' active' : '');
    btn.innerHTML = '<span class="bdot"></span><span>' + b.name + '</span>';
    btn.title = b.name + '（' + b.id + '）';
    btn.addEventListener('click', () => selectBrush(i));
    host.append(btn);
  });
}
function selectBrush(i) {
  state.brushIndex = i;
  setTool('brush');
  applyPreset(presets.brushes[i]);
  syncBrushControls();
  renderBrushGrid();
}
function syncBrushControls() {
  if (!controller) return;
  const p = controller.preset;
  $('brushSize').value = p.size.base;
  $('brushSizeVal').textContent = Math.round(p.size.base);
  $('brushHardness').value = p.hardness.base;
  $('brushHardnessVal').textContent = Number(p.hardness.base).toFixed(2);
  $('brushOpacity').value = p.opacity.base;
  $('brushOpacityVal').textContent = Number(p.opacity.base).toFixed(2);
  syncLeftSliders();
}
function syncLeftSliders() {
  if (!controller) return;
  const p = controller.preset;
  const size = Math.round(p.size.base);
  const op = Math.round(p.opacity.base * 100);
  const ls = document.getElementById('leftSizeRange');
  const lo = document.getElementById('leftOpacityRange');
  if (ls) ls.value = size;
  if (lo) lo.value = op;
  const lsv = document.getElementById('leftSizeVal'); if (lsv) lsv.textContent = size + 'px';
  const lov = document.getElementById('leftOpacityVal'); if (lov) lov.textContent = op + '%';
  const rbn = document.getElementById('railBrushName'); if (rbn) rbn.textContent = (p.engine && p.engine.eraser) ? '橡皮' : (p.name || '画笔');
}
function bindBrushControls() {
  const setSize = (v) => {
    v = Math.max(1, Math.min(256, Math.round(v)));
    controller.setParam('size.base', v);
    $('brushSize').value = v; $('brushSizeVal').textContent = v;
    $('leftSizeRange').value = v; $('leftSizeVal').textContent = v + 'px';
  };
  const setOpacity = (v) => {
    v = Math.max(0.02, Math.min(1, v));
    controller.setParam('opacity.base', v);
    $('brushOpacity').value = v; $('brushOpacityVal').textContent = v.toFixed(2);
    $('leftOpacityRange').value = Math.round(v * 100); $('leftOpacityVal').textContent = Math.round(v * 100) + '%';
  };
  $('brushSize').addEventListener('input', (e) => setSize(parseFloat(e.target.value)));
  $('leftSizeRange').addEventListener('input', (e) => setSize(parseFloat(e.target.value)));
  $('brushHardness').addEventListener('input', (e) => {
    const v = parseFloat(e.target.value);
    $('brushHardnessVal').textContent = v.toFixed(2);
    controller.setParam('hardness.base', v);
  });
  $('brushOpacity').addEventListener('input', (e) => setOpacity(parseFloat(e.target.value)));
  $('leftOpacityRange').addEventListener('input', (e) => setOpacity(parseFloat(e.target.value) / 100));
  $('colorInput').addEventListener('input', (e) => setBrushColor(e.target.value));
  const _rc = $('railColor'); if (_rc) _rc.addEventListener('click', () => togglePopover('popColor'));
  $('btnColorReset').addEventListener('click', () => setBrushColor('#232a33'));
  window.__setBrushSize = setSize;
  window.__setBrushOpacity = setOpacity;
  const ls = $('leftSizeRange');
  ls.addEventListener('wheel', (e) => { e.preventDefault(); setSize(controller.preset.size.base + (e.deltaY < 0 ? (e.shiftKey ? 10 : 1) : -(e.shiftKey ? 10 : 1))); }, { passive: false });
  ls.addEventListener('dblclick', () => setSize(18));
  const lo = $('leftOpacityRange');
  lo.addEventListener('wheel', (e) => { e.preventDefault(); const d = e.deltaY < 0 ? 1 : -1; setOpacity(controller.preset.opacity.base + d / 100); }, { passive: false });
  lo.addEventListener('dblclick', () => setOpacity(1));
  $('btnEyedropper').addEventListener('click', () => {
    if (state.tool === 'eyedropper') { setTool('brush'); $('btnEyedropper').classList.remove('active'); return; }
    setTool('eyedropper');
    $('btnEyedropper').classList.add('active');
  });
  $('btnEyedropper').classList.remove('active');
}

function attachSelectionInput() {
  if (toolInputBound) return;
  toolInputBound = true;
  const canvas = mainCanvas;
  let selStart = null;
  let lassoPoints = [];
  let trDrag = null;

  const updateSelState = (bbox) => {
    const has = !!(selectionManager && selectionManager.hasSelection);
    state.selection = has && bbox ? bbox : (has ? state.selection : null);
    const hint = has ? '选区已建立（Esc 取消 / Ctrl+D 取消选择）' : '选区：拖动框选；M 矩形、Shift+M 椭圆、L 套索、W 魔棒';
    $('statusHint').textContent = state.tool === 'select' ? hint : $('statusHint').textContent;
    updateToolOptions();
  };

  canvas.addEventListener('pointerdown', (e) => {
    if (state.tool === 'transform') {
      if (!state.transformActive) return;
      const p = canvasPoint(e);
      const hit = hitTransformTarget(p.x, p.y);
      if (!hit) return;
      e.preventDefault(); e.stopPropagation();
      trDrag = { mode: hit, start: p, base: { ...(engine._transform || {}) } };
      canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId);
      return;
    }
    if (state.tool !== 'select' || !selectionManager) return;
    e.preventDefault(); e.stopPropagation();
    const p = canvasPoint(e);
    selStart = p; lassoPoints = [p];
    state.selection = { x: p.x, y: p.y, width: 1, height: 1 };
    if (state.selectionMode === 'wand') { applyWand(p); selStart = null; return; }
  }, { capture: true });

  canvas.addEventListener('pointermove', (e) => {
    if (state.tool === 'transform' && trDrag) {
      e.preventDefault(); e.stopPropagation();
      const raw = canvasPoint(e);
      const p = trDrag.mode === 'move' ? snapDocPoint(raw) : raw;
      if (trDrag.mode === 'move') {
        engine.updateTransform({ x: (trDrag.base.x || 0) + (p.x - trDrag.start.x), y: (trDrag.base.y || 0) + (p.y - trDrag.start.y) });
      } else if (trDrag.mode === 'rotate') {
        engine.dragTransformHandle('rotate', p.x, p.y, { snap: e.shiftKey });
      } else {
        engine.dragTransformHandle(trDrag.mode, p.x, p.y);
      }
      drawTransformOverlay();
      return;
    }
    if (state.tool !== 'select' || !selStart) return;
    e.preventDefault(); e.stopPropagation();
    const p = canvasPoint(e);
    lassoPoints.push(p);
    state.selection = normRect(selStart, p);
    drawSelectionPreview();
  }, { capture: true });

  const finishPointer = async (e) => {
    if (state.tool === 'transform' && trDrag) { trDrag = null; return; }
    if (state.tool !== 'select' || !selStart || !selectionManager) return;
    const start = selStart; selStart = null;
    const p = canvasPoint(e || { clientX: start.x, clientY: start.y });
    const mode = state.selectionBool || 'replace';
    const feather = state.feather || 0;
    try {
      if (state.selectionMode === 'rect') selectionManager.rect(start.x, start.y, p.x, p.y, mode, feather);
      else if (state.selectionMode === 'ellipse') selectionManager.ellipse(start.x, start.y, p.x, p.y, mode, feather);
      else selectionManager.lasso(lassoPoints, mode, feather);
      const b = state.selectionMode === 'lasso' ? bboxOfPoints(lassoPoints) : normRect(start, p);
      updateSelState(b);
      showToast('已建立选区（' + state.selectionMode + ' / ' + mode + (feather ? ' / 羽化 ' + feather : '') + '）');
    } catch (err) { showToast('选区失败：' + (err.message || err), true); }
    if (transformOverlay) transformOverlay.getContext('2d').clearRect(0, 0, transformOverlay.width, transformOverlay.height);
  };
  canvas.addEventListener('pointerup', finishPointer, { capture: true });
  canvas.addEventListener('pointercancel', () => { selStart = null; trDrag = null; }, { capture: true });

  async function applyWand(p) {
    try {
      $('statusHint').textContent = '魔棒取样中…';
      await selectionManager.wandAt(p.x, p.y, state.selectionBool || 'replace', 32);
      if (selectionManager.hasSelection) state.selection = { x: Math.round(p.x), y: Math.round(p.y), width: 64, height: 64 };
      updateSelState(state.selection);
      showToast('魔棒选区已生成');
    } catch (err) { showToast('魔棒失败：' + (err.message || err), true); }
  }
}
function bboxOfPoints(points) {
  if (!points || !points.length) return null;
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const p of points) { x0 = Math.min(x0, p.x); y0 = Math.min(y0, p.y); x1 = Math.max(x1, p.x); y1 = Math.max(y1, p.y); }
  return { x: x0, y: y0, width: x1 - x0, height: y1 - y0 };
}
function drawSelectionPreview() {
  const canvas = transformOverlay;
  if (!canvas || !state.selection) return;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const r = state.selection;
  if (state.selectionMode === 'rect' || state.selectionMode === 'ellipse') {
    ctx.save(); ctx.strokeStyle = '#7db4ff'; ctx.setLineDash([6, 4]); ctx.lineWidth = 2;
    if (state.selectionMode === 'ellipse') { ctx.beginPath(); ctx.ellipse(r.x + r.width / 2, r.y + r.height / 2, Math.max(1, r.width / 2), Math.max(1, r.height / 2), 0, 0, Math.PI * 2); ctx.stroke(); }
    else ctx.strokeRect(r.x, r.y, r.width, r.height);
    ctx.restore();
  }
}
function clearSelectionUI() {
  if (selectionManager) selectionManager.clear();
  engine.clearSelection();
  state.selection = null;
  const c = transformOverlay && transformOverlay.getContext('2d'); if (c) c.clearRect(0, 0, transformOverlay.width, transformOverlay.height);
  updateToolOptions();
  $('statusHint').textContent = '已取消选区';
}
function invertSelectionUI() {
  if (!selectionManager || !selectionManager.hasSelection) { showToast('当前没有选区可反选', true); return; }
  const sm = selectionManager;
  const tmp = document.createElement('canvas'); tmp.width = sm.width; tmp.height = sm.height;
  const tctx = tmp.getContext('2d');
  tctx.fillStyle = '#fff'; tctx.fillRect(0, 0, tmp.width, tmp.height);
  tctx.globalCompositeOperation = 'destination-out'; tctx.drawImage(sm.mask, 0, 0);
  sm.mctx.clearRect(0, 0, sm.width, sm.height);
  sm.mctx.drawImage(tmp, 0, 0);
  sm._afterChange();
  updateToolOptions();
  showToast('已反选');
}
function updateToolOptions() {
  updateStatusContext();
  const to = document.getElementById('toolOptions');
  if (!to) return;
  const show = state.tool === 'select' || state.tool === 'transform' || state.tool === 'shape';
  to.hidden = !show;
  const sel = document.getElementById('toSelection'); const tr = document.getElementById('toTransform');
  if (sel) sel.hidden = state.tool !== 'select';
  if (tr) tr.hidden = state.tool !== 'transform';
  const sh = document.getElementById('toShape');
  if (sh) {
    sh.hidden = state.tool !== 'shape';
    sh.querySelectorAll('[data-shape]').forEach((b) => b.classList.toggle('active', b.dataset.shape === state.shapeType));
  }
  to.querySelectorAll('[data-selmode]').forEach((b) => b.classList.toggle('active', b.dataset.selmode === state.selectionMode));
  const sb = document.getElementById('selBool'); if (sb) sb.value = state.selectionBool;
  const fe = document.getElementById('selFeather'); if (fe) fe.value = state.feather;
  const fv = document.getElementById('selFeatherVal'); if (fv) fv.textContent = state.feather;
  const ta = document.getElementById('trAngle'); if (ta) ta.textContent = Math.round((engine._transform && engine._transform.rotate) || 0) + '°';
}
function beginTransformUI() {
  if (state.transformActive) return;
  const l = activeLayer();
  if (!l) return;
  if (l.locked) { showToast('图层已锁定，无法变换', true); return; }
  engine.setActiveLayer(l.id);
  // 无选区时按图层内容包围盒给变换框（插入的图片会有贴合图片的手柄，而不是整张画布）
  let bounds = null;
  try {
    const selActive = typeof engine.hasSelection === 'function' ? engine.hasSelection() : false;
    if (!selActive && typeof engine.getLayerContentBounds === 'function') bounds = engine.getLayerContentBounds(l.id);
  } catch (e) { bounds = null; }
  engine.beginTransform(l.id, bounds ? { bounds } : undefined);
  state.transformActive = true;
  drawTransformOverlay();
  updateToolOptions();
  $('statusHint').textContent = '变换：拖手柄缩放/旋转（Shift 15° 吸附），拖内部移动；Enter 提交 / Esc 取消';
}
function drawTransformOverlay() {
  const canvas = transformOverlay;
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (!state.transformActive) return;
  const h = engine.getTransformHandles();
  if (!h) return;
  const b = h.bounds; const rad = (b.rotate || 0) * Math.PI / 180;
  const corner = (ux, uy) => ({ x: b.cx + (ux * b.w / 2) * Math.cos(rad) - (uy * b.h / 2) * Math.sin(rad), y: b.cy + (ux * b.w / 2) * Math.sin(rad) + (uy * b.h / 2) * Math.cos(rad) });
  const c = [corner(-1, -1), corner(1, -1), corner(1, 1), corner(-1, 1)];
  ctx.save();
  ctx.strokeStyle = '#6AA6FF'; ctx.lineWidth = 2; ctx.setLineDash([]);
  ctx.beginPath(); ctx.moveTo(c[0].x, c[0].y); for (let i = 1; i < 4; i += 1) ctx.lineTo(c[i].x, c[i].y); ctx.closePath(); ctx.stroke();
  ctx.fillStyle = '#0f1825'; ctx.strokeStyle = '#6AA6FF'; ctx.lineWidth = 2;
  for (const hd of h.handles) {
    if (hd.id === 'rotate') { ctx.beginPath(); ctx.arc(hd.x, hd.y, 6, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); continue; }
    ctx.fillRect(hd.x - 5, hd.y - 5, 10, 10); ctx.strokeRect(hd.x - 5, hd.y - 5, 10, 10);
  }
  ctx.restore();
  updateToolOptions();
  syncTransformInputs();
}
function syncTransformInputs() {
  const b = engine && engine.getTransformBounds ? engine.getTransformBounds() : null;
  if (!b || !state.transformActive) return;
  const set = (id, v) => { const el = document.getElementById(id); if (el && document.activeElement !== el) el.value = String(Math.round(v)); };
  set('trX', b.cx - b.w / 2); set('trY', b.cy - b.h / 2); set('trW', b.w); set('trH', b.h); set('trRot', b.rotate || 0);
  const ta = document.getElementById('trAngle'); if (ta) ta.textContent = Math.round(b.rotate || 0) + '°';
}
function applyTransformInputs() {
  if (!state.transformActive || !engine.setTransformBounds) return;
  const num = (id) => { const el = document.getElementById(id); const v = el ? Number(el.value) : NaN; return Number.isFinite(v) ? v : null; };
  const x = num('trX'), y = num('trY'), w = num('trW'), h = num('trH'), r = num('trRot');
  if (x == null || y == null || w == null || h == null) return;
  engine.setTransformBounds({ x, y, width: w, height: h, rotate: r == null ? undefined : r });
  drawTransformOverlay();
}
function bindTransformControls() {
  const on = (id, fn) => { const el = document.getElementById(id); if (el) el.addEventListener('click', fn); };
  on('btnTrCommit', () => commitTransformUI());
  on('btnTrCancel', () => cancelTransformUI());
  on('btnTrFlipH', () => { if (engine._transform) { engine.updateTransform({ flipH: !engine._transform.flipH }); drawTransformOverlay(); } });
  on('btnTrFlipV', () => { if (engine._transform) { engine.updateTransform({ flipV: !engine._transform.flipV }); drawTransformOverlay(); } });
  ['trX', 'trY', 'trW', 'trH', 'trRot'].forEach((id) => { const el = document.getElementById(id); if (el) el.addEventListener('change', applyTransformInputs); });
}
function hitTransformTarget(x, y) {
  const h = engine.getTransformHandles();
  if (!h) return null;
  for (const hd of h.handles) { if (Math.hypot(hd.x - x, hd.y - y) <= 14) return hd.id; }
  const b = h.bounds; const rad = (b.rotate || 0) * Math.PI / 180;
  const dx = x - b.cx, dy = y - b.cy;
  const lx = dx * Math.cos(-rad) - dy * Math.sin(-rad);
  const ly = dx * Math.sin(-rad) + dy * Math.cos(-rad);
  if (Math.abs(lx) <= b.w / 2 && Math.abs(ly) <= b.h / 2) return 'move';
  return null;
}
function commitTransformUI() {
  if (!state.transformActive) return;
  engine.commitTransform();
  state.transformActive = false;
  const c = transformOverlay && transformOverlay.getContext('2d'); if (c) c.clearRect(0, 0, transformOverlay.width, transformOverlay.height);
  updateToolOptions(); renderAll(); scheduleProjectAutosave();
  if (state.tool === 'transform') setTool('brush');
  showToast('变换已提交（1 步 undo）');
}
function cancelTransformUI(opts = {}) {
  if (!state.transformActive) return;
  engine.cancelTransform();
  state.transformActive = false;
  const c = transformOverlay && transformOverlay.getContext('2d'); if (c) c.clearRect(0, 0, transformOverlay.width, transformOverlay.height);
  updateToolOptions();
  if (!opts.keepTool && state.tool === 'transform') setTool('brush');
  showToast('已取消变换');
}
window.__T64_READY__ = true;
if (!window.__eyedropperBound) {
  window.__eyedropperBound = true;
  document.addEventListener('pointerdown', (e) => {
    if (state.tool !== 'eyedropper') return;
    if (!document.getElementById('mainCanvas').contains(e.target)) return;
    e.preventDefault(); e.stopPropagation();
    sampleColorAt(canvasPoint(e)).then(() => { setTool('brush'); document.getElementById('btnEyedropper').classList.remove('active'); }).catch((err) => showToast('取色失败：' + err.message, true));
  }, true);
}
function canvasPoint(e) {
  const rect = mainCanvas.getBoundingClientRect();
  return { x: clamp((e.clientX - rect.left) * mainCanvas.width / rect.width, 0, mainCanvas.width), y: clamp((e.clientY - rect.top) * mainCanvas.height / rect.height, 0, mainCanvas.height) };
}
function normRect(a, b) {
  return { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), width: Math.abs(a.x - b.x), height: Math.abs(a.y - b.y) };
}
function drawSelection(rectOverride) {
  const ctx = overlayCtx;
  if (!ctx) return;
  ctx.clearRect(0, 0, overlayCanvas.width, overlayCanvas.height);
  const r = rectOverride || state.selection;
  if (!r) { updateSelectionAiChip(); return; }
  ctx.save();
  ctx.fillStyle = 'rgba(96,165,250,.14)';
  ctx.fillRect(r.x, r.y, r.width, r.height);
  ctx.strokeStyle = '#60a5fa';
  ctx.lineWidth = 2;
  ctx.setLineDash([7, 5]);
  ctx.strokeRect(r.x + 1, r.y + 1, Math.max(0, r.width - 2), Math.max(0, r.height - 2));
  ctx.restore();
  updateSelectionAiChip();
}
function updateSelectionAiChip() {
  const chip = document.getElementById('selectionAiChip');
  if (!chip || !mainCanvas) return;
  const b = state.selection;
  const show = !!b && b.width > 24 && b.height > 24 && !state.demo.active && !ROADSHOW.active && !activePopoverId && !state.annotationMode && !state.transformActive;
  if (!show) { chip.hidden = true; return; }
  const rect = mainCanvas.getBoundingClientRect();
  const wrap = document.getElementById('canvasWrap');
  const wrect = wrap ? wrap.getBoundingClientRect() : rect;
  const x = rect.x - wrect.x + ((b.x + b.width) / Math.max(1, engine.width)) * rect.width;
  const y = rect.y - wrect.y + ((b.y + b.height) / Math.max(1, engine.height)) * rect.height;
  chip.hidden = false;
  chip.style.left = clamp(x, 70, Math.max(70, wrect.width - 70)) + 'px';
  chip.style.top = clamp(y, 36, Math.max(36, wrect.height - 12)) + 'px';
}

/* ---------------- 图层 ---------------- */
let _sampleCanvas = null;
async function sampleColorAt(p) {
  const url = await getCanvasDataUrl();
  if (!_sampleCanvas) { _sampleCanvas = document.createElement('canvas'); }
  _sampleCanvas.width = engine.width; _sampleCanvas.height = engine.height;
  const ctx = _sampleCanvas.getContext('2d');
  const img = new Image(); img.src = url; await img.decode();
  ctx.drawImage(img, 0, 0);
  const d = ctx.getImageData(Math.floor(p.x), Math.floor(p.y), 1, 1).data;
  const hex = '#' + [d[0], d[1], d[2]].map((n) => n.toString(16).padStart(2, '0')).join('');
  setBrushColor(hex);
  showToast('已取色 ' + hex);
}
function activeLayer() { return engine.layers.find((l) => l.id === engine.activeLayerId) || null; }
/* ---------------- 图层树（T61：组/蒙版/剪贴/16 混合） ---------------- */
const BLEND_GROUPS = [
  ['正常', ['normal', 'dissolve']],
  ['变暗', ['darken', 'multiply', 'color-burn']],
  ['变亮', ['lighten', 'screen', 'color-dodge']],
  ['对比', ['overlay', 'soft-light', 'hard-light']],
  ['差值', ['difference', 'exclusion']],
  ['颜色', ['hue', 'saturation', 'color', 'luminosity']],
];
const BLEND_LABELS = { normal: '正常', dissolve: '溶解', darken: '变暗', multiply: '正片叠底', 'color-burn': '颜色加深', lighten: '变亮', screen: '滤色', 'color-dodge': '颜色减淡', overlay: '叠加', 'soft-light': '柔光', 'hard-light': '强光', difference: '差值', exclusion: '排除', hue: '色相', saturation: '饱和度', color: '颜色', luminosity: '明度' };

function layerById(id) { return engine.layers.find((l) => l.id === id) || null; }
function groupById(id) { return engine.groups.find((g) => g.id === id) || null; }
function commitDocUI() { engine.compositor.setLayers(engine.layers); engine.presentFull(); renderAll(); scheduleProjectAutosave(); }
function layerThumbHtml(l) {
  if (l.mask && l.mask.exists) return '<span class="ly-thumb" title="有蒙版">M</span>';
  return '<span class="ly-thumb" title="栅格层">▦</span>';
}
function renderLayers() {
  if (!engine) return;
  const host = $('layerList');
  if (!host) return;
  const doc = engine.getDoc();
  host.innerHTML = '';
  const addRow = (layer, child) => {
    const row = document.createElement('div');
    row.className = 'layer-row' + (child ? ' child' : '') + (layer.id === engine.activeLayerId && !state.selectedGroupId ? ' active' : '');
    row.dataset.layerId = layer.id;
    row.draggable = true;
    row.innerHTML = '<button class="ly-eye" title="显示/隐藏">' + (layer.visible ? '👁' : '◌') + '</button>' + layerThumbHtml(layer) +
      '<span class="ly-name">' + escapeHtml(layer.name) + '</span><span class="ly-badges">' +
      (layer.kind === 'adjust' ? '<span class="ly-badge" title="参数化栅格快照：源层后续改动不会自动更新；重开参数可重算">调整</span>' : '') + (layer.kind === 'text' ? '<span class="ly-badge" title="结构化文字图层：文字字段 + 栅格缓存，可再次编辑">文字</span>' : '') +
      ((state.assetLayerRefs && state.assetLayerRefs.has(layer.id)) ? '<span class="ly-badge">素材</span>' : '') + (layer.clip ? '<span class="ly-badge clip">C</span>' : '') + (layer.locked ? '<span class="ly-badge lock">L</span>' : '') +
      (layer.mask && layer.mask.exists ? '<span class="ly-badge mask">M</span>' : '') + '</span><span class="ly-blend">' + (BLEND_LABELS[layer.blend] || layer.blend) + '</span>';
    row.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      engine.setActiveLayer(layer.id);
      state.selectedGroupId = null;
      if (engine.getActiveTarget() === 'group-mask' || engine.getActiveTarget() === 'mask') { engine.setActiveTarget('layer'); if (typeof engine.setMaskStrokePaint === 'function') engine.setMaskStrokePaint('white'); setupBrushInput(); }
      renderLayers();
    });
    row.addEventListener('dblclick', (e) => {
      if (e.target.closest('button')) return;
      e.preventDefault();
      engine.setActiveLayer(layer.id);
      state.selectedGroupId = null;
      const tm = state.textLayers.get(layer.id);
      if (tm) {
        openTextComposer(null, { docPoint: { x: tm.x + tm.width / 2, y: tm.y + tm.height / 2 }, layerId: layer.id, text: tm.text, fontSize: tm.fontSize, color: tm.color });
        showToast('编辑文字图层：改完点「更新」');
        return;
      }
      setTool('transform');
      showToast('变换图层：拖动手柄缩放/旋转，拖内部移动；Enter 提交 / Esc 取消');
    });
    row.querySelector('.ly-name').addEventListener('dblclick', (e) => {
      e.stopPropagation();
      const nameEl = e.currentTarget;
      const input = document.createElement('input');
      input.type = 'text';
      input.value = layer.name;
      input.style.cssText = 'width:100%;font-size:12px;padding:2px 4px;border-radius:4px;border:1px solid #6AA6FF;background:#0b1220;color:#dbe7f5';
      nameEl.replaceWith(input);
      input.focus(); input.select();
      let done = false;
      const commit = (ok) => {
        if (done) return; done = true;
        const v = input.value.trim();
        if (ok && v) {
          const l = engine.layers.find((x) => x.id === layer.id);
          if (l) l.name = v;
          scheduleProjectAutosave();
        }
        renderLayers();
      };
      input.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); commit(true); } else if (ev.key === 'Escape') { ev.preventDefault(); commit(false); } });
      input.addEventListener('blur', () => commit(true));
    });
    row.querySelector('.ly-eye').addEventListener('click', (e) => { e.stopPropagation(); engine.setLayerVisible(layer.id, !layer.visible); renderLayers(); scheduleProjectAutosave(); });
    row.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/layer', layer.id); e.dataTransfer.effectAllowed = 'move'; row.classList.add('dragging'); });
    row.addEventListener('dragend', () => row.classList.remove('dragging'));
    host.append(row);
  };
  for (const g of doc.groups) {
    const row = document.createElement('div');
    row.className = 'layer-row group-row' + (state.selectedGroupId === g.id ? ' active' : '');
    row.dataset.groupId = g.id;
    const gmask = g.mask && g.mask.exists;
    row.innerHTML = '<button class="ly-collapse" title="折叠/展开">' + (g.collapsed ? '▸' : '▾') + '</button><button class="ly-eye" title="组显示/隐藏">' + (g.visible ? '👁' : '◌') + '</button>' +
      '<span class="ly-thumb group-mask-thumb" data-gid="' + g.id + '">' + (gmask ? 'M' : '▧') + '</span>' +
      '<span class="ly-name">' + escapeHtml(g.name) + '</span><span class="ly-badges">' +
      (g.clip ? '<span class="ly-badge clip">C</span>' : '') + (gmask ? '<span class="ly-badge mask ' + (g.mask.enabled === false ? 'off' : '') + '">M' + (g.mask.enabled === false ? '×' : '') + '</span>' : '') +
      '</span><span class="ly-blend">' + Math.round((g.opacity == null ? 1 : g.opacity) * 100) + '%</span>' +
      '<button class="ly-gmask" title="编辑组蒙版" data-gid="' + g.id + '">' + (gmask ? (engine.getActiveTarget() === 'group-mask' && engine.getActiveGroup() === g.id ? '蒙版✓' : '蒙版') : '+蒙版') + '</button>' +
      '<button class="ly-gclip" title="组剪贴（以组下方图层为基底）" data-gid="' + g.id + '">C' + (g.clip ? '✓' : '') + '</button>';
    row.addEventListener('click', (e) => { if (e.target.closest('button')) return; state.selectedGroupId = g.id; renderLayers(); });
    row.querySelector('.ly-collapse').addEventListener('click', (e) => { e.stopPropagation(); g.collapsed = !g.collapsed; engine.presentFull(); renderLayers(); });
    row.querySelector('.ly-eye').addEventListener('click', (e) => { e.stopPropagation(); g.visible = !g.visible; engine.presentFull(); renderLayers(); scheduleProjectAutosave(); });
    row.querySelector('.ly-gmask').addEventListener('click', (e) => { e.stopPropagation(); editGroupMaskUI(g.id); });
    row.querySelector('.ly-gclip').addEventListener('click', (e) => { e.stopPropagation(); toggleGroupClipUI(g.id); });
    if (gmask) renderGroupMaskThumb(g);
    row.addEventListener('dragover', (e) => { e.preventDefault(); row.classList.add('drop-target'); });
    row.addEventListener('dragleave', () => row.classList.remove('drop-target'));
    row.addEventListener('drop', (e) => { e.preventDefault(); row.classList.remove('drop-target'); const id = e.dataTransfer.getData('text/layer'); if (id) assignLayerToGroup(id, g.id); });
    host.append(row);
    if (!g.collapsed) for (const l of doc.layers.filter((x) => x.group === g.id)) addRow(l, true);
  }
  for (const l of doc.layers.filter((x) => !x.group)) addRow(l, false);
  const dropHint = document.createElement('div');
  dropHint.className = 'layer-drop-hint';
  dropHint.textContent = '拖到此处的图层移出组（或拖到组名入组）';
  dropHint.addEventListener('dragover', (e) => { e.preventDefault(); dropHint.classList.add('hover'); });
  dropHint.addEventListener('dragleave', () => dropHint.classList.remove('hover'));
  dropHint.addEventListener('drop', (e) => { e.preventDefault(); dropHint.classList.remove('hover'); const id = e.dataTransfer.getData('text/layer'); if (id) assignLayerToGroup(id, null); });
  host.append(dropHint);
  const lc = $('layerCountSub'); if (lc) lc.textContent = engine.layers.length + '/30';
  renderLayerDetail();
}
function renderLayerDetail() {
  const host = $('layerDetail');
  if (!host) return;
  if (state.selectedGroupId) {
    const g = groupById(state.selectedGroupId);
    if (!g) { state.selectedGroupId = null; return renderLayerDetail(); }
    const gmask = g.mask && g.mask.exists;
    const editingGroupMask = engine.getActiveTarget() === 'group-mask' && engine.getActiveGroup() === g.id;
    host.innerHTML = '<div class="ld-row"><span>组名</span><input type="text" id="ldGroupName" value="' + escapeHtml(g.name) + '"><span class="ld-hint">1 级</span></div>' +
      '<div class="ld-row"><span>不透明</span><input type="range" id="ldGroupOpacity" min="0" max="100" value="' + Math.round((g.opacity == null ? 1 : g.opacity) * 100) + '"><span id="ldGroupOpacityVal">' + Math.round((g.opacity == null ? 1 : g.opacity) * 100) + '%</span></div>' +
      '<div class="ld-actions">' +
      '<button class="btn tiny ' + (editingGroupMask ? 'active' : '') + '" id="ldGroupMaskEdit" title="笔触写入组蒙版（白显示/黑隐藏）">' + (gmask ? (editingGroupMask ? '正在编辑组蒙版' : '编辑组蒙版') : '+组蒙版') + '</button>' +
      '<button class="btn tiny" id="ldGroupMaskToggle" ' + (gmask ? '' : 'disabled') + '>' + (gmask ? (g.mask.enabled === false ? '启用蒙版' : '停用蒙版') : '组蒙版') + '</button>' +
      '<button class="btn tiny" id="ldGroupMaskApply" ' + (gmask ? '' : 'disabled') + '>应用组蒙版</button>' +
      '<button class="btn tiny danger" id="ldGroupMaskRemove" ' + (gmask ? '' : 'disabled') + '>删组蒙版</button>' +
      '<button class="btn tiny ' + (g.clip ? 'active' : '') + '" id="ldGroupClip" title="组下方图层 alpha 作为剪贴基底">组剪贴' + (g.clip ? ' ✓' : '') + '</button>' +
      '<button class="btn tiny" id="ldGroupVisible">' + (g.visible ? '隐藏组' : '显示组') + '</button>' +
      '<button class="btn tiny danger" id="ldGroupDelete">删除组（保留图层）</button></div>' +
      (editingGroupMask ? '<div class="ld-hint">正在编辑组蒙版：画笔/橡皮作用于组蒙版，白色显示、黑色隐藏；点图层或再点按钮退出</div>' : '');
    $('ldGroupName').addEventListener('change', (e) => { g.name = e.target.value.trim() || g.name; engine.presentFull(); renderLayers(); scheduleProjectAutosave(); });
    $('ldGroupOpacity').addEventListener('input', (e) => { g.opacity = clamp(parseInt(e.target.value, 10) / 100, 0, 1); $('ldGroupOpacityVal').textContent = e.target.value + '%'; engine.presentFull(); scheduleProjectAutosave(); });
    $('ldGroupVisible').addEventListener('click', () => { g.visible = !g.visible; engine.presentFull(); renderLayers(); scheduleProjectAutosave(); });
    $('ldGroupDelete').addEventListener('click', () => deleteGroup(g.id));
    $('ldGroupMaskEdit').addEventListener('click', () => editGroupMaskUI(g.id));
    $('ldGroupMaskToggle').addEventListener('click', () => { const next = !(g.mask && g.mask.exists && g.mask.enabled !== false); if (engine.setGroupMaskEnabled(g.id, next)) { commitDocUI(); showToast(next ? '组蒙版已启用' : '组蒙版已停用'); } });
    $('ldGroupMaskApply').addEventListener('click', () => { if (engine.applyGroupMask(g.id)) { commitDocUI(); showToast('组蒙版已应用（混合模式近似）'); } });
    $('ldGroupMaskRemove').addEventListener('click', () => { if (engine.removeGroupMask(g.id)) { if (engine.getActiveGroup() === g.id) { engine.activeGroupId = null; engine.setActiveTarget('layer'); } commitDocUI(); showToast('组蒙版已删除'); } });
    $('ldGroupClip').addEventListener('click', () => toggleGroupClipUI(g.id));
    return;
  }
  const l = layerById(engine.activeLayerId);
  if (!l) { host.innerHTML = '<div class="ld-hint">未选中图层</div>'; return; }
  const groups = engine.getDoc().groups;
  const blendOpts = BLEND_GROUPS.map(([name, list]) => '<optgroup label="' + name + '">' + list.map((m) => '<option value="' + m + '"' + (l.blend === m ? ' selected' : '') + '>' + BLEND_LABELS[m] + '</option>').join('') + '</optgroup>').join('');
  host.innerHTML = '<div class="ld-row"><span>混合</span><select id="ldBlend">' + blendOpts + '</select><span class="ld-hint">16 种</span></div>' +
    '<div class="ld-row"><span>不透明</span><input type="range" id="ldOpacity" min="0" max="100" value="' + Math.round((l.opacity == null ? 1 : l.opacity) * 100) + '"><span id="ldOpacityVal">' + Math.round((l.opacity == null ? 1 : l.opacity) * 100) + '%</span></div>' +
    '<div class="ld-row"><span>组</span><select id="ldGroup"><option value="">顶层（无组）</option>' + groups.map((g) => '<option value="' + g.id + '"' + (l.group === g.id ? ' selected' : '') + '>' + escapeHtml(g.name) + '</option>').join('') + '</select></div>' +
    '<div class="ld-actions">' +
    '<button class="btn tiny ' + (l.clip ? 'active' : '') + '" id="ldClip">剪贴' + (l.clip ? ' ✓' : '') + '</button>' +
    '<button class="btn tiny ' + (l.locked ? 'active' : '') + '" id="ldLock">锁定' + (l.locked ? ' ✓' : '') + '</button>' +
    '<button class="btn tiny" id="ldMaskAdd" ' + (l.mask.exists ? 'disabled' : '') + '>+蒙版</button>' +
    '<button class="btn tiny ' + (l.mask.exists && l.mask.enabled ? 'active' : '') + '" id="ldMaskToggle" ' + (l.mask.exists ? '' : 'disabled') + '>' + (l.mask.exists ? (l.mask.enabled ? '蒙版 ✓' : '蒙版 ✕') : '蒙版') + '</button>' +
    '<button class="btn tiny" id="ldMaskApply" ' + (l.mask.exists ? '' : 'disabled') + '>应用蒙版</button>' +
    '<button class="btn tiny danger" id="ldMaskRemove" ' + (l.mask.exists ? '' : 'disabled') + '>删蒙版</button>' +
    '<button class="btn tiny ' + (engine.getActiveTarget() === 'mask' ? 'active' : '') + '" id="ldTargetMask" ' + (l.mask.exists ? '' : 'disabled') + '>画在蒙版</button>' +
    '</div><div class="ld-hint">' + (engine.getActiveTarget() === 'mask' && l.mask.exists ? '当前笔触写入蒙版（黑白）：白=显示，黑=隐藏' : '当前笔触写入图层内容') + '</div>';
  $('ldBlend').addEventListener('change', (e) => { engine.setLayerBlend(l.id, e.target.value); renderLayers(); scheduleProjectAutosave(); });
  $('ldOpacity').addEventListener('input', (e) => { engine.setLayerOpacity(l.id, parseInt(e.target.value, 10) / 100); $('ldOpacityVal').textContent = e.target.value + '%'; scheduleProjectAutosave(); });
  $('ldGroup').addEventListener('change', (e) => assignLayerToGroup(l.id, e.target.value || null));
  $('ldClip').addEventListener('click', () => { engine.setLayerClip(l.id, !l.clip); renderLayers(); scheduleProjectAutosave(); });
  $('ldLock').addEventListener('click', () => { engine.setLayerLocked(l.id, !l.locked); renderLayers(); scheduleProjectAutosave(); });
  $('ldMaskAdd').addEventListener('click', () => { engine.addMask(l.id); engine.setActiveTarget('mask'); setupBrushInput(); renderLayers(); scheduleProjectAutosave(); showToast('已添加蒙版，笔触写入蒙版（白显示/黑隐藏）'); });
  $('ldMaskToggle').addEventListener('click', () => { engine.setMaskEnabled(l.id, !l.mask.enabled); renderLayers(); scheduleProjectAutosave(); });
  $('ldMaskApply').addEventListener('click', () => applyLayerMask(l.id));
  $('ldMaskRemove').addEventListener('click', () => { engine.removeMask(l.id); engine.setActiveTarget('layer'); setupBrushInput(); renderLayers(); scheduleProjectAutosave(); });
  $('ldTargetMask').addEventListener('click', () => { engine.setActiveTarget(engine.getActiveTarget() === 'mask' ? 'layer' : 'mask'); syncMaskPaintUI(); setupBrushInput(); renderLayers(); const target = engine.getActiveTarget(); $('statusHint').textContent = target === 'mask' ? '蒙版编辑：白=显示 / 黑=隐藏 · ' + (state.tool === 'eraser' ? '橡皮=隐藏' : '画笔=显示') + '（图层蒙版）' : '已退出图层蒙版编辑'; });
}
function syncMaskPaintUI() {
  const target = engine.getActiveTarget();
  if (target !== 'mask' && target !== 'group-mask') {
    if (typeof engine.setMaskStrokePaint === 'function') engine.setMaskStrokePaint('white');
    return null;
  }
  const paint = state.tool === 'eraser' ? 'black' : 'white';
  if (typeof engine.setMaskStrokePaint === 'function') engine.setMaskStrokePaint(paint);
  return '蒙版编辑：白=显示 / 黑=隐藏 · ' + (paint === 'black' ? '橡皮=隐藏' : '画笔=显示') + (target === 'group-mask' ? '（组蒙版）' : '（图层蒙版）');
}
function editGroupMaskUI(groupId) {
  const g = groupById(groupId);
  if (!g) return;
  if (!g.mask || !g.mask.exists) {
    engine.addGroupMask(groupId);
    commitDocUI();
  }
  engine.setActiveGroup(groupId);
  if (engine.getActiveTarget() === 'group-mask' && engine.getActiveGroup() === groupId) {
    engine.setActiveTarget('layer');
    if (typeof engine.setMaskStrokePaint === 'function') engine.setMaskStrokePaint('white');
    $('statusHint').textContent = '已退出组蒙版编辑';
  } else {
    engine.setActiveTarget('group-mask');
    syncMaskPaintUI();
    $('statusHint').textContent = '蒙版编辑：白=显示 / 黑=隐藏 · ' + (state.tool === 'eraser' ? '橡皮=隐藏' : '画笔=显示') + '（组蒙版）';
    showToast('正在编辑组蒙版（' + g.name + '）');
  }
  setupBrushInput();
  renderLayers();
}
function toggleGroupClipUI(groupId) {
  const g = groupById(groupId);
  if (!g) return;
  const ok = engine.setGroupClip(groupId, !g.clip);
  if (ok) { commitDocUI(); showToast(g.clip ? '组剪贴已开启（以组下方图层为基底）' : '组剪贴已关闭'); }
}
function renderGroupMaskThumb(g) {
  const host = document.querySelector('.group-mask-thumb[data-gid="' + g.id + '"]');
  if (!host || !engine.maskStore) return;
  if (!engine.maskStore.count(g.id)) return;
  try {
    const CK = engine.CK; const w = engine.width; const h = engine.height; const T = engine.tileSize;
    const surface = CK.MakeRenderTarget(engine.gr, w, h);
    const c = surface.getCanvas();
    c.clear(CK.TRANSPARENT);
    for (const key of engine.maskStore.listTiles(g.id)) {
      const t = engine.maskStore.get(g.id, key); if (!t) continue;
      const parts = key.split(',').map(Number);
      c.drawImage(t.image, parts[0] * T, parts[1] * T);
    }
    surface.flush();
    const snap = surface.makeImageSnapshot();
    const bytes = snap.encodeToBytes();
    try { snap.delete(); } catch (e) {}
    try { surface.delete(); } catch (e) {}
    const blob = new Blob([bytes], { type: 'image/png' });
    createImageBitmap(blob).then((bmp) => {
      host.textContent = '';
      const cv = document.createElement('canvas'); cv.width = 22; cv.height = 22;
      const ctx = cv.getContext('2d'); ctx.drawImage(bmp, 0, 0, 22, 22);
      host.append(cv);
      try { bmp.close(); } catch (e) {}
    }).catch(() => {});
  } catch (e) { /* ignore thumbnail failure */ }
}
function assignLayerToGroup(layerId, groupId) {
  engine.moveToGroup(layerId, groupId || null);
  commitDocUI();
}
function addGroupUI() {
  const g = engine.addGroup('组 ' + (engine.groups.length + 1));
  state.selectedGroupId = g.id;
  commitDocUI();
  return g;
}
function deleteGroup(groupId) {
  const g = groupById(groupId); if (!g) return;
  for (const l of engine.layers) if (l.group === groupId) l.group = null;
  engine.groups.splice(engine.groups.indexOf(g), 1);
  state.selectedGroupId = null;
  commitDocUI();
}
function applyLayerMask(layerId) {
  const l = layerById(layerId);
  if (!l || !l.mask.exists) return;
  const store = engine.store; const maskStore = engine.maskStore; const CK = engine.CK;
  for (const key of store.listTiles(layerId)) {
    const mt = maskStore.get(layerId, key);
    store.withCanvas(layerId, key, (c) => {
      if (!mt) { c.clear(CK.TRANSPARENT); return; }
      const paint = new CK.Paint();
      paint.setBlendMode(CK.BlendMode.DstIn);
      c.drawImage(mt.image, 0, 0, paint);
      paint.delete();
    });
    store.refreshImage(layerId, key);
  }
  engine.removeMask(layerId);
  engine.setActiveTarget('layer');
  renderAll(); scheduleProjectAutosave();
  showToast('蒙版已应用到图层像素');
}
function addLayerUI() {
  const group = state.selectedGroupId || null;
  engine.addLayer({ name: '图层 ' + (engine.layers.length + 1), group });
  state.selectedGroupId = null;
  commitDocUI();
}
function duplicateLayerUI() {
  const l = layerById(engine.activeLayerId); if (!l) return;
  engine.duplicateLayer(l.id);
  commitDocUI();
}
function mergeDownUI() {
  const id = engine.activeLayerId;
  if (!engine.mergeDown(id)) showToast('下方没有可合并图层（需同组相邻）', true);
  else commitDocUI();
}
async function flattenUI() {
  engine.flattenAll();
  renderAll(); scheduleProjectAutosave();
  showToast('已拼合为单图层（可 undo）');
}
function moveLayerUI(dir) {
  engine.moveLayer(engine.activeLayerId, dir);
  commitDocUI();
}
function deleteLayerUI() {
  if (engine.layers.length <= 1) { showToast('至少保留一个图层', true); return; }
  if (!engine.deleteLayer(engine.activeLayerId)) { showToast('删除失败', true); return; }
  commitDocUI();
}
function bindLayerControls() {
  $('btnAddLayer').addEventListener('click', addLayerUI);
  $('btnAddGroup').addEventListener('click', addGroupUI);
  $('btnLayerUp').addEventListener('click', () => moveLayerUI(1));
  $('btnLayerDown').addEventListener('click', () => moveLayerUI(-1));
  $('btnDuplicateLayer').addEventListener('click', duplicateLayerUI);
  $('btnMergeDown').addEventListener('click', mergeDownUI);
  $('btnFlatten').addEventListener('click', () => flattenUI().catch((e) => showToast(e.message, true)));
  $('btnLayerDelete').addEventListener('click', deleteLayerUI);
  $('btnCollapseLayers') && $('btnCollapseLayers').addEventListener('click', () => { const list = $('layerList'); list.style.display = list.style.display === 'none' ? '' : 'none'; });
}

/* ---------------- T61 项目保存/打开（.mozheng + IndexedDB 自动保存） ---------------- */
const IDB_NAME = 'mozheng.v2.projects';
const IDB_STORE = 'autosave';
let idbPromise = null;
function idbOpen() {
  if (!idbPromise) {
    idbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains(IDB_STORE)) req.result.createObjectStore(IDB_STORE); };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return idbPromise;
}
async function idbPut(key, value) {
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).put(value, key);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}
async function idbGet(key) {
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, 'readonly');
    const req = tx.objectStore(IDB_STORE).get(key);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}
async function idbDelete(key) {
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).delete(key);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}
let autosaveTimer = null;
let autosaveBusy = false;
function setProjectStatus(msg) { const el = $('projectStatus'); if (el) el.textContent = msg; }
function scheduleProjectAutosave() {
  clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(async () => {
    if (autosaveBusy || !engine) return;
    if (ASYNC_TASK.active) { autosaveTimer = setTimeout(() => scheduleProjectAutosave(), 1400); return; }
    autosaveBusy = true;
    try {
      let blob; let compressed = true;
      let usedAsync = false;
      if (typeof engine.saveDocAsync === 'function' && typeof Worker !== 'undefined' && typeof OffscreenCanvas !== 'undefined') {
        try { blob = await engine.saveDocAsync({ compress: true }); usedAsync = true; } catch (e) { usedAsync = false; }
      }
      if (!blob) {
        try { blob = await engine.getDocFileBlob({ compress: true }); }
        catch (e) { compressed = false; blob = await engine.getDocFileBlob({ compress: false }); }
      }
      await idbPut('current', { blob, compressed, bytes: blob.size, savedAt: Date.now(), name: '雾中山谷 · v2', async: usedAsync });
      const t = new Date().toLocaleTimeString('zh-CN', { hour12: false });
      setProjectStatus('已自动保存 ' + t + ' · ' + (compressed ? 'v2 gzip' : 'v1 JSON') + ' · ' + Math.round(blob.size / 1024) + ' KB');
      const ss = $('saveState'); if (ss) ss.title = '已自动保存 ' + t;
    } catch (e) { console.warn('[app] autosave failed', e); setProjectStatus('自动保存失败：' + (e.message || e)); }
    finally { autosaveBusy = false; }
  }, 1200);
}
async function restoreProject() {
  try {
    const rec = await idbGet('current');
    const input = rec && (rec.blob || rec.json);
    if (input) {
      await engine.deserializeDocAuto(input);
      applyPresentStrategyForSize(engine.width, engine.height);
      state.selection = null; state.analysis = null; state.directions = null; state.candidates = null;
      drawSelection();
      const kb = Math.round(((rec.bytes || (rec.blob && rec.blob.size) || (rec.json || '').length) / 1024));
      setProjectStatus('已恢复自动保存 · ' + new Date(rec.savedAt).toLocaleString('zh-CN', { hour12: false }) + ' · ' + (rec.compressed === false ? 'v1' : 'v2 gzip') + ' ' + kb + ' KB');
      showToast('已恢复上次自动保存的完整图层结构');
      return true;
    }
  } catch (e) { console.warn('[app] restore autosave failed', e); }
  await restoreSnapshot();
  return false;
}
function projectFileName() {
  const d = new Date(); const p = (n) => String(n).padStart(2, '0');
  return 'inkproof-' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()) + '.mozheng';
}
async function saveProjectDownload() {
  if (ASYNC_TASK.active) { showToast('已有导出/保存任务进行中，请先取消或等待完成'); return null; }
  const btn = document.getElementById('btnSaveProject'); if (btn) btn.disabled = true;
  let ac = null;
  const canAsync = typeof engine.saveDocAsync === 'function' && typeof Worker !== 'undefined' && typeof OffscreenCanvas !== 'undefined';
  if (canAsync) {
    ac = new AbortController();
    showAsyncTask('保存项目', () => { try { ac.abort(); } catch (e) {} try { engine.cancelSave && engine.cancelSave(); } catch (e) {} }, { mode: 'save' });
  } else {
    showAsyncTask('保存项目（兼容模式）', null, { mode: 'save' });
  }
  try {
    let blob; let compressed = true;
    if (canAsync) {
      try { blob = await engine.saveDocAsync({ compress: true, signal: ac.signal, onProgress: updateAsyncTask }); }
      catch (e) {
        if (e && e.name === 'AbortError') { showToast('已取消保存'); return null; }
        console.warn('[app] async save failed, fallback', e);
        try { blob = await engine.getDocFileBlob({ compress: true }); } catch (e2) { compressed = false; blob = await engine.getDocFileBlob({ compress: false }); }
        showToast('异步保存不可用，已降级为同步保存');
      }
    } else {
      try { blob = await engine.getDocFileBlob({ compress: true }); }
      catch (e) { compressed = false; blob = await engine.getDocFileBlob({ compress: false }); showToast('当前浏览器不支持压缩保存，已保存 v1 兼容格式', true); }
    }
    if (!blob) return null;
    downloadBlob(projectFileName(), blob);
    await idbPut('current', { blob, compressed, bytes: blob.size, savedAt: Date.now(), name: '雾中山谷 · v2' });
    const kb = Math.round(blob.size / 1024);
    setProjectStatus('已保存 .mozheng · ' + (compressed ? 'v2 gzip' : 'v1 JSON') + ' ' + kb + ' KB');
    showToast('项目已保存为 .mozheng（' + (compressed ? 'v2 gzip' : 'v1') + ' · ' + kb + ' KB）');
    return { blob, compressed, bytes: blob.size };
  } catch (e) { if (!(e && e.name === 'AbortError')) showToast('保存失败：' + (e.message || e), true); return null; }
  finally { hideAsyncTask(); if (btn) btn.disabled = false; }
}
function validateProjectText(text) {
  let container;
  try { container = JSON.parse(text); } catch (e) { throw new Error('不是有效的 JSON 文件'); }
  if (!container || container.format !== 'mozheng') throw new Error('不是墨证 .mozheng 项目（format 字段缺失）');
  if (!(container.version >= 1 && container.version <= 1)) throw new Error('不支持的 .mozheng 版本：v' + container.version + '（当前 v1）');
  if (!container.doc || !container.doc.layers || !Array.isArray(container.doc.layers)) throw new Error('.mozheng 缺少图层数据（doc.layers）');
  return container;
}
async function applyLoadedDoc(doc) {
  applyPresentStrategyForSize(engine.width, engine.height);
  state.selectedGroupId = null; state.selection = null; state.analysis = null; state.directions = null; state.candidates = null;
  engine.setActiveTarget('layer'); engine.activeGroupId = null;
  syncTextLayersFromEngine();
  drawSelection(); renderAll();
}
async function loadProjectData(input, opts = {}) {
  let compressed = false;
  try {
    let bytes = null;
    if (input instanceof Blob) bytes = new Uint8Array(await input.arrayBuffer());
    else if (input instanceof ArrayBuffer) bytes = new Uint8Array(input);
    else if (input instanceof Uint8Array) bytes = input;
    if (bytes && bytes.length >= 2) compressed = bytes[0] === 0x1f && bytes[1] === 0x8b;
  } catch (e) { /* ignore */ }
  const doc = await engine.deserializeDocAuto(input);
  await applyLoadedDoc(doc);
  setProjectStatus('已打开项目 · ' + doc.layers.length + ' 图层 / ' + doc.groups.length + ' 组' + (compressed ? ' · v2 gzip' : ' · v1 JSON'));
  showToast('项目已打开：' + doc.layers.length + ' 图层 / ' + doc.groups.length + ' 组（' + (compressed ? 'v2 gzip' : 'v1 JSON') + '）');
  if (!opts.silent && state.demo.active) pauseDemo(true);
  return doc;
}
async function loadProjectText(text, opts = {}) { return loadProjectData(text, opts); }
async function loadProjectFile(file) {
  try { return await loadProjectData(file); }
  catch (e) { showToast('打开失败：' + (e.message || e), true); return null; }
}
async function getAutosaveMeta() {
  try {
    const r = await idbGet('current');
    if (!r) return null;
    return { savedAt: r.savedAt, bytes: r.bytes || (r.blob && r.blob.size) || (r.json || '').length, compressed: r.compressed !== false, name: r.name };
  } catch (e) { return null; }
}

/* ---------------- T61 PSD 导入/导出 ---------------- */
let psdMods = null;
async function loadPsdModules() {
  if (psdMods) return psdMods;
  const [importer, exporter, bridge, model] = await Promise.all([
    import('../../psd/src/importer.js'),
    import('../../psd/src/exporter.js'),
    import('../../psd/src/v2doc-bridge.js'),
    import('../../psd/src/model.js'),
  ]);
  psdMods = { importer, exporter, bridge, model };
  return psdMods;
}
function ensureAgPsd() {
  if (!window.agPsd) throw new Error('ag-psd 未加载（v2/psd/vendor/ag-psd/bundle.js）');
  return window.agPsd;
}
function fitCanvasToDoc(src, width, height) {
  if (src.width === width && src.height === height) return src;
  const c = document.createElement('canvas'); c.width = width; c.height = height;
  const ctx = c.getContext('2d'); ctx.imageSmoothingEnabled = true; ctx.drawImage(src, 0, 0, width, height);
  return c;
}
function writeCanvasToStore(store, layerId, canvas) {
  const CK = engine.CK;
  const T = engine.tileSize;
  const img = CK.MakeImageFromCanvasImageSource(canvas);
  for (let ty = 0; ty < store.tilesH; ty += 1) {
    for (let tx = 0; tx < store.tilesW; tx += 1) {
      const key = tx + ',' + ty;
      store.withCanvas(layerId, key, (c) => {
        c.clear(CK.TRANSPARENT);
        c.drawImage(img, -tx * T, -ty * T);
      });
      store.refreshImage(layerId, key);
    }
  }
  try { img.delete(); } catch (e) { /* ignore */ }
}
async function psdImportBuffer(buffer, name) {
  const agPsd = ensureAgPsd();
  const mods = await loadPsdModules();
  const imported = mods.importer.importPsd(buffer, agPsd);
  const psdDoc = imported.doc;
  const v2doc = mods.bridge.psdDocToV2Doc(psdDoc);
  v2doc.width = engine.width; v2doc.height = engine.height;
  // 收集 PSD 叶子层（按 bridge 顺序）
  const leaves = [];
  const walk = (nodes) => { for (const n of nodes) { if (n.type === 'group') walk(n.children || []); else leaves.push(n); } };
  walk(psdDoc.children || []);
  engine.deserializeDoc(JSON.stringify({ format: 'mozheng', version: 1, doc: v2doc, tiles: {}, masks: {} }));
  for (let i = 0; i < engine.layers.length; i += 1) {
    const layer = engine.layers[i]; const node = leaves[i];
    if (!node) continue;
    if (node.canvas) writeCanvasToStore(engine.store, layer.id, fitCanvasToDoc(node.canvas, engine.width, engine.height));
    if (node.mask) {
      writeCanvasToStore(engine.maskStore, layer.id, fitCanvasToDoc(node.mask, engine.width, engine.height));
      const meta = engine.layers.find((l) => l.id === layer.id); if (meta) meta.mask = { exists: true, enabled: true };
    }
  }
  engine.presentFull(); engine.setActiveTarget('layer');
  renderAll(); scheduleProjectAutosave();
  state.psdFidelity = imported.fidelity;
  const items = imported.fidelity.items || [];
  const summary = imported.fidelity.summary || { itemCount: items.length, byFeature: {} };
  setProjectStatus('PSD 导入：' + v2doc.layers.length + ' 图层 / ' + v2doc.groups.length + ' 组 · 保真项 ' + summary.itemCount);
  showToast('PSD 已导入：' + v2doc.layers.length + ' 图层 / ' + v2doc.groups.length + ' 组' + (summary.itemCount ? '（' + summary.itemCount + ' 项已记录保真差异）' : ''));
  return { doc: v2doc, fidelity: imported.fidelity, layers: v2doc.layers.length, groups: v2doc.groups.length, items: items.length };
}
async function psdFileImport(file) {
  const buffer = await file.arrayBuffer();
  return psdImportBuffer(buffer, file.name);
}
async function storeToCanvas(store, layerId) {
  const CK = engine.CK; const w = engine.width; const h = engine.height; const T = engine.tileSize;
  const surface = CK.MakeRenderTarget(engine.gr, w, h);
  const c = surface.getCanvas();
  c.clear(CK.TRANSPARENT);
  for (const key of store.listTiles(layerId)) {
    const t = store.get(layerId, key); if (!t) continue;
    const parts = key.split(',').map(Number);
    c.drawImage(t.image, parts[0] * T, parts[1] * T);
  }
  surface.flush();
  const snap = surface.makeImageSnapshot();
  const bytes = snap.encodeToBytes();
  try { snap.delete(); } catch (e) {}
  try { surface.delete(); } catch (e) {}
  const blob = new Blob([bytes], { type: 'image/png' });
  const bmp = await createImageBitmap(blob);
  const canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
  canvas.getContext('2d').drawImage(bmp, 0, 0);
  try { bmp.close(); } catch (e) {}
  return canvas;
}
async function psdExportBuffer(opts = {}) {
  const { signal, onProgress } = opts;
  const checkAbort = () => { if (signal && signal.aborted) throw abortError(); };
  const agPsd = ensureAgPsd();
  const mods = await loadPsdModules();
  const doc = engine.getDoc();
  const layerCanvases = new Map();
  const maskCanvases = new Map();
  const total = doc.layers.length * 2 + 1;
  let done = 0;
  const progress = () => { if (onProgress) onProgress({ phase: 'package', done, total }); };
  for (const l of doc.layers) {
    checkAbort();
    const cv = await storeToCanvas(engine.store, l.id);
    layerCanvases.set(l.id, cv); done += 1; progress(); await rafYield();
    if (l.mask && l.mask.exists) {
      checkAbort();
      const mv = await storeToCanvas(engine.maskStore, l.id);
      maskCanvases.set(l.id, mv);
    }
    done += 1; progress(); await rafYield();
  }
  checkAbort();
  const children = [];
  const groupChildren = new Map();
  for (const g of doc.groups) {
    const node = { type: 'group', name: g.name, visible: g.visible !== false, opacity: g.opacity == null ? 1 : g.opacity, blendMode: 'pass through', clip: false, mask: null, children: [] };
    groupChildren.set(g.id, node.children); children.push(node);
  }
  for (const l of doc.layers) {
    const node = {
      type: 'layer', name: l.name, visible: l.visible !== false, opacity: l.opacity == null ? 1 : l.opacity,
      blendMode: (mods.model.INTERNAL_TO_PSD && mods.model.INTERNAL_TO_PSD[l.blend]) || 'normal',
      clip: !!l.clip, mask: l.mask && l.mask.exists ? (maskCanvases.get(l.id) || null) : null,
      canvas: layerCanvases.get(l.id), children: [],
    };
    if (l.group && groupChildren.has(l.group)) groupChildren.get(l.group).push(node); else children.push(node);
  }
  checkAbort();
  const psdDoc = { width: engine.width, height: engine.height, bitsPerChannel: 8, colorMode: 3, children };
  const buffer = mods.exporter.exportPsd(psdDoc, agPsd);
  done += 1; progress();
  return {
    buffer,
    summary: { layers: doc.layers.length, groups: doc.groups.length, masks: doc.layers.filter((l) => l.mask && l.mask.exists).length, blend: doc.layers.filter((l) => l.blend !== 'normal').length, bytes: buffer.byteLength },
  };
}
async function exportPsdDownload() {
  if (ASYNC_TASK.active) { showToast('已有导出/保存任务进行中，请先取消或等待完成'); return null; }
  const btn = document.getElementById('btnExportPsd'); if (btn) btn.disabled = true;
  const gmaskCount = engine.getDoc().groups.filter((g) => g.mask && g.mask.exists).length;
  const note = gmaskCount ? '（组蒙版像素为已知限制）' : '';
  const canAsync = typeof engine.exportPSDAsync === 'function' && typeof Worker !== 'undefined' && typeof OffscreenCanvas !== 'undefined';
  let ac = null;
  try {
    if (canAsync) {
      ac = new AbortController();
      showAsyncTask('导出 PSD', () => { try { ac.abort(); } catch (e) {} try { engine.cancelPSDExport && engine.cancelPSDExport(); } catch (e) {} }, { mode: 'psd' });
      try {
        const blob = await engine.exportPSDAsync({ signal: ac.signal, onProgress: updateAsyncTask });
        downloadBlob('inkproof-' + Date.now().toString(36) + '.psd', blob);
        setProjectStatus('PSD 已导出 · ' + Math.round(blob.size / 1024) + ' KB');
        showToast('PSD 已导出 · ' + Math.round(blob.size / 1024) + ' KB ' + note);
        return { blob, bytes: blob.size };
      } catch (e) {
        if (e && e.name === 'AbortError') { showToast('已取消 PSD 导出'); return null; }
        console.warn('[app] async PSD failed, fallback', e);
        showToast('异步 PSD 不可用，已降级为同步导出');
      }
    }
    showAsyncTask('导出 PSD（兼容模式）', null, { mode: 'psd' });
    const res = await psdExportBuffer({});
    downloadBlob('inkproof-' + Date.now().toString(36) + '.psd', new Blob([res.buffer], { type: 'image/vnd.adobe.photoshop' }));
    setProjectStatus('PSD 已导出：' + res.summary.layers + ' 图层 / ' + res.summary.groups + ' 组' + (gmaskCount ? '（组蒙版像素 PSD 暂不支持）' : ''));
    showToast('PSD 已导出：' + res.summary.layers + ' 图层 / ' + res.summary.groups + ' 组' + note);
    return { bytes: res.buffer.byteLength };
  } catch (e) {
    if (!(e && e.name === 'AbortError')) showToast('PSD 导出失败：' + (e.message || e), true);
    return null;
  } finally { hideAsyncTask(); if (btn) btn.disabled = false; }
}
function importPsdFileInput(file) {
  psdFileImport(file).catch((e) => { console.error(e); showToast('PSD 导入失败：' + (e.message || e), true); });
}
function renderHistoryMenu() {
  const host = document.getElementById('historyList');
  if (!host || !engine) return;
  let list = [];
  try { list = engine.getHistorySummary ? engine.getHistorySummary(10) : []; } catch (e) { list = []; }
  const depth = engine.undoManager ? engine.undoManager.undoStack.length : 0;
  host.innerHTML = list.length
    ? list.slice().reverse().map((e) => '<button class="history-row' + (e.depth === depth ? ' current' : '') + '" data-history-depth="' + e.depth + '"><span>' + escapeHtml(e.label) + '</span><span class="h-depth">#' + e.depth + '</span></button>').join('')
    : '<div class="hint" style="padding:2px 7px">还没有可撤销的操作</div>';
  host.querySelectorAll('[data-history-depth]').forEach((btn) => btn.addEventListener('click', () => {
    const target = parseInt(btn.dataset.historyDepth, 10);
    const cur = engine.undoManager ? engine.undoManager.undoStack.length : 0;
    if (Number.isFinite(target) && target < cur) {
      const n = engine.undoToDepth ? engine.undoToDepth(target) : 0;
      renderAll(); renderHistoryMenu(); scheduleProjectAutosave();
      showToast('已回退 ' + n + ' 步（可 Ctrl+Y 重做）');
    }
  }));
}
async function undoUI() {
  if (state.strokeActive) { showToast('正在绘制，先抬笔再撤销', true); return; }
  if (engine.undo()) { syncTextLayersFromEngine(); renderAll(); renderHistoryMenu(); scheduleProjectAutosave(); }
}
async function redoUI() {
  if (engine.redo()) { syncTextLayersFromEngine(); renderAll(); renderHistoryMenu(); scheduleProjectAutosave(); }
}
function initTooltips() {
  if (document.getElementById('uiTooltip')) return;
  const tip = document.createElement('div');
  tip.id = 'uiTooltip';
  tip.setAttribute('role', 'tooltip');
  tip.hidden = true;
  document.body.appendChild(tip);
  let timer = null;
  let current = null;
  let savedTitle = '';
  const hide = () => {
    if (timer) { clearTimeout(timer); timer = null; }
    tip.hidden = true;
    if (current && savedTitle) { try { current.setAttribute('title', savedTitle); } catch (e) { /* ignore */ } }
    current = null; savedTitle = '';
  };
  const show = (el) => {
    const text = savedTitle || el.getAttribute('title') || el.getAttribute('aria-label');
    if (!text) return;
    tip.textContent = text;
    tip.hidden = false;
    const r = el.getBoundingClientRect();
    const tr = tip.getBoundingClientRect();
    let x = r.left + r.width / 2 - tr.width / 2;
    let y = r.bottom + 10;
    x = Math.max(8, Math.min(window.innerWidth - tr.width - 8, x));
    if (y + tr.height > window.innerHeight - 8) y = r.top - tr.height - 10;
    tip.style.left = Math.round(x) + 'px';
    tip.style.top = Math.round(y) + 'px';
  };
  document.addEventListener('pointerover', (e) => {
    const el = e.target && e.target.closest ? e.target.closest('[title]') : null;
    if (!el || el === current) return;
    hide();
    current = el; savedTitle = el.getAttribute('title') || '';
    if (!savedTitle) return;
    el.removeAttribute('title');
    timer = setTimeout(() => { timer = null; show(el); }, 380);
  }, true);
  document.addEventListener('pointerout', (e) => {
    if (!current) return;
    const related = e.relatedTarget;
    if (related && current.contains(related)) return;
    hide();
  }, true);
  document.addEventListener('pointerdown', hide, true);
  window.addEventListener('blur', hide);
  window.addEventListener('scroll', hide, true);
}
function setAdjustSliders(params) {
  const p = params || {};
  const map = { adjBrightness: Math.round(Number(p.brightness || 0) * 100), adjContrast: Math.round(Number(p.contrast || 0) * 100), adjSaturation: Math.round((Number(p.saturation == null ? 1 : p.saturation) - 1) * 100), adjHue: Math.round(Number(p.hue || 0)) };
  for (const [id, v] of Object.entries(map)) { const el = document.getElementById(id); if (el) el.value = String(v); }
  syncAdjustOutputs();
}
function buildSelectionMaskDataUrl(sel) {
  const c = document.createElement('canvas'); c.width = engine.width; c.height = engine.height;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  if (sel) {
    const x = Math.max(0, Math.round(sel.x)); const y = Math.max(0, Math.round(sel.y));
    const w = Math.min(c.width - x, Math.max(0, Math.round(sel.width))); const h = Math.min(c.height - y, Math.max(0, Math.round(sel.height)));
    if (w > 0 && h > 0) { ctx.fillStyle = '#fff'; ctx.fillRect(x, y, w, h); }
  }
  return c.toDataURL('image/png');
}
/** 与 buildSelectionMaskDataUrl 同口径的包围盒，供 setMaskFromDataUrl 只写相交 tile（T117 P1-5） */
function selectionMaskBBox(sel) {
  if (!sel) return null;
  const x = Math.max(0, Math.round(sel.x)), y = Math.max(0, Math.round(sel.y));
  const w = Math.min(engine.width - x, Math.max(0, Math.round(sel.width)));
  const h = Math.min(engine.height - y, Math.max(0, Math.round(sel.height)));
  return w > 0 && h > 0 ? [x, y, w, h] : null;
}
function openAdjustModal(opts = {}) {
  const l = activeLayer();
  if (!l) { showToast('先选中一个图层', true); return; }
  if (l.locked) { showToast('图层已锁定，无法调整', true); return; }
  const nameEl = document.getElementById('adjustLayerName');
  const isAdjust = l.kind === 'adjust' && l.adjust;
  if (nameEl) nameEl.textContent = (l.name || '—') + (isAdjust ? '（调整层 · 快照 · 参数可重开）' : '');
  for (const id of ['adjBrightness', 'adjContrast', 'adjSaturation', 'adjHue']) { const el = document.getElementById(id); if (el) el.value = '0'; }
  if (isAdjust) setAdjustSliders(l.adjust);
  syncAdjustOutputs();
  const mask = document.getElementById('adjMaskSelection');
  const maskHint = document.getElementById('adjMaskHint');
  const hasSel = !!(state.selection && state.selection.width > 0 && state.selection.height > 0);
  if (mask) { mask.checked = !!(isAdjust && l.mask && l.mask.exists); mask.disabled = !hasSel; }
  // P2-2：文案必须与「取消勾选 = 移除 mask」的实现一致，不能暗示「不勾选 = 保留旧限制」。
  if (maskHint) maskHint.textContent = hasSel ? (isAdjust ? '取消勾选将移除蒙版限制；勾选则替换为当前选区' : '只影响选框内像素') : '先框选一块区域';
  const apply = document.getElementById('btnAdjustApply'); if (apply) apply.textContent = isAdjust ? '更新调整层' : '应用为新图层';
  openModal('adjustModal');
}
function syncAdjustOutputs() {
  const map = { adjBrightness: ['adjBrightnessVal', ''], adjContrast: ['adjContrastVal', ''], adjSaturation: ['adjSaturationVal', ''], adjHue: ['adjHueVal', '°'] };
  for (const [id, [outId, suffix]] of Object.entries(map)) {
    const el = document.getElementById(id); const out = document.getElementById(outId);
    if (el && out) out.textContent = el.value + suffix;
  }
}
function openCanvasResizeModal(mode = 'resize') {
  const sel = state.selection || selectionOrDefault();
  if (mode === 'crop' && !state.selection) { showToast('先框选要保留的区域，再裁剪画布', true); return; }
  const w = mode === 'crop' ? Math.max(16, Math.round(sel.width)) : engine.width;
  const h = mode === 'crop' ? Math.max(16, Math.round(sel.height)) : engine.height;
  state.pendingResize = { mode, offsetX: mode === 'crop' ? -Math.round(sel.x) : 0, offsetY: mode === 'crop' ? -Math.round(sel.y) : 0 };
  const title = document.getElementById('canvasResizeTitle');
  const sub = document.getElementById('canvasResizeSub');
  const warning = document.getElementById('resizeWarning');
  const anchor = document.getElementById('resizeAnchor');
  if (title) title.textContent = mode === 'crop' ? '裁剪画布' : '画布尺寸';
  if (sub) sub.textContent = mode === 'crop' ? '保留当前选区内的画面；选区外像素会被裁掉，图层结构保留。' : '改变画布尺寸并保留图层；画布越大占用内存越高。';
  if (warning) warning.textContent = mode === 'crop' ? '注意：裁剪会重建像素存储并清空撤销历史；裁掉的像素不保留，建议先保存项目。' : '注意：画布尺寸变更会重建像素存储并清空撤销历史；图层内容按定位保留。';
  const wi = document.getElementById('resizeWidth'); if (wi) wi.value = String(w);
  const hi = document.getElementById('resizeHeight'); if (hi) hi.value = String(h);
  if (anchor) { anchor.value = mode === 'crop' ? 'top-left' : 'center'; anchor.disabled = mode === 'crop'; }
  openModal('canvasResizeModal');
}
async function applyCanvasResizeFromModal() {
  const mode = (state.pendingResize && state.pendingResize.mode) || 'resize';
  const w = clamp(parseInt((document.getElementById('resizeWidth') || {}).value, 10) || engine.width, 16, 4096);
  const h = clamp(parseInt((document.getElementById('resizeHeight') || {}).value, 10) || engine.height, 16, 4096);
  const anchor = (document.getElementById('resizeAnchor') || {}).value || 'center';
  const fromW = engine.width, fromH = engine.height;
  let ox = 0, oy = 0;
  if (mode === 'crop') { ox = state.pendingResize.offsetX || 0; oy = state.pendingResize.offsetY || 0; }
  else if (anchor === 'center') { ox = Math.round((fromW - w) / 2); oy = Math.round((fromH - h) / 2); }
  try {
    await engine.resizeCanvas(w, h, { offsetX: ox, offsetY: oy });
    try { if (selectionManager && selectionManager.resize) selectionManager.resize(w, h); } catch (e) { /* ignore */ }
    state.selection = null; state.transformActive = false;
    closeModal('canvasResizeModal');
    state.pendingResize = null;
    try { applyDocCanvasSizeUI(); } catch (e) { /* ignore */ }
    try { fitView(); } catch (e) { /* ignore */ }
    drawSelection(); renderAll(); renderLayers(); scheduleProjectAutosave();
    addRecord(baseRecord('L6', { kind: 'canvas_resized', anchor: { type: 'whole', value: null }, model: { provider: 'mock', model: MOCK_MODEL }, params: { mode, from: [fromW, fromH], to: [w, h], offset: [ox, oy], history_cleared: true }, input_refs: [], assertions: [{ type: 'user_operation', value: true }], ai_role: null, source: 'observed', author: 'user', note: mode === 'crop' ? '裁剪画布（图层保留，历史清空）' : '调整画布尺寸（图层保留，历史清空）' }));
    showToast((mode === 'crop' ? '已裁剪到 ' : '画布尺寸已改为 ') + w + '×' + h + ' · 图层已保留 · 历史已清空');
  } catch (e) {
    console.error(e);
    showToast('画布尺寸变更失败：' + (e.message || e), true);
  }
}
async function applyAdjustmentsFromModal() {  const l = activeLayer();
  if (!l) return;
  const val = (id) => Number((document.getElementById(id) || {}).value || 0);
  const params = { brightness: val('adjBrightness') / 100, contrast: val('adjContrast') / 100, saturation: 1 + val('adjSaturation') / 100, hue: val('adjHue') };
  if (!params.brightness && !params.contrast && !val('adjSaturation') && !params.hue && l.kind !== 'adjust') { showToast('调整参数全为 0，无需应用'); return; }
  try {
    const ops = await import('../core/editor-ops.mjs');
    const isAdjust = l.kind === 'adjust';
    const srcMeta = (engine.getLayerMeta(l.id) || {}).adjustSource || null;
    const source = isAdjust && srcMeta && srcMeta.sourceLayerId ? engine.getLayers().find((x) => x.id === srcMeta.sourceLayerId) : l;
    if (!source) { showToast('调整层的源图层已被删除，无法重算参数', true); return; }
    const box = (() => { try { return engine.getLayerContentBounds(source.id); } catch (e) { return null; } })() || { x: 0, y: 0, width: engine.width, height: engine.height };
    const src = await engine.getLayerDataUrl(source.id);
    const out = await ops.computeAdjustedDataUrl(src, params);
    const wantMask = !!(document.getElementById('adjMaskSelection') || {}).checked && !!state.selection;
    if (isAdjust) {
      // T117 P1-2：先捕获 mask 状态，像素替换 + mask 变更合并为同一 undo 事务。
      const maskBefore = engine.captureMaskState ? engine.captureMaskState(l.id) : null;
      const ok = await engine.replaceLayerFromDataUrlWithInfo(l.id, out, { kind: 'adjust', adjust: params });
      if (!ok) throw new Error('调整层更新失败');
      if (wantMask) await engine.setMaskFromDataUrl(l.id, buildSelectionMaskDataUrl(state.selection), { bbox: selectionMaskBBox(state.selection) });
      // T117 P1-1：取消勾选必须真正移除旧 mask，否则 L6 写 masked=false 而画面仍被旧选区限制。
      else if (l.mask && l.mask.exists) engine.removeMask(l.id);
      if (engine.commitMaskChangeToLastUndo) engine.commitMaskChangeToLastUndo(l.id, maskBefore);
      addRecord(baseRecord('L6', { kind: 'adjust_layer', anchor: { type: 'bbox', value: [box.x, box.y, box.width, box.height] }, model: { provider: 'mock', model: MOCK_MODEL }, params: { action: 'update', source_layer_id: source.id, brightness: params.brightness, contrast: params.contrast, saturation: params.saturation, hue: params.hue, non_destructive: true, masked: wantMask }, input_refs: [], assertions: [{ type: 'user_operation', value: true }], ai_role: null, source: 'observed', author: 'user', note: '调整层参数更新（栅格缓存重算）' }));
      closeModal('adjustModal');
      renderAll(); renderLayers(); scheduleProjectAutosave();
      showToast('调整层参数已更新（像素可撤销；参数保存于图层）');
      return;
    }
    const layer = await importImageAsLayer(out, '调整 · ' + (l.name || '图层'), { x: 0, y: 0, width: engine.width, height: engine.height });
    engine.setLayerInfo(layer.id, { kind: 'adjust', adjust: params });
    engine.setLayerMeta(layer.id, { ...(engine.getLayerMeta(layer.id) || {}), adjustSource: { type: 'layer', sourceLayerId: l.id, bounds: [box.x, box.y, box.width, box.height] } });
    if (wantMask) await engine.setMaskFromDataUrl(layer.id, buildSelectionMaskDataUrl(state.selection), { bbox: selectionMaskBBox(state.selection) });
    // T117 P1-4：kind/adjust/meta/mask 都写完后，刷新 addLayer 留下的结构快照，
    // 让「创建 → undo → redo」能完整恢复内容、参数与蒙版，而不是空 raster 层。
    try { engine.refreshTrailingStructureSnapshot(); } catch (e) { /* ignore */ }
    addRecord(baseRecord('L6', { kind: 'adjust_layer', anchor: { type: 'bbox', value: [box.x, box.y, box.width, box.height] }, model: { provider: 'mock', model: MOCK_MODEL }, params: { action: 'create', source_layer_id: l.id, brightness: params.brightness, contrast: params.contrast, saturation: params.saturation, hue: params.hue, non_destructive: true, masked: wantMask }, input_refs: [], assertions: [{ type: 'user_operation', value: true }], ai_role: null, source: 'observed', author: 'user', note: '非破坏调整层（参数可重开；栅格缓存）' }));
    closeModal('adjustModal');
    renderAll(); renderLayers(); scheduleProjectAutosave();
    showToast(wantMask ? '已创建调整层（仅选区）：框外保持原图' : '已创建调整层（快照）：源层未变，参数可重开');
  } catch (e) { console.error(e); showToast('图像调整失败：' + (e.message || e), true); }
}
async function bindProjectControls() {
  $('btnNewCanvas').addEventListener('click', () => {
    closePopovers();
    const w = document.getElementById('newCanvasW'); const h = document.getElementById('newCanvasH');
    if (w) w.value = String(engine.width); if (h) h.value = String(engine.height);
    openModal('newCanvasModal');
  });
  document.querySelectorAll('#newCanvasPresets [data-w]').forEach((b) => b.addEventListener('click', () => {
    const w = document.getElementById('newCanvasW'); const h = document.getElementById('newCanvasH');
    if (w) w.value = b.dataset.w; if (h) h.value = b.dataset.h;
  }));
  $('btnNewCanvasCreate').addEventListener('click', () => {
    const w = clamp(parseInt((document.getElementById('newCanvasW') || {}).value, 10) || 1200, 256, 4096);
    const h = clamp(parseInt((document.getElementById('newCanvasH') || {}).value, 10) || 800, 256, 4096);
    closeModal('newCanvasModal');
    location.href = location.pathname + '?new=1&w=' + w + '&h=' + h;
  });
  $('btnHistoryUndo').addEventListener('click', () => undoUI());
  $('btnHistoryRedo').addEventListener('click', () => redoUI());
  $('btnAdjustLayer').addEventListener('click', () => { closePopovers(); openAdjustModal(); });
  $('btnCanvasResize').addEventListener('click', () => { closePopovers(); openCanvasResizeModal('resize'); });
  $('btnCropSelection').addEventListener('click', () => { closePopovers(); openCanvasResizeModal('crop'); });
  $('btnCanvasResizeApply').addEventListener('click', () => applyCanvasResizeFromModal());
  $('btnToggleGrid').addEventListener('click', () => { state.showGrid = !state.showGrid; syncGuideUI(); renderGuideCanvas(); });
  $('btnToggleThirds').addEventListener('click', () => { state.showThirds = !state.showThirds; syncGuideUI(); renderGuideCanvas(); });
  $('btnToggleSymmetry').addEventListener('click', () => { const order = [null, 'x', 'y', 'both']; state.symmetryAxis = order[(order.indexOf(state.symmetryAxis) + 1) % order.length]; syncGuideUI(); renderGuideCanvas(); });
  $('btnCustomGuides').addEventListener('click', openCustomGuidesModal);
  $('btnAddGuideX').addEventListener('click', () => addCustomGuide('x'));
  $('btnAddGuideY').addEventListener('click', () => addCustomGuide('y'));
  $('btnClearGuides').addEventListener('click', clearCustomGuides);
  syncGuideUI();
  for (const id of ['adjBrightness', 'adjContrast', 'adjSaturation', 'adjHue']) { const el = document.getElementById(id); if (el) el.addEventListener('input', syncAdjustOutputs); }
  $('btnAdjustApply').addEventListener('click', () => applyAdjustmentsFromModal());
  $('btnSaveProject').addEventListener('click', () => { saveProjectDownload().catch((e) => showToast('保存失败：' + (e.message || e), true)); });
  $('btnOpenProject').addEventListener('click', () => $('projectFileInput').click());
  $('projectFileInput').addEventListener('change', (e) => { const f = e.target.files && e.target.files[0]; if (f) loadProjectFile(f); e.target.value = ''; });
  $('btnImportImage').addEventListener('click', () => { closePopovers(); $('fileInput').click(); });
  $('fileInput').addEventListener('change', (e) => { const f = e.target.files && e.target.files[0]; if (f) importImageFileToCanvas(f); e.target.value = ''; });
  $('btnImportPsd').addEventListener('click', () => $('psdFileInput').click());
  $('psdFileInput').addEventListener('change', (e) => { const f = e.target.files && e.target.files[0]; if (f) importPsdFileInput(f); e.target.value = ''; });
  $('btnExportPsd').addEventListener('click', () => exportPsdDownload().catch((e) => showToast('PSD 导出失败：' + (e.message || e), true)));
  const wrap = $('canvasWrap');
  wrap.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
  wrap.addEventListener('drop', (e) => {
    e.preventDefault();
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (!f) return;
    const name = (f.name || '').toLowerCase();
    if (/^image\/(png|jpeg|webp)$/i.test(f.type || '')) importImageFileToCanvas(f);
    else if (name.endsWith('.mozheng') || name.endsWith('.json')) loadProjectFile(f);
    else if (name.endsWith('.psd') || name.endsWith('.psb')) importPsdFileInput(f);
    else showToast('不支持的文件类型：请拖入图片、.mozheng 或 .psd', true);
  });
}

/* ---------------- T96 真实模型接入（本地代理，默认 Mock，密钥不落前端） ---------------- */
const AI_SETTINGS_KEY = 'mozheng.ai.settings.v1';
const AI_PRESETS = {
  mock: { label: '本地 Mock', provider: 'mock', baseUrl: '', model: 'mock-ai@0.1.0', vision: false, imageGen: true, imageEdit: true },
  moonshot: { label: 'Kimi K3.1 Pro', provider: 'moonshot', baseUrl: 'https://api.moonshot.cn/v1', model: 'kimi-k3.1-pro', vision: true, imageGen: false },
  'hunyuan-image': { label: '混元生图 3.0', provider: 'hunyuan', baseUrl: 'https://tokenhub.tencentmaas.com/v1', model: 'hy-image-v3.0', vision: true, imageGen: true },
  qwen: { label: 'Qwen3.8 Max', provider: 'qwen', baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1', imageBaseUrl: 'https://dashscope.aliyuncs.com', model: 'qwen3.8-max', imageModel: 'qwen-image-3.0', imageEditModel: 'qwen-image-3.0-pro', vision: true, imageGen: true, imageEdit: true },
  'hunyuan-vision': { label: '混元视觉 Hy4', provider: 'hunyuan', baseUrl: 'https://api.hunyuan.cloud.tencent.com/v1', model: '', vision: true, imageGen: false },
  custom: { label: '自定义 OpenAI-compatible', provider: 'openai-compatible', baseUrl: 'https://api.openai.com/v1', model: '', vision: true, imageGen: false },
};
const aiRuntime = { preset: 'mock', config: null, configError: null, allowReal: false, requireConfirm: true, privacyMode: true, hasKey: false, lastTest: null, confirmResolver: null, confirmObserver: null };
const AI_TASK_LABEL = { analyze: '读画面', directions: '给方向', generate: '出局部方案', edit: '改图', chat: '对话' };
state.aiLastCall = null;

function aiToken() { return (typeof window !== 'undefined' && window.__AI_LOCAL_TOKEN__) || ''; }
function aiPreset() { return AI_PRESETS[aiRuntime.preset] || AI_PRESETS.mock; }
function aiProviderLabel(meta) {
  if (meta && meta.mock) return '本地 Mock';
  if (!meta && !aiRealEligible()) return '本地 Mock';
  const p = String((meta && meta.provider) || (aiRuntime.config && aiRuntime.config.provider) || aiPreset().provider || 'mock');
  if (p === 'moonshot' || p === 'kimi') return 'Kimi';
  if (p === 'openai-compatible' && /qwen/i.test(String((meta && (meta.model || meta.modelVersion)) || aiRuntimeModel() || ''))) return 'Qwen';
  if (p === 'hunyuan' || p === 'tencent') return '混元';
  if (p === 'qwen' || p === 'dashscope') return 'Qwen';
  if (p === 'openai-compatible' || p === 'custom') return '自定义';
  if (p === 'mock') return '本地 Mock';
  return p;
}
function aiRuntimeModel() {
  const cfg = aiRuntime.config || {};
  const pid = cfg.provider || aiPreset().provider;
  const prov = cfg.providers && cfg.providers[pid];
  return (cfg.model) || (prov && prov.model) || aiPreset().model || MOCK_MODEL;
}
function aiRealEligible() {
  const cfg = aiRuntime.config;
  // T120：上游为内网/回环时凭据按设计被剥离（hasKey=false），但本地代理/测试假上游本就无凭据调用；
  // 此时以「配置里存了 key 或明确是本地无凭据上游」作为真实调用资格，密钥仍绝不外发（服务端剥离不变）。
  if (!aiToken() || !cfg || cfg.mode === 'mock' || !aiRuntime.allowReal || aiRuntime.privacyMode || aiRuntime.preset === 'mock') return false;
  const keyOk = !!cfg.hasKey || (!!cfg.unsafeUpstream && !!cfg.hasStoredKey);
  return keyOk;
}
function aiProviderIdFor(presetId) {
  return (AI_PRESETS[presetId] || AI_PRESETS.mock).provider;
}
async function aiProxyJson(path, opts = {}) {
  const headers = { accept: 'application/json' };
  const token = aiToken();
  if (token) headers['x-ai-token'] = token;
  if (opts.body !== undefined) headers['content-type'] = 'application/json';
  let res;
  try {
    res = await fetch(path, { method: opts.method || 'GET', headers, body: opts.body === undefined ? undefined : JSON.stringify(opts.body) });
  } catch (e) {
    throw new Error('本地 AI 代理不可达；请用 v2/serve.mjs 启动页面（Mock 仍可离线使用）');
  }
  let data = null;
  try { data = await res.json(); } catch (e) { data = null; }
  if (!res.ok) {
    const info = data && data.error ? data.error : {};
    const err = new Error(info.userMessage || info.message || ('AI 代理错误 HTTP ' + res.status));
    err.status = res.status; err.code = info.code || 'http_' + res.status; err.retryable = res.status === 429 || res.status >= 500; err.requestId = info.requestId || null;
    throw err;
  }
  return data;
}
function loadAiLocalSettings() {
  try {
    const raw = JSON.parse(localStorage.getItem(AI_SETTINGS_KEY) || '{}');
    aiRuntime.preset = AI_PRESETS[raw.preset] ? raw.preset : 'mock';
    aiRuntime.allowReal = !!raw.allowReal;
    aiRuntime.requireConfirm = raw.requireConfirm !== false;
    aiRuntime.privacyMode = raw.privacyMode !== false;
  } catch (e) { /* ignore */ }
}
function saveAiLocalSettings() {
  try { localStorage.setItem(AI_SETTINGS_KEY, JSON.stringify({ preset: aiRuntime.preset, allowReal: aiRuntime.allowReal, requireConfirm: aiRuntime.requireConfirm, privacyMode: aiRuntime.privacyMode })); } catch (e) { /* ignore */ }
}
function setAiTestStatus(text, kind) {
  const el = document.getElementById('aiTestStatus');
  if (!el) return;
  el.textContent = text;
  el.className = 'ai-test-status' + (kind ? ' ' + kind : '');
}
function presetFromConfig(cfg) {
  if (!cfg || !cfg.provider || !cfg.hasKey) return 'mock';
  if (cfg.provider === 'moonshot') return 'moonshot';
  if (cfg.provider === 'hunyuan') return (cfg.supports && cfg.supports.imageGen) ? 'hunyuan-image' : 'hunyuan-vision';
  if (cfg.provider === 'qwen') return 'qwen';
  if (cfg.provider === 'openai-compatible') {
    const model = String(cfg.model || (cfg.providers && cfg.providers['openai-compatible'] && cfg.providers['openai-compatible'].model) || '');
    const base = String((cfg.providers && cfg.providers['openai-compatible'] && cfg.providers['openai-compatible'].baseUrl) || cfg.baseUrl || '');
    if (/qwen|dashscope/i.test(model + ' ' + base)) return 'qwen';
    return 'custom';
  }
  return 'mock';
}
async function refreshAiConfig(opts = {}) {
  if (!aiToken()) {
    aiRuntime.config = { ok: false, mode: 'mock', provider: 'mock', model: MOCK_MODEL, hasKey: false, providers: {}, privacyMode: aiRuntime.privacyMode };
    aiRuntime.configError = '代理未连接：本地 token 未注入（请用 v2/serve.mjs 启动；Mock 仍可用）';
    aiRuntime.hasKey = false;
    if (!opts.keepPreset) aiRuntime.preset = 'mock';
    renderAiSettings(); renderAiProviderBadge();
    return;
  }
  try {
    const cfg = await loadAiConfig(fetch, aiToken());
    aiRuntime.config = cfg;
    aiRuntime.configError = cfg && cfg.ok === false ? (cfg.error || '配置读取失败') : null;
    aiRuntime.hasKey = !!(cfg && cfg.hasKey);
    if (!opts.keepPreset) { const pp = presetFromConfig(cfg); if (pp) aiRuntime.preset = pp; }
    if (cfg && cfg.privacyMode) aiRuntime.privacyMode = true;
    // 已配置真实 key 且用户从未手动改过开关 → 默认开启真实协作（仍保留每次手动确认），让"和 API 模型协作"成为默认路径
    let hasSavedPrefs = false;
    try { hasSavedPrefs = !!localStorage.getItem(AI_SETTINGS_KEY); } catch (e) { hasSavedPrefs = false; }
    if (cfg && cfg.hasKey && cfg.mode !== 'mock' && !hasSavedPrefs) {
      aiRuntime.allowReal = true;
      aiRuntime.privacyMode = false;
      aiRuntime.requireConfirm = true;
      saveAiLocalSettings();
    }
    renderAiSettings(); renderAiProviderBadge();
    try { renderAIPanel(); } catch (e) { /* 面板可能尚未初始化 */ }
    try { if (document.getElementById('aiModelBody')) renderAiModelTab(); } catch (e) { /* ignore */ }
  } catch (e) {
    aiRuntime.configError = e.message || '配置读取失败';
    aiRuntime.hasKey = false;
    setAiTestStatus(aiRuntime.configError, 'err');
    renderAiProviderBadge();
  }
}
function fillAiFormFromPreset() {
  const p = aiPreset();
  const sel = document.getElementById('aiProviderSelect'); if (sel) sel.value = aiRuntime.preset;
  const base = document.getElementById('aiBaseUrl'); const model = document.getElementById('aiModel');
  const cfg = aiRuntime.config || {};
  const prov = cfg.providers && cfg.providers[p.provider];
  if (base) base.value = (prov && prov.baseUrl) || (cfg.provider === p.provider && cfg.baseUrl) || p.baseUrl || '';
  if (model) model.value = (prov && prov.model) || (cfg.provider === p.provider && cfg.model) || p.model || '';
  const keyInput = document.getElementById('aiKeyInput'); if (keyInput) keyInput.value = '';
}
function renderAiSettings() {
  const p = aiPreset();
  const sel = document.getElementById('aiProviderSelect'); if (sel) sel.value = aiRuntime.preset;
  const keyState = document.getElementById('aiKeyState');
  // T120：上游为本地/内网时凭据按安全策略剥离；如实告知「存了但不外发」，不再误导为「未配置」。
  const cfgNow2 = aiRuntime.config || {};
  if (keyState) keyState.textContent = aiRuntime.hasKey ? '已配置 Key（仅本地服务保存）'
    : (cfgNow2.unsafeUpstream && cfgNow2.hasStoredKey ? '已配置 Key；上游为本地/内网，按安全策略不发送密钥（无凭据调用）' : '未配置 Key（使用 Mock）');
  const allow = document.getElementById('aiAllowReal'); if (allow) allow.checked = aiRuntime.allowReal;
  const confirm = document.getElementById('aiRequireConfirm'); if (confirm) confirm.checked = aiRuntime.requireConfirm;
  const privacy = document.getElementById('aiPrivacyMode'); if (privacy) privacy.checked = aiRuntime.privacyMode;
  if (aiRuntime.configError) setAiTestStatus(aiRuntime.configError, 'err');
  else {
    const stateText = !aiRuntime.hasKey ? '未配置 key → Mock（离线可用）'
      : aiRuntime.privacyMode ? '隐私模式：强制 Mock（不上传）'
      : !aiRuntime.allowReal ? '已配置 key；允许真实调用默认关闭'
      : '真实调用已启用；每次调用会先确认';
    setAiTestStatus('当前：' + aiProviderLabel() + ' / ' + aiRuntimeModel() + ' · ' + stateText + ' · vision ' + (p.vision ? '✓' : '—') + ' / image ' + (p.imageGen ? '✓' : '—'), aiRealEligible() ? 'ok' : '');
  }
  fillAiFormFromPreset();
  renderAiProviderBadge();
}
function renderAiProviderBadge() {
  const real = aiRealEligible();
  const text = real ? aiProviderLabel() : '本地 Mock';
  for (const id of ['aiProviderBadge', 'aiAccessBadge']) {
    const el = document.getElementById(id);
    if (!el) continue;
    el.textContent = text + (real ? ' · 真实' : '');
    el.classList.toggle('real', real);
    el.title = real ? (aiProviderLabel() + ' / ' + aiRuntimeModel() + '（真实调用需确认）') : '本地 Mock（无网络请求；可在设置中接入真实模型）';
  }
  const aiBtn = document.getElementById('btnAiPanel');
  if (aiBtn) aiBtn.title = 'AI 协作 · ' + (real ? aiProviderLabel() + ' / ' + aiRuntimeModel() : '本地 Mock') + ' · 点顶栏模型徽章可进设置';
  try { if (document.getElementById('aiModelBody')) renderAiModelTab(); } catch (e) { /* ignore */ }
  updateStatusContext();
}
function liveContext() {
  const l = activeLayer();
  let undoDepth = 0;
  try { undoDepth = engine && engine.getStats ? engine.getStats().undoDepth : 0; } catch (e) { /* ignore */ }
  return {
    active_layer: l ? { id: l.id, name: l.name, blend: l.blend, opacity: l.opacity } : null,
    tool: state.tool, brush: state.activePresetId,
    selection: state.selection ? { x: Math.round(state.selection.x), y: Math.round(state.selection.y), width: Math.round(state.selection.width), height: Math.round(state.selection.height) } : null,
    annotated: annotationInk(),
    undo_depth: undoDepth,
    recent_ai: (state.aiSession || []).slice(-3).map((e) => ({ kind: e.kind, text: e.text })),
  };
}
function aiLibraryL5Decisions(limit = 5) {
  const out = [];
  for (const a of (state.library.assets || [])) {
    for (const d of (a.L5 || [])) {
      if (!d || d.source !== 'user-confirmed') continue;
      out.push({
        id: d.id, kind: d.kind, at: d.at || a.updatedAt || null, source: 'user-confirmed',
        text: d.note || ((d.kind === 'confirm' ? '确认' : d.kind === 'reject' ? '否决' : '使用') + ' ' + (d.tags || []).join(' / ')),
        tags: d.tags || [], asset: a.fileName || null, asset_id: a.id, preset: !!d.preset, target: d.targetId || null,
      });
    }
  }
  return out.sort((x, y) => String(y.at || '').localeCompare(String(x.at || ''))).slice(0, limit);
}
function aiLocalL5Decisions(limit = 4) {
  return (state.records || []).filter((r) => r && r.layer === 'L5').slice(-limit).map((r) => ({
    id: r.id, kind: r.kind, at: r.created_at, source: 'user-confirmed', text: r.note || r.kind, tags: [], asset: null, preset: false,
  }));
}
/** 档案摘要：把 L1/L2/L4 + **L5 用户决策（含素材库 user-confirmed）** 一起交给模型 —— 记忆回指必须是真的 */
function aiArchiveSummary() {
  const recs = (state.records || []).filter((r) => ['L1', 'L2', 'L4'].includes(r.layer)).slice(-8);
  const lastL1 = (state.records || []).slice().reverse().find((r) => r.layer === 'L1') || null;
  const l2 = (state.records || []).filter((r) => r.layer === 'L2').slice(-6).map((r) => ({ id: r.id, label: r.label, bbox: r.anchor && r.anchor.value, importance: r.importance, confidence: r.confidence, source: r.source }));
  const l4 = (state.records || []).filter((r) => r.layer === 'L4').slice(-6).map((r) => ({ id: r.id, text: r.text, source: r.source, confidence: r.confidence, anchor: r.anchor && r.anchor.value }));
  const l5 = [...aiLibraryL5Decisions(5), ...aiLocalL5Decisions(4)].slice(0, 8);
  return {
    mode: state.mode, ai_role: state.aiRole, library_ref: state.aiReference ? { id: state.aiReference.id, fileName: state.aiReference.fileName, tags: state.aiReference.tags } : null,
    L0: engine ? { file: 'live://v2/canvas', width: engine.width, height: engine.height, format: 'png' } : null,
    L1: lastL1 ? { id: lastL1.id, scene: lastL1.scene, subject: lastL1.subject, medium: lastL1.medium, palette: lastL1.palette, source: lastL1.source } : null,
    L2: l2, L4: l4, L5: l5,
    preferences: l5.length ? { from_user_decisions: true, summary: l5.map((d) => d.text).filter(Boolean).slice(0, 4).join('；') } : null,
    recent: recs.map((r) => ({ layer: r.layer, id: r.id, text: r.text || r.scene || r.label || '', source: r.source, confidence: r.confidence })),
  };
}
function aiCropRect(sel, kind, maxSide) {
  const limit = maxSide || (kind === 'generate' ? 1024 : 1568);
  const scale = Math.min(1, limit / Math.max(1, sel.width, sel.height));
  const w = Math.max(1, Math.round(sel.width * scale));
  const h = Math.max(1, Math.round(sel.height * scale));
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  try { ctx.drawImage(mainCanvas, sel.x, sel.y, sel.width, sel.height, 0, 0, w, h); } catch (e) { /* ignore */ }
  if (state.annotationDirty) {
    const a = document.getElementById('annotationCanvas');
    if (a && annotationInk()) { try { ctx.drawImage(a, sel.x, sel.y, sel.width, sel.height, 0, 0, w, h); } catch (e) { /* ignore */ } }
  }
  return { dataUrl: c.toDataURL('image/jpeg', 0.86), width: w, height: h, bbox: [sel.x, sel.y, sel.width, sel.height], scale, annotated: annotationInk() };
}
async function aiCropRectAsync(rect, kind, maxSide) {
  const sel = rect || state.selection || selectionOrDefault();
  const limit = maxSide || (kind === 'generate' ? 1024 : 1568);
  const scale = Math.min(1, limit / Math.max(1, sel.width, sel.height));
  const w = Math.max(1, Math.round(sel.width * scale));
  const h = Math.max(1, Math.round(sel.height * scale));
  try {
    // 离屏合成（含 live）后再裁切：主画布是 WebGL，跨帧直接 drawImage 可能拿到黑图
    const url = await engine.getCompositeDataUrl();
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const ctx = c.getContext('2d');
    ctx.drawImage(img, sel.x, sel.y, sel.width, sel.height, 0, 0, w, h);
    if (state.annotationDirty) {
      const a = document.getElementById('annotationCanvas');
      if (a && annotationInk()) { try { ctx.drawImage(a, sel.x, sel.y, sel.width, sel.height, 0, 0, w, h); } catch (e) { /* ignore */ } }
    }
    return { dataUrl: c.toDataURL('image/jpeg', 0.86), width: w, height: h, bbox: [sel.x, sel.y, sel.width, sel.height], scale, annotated: annotationInk() };
  } catch (e) {
    return aiCropRect(sel, kind, maxSide);
  }
}
function aiSelectionCrop(kind) {
  const sel = state.selection || selectionOrDefault();
  return aiCropRect(sel, kind);
}
async function aiSelectionCropAsync(kind) {
  return aiCropRectAsync(state.selection || selectionOrDefault(), kind);
}
function aiWorkshopCrop() {
  if (state.aiImageScope === 'canvas') return aiCropRect({ x: 0, y: 0, width: engine.width, height: engine.height }, 'analyze', 1568);
  return aiCropRect(state.selection || selectionOrDefault(), 'analyze', 1568);
}
async function aiWorkshopCropAsync() {
  if (state.aiImageScope === 'canvas') return aiCropRectAsync({ x: 0, y: 0, width: engine.width, height: engine.height }, 'analyze', 1568);
  return aiCropRectAsync(state.selection || selectionOrDefault(), 'analyze', 1568);
}
async function aiLayerCrop() {
  const l = activeLayer();
  if (!l) throw new Error('没有选中的图层');
  let b = null;
  try { b = engine.getLayerContentBounds(l.id); } catch (e) { b = null; }
  const box = b || { x: 0, y: 0, width: engine.width, height: engine.height };
  const maxSide = 1568;
  const scale = Math.min(1, maxSide / Math.max(1, box.width, box.height));
  const w = Math.max(1, Math.round(box.width * scale)), h = Math.max(1, Math.round(box.height * scale));
  const url = await engine.getLayerDataUrl(l.id);
  const img = new Image(); img.src = url; await img.decode();
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  try { c.getContext('2d').drawImage(img, box.x, box.y, box.width, box.height, 0, 0, w, h); } catch (e) { /* ignore */ }
  state.selection = { x: box.x, y: box.y, width: box.width, height: box.height };
  drawSelection();
  return { dataUrl: c.toDataURL('image/jpeg', 0.9), width: w, height: h, bbox: [box.x, box.y, box.width, box.height], scale, annotated: false, layer: { id: l.id, name: l.name } };
}
function showAiConfirmOnce(intro) {
  if (aiRuntime.confirmResolver) return Promise.resolve(false);
  const provider = aiProviderLabel();
  const model = aiRuntimeModel();
  const text = document.getElementById('aiConfirmText');
  if (text) {
    const base = intro || ('将把选区裁切的 base64 图片' + (annotationInk() ? '（含你手绘的红圈/箭头标注）' : '') + ' / 档案摘要发送给 ' + provider + ' / ' + model);
    text.textContent = /[？?]\s*$/.test(base) ? base : base + '，是否继续？';
  }
  const cost = document.getElementById('aiConfirmCost');
  if (cost) cost.textContent = '本次为真实模型调用；Qwen-Image 3.0 约 ¥0.18/张、混元生图约 ¥0.2/张（失败不计费）；分析按 token 计费（Qwen 输入 12 / 输出 36 元每百万 tokens，缓存命中 1.5）；确认之前不会发送任何图片或摘要。';
  openModal('aiConfirmModal');
  const mask = document.getElementById('aiConfirmModal');
  if (aiRuntime.confirmObserver) { try { aiRuntime.confirmObserver.disconnect(); } catch (e) {} }
  return new Promise((resolve) => {
    aiRuntime.confirmResolver = resolve;
    try {
      aiRuntime.confirmObserver = new MutationObserver(() => {
        if (!mask.classList.contains('show') && aiRuntime.confirmResolver) { const r = aiRuntime.confirmResolver; aiRuntime.confirmResolver = null; r(false); }
      });
      aiRuntime.confirmObserver.observe(mask, { attributes: true, attributeFilter: ['class'] });
    } catch (e) { /* ignore */ }
  });
}
async function confirmAiSend(intro) {
  if (!aiRealEligible()) return true;
  if (!aiRuntime.requireConfirm) return true;
  const ok = await showAiConfirmOnce(intro);
  if (!ok) showToast('已取消：没有发送图片或档案摘要，也没有写入 AI 记录');
  return ok;
}
function aiGetProvider(opts = {}) {
  const real = aiRealEligible();
  // T120：内网/回环上游凭据按设计被剥离；本地代理本就无凭据调用，资格与 aiRealEligible 同源。
  const cfgNow = aiRuntime.config || {};
  const keyOkNow = !!cfgNow.hasKey || (!!cfgNow.unsafeUpstream && !!cfgNow.hasStoredKey);
  const provider = createProvider({
    mode: real ? 'real' : 'mock',
    provider: real ? aiPreset().provider : 'mock',
    model: real ? aiRuntimeModel() : MOCK_MODEL,
    baseUrl: real ? (aiPreset().baseUrl || (aiRuntime.config && aiRuntime.config.baseUrl) || '') : '',
    hasKey: real ? keyOkNow : false,
    mockOnly: !real,
    token: aiToken(),
    confirmReal: true,
    retry: 1,
    signal: opts.signal || null,
    imageModel: aiPreset().imageModel || (aiRuntime.config && aiRuntime.config.imageModel) || undefined,
    imageEditModel: aiPreset().imageEditModel || (aiRuntime.config && aiRuntime.config.imageEditModel) || undefined,
  });
  // ai-provider 的 Moonshot/Hunyuan 构造器会把 baseUrl 指向上游；浏览器必须走本地 /api/ai/* 代理
  try { if (provider && provider.client) provider.client.base = ''; } catch (e) { /* ignore */ }
  return provider;
}
function aiCallMeta(res, kind) {
  const meta = (res && res.meta) || { provider: aiRealEligible() ? aiPreset().provider : 'mock', model: aiRuntimeModel(), mock: !aiRealEligible(), latencyMs: 0 };
  return { ...meta, task: kind, at: iso() };
}
let aiScanTimer = null;
let aiScanPhase = 0;
function startAiScan() {
  if (aiScanTimer) return;
  aiScanPhase = 0;
  aiScanTimer = setInterval(() => {
    try {
      if (!overlayCtx) return;
      drawSelection();
      const b = state.selection || selectionOrDefault();
      aiScanPhase = (aiScanPhase + 1) % 60;
      const ctx = overlayCtx;
      ctx.save();
      ctx.strokeStyle = 'rgba(96,165,250,.85)';
      ctx.lineWidth = 2; ctx.setLineDash([10, 8]); ctx.lineDashOffset = -aiScanPhase * 2;
      ctx.strokeRect(b.x, b.y, b.width, b.height);
      const sx = b.x + (aiScanPhase / 60) * b.width;
      const grad = ctx.createLinearGradient(sx - 16, 0, sx + 16, 0);
      grad.addColorStop(0, 'rgba(96,165,250,0)'); grad.addColorStop(0.5, 'rgba(147,197,253,.28)'); grad.addColorStop(1, 'rgba(96,165,250,0)');
      ctx.fillStyle = grad; ctx.fillRect(sx - 16, b.y, 32, b.height);
      ctx.restore();
    } catch (e) { /* ignore */ }
  }, 90);
}
function stopAiScan() {
  if (aiScanTimer) { clearInterval(aiScanTimer); aiScanTimer = null; }
  try { drawSelection(); } catch (e) { /* ignore */ }
}
let aiWaitTimer = null, aiWaitStart = 0, aiWaitLabel = '';
function startAiWaitTimer(label) {
  stopAiWaitTimer();
  aiWaitStart = Date.now(); aiWaitLabel = label || '';
  const tick = () => {
    const el = document.getElementById('aiStatus');
    if (!el || !aiWaitStart) return;
    el.textContent = aiWaitLabel + ' · 已等待 ' + Math.round((Date.now() - aiWaitStart) / 1000) + 's';
  };
  tick();
  aiWaitTimer = setInterval(tick, 1000);
}
function stopAiWaitTimer() { if (aiWaitTimer) { clearInterval(aiWaitTimer); aiWaitTimer = null; } aiWaitStart = 0; }
function aiBeginTask(label) {
  state.aiBusy = true;
  startAiWaitTimer(label);
  startAiScan();
  const aiPop = document.getElementById('popAI');
  if (aiPop) aiPop.classList.add('is-busy');
  const btn = document.getElementById('btnAiCancel');
  if (btn) btn.hidden = false;
  if (document.getElementById('aiStatus')) document.getElementById('aiStatus').textContent = label;
  if (document.getElementById('statusAiState')) document.getElementById('statusAiState').textContent = label;
}
function aiEndTask() {
  state.aiBusy = false;
  state.aiAbort = null;
  stopAiScan();
  stopAiWaitTimer();
  const aiPop = document.getElementById('popAI');
  if (aiPop) aiPop.classList.remove('is-busy');
  const btn = document.getElementById('btnAiCancel');
  if (btn) btn.hidden = true;
  if (document.getElementById('aiStatus')) document.getElementById('aiStatus').textContent = '待指示';
  if (document.getElementById('statusAiState')) document.getElementById('statusAiState').textContent = 'AI 待命';
}
function aiPhase(text) {
  if (aiWaitStart) aiWaitLabel = text; // UX-T120：等待计时标签跟随阶段文案
  if (document.getElementById('aiStatus')) document.getElementById('aiStatus').textContent = text;
  if (document.getElementById('statusAiState')) document.getElementById('statusAiState').textContent = text;
}
function aiLog(kind, text, meta) {
  const m = meta || state.aiLastCall || {};
  state.aiSession.push({ at: iso(), kind, text, provider: m.provider || (aiRealEligible() ? aiPreset().provider : 'mock'), model: m.model || m.modelVersion || aiRuntimeModel(), mock: m.mock !== false });
  if (state.aiSession.length > 24) state.aiSession.shift();
}
function cancelAiRequest() {
  if (state.aiAbort) { try { state.aiAbort.abort(); } catch (e) { /* ignore */ } }
  aiEndTask();
  aiPhase('已取消');
  showToast('已取消 AI 请求；已发出的请求可能仍会计费，未收到的结果不会写入');
}
function renderAiSessionHtml() {
  if (!state.aiSession.length) return '';
  return '<div class="ai-section-title">本次协作记录（' + state.aiSession.length + '）</div><div class="ai-session">' +
    state.aiSession.slice(-8).map((e) => '<div class="ai-session-row"><span class="ai-session-dot ' + escapeHtml(e.kind) + '"></span><span class="ai-session-text">' + escapeHtml(e.text) + '</span><span class="ai-session-meta">' + escapeHtml((e.provider || '') + '/' + (e.model || '')) + '</span></div>').join('') +
    '</div>';
}
function recordAiCall(task, status, meta, extra = {}) {
  if (state.ignoreArchive) return;
  const provider = (meta && meta.provider) || 'mock';
  const model = (meta && (meta.model || meta.modelVersion)) || MOCK_MODEL;
  // T119：成本为官价估算（按实测 usage 套用官方单价），不是账单实测；字段名与 note 均标明估算口径。
  const estCost = (m) => {
    if (!m || m.mock) return 0;
    if (!/qwen/i.test(String(m.provider || ''))) return 0.2;
    const t = String(m.task || task || '');
    if (t.includes('edit') || /-pro/i.test(String(m.model || m.modelVersion || ''))) return 0.52;
    if (t === 'analyze' || t === 'chat' || t === 'directions') return 0.05;
    return 0.18;
  };
  try {
    addRecord(baseRecord('L6', {
      kind: 'critique',
      model: { provider, model, modelVersion: (meta && meta.modelVersion) || model },
      params: { task, status, request_id: (meta && meta.requestId) || null, mock: !!(meta && meta.mock), latency_ms: (meta && meta.latencyMs) || 0, usage: (meta && meta.usage) || null, cost_basis: meta && meta.mock ? null : 'list_price_estimate', ...extra },
      input_refs: state.records.filter((r) => ['L1', 'L2', 'L4'].includes(r.layer)).slice(-8).map((r) => r.id),
      assertions: [{ type: 'mock_only', value: !!(meta && meta.mock) }, { type: 'no_training_use', value: true }],
      usage: (meta && meta.usage) || null, latency_ms: (meta && meta.latencyMs) || 0,
      cost_cny: estCost(meta), credits: meta && meta.mock ? 0 : 1,
      ai_role: 'assistant', source: 'inferred', author: 'ai',
      note: (status === 'ok' ? '成功' : '失败') + ' · ' + AI_TASK_LABEL[task] + ' · ' + provider + '/' + model + (meta && !meta.mock ? ' · 成本为官价估算' : ''),
    }));
  } catch (e) { console.warn('[ai] record failed', e); }
}
async function saveAiConfigFromUI() {
  const presetId = (document.getElementById('aiProviderSelect') || {}).value || aiRuntime.preset;
  aiRuntime.preset = AI_PRESETS[presetId] ? presetId : 'mock';
  const spec = AI_PRESETS[aiRuntime.preset];
  const baseUrl = ((document.getElementById('aiBaseUrl') || {}).value || spec.baseUrl || '').trim();
  const model = ((document.getElementById('aiModel') || {}).value || spec.model || '').trim();
  const key = ((document.getElementById('aiKeyInput') || {}).value || '').trim();
  if (!aiToken()) { setAiTestStatus('保存失败：本地代理 token 未注入。请用 v2/serve.mjs 启动页面；Mock 仍可使用。', 'err'); return; }
  try {
    const body = { mode: aiRuntime.allowReal ? 'real' : 'mock', provider: spec.provider, model, baseUrl, privacyMode: aiRuntime.privacyMode };
    if (aiRuntime.preset !== 'mock') {
      body.providers = { [spec.provider]: { baseUrl, model } };
      if (key) body.providers[spec.provider].apiKey = key;
      if (aiRuntime.preset === 'hunyuan-image') body.providers[spec.provider].imageModel = model;
      if (aiRuntime.preset === 'qwen') { body.providers[spec.provider].imageBaseUrl = spec.imageBaseUrl; body.providers[spec.provider].imageModel = spec.imageModel; body.providers[spec.provider].imageEditModel = spec.imageEditModel; body.providers[spec.provider].imageProtocol = 'dashscope-async'; }
    } else { body.provider = 'mock'; body.model = MOCK_MODEL; }
    const r = await aiProxyJson('/api/ai/config', { method: 'POST', body });
    const cfg = r && r.config ? r.config : null;
    if (cfg) { aiRuntime.config = cfg; aiRuntime.hasKey = !!cfg.hasKey; aiRuntime.privacyMode = !!cfg.privacyMode; }
    const keyInput = document.getElementById('aiKeyInput'); if (keyInput) keyInput.value = '';
    saveAiLocalSettings();
    await refreshAiConfig({ keepPreset: true });
    setAiTestStatus('配置已保存（密钥只在本地服务；前端不保留）。当前：' + aiProviderLabel() + ' / ' + aiRuntimeModel(), 'ok');
    renderAiProviderBadge(); showToast('AI 模型配置已保存');
  } catch (e) { setAiTestStatus('保存失败：' + (e.message || e), 'err'); }
}
async function testAiConnection() {
  if (!aiToken()) { setAiTestStatus('测试失败：本地代理 token 未注入，请用 v2/serve.mjs 启动页面。', 'err'); return; }
  setAiTestStatus('测试连接中…', '');
  try {
    const r = await aiProxyJson('/api/ai/test', { method: 'POST', body: {} });
    const caps = aiPreset();
    const capText = 'vision ' + (caps.vision ? '✓' : '—') + ' / image ' + (caps.imageGen ? '✓' : '—');
    aiRuntime.lastTest = r;
    setAiTestStatus((r.ok ? '连接成功' : '连接失败') + ' · ' + (r.mode || 'mock') + ' · ' + (r.provider || 'mock') + ' · ' + (r.latencyMs || 0) + 'ms · ' + capText + (r.mock ? '（无 key，Mock）' : ''), r.ok ? 'ok' : 'err');
  } catch (e) {
    setAiTestStatus('测试失败：' + (e.message || e) + (e.retryable ? ' · 可稍后重试' : ''), 'err');
  }
}
async function clearAiKeyFromUI() {
  const spec = aiPreset();
  if (!aiToken()) { setAiTestStatus('清除失败：代理 token 未注入。', 'err'); return; }
  try {
    await aiProxyJson('/api/ai/config', { method: 'POST', body: { providers: { [spec.provider]: { apiKey: '' } } } });
    await refreshAiConfig({ keepPreset: true });
    setAiTestStatus('已清除该 provider 的本地 Key；真实调用将回退 Mock。', 'ok');
  } catch (e) { setAiTestStatus('清除失败：' + (e.message || e), 'err'); }
}
function initAiSettings() {
  loadAiLocalSettings();
  const sel = document.getElementById('aiProviderSelect');
  if (sel) sel.addEventListener('change', () => { aiRuntime.preset = AI_PRESETS[sel.value] ? sel.value : 'mock'; saveAiLocalSettings(); renderAiSettings(); });
  const onToggle = () => {
    aiRuntime.allowReal = !!(document.getElementById('aiAllowReal') || {}).checked;
    aiRuntime.requireConfirm = !!(document.getElementById('aiRequireConfirm') || {}).checked;
    aiRuntime.privacyMode = !!(document.getElementById('aiPrivacyMode') || {}).checked;
    saveAiLocalSettings(); renderAiProviderBadge();
  };
  ['aiAllowReal', 'aiRequireConfirm', 'aiPrivacyMode'].forEach((id) => { const el = document.getElementById(id); if (el) el.addEventListener('change', onToggle); });
  const save = document.getElementById('btnAiSave'); if (save) save.addEventListener('click', () => saveAiConfigFromUI().catch((e) => setAiTestStatus(String(e.message || e), 'err')));
  const test = document.getElementById('btnAiTest'); if (test) test.addEventListener('click', () => testAiConnection());
  const clear = document.getElementById('btnAiClearKey'); if (clear) clear.addEventListener('click', () => clearAiKeyFromUI().catch((e) => setAiTestStatus(String(e.message || e), 'err')));
  const ok = document.getElementById('btnAiConfirmOk'); if (ok) ok.addEventListener('click', () => { closeModal('aiConfirmModal'); const r = aiRuntime.confirmResolver; aiRuntime.confirmResolver = null; if (r) r(true); });
  const cancel = document.getElementById('btnAiConfirmCancel'); if (cancel) cancel.addEventListener('click', () => { closeModal('aiConfirmModal'); const r = aiRuntime.confirmResolver; aiRuntime.confirmResolver = null; if (r) r(false); });
  renderAiSettings();
  refreshAiConfig({ quiet: true }).catch(() => {});
}

/* ---------------- 卡住协作 / AI ---------------- */
function selectionOrDefault() { return state.selection || { x: 240, y: 200, width: 520, height: 360 }; }
async function runAnalyze(opts = {}) {
  if (state.mode === 'attest') { showToast('存证模式已禁用 AI', true); return null; }
  // UX-T120：空白画布预检。此前空画布点「让 AI 看看」会先弹付费确认、再对纯白图发起真实调用；
  // 现在先提示并重新展示引导卡。测试/路演可传 opts.allowBlank 旁路（路演第 3 拍前已载入示例）。
  if (!opts.allowBlank && !state.demo.active && !ROADSHOW.active && quickStartBlank()) {
    showToast('画布还是空的：先画一笔或打开示例，再框选一块点「让 AI 看看」');
    let dismissed = false;
    try { dismissed = localStorage.getItem(LS_QUICKSTART) === '1'; } catch (e) { /* ignore */ }
    const qs = document.getElementById('quickStart');
    if (qs && !dismissed) qs.hidden = false;
    return null;
  }
  const sel = selectionOrDefault();
  state.selection = sel;
  drawSelection();
  const real = aiRealEligible();
  if (real && !(await confirmAiSend())) return null;
  const ac = new AbortController();
  state.aiAbort = ac;
  aiBeginTask('读取选区…');
  $('statusAiState').textContent = 'AI 分析中';
  openPopover('popAI');
  try {
    const crop = await aiSelectionCropAsync('analyze');
    const archive = aiArchiveSummary();
    aiPhase('发送给 ' + aiProviderLabel() + '…');
    const provider = aiGetProvider({ signal: ac.signal });
    state.aiCalls += 1;
    const runtime = await getSkillRuntime();
    const run = await runtime.run('canvas.observe', {
      image: crop.dataUrl, width: crop.width, height: crop.height, selection: { ...sel }, archive,
      userIntent: state.aiIntent || '', mode: state.mode, aiRole: state.aiRole, live: liveContext(),
      context: { mode: state.mode, aiRole: state.aiRole, libraryRef: state.aiReference ? { id: state.aiReference.id, fileName: state.aiReference.fileName, tags: state.aiReference.tags, l1: state.aiReference.l1 } : null },
    }, { provider });
    const res = run.result;
    aiPhase('解析观察…');
    state.aiLastCall = { ...aiCallMeta(res, 'analyze'), skill: run.skill.id, skill_version: run.skill.version };
    aiEndTask();
    aiLog('analyze', '观察 ' + ((res.observations || []).length) + ' 条 · ' + (state.aiLastCall.latencyMs || 0) + 'ms · ' + run.skill.id, state.aiLastCall);
    if (state.aiReference) res.libraryRef = { id: state.aiReference.id, fileName: state.aiReference.fileName, sha256: state.aiReference.sha256 };
    clearCandidatePreview();
    state.analysis = res;
    state.directions = null;
    state.candidates = null;
    recordAiCall('analyze', 'ok', state.aiLastCall, { model: res.global && res.global.medium ? res.global.medium.kind : null, observations: (res.observations || []).length, skill: run.skill.id, skill_version: run.skill.version, l5_refs: (archive.L5 || []).map((d) => d.id), memory_used: !!(archive.L5 && archive.L5.length) });
    if (!state.ignoreArchive && !opts.noRecords) {
      addRecord(baseRecord('L1', {
        anchor: { type: 'whole', value: null },
        subject: res.global.subject,
        scene: res.global.summary,
        medium: res.global.medium,
        palette: res.global.palette,
        aspect_ratio: '3:2',
        confidence: res.confidence,
      }));
      for (const region of res.regions) {
        addRecord(baseRecord('L2', { id: region.id, anchor: { type: 'bbox', value: region.bbox }, label: region.label, crop_path: 'ai://crop/' + region.id + '.png', importance: region.importance, confidence: region.confidence }));
      }
      for (const obs of res.observations) {
        addRecord(baseRecord('L4', { id: obs.id, anchor: { type: 'bbox', value: obs.anchor.value }, kind: obs.kind, text: obs.text, evidence_refs: obs.evidenceRefs, confidence: obs.confidence }));
      }
    }
    $('aiStatus').textContent = '待决定';
    $('statusAiState').textContent = 'AI 已给出观察';
    renderAiProviderBadge();
    renderAIPanel();
    return res;
  } catch (e) {
    console.error(e);
    aiEndTask();
    if (e && (e.code === 'cancelled' || e.name === 'AbortError')) {
      aiPhase('已取消');
      $('statusAiState').textContent = 'AI 已取消';
      showToast('已取消 AI 请求；若请求已发出可能仍会计费');
      return null;
    }
    state.aiLastCall = { provider: aiRealEligible() ? aiPreset().provider : 'mock', model: aiRuntimeModel(), mock: !aiRealEligible(), task: 'analyze', status: 'error', errorCode: e.code || 'ai_error', latencyMs: 0, at: iso() };
    recordAiCall('analyze', 'error', state.aiLastCall, { error_code: e.code || 'ai_error', error_message: (e.userMessage || e.message || String(e)).slice(0, 200), retryable: !!e.retryable });
    aiLog('error', '分析失败 · ' + (e.code || 'ai_error'), state.aiLastCall);
    $('aiStatus').textContent = '失败';
    $('statusAiState').textContent = 'AI 失败';
    renderAiProviderBadge();
    showToast('AI 分析失败：' + (e.userMessage || e.message || e), true);
    return null;
  }
}

function observationRecord(id) { return state.records.find((r) => r.id === id && r.layer === 'L4'); }
function confirmObservation(id, accept) {
  const rec = observationRecord(id);
  if (!rec) return false;
  rec.source = accept ? 'user-confirmed' : 'inferred';
  rec.author = accept ? 'ai-suggested-user-accepted' : 'user';
  rec.updated_at = iso();
  if (accept) rec.confidence = clamp((rec.confidence || 0.6) + 0.1, 0, 1);
  addRecord(baseRecord('L5', {
    anchor: rec.anchor,
    kind: accept ? 'keep' : 'reject_ai',
    session_id: state.sessionId,
    created_by: accept ? 'ai-suggested-user-accepted' : 'user',
    source: 'user-confirmed', author: 'user',
    note: (accept ? '确认观察：' : '否决观察：') + (rec.text || '').slice(0, 40),
  }));
  renderAIPanel(); renderArchiveCount(); scheduleSave();
  aiLog('decision', (accept ? '确认观察' : '否决观察') + '：' + (rec.text || '').slice(0, 28));
  showToast(accept ? '已确认观察，并写回 L5 决策' : '已否决观察，并写回 L5 决策');
  return true;
}

async function runDirections() {
  if (state.mode === 'attest') { showToast('存证模式已禁用 AI', true); return null; }
  if (!state.analysis) { showToast('请先「让 AI 看看」', true); return null; }
  const real = aiRealEligible();
  if (real && !(await confirmAiSend())) return null;
  const sel = state.selection || selectionOrDefault();
  const ac = new AbortController(); state.aiAbort = ac; aiBeginTask('准备方向…');
  try {
    const crop = await aiSelectionCropAsync('analyze');
    const archive = aiArchiveSummary();
    aiPhase('让模型给方向…');
    const provider = aiGetProvider({ signal: ac.signal });
    state.aiCalls += 1;
    const runtime = await getSkillRuntime();
    const run = await runtime.run('canvas.directions', {
      image: crop.dataUrl, width: crop.width, height: crop.height, selection: { ...sel }, archive,
      userIntent: state.aiIntent || '', mode: state.mode, aiRole: state.aiRole, live: liveContext(),
      observationIds: state.analysis.observations.map((o) => o.id), count: 2,
      context: { mode: state.mode, aiRole: state.aiRole, libraryRef: state.aiReference ? { id: state.aiReference.id, fileName: state.aiReference.fileName } : null },
    }, { provider });
    const res = run.result;
    state.aiLastCall = { ...aiCallMeta(res, 'directions'), skill: run.skill.id, skill_version: run.skill.version };
    aiEndTask();
    state.directions = res.directions;
    state.selectedDirection = null;
    state.candidates = null;
    recordAiCall('directions', 'ok', state.aiLastCall, { count: res.directions.length, skill: run.skill.id, skill_version: run.skill.version, l5_refs: (archive.L5 || []).map((d) => d.id), memory_used: !!(archive.L5 && archive.L5.length) });
    aiLog('directions', '给出 ' + res.directions.length + ' 个方向 · ' + (state.aiLastCall.latencyMs || 0) + 'ms · ' + run.skill.id, state.aiLastCall);
    $('aiStatus').textContent = '选方向';
    renderAiProviderBadge();
    renderAIPanel();
    return res;
  } catch (e) {
    console.error(e);
    aiEndTask();
    if (e && (e.code === 'cancelled' || e.name === 'AbortError')) { aiPhase('已取消'); showToast('已取消方向请求'); return null; }
    state.aiLastCall = { provider: aiRealEligible() ? aiPreset().provider : 'mock', model: aiRuntimeModel(), mock: !aiRealEligible(), task: 'directions', status: 'error', errorCode: e.code || 'ai_error', at: iso() };
    recordAiCall('directions', 'error', state.aiLastCall, { error_code: e.code || 'ai_error', error_message: (e.userMessage || e.message || String(e)).slice(0, 200), retryable: !!e.retryable });
    aiLog('error', '方向失败 · ' + (e.code || 'ai_error'), state.aiLastCall);
    showToast('AI 方向失败：' + (e.userMessage || e.message || e), true);
    return null;
  }
}
async function runGenerate(directionId) {
  if (state.mode === 'attest') { showToast('存证模式已禁用 AI', true); return null; }
  if (!state.directions) await runDirections();
  if (!state.directions) return null;
  const real = aiRealEligible();
  if (real && !(await confirmAiSend())) return null;
  const dir = state.directions.find((d) => d.id === directionId) || state.directions[0];
  const sel = state.selection || selectionOrDefault();
  const ac = new AbortController(); state.aiAbort = ac; aiBeginTask('准备局部方案…');
  try {
    const crop = await aiSelectionCropAsync('generate');
    const live = liveContext();
    const prompt = '局部方案：' + (dir.title || '') + '\n' + (dir.why || '') + (state.aiIntent ? ('\n用户意图：' + state.aiIntent) : '') + '\n当前画布状态：' + JSON.stringify(live) + '\n只生成选区裁切区域内的内容，保持周围画布不变；输出 patch，不重绘整图。';
    aiPhase((real ? '真实生图排队中…（10–30s）' : '生成局部方案…'));
    const provider = aiGetProvider({ signal: ac.signal });
    state.aiCalls += 1;
    const runtime = await getSkillRuntime();
    const run = await runtime.run('image.generate', { image: crop.dataUrl, width: crop.width, height: crop.height, prompt, directionId: dir.id, selection: { ...sel }, count: 2, size: '1024x1024', context: { mode: state.mode, aiRole: state.aiRole } }, { provider });
    const res = run.result;
    state.aiLastCall = { ...aiCallMeta(res, 'generate'), skill: run.skill.id, skill_version: run.skill.version };
    aiEndTask();
    clearCandidatePreview();
    state.candidates = res.candidates;
    state.selectedDirection = dir;
    recordAiCall('generate', 'ok', state.aiLastCall, { direction_id: dir.id, candidate_ids: (res.candidates || []).map((c) => c.id), local_patch: true, skill: run.skill.id, skill_version: run.skill.version });
    aiLog('generate', '生成 ' + ((res.candidates || []).length) + ' 个候选 · ' + (state.aiLastCall.latencyMs || 0) + 'ms · ' + run.skill.id, state.aiLastCall);
    $('aiStatus').textContent = '选方案';
    renderAiProviderBadge();
    renderAIPanel();
    return res;
  } catch (e) {
    console.error(e);
    aiEndTask();
    if (e && (e.code === 'cancelled' || e.name === 'AbortError')) { aiPhase('已取消'); showToast('已取消生图请求；若已提交可能仍会计费'); return null; }
    state.aiLastCall = { provider: aiRealEligible() ? aiPreset().provider : 'mock', model: aiRuntimeModel(), mock: !aiRealEligible(), task: 'generate', status: 'error', errorCode: e.code || 'ai_error', at: iso() };
    recordAiCall('generate', 'error', state.aiLastCall, { error_code: e.code || 'ai_error', error_message: (e.userMessage || e.message || String(e)).slice(0, 200), retryable: !!e.retryable });
    showToast('AI 生成失败：' + (e.userMessage || e.message || e), true);
    return null;
  }
}
async function previewCandidate(idx) {
  const c = state.candidates && state.candidates[idx];
  if (!c) return;
  if (state.previewCandidateIndex === idx) { clearCandidatePreview(); renderAIPanel(); return; }
  const cv = document.getElementById('candidatePreviewCanvas');
  if (!cv) return;
  cv.width = engine.width; cv.height = engine.height;
  const ctx = cv.getContext('2d');
  ctx.clearRect(0, 0, cv.width, cv.height);
  const img = new Image(); img.src = c.imageDataUrl;
  try { await img.decode(); } catch (e) { showToast('候选预览加载失败', true); return; }
  const sel = state.selection || selectionOrDefault();
  try { ctx.drawImage(img, sel.x, sel.y, sel.width, sel.height); } catch (e) { /* ignore */ }
  state.previewCandidateIndex = idx;
  renderAIPanel();
  showToast('已把候选 ' + c.label + ' 叠在画布上看效果；不落层、不写档案');
}
function clearCandidatePreview() {
  state.previewCandidateIndex = null;
  const cv = document.getElementById('candidatePreviewCanvas');
  if (cv) cv.getContext('2d').clearRect(0, 0, cv.width, cv.height);
}
function selectionBaseCrop(sel) {
  const s = sel || state.selection || selectionOrDefault();
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(s.width)); c.height = Math.max(1, Math.round(s.height));
  try { c.getContext('2d').drawImage(mainCanvas, s.x, s.y, s.width, s.height, 0, 0, c.width, c.height); } catch (e) { /* ignore */ }
  return c.toDataURL('image/png');
}
async function maskCandidateForSelection(dataUrl, sel) {
  const hasMask = !!(selectionManager && selectionManager.mask && typeof engine.hasSelection === 'function' && engine.hasSelection());
  if (!hasMask) return { dataUrl, masked: false };
  const img = new Image(); img.src = dataUrl; await img.decode();
  const s = sel || state.selection || selectionOrDefault();
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(s.width)); c.height = Math.max(1, Math.round(s.height));
  const ctx = c.getContext('2d');
  ctx.drawImage(img, 0, 0, c.width, c.height);
  ctx.globalCompositeOperation = 'destination-in';
  try { ctx.drawImage(selectionManager.mask, s.x, s.y, s.width, s.height, 0, 0, c.width, c.height); } catch (e) { /* ignore */ }
  ctx.globalCompositeOperation = 'source-over';
  return { dataUrl: c.toDataURL('image/png'), masked: true };
}
function candidateCompareHtml(cand, idx, sel) {
  const active = state.compareCandidateIndex === idx;
  if (!active) return '';
  const base = selectionBaseCrop(sel);
  return '<div class="cand-compare" data-compare-idx="' + idx + '">' +
    '<div class="cand-compare-stage"><img class="cmp-base" src="' + base + '" alt="原图"><img class="cmp-result" src="' + cand.imageDataUrl + '" alt="结果"></div>' +
    '<input type="range" id="candCompareRange" min="0" max="100" value="50" aria-label="对比原图与结果">' +
    '<div class="cmp-labels"><span>原图</span><span>结果</span></div></div>';
}
function bindCandidateCompare(host) {
  const range = host.querySelector('#candCompareRange');
  if (!range) return;
  const stage = host.querySelector('.cand-compare-stage');
  const result = host.querySelector('.cmp-result');
  if (!stage || !result) return;
  const update = () => { const v = Number(range.value); result.style.clipPath = 'inset(0 0 0 ' + v + '%)'; };
  update();
  range.addEventListener('input', update);
}
async function applyCandidate(idx) {
  const cand = state.candidates && state.candidates[idx];
  if (!cand) return;
  clearCandidatePreview();
  const sel = state.selection || selectionOrDefault();
  $('statusHint').textContent = '正在把局部方案落为新图层…';
  try {
    const meta = state.aiLastCall || { provider: 'mock', model: MOCK_MODEL, mock: true, latencyMs: 0 };
    const label = aiProviderLabel(meta);
    const masked = await maskCandidateForSelection(cand.imageDataUrl, sel);
    const layer = await importImageAsLayer(masked.dataUrl, 'AI 局部方案 ' + String.fromCharCode(65 + idx) + ' · ' + label, { x: sel.x, y: sel.y, width: sel.width, height: sel.height });
    // 来源诚实：Mock 结果（没有真的调用模型）在图层面板上必须一眼可辨
    if (meta.mock) { try { layer.name = '[Mock] ' + layer.name; } catch (e) { /* ignore */ } }
    state.generatedCandidateId = cand.id;
    enterImageTransformUI(layer, sel.x, sel.y, sel.width, sel.height);
    showToast(masked.masked ? '已按选区形状裁切并落为新图层：框外像素保留，可继续变换/撤销' : '已落为新图层：现在可直接拖手柄缩放/旋转，Enter 提交；Ctrl+Z 撤销');
    aiLog('apply', '落为新图层：' + (cand.label || '候选') + (masked.masked ? '（mask 裁切）' : ''), state.aiLastCall);
    if (!state.ignoreArchive) {
      addRecord(baseRecord('L6', {
        kind: 'generation',
        anchor: { type: 'bbox', value: [sel.x, sel.y, sel.width, sel.height] },
        model: { provider: meta.provider || 'mock', model: meta.model || meta.modelVersion || MOCK_MODEL, modelVersion: meta.modelVersion || meta.model || MOCK_MODEL },
        params: { direction_id: state.selectedDirection ? state.selectedDirection.id : null, candidate_id: cand.id, candidate_sha256: cand.sha256 || null, selection: [sel.x, sel.y, sel.width, sel.height], library_ref: state.aiReference ? { id: state.aiReference.id, sha256: state.aiReference.sha256 } : null, local_patch: true, masked: masked.masked, mask_policy: masked.masked ? 'selection_alpha' : 'none', request_id: meta.requestId || null, skill: meta.skill || null, skill_version: meta.skill_version || null },
        input_refs: state.records.filter((r) => ['L1', 'L2', 'L4'].includes(r.layer)).slice(-8).map((r) => r.id),
        assertions: [{ type: meta.mock ? 'mock_only' : 'real_model', value: true }, { type: 'no_training_use', value: true }],
        output_asset_id: cand.id,
        cost_cny: meta.mock ? 0 : (/qwen/i.test(String(meta.provider || '')) ? (String(meta.task || '').includes('edit') || /-pro/i.test(String(meta.model || meta.modelVersion || '')) ? 0.52 : 0.18) : 0.2), credits: meta.mock ? 0 : (/qwen/i.test(String(meta.provider || '')) ? 1 : 1), cost_basis: meta.mock ? null : 'list_price_estimate',
        ai_role: 'assistant', source: 'inferred', author: 'ai',
        note: (cand.why || '') + ' · 局部 patch 落新图层' + (masked.masked ? ' · 按选区 mask 裁切（框外保留）' : '') + (/qwen/i.test(String(meta.provider || '')) ? (String(meta.task || '').includes('edit') || /-pro/i.test(String(meta.model || meta.modelVersion || '')) ? ' · Qwen-Image-Edit 2K 官价估算约 ¥0.52/张' : ' · Qwen-Image 3.0 官价估算约 ¥0.18/张（北京官方价 0.024754 USD）') : ''),
      }));
    }
    $('aiStatus').textContent = '方案已落层';
    $('statusHint').textContent = 'AI 局部方案已落为新图层，可撤销/隐藏/删除；未改动原画';
    renderAIPanel(); renderLayers(); renderArchiveCount(); scheduleSave(); setTimeout(saveSnapshot, 500);
    showToast('已落局部方案「' + layer.name + '」；AI 未改动原画');
  } catch (e) {
    console.error(e);
    showToast('落层失败：' + (e.message || e), true);
  }
}
function aiChatContextLine() {
  const c = state.aiChatContext || {};
  const sel = state.selection || selectionOrDefault();
  const refs = (state.library.assets || []).length;
  const parts = [];
  parts.push(c.selection !== false ? ('选区 ' + Math.round(sel.width) + '×' + Math.round(sel.height)) : '不带选区图');
  if (c.canvas) parts.push('整幅画布缩略图');
  if (c.library !== false) parts.push('素材摘要 ' + refs + ' 张');
  if (c.archive !== false) parts.push('档案/L6 摘要');
  if (c.profile !== false) parts.push('画像');
  parts.push('对话 ' + (state.aiChat || []).length + ' 条');
  return parts.join(' · ');
}
function deriveProfileHints() {
  const assets = state.library.assets || [];
  const counts = new Map();
  const moods = new Map();
  let confirmed = 0;
  for (const a of assets) {
    const ok = (a.L5 || []).filter((d) => d.kind === 'confirm').length;
    if (!ok) continue;
    confirmed += 1;
    for (const t of (a.tags || [])) { const s = String(t).trim(); if (s) counts.set(s, (counts.get(s) || 0) + 1); }
    for (const m of ((a.L1 && a.L1.mood) || [])) { const s = String(m).trim(); if (s) moods.set(s, (moods.get(s) || 0) + 1); }
  }
  const tags = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([t]) => t);
  const mood = [...moods.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([t]) => t);
  return { tags, mood, confirmed };
}
function aiProfileHintsHtml() {
  const h = deriveProfileHints();
  if (!h.confirmed) return '';
  const words = [...new Set([...h.tags, ...h.mood])].slice(0, 6);
  if (!words.length) return '';
  return '<div class="ai-profile-hints"><span>建议 · 尚未写入</span>从你的 ' + h.confirmed + ' 次素材确认里看到：<b>' + escapeHtml(words.map((w) => '#' + w).join(' ')) + '</b><button class="btn tiny" id="btnUseProfileHints">采用建议写入画像</button></div>';
}
function aiProfileHtml() {
  const p = state.aiProfile || {};
  return '<details class="ai-profile"><summary>AI 对你的理解（记忆）</summary>' +
    aiProfileHintsHtml() +
    '<div class="ai-profile-grid">' +
    '<label>风格关键词<input id="aiProfileStyle" value="' + escapeHtml(p.style || '') + '" placeholder="冷灰蓝、留白、颗粒、克制"></label>' +
    '<label>避免<input id="aiProfileAvoid" value="' + escapeHtml(p.avoid || '') + '" placeholder="不要塑料感、不要过度锐化"></label>' +
    '<label>常用媒介/场景<input id="aiProfileMedium" value="' + escapeHtml(p.medium || '') + '" placeholder="数字绘画 / 插画 / 概念场景"></label>' +
    '<label class="wide">备注<textarea id="aiProfileNotes" rows="2" placeholder="例如：保留手绘笔触，宁可暗一点也不要糊">' + escapeHtml(p.notes || '') + '</textarea></label>' +
    '</div><div class="hint">会随每次对话发送；同时带上素材档案、L5 决策和最近 L6 记录。只存本地。</div>' +
    '<div class="ai-profile-actions"><button class="btn tiny" id="btnAiMemoryClear">清空 AI 记忆（对话+画像）</button></div></details>';
}
function executeChatAction(action) {
  if (!action || !action.type) return;
  const v = validateAction(action);
  if (!v.ok) { showToast('该建议未通过安全校验，已忽略', true); return; }
  if (action.type === 'observe') {
    state.aiIntent = action.reason || action.label || state.aiIntent;
    switchAiTab('obs'); renderAIPanel();
    showToast('已把建议放进意图；点「让 AI 看看」继续');
    return;
  }
  if (action.type === 'generate' || action.type === 'edit') {
    switchAiTab('image');
    state.aiImageScope = 'selection';
    state.aiImagePrompt = (action.params && action.params.prompt) || action.label || '';
    renderAiImageTab();
    showToast(action.type === 'edit' ? '已切到图像编辑并填入建议；确认后执行' : '已切到图像工作台并填入建议；确认后生成');
    return;
  }
  if (action.type === 'adjust') {
    openAdjustModal(action.params || {});
    showToast('已打开图像调整；可先调数值再应用');
    return;
  }
  if (action.type === 'reference') {
    const id = action.params && action.params.assetId;
    const name = action.params && action.params.fileName;
    const a = (state.library.assets || []).find((x) => (id && x.id === id) || (name && x.fileName === name));
    switchAiTab('image');
    if (a) { try { selectLibraryAsset(a.id); } catch (e) { /* ignore */ } openLibrarySheet(); }
    renderAiImageTab();
    showToast(a ? ('已定位素材「' + (a.fileName || '素材') + '」；点「作为 AI 参考」确认加入') : '已切到图像工作台；从素材库选一张参考');
    return;
  }
  if (action.type === 'annotate') {
    switchAiTab('obs');
    if (!state.annotationMode) toggleAnnotationMode(true);
    showToast('标注模式已开：在画布上圈出想指给 AI 的位置');
    return;
  }
  if (action.type === 'export') { switchAiTab('evidence'); showToast('已打开证据视图'); return; }
  showToast('这个建议暂时需要手动处理');
}
function aiChatHtml() {
  const all = state.aiChat || [];
  const start = Math.max(0, all.length - 30);
  const msgs = all.slice(start).map((m, off) => {
    const idx = start + off;
    const actions = Array.isArray(m.actions) && m.actions.length
      ? '<div class="ai-chat-actions"><span class="ai-chat-actions-label">建议 · 不会自动执行</span>' + m.actions.map((a, ai) => '<button class="ai-chat-action" data-chat-action="' + idx + ':' + ai + '" title="' + escapeHtml((a.reason || '') + ' · ' + describeAction(a)) + '"><span>' + escapeHtml(a.label || a.type) + '</span><em>→ ' + ({ observe: '观察', generate: '生成', edit: '编辑', adjust: '调整', reference: '参考', annotate: '标注', export: '证据' }[a.type] || '建议') + '</em></button>').join('') + '</div>'
      : '';
    return '<div class="ai-chat-msg ' + (m.role === 'user' ? 'user' : 'assistant') + '"><span class="ai-chat-who">' + (m.role === 'user' ? '你' : 'AI') + '</span><div class="ai-chat-text">' + escapeHtml(m.content) + '</div>' + actions + (m.meta && m.role === 'assistant' ? '<div class="ai-chat-meta">' + escapeHtml((m.meta.provider || '') + ' / ' + (m.meta.model || '') + ' · ' + (m.meta.mock ? 'Mock' : '真实') + ' · ' + (m.meta.latencyMs || 0) + 'ms' + (m.meta.usage && m.meta.usage.total_tokens ? ' · ' + m.meta.usage.total_tokens + ' tokens' : '')) + '</div>' : '') + '</div>';
  }).join('');
  const c = state.aiChatContext || {};
  const chip = (id, label) => '<button class="ai-context-chip' + (c[id] !== false && c[id] ? ' active' : '') + '" data-chat-ctx="' + id + '">' + label + '</button>';
  const totalTokens = all.reduce((n, m) => n + (m.meta && m.meta.usage && Number(m.meta.usage.total_tokens) ? Number(m.meta.usage.total_tokens) : 0), 0);
  return '<div class="ai-chat"><div class="ai-chat-head"><div><div class="ai-section-title" style="margin:0">和 AI 说 <span class="hint">长期对话 · ' + all.length + ' 条' + (totalTokens ? ' · ' + totalTokens + ' tokens' : '') + '</span></div><div class="ai-chat-context-label">' + escapeHtml(aiChatContextLine()) + '</div></div><button class="btn tiny" id="btnAiChatClear" title="清空对话历史">清空对话</button></div>' +
    '<div class="ai-context-chips">' + chip('selection', '选区图') + chip('canvas', '整幅画布') + chip('library', '素材库') + chip('archive', '档案/证据') + chip('profile', '画像') + '</div>' +
    (msgs ? '<div class="ai-chat-log">' + msgs + '</div>' : '<div class="hint">可以问：这里为什么平？整幅画下一步怎么改？参考素材里哪张更接近？我的风格偏好是什么？</div>') +
    aiProfileHtml() +
    '<div class="ai-chat-quick"><button class="ai-intent-chip" data-chat-quick="这里为什么显得平？">为什么平？</button><button class="ai-intent-chip" data-chat-quick="结合我的素材库和整幅画，下一步最值得改哪里？">结合素材看整幅</button><button class="ai-intent-chip" data-chat-quick="保留我的笔触，只帮我把主体和背景拉开。">保留笔触</button></div>' +
    '<form class="ai-chat-form" id="aiChatForm"><textarea id="aiChatInput" rows="2" placeholder="直接问 AI…（Enter 发送 / Shift+Enter 换行）"></textarea><button class="btn primary tiny" id="btnAiChatSend" type="submit">发送</button></form></div>';
}
function bindAiChat(host) {
  const form = host.querySelector('#aiChatForm');
  if (!form) return;
  const input = host.querySelector('#aiChatInput');
  if (input) input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); } });
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input ? input.value.trim() : '';
    if (!text) return;
    if (input) input.value = '';
    runChat(text).catch((err) => showToast('对话失败：' + (err.message || err), true));
  });
  host.querySelectorAll('[data-chat-quick]').forEach((b) => b.addEventListener('click', () => { if (input) { input.value = b.dataset.chatQuick; input.focus(); } }));
  host.querySelectorAll('[data-chat-ctx]').forEach((b) => b.addEventListener('click', () => {
    const key = b.dataset.chatCtx;
    state.aiChatContext[key] = !(state.aiChatContext[key] !== false && state.aiChatContext[key]);
    renderAIPanel();
  }));
  host.querySelectorAll('[data-chat-action]').forEach((b) => b.addEventListener('click', () => {
    const parts = String(b.dataset.chatAction || '').split(':').map(Number);
    const msg = state.aiChat[parts[0]];
    const action = msg && Array.isArray(msg.actions) ? msg.actions[parts[1]] : null;
    if (action) executeChatAction(action);
  }));
  const clear = host.querySelector('#btnAiChatClear'); if (clear) clear.addEventListener('click', clearAiChat);
  const memClear = host.querySelector('#btnAiMemoryClear'); if (memClear) memClear.addEventListener('click', clearAiMemory);
  const useHints = host.querySelector('#btnUseProfileHints');
  if (useHints) useHints.addEventListener('click', () => {
    const h = deriveProfileHints();
    const words = [...new Set([...h.tags, ...h.mood])].slice(0, 6);
    if (!words.length) return;
    state.aiProfile.style = [...new Set([...(String(state.aiProfile.style || '').split(/[、,，\s]+/).filter(Boolean)), ...words])].join('、').slice(0, 300);
    saveAiProfile();
    renderAIPanel();
    const d = document.querySelector('.ai-profile'); if (d) d.open = true;
    showToast('已把素材决策里的关键词写入画像；可继续编辑');
  });
  const bindProfile = (id, key) => { const el = host.querySelector('#' + id); if (el) el.addEventListener('input', () => { state.aiProfile[key] = el.value; saveAiProfile(); }); };
  bindProfile('aiProfileStyle', 'style'); bindProfile('aiProfileAvoid', 'avoid'); bindProfile('aiProfileMedium', 'medium'); bindProfile('aiProfileNotes', 'notes');
  const log = host.querySelector('.ai-chat-log');
  if (log) log.scrollTop = log.scrollHeight;
}
function buildChatContext() {
  const flags = state.aiChatContext || {};
  const layers = engine.getLayers();
  const active = activeLayer();
  const assets = state.library.assets || [];
  const refs = (state.aiWorkshopRefs || []).length ? state.aiWorkshopRefs : (state.aiReference ? [state.aiReference] : []);
  return {
    canvas: { width: engine.width, height: engine.height, layers: layers.length, visible: layers.filter((l) => l.visible !== false).length, active_layer: active ? active.name : null, tool: state.tool, mode: state.mode, ai_role: state.aiRole },
    selection: state.selection || null,
    library: flags.library === false ? null : {
      count: assets.length,
      preferences: state.library.prefs || null,
      referenced: refs.map((r) => ({ id: r.id, fileName: r.fileName })),
      assets: assets.slice(0, 10).map((a) => ({ id: a.id, fileName: a.fileName, tags: (a.tags || []).slice(0, 8), L1: a.L1 ? { summary: a.L1.summary, subject: (a.L1.subject || []).slice(0, 5), mood: (a.L1.mood || []).slice(0, 5) } : null, palette: (a.palette || []).slice(0, 6), analysisSource: a.analysisSource || 'mock' })),
    },
    archive: flags.archive === false ? null : aiArchiveSummary(),
    recent_events: flags.archive === false ? null : (state.records || []).slice(-12).map((r) => ({ layer: r.layer, kind: r.kind, note: String(r.note || '').slice(0, 80), ai_role: r.ai_role || null, model: r.model || null })),
    decisions: { confirmed: (state.library.assets || []).reduce((n, a) => n + ((a.L5 || []).filter((d) => d.kind === 'confirm').length), 0), rejected: (state.library.assets || []).reduce((n, a) => n + ((a.L5 || []).filter((d) => d.kind === 'reject').length), 0) },
    profile: flags.profile === false ? null : (state.aiProfile || {}),
    context_flags: flags,
    conversation_count: (state.aiChat || []).length,
  };
}
async function chatCanvasImage() {
  try {
    const url = await engine.getCompositeDataUrl();
    const img = new Image(); img.src = url; await img.decode();
    const maxSide = 1024;
    const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(img.width * scale)); c.height = Math.max(1, Math.round(img.height * scale));
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.86);
  } catch (e) { return null; }
}
async function runChat(text) {
  if (!text) return null;
  if (state.mode === 'attest') { showToast('存证模式已禁用 AI', true); return null; }
  if (state.aiBusy) { showToast('AI 正在处理上一个请求，请稍候', true); return null; }
  const real = aiRealEligible();
  if (real && !(await confirmAiSend('将把对话、画布/选区图、档案与素材摘要发送给 ' + aiProviderLabel() + ' / ' + aiRuntimeModel() + '，用于多轮协作回答'))) return null;
  const sel = state.selection || selectionOrDefault();
  const ac = new AbortController(); state.aiAbort = ac;
  state.aiChat.push({ role: 'user', content: text });
  saveAiChat();
  aiBeginTask('AI 正在回答…');
  renderAIPanel();
  try {
    const flags = state.aiChatContext || {};
    const images = [];
    if (flags.selection !== false) { try { images.push((await aiSelectionCropAsync('analyze')).dataUrl); } catch (e) { /* ignore */ } }
    if (flags.canvas) { const full = await chatCanvasImage(); if (full) images.push(full); }
    const provider = aiGetProvider({ signal: ac.signal });
    const ctx = buildChatContext();
    const res = await provider.converse({
      text, images, image: images[0] || null, selection: { ...sel }, history: state.aiChat.slice(0, -1),
      live: liveContext(), analysis: state.analysis, archive: ctx.archive, library: ctx.library,
      events: ctx.recent_events, profile: ctx.profile, context: ctx, mode: state.mode, aiRole: state.aiRole,    });
    state.aiLastCall = aiCallMeta(res, 'chat');
    state.aiChat.push({ role: 'assistant', content: res.text, actions: Array.isArray(res.actions) ? res.actions : [], meta: res.meta || state.aiLastCall });
    saveAiChat();
    aiEndTask();
    const hs = document.getElementById('aiStatus'); if (hs) hs.textContent = '回答完成';
    recordAiCall('chat', 'ok', state.aiLastCall, { question: text.slice(0, 120), answer: String(res.text || '').slice(0, 200), context_flags: { ...flags }, images: images.length, history: state.aiChat.length - 2 });
    aiLog('chat', '回答：' + String(res.text || '').slice(0, 36), state.aiLastCall);
    renderAIPanel();
    return res;
  } catch (e) {
    console.error(e);
    aiEndTask();
    if (e && (e.code === 'cancelled' || e.name === 'AbortError')) { aiPhase('已取消'); return null; }
    state.aiLastCall = { provider: aiRealEligible() ? aiPreset().provider : 'mock', model: aiRuntimeModel(), mock: !aiRealEligible(), task: 'chat', status: 'error', errorCode: e.code || 'ai_error', latencyMs: 0, at: iso() };
    const hs = document.getElementById('aiStatus'); if (hs) hs.textContent = '对话失败';
    recordAiCall('chat', 'error', state.aiLastCall, { error_code: e.code || 'ai_error', error_message: (e.userMessage || e.message || String(e)).slice(0, 200) });
    state.aiChat.push({ role: 'assistant', content: '（失败）' + (e.userMessage || e.message || e), meta: { mock: true } });
    saveAiChat();
    renderAIPanel();
    return null;
  }
}
function aiIntentHtml() {
  const chips = ['更亮', '更暗', '更冷', '更暖', '保留笔触', '别动主体'];
  return '<div class="ai-intent"><div class="ai-intent-title">告诉 AI 你的意图 <span class="hint">（可选，会随选区一起发送）</span></div>' +
    '<textarea id="aiIntentInput" rows="2" placeholder="例如：让雾更冷、主体边缘更干净，但保留我的笔触">' + escapeHtml(state.aiIntent || '') + '</textarea>' +
    '<div class="ai-intent-chips">' + chips.map((c) => '<button class="ai-intent-chip" data-intent="' + escapeHtml(c) + '">' + escapeHtml(c) + '</button>').join('') + '</div>' +
    '<div class="ai-intent-actions"><button class="btn tiny" id="btnAnnotateToggle">' + (state.annotationMode ? '✅ 完成标注' : '✏️ 在画布上标注') + '</button><button class="btn tiny" id="btnAnnotateClear">清空标注</button><button class="btn tiny" id="btnAiVoice">🎤 语音说</button><span class="ai-voice-state" id="aiVoiceState"></span></div></div>';
}
function bindAiIntent(host) {
  if (!host) return;
  const ta = host.querySelector('#aiIntentInput');
  if (ta) {
    ta.addEventListener('input', () => { state.aiIntent = ta.value; });
  }
  host.querySelectorAll('[data-intent]').forEach((btn) => btn.addEventListener('click', () => {
    const v = btn.dataset.intent;
    if (!ta) return;
    const cur = ta.value.trim();
    ta.value = cur ? (cur + '，' + v) : v;
    state.aiIntent = ta.value;
    ta.focus();
  }));
  const ann = host.querySelector('#btnAnnotateToggle'); if (ann) ann.addEventListener('click', () => toggleAnnotationMode());
  const clr = host.querySelector('#btnAnnotateClear'); if (clr) clr.addEventListener('click', () => { clearAnnotationInk(); renderAIPanel(); });
  const voice = host.querySelector('#btnAiVoice'); if (voice) voice.addEventListener('click', () => startVoiceInput(voice));
}
function startVoiceInput(btn) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { showToast('当前浏览器不支持语音识别；可改用文字或画布标注', true); return; }
  if (state.voiceRec) { try { state.voiceRec.stop(); } catch (e) { /* ignore */ } state.voiceRec = null; if (btn) btn.textContent = '🎤 语音说'; return; }
  const ta = document.getElementById('aiIntentInput');
  const base = ta ? ta.value.trim() : '';
  let rec = null;
  try { rec = new SR(); } catch (e) { showToast('语音初始化失败：' + (e.message || e), true); return; }
  rec.lang = 'zh-CN'; rec.interimResults = true; rec.continuous = false;
  state.voiceRec = rec;
  if (btn) btn.textContent = '🔴 正在听…（点此停止）';
  const st = document.getElementById('aiVoiceState'); if (st) st.textContent = '正在听…';
  rec.onresult = (e) => {
    let txt = '';
    for (let i = e.resultIndex; i < e.results.length; i += 1) txt += e.results[i][0].transcript;
    if (ta) { ta.value = (base ? base + ' ' : '') + txt; state.aiIntent = ta.value; }
  };
  rec.onerror = (e) => { const st2 = document.getElementById('aiVoiceState'); if (st2) st2.textContent = '语音不可用：' + (e.error || 'error'); showToast('语音识别失败：' + (e.error || 'error'), true); };
  rec.onend = () => { state.voiceRec = null; if (btn) btn.textContent = '🎤 语音说'; const st2 = document.getElementById('aiVoiceState'); if (st2) st2.textContent = ''; };
  try { rec.start(); } catch (e) { state.voiceRec = null; if (btn) btn.textContent = '🎤 语音说'; showToast('语音启动失败：' + (e.message || e), true); }
}
function locateObservation(id) {
  const rec = observationRecord(id);
  const b = rec && rec.anchor && Array.isArray(rec.anchor.value) ? rec.anchor.value : null;
  if (!b || b.length < 4) { showToast('该观察没有锚点坐标', true); return; }
  state.selection = { x: b[0], y: b[1], width: b[2], height: b[3] };
  drawSelection();
  if (state.aiOverlayVisible) renderAiCanvasOverlay();
  showToast('已在画布上标出 AI 观察锚点：' + b.map((n) => Math.round(n)).join(', '));
}
function renderAiCanvasOverlay() {
  const c = document.getElementById('aiSuggestionCanvas');
  if (!c) return;
  const ctx = c.getContext('2d');
  if (c.width !== engine.width || c.height !== engine.height) { c.width = engine.width; c.height = engine.height; }
  ctx.clearRect(0, 0, c.width, c.height);
  if (!state.aiOverlayVisible || !state.analysis) return;
  const obs = state.analysis.observations || [];
  const regions = state.analysis.regions || [];
  ctx.save();
  ctx.lineWidth = 2.5;
  ctx.setLineDash([9, 6]);
  ctx.font = '600 20px "Segoe UI", "Microsoft YaHei", sans-serif';
  ctx.textBaseline = 'top';
  let i = 0;
  for (const o of obs) {
    const b = o.anchor && Array.isArray(o.anchor.value) ? o.anchor.value : null;
    if (!b || b.length < 4) continue;
    i += 1;
    const x = b[0], y = b[1], w = b[2], h = b[3];
    ctx.strokeStyle = 'rgba(245,158,11,.95)';
    ctx.strokeRect(x, y, w, h);
    ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(245,158,11,.95)';
    ctx.beginPath(); ctx.arc(x + 14, y + 14, 12, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#1f2937'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(String(i), x + 14, y + 14);
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    const label = (o.text || o.kind || '观察').slice(0, 18);
    const tw = ctx.measureText(label).width + 14;
    ctx.fillStyle = 'rgba(15,23,42,.86)';
    ctx.fillRect(x, Math.max(0, y - 30), tw, 26);
    ctx.fillStyle = '#fde68a';
    ctx.fillText(label, x + 7, Math.max(0, y - 30) + 4);
    ctx.setLineDash([9, 6]); ctx.strokeStyle = 'rgba(245,158,11,.95)';
  }
  ctx.setLineDash([]);
  for (const r of regions) {
    const b = r.bbox; if (!Array.isArray(b) || b.length < 4) continue;
    ctx.strokeStyle = 'rgba(96,165,250,.9)';
    ctx.strokeRect(b[0], b[1], b[2], b[3]);
  }
  ctx.restore();
}
function toggleAiCanvasOverlay(force) {
  state.aiOverlayVisible = force == null ? !state.aiOverlayVisible : !!force;
  renderAiCanvasOverlay();
  renderAIPanel();
  showToast(state.aiOverlayVisible ? '已显示 AI 标注层：橙色框=观察，蓝色框=区域；不写档案' : '已隐藏 AI 标注层');
}
function renderAIPanel() {
  renderAIReferenceBar();
  renderAiPinnedStatus();
  const host = $('aiBody');
  if (!host) return;
  const modelLine = aiProviderLabel() + ' / ' + aiRuntimeModel();
  if (!state.analysis) {
    const selNow = state.selection;
    host.innerHTML =
      '<div class="ai-ctx"><div class="ai-ctx-title">正在与谁协作</div>' +
        '<div class="ai-ctx-row"><span>模型</span><b>' + escapeHtml(modelLine) + '</b></div>' +
        '<div class="ai-ctx-row"><span>模式</span><b>' + (aiRealEligible() ? '真实调用（每次会先确认）' : '本地 Mock（无网络请求）') + '</b></div>' +
        '<div class="ai-ctx-row"><span>上下文</span><b>' + (selNow ? ('选区 ' + Math.round(selNow.width) + '×' + Math.round(selNow.height)) : '未框选（默认取中部区域）') + ' · 档案 ' + state.records.filter((r) => ['L1', 'L2', 'L4'].includes(r.layer)).length + ' 条' + ((state.aiWorkshopRefs || []).length ? ' · 素材参考 ' + (state.aiWorkshopRefs || []).length + ' 张' : '') + '</b></div>' +
        '<div class="ai-ctx-row"><span>成本</span><b>' + (aiRealEligible() ? '真实调用已开启；生图/编辑约 ¥0.18/张' : 'Mock · ¥0 · 不联网') + '</b></div>' +
      '</div>' +
      '<div class="ai-empty"><div class="ai-empty-title">先做一件事：圈出来，让 AI 看看</div><div class="hint">① 选择工具框一块 → ② 点选区旁「✨ AI 看这里」→ ③ 确认/否决观察 → ④ 选方向、生成方案 → ⑤ 落为新图层；AI 不直接改原画。</div><div class="ai-entry"><button class="btn tiny" id="btnAiSettingsInline">AI 模型接入</button><button class="btn tiny" id="btnAiModelTabInline">接口状态</button><button class="btn tiny" id="btnAiImageTabInline">AI 图像工作台</button></div></div>' +
      aiIntentHtml() + aiChatHtml();
    bindAiIntent(host);
    bindAiChat(host);
    const s1 = document.getElementById('btnAiSettingsInline'); if (s1) s1.addEventListener('click', openAiSettingsPanel);
    const s2 = document.getElementById('btnAiModelTabInline'); if (s2) s2.addEventListener('click', () => switchAiTab('model'));
    const s3 = document.getElementById('btnAiImageTabInline'); if (s3) s3.addEventListener('click', () => switchAiTab('image'));
    return;
  }
  const a = state.analysis;
  const meta = state.aiLastCall || a.meta || {};
  const modelText = aiProviderLabel(meta) + ' / ' + (meta.modelVersion || meta.model || aiRuntimeModel());
  const realCall = meta.mock === false;
  const tokens = meta.usage && meta.usage.total_tokens ? (' · ' + meta.usage.total_tokens + ' tokens') : '';
  const sel = state.selection || { width: 0, height: 0 };
  const refsCount = state.records.filter((r) => ['L1', 'L2', 'L4'].includes(r.layer)).length;
  const workshopRefs = (state.aiWorkshopRefs || []).length;
  const costLine = realCall
    ? '本次视觉调用已计费（按 tokens）；下一步生图/编辑约 ¥0.18/张'
    : 'Mock · ¥0 · 不联网';
  const dirLen = state.directions ? state.directions.length : 0;
  const stepNow = state.candidates ? (state.generatedCandidateId ? 5 : 4) : (state.directions ? 3 : 2);
  const steps = ['选区', '观察', '方向', '候选', '落层'];
  let html = '<div class="ai-steps">' + steps.map((s, i) => '<span class="ai-step' + (i + 1 < stepNow ? ' done' : '') + (i + 1 === stepNow ? ' active' : '') + '">' + (i + 1) + ' ' + s + '</span>').join('') + '</div>';
  html += '<div class="ai-ctx"><div class="ai-ctx-title">本次协作上下文</div>' +
    '<div class="ai-ctx-row"><span>模型</span><b>' + escapeHtml(modelText) + '</b></div>' +
    '<div class="ai-ctx-row"><span>模式</span><b>' + (realCall ? '真实调用' : 'Mock') + ' · ' + (meta.latencyMs || 0) + 'ms' + tokens + '</b></div>' +
    '<div class="ai-ctx-row"><span>范围</span><b>选区 ' + Math.round(sel.width) + '×' + Math.round(sel.height) + ' · 档案 ' + refsCount + ' 条' + (state.aiReference ? ' · 素材参考 ' + escapeHtml(state.aiReference.fileName || '') : '') + '</b></div>' +
    '<div class="ai-ctx-row"><span>将发送</span><b>选区图' + (annotationInk() ? ' + 手绘标注' : '') + ' + 档案摘要' + (workshopRefs ? ' + 素材参考 ' + workshopRefs + ' 张' : '') + '</b></div>' +
    '<div class="ai-ctx-row"><span>成本</span><b>' + escapeHtml(costLine) + '</b></div>' +
    '<div class="ai-ctx-row"><span>实时</span><b>' + escapeHtml((() => { const l = activeLayer(); return (l ? l.name : '—') + ' · ' + state.tool + (annotationInk() ? ' · 有手绘标注' : ''); })()) + '</b></div>' +
    '<div class="ai-ctx-row"><span>档案</span><b><button class="btn tiny" id="btnCtxArchive">查看档案 / 证据</button></b></div></div>';
  html += aiIntentHtml();
  html += '<div class="ai-entry"><button class="btn tiny" id="btnToggleAiOverlay">' + (state.aiOverlayVisible ? '隐藏画布 AI 标注' : '在画布显示 AI 标注') + '</button><span class="hint">橙色框=观察 / 蓝色框=区域；不落层、不写档案</span></div>';
  html += '<div class="ai-summary"><div class="ai-sum-title">' + escapeHtml(a.global.summary) + '</div><div class="ai-meta">' + escapeHtml(a.global.subject.join(' · ')) + ' · ' + escapeHtml((a.global.medium && a.global.medium.kind) || '未识别媒介') + ' · 置信度 ' + fmtPct(a.confidence) + '</div></div>';
  html += '<div class="ai-section-title">观察（' + a.observations.length + '）· 每条可确认/否决</div>';
  for (const obs of a.observations) {
    const rec = observationRecord(obs.id);
    const status = rec ? rec.source : 'inferred';
    const anchorText = obs.anchor && Array.isArray(obs.anchor.value) ? obs.anchor.value.map((n) => Math.round(n)).join(',') : '整图/无坐标';
    html += '<div class="obs-card ' + (status === 'user-confirmed' ? 'confirmed' : '') + '"><div class="obs-head"><span class="badge ' + status + '">' + (status === 'user-confirmed' ? '已确认' : 'AI 推断') + '</span><span class="obs-conf">' + fmtPct(obs.confidence) + '</span></div><div class="obs-text">' + escapeHtml(obs.text) + '</div><div class="obs-foot"><button class="btn tiny" data-obs="' + obs.id + '" data-accept="1">确认</button><button class="btn tiny danger" data-obs="' + obs.id + '" data-accept="0">否决</button><button class="btn tiny ai-locate-btn" data-locate="' + obs.id + '">在画布定位</button><span class="obs-anchor">锚点 ' + anchorText + '</span></div></div>';
  }
  if (!state.directions) {
    html += '<button class="btn primary ai-cta" id="btnGetDirections">让 AI 给 2 个方向（下一步）</button>';
  } else {
    html += '<div class="ai-section-title">方向（' + dirLen + '）· 先选一个，再生成方案</div>';
    for (const d of state.directions) {
      const selected = state.selectedDirection && state.selectedDirection.id === d.id;
      html += '<div class="dir-card' + (selected ? ' selected' : '') + '" data-dir-select="' + d.id + '" role="button" tabindex="0"><div class="dir-head"><b>' + escapeHtml(d.title) + '</b><span class="obs-conf">' + fmtPct(d.confidence) + '</span></div><div class="dir-why">' + escapeHtml(d.why) + '</div><div class="obs-foot"><span class="badge ' + (selected ? 'user-confirmed' : 'inferred') + '">' + (selected ? '已选方向' : '点选') + '</span><span class="obs-anchor">' + escapeHtml((d.tags || []).join(' · ')) + '</span></div></div>';
    }
    html += '<button class="btn primary ai-cta" id="btnGenFromDir"' + (state.selectedDirection ? '' : ' disabled') + '>用所选方向生成局部方案</button>';
  }
  if (state.candidates) {
    html += '<div class="ai-section-title">局部方案（选区裁切 patch → 新图层，不是原地重绘）</div>';
    const _lm = state.aiLastCall || {};
    const _prov = aiProviderLabel(_lm);
    const _mock = _lm.mock !== false;
    const _isQwen = /qwen/i.test(String(_lm.provider || '') + ' ' + String(_lm.modelVersion || _lm.model || ''));
    html += '<div class="ai-candidate-note">' + escapeHtml(_prov + ' / ' + (_lm.modelVersion || _lm.model || aiRuntimeModel()) + (_mock ? ' · Mock ¥0' : (_isQwen ? ' · 约 ¥0.18/张 · 异步排队 · 1/1 串行 · 局部 patch' : ' · 预计 ¥0.2/张 · 1/1 串行')) + ' · 落层按选区 mask 裁切，框外保留') + '</div>';
    state.candidates.forEach((c, i) => {
      const active = state.previewCandidateIndex === i;
      const comparing = state.compareCandidateIndex === i;
      html += '<div class="cand-card"><img class="cand-img" src="' + c.imageDataUrl + '" alt="' + escapeHtml(c.label) + '"><div class="cand-body"><b>' + escapeHtml(c.label) + '</b><div class="hint">' + escapeHtml(c.why || '') + '</div><button class="btn tiny primary" data-cand="' + i + '">落为新图层</button><button class="btn tiny" data-preview-cand="' + i + '">' + (active ? '隐藏画布预览' : '在画布上预览') + '</button><button class="btn tiny" data-compare-cand="' + i + '">' + (comparing ? '关闭对比' : '对比原图') + '</button></div></div>';
      html += candidateCompareHtml(c, i, state.selection || selectionOrDefault());
    });
    html += '<button class="btn tiny" id="btnRetryGen">重新生成 2 个候选（会再次计费）</button>';
  }
  html += renderAiSessionHtml();
  html += aiChatHtml();
  host.innerHTML = html;
  bindAiIntent(host);
  bindAiChat(host);
  host.querySelectorAll('[data-obs]').forEach((btn) => btn.addEventListener('click', () => confirmObservation(btn.dataset.obs, btn.dataset.accept === '1')));
  host.querySelectorAll('[data-locate]').forEach((btn) => btn.addEventListener('click', () => locateObservation(btn.dataset.locate)));
  const dirBtn = host.querySelector('#btnGetDirections');
  if (dirBtn) dirBtn.addEventListener('click', () => runDirections().catch((e) => showToast(e.message, true)));
  host.querySelectorAll('[data-dir-select]').forEach((card) => {
    const pick = () => { state.selectedDirection = (state.directions || []).find((d) => d.id === card.dataset.dirSelect) || null; renderAIPanel(); };
    card.addEventListener('click', pick);
    card.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } });
  });
  const genBtn = host.querySelector('#btnGenFromDir');
  if (genBtn) genBtn.addEventListener('click', () => { if (state.selectedDirection) runGenerate(state.selectedDirection.id).catch((e) => showToast(e.message, true)); });
  host.querySelectorAll('[data-cand]').forEach((btn) => btn.addEventListener('click', () => applyCandidate(parseInt(btn.dataset.cand, 10))));
  host.querySelectorAll('[data-preview-cand]').forEach((btn) => btn.addEventListener('click', () => previewCandidate(parseInt(btn.dataset.previewCand, 10))));
  host.querySelectorAll('[data-compare-cand]').forEach((btn) => btn.addEventListener('click', () => { const i = parseInt(btn.dataset.compareCand, 10); state.compareCandidateIndex = state.compareCandidateIndex === i ? null : i; renderAIPanel(); }));
  bindCandidateCompare(host);
  const ctxArch = host.querySelector('#btnCtxArchive'); if (ctxArch) ctxArch.addEventListener('click', () => switchAiTab('archive'));
  const aiOverlayBtn = host.querySelector('#btnToggleAiOverlay'); if (aiOverlayBtn) aiOverlayBtn.addEventListener('click', () => toggleAiCanvasOverlay());
  if (state.aiOverlayVisible) renderAiCanvasOverlay();
  const retry = host.querySelector('#btnRetryGen'); if (retry) retry.addEventListener('click', () => { if (state.selectedDirection) runGenerate(state.selectedDirection.id).catch((e) => showToast(e.message, true)); });
}

/* ---------------- 档案 / 证据 ---------------- */
function renderAiPinnedStatus() {
  const host = document.getElementById('aiPinnedStatus');
  if (!host) return;
  const real = aiRealEligible();
  const sel = state.selection;
  const refs = (state.aiReference ? 1 : 0) + ((state.aiWorkshopRefs || []).length);
  const assetsCount = (state.library.assets || []).length;
  const archiveCount = state.records.filter((r) => ['L1', 'L2', 'L4'].includes(r.layer)).length;
  const last = state.aiLastCall;
  const latency = last && last.latencyMs ? (' · ' + last.latencyMs + 'ms') : '';
  host.innerHTML = '<b>' + escapeHtml(aiProviderLabel()) + '</b>' +
    '<span class="' + (real ? 'pin-real' : 'pin-mock') + '">' + (real ? '真实' : 'Mock') + '</span>' +
    '<span class="pin-sep">·</span><span>选区 ' + (sel ? (Math.round(sel.width) + '×' + Math.round(sel.height)) : '未框选') + '</span>' +
    '<span class="pin-sep">·</span><span>素材库 ' + assetsCount + ' · 引用 ' + refs + ' · 档案 ' + archiveCount + '</span>' +
    '<span class="pin-sep">·</span><span class="pin-cost">' + (real ? '约 ¥0.18/张' : '¥0 · 不联网') + latency + '</span>';
}
function updateStatusContext() {
  const el = document.getElementById('statusContext');
  if (!el) return;
  const l = activeLayer();
  const toolNames = { brush: '画笔', eraser: '橡皮', smudge: '涂抹', select: '选择', transform: '变换', move: '移动', text: '文字', shape: '形状' };
  const mode = state.mode === 'attest' ? '存证' : '协作';
  const ai = aiRealEligible() ? aiProviderLabel() + ' 真实' : 'Mock';
  el.textContent = (l ? l.name : '无图层') + ' · ' + (toolNames[state.tool] || state.tool) + ' · ' + ai + ' · ' + mode;
}
function switchAiTab(name) {
  const logical = (name === 'archive' || name === 'evidence') ? 'records' : name;
  const ids = { obs: 'aiTabObs', records: 'aiTabRecords', model: 'aiTabModel', image: 'aiTabImage' };
  Object.entries(ids).forEach(([k, id]) => { const el = document.getElementById(id); if (el) el.style.display = k === logical ? '' : 'none'; });
  document.querySelectorAll('.ai-tab').forEach((b) => { const on = b.dataset.aiTab === logical; b.classList.toggle('active', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); });
  const badge = document.getElementById('aiProviderBadge');
  if (badge) badge.classList.toggle('active-tab', logical === 'model');
  if (logical === 'records') setRecordSubtab(name === 'evidence' ? 'evidence' : (name === 'archive' ? 'archive' : (state.aiRecordSubtab || 'archive')));
  if (logical === 'model') renderAiModelTab();
  if (logical === 'image') renderAiImageTab();
  if (logical === 'obs') renderAIPanel();
}
function setRecordSubtab(kind) {
  state.aiRecordSubtab = kind === 'evidence' ? 'evidence' : 'archive';
  const a = document.getElementById('aiRecordArchive');
  const e = document.getElementById('aiRecordEvidence');
  if (a) a.style.display = state.aiRecordSubtab === 'archive' ? '' : 'none';
  if (e) e.style.display = state.aiRecordSubtab === 'evidence' ? '' : 'none';
  document.querySelectorAll('[data-record-tab]').forEach((b) => b.classList.toggle('active', b.dataset.recordTab === state.aiRecordSubtab));
  if (state.aiRecordSubtab === 'archive') renderArchive();
  else renderAiEvidence();
}
function renderAiImageTab() {
  const host = document.getElementById('aiImageBody');
  if (!host) return;
  const p = aiPreset();
  const canGen = !!p.imageGen;
  const canEdit = !!p.imageEdit;
  const scope = state.aiImageScope || 'selection';
  const cands = state.candidates || [];
  const assets = state.library.assets || [];
  const refs = state.aiWorkshopRefs || [];
  const orderedAssets = (() => {
    try {
      const recs = rankAssetsForSelection(assets, { intent: state.aiImagePrompt || '', selection: state.selection || null, limit: 12 });
      if (recs && recs.length) { const seen = new Set(); return [...recs.map((x) => x.asset), ...assets].filter((a) => { if (!a || seen.has(a.id)) return false; seen.add(a.id); return true; }); }
    } catch (e) { /* ignore */ }
    return assets;
  })();
  const refHtml = refs.length
    ? refs.map((r) => '<span class="ai-ref-chip">' + escapeHtml((r.fileName || '').replace(/\.[^.]+$/, '')) + '<button data-ref-remove="' + escapeHtml(r.id) + '">×</button></span>').join('')
    : '<span class="hint">未引用素材（最多 3 张，会随生成/编辑一起发送）</span>';
  const pickHtml = orderedAssets.slice(0, 12).map((a) => '<button class="ai-ref-pick' + (refs.some((r) => r.id === a.id) ? ' active' : '') + '" data-ref-pick="' + escapeHtml(a.id) + '" title="' + escapeHtml(a.fileName || '') + '">' + escapeHtml((a.fileName || '素材').replace(/\.[^.]+$/, '').slice(0, 10)) + '</button>').join('');
  const cards = cands.map((c, i) => '<div class="cand-card"><img class="cand-img" src="' + c.imageDataUrl + '" alt="' + escapeHtml(c.label) + '"><div class="cand-body"><b>' + escapeHtml(c.label) + '</b><div class="hint">' + escapeHtml(c.why || '') + '</div><button class="btn tiny primary" data-img-apply="' + i + '">落为新图层</button><button class="btn tiny" data-img-preview="' + i + '">在画布预览</button><button class="btn tiny" data-img-save="' + i + '">存回素材库</button></div></div>').join('');
  host.innerHTML =
    '<div class="ai-ctx"><div class="ai-ctx-title">AI 图像工作台</div>' +
      '<div class="ai-ctx-row"><span>模型</span><b>' + escapeHtml(aiProviderLabel() + ' / ' + aiRuntimeModel()) + '</b></div>' +
      '<div class="ai-ctx-row"><span>能力</span><b>图像理解 ' + (p.vision !== false ? '✓' : '—') + ' · 生成 ' + (canGen ? '✓' : '—') + ' · 编辑 ' + (canEdit ? '✓' : '—') + '</b></div>' +
      '<div class="ai-ctx-row"><span>输出</span><b>落为新图层后，可继续变换 / 蒙版 / 再次修改</b></div></div>' +
    '<div class="ai-intent"><div class="ai-intent-title">描述你想生成或修改成什么</div>' +
      '<textarea id="aiImagePrompt" rows="3" placeholder="例如：把这片山谷改成清晨冷雾，保留我的笔触；或：把主体换成一只白鹤">' + escapeHtml(state.aiImagePrompt || '') + '</textarea>' +
      '<div class="ai-intent-actions"><button class="btn tiny' + (scope === 'selection' ? ' primary' : '') + '" id="btnImgScopeSel">输入：选区</button><button class="btn tiny' + (scope === 'canvas' ? ' primary' : '') + '" id="btnImgScopeCanvas">输入：整张画布</button><button class="btn tiny' + (scope === 'layer' ? ' primary' : '') + '" id="btnImgScopeLayer">输入：当前图层</button></div>' +
      '<div class="ai-image-refs"><div class="ai-intent-title">素材库参考 <span class="hint">（生成最多带 3 张；编辑时选区算 1 张，参考最多 2 张）</span></div><div class="ai-ref-chips">' + refHtml + '</div><div class="ai-ref-picks">' + (pickHtml || '<span class="hint">素材库为空：导入一张后即可作为生成参考</span>') + '</div></div>' +
      '<div class="ai-entry" style="margin-top:6px"><button class="btn primary tiny" id="btnImgGenerate"' + (canGen ? '' : ' disabled') + '>生成 2 张新图</button><button class="btn tiny" id="btnImgEdit"' + (canEdit ? '' : ' disabled') + '>按描述修改这张图</button></div>' +
      '<div class="hint">生成/编辑会落地为新图层，原画不动；真实调用前会确认并显示模型。Qwen 图像编辑约 30–120s。</div></div>' +
    (cards ? '<div class="ai-section-title">结果（先画布预览，再落层；可存回素材库复用）</div>' + cards : '<div class="hint">还没有结果。选「输入：选区」可只改框内；选「整张画布」可整体编辑；引用素材后可让模型参考它们。</div>');
  if (!assets.length) { ensureSampleLibrary().then(() => renderAiImageTab()).catch(() => {}); }
  const ta = host.querySelector('#aiImagePrompt');
  if (ta) ta.addEventListener('input', () => { state.aiImagePrompt = ta.value; });
  const s1 = host.querySelector('#btnImgScopeSel'); if (s1) s1.addEventListener('click', () => { state.aiImageScope = 'selection'; renderAiImageTab(); });
  const s2 = host.querySelector('#btnImgScopeCanvas'); if (s2) s2.addEventListener('click', () => { state.aiImageScope = 'canvas'; renderAiImageTab(); });
  const s3 = host.querySelector('#btnImgScopeLayer'); if (s3) s3.addEventListener('click', () => { state.aiImageScope = 'layer'; renderAiImageTab(); });
  const gen = host.querySelector('#btnImgGenerate'); if (gen) gen.addEventListener('click', () => runImageWorkshop('generate'));
  const ed = host.querySelector('#btnImgEdit'); if (ed) ed.addEventListener('click', () => runImageWorkshop('edit'));
  host.querySelectorAll('[data-img-apply]').forEach((b) => b.addEventListener('click', () => applyCandidate(parseInt(b.dataset.imgApply, 10))));
  host.querySelectorAll('[data-img-preview]').forEach((b) => b.addEventListener('click', () => previewCandidate(parseInt(b.dataset.imgPreview, 10))));
  host.querySelectorAll('[data-img-save]').forEach((b) => b.addEventListener('click', () => saveCandidateToLibrary(parseInt(b.dataset.imgSave, 10))));
  host.querySelectorAll('[data-ref-pick]').forEach((b) => b.addEventListener('click', () => toggleWorkshopRef(b.dataset.refPick)));
  host.querySelectorAll('[data-ref-remove]').forEach((b) => b.addEventListener('click', () => toggleWorkshopRef(b.dataset.refRemove)));
}
function toggleWorkshopRef(id) {
  const refs = state.aiWorkshopRefs || [];
  const i = refs.findIndex((r) => r.id === id);
  if (i >= 0) refs.splice(i, 1);
  else {
    if (refs.length >= 3) { showToast('素材参考最多 3 张', true); return; }
    const a = (state.library.assets || []).find((x) => x.id === id);
    if (!a) return;
    refs.push({ id: a.id, fileName: a.fileName, sha256: a.sha256 });
  }
  state.aiWorkshopRefs = refs;
  renderAiImageTab();
}
function urlToDataUrl(url) {
  return fetch(url).then((r) => r.blob()).then((blob) => new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result || ''));
    fr.onerror = () => reject(fr.error || new Error('读取素材失败'));
    fr.readAsDataURL(blob);
  }));
}
async function saveCandidateToLibrary(idx) {
  const cand = state.candidates && state.candidates[idx];
  if (!cand) return;
  try {
    const api = await initLibrary();
    const name = 'AI-' + (cand.label || '结果').replace(/[\\/:*?"<>|]/g, '-') + '-' + Date.now().toString(36) + '.png';
    const res = await api.importDataUrls([{ name, dataUrl: cand.imageDataUrl, mime: 'image/png' }], { context: { source: 'ai-generated', model: (state.aiLastCall && (state.aiLastCall.modelVersion || state.aiLastCall.model)) || aiRuntimeModel(), prompt: state.aiImagePrompt || state.selectedDirection && state.selectedDirection.title || '' } });
    if (res.duplicates && res.duplicates.length) { showToast('素材库已有同一张（sha 去重），无需重复保存'); return; }
    const asset = res.imported && res.imported[0];
    if (!asset) throw new Error((res.errors && res.errors[0] && res.errors[0].error) || '导入失败');
    const meta = state.aiLastCall || {};
    asset.tags = [...new Set(['AI生成', ...(asset.tags || [])])].slice(0, 32);
    asset.provenance = {
      source: 'ai-generated', provider: meta.provider || aiPreset().provider, model: meta.modelVersion || meta.model || aiRuntimeModel(),
      prompt: state.aiImagePrompt || (state.selectedDirection && state.selectedDirection.title) || '', refs: (state.aiWorkshopRefs || []).map((r) => ({ asset_id: r.id, fileName: r.fileName, sha256: r.sha256 })),
      candidate_sha256: cand.sha256 || null, generated_at: iso(),
    };
    asset.updatedAt = iso();
    try { await api.store.put(asset); } catch (e) { /* 保留已导入的资产 */ }
    await refreshLibraryAssets();
    if (state.library.open) renderLibrary();
    addRecord(baseRecord('L6', { kind: 'export', anchor: { type: 'whole', value: null }, model: { provider: meta.provider || 'mock', model: meta.modelVersion || meta.model || MOCK_MODEL }, params: { action: 'save_to_library', asset_id: asset.id, sha256: asset.sha256, source: 'ai-generated', prompt: (state.aiImagePrompt || '').slice(0, 200) }, input_refs: [], assertions: [{ type: 'user_operation', value: true }], ai_role: 'assistant', source: 'observed', author: 'user', note: 'AI 结果存回素材库' }));
    showToast('已存回素材库「' + name + '」：可搜索/插入/继续当参考');
  } catch (e) { console.error(e); showToast('存回素材库失败：' + (e.message || e), true); }
}
async function runImageWorkshop(mode) {
  if (state.mode === 'attest') { showToast('存证模式已禁用 AI', true); return null; }
  if (state.aiBusy) { showToast('AI 正在处理上一个请求，请稍候', true); return null; }
  const prompt = ((document.getElementById('aiImagePrompt') || {}).value || state.aiImagePrompt || '').trim();
  if (!prompt) { showToast('先写一句你想生成/修改成什么', true); return null; }
  const real = aiRealEligible();
  if (real && !(await confirmAiSend())) return null;
  const ac = new AbortController(); state.aiAbort = ac;
  aiBeginTask(mode === 'edit' ? '准备图像编辑…（可能需要 30–120s）' : '准备生成图片…');
  try {
    const crop = state.aiImageScope === 'layer' ? await aiLayerCrop() : await aiWorkshopCropAsync();
    // 服务端口径：编辑输入总数 ≤3 张（选区裁切算 1 张）→ 参考最多 2 张；超出时明确提示，不静默截断
    const allRefs = state.aiWorkshopRefs || [];
    const refsWanted = mode === 'edit' ? allRefs.slice(0, 2) : allRefs;
    const refImages = [];
    const refNames = [];
    for (const ref of refsWanted) {
      try {
        const a = (state.library.assets || []).find((x) => x.id === ref.id);
        if (!a) continue;
        const resolved = await getAssetImageUrl(a);
        if (resolved && resolved.url) { refImages.push(await urlToDataUrl(resolved.url)); refNames.push(a.fileName || ref.fileName || ''); }
        try { resolved && resolved.cleanup && resolved.cleanup(); } catch (e) { /* ignore */ }
      } catch (e) { console.warn('[workshop] ref load failed', e); }
    }
    if (mode === 'edit' && allRefs.length > 2) showToast('编辑最多 3 张输入（含选区）：本次只带前 2 张参考，其余未发送', true);
    const provider = aiGetProvider({ signal: ac.signal });
    aiPhase(mode === 'edit' ? 'Qwen 图像编辑中…（30–120s，输入 ' + (1 + refImages.length) + ' 张）' : '生成图片中…（10–30s，输入 ' + refImages.length + ' 张参考）');
    const fullPrompt = prompt + (refNames.length ? ('\n参考素材：' + refNames.join('、') + '，请借鉴其风格/元素，但以当前画布为准。') : '');
    const editImages = [crop.dataUrl, ...refImages].slice(0, 3);
    const input = { prompt: fullPrompt, directionId: mode === 'edit' ? 'workshop-edit' : 'workshop-gen', count: mode === 'edit' ? 1 : 2, size: '1024x1024', image: mode === 'edit' || state.aiImageScope === 'selection' ? crop.dataUrl : null, images: mode === 'edit' ? editImages : refImages, selection: state.selection || null, context: { mode: state.mode, aiRole: 'assistant', live: liveContext(), scope: state.aiImageScope, prompt: fullPrompt, refs: refsWanted.map((r) => ({ asset_id: r.id, fileName: r.fileName, sha256: r.sha256 })), sent_image_count: mode === 'edit' ? editImages.length : refImages.length } };
    const runtime = await getSkillRuntime();
    const skillId = mode === 'edit' ? 'image.edit' : 'image.generate';
    const run = await runtime.run(skillId, input, { provider });
    const res = run.result;
    state.aiLastCall = { ...aiCallMeta(res, mode === 'edit' ? 'edit' : 'generate'), skill: run.skill.id, skill_version: run.skill.version };
    aiEndTask();
    state.candidates = res.candidates || [];
    state.selectedDirection = { id: mode === 'edit' ? 'workshop-edit' : 'workshop-gen', title: prompt, why: prompt, tags: [mode === 'edit' ? 'edit' : 'generate'] };
    state.generatedCandidateId = null;
    recordAiCall(mode === 'edit' ? 'edit' : 'generate', 'ok', state.aiLastCall, { workspace: 'image', prompt: prompt.slice(0, 200), scope: state.aiImageScope, skill: run.skill.id, skill_version: run.skill.version, refs: refsWanted.map((r) => ({ asset_id: r.id, fileName: r.fileName, sha256: r.sha256 })), sent_image_count: mode === 'edit' ? editImages.length : refImages.length, candidate_ids: (res.candidates || []).map((c) => c.id), local_patch: true });
    aiLog(mode === 'edit' ? 'edit' : 'generate', (mode === 'edit' ? '图像编辑 ' : '生成图片 ') + (res.candidates || []).length + ' 张 · ' + (state.aiLastCall.latencyMs || 0) + 'ms · ' + run.skill.id, state.aiLastCall);
    renderAiImageTab(); renderAiProviderBadge();
    showToast(mode === 'edit' ? '编辑结果已返回：可先在画布预览，再落为新图层继续改' : '图片已生成：先在画布预览，再落为新图层');
    return res;
  } catch (e) {
    console.error(e);
    aiEndTask();
    if (e && (e.code === 'cancelled' || e.name === 'AbortError')) { aiPhase('已取消'); return null; }
    state.aiLastCall = { provider: aiRealEligible() ? aiPreset().provider : 'mock', model: aiRuntimeModel(), mock: !aiRealEligible(), task: mode === 'edit' ? 'edit' : 'generate', status: 'error', errorCode: e.code || 'ai_error', latencyMs: 0, at: iso() };
    recordAiCall(mode === 'edit' ? 'edit' : 'generate', 'error', state.aiLastCall, { error_code: e.code || 'ai_error', error_message: (e.userMessage || e.message || String(e)).slice(0, 200), retryable: !!e.retryable });
    aiLog('error', (mode === 'edit' ? '图像编辑失败 · ' : '生成失败 · ') + (e.code || 'ai_error'), state.aiLastCall);
    showToast((mode === 'edit' ? '图像编辑失败：' : '图片生成失败：') + (e.userMessage || e.message || e), true);
    return null;
  }
}
function openAiSettingsPanel() {
  closePopovers();
  openModal('aboutModal');
  setTimeout(() => {
    const card = document.getElementById('aiAccessCard');
    if (card) card.scrollIntoView({ block: 'center', behavior: 'smooth' });
    const sel = document.getElementById('aiProviderSelect');
    if (sel) sel.focus({ preventScroll: true });
  }, 120);
}
function renderAiModelTab() {
  const host = document.getElementById('aiModelBody');
  if (!host) return;
  const cfg = aiRuntime.config || {};
  const pid = cfg.provider || aiPreset().provider;
  const prov = (cfg.providers && cfg.providers[pid]) || {};
  const p = aiPreset();
  const real = aiRealEligible();
  const last = state.aiLastCall;
  const keyText = aiRuntime.hasKey ? ('已配置 · 末四位 ' + (prov.keyLast4 || '****')) : '未配置（Mock 可用）';
  const statusText = real ? '真实调用已启用' : (aiRuntime.hasKey ? '已配置，真实调用未启用（或隐私模式）' : 'Mock 模式');
  const l6 = (state.records || []).filter((r) => r.layer === 'L6');
  const aiCalls = l6.filter((r) => ['critique', 'generation'].includes(r.kind));
  const totalTokens = aiCalls.reduce((n, r) => n + ((r.usage && r.usage.total_tokens) || 0), 0);
  const totalLatency = aiCalls.reduce((n, r) => n + (Number(r.latency_ms) || 0), 0);
  const realCalls = aiCalls.filter((r) => r.params && r.params.mock === false).length;
  const skills = (() => { try { return skillRuntime ? skillRuntime.list() : [{ id: 'asset.decompose', title: '素材理解拆解' }, { id: 'canvas.observe', title: '画布观察' }, { id: 'canvas.directions', title: '画布方向建议' }, { id: 'image.generate', title: '图像生成' }, { id: 'image.edit', title: '图像编辑' }]; } catch (e) { return []; } })();
  const cap = (ok, label) => '<div class="ai-cap' + (ok ? ' on' : '') + '"><b>' + (ok ? '✓' : '—') + '</b><span>' + label + '</span></div>';
  const lastText = last ? (aiProviderLabel(last) + ' / ' + (last.modelVersion || last.model || aiRuntimeModel()) + ' · ' + (last.mock ? 'Mock' : '真实') + ' · ' + (last.latencyMs || 0) + 'ms') : '还没有调用记录';
  host.innerHTML =
    '<div class="ai-ctx">' +
      '<div class="ai-ctx-title">模型控制台 <span class="ai-provider-pill" id="aiModelPill">' + escapeHtml(aiProviderLabel()) + '</span></div>' +
      '<div class="ai-ctx-row"><span>Provider</span><b>' + escapeHtml(pid) + '</b></div>' +
      '<div class="ai-ctx-row"><span>Model</span><b>' + escapeHtml(aiRuntimeModel()) + '</b></div>' +
      '<div class="ai-ctx-row"><span>Key</span><b>' + escapeHtml(keyText) + '</b></div>' +
      '<div class="ai-ctx-row"><span>状态</span><b>' + escapeHtml(statusText) + '</b></div>' +
    '</div>' +
    '<div class="ai-cap-grid">' + cap(p.vision !== false, '视觉理解') + cap(!!p.imageGen, '图像生成') + cap(!!p.imageEdit, '图像编辑') + cap(true, '自由对话') + '</div>' +
    '<div class="ai-section-title">技能（平台 Skill）</div><div class="ai-skill-list">' + skills.map((s) => '<span class="ai-skill-chip" title="' + escapeHtml(s.description || '') + '">' + escapeHtml(s.id) + '</span>').join('') + '</div>' +
    '<div class="ai-section-title">用量</div><div class="ai-usage-grid"><div><b>' + aiCalls.length + '</b><span>调用</span></div><div><b>' + realCalls + '</b><span>真实</span></div><div><b>' + totalTokens + '</b><span>tokens</span></div><div><b>' + Math.round(totalLatency / Math.max(1, aiCalls.length)) + '</b><span>平均 ms</span></div></div>' +
    '<div class="ai-ctx-row" style="margin-top:6px"><span>上次</span><b>' + escapeHtml(lastText) + '</b></div>' +
    '<div class="ai-set-toggles" style="margin-top:8px">' +
      '<label><input type="checkbox" id="aiModelAllowReal"' + (aiRuntime.allowReal ? ' checked' : '') + '> 允许真实调用</label>' +
      '<label><input type="checkbox" id="aiModelRequireConfirm"' + (aiRuntime.requireConfirm ? ' checked' : '') + '> 每次手动确认</label>' +
      '<label><input type="checkbox" id="aiModelPrivacy"' + (aiRuntime.privacyMode ? ' checked' : '') + '> 隐私模式（强制 Mock）</label>' +
    '</div>' +
    '<div class="ai-entry" style="margin-top:8px">' +
      '<button class="btn primary" id="btnAiSettingsOpen">配置模型接入</button>' +
      '<button class="btn tiny" id="btnAiModelTest">测试连接</button>' +
      '<button class="btn tiny" id="btnAiModelRefresh">刷新状态</button>' +
    '</div>' +
    '<div class="hint">入口：这里 / 更多 →「AI 模型接入」/ 顶部 AI 面板。密钥只存本地代理；真实调用前会确认，失败不计费。</div>';
  const onChange = () => {
    aiRuntime.allowReal = !!(document.getElementById('aiModelAllowReal') || {}).checked;
    aiRuntime.requireConfirm = !!(document.getElementById('aiModelRequireConfirm') || {}).checked;
    aiRuntime.privacyMode = !!(document.getElementById('aiModelPrivacy') || {}).checked;
    saveAiLocalSettings(); renderAiSettings(); renderAiProviderBadge(); renderAiModelTab();
  };
  ['aiModelAllowReal', 'aiModelRequireConfirm', 'aiModelPrivacy'].forEach((id) => { const el = document.getElementById(id); if (el) el.addEventListener('change', onChange); });
  const so = document.getElementById('btnAiSettingsOpen'); if (so) so.addEventListener('click', openAiSettingsPanel);
  const tt = document.getElementById('btnAiModelTest'); if (tt) tt.addEventListener('click', async () => { setAiTestStatus('测试连接中…', ''); await testAiConnection(); renderAiModelTab(); });
  const rr = document.getElementById('btnAiModelRefresh'); if (rr) rr.addEventListener('click', async () => { await refreshAiConfig({ keepPreset: true }); renderAiModelTab(); });
}
async function renderAiEvidence() {
  const host = document.getElementById('aiEvidenceBody');
  if (!host) return;
  host.innerHTML = '<div class="hint">计算中…</div>';
  try {
    const pkg = await buildEvidence();
    const m = pkg.manifest;
    host.innerHTML = '<div class="ev-grid">' +
      '<div class="ev-item"><span>事件</span><b>' + m.event_count + '</b></div>' +
      '<div class="ev-item"><span>链头</span><b><code>' + shortHash(m.head_hash) + '</code></b></div>' +
      '<div class="ev-item"><span>画布 SHA-256</span><b><code>' + shortHash(pkg.project.canvas.sha256) + '</code></b></div>' +
      '<div class="ev-item"><span>zero_generation</span><b>' + m.attest.zero_generation + '</b></div>' +
      '<div class="ev-item"><span>模式</span><b>' + m.attest.mode + '</b></div>' +
      '<div class="ev-item"><span>网络请求</span><b>' + m.mock.network_requests + '</b></div></div>' +
      '<div class="hint" style="margin-top:8px">图层：' + m.layers.map((l) => l.name + ' · ' + l.tile_count + ' tiles').join('；') + '</div>';
  } catch (e) { host.innerHTML = '<div class="hint">证据摘要生成失败：' + escapeHtml(e.message || String(e)) + '</div>'; }
}
function renderArchiveCount() {
  const el = $('decisionCount');
  if (el) el.textContent = String(state.records.length);
  const ev = $('statusEvents');
  if (ev) ev.textContent = '事件 ' + state.records.length;
}
function renderArchive() {
  const body = $('archiveBody');
  if (!body) return;
  const layers = ['L0', 'L1', 'L2', 'L4', 'L5', 'L6'];
  const names = { L0: 'L0 · 画布来源', L1: 'L1 · 整体档案', L2: 'L2 · 区域', L4: 'L4 · 观察', L5: 'L5 · 决策', L6: 'L6 · AI 生成/模式' };
  let html = '';
  for (const layer of layers) {
    const list = state.records.filter((r) => r.layer === layer);
    if (!list.length) continue;
    html += '<div class="archive-group"><div class="archive-group-title">' + names[layer] + ' <span class="count">' + list.length + '</span></div>';
    for (const r of list) {
      let text = '';
      if (layer === 'L4') text = escapeHtml(r.text || '') + ' <span class="badge ' + r.source + '">' + r.source + '</span>';
      else if (layer === 'L5') text = r.kind + ' · ' + escapeHtml(r.note || '');
      else if (layer === 'L6') text = r.kind + ' · ' + escapeHtml((r.model && r.model.model) || '') + ' · ' + escapeHtml((r.params && r.params.candidate_id) || '');
      else if (layer === 'L1') text = escapeHtml(r.scene || '');
      else if (layer === 'L2') text = escapeHtml(r.label || '') + ' · 重要度 ' + r.importance;
      else text = escapeHtml(r.file_path || '');
      html += '<div class="archive-row"><span class="archive-id">' + escapeHtml(r.id) + '</span><span class="archive-text">' + text + '</span><span class="archive-time">' + new Date(r.created_at).toLocaleTimeString('zh-CN', { hour12: false }) + '</span></div>';
    }
    html += '</div>';
  }
  html += '<div class="archive-chain">哈希链：<code>' + escapeHtml(shortHash(state.headHash)) + '</code> · 事件 ' + state.records.length + '</div>';
  body.innerHTML = html || '<div class="hint">还没有档案记录——画几笔或让 AI 看看。</div>';
  const aiArchive = document.getElementById('aiArchiveBody');
  if (aiArchive) aiArchive.innerHTML = body.innerHTML;
}
async function updateHeadHash() {
  if (!state.records.length) { $('statusHash').textContent = '哈希准备中…'; return; }
  let prev = GENESIS_HASH;
  for (const r of state.records) prev = await sha256Hex(prev + canonicalJson(r));
  state.headHash = prev;
  const hashStr = String(prev).slice(0, 8);
  $('statusHash').textContent = hashStr;
  $('statusHash').title = prev;
  if ($('aboutHash')) $('aboutHash').textContent = 'SHA-256 · ' + shortHash(prev);
}
function scheduleHashUpdate() { clearTimeout(hashTimer); hashTimer = setTimeout(() => updateHeadHash().catch(() => {}), 250); }
async function buildEvidence(opts = {}) {
  let canvas;
  if (opts.canvasDataUrl) canvas = opts.canvasDataUrl;
  else if (opts.asyncPNG && typeof engine.exportPNGAsync === 'function') {
    const large = engine.width * engine.height > 2048 * 2048;
    const blob = await engine.exportPNGAsync({ tileSize: large ? 512 : 256, signal: opts.signal, onProgress: opts.onProgress });
    canvas = await blobToDataUrl(blob);
  } else {
    canvas = await getCanvasDataUrl();
  }
  const canvasDataUrlSha = await sha256Hex(canvas);
  // 像素/文件口径：对导出的 PNG 字节做 SHA-256（可与 Get-FileHash 对照）；dataURL 哈希保留给旧版 CLI verify
  let canvasPngSha = null, canvasPngBytes = 0;
  try { const bytes = roadshowDataUrlBytes(canvas); canvasPngBytes = bytes.byteLength; canvasPngSha = await sha256Hex(bytes); } catch (e) { canvasPngSha = null; }
  const layers = [];
  for (const l of engine.layers) {
    const meta = JSON.stringify({ id: l.id, name: l.name, blend: l.blend || 'normal', opacity: l.opacity == null ? 1 : l.opacity, count: engine.store.count(l.id), keys: engine.store.listTiles(l.id) });
    const tileCount = engine.store.count(l.id);
    let pngSha = null, pngBytes = null;
    if (tileCount > 0) {
      try {
        const url = await engine.getLayerDataUrl(l.id);
        const bytes = roadshowDataUrlBytes(url);
        pngBytes = bytes.byteLength;
        pngSha = await sha256Hex(bytes);
      } catch (e) { pngSha = null; pngBytes = null; } // 空图层/编码失败：保留 null 并标 empty
    }
    layers.push({ id: l.id, name: l.name, blend: l.blend || 'normal', opacity: l.opacity == null ? 1 : l.opacity, tile_count: tileCount, sha256: await sha256Hex(meta), png_sha256: pngSha, png_bytes: pngBytes, empty: tileCount === 0 });
  }
  // P0-2：演示/预置种子事件必须与正式证据哈希链物理隔离。
  // 旧版把 state.records 全量纳入链，其中 roadshowSeedRecords() 注入的 7 条「昨日」事件
  // 带伪模型/伪成本/伪用户来源，等于用产品自己演示了「链可被任意构造」。
  // 现在：formalRecords 参与链；预置/合成事件不参与链、不计入 event_count、不计入 AI 调用与成本统计。
  const allRecords = Array.isArray(state.records) ? state.records : [];
  const isDemoRecord = (r) => !!(r && (
    r.synthetic === true ||
    r.preset === true ||
    r.decision_source === 'roadshow_script' ||
    r.source === 'synthetic' ||
    (r.params && (r.params.preset_sample === true || r.params.synthetic === true || r.params.scripted === true))
  ));
  const formalRecords = allRecords.filter((r) => !isDemoRecord(r));
  const demoRecords = allRecords.filter(isDemoRecord);
  let prev = GENESIS_HASH;
  const events = [];
  for (const r of formalRecords) {
    const chain_hash = await sha256Hex(prev + canonicalJson(r));
    events.push({ ...r, chain_prev: prev, chain_hash });
    prev = chain_hash;
  }
  if (opts.onProgress) opts.onProgress({ phase: 'package', done: 1, total: 1 });
  // AI 证据：只从正式 L6 记录聚合 provider/model/usage；预置样本不得冒充真实调用。
  const aiRecords = formalRecords.filter((r) => r && r.layer === 'L6' && r.params && r.params.task);
  const byProvider = new Map();
  let realCalls = 0, mockCalls = 0, totalTokens = 0, totalLatency = 0;
  for (const r of aiRecords) {
    const p = (r.model && r.model.provider) || 'mock';
    const m = (r.model && (r.model.model || r.model.modelVersion)) || 'unknown';
    const key = p + '/' + m;
    byProvider.set(key, (byProvider.get(key) || 0) + 1);
    if (r.params.mock) mockCalls += 1; else realCalls += 1;
    if (r.params.usage && r.params.usage.total_tokens) totalTokens += r.params.usage.total_tokens;
    totalLatency += r.params.latency_ms || 0;
  }
  const aiProviders = [...byProvider.entries()].map(([key, count]) => { const i = key.indexOf('/'); return { provider: key.slice(0, i), model: key.slice(i + 1), calls: count }; });
  const aiManifest = { calls: aiRecords.length, real_calls: realCalls, mock_calls: mockCalls, providers: aiProviders, total_tokens: totalTokens, total_latency_ms: totalLatency, network_requests: realCalls };
  const refs = [];
  state.assetLayerRefs.forEach((v, layerId) => { const asset = (state.library.assets || []).find((x) => x.id === v.assetId); refs.push({ usage: 'insert', asset_id: v.assetId, fileName: v.fileName, sha256: v.sha256, layer_id: layerId, L1_id: asset && asset.L1 ? asset.L1.id : null, L2_ids: asset ? (asset.L2 || []).map((r) => r.id) : [] }); });
  if (state.aiReference) { const asset = (state.library.assets || []).find((x) => x.id === state.aiReference.id); refs.push({ usage: 'ai_reference', asset_id: state.aiReference.id, fileName: state.aiReference.fileName, sha256: state.aiReference.sha256, L1_id: asset && asset.L1 ? asset.L1.id : null, L2_ids: asset ? (asset.L2 || []).map((r) => r.id) : [] }); }
  return {
    schema: 'inkproof.evidence.v1', schema_version: SCHEMA_VERSION, generated_at: iso(),
    refs,
    app: '墨证 InkProof v2 · M4.2',
    project: {
      name: opts.projectName || '《雾中山谷 · v2》',
      canvas: {
        width: engine.width, height: engine.height, format: 'png',
        sha256: canvasDataUrlSha, dataurl_sha256: canvasDataUrlSha,
        png_sha256: canvasPngSha, png_bytes: canvasPngBytes,
        hash_subject: { sha256: 'canvas_dataurl_string(legacy)', png_sha256: 'canvas_png_bytes' },
      },
    },
    manifest: {
      event_count: events.length, head_hash: prev, genesis_hash: GENESIS_HASH, layers,
      // 演示种子只在包里留一个计数，不携带内容，避免伪事件被误读为真实过程。
      demo_events_excluded: demoRecords.length,
      demo_events_policy: '预置/合成演示事件与路演脚本代点的决策不参与正式事件哈希链，不计入 event_count / AI 调用 / 成本；本包不导出其内容。',
      hash_policy: {
        canvas_sha256: 'dataURL string SHA-256（旧版 / CLI verify 口径，保持兼容）',
        canvas_png_sha256: '导出 PNG 文件字节 SHA-256（下载后用 Get-FileHash 可对照）',
        layer_sha256: '图层元数据 JSON SHA-256（旧版）',
        layer_png_sha256: '图层 PNG 字节 SHA-256（tile_count=0 的空图层为 null）',
        chain_scope: 'SHA-256 链只覆盖 events[] 且只含真实事件；manifest / refs / canvas_png_data_url 与演示事件均不在链上。无签名、无第三方时间戳，只能检测顺序错乱与无意损坏，不能抵御蓄意改写，不是法律鉴定。',
      },
      tools: { renderer: 'CanvasKit/Skia (BSD-3) + v2 engine tile', brushes: 'v2 10 brushes' },
      ai: aiManifest,
      mock: { calls: mockCalls, network_requests: realCalls },
      attest: { mode: state.mode, zero_generation: state.mode === 'attest' },
      refs_count: refs.length,
    },
    refs, events, canvas_png_data_url: canvas,
  };
}
async function openEvidence(pkgOrOpts) {
  const body = $('evidenceBody');
  const provided = (pkgOrOpts && typeof pkgOrOpts === 'object' && pkgOrOpts.manifest && pkgOrOpts.schema === 'inkproof.evidence.v1') ? pkgOrOpts : null;
  body.innerHTML = '<div class="hint">' + (provided ? '渲染证据包…' : '分块渲染画布 / 计算哈希链…') + '</div>';
  openModal('evidenceModal');
  const ac = new AbortController();
  if (!provided) showAsyncTask('生成证据包', () => { try { ac.abort(); } catch (e) {} try { engine.cancelExport(); } catch (e) {} });
  try {
    const pkg = provided || await buildEvidence({ asyncPNG: typeof engine.exportPNGAsync === 'function', signal: ac.signal, onProgress: updateAsyncTask });
    state.evidence = pkg;
    const m = pkg.manifest;
    const modeTag = document.getElementById('evidenceModeTag');
    if (modeTag) {
      const ai = m.ai || {};
      if (Number(ai.real_calls || 0) > 0) { modeTag.textContent = '真实调用 ' + ai.real_calls + ' 次'; modeTag.className = 'mock-tag live'; }
      else if (Number(ai.mock_calls || 0) > 0) { modeTag.textContent = 'Mock · 未调用模型'; modeTag.className = 'mock-tag'; }
      else { modeTag.textContent = '本地 · 无 AI 调用'; modeTag.className = 'mock-tag'; }
    }
    body.innerHTML = '<div class="ev-grid">' +
      '<div class="ev-item"><span>事件</span><b>' + m.event_count + '</b></div>' +
      '<div class="ev-item"><span>链头哈希</span><b><code>' + shortHash(m.head_hash) + '</code></b></div>' +
      '<div class="ev-item"><span>画布 PNG 字节 SHA-256</span><b><code>' + shortHash(pkg.project.canvas.png_sha256 || '') + '</code></b></div>' +
      '<div class="ev-item"><span>画布 dataURL SHA-256（旧口径）</span><b><code>' + shortHash(pkg.project.canvas.sha256) + '</code></b></div>' +
      '<div class="ev-item"><span>zero_generation</span><b>' + m.attest.zero_generation + '</b></div>' +
      '<div class="ev-item"><span>模式</span><b>' + m.attest.mode + '</b></div>' +
      '<div class="ev-item"><span>网络请求</span><b>' + (m.ai ? m.ai.network_requests : 0) + '</b></div></div>' +
      '<div class="ev-section-title">AI 调用</div><div class="ev-layers">' +
      (m.ai && m.ai.calls ? ('<div class="ev-layer"><span>真实 ' + m.ai.real_calls + ' · Mock ' + m.ai.mock_calls + '</span><span>' + (m.ai.providers || []).map((p) => escapeHtml(p.provider + '/' + p.model) + ' ×' + p.calls).join(' · ') + '</span><span>' + (m.ai.total_tokens || 0) + ' tokens</span></div>') : '<div class="ev-layer"><span>无 AI 调用记录</span></div>') +
      '</div>' +
      '<div class="ev-section-title">图层</div><div class="ev-layers">' + m.layers.map((l) => '<div class="ev-layer"><span>' + escapeHtml(l.name) + '</span><code>png ' + shortHash(l.png_sha256 || '') + '</code><span>' + l.tile_count + ' tiles</span></div>').join('') + '</div>' +
      '<div class="ev-section-title">事件清单（' + m.event_count + '）</div><div class="ev-events">' + pkg.events.slice(-12).map((e) => '<div class="ev-event"><span class="archive-id">' + escapeHtml(e.id) + '</span><span>' + escapeHtml(e.layer) + ' · ' + escapeHtml(e.kind || '') + '</span><code>' + shortHash(e.chain_hash) + '</code></div>').join('') + '</div>' +
      '<div class="hint">证据包含画布 PNG（base64）、事件哈希链与 AI 调用清单；画布 PNG 字节哈希（png_sha256）可与下载的 PNG 用 Get-FileHash 对照；dataURL 哈希保留给旧版 CLI verify。</div>';
  } catch (e) {
    body.innerHTML = '<div class="hint">' + (e && e.name === 'AbortError' ? '已取消生成证据包' : '证据包生成失败：' + escapeHtml(e.message || String(e))) + '</div>';
  } finally { hideAsyncTask(); }
}
function downloadBlob(filename, blob) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1500);
}
function downloadJson() {
  if (!state.evidence) return;
  downloadBlob('inkproof-evidence.json', new Blob([JSON.stringify(state.evidence, null, 2)], { type: 'application/json' }));
}
async function downloadPng() {
  if (typeof engine.exportPNGAsync !== 'function') {
    const url = await getCanvasDataUrl();
    const a = document.createElement('a'); a.href = url; a.download = 'inkproof-canvas.png'; a.click();
    showToast('已导出 PNG（兼容模式：同步编码）');
    return;
  }
  const ac = new AbortController();
  const large = engine.width * engine.height > 2048 * 2048;
  showAsyncTask('导出 PNG' + (large ? '（4096² 分块）' : ''), () => { try { ac.abort(); } catch (e) {} try { engine.cancelExport(); } catch (e) {} });
  try {
    const blob = await engine.exportPNGAsync({ tileSize: large ? 512 : 256, signal: ac.signal, onProgress: updateAsyncTask });
    downloadBlob('inkproof-canvas.png', blob);
    showToast('PNG 已导出 · ' + Math.round(blob.size / 1024) + ' KB');
  } catch (e) {
    if (e && e.name === 'AbortError') showToast('已取消 PNG 导出');
    else {
      try { const url = await getCanvasDataUrl(); const a = document.createElement('a'); a.href = url; a.download = 'inkproof-canvas.png'; a.click(); showToast('Worker 不可用，已降级为同步导出'); }
      catch (e2) { showToast('导出失败：' + (e2.message || e2), true); }
    }
  } finally { hideAsyncTask(); }
}
async function exportBoth() {
  const ac = new AbortController();
  showAsyncTask('导出证据包', () => { try { ac.abort(); } catch (e) {} try { engine.cancelExport(); } catch (e) {} });
  try {
    if (!state.evidence) state.evidence = await buildEvidence({ asyncPNG: typeof engine.exportPNGAsync === 'function', signal: ac.signal, onProgress: updateAsyncTask });
    downloadJson();
    await downloadPng();
    if (!state.records.some((r) => r.layer === 'L6' && r.kind === 'export')) {
      addRecord(baseRecord('L6', {
        kind: 'export', anchor: { type: 'whole', value: null },
        model: { provider: 'mock', model: MOCK_MODEL }, params: {}, input_refs: [], assertions: [{ type: 'mock_only', value: true }],
        ai_role: 'assistant', source: 'observed', author: 'user', note: '导出证据包（JSON + PNG）',
      }));
    }
    showToast('证据包已导出（JSON + PNG）');
    closeModal('evidenceModal');
  } catch (e) { if (!(e && e.name === 'AbortError')) showToast('导出失败：' + (e.message || e), true); else showToast('已取消导出'); }
  finally { hideAsyncTask(); }
}

/* ---------------- 模式 / 弹窗 ---------------- */
function setMode(mode, opts = {}) {
  const next = mode === 'attest' ? 'attest' : 'collab';
  if (next === state.mode && !opts.force) return;
  const from = state.mode;
  state.mode = next;
  applyAttestUI(next === 'attest');
  if (!opts.silent && !state.demo.active) {
    addRecord(baseRecord('L6', {
      kind: 'mode_change', anchor: { type: 'whole', value: null },
      from_mode: from, to_mode: next, actor: 'user',
      model: { provider: 'mock', model: MOCK_MODEL }, params: {}, input_refs: [],
      assertions: [{ type: 'zero_generation', value: next === 'attest' }],
      ai_role: 'assistant', source: 'observed', author: 'user',
      note: next === 'attest' ? '进入存证模式：AI 禁用' : '回到协作模式',
    }));
  }
  scheduleSave();
  renderAll();
}
function applyAttestUI(on) {
  document.body.classList.toggle('attest', on);
  document.querySelectorAll('#modeSwitch .mode-opt').forEach((b) => { const on = b.dataset.mode === state.mode; b.classList.toggle('active', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
  const sm = $('statusModeText'); if (sm) sm.textContent = on ? '存证模式 · AI 禁用' : '协作模式 · AI 可参与';
  const am = $('aboutMode'); if (am) am.textContent = on ? '存证（AI 禁用）' : '协作';
  if ($('btnAskAi')) $('btnAskAi').disabled = on;
  if (on && $('aiBody')) $('aiBody').innerHTML = '<div class="ai-empty"><div class="ai-empty-title">存证模式已开启</div><div class="hint">AI 已被禁用，画布/档案/证据链照常记录；导出的证据包会标记 <code>zero_generation: true</code>。</div></div>';
}
function toggleFullscreen() {
  try {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen();
    else document.exitFullscreen();
  } catch (e) { showToast('当前环境不支持全屏', true); }
}
function openPopupEvidence() {
  openPopover('popAI');
  switchAiTab('evidence');
}
function openModal(id) { const el = $(id); if (el) el.classList.add('show'); }
function closeModal(id) { const el = $(id); if (el) el.classList.remove('show'); }
function bindModals() {
  document.querySelectorAll('[data-close]').forEach((btn) => btn.addEventListener('click', () => closeModal(btn.dataset.close)));
  document.querySelectorAll('.modal-mask').forEach((mask) => {
    mask.addEventListener('click', (e) => { if (e.target === mask) closeModal(mask.id); });
  });
}
let toastTimer = null;

function showToast(msg, isErr) {
  const wrap = $('toastWrap');
  wrap.innerHTML = `<div class="toast ${isErr ? 'error' : ''}" style="pointer-events:auto">${escapeHtml(msg)}</div>`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { wrap.innerHTML = ''; }, 2600);
}
function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* ---------------- T78 异步任务 / 导出进度 ---------------- */
const ASYNC_TASK = { active: false, kind: null, cancel: null, pct: 0, mode: "" };
function showAsyncTask(label, cancelFn, opts = {}) {
  ASYNC_TASK.active = true; ASYNC_TASK.kind = label; ASYNC_TASK.mode = opts.mode || ""; ASYNC_TASK.cancel = cancelFn || null; ASYNC_TASK.pct = 0;
  const bar = document.getElementById('asyncTask'); if (!bar) return;
  bar.hidden = false;
  document.getElementById('asyncTaskLabel').textContent = label;
  document.getElementById('asyncTaskBar').style.width = '0%';
  document.getElementById('asyncTaskPct').textContent = '0%';
  const btn = document.getElementById('asyncTaskCancel'); if (btn) { btn.disabled = !cancelFn; btn.textContent = cancelFn ? '取消' : '处理中'; }
}
function updateAsyncTask(p) {
  if (!ASYNC_TASK.active || !p) return;
  const label = document.getElementById('asyncTaskLabel'); const bar = document.getElementById('asyncTaskBar'); const pct = document.getElementById('asyncTaskPct');
  const phase = p.phase || '';
  const total = Math.max(1, p.total || 1);
  const progress = phase === 'done' ? 100 : Math.min(100, Math.round(((p.done || 0) / total) * 100));
  ASYNC_TASK.pct = progress;
  if (bar) bar.style.width = progress + '%';
  if (pct) pct.textContent = progress + '%';
  if (label) {
    if (phase === 'fallback') label.textContent = '兼容模式：同步处理中…';
    else if (phase === 'encode' && ASYNC_TASK.mode === 'save') { label.textContent = 'Worker 编码 tile ' + (p.done || 0) + ' 个'; if (pct) pct.textContent = Math.min(95, 8 + (p.done || 0) * 4) + '%'; if (bar) bar.style.width = Math.min(95, 8 + (p.done || 0) * 4) + '%'; }
    else if (phase === 'encode' && ASYNC_TASK.mode === 'psd') label.textContent = 'PSD 打包中…';
    else if (phase === 'render') { label.textContent = '逐层读取 ' + (p.done || 0) + ' / ' + total; }
    else if (phase === 'done') { label.textContent = ASYNC_TASK.kind + ' · 完成'; }
    else if (phase === 'read') label.textContent = '分块渲染 ' + (p.done || 0) + ' / ' + total;
    else if (phase === 'encode') label.textContent = '编码 PNG ' + (p.done || 0) + ' / ' + total;
    else if (phase === 'package') label.textContent = '打包 ' + (p.done || 0) + ' / ' + total;
    else if (phase === 'done') label.textContent = ASYNC_TASK.kind + ' · 完成';
    else label.textContent = ASYNC_TASK.kind;
  }
}
function hideAsyncTask() {
  ASYNC_TASK.active = false; ASYNC_TASK.kind = null; ASYNC_TASK.cancel = null; ASYNC_TASK.mode = ''; ASYNC_TASK.mode = '';
  const bar = document.getElementById('asyncTask'); if (bar) bar.hidden = true;
}
function bindAsyncTaskControls() {
  const btn = document.getElementById('asyncTaskCancel');
  if (btn) btn.onclick = () => { try { ASYNC_TASK.cancel && ASYNC_TASK.cancel(); } catch (e) { /* ignore */ } };
}
function blobToDataUrl(blob) {
  return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = () => rej(r.error || new Error('read blob failed')); r.readAsDataURL(blob); });
}
function rafYield() { return new Promise((r) => requestAnimationFrame(r)); }
function abortError() { const e = new Error('已取消'); e.name = 'AbortError'; return e; }

/* ---------------- T71 素材库（Sheet + mock 反解 + 画布双向） ---------------- */
const LIB_SHEET = () => document.getElementById('librarySheet');
function libApi() { return state.library.api; }
let skillRuntime = null;
async function getSkillRuntime() {
  if (skillRuntime) return skillRuntime;
  const [{ SkillRuntime }, { BUILTIN_SKILLS }] = await Promise.all([
    import('../core/skills/runtime.mjs'),
    import('../core/skills/builtin.mjs'),
  ]);
  skillRuntime = new SkillRuntime({ logger: (kind, entry) => { try { if (kind === 'skill_ok') aiLog('skill', '技能 ' + entry.skill + ' 完成 · ' + entry.latencyMs + 'ms'); } catch (e) { /* ignore */ } } });
  for (const s of BUILTIN_SKILLS) skillRuntime.register(s);
  return skillRuntime;
}
async function initLibrary() {
  if (state.library.api) return state.library.api;
  const mod = await import('../../library/api.mjs');
  state.library.api = await mod.createLibrary();
  return state.library.api;
}
function libEsc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function sampleCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function sampleArtA() {
  const c = sampleCanvas(1600, 1200); const g = c.getContext('2d');
  const sky = g.createLinearGradient(0, 0, 0, 820);
  sky.addColorStop(0, '#6f8a9e'); sky.addColorStop(0.32, '#93aab8'); sky.addColorStop(0.62, '#c3d2d9'); sky.addColorStop(1, '#e4ebee');
  g.fillStyle = sky; g.fillRect(0, 0, 1600, 1200);
  const glow = g.createRadialGradient(1260, 240, 8, 1260, 240, 360);
  glow.addColorStop(0, 'rgba(255,250,226,.9)'); glow.addColorStop(0.35, 'rgba(255,246,214,.38)'); glow.addColorStop(1, 'rgba(255,246,214,0)');
  g.fillStyle = glow; g.fillRect(840, 0, 760, 640);
  // 最深远山
  g.fillStyle = '#5f7789';
  g.beginPath(); g.moveTo(0, 520); g.lineTo(170, 250); g.lineTo(330, 460); g.lineTo(520, 210); g.lineTo(760, 500); g.lineTo(980, 300); g.lineTo(1210, 520); g.lineTo(1400, 350); g.lineTo(1600, 540); g.lineTo(1600, 720); g.lineTo(0, 720); g.closePath(); g.fill();
  // 远雾带
  g.fillStyle = 'rgba(210,223,229,.55)'; g.beginPath(); g.ellipse(560, 560, 560, 72, 0, 0, Math.PI * 2); g.fill();
  // 次远山
  g.fillStyle = '#768e9f';
  g.beginPath(); g.moveTo(0, 640); g.lineTo(230, 470); g.lineTo(470, 640); g.lineTo(700, 430); g.lineTo(960, 640); g.lineTo(1240, 470); g.lineTo(1600, 660); g.lineTo(1600, 780); g.lineTo(0, 780); g.closePath(); g.fill();
  // 中雾带（主视觉）
  g.fillStyle = 'rgba(226,236,240,.82)'; g.beginPath(); g.ellipse(640, 700, 620, 82, 0, 0, Math.PI * 2); g.fill();
  g.fillStyle = 'rgba(238,244,246,.7)'; g.beginPath(); g.ellipse(1260, 745, 430, 56, 0, 0, Math.PI * 2); g.fill();
  // 近山剪影
  g.fillStyle = '#4f6778';
  g.beginPath(); g.moveTo(0, 790); g.lineTo(220, 650); g.lineTo(380, 780); g.lineTo(560, 690); g.lineTo(760, 800); g.lineTo(980, 700); g.lineTo(1180, 810); g.lineTo(1420, 690); g.lineTo(1600, 800); g.lineTo(1600, 900); g.lineTo(0, 900); g.closePath(); g.fill();
  // 水面
  const water = g.createLinearGradient(0, 820, 0, 1200);
  water.addColorStop(0, '#9fb5c1'); water.addColorStop(0.5, '#c3d2d9'); water.addColorStop(1, '#dfe8ea');
  g.fillStyle = water; g.fillRect(0, 820, 1600, 380);
  for (let i = 0; i < 52; i += 1) {
    const y = 830 + i * 7; const w = 120 + (i * 83) % 420;
    g.fillStyle = 'rgba(255,255,255,' + (0.05 + (i % 4) * 0.02) + ')';
    g.fillRect(120 + (i * 97) % 1180, y, w, 2);
  }
  // 倒影
  for (let i = 0; i < 22; i += 1) { g.fillStyle = 'rgba(120,145,160,' + (0.05 + (i % 3) * 0.015) + ')'; g.fillRect(300 + (i * 61) % 1000, 840 + i * 12, 90 + (i % 4) * 55, 3); }
  // 暗角 + 轻颗粒
  const vg = g.createRadialGradient(800, 560, 320, 800, 560, 980);
  vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(28,38,48,.28)');
  g.fillStyle = vg; g.fillRect(0, 0, 1600, 1200);
  for (let i = 0; i < 9000; i += 1) { const x = (i * 73) % 1600, y = (i * 131) % 1200; g.fillStyle = 'rgba(255,255,255,' + (0.012 + ((i * 7) % 20) / 1600) + ')'; g.fillRect(x, y, 1, 1); }
  return { name: '雾中山谷-示例.jpg', dataUrl: c.toDataURL('image/jpeg', 0.9), mime: 'image/jpeg' };
}
function sampleArtB() {
  const c = sampleCanvas(1200, 1600); const g = c.getContext('2d');
  g.fillStyle = '#fbfaf7'; g.fillRect(0, 0, 1200, 1600);
  g.strokeStyle = '#5e5952'; g.lineWidth = 2.4; g.lineCap = 'round'; g.lineJoin = 'round';
  // 头部与头发
  g.beginPath(); g.ellipse(710, 350, 122, 150, -0.06, 0, Math.PI * 2); g.stroke();
  g.beginPath(); g.moveTo(596, 330); g.quadraticCurveTo(600, 190, 720, 188); g.quadraticCurveTo(840, 190, 846, 330); g.stroke();
  g.beginPath(); g.moveTo(606, 300); g.quadraticCurveTo(560, 430, 585, 540); g.stroke();
  g.beginPath(); g.moveTo(838, 300); g.quadraticCurveTo(880, 420, 856, 540); g.stroke();
  // 面部细节（轻线）
  g.lineWidth = 1.6;
  g.beginPath(); g.moveTo(660, 330); g.quadraticCurveTo(680, 340, 700, 332); g.stroke();
  g.beginPath(); g.moveTo(742, 332); g.quadraticCurveTo(762, 340, 782, 330); g.stroke();
  g.beginPath(); g.moveTo(720, 350); g.lineTo(714, 398); g.stroke();
  g.beginPath(); g.moveTo(690, 430); g.quadraticCurveTo(720, 444, 752, 430); g.stroke();
  // 颈/肩
  g.lineWidth = 2.4;
  g.beginPath(); g.moveTo(678, 492); g.lineTo(674, 548); g.stroke();
  g.beginPath(); g.moveTo(760, 492); g.lineTo(764, 548); g.stroke();
  g.beginPath(); g.moveTo(674, 548); g.quadraticCurveTo(560, 590, 510, 690); g.lineTo(488, 820); g.stroke();
  g.beginPath(); g.moveTo(764, 548); g.quadraticCurveTo(880, 590, 930, 690); g.lineTo(950, 820); g.stroke();
  // 躯干与手臂
  g.beginPath(); g.moveTo(520, 700); g.quadraticCurveTo(560, 960, 600, 1110); g.stroke();
  g.beginPath(); g.moveTo(920, 700); g.quadraticCurveTo(880, 960, 840, 1110); g.stroke();
  g.beginPath(); g.moveTo(548, 760); g.quadraticCurveTo(470, 880, 430, 1030); g.stroke();
  g.beginPath(); g.moveTo(892, 760); g.quadraticCurveTo(980, 870, 1010, 1010); g.stroke();
  // 手
  g.lineWidth = 1.8;
  g.beginPath(); g.ellipse(424, 1054, 34, 48, 0.25, 0, Math.PI * 2); g.stroke();
  g.beginPath(); g.ellipse(1016, 1032, 32, 46, -0.2, 0, Math.PI * 2); g.stroke();
  for (let i = 0; i < 4; i += 1) { g.beginPath(); g.moveTo(406 + i * 9, 1018 + i * 4); g.quadraticCurveTo(414 + i * 9, 1050, 416 + i * 9, 1072 + i * 3); g.stroke(); }
  // 腰部与腿
  g.lineWidth = 2.4;
  g.beginPath(); g.moveTo(600, 1110); g.quadraticCurveTo(720, 1160, 840, 1110); g.stroke();
  g.beginPath(); g.moveTo(620, 1150); g.quadraticCurveTo(600, 1320, 566, 1460); g.stroke();
  g.beginPath(); g.moveTo(818, 1150); g.quadraticCurveTo(848, 1320, 884, 1460); g.stroke();
  g.beginPath(); g.moveTo(566, 1460); g.quadraticCurveTo(600, 1490, 646, 1462); g.stroke();
  g.beginPath(); g.moveTo(884, 1460); g.quadraticCurveTo(920, 1490, 956, 1458); g.stroke();
  // 衣褶
  g.lineWidth = 1.5; g.strokeStyle = '#7d766e';
  for (let i = 0; i < 12; i += 1) { g.beginPath(); g.moveTo(560 + i * 24, 830 + (i % 3) * 26); g.quadraticCurveTo(590 + i * 24, 980 + (i % 4) * 20, 610 + i * 18, 1100); g.stroke(); }
  for (let i = 0; i < 9; i += 1) { g.beginPath(); g.moveTo(540 + i * 10, 610 + i * 14); g.lineTo(500 + i * 6, 700 + i * 16); g.stroke(); }
  // 排线阴影（肩/袖口密集）
  g.strokeStyle = 'rgba(94,89,82,.55)'; g.lineWidth = 1.1;
  for (let i = 0; i < 34; i += 1) { const x = 520 + i * 12, y = 590 + i * 7; g.beginPath(); g.moveTo(x, y); g.lineTo(x - 18, y + 42); g.stroke(); }
  for (let i = 0; i < 18; i += 1) { const x = 430 + (i % 6) * 14, y = 980 + Math.floor(i / 6) * 22; g.beginPath(); g.moveTo(x, y); g.lineTo(x + 26, y + 12); g.stroke(); }
  // 背景轻线/纸面暗示
  g.strokeStyle = 'rgba(150,144,136,.22)'; g.lineWidth = 1;
  g.beginPath(); g.moveTo(80, 1260); g.quadraticCurveTo(260, 1180, 440, 1260); g.stroke();
  g.beginPath(); g.moveTo(840, 220); g.quadraticCurveTo(980, 260, 1080, 200); g.stroke();
  return { name: '人物线稿-示例.png', dataUrl: c.toDataURL('image/png'), mime: 'image/png' };
}
function sampleArtC() {
  const c = sampleCanvas(1600, 1200); const g = c.getContext('2d');
  const base = g.createLinearGradient(0, 0, 1600, 1200);
  base.addColorStop(0, '#efe9dc'); base.addColorStop(0.5, '#e8e1d4'); base.addColorStop(1, '#ddd4c3');
  g.fillStyle = base; g.fillRect(0, 0, 1600, 1200);
  // 水彩沉淀/晕染
  for (let i = 0; i < 26; i += 1) {
    const x = 100 + (i * 173) % 1400, y = 80 + (i * 251) % 1040, r = 80 + (i * 37) % 180;
    const w = g.createRadialGradient(x, y, 4, x, y, r);
    w.addColorStop(0, 'rgba(190,174,148,' + (0.055 + (i % 4) * 0.012) + ')'); w.addColorStop(1, 'rgba(190,174,148,0)');
    g.fillStyle = w; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
  }
  // 细密颗粒
  for (let i = 0; i < 42000; i += 1) {
    const x = (i * 73) % 1600, y = (i * 149) % 1200;
    const a = 0.02 + ((i * 37) % 50) / 1500;
    g.fillStyle = (i % 7 === 0 ? 'rgba(255,255,255,' + a + ')' : 'rgba(122,108,88,' + a + ')');
    g.fillRect(x, y, 1.3, 1.3);
  }
  // 纤维
  for (let i = 0; i < 140; i += 1) {
    g.strokeStyle = 'rgba(160,148,126,' + (0.08 + (i % 5) * 0.02) + ')'; g.lineWidth = 0.8 + (i % 3) * 0.3;
    const x = (i * 131) % 1600, y = (i * 211) % 1200;
    g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + 60 + (i % 40), y + 24, x + 150 + (i % 70), y + 6); g.stroke();
  }
  // 亮斑（右上方）
  const glow = g.createRadialGradient(1250, 280, 20, 1250, 280, 420);
  glow.addColorStop(0, 'rgba(255,253,244,.6)'); glow.addColorStop(1, 'rgba(255,253,244,0)');
  g.fillStyle = glow; g.fillRect(760, 0, 900, 760);
  // 纸边
  g.strokeStyle = 'rgba(160,148,126,.28)'; g.lineWidth = 3;
  g.strokeRect(36, 36, 1528, 1128);
  g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 1; g.strokeRect(42, 42, 1516, 1116);
  return { name: '水彩纸-示例.png', dataUrl: c.toDataURL('image/png'), mime: 'image/png' };
}
async function ensureSampleLibrary() {
  const api = await initLibrary();
  let list = await api.list();
  if (!list.length) {
    const res = await api.importDataUrls([sampleArtB(), sampleArtC(), sampleArtA()]);
    for (const a of res.imported) { try { await curateSampleAsset(api, a); } catch (e) { console.warn('[library] curate sample failed', e); } }
    list = await api.list();
  }
  state.library.assets = list;
  return list;
}
async function curateSampleAsset(api, a) {
  const name = a.fileName || '';
  let tags = []; let l1 = {}; let l2 = []; let l4 = [];
  if (name.includes('雾中山谷')) {
    tags = ['雾', '山', '冷蓝', '低饱和', '安静', '示例'];
    l1 = { summary: '冷灰蓝的低饱和山谷，雾带把远山和近水分成三层。', subject: ['山', '雾'], mood: '安静', confidence: 0.62 };
    l2 = [
      { id: 'sample-a-l2-1', label: '远山', bbox: [120, 180, 1360, 300], importance: 0.72, confidence: 0.7, anchor: { type: 'bbox', value: [120, 180, 1360, 300] }, source: 'inferred' },
      { id: 'sample-a-l2-2', label: '雾带', bbox: [180, 430, 1240, 260], importance: 0.86, confidence: 0.74, anchor: { type: 'bbox', value: [180, 430, 1240, 260] }, source: 'inferred' },
      { id: 'sample-a-l2-3', label: '近水', bbox: [260, 760, 1080, 280], importance: 0.65, confidence: 0.61, anchor: { type: 'bbox', value: [260, 760, 1080, 280] }, source: 'inferred' },
    ];
    l4 = [
      { id: 'sample-a-l4-1', kind: 'observation', text: '画面主色是冷灰蓝，明度最高处在雾带。', confidence: 0.74, anchor: { type: 'bbox', value: [180, 430, 1240, 260] } },
      { id: 'sample-a-l4-2', kind: 'observation', text: '远山与近水的明度差集中在雾带，视线会先停在雾带缺口。', confidence: 0.61, anchor: { type: 'bbox', value: [180, 430, 1240, 260] } },
      { id: 'sample-a-l4-3', kind: 'observation', text: '笔触方向以水平铺陈为主，垂直细节较少。', confidence: 0.58, anchor: { type: 'bbox', value: [120, 180, 1360, 300] } },
    ];
  } else if (name.includes('人物线稿')) {
    tags = ['线稿', '人物', '肩线', '留白', '示例'];
    l1 = { summary: '白底细线人物线稿，主体偏右，肩线与袖口是细节密集区。', subject: ['人物', '肩线'], mood: '克制', confidence: 0.6 };
    l2 = [
      { id: 'sample-b-l2-1', label: '肩线', bbox: [520, 420, 420, 260], importance: 0.82, confidence: 0.71, anchor: { type: 'bbox', value: [520, 420, 420, 260] }, source: 'inferred' },
      { id: 'sample-b-l2-2', label: '袖口', bbox: [600, 700, 300, 180], importance: 0.66, confidence: 0.64, anchor: { type: 'bbox', value: [600, 700, 300, 180] }, source: 'inferred' },
      { id: 'sample-b-l2-3', label: '留白', bbox: [80, 80, 520, 980], importance: 0.58, confidence: 0.6, anchor: { type: 'bbox', value: [80, 80, 520, 980] }, source: 'inferred' },
    ];
    l4 = [
      { id: 'sample-b-l4-1', kind: 'observation', text: '线条宽度以 2–3px 细线为主，转折集中在肩部。', confidence: 0.71, anchor: { type: 'bbox', value: [520, 420, 420, 260] } },
      { id: 'sample-b-l4-2', kind: 'observation', text: '硬边直线与弧线形成对比，明暗几乎全部由线密度承担。', confidence: 0.63, anchor: { type: 'bbox', value: [520, 420, 420, 260] } },
      { id: 'sample-b-l4-3', kind: 'observation', text: '左上与右下留白较大，主体没有被裁切。', confidence: 0.69, anchor: { type: 'whole', value: null } },
    ];
  } else if (name.includes('水彩纸')) {
    tags = ['水彩纸', '颗粒', '米色', '纹理', '示例'];
    l1 = { summary: '浅灰米色水彩纸纹理，颗粒细密均匀，局部有轻微亮斑。', subject: ['纸张', '颗粒'], mood: '温和', confidence: 0.68 };
    l2 = [
      { id: 'sample-c-l2-1', label: '颗粒区', bbox: [180, 160, 1240, 900], importance: 0.78, confidence: 0.66, anchor: { type: 'bbox', value: [180, 160, 1240, 900] }, source: 'inferred' },
      { id: 'sample-c-l2-2', label: '亮斑区', bbox: [900, 180, 460, 420], importance: 0.55, confidence: 0.6, anchor: { type: 'bbox', value: [900, 180, 460, 420] }, source: 'inferred' },
      { id: 'sample-c-l2-3', label: '纸边', bbox: [0, 0, 1600, 140], importance: 0.42, confidence: 0.58, anchor: { type: 'bbox', value: [0, 0, 1600, 140] }, source: 'inferred' },
    ];
    l4 = [
      { id: 'sample-c-l4-1', kind: 'observation', text: '纹理颗粒在整张图上密度接近，亮斑集中在右上。', confidence: 0.66, anchor: { type: 'bbox', value: [900, 180, 460, 420] } },
      { id: 'sample-c-l4-2', kind: 'observation', text: '明度整体偏高，没有明显色相偏移。', confidence: 0.72, anchor: { type: 'whole', value: null } },
    ];
  } else { return; }
  const norm = (r) => ({ ...r, source: r.source || 'inferred', author: r.author || 'ai', modelVersion: a.modelVersion, evidenceRefs: r.evidenceRefs || [] });
  a.tags = [...new Set([...tags, ...(a.tags || [])])].slice(0, 32);
  a.L1 = { ...(a.L1 || {}), ...l1, source: 'inferred', author: 'ai', confidence: l1.confidence, anchor: { type: 'whole', value: null }, modelVersion: a.modelVersion };
  a.L2 = l2.map(norm); a.L4 = l4.map(norm); a.L5 = a.L5 || [];
  a.updatedAt = new Date().toISOString();
  await api.store.put(a);
}
async function refreshLibraryAssets() { const api = await initLibrary(); state.library.assets = await api.list(); }
function libFilterAssets() {
  const q = (state.library.query || '').trim();
  const filtered = (state.library.assets || []).filter((a) => {
    const filter = state.library.filter;
    const l1 = a.L1 || {};
    const l4 = a.L4 || []; const l5 = a.L5 || [];
    if (filter === 'pending') return l4.some((o) => !l5.some((d) => d.kind === 'confirm' && d.targetId === o.id));
    if (filter === 'referenced') return (a.projectRefs || []).length > 0 || (a.usageCount || 0) > 0;
    if (filter === 'lowconf') return (l1.confidence != null && l1.confidence < 0.55) || l4.some((o) => (o.confidence || 0) < 0.55);
    return true;
  });
  if (q) {
    const ql = q.toLowerCase();
    const literal = filtered.filter((a) => {
      const hay = [a.fileName, ...(a.tags || []), (a.L1 && a.L1.summary) || '', (a.L1 && a.L1.mood) || '', ...((a.L1 && a.L1.subject) || []), ...((a.L2 || []).map((r) => r.label))].join(' ').toLowerCase();
      return hay.includes(ql);
    });
    const pool = literal.length ? literal : filtered;
    try {
      const ranked = rankAssetsForQuery(pool, q, 60);
      if (ranked.length) return ranked.map((x) => x.asset);
      return pool;
    } catch (e) { /* fall through */ }
  }
  return filtered.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
}
function libThumbSrc(id) { return state.library.thumbs.get(id) || ''; }
async function libLoadThumb(id) {
  if (state.library.thumbs.has(id)) return;
  const api = await initLibrary();
  try { const t = await api.getThumbnail(id); if (t && t.dataUrl) { state.library.thumbs.set(id, t.dataUrl); renderLibrary(); } } catch (e) { /* ignore */ }
}
function libFormatBytes(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
function libSrcMeta(x) {
  return { observed: { icon: '●', label: '可见' }, inferred: { icon: '△', label: 'AI 推断' }, 'user-confirmed': { icon: '✓', label: '你确认' } }[x] || { icon: '·', label: x };
}
function libSrcBadge(x) { const m = libSrcMeta(x); return '<span class="lib-src ' + x + '"><i class="lib-src-ico">' + m.icon + '</i>' + m.label + '</span>'; }
function libSourceBadges(a) {
  const src = a.source || ['observed'];
  const order = ['observed', 'inferred', 'user-confirmed'];
  return order.filter((x) => src.includes(x)).map((x) => libSrcBadge(x)).join(' ');
}
function libRefCount(a) { return ((a.projectRefs || []).length > 0 || (a.usageCount || 0) > 0) ? 1 : 0; }
function libPendingCount(a) {
  const l4 = a.L4 || []; const l5 = a.L5 || [];
  return l4.filter((o) => !l5.some((d) => d.kind === 'confirm' && d.targetId === o.id)).length;
}
function renderLibrary() {
  const grid = document.getElementById('libGrid');
  if (!grid) return;
  const list = libFilterAssets();
  const cnt = document.getElementById('libCount'); if (cnt) cnt.textContent = String((state.library.assets || []).length);
  document.querySelectorAll('#libFilters .lib-chip').forEach((b) => b.classList.toggle('active', b.dataset.filter === state.library.filter && !state.library.tag));
  if (state.library.tag) {
    const bar = document.getElementById('libFilters');
    let chip = bar.querySelector('.lib-tag-filter');
    if (!chip) { chip = document.createElement('button'); chip.className = 'lib-chip lib-tag-filter active'; bar.append(chip); }
    chip.textContent = '#' + state.library.tag + ' ×';
    chip.onclick = () => { state.library.tag = null; renderLibrary(); };
  }
  grid.innerHTML = list.map((a) => {
    const thumb = libThumbSrc(a.id);
    const pending = libPendingCount(a);
    const refs = libRefCount(a);
    return '<article class="lib-card' + (state.library.selectedId === a.id ? ' active' : '') + '" data-id="' + libEsc(a.id) + '">' +
      '<div class="lib-thumb">' + (thumb ? '<img src="' + thumb + '" alt="">' : '<span class="lib-skel">缩略图</span>') +
      '<div class="lib-card-badges">' + libSourceBadges(a) + '</div><span class="lib-status">' + (pending ? pending + ' 待确认' : 'AI 已读') + '</span></div>' +
      '<div class="lib-card-body"><div class="lib-card-title">' + libEsc((a.fileName || '素材').replace(/\.[^.]+$/, '')) + '</div>' +
      '<div class="lib-card-row">' + (a.tags || []).slice(0, 3).map((t) => '<span class="lib-tag">' + libEsc(t) + '</span>').join('') + '</div>' +
      '<div class="lib-card-status">AI 已读 · ' + ((a.L2 || []).length) + ' 区域 · ' + ((a.L4 || []).length) + ' 观察</div>' +
      (refs ? '<div class="lib-ref-tag">被本作品引用 1 次</div>' : '') + '</div></article>';
  }).join('');
  grid.querySelectorAll('.lib-card').forEach((el) => el.addEventListener('click', () => selectLibraryAsset(el.dataset.id)));
  list.forEach((a) => libLoadThumb(a.id));
  const empty = document.getElementById('libState');
  if (empty) {
    empty.hidden = list.length > 0;
    empty.textContent = !state.library.assets.length ? '还没有素材。导入一张，让 AI 先读懂它，再在画布用它。' : (state.library.query || state.library.filter !== 'all' ? '没有匹配的素材。换个关键词，或清空筛选。' : '');
    if (state.library.query || state.library.filter !== 'all' || state.library.tag) empty.innerHTML = '没有匹配的素材。 <button class="lib-act" id="libClearSearch">清空筛选</button>';
    const clr = document.getElementById('libClearSearch'); if (clr) clr.onclick = () => { state.library.query = ''; state.library.filter = 'all'; state.library.tag = null; const inp = document.getElementById('libSearch'); if (inp) inp.value = ''; renderLibrary(); };
  }
  renderLibraryDetail();
}
function selectLibraryAsset(id) { state.library.selectedId = id; state.library.highlightRegion = -1; renderLibrary(); }
function libSelectedAsset() { const id = state.library.selectedId; return (state.library.assets || []).find((a) => a.id === id) || null; }
function libPreviewSrc(a) { return state.library.thumbs.get(a.id) || ''; }
function renderLibraryDetail() {
  const host = document.getElementById('libDetail');
  if (!host) return;
  const a = libSelectedAsset();
  if (!a) { host.innerHTML = '<div class="lib-detail-empty">选择一张素材，查看它被 AI 读懂的内容。</div>'; return; }
  const l1 = a.L1 || {}; const l2 = a.L2 || []; const l4 = a.L4 || []; const l5 = a.L5 || [];
  const pref = state.library.prefs || {};
  const confirmed = (obs) => l5.some((d) => d.kind === 'confirm' && d.targetId === obs.id);
  const rejected = (obs) => l5.some((d) => d.kind === 'reject' && d.targetId === obs.id);
  const refCount = libRefCount(a);
  const isRef = state.aiReference && state.aiReference.id === a.id;
  host.innerHTML = '<div class="lib-detail-body"><div class="lib-preview"><img id="libPreviewImg" src="' + libPreviewSrc(a) + '" alt=""><canvas id="libPreviewOverlay" width="' + a.width + '" height="' + a.height + '"></canvas></div>' +
    '<div class="lib-h1">' + libEsc((a.fileName || '').replace(/\.[^.]+$/, '')) + '<span class="lib-menu"><button class="lib-act" id="libReanalyze" title="重新分析（Mock）">↻</button> <button class="lib-act" id="libReanalyzeReal" title="真实模型重读（Qwen 视觉）">◎ 真实读</button> <button class="lib-act" id="libDeleteAsset" title="删除">🗑</button></span></div>' +
    '<div class="lib-file">' + libEsc(a.fileName) + ' · ' + (a.analysisSource === 'real' ? ('真实 AI 已读 · ' + libEsc(a.modelVersion || '') + (a.analysis && a.analysis.at ? ' · ' + libEsc(String(a.analysis.at).slice(0, 16).replace('T', ' ')) : '')) : '本地 Mock 初读 · 可点「真实读」用视觉模型重读') + '</div>' +
    '<div class="lib-sec"><div class="lib-sec-title">L0 · 原件（可见）</div><div class="lib-kv">' + libSrcBadge('observed') + ' '  + libEsc((a.mime || 'image').replace('image/', '').toUpperCase()) + ' · ' + a.width + '×' + a.height + ' · ' + libFormatBytes(a.bytes || 0) + ' · 导入 ' + libEsc(String(a.createdAt || '').slice(0, 10)) + '</div><div class="lib-kv muted">SHA-256 ' + libEsc(String(a.sha256 || '').slice(0, 12)) + ' · AI 不修改原件</div></div>' +
    '<div class="lib-sec"><div class="lib-sec-title">L1 · 全局（AI 推断）</div><div class="lib-l1-summary">' + libEsc(l1.summary || '') + '</div>' +
    '<div class="lib-chips">' + (l1.subject || []).map((t) => '<span class="lib-tag">主体 · ' + libEsc(t) + '</span>').join('') + (l1.mood ? '<span class="lib-tag">情绪 · ' + libEsc(l1.mood) + '</span>' : '') + '</div>' +
    '<div class="lib-palette">' + (a.palette || []).slice(0, 6).map((c) => '<span style="background:' + libEsc(c) + '" title="' + libEsc(String(c).toUpperCase()) + '" aria-label="色板 ' + libEsc(String(c).toUpperCase()) + '" data-color="' + libEsc(c) + '"></span>').join('') + '</div>' +
    '<div class="lib-kv muted">' + libSrcBadge('inferred') + ' ' + Math.round((l1.confidence || 0) * 100) + '% · mock-ai@0.1.0</div></div>' +
    '<div class="lib-sec"><div class="lib-sec-title">L2 · 区域（' + l2.length + '）</div>' + l2.map((r, i) => '<div class="lib-l2-row' + (state.library.highlightRegion === i ? ' highlight' : '') + '" data-region="' + i + '"><div class="lib-l2-thumb"><canvas width="44" height="44" data-l2thumb="' + i + '"></canvas></div><div class="lib-l2-meta"><div class="lib-l2-label">' + libEsc(r.label) + ' · 重要度 ' + Math.round((r.importance || 0) * 100) + '%</div><div class="lib-kv muted">bbox ' + ((r.bbox || []).map((n) => Math.round(n)).join(', ')) + '</div><div class="lib-bar"><i style="width:' + Math.round((r.importance || 0) * 100) + '%"></i></div></div></div>').join('') + '</div>' +
    '<div class="lib-sec"><div class="lib-sec-title">L4 · 观察（' + l4.length + '）</div>' + l4.map((o) => '<div class="lib-obs"><div class="lib-obs-head">' + libSrcBadge('inferred') + '<span class="lib-kv muted">' + Math.round((o.confidence || 0) * 100) + '%</span>' + (confirmed(o) ? libSrcBadge('user-confirmed') : rejected(o) ? '<span class="lib-src"><i class="lib-src-ico">×</i>已否决</span>' : '') + '</div><div class="lib-obs-text">' + libEsc(o.text) + '</div><div class="lib-obs-anchor">anchor · ' + libEsc(o.anchor && o.anchor.value ? String(o.anchor.value) : '整体') + '</div><div class="lib-obs-actions"><button class="primary" data-confirm="' + libEsc(o.id) + '">确认</button><button class="danger" data-reject="' + libEsc(o.id) + '">不对</button></div></div>').join('') + '</div>' +
    '<div class="lib-sec"><div class="lib-sec-title">L5 · 决策（最近 3 条）</div><ul class="lib-l5">' + (l5.slice(-3).map((d) => '<li>' + (d.kind === 'confirm' ? '✓ 你确认了' : d.kind === 'reject' ? '× 你否决了' : '● 使用了这张素材') + (d.tags && d.tags.length ? ' · ' + libEsc(d.tags.slice(0, 3).join(' · ')) : '') + ' · ' + libEsc(String(d.at || '').slice(11, 16)) + '</li>').join('') || '<li>还没有决策。</li>') + '</ul></div>' +
    '<div class="lib-sec"><div class="lib-sec-title">偏好（最小）</div><div class="lib-kv">' + libEsc(pref.summary || 'AI 从你的确认里读到的偏好：暂无') + '</div><div class="lib-kv muted">仅作为后续参考，不训练模型</div></div>' +
    '<div class="lib-sec"><div class="lib-sec-title">引用关系</div><div class="lib-kv">' + (refCount ? '本作品引用 ' + refCount + ' 次' : '尚未被本作品引用') + (isRef ? ' · 当前作为 AI 参考' : '') + '</div>' + (isRef ? '<div class="lib-ref-row">参考：' + libEsc(a.fileName) + ' <button id="libClearRef">取消引用</button></div>' : '') + '</div>' +
    '</div><div class="lib-actions"><button class="primary" id="libInsertLayer">插入为图层</button><button class="ghost" id="libUseRef">作为 AI 参考</button><button class="ghost" id="libAddTagQuick">+ 标签</button>' + (state.library.deleteConfirm === a.id ? '<button class="ghost" id="libDeleteConfirm" style="color:#fca5a5">确认删除</button>' : '') + '</div>';
  const img = document.getElementById('libPreviewImg');
  if (img && !img.src) img.src = libPreviewSrc(a);
  if (img) img.onload = () => drawLibraryOverlay(a);
  drawLibraryOverlay(a);
  host.querySelectorAll('[data-confirm]').forEach((b) => b.onclick = async () => { const api = await initLibrary(); await api.confirm(a.id, { targetId: b.dataset.confirm, tags: a.tags || [] }); await refreshLibraryAssets(); await refreshLibraryPrefs(); renderLibrary(); showToast('已确认，写回 L5'); });
  host.querySelectorAll('[data-reject]').forEach((b) => b.onclick = async () => { const api = await initLibrary(); await api.reject(a.id, { targetId: b.dataset.reject, tags: a.tags || [] }); await refreshLibraryAssets(); await refreshLibraryPrefs(); renderLibrary(); showToast('已否决，写回 L5'); });
  host.querySelectorAll('[data-region]').forEach((el) => { el.onmouseenter = () => { state.library.highlightRegion = Number(el.dataset.region); drawLibraryOverlay(a); }; el.onclick = () => { state.library.highlightRegion = Number(el.dataset.region); drawLibraryOverlay(a); }; });
  host.querySelectorAll('[data-l2thumb]').forEach((cv) => drawRegionThumb(cv, a, Number(cv.dataset.l2thumb)));
  host.querySelectorAll('[data-color]').forEach((el) => el.onclick = () => { navigator.clipboard && navigator.clipboard.writeText(el.dataset.color).catch(() => {}); showToast('已复制 ' + el.dataset.color); });
  document.getElementById('libInsertLayer').onclick = () => insertAssetLayer(a);
  document.getElementById('libUseRef').onclick = () => useAssetAsReference(a);
  const _cr = document.getElementById('libClearRef'); if (_cr) _cr.onclick = () => clearAIReference();
  const _ra = document.getElementById('libReanalyze'); if (_ra) _ra.onclick = () => reanalyzeAsset(a);
  const _rr = document.getElementById('libReanalyzeReal'); if (_rr) _rr.onclick = () => reanalyzeAssetReal(a);
  const _da = document.getElementById('libDeleteAsset'); if (_da) _da.onclick = () => { state.library.deleteConfirm = a.id; renderLibraryDetail(); };
  const dc = document.getElementById('libDeleteConfirm'); if (dc) dc.onclick = () => deleteLibraryAsset(a);
  document.getElementById('libAddTagQuick').onclick = () => addTagToAsset(a);
}
function drawLibraryOverlay(a) {
  const cv = document.getElementById('libPreviewOverlay'); if (!cv) return;
  const img = document.getElementById('libPreviewImg'); if (!img) return;
  const rect = img.getBoundingClientRect();
  const ratio = a.width / a.height;
  let w = rect.width, h = w / ratio; if (h > rect.height) { h = rect.height; w = h * ratio; }
  cv.width = Math.max(1, Math.round(w)); cv.height = Math.max(1, Math.round(h));
  cv.style.width = 'auto'; cv.style.height = 'auto';
  const g = cv.getContext('2d'); g.clearRect(0, 0, cv.width, cv.height);
  const sx = cv.width / a.width, sy = cv.height / a.height;
  (a.L2 || []).forEach((r, i) => {
    const b = r.bbox || [];
    if (b.length < 4) return;
    g.strokeStyle = state.library.highlightRegion === i ? '#fcd34d' : '#6AA6FF';
    g.lineWidth = state.library.highlightRegion === i ? 3 : 1.6;
    g.strokeRect(b[0] * sx, b[1] * sy, b[2] * sx, b[3] * sy);
  });
}
function drawRegionThumb(cv, a, idx) {
  const img = document.getElementById('libPreviewImg'); if (!img || !img.complete || !img.naturalWidth) return;
  const r = (a.L2 || [])[idx]; if (!r || !r.bbox) return;
  const g = cv.getContext('2d'); g.clearRect(0, 0, cv.width, cv.height);
  try { g.drawImage(img, r.bbox[0], r.bbox[1], r.bbox[2], r.bbox[3], 0, 0, cv.width, cv.height); } catch (e) { /* ignore */ }
}
function libOverlayVisible() { return !!state.library.open; }
async function openLibrarySheet() {
  if (state.library.open) return;
  state.library.open = true;
  state.library.savedUi = {
    tool: state.tool,
    selectionMode: state.selectionMode,
    selection: state.selection ? { ...state.selection } : null,
  };
  if (state.transformActive) cancelTransformUI();
  closePopovers();
  const sk = document.getElementById('libSearch'); if (sk) sk.value = state.library.query || '';
  document.getElementById('libraryBackdrop').hidden = false;
  document.getElementById('librarySheet').hidden = false;
  document.body.classList.add('library-open');
  try {
    await initLibrary();
    await ensureSampleLibrary();
    await refreshLibraryPrefs();
    const last = state.library.selectedId;
    renderLibrary();
    if (!libSelectedAsset()) { const first = libFilterAssets()[0]; if (first) { state.library.selectedId = first.id; renderLibrary(); } }
    setTimeout(() => { try { const si = document.getElementById('libSearch'); if (si) si.focus(); } catch (e) {} }, 40);
  } catch (e) { console.error(e); showToast('素材库加载失败：' + (e.message || e), true); }
}
async function refreshLibraryPrefs() { try { const api = await initLibrary(); state.library.prefs = await api.preferences(); } catch (e) { state.library.prefs = null; } }
function closeLibrarySheet() {
  state.library.open = false;
  document.getElementById('libraryBackdrop').hidden = true;
  document.getElementById('librarySheet').hidden = true;
  document.body.classList.remove('library-open');
  const saved = state.library.savedUi; state.library.savedUi = null;
  if (saved && !state.demo.active) {
    if (saved.selectionMode) state.selectionMode = saved.selectionMode;
    if (saved.tool && saved.tool !== state.tool) setTool(saved.tool);
    else setupBrushInput();
  }
  try { document.getElementById('btnLibrary').focus({ preventScroll: true }); } catch (e) {}
}
async function libImportFiles(files) {
  const list = Array.from(files || []).filter((f) => /^image\/(png|jpeg|webp)$/.test(f.type || ''));
  if (!list.length) { showToast('请选择 PNG / JPG / WebP 图片', true); return; }
  const api = await initLibrary();
  const prog = document.getElementById('libProgress'); const txt = document.getElementById('libProgressText'); const bar = document.getElementById('libProgressBar');
  if (prog) prog.hidden = false; if (txt) txt.textContent = '正在读懂 0 / ' + list.length + '…'; if (bar) bar.style.width = '0%';
  try {
    const res = await api.importFiles(list, { onProgress: (p) => { if (txt) txt.textContent = '正在读懂 ' + p.index + ' / ' + p.total + ' · 导入 ' + p.imported + (p.duplicates ? ' · 重复 ' + p.duplicates : ''); if (bar) bar.style.width = Math.round(((p.index + 1) / p.total) * 100) + '%'; } });
    await refreshLibraryAssets(); await refreshLibraryPrefs(); state.library.selectedId = res.imported[0] ? res.imported[0].id : state.library.selectedId; renderLibrary();
    const regions = res.imported.reduce((n, a) => n + (a.L2 || []).length, 0); const obs = res.imported.reduce((n, a) => n + (a.L4 || []).length, 0);
    showToast('已导入 ' + res.imported.length + ' 张，AI 读懂了 ' + regions + ' 个区域、' + obs + ' 条观察' + (res.duplicates.length ? '；' + res.duplicates.length + ' 张已存在（sha 去重）' : '') + (res.errors.length ? '；' + res.errors.length + ' 张失败' : ''));
  } catch (e) { showToast('导入失败：' + (e.message || e), true); }
  finally { setTimeout(() => { if (prog) prog.hidden = true; }, 900); }
}
async function addTagToAsset(a) {
  const input = document.getElementById('libTagInput');
  if (!input) {
    const host = document.getElementById('libDetail'); const box = document.createElement('div'); box.className = 'ld-row';
    box.innerHTML = '<input id="libTagInput" placeholder="新标签，回车保存" style="flex:1 1 auto;background:#0b1220;border:1px solid #2a3a52;color:#dbe7f5;border-radius:6px;padding:4px 6px;font-size:12px"><button class="lib-act" id="libTagSave">保存</button>';
    host.insertBefore(box, host.querySelector('.lib-actions'));
    const save = async () => { const v = document.getElementById('libTagInput').value.trim(); if (!v) return; const api = await initLibrary(); await api.updateTags(a.id, [...(a.tags || []), v]); await refreshLibraryAssets(); renderLibrary(); showToast('标签已保存：' + v); };
    document.getElementById('libTagSave').onclick = save;
    document.getElementById('libTagInput').onkeydown = (e) => { if (e.key === 'Enter') save(); };
    document.getElementById('libTagInput').focus();
    return;
  }
  input.focus();
}
async function getAssetImageUrl(a) {
  const api = await initLibrary();
  let cleanup = () => {};
  try {
    if (typeof api.getOriginal === 'function') {
      const orig = await api.getOriginal(a.id, { objectUrl: true, imageBitmap: true });
      if (orig) {
        if (orig.imageBitmap) {
          try {
            const cv = document.createElement('canvas');
            cv.width = orig.imageBitmap.width; cv.height = orig.imageBitmap.height;
            cv.getContext('2d').drawImage(orig.imageBitmap, 0, 0);
            const dataUrl = cv.toDataURL('image/png');
            try { orig.imageBitmap.close(); } catch (e) {}
            if (orig.url) { try { URL.revokeObjectURL(orig.url); } catch (e) {} }
            state.lastAssetImageSource = 'original-bitmap';
            return { url: dataUrl, cleanup: () => {}, source: 'original-bitmap' };
          } finally {
            if (orig.url) { try { URL.revokeObjectURL(orig.url); } catch (e) {} }
          }
        }
        if (orig.url) {
          state.lastAssetImageSource = orig.fallback ? 'thumb' : 'original-url';
          return { url: orig.url, cleanup: () => { try { URL.revokeObjectURL(orig.url); } catch (e) {} }, source: state.lastAssetImageSource };
        }
        if (orig.blob) {
          const url = URL.createObjectURL(orig.blob);
          state.lastAssetImageSource = orig.fallback ? 'thumb' : 'original-blob';
          return { url, cleanup: () => { try { URL.revokeObjectURL(url); } catch (e) {} }, source: state.lastAssetImageSource };
        }
        if (orig.dataUrl) {
          state.lastAssetImageSource = orig.fallback ? 'thumb' : 'original-data';
          return { url: orig.dataUrl, cleanup, source: state.lastAssetImageSource };
        }
      }
    }
  } catch (e) { /* fallback to thumbnail */ }
  const t = await api.getThumbnail(a.id);
  state.lastAssetImageSource = 'thumb';
  return { url: t && t.dataUrl ? t.dataUrl : '', cleanup, source: 'thumb' };
}
async function recordAssetProjectRef(a) {
  try {
    const api = await initLibrary();
    const latest = await api.get(a.id);
    if (!latest) return;
    latest.projectRefs = [...new Set([...(latest.projectRefs || []), '雾中山谷 · v2'])];
    latest.usageCount = (latest.usageCount || 0) + 1;
    await api.store.put(latest);
  } catch (e) { /* ignore */ }
}
async function insertAssetLayer(a) {
  let resolved = null;
  try {
    resolved = await getAssetImageUrl(a);
    const url = resolved.url;
    if (!url) throw new Error('无法取得素材图（T74 原图/缩略图均不可用）');
    const img = new Image(); img.src = url; await img.decode();
    const maxW = engine.width * 0.6, maxH = engine.height * 0.6;
    const sc = Math.min(maxW / img.width, maxH / img.height);
    const w = Math.round(img.width * sc), h = Math.round(img.height * sc);
    const layer = await importImageAsLayer(url, '素材 · ' + (a.fileName || 'asset').replace(/\.[^.]+$/, ''), { x: Math.round((engine.width - w) / 2), y: Math.round((engine.height - h) / 2), width: w, height: h });
    try { resolved.cleanup(); } catch (e) { /* ignore */ }
    state.lastAssetImageSource = resolved.source;
    state.assetLayerRefs.set(layer.id, { assetId: a.id, fileName: a.fileName, sha256: a.sha256, imageSource: resolved.source });
    await recordAssetProjectRef(a);
    const api = await initLibrary(); try { await api.markUsed(a.id); } catch (e) {}
    state.aiReference = { id: a.id, fileName: a.fileName, sha256: a.sha256, tags: (a.tags || []).slice(0, 6), l1: a.L1, l2: (a.L2 || []).slice(0, 3) };
    addRecord(baseRecord('L6', { kind: 'asset_inserted', anchor: { type: 'whole', value: null }, model: { provider: 'mock', model: MOCK_MODEL }, params: { asset_id: a.id, sha256: a.sha256, layer_id: layer.id, image_source: resolved.source, position: { x: Math.round((engine.width - w) / 2), y: Math.round((engine.height - h) / 2), w, h } }, input_refs: [], assertions: [{ type: 'ai_never_inserts', value: true }], ai_role: 'assistant', source: 'observed', author: 'user', note: '素材插入为图层' }));
    renderAIReferenceBar(); renderAll(); scheduleProjectAutosave();
    closeLibrarySheet();
    if (!state.demo.active) {
      enterImageTransformUI(layer, (engine.width - w) / 2, (engine.height - h) / 2, w, h);
      showToast('已插入为图层并进入变换：拖手柄缩放/旋转、拖内部移动，Enter 提交；按 H 或空格拖动画布');
    } else {
      showToast('已插入为图层 · 可移动、隐藏、撤销');
    }
    return layer;
  } catch (e) { try { resolved && resolved.cleanup && resolved.cleanup(); } catch (err) {} console.error(e); showToast('插入失败：' + (e.message || e), true); return null; }
}
async function useAssetAsReference(a) {
  state.aiReference = { id: a.id, fileName: a.fileName, sha256: a.sha256, tags: (a.tags || []).slice(0, 6), l1: a.L1, l2: (a.L2 || []).slice(0, 3) };
  try { addRecord(baseRecord('L6', { kind: 'reference_added', anchor: { type: 'whole', value: null }, model: { provider: 'mock', model: MOCK_MODEL }, params: { asset_id: a.id, sha256: a.sha256 }, input_refs: [], assertions: [{ type: 'ai_never_modifies_original', value: true }], ai_role: 'assistant', source: 'observed', author: 'user', note: '素材作为 AI 参考' })); } catch (e) { /* ignore */ }
  renderAIReferenceBar();
  closeLibrarySheet();
  openPopover('popAI');
  renderAIPanel();
  showToast('已作为 AI 参考：' + (a.fileName || '素材'));
}
function renderAIReferenceBar() {
  const bar = document.getElementById('aiReferenceBar'); if (!bar) return;
  const r = state.aiReference;
  if (!r) { bar.hidden = true; bar.innerHTML = ''; return; }
  bar.hidden = false;
  const tags = (r.tags || []).slice(0, 3).map((t) => libEsc(t)).join(' · ');
  const l2 = (r.l2 || []).map((x) => x.label).slice(0, 3).join(' / ');
  bar.innerHTML = '<span class="ai-ref-text">参考素材：<span class="rname" title="' + libEsc(r.fileName || '') + '">' + libEsc((r.fileName || '').replace(/\.[^.]+$/, '')) + '</span>' + (tags ? ' · ' + tags : '') + (l2 ? ' · ' + libEsc(l2) : '') + '</span><button id="btnClearAIReference" class="ai-ref-remove" title="移除素材参考" aria-label="移除素材参考">×</button>';
  const b = document.getElementById('btnClearAIReference'); if (b) b.onclick = () => clearAIReference();
}
function clearAIReference() {
  const r = state.aiReference; state.aiReference = null; renderAIReferenceBar(); renderAIPanel();
  if (r) { try { addRecord(baseRecord('L6', { kind: 'reference_removed', anchor: { type: 'whole', value: null }, model: { provider: 'mock', model: MOCK_MODEL }, params: { asset_id: r.id }, input_refs: [], assertions: [{ type: 'reference_only', value: true }], ai_role: 'assistant', source: 'observed', author: 'user', note: '取消素材参考' })); } catch (e) {} }
  showToast('已取消本次素材参考');
}
async function imageUrlToAnalysisInput(url, maxSide = 1568) {
  const img = new Image();
  img.src = url;
  await img.decode();
  const scale = Math.min(1, maxSide / Math.max(1, img.width, img.height));
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  c.getContext('2d').drawImage(img, 0, 0, w, h);
  return { dataUrl: c.toDataURL('image/jpeg', 0.9), width: w, height: h };
}
async function reanalyzeAssetReal(a, opts = {}) {
  if (!a) return null;
  if (!aiRealEligible()) { showToast('真实视觉重读需要先在「模型」里允许真实调用', true); return null; }
  const provider = aiProviderLabel();
  const model = aiRuntimeModel();
  if (!opts.skipConfirm) {
    const ok = await confirmAiSend('将把素材「' + (a.fileName || 'asset') + '」缩放后的缩略图发送给 ' + provider + ' / ' + model + '，用来重读它的整体、区域、观察、标签与色板');
    if (!ok) return null;
  }
  const ac = new AbortController();
  state.aiAbort = ac;
  if (!opts.batch) aiBeginTask('真实视觉读素材…');
  try {
    const resolved = await getAssetImageUrl(a);
    if (!resolved || !resolved.url) throw new Error('无法取得素材图');
    const input = await imageUrlToAnalysisInput(resolved.url, 1568);
    try { resolved.cleanup && resolved.cleanup(); } catch (e) { /* ignore */ }
    const runtime = await getSkillRuntime();
    const run = await runtime.run('asset.decompose', {
      image: input.dataUrl, width: input.width, height: input.height, fileName: a.fileName,
      archive: aiArchiveSummary(),
    }, { provider: aiGetProvider({ signal: ac.signal }), context: { source: 'library', assetId: a.id } });
    const res = run.result;
    const libMod = await import('../../library/library-schema.mjs');
    const api = await initLibrary();
    const latest = await api.get(a.id);
    if (!latest) throw new Error('素材不存在');
    const merged = mergeRealAnalysis(latest, res, {
      provider: (run.meta && run.meta.provider) || aiPreset().provider,
      model: (run.meta && (run.meta.modelVersion || run.meta.model)) || model,
      skill: run.skill.id, skill_version: run.skill.version,
      latency_ms: run.log ? run.log.latencyMs : null,
    });
    Object.assign(latest, merged);
    latest.tags = [...new Set([...(latest.tags || []), '真实AI重读'])].slice(0, 32);
    latest.updatedAt = iso();
    await api.store.put(latest);
    await refreshLibraryAssets();
    if (state.library.open) renderLibrary();
    addRecord(baseRecord('L6', {
      kind: 'critique', anchor: { type: 'whole', value: null },
      model: { provider: run.meta && run.meta.provider || aiPreset().provider, model: latest.modelVersion || model },
      params: { task: 'asset_decompose', asset_id: a.id, skill: run.skill.id, skill_version: run.skill.version, latency_ms: run.log ? run.log.latencyMs : null, usage: run.meta && run.meta.usage || null, observations: (res.observations || []).length, regions: (res.regions || []).length },
      input_refs: [], assertions: [{ type: 'no_training_use', value: true }, { type: 'inferred_only', value: true }],
      usage: run.meta && run.meta.usage || null, latency_ms: run.log ? run.log.latencyMs : 0,
      ai_role: 'assistant', source: 'inferred', author: 'ai', note: '真实视觉重读素材（skill: ' + run.skill.id + '）',
    }));
    aiLog('skill', '真实重读素材「' + (a.fileName || '') + '」· ' + (run.log ? run.log.latencyMs : 0) + 'ms', { provider: run.meta && run.meta.provider, model: latest.modelVersion });
    if (!opts.batch) aiEndTask();
    if (!opts.silent) showToast('真实视觉重读完成：' + (res.observations || []).length + ' 条观察 / ' + (res.regions || []).length + ' 个区域；模型 ' + latest.modelVersion);
    return latest;
  } catch (e) {
    console.error(e);
    if (!opts.batch) aiEndTask();
    if (opts.batch) throw e;
    if (e && (e.code === 'cancelled' || e.name === 'AbortError')) showToast('已取消素材重读');
    else showToast('素材重读失败：' + (e.userMessage || e.message || e), true);
    return null;
  }
}
function batchReviewStatusText(s) {
  return ({ planned: '待读', running: '读取中…', done: '已读 · 待决定', adopted: '已采用', kept: '已保留 Mock', error: '失败' })[s] || s;
}
async function openBatchReviewPanel() {
  try {
    await refreshLibraryAssets();
    const assets = state.library.assets || [];
    const batchMod = await import('../core/asset-batch.mjs');
    const plan = batchMod.planBatchRead(assets, { limit: 3, onlyMock: true });
    if (!plan.length) { showToast('没有待重读的素材（已读/无 Mock 档案）'); return null; }
    state.batchReview = {
      mode: aiRealEligible() ? 'real' : 'mock',
      plan,
      items: plan.map((p) => ({ id: p.id, fileName: p.fileName, reason: p.reason, before: null, result: null, status: 'planned', error: null })),
      started: false, running: false, cancelled: false,
    };
    const sub = document.getElementById('batchReviewSub');
    if (sub) sub.textContent = '串行读取 ' + plan.length + ' 张素材；结果写入素材库，可逐项采用 / 保留 Mock / 重试。';
    renderBatchReview();
    openModal('batchReviewModal');
    return state.batchReview;
  } catch (e) { showToast('批量重读准备失败：' + (e.message || e), true); return null; }
}
function renderBatchReview() {
  const st = state.batchReview;
  const list = document.getElementById('batchReviewList');
  const sum = document.getElementById('batchReviewSummary');
  const prog = document.getElementById('batchReviewProgress');
  if (!st || !list) return;
  const done = st.items.filter((i) => ['done', 'adopted', 'kept'].includes(i.status)).length;
  const adopted = st.items.filter((i) => i.status === 'adopted').length;
  const kept = st.items.filter((i) => i.status === 'kept').length;
  const failed = st.items.filter((i) => i.status === 'error').length;
  if (sum) sum.textContent = (st.mode === 'real' ? '真实视觉重读' : 'Mock 离线重读') + ' · ' + st.items.length + ' 张 · 已处理 ' + done + ' · 采用 ' + adopted + ' · 保留 ' + kept + (failed ? ' · 失败 ' + failed : '');
  if (prog) prog.textContent = st.running ? ('正在读取… ' + done + '/' + st.items.length) : (st.started ? '读取结束；可逐项决定，或点「全部采用 / 全部保留 Mock」。' : '准备就绪：点击「开始重读」，真实模式会先确认一次。');
  list.innerHTML = st.items.map((it, i) => {
    const result = it.result;
    const body = it.status === 'error' ? escapeHtml(it.error || '失败') : (result && result.L1 ? ('L1：' + String(result.L1.summary || '').slice(0, 120) + (result.L2 ? ' · L2 ' + result.L2.length : '') + (result.L4 ? ' · L4 ' + result.L4.length : '')) : (it.status === 'running' ? '正在读取素材与拆解…' : escapeHtml(it.reason || '')));
    const actions = ['done', 'error'].includes(it.status)
      ? '<div class="batch-review-actions">' + (it.status === 'done' ? '<button class="btn tiny primary" data-batch-act="adopt" data-batch-i="' + i + '">采用</button><button class="btn tiny" data-batch-act="keep" data-batch-i="' + i + '">保留 Mock</button>' : '') + '<button class="btn tiny" data-batch-act="retry" data-batch-i="' + i + '">重试</button></div>'
      : '';
    return '<div class="batch-review-item"><div class="batch-review-head"><span class="batch-review-name">' + escapeHtml(it.fileName || it.id) + '</span><span class="batch-review-status ' + it.status + '">' + batchReviewStatusText(it.status) + '</span></div><div class="batch-review-body">' + body + '</div>' + actions + '</div>';
  }).join('');
  const start = document.getElementById('batchReviewStart'); if (start) { start.hidden = st.started; start.disabled = st.running; start.textContent = st.running ? '运行中…' : '开始重读'; }
  const stop = document.getElementById('batchReviewStop'); if (stop) stop.hidden = !st.running;
  const adoptAll = document.getElementById('batchReviewAdoptAll'); if (adoptAll) adoptAll.hidden = !st.items.some((i) => i.status === 'done');
  const keepAll = document.getElementById('batchReviewKeepAll'); if (keepAll) keepAll.hidden = !st.items.some((i) => ['done', 'adopted'].includes(i.status) && i.before);
  list.querySelectorAll('[data-batch-act]').forEach((b) => b.addEventListener('click', () => {
    const i = parseInt(b.dataset.batchI, 10);
    if (b.dataset.batchAct === 'adopt') adoptBatchItem(i);
    else if (b.dataset.batchAct === 'keep') keepBatchItem(i);
    else if (b.dataset.batchAct === 'retry') retryBatchItem(i);
  }));
}
async function runBatchItem(item) {
  const st = state.batchReview;
  const a = (state.library.assets || []).find((x) => x.id === item.id);
  if (!a) throw new Error('素材不存在：' + item.id);
  item.before = JSON.parse(JSON.stringify(a));
  item.status = 'running'; item.error = null; item.result = null; renderBatchReview();
  let latest = null;
  if (st.mode === 'real') latest = await reanalyzeAssetReal(a, { skipConfirm: true, batch: true, silent: true });
  else { await reanalyzeAsset(a, { silent: true, batch: true }); const api = await initLibrary(); latest = await api.get(item.id); }
  if (!latest) throw new Error('读取没有返回结果');
  item.result = latest; item.status = 'done'; renderBatchReview();
  return latest;
}
async function startBatchReview() {
  const st = state.batchReview;
  if (!st || st.running) return null;
  const useReal = st.mode === 'real';
  const ok = await confirmAiSend(useReal
    ? ('将按队列串行把 ' + st.items.length + ' 张素材缩略图发送给 ' + aiProviderLabel() + ' / ' + aiRuntimeModel() + ' 做真实视觉重读；结果写入素材库，可再保留 Mock / 重试。')
    : ('当前未启用真实调用：将用本地 Mock 串行重读 ' + st.items.length + ' 张素材（不联网、不花钱）。'));
  if (!ok) return null;
  st.started = true; st.running = true; st.cancelled = false;
  state.aiAbort = new AbortController();
  renderBatchReview();
  let done = 0, failed = 0;
  for (const item of st.items) {
    if (st.cancelled) break;
    if (!['planned', 'error'].includes(item.status)) continue;
    try { await runBatchItem(item); done += 1; } catch (e) { item.status = 'error'; item.error = e.userMessage || e.message || String(e); failed += 1; renderBatchReview(); }
  }
  st.running = false;
  await refreshLibraryAssets();
  if (state.library.open) renderLibrary();
  addRecord(baseRecord('L6', { kind: 'critique', anchor: { type: 'whole', value: null }, model: { provider: useReal ? aiPreset().provider : 'mock', model: useReal ? aiRuntimeModel() : MOCK_MODEL }, params: { task: 'asset_batch_decompose', mode: useReal ? 'real' : 'mock', total: st.items.length, done, failed, ids: st.items.map((x) => x.id), skill: 'asset.decompose' }, input_refs: [], assertions: [{ type: useReal ? 'no_training_use' : 'mock_only', value: true }], ai_role: 'assistant', source: useReal ? 'inferred' : 'observed', author: 'ai', note: useReal ? '素材批量真实理解队列' : '素材批量 Mock 理解队列' }));
  renderBatchReview();
  showToast('批量重读结束：' + done + ' 成功 / ' + failed + ' 失败；请逐项采用或保留 Mock');
  return st;
}
async function adoptBatchItem(i) {
  const st = state.batchReview; const item = st && st.items[i]; if (!item) return;
  item.status = 'adopted'; renderBatchReview();
  showToast('已采用：' + (item.fileName || item.id));
}
async function keepBatchItem(i) {
  const st = state.batchReview; const item = st && st.items[i]; if (!item || !item.before) return;
  try {
    const api = await initLibrary();
    const latest = await api.get(item.id);
    if (latest) await api.store.put({ ...item.before, updatedAt: iso() });
    item.status = 'kept'; renderBatchReview();
    await refreshLibraryAssets(); if (state.library.open) renderLibrary();
    showToast('已保留 Mock：' + (item.fileName || item.id));
  } catch (e) { showToast('保留 Mock 失败：' + (e.message || e), true); }
}
async function retryBatchItem(i) {
  const st = state.batchReview; const item = st && st.items[i]; if (!item || st.running) return;
  st.running = true; st.started = true; renderBatchReview();
  try { await runBatchItem(item); showToast('重试完成：' + (item.fileName || item.id)); }
  catch (e) { item.status = 'error'; item.error = e.message || String(e); showToast('重试失败：' + item.error, true); }
  st.running = false; await refreshLibraryAssets(); if (state.library.open) renderLibrary(); renderBatchReview();
}
async function adoptAllBatch() {
  const st = state.batchReview; if (!st) return;
  st.items.forEach((it) => { if (it.status === 'done') it.status = 'adopted'; });
  renderBatchReview(); showToast('已采用待决定结果（保留 Mock 的项不变）');
}
async function keepAllBatch() {
  const st = state.batchReview; if (!st) return;
  for (let i = 0; i < st.items.length; i += 1) {
    const it = st.items[i];
    if (it.before && ['done', 'adopted', 'kept'].includes(it.status)) await keepBatchItem(i);
  }
  renderBatchReview();
}
async function batchReanalyzeAssets() { return openBatchReviewPanel(); }
async function reanalyzeAsset(a, opts = {}) {
  try {
    const mod = await import('../../library/analyze.mjs');
    const resolved = await getAssetImageUrl(a);
    const url = resolved.url;
    const image = await mod.loadImage(url);
    const res = await fetch(url); const buf = await res.arrayBuffer();
    const libMod = await import('../../library/api.mjs');
    const sha = await libMod.sha256Hex(buf);
    const fresh = mod.analyzeImage({ image, dataUrl: url, width: image.width, height: image.height, fileName: a.fileName, mime: a.mime, bytes: buf.byteLength, sha256: a.sha256 || sha, context: { sample: true } });
    const api = await initLibrary();
    const latest = await api.get(a.id); if (!latest) throw new Error('素材不存在');
    latest.L1 = fresh.L1; latest.L2 = fresh.L2; latest.L4 = fresh.L4; latest.tags = [...new Set([...(fresh.tags || []), ...(latest.tags || [])])].slice(0, 32); latest.palette = fresh.palette; latest.source = fresh.source; latest.modelVersion = fresh.modelVersion; latest.updatedAt = new Date().toISOString();
    await api.store.put(latest);
    try { resolved.cleanup(); } catch (e) {}
    await refreshLibraryAssets(); if (state.library.open) renderLibrary();
    if (!opts.silent) showToast('已重新分析（mock）');
    return latest;
  } catch (e) {
    if (opts.batch) throw e;
    showToast('重新分析失败：' + (e.message || e), true);
    return null;
  }
}
async function deleteLibraryAsset(a) {
  try {
    const api = await initLibrary();
    await api.delete(a.id);
    state.library.deleteConfirm = null; state.library.selectedId = null;
    state.assetLayerRefs.forEach((v, k) => { if (v.assetId === a.id) state.assetLayerRefs.delete(k); });
    if (state.aiReference && state.aiReference.id === a.id) clearAIReference();
    await refreshLibraryAssets(); await refreshLibraryPrefs(); renderLibrary();
    showToast('素材已删除');
  } catch (e) { showToast('删除失败：' + (e.message || e), true); }
}
function bindLibraryControls() {
  const btn = document.getElementById('btnLibrary'); if (btn) btn.onclick = () => { if (state.library.open) closeLibrarySheet(); else openLibrarySheet(); };
  const close = document.getElementById('libClose'); if (close) close.onclick = closeLibrarySheet;
  const backdrop = document.getElementById('libraryBackdrop'); if (backdrop) backdrop.onclick = closeLibrarySheet;
  const search = document.getElementById('libSearch');
  if (search) { let t = null; search.oninput = () => { clearTimeout(t); t = setTimeout(() => { state.library.query = search.value.trim(); renderLibrary(); }, 200); }; search.onkeydown = (e) => { if (e.key === 'Escape') { e.stopPropagation(); if (search.value) { search.value = ''; state.library.query = ''; renderLibrary(); } else closeLibrarySheet(); } }; }
  const sw = document.getElementById('libSearchClear'); if (sw) sw.onclick = () => { if (search) search.value = ''; state.library.query = ''; state.library.tag = null; renderLibrary(); };
  document.querySelectorAll('#libFilters .lib-chip').forEach((b) => b.onclick = () => { state.library.filter = b.dataset.filter; state.library.tag = null; renderLibrary(); });
  const imp = document.getElementById('libImportBtn'); if (imp) imp.onclick = () => document.getElementById('libFileInput').click();
  const batchBtn = document.getElementById('libBatchRead'); if (batchBtn) batchBtn.onclick = () => batchReanalyzeAssets();
  const brStart = document.getElementById('batchReviewStart'); if (brStart) brStart.onclick = () => startBatchReview();
  const brStop = document.getElementById('batchReviewStop'); if (brStop) brStop.onclick = () => { if (state.batchReview) { state.batchReview.cancelled = true; try { state.aiAbort && state.aiAbort.abort(); } catch (e) { /* ignore */ } } showToast('已请求停止剩余队列'); };
  const brAdoptAll = document.getElementById('batchReviewAdoptAll'); if (brAdoptAll) brAdoptAll.onclick = () => adoptAllBatch();
  const brKeepAll = document.getElementById('batchReviewKeepAll'); if (brKeepAll) brKeepAll.onclick = () => keepAllBatch();
  const fi = document.getElementById('libFileInput'); if (fi) fi.onchange = () => { if (fi.files && fi.files.length) libImportFiles(fi.files); fi.value = ''; };
  const sheet = LIB_SHEET();
  if (sheet) {
    sheet.addEventListener('dragover', (e) => { e.preventDefault(); document.getElementById('libDrop').hidden = false; });
    sheet.addEventListener('dragleave', (e) => { if (!sheet.contains(e.relatedTarget)) document.getElementById('libDrop').hidden = true; });
    sheet.addEventListener('drop', (e) => { e.preventDefault(); document.getElementById('libDrop').hidden = true; if (e.dataTransfer.files && e.dataTransfer.files.length) libImportFiles(e.dataTransfer.files); });
  }
  renderAIReferenceBar();
}

/* ---------------- 路演模式 Roadshow（6 拍 · 真实/预置分级 · 客户交付） ---------------- */
const RS_PROJECT_NAME = '《呼吸》· 短片概念图';
const RS_EDIT_PROMPT = '把画布中部的雾带改为清晨冷雾：更冷、更通透、有层次，晨光从右侧山口进入；保留远山轮廓与近水的手绘笔触和纸张纹理，构图不变，不要紫色、不要赛博朋克、不要文字或水印。';
const RS_BRIEF_LINE = '项目《呼吸》短片概念图：客户要求把山谷雾带改成清晨冷雾、保留近水手绘笔触；明早 10:00 前交 PNG + 证据包；上周已定冷灰蓝（保留）、否决赛博朋克紫。';
const RS_STEPS = [
  { id: 'brief', n: '01', pip: '档案', title: '客户 brief / 本地档案', hint: '先讲清楚交付：项目《呼吸》· 短片概念图；雾带改清晨冷雾、保留近水笔触；明早 10:00。顺手指出素材库里的演示剧本档案（预置样本与 L5 决策，非真实用户历史）。看完点右上 ✕ 关闭素材库（或点空白处），再进入下一拍。', budget: 30, target: '#btnLibrary', targetLabel: '素材库入口', exec: '打开档案' },
  { id: 'select', n: '02', pip: '框选', title: '框选雾带 + 打开 AI 对话', hint: '框住雾带（约 60% 宽 / 42% 高）：AI 只读这块裁切图；框外像素不会被发送，也不会被落层覆盖。', budget: 40, target: '#canvasWrap', targetLabel: '画布选区', exec: '框选雾带' },
  { id: 'observe', n: '03', pip: '观察', title: '让 AI 看看（真实视觉 / Mock 分级）', hint: '发送：选区裁切图 + 档案摘要（含 L5 决策 + 素材库记忆）。真实视觉基线 8.7–21.3s；没有 key 时走 Mock，并在面板标明「Mock 占位」。', budget: 60, target: '#popAI', targetLabel: 'AI 观察面板', exec: '让 AI 看看' },
  { id: 'decide', n: '04', pip: '写回', title: '确认 2 条 / 否决 1 条 → 记忆写回', hint: '每条观察都能确认或否决；决定写回 L5，并进入下一次生成/观察的上下文（不是假装记住）。', budget: 40, target: '#aiBody', targetLabel: '观察列表', exec: '写回决定' },
  { id: 'edit', n: '05', pip: '落层', title: '选方向 → 编辑 / 生成 → 落新图层', hint: '方向由演示剧本中的 L5 锁定：清晨冷雾（选定）/ 赛博朋克紫（否决），均为脚本代点、非真人决策。默认真实提交给 Qwen 编辑（实测约 12–25s）；真实调用失败或无 key 时显式降级为预置样本落层（历史样本文件，非本场调用、非用户历史），UI 与证据链分别标明来源。', budget: 90, target: '#canvasWrap', targetLabel: '新图层', exec: '真实编辑优先 · 失败降级预置样本' },
  { id: 'evidence', n: '06', pip: '证据', title: '导出证据包 → 第三方复核', hint: '证据包含哈希链、画布 PNG 字节 SHA-256、图层 SHA-256、AI 调用清单与 token/成本；包内本地复核 + 可下载 PNG 供 Get-FileHash 对照。', budget: 60, target: '#aiBody', targetLabel: '证据包', exec: '生成证据包' },
];
const ROADSHOW = {
  active: false, step: 0, busy: false, prepared: false, preparing: null, error: null,
  auto: false, autoTimer: null, // T120 自动演示状态
  startedAt: 0, stepStartedAt: 0, timer: null, log: [], done: {},
  savedRecords: null, savedProjectLabel: '', savedAi: null, realEnabled: false,
  manifest: null, sample: null, baseFile: null, lib: {}, libCount: 0,
  baseLayerId: null, noteLayerId: null, editLayerId: null,
  selection: null, appliedPreset: false, appliedReal: false,
  decisions: null, l5Ids: [], lastSampleRecord: null, lastRealRecord: null,
  evidence: null, verify: null, maskPolicy: null, hlTimer: null, lastL5Context: 0,
};

function roadshowFmt(ms) {
  const s = Math.max(0, Math.floor(Number(ms) / 1000));
  return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
}
function roadshowNow(text) {
  const el = document.getElementById('roadshowNow');
  if (el) el.textContent = text || '';
}
function roadshowLog(kind, text) {
  ROADSHOW.log.push({ at: Date.now(), kind: kind || 'info', text: String(text == null ? '' : text) });
  if (ROADSHOW.log.length > 30) ROADSHOW.log.shift();
  const host = document.getElementById('roadshowLog');
  if (!host) return;
  host.innerHTML = ROADSHOW.log.slice(-4).map((e) => '<div class="rs-log-row ' + escapeHtml(e.kind) + '"><span class="t">' + new Date(e.at).toLocaleTimeString('zh-CN', { hour12: false }) + '</span><span class="m">' + escapeHtml(e.text) + '</span></div>').join('');
}
function roadshowSelectionRect() {
  const W = engine ? engine.width : 1600, H = engine ? engine.height : 1600;
  return { x: Math.round(W * 0.18), y: Math.round(W * 0.22), width: Math.round(W * 0.6), height: Math.round(W * 0.42) };
}
/** importImageAsLayer 直接画到合成 canvas，但保留帧（presentSurface）不会自动刷新；
 *  下一次 presentFull / burst 会用旧保留帧覆盖，导致新图层“看不见”。这里强制重绘一次。 */
function roadshowPresent() {
  try {
    if (engine && engine.compositor) { engine.compositor.setLayers(engine.layers); engine.compositor.compositeAll(engine.store); }
    if (engine && typeof engine.presentFull === 'function') engine.presentFull();
  } catch (e) { /* ignore */ }
}
function roadshowHighlight(selector, label) {
  document.querySelectorAll('.rs-hl').forEach((el) => el.classList.remove('rs-hl'));
  const target = document.getElementById('roadshowTarget');
  if (target) target.textContent = label ? ('高亮 · ' + label) : '';
  const el = selector ? document.querySelector(selector) : null;
  if (!el) return;
  el.classList.add('rs-hl');
  clearTimeout(ROADSHOW.hlTimer);
  ROADSHOW.hlTimer = setTimeout(() => { try { el.classList.remove('rs-hl'); } catch (e) { /* ignore */ } }, 4200);
}
function roadshowStats() {
  const since = (ROADSHOW.startedAt || 0) - 1500;
  const l6 = (state.records || []).filter((r) => r && r.layer === 'L6' && Date.parse(r.created_at || '') >= since);
  const ai = l6.filter((r) => r.params && r.params.task);
  const real = ai.filter((r) => r.params && !r.params.mock).length;
  const mock = ai.length - real;
  const tokens = ai.reduce((n, r) => n + ((r.params && r.params.usage && r.params.usage.total_tokens) || (r.usage && r.usage.total_tokens) || 0), 0);
  const costItems = l6.filter((r) => r.cost_cny != null && r.params && (r.params.task || r.params.cached_sample || r.params.candidate_id));
  let cost = costItems.reduce((n, r) => n + Number(r.cost_cny || 0), 0);
  let costKnown = costItems.length > 0;
  // 真实文本调用按 token 估价（qwen3.8-max：输入 ¥12/M · 输出 ¥36/M，未计缓存折扣），让路演控制台不显示「—」
  for (const r of ai) {
    if (!r.params || r.params.mock) continue;
    const u = (r.params.usage) || r.usage || null;
    if (!u) continue;
    const inTok = Number(u.prompt_tokens || 0); const outTok = Number(u.completion_tokens || 0);
    if (!inTok && !outTok) continue;
    cost += (inTok * 12 + outTok * 36) / 1e6;
    costKnown = true;
  }
  return { calls: ai.length, real, mock, tokens, costKnown, cost };
}
function roadshowBadgeInfo() {
  if (ROADSHOW.appliedReal) return { label: '实时', cls: 'live', title: '本场第 5 拍已用真实模型编辑落层' };
  if (ROADSHOW.appliedPreset) return { label: '预置样本', cls: 'preset', title: '本场第 5 拍用预置样本（历史样本文件）落层；未调用模型、未计费，非用户真实历史' };
  if (!aiRealEligible()) return { label: 'Mock', cls: 'mock', title: '未启用真实调用：观察走本地 Mock 占位，第 5 拍使用预置样本' };
  return { label: '实时', cls: 'live', title: '真实模型已启用：' + aiProviderLabel() + ' / ' + aiRuntimeModel() + '（本场尚未调用）' };
}
function roadshowRenderBadge() {
  const b = roadshowBadgeInfo();
  const el = document.getElementById('roadshowBadge');
  if (el) { el.textContent = b.label; el.className = 'rs-badge ' + b.cls; el.title = b.title; }
  const meta = document.getElementById('roadshowMeta');
  if (meta) {
    const s = roadshowStats();
    meta.innerHTML = '<span>调用 <b>' + s.calls + '</b>（真实 ' + s.real + ' · Mock ' + s.mock + '）</span><span>成本 <b>' + (s.costKnown ? ('¥' + s.cost.toFixed(2)) : '—') + '</b></span>' + (s.tokens ? ('<span>' + s.tokens + ' tokens</span>') : '');
  }
}
function roadshowTick() {
  if (!ROADSHOW.active) return;
  const t = document.getElementById('roadshowTimer');
  if (t) t.textContent = roadshowFmt(Date.now() - ROADSHOW.startedAt);
  const sc = document.getElementById('roadshowStepClock');
  if (sc) sc.textContent = '本拍 ' + roadshowFmt(Date.now() - (ROADSHOW.stepStartedAt || ROADSHOW.startedAt));
  roadshowRenderBadge();
}
function roadshowStartTimer() {
  roadshowStopTimer();
  ROADSHOW.startedAt = Date.now();
  ROADSHOW.stepStartedAt = ROADSHOW.startedAt;
  ROADSHOW.timer = setInterval(roadshowTick, 1000);
  roadshowTick();
}
function roadshowStopTimer() { if (ROADSHOW.timer) { clearInterval(ROADSHOW.timer); ROADSHOW.timer = null; } }

/* ---- 真实调用开关：显式写入 localStorage，避免「自动开真实 + 每次确认」导致演示空转 ---- */
function roadshowEnableRealRuntime() {
  ROADSHOW.savedAi = {
    allowReal: aiRuntime.allowReal, requireConfirm: aiRuntime.requireConfirm, privacyMode: aiRuntime.privacyMode,
    preset: aiRuntime.preset, raw: (() => { try { return localStorage.getItem(AI_SETTINGS_KEY); } catch (e) { return null; } })(),
  };
  const cfg = aiRuntime.config || {};
  const keyed = !!(aiRuntime.hasKey || cfg.hasKey) && !!aiToken();
  if (keyed && cfg.hasKey) {
    const pp = presetFromConfig(cfg);
    if (pp && AI_PRESETS[pp]) aiRuntime.preset = pp;
  }
  aiRuntime.allowReal = keyed;
  aiRuntime.requireConfirm = false;
  aiRuntime.privacyMode = !keyed;
  try { saveAiLocalSettings(); } catch (e) { /* ignore */ }
  try { renderAiSettings(); } catch (e) { /* ignore */ }
  try { renderAiProviderBadge(); } catch (e) { /* ignore */ }
  ROADSHOW.realEnabled = aiRealEligible();
  return ROADSHOW.realEnabled;
}
function roadshowRestoreAiRuntime() {
  const saved = ROADSHOW.savedAi;
  if (!saved) return;
  try {
    if (saved.raw == null) localStorage.removeItem(AI_SETTINGS_KEY);
    else localStorage.setItem(AI_SETTINGS_KEY, saved.raw);
  } catch (e) { /* ignore */ }
  aiRuntime.allowReal = saved.allowReal;
  aiRuntime.requireConfirm = saved.requireConfirm;
  aiRuntime.privacyMode = saved.privacyMode;
  aiRuntime.preset = saved.preset;
  try { renderAiSettings(); } catch (e) { /* ignore */ }
  try { renderAiProviderBadge(); } catch (e) { /* ignore */ }
}

/* ---- 素材读取（客户端 fetch，不依赖服务端回放） ---- */
function roadshowAssetUrl(rel) {
  const clean = String(rel || '').replace(/^\.?\//, '');
  return new URL('../' + clean, import.meta.url).href;
}
async function roadshowPeekAssets() {
  try {
    const res = await fetch(roadshowAssetUrl('demo/assets.json'), { cache: 'no-store' });
    if (!res.ok) throw new Error('assets.json HTTP ' + res.status);
    const data = await res.json();
    const assets = (data && data.assets) || {};
    const edit = assets.edit2 || assets.edit || null;
    if (!assets.base) throw new Error('assets.json 缺少 base');
    return { ok: true, count: 1 + (edit ? 1 : 0) + 1, editSha: edit && edit.sha256, editFile: edit && edit.file, editModel: edit && edit.model };
  } catch (e) {
    return { ok: false, error: (e && e.message) || String(e) };
  }
}
async function roadshowFetchImage(spec) {
  const res = await fetch(roadshowAssetUrl(spec.file), { cache: 'no-store' });
  if (!res.ok) throw new Error('素材 ' + spec.file + ' 读取失败 HTTP ' + res.status);
  const buf = await res.arrayBuffer();
  const sha = await sha256Hex(new Uint8Array(buf));
  const mime = /\.(jpe?g)$/i.test(spec.file) ? 'image/jpeg' : /\.webp$/i.test(spec.file) ? 'image/webp' : 'image/png';
  const dataUrl = await blobToDataUrl(new Blob([buf], { type: mime }));
  return { dataUrl, sha256: sha, bytes: buf.byteLength, meta: spec };
}
async function roadshowLoadManifest() {
  let data = null;
  try {
    const res = await fetch(roadshowAssetUrl('demo/assets.json'), { cache: 'no-store' });
    if (res.ok) data = await res.json();
  } catch (e) { console.warn('[roadshow] assets.json 读取失败', e); }
  const assets = (data && data.assets) || {};
  const base = assets.base || { file: 'demo/roadshow-base.png', sha256: null, model: 'qwen-image-3.0', generated_at: null, fallback: true };
  const edit = assets.edit2 || assets.edit || { file: 'demo/roadshow-edit2.png', sha256: null, model: 'qwen-image-3.0-pro', generated_at: null, fallback: true };
  return { assets, base, edit, raw: data };
}
/** 真实编辑样本未就绪时：本地合成一个明确标注的「占位」样本（不冒充真实结果） */
async function roadshowFallbackSample(baseFile) {
  try {
    const img = new Image(); img.src = baseFile.dataUrl; await img.decode();
    const W = img.naturalWidth || 2048, H = img.naturalHeight || 2048;
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const g = c.getContext('2d');
    g.filter = 'saturate(0.84) hue-rotate(-8deg) brightness(1.02)';
    g.drawImage(img, 0, 0, W, H);
    g.filter = 'none';
    const band = g.createLinearGradient(0, H * 0.16, 0, H * 0.68);
    band.addColorStop(0, 'rgba(120,160,190,0)');
    band.addColorStop(0.32, 'rgba(158,198,222,.34)');
    band.addColorStop(0.66, 'rgba(120,160,190,.2)');
    band.addColorStop(1, 'rgba(120,160,190,0)');
    g.fillStyle = band; g.fillRect(0, H * 0.14, W, H * 0.58);
    const dataUrl = c.toDataURL('image/png');
    const bytes = roadshowDataUrlBytes(dataUrl);
    const sha = await sha256Hex(bytes);
    return { dataUrl, sha256: sha, bytes: bytes.byteLength, fileName: '冷雾实验-本地合成占位.png', meta: { file: 'demo/roadshow-edit2.png', model: 'local-composite-placeholder', generated_at: iso(), fallback: true, prompt: '本地合成占位：冷雾带 + 降饱和（真实编辑样本未就绪，非真实模型结果）' } };
  } catch (e) { console.warn('[roadshow] fallback sample failed', e); return null; }
}

/* ---- 项目准备：1600² 画布 / 成稿图层 / 批注文字层 / 素材库 / 演示剧本 L6 / 真实选区 ---- */
function roadshowDataUrlBytes(dataUrl) {
  const s = String(dataUrl || '');
  const i = s.indexOf(',');
  const b64 = i >= 0 ? s.slice(i + 1) : s;
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i2 = 0; i2 < bin.length; i2 += 1) out[i2] = bin.charCodeAt(i2);
  return out;
}
/** 演示剧本时间：构造「昨天 hh:mm」供路演叙事使用。
 *  不是真实事件时间；所有使用它的记录必须带 timestamp_kind:'scripted_demo' + synthetic:true，
 *  且由 buildEvidence() 排除出正式证据链。 */
function roadshowYesterday(h, m) {
  const y = new Date(Date.now() - 24 * 3600 * 1000);
  return new Date(y.getFullYear(), y.getMonth(), y.getDate(), h, m, 5).toISOString();
}
async function roadshowAddNoteLayer() {
  const text = '客户批注：冷雾 / 保留笔触';
  const fontSize = 46;
  const font = '600 ' + fontSize + 'px "Microsoft YaHei", "Segoe UI", sans-serif';
  const c = document.createElement('canvas');
  const g0 = c.getContext('2d');
  g0.font = font;
  const lines = [text];
  let maxW = 0;
  for (const ln of lines) maxW = Math.max(maxW, g0.measureText(ln).width);
  const padX = 30, padY = 22;
  c.width = Math.max(1, Math.ceil(maxW + padX * 2));
  c.height = Math.max(1, Math.ceil(lines.length * fontSize * 1.3 + padY * 2));
  const g = c.getContext('2d');
  g.clearRect(0, 0, c.width, c.height);
  g.fillStyle = 'rgba(10,20,34,.55)';
  g.fillRect(0, 0, c.width, c.height);
  g.strokeStyle = 'rgba(147,197,253,.55)';
  g.lineWidth = 2;
  g.setLineDash([10, 7]);
  g.strokeRect(1, 1, c.width - 2, c.height - 2);
  g.setLineDash([]);
  g.font = font; g.fillStyle = '#eaf2ff'; g.textBaseline = 'top';
  lines.forEach((ln, i) => g.fillText(ln, padX, padY + i * fontSize * 1.3));
  const x = 90, y = 104;
  const layer = await importImageAsLayer(c.toDataURL('image/png'), '文字 · 客户批注：冷雾 / 保留笔触', { x, y, width: c.width, height: c.height });
  try {
    const info = { layerId: layer.id, text, content: text, fontSize, color: '#eaf2ff', fontFamily: 'Microsoft YaHei', x, y, width: c.width, height: c.height, updatedAt: iso() };
    state.textLayers.set(layer.id, info);
    engine.setLayerInfo(layer.id, { kind: 'text', text: info });
  } catch (e) { /* ignore */ }
  return layer.id;
}
async function roadshowCurateBase(api, asset, meta, baseFile) {
  const tags = ['山谷', '雾', '冷灰蓝', '水彩', '手绘笔触', '项目原图', '路演预置'];
  const L1 = {
    layer: 'L1', source: 'inferred', confidence: 0.7, anchor: { type: 'whole', value: null },
    summary: '清晨北方山谷：远山 / 雾带 / 近水三层空间；冷灰蓝低饱和，纸纹与手绘笔触可见。',
    subject: ['山', '雾', '水'], medium: { kind: 'watercolor', detail: '水彩 + 水墨，保留手绘笔触与纸张纹理' },
    palette: [{ hex: '#5f7789' }, { hex: '#768e9f' }, { hex: '#c3d2d9' }, { hex: '#dfe8ea' }],
    mood: ['安静', '克制'], modelVersion: (meta && meta.model) || 'qwen-image-3.0',
  };
  const L2 = [
    { id: 'L2-roadshow-far', layer: 'L2', label: '远山', source: 'inferred', confidence: 0.7, bbox: [140, 300, 1320, 320], importance: 0.7, anchor: { type: 'bbox', value: [140, 300, 1320, 320] } },
    { id: 'L2-roadshow-fog', layer: 'L2', label: '雾带', source: 'inferred', confidence: 0.76, bbox: [288, 352, 960, 672], importance: 0.92, anchor: { type: 'bbox', value: [288, 352, 960, 672] } },
    { id: 'L2-roadshow-water', layer: 'L2', label: '近水', source: 'inferred', confidence: 0.66, bbox: [260, 1180, 1080, 320], importance: 0.68, anchor: { type: 'bbox', value: [260, 1180, 1080, 320] } },
  ];
  const L4 = [
    { id: 'L4-roadshow-base-1', layer: 'L4', kind: 'observation', source: 'inferred', author: 'ai', confidence: 0.78, text: '雾带把远山与近水分成三层，视线先落在雾带缺口。', anchor: { type: 'bbox', value: [288, 352, 960, 672] }, evidenceRefs: ['L2-roadshow-fog'], modelVersion: (meta && meta.model) || 'qwen-image-3.0' },
    { id: 'L4-roadshow-base-2', layer: 'L4', kind: 'observation', source: 'inferred', author: 'ai', confidence: 0.72, text: '主色是冷灰蓝，画面最高明度在雾带。', anchor: { type: 'whole', value: null }, evidenceRefs: ['L1'], modelVersion: (meta && meta.model) || 'qwen-image-3.0' },
    { id: 'L4-roadshow-base-3', layer: 'L4', kind: 'observation', source: 'inferred', author: 'ai', confidence: 0.7, text: '近水保留手绘笔触与纸纹颗粒，是客户要保留的部分。', anchor: { type: 'bbox', value: [260, 1180, 1080, 320] }, evidenceRefs: ['L2-roadshow-water'], modelVersion: (meta && meta.model) || 'qwen-image-3.0' },
  ];
  const nowIso = iso();
  asset.fileName = 'roadshow-base.png';
  asset.tags = [...new Set([...tags, ...(asset.tags || [])])].slice(0, 32);
  asset.L1 = { ...(asset.L1 || {}), ...L1, anchor: { type: 'whole', value: null } };
  asset.L2 = L2; asset.L4 = L4;
  asset.L5 = asset.L5 || [];
  asset.source = [...new Set(['observed', 'inferred', ...(asset.L5.length ? ['user-confirmed'] : [])])];
  asset.modelVersion = (meta && meta.model) || 'qwen-image-3.0';
  asset.provenance = { source: 'roadshow-preset', model: (meta && meta.model) || 'qwen-image-3.0', prompt: (meta && meta.prompt) || null, generated_at: (meta && meta.generated_at) || null, sha256_source: (baseFile && baseFile.sha256) || (meta && meta.sha256) || null };
  asset.updatedAt = nowIso;
  await api.store.put(asset);
  return asset;
}
async function roadshowCurateEdit(api, asset, sample) {
  const tags = ['冷雾', '冷灰蓝', '清晨', '水彩', '手绘笔触', '交付候选', '路演预置'];
  const model = (sample && sample.meta && sample.meta.model) || 'qwen-image-3.0-pro';
  const L1 = {
    layer: 'L1', source: 'inferred', confidence: 0.74, anchor: { type: 'whole', value: null },
    summary: '同一山谷的冷雾编辑版：雾更冷更通透、晨光从右侧山口进入；构图与原图一致，近水笔触保留。',
    subject: ['山', '雾', '水'], medium: { kind: 'watercolor', detail: '水彩 + 水墨，保留手绘笔触与纸张纹理' },
    palette: [{ hex: '#4b6478' }, { hex: '#7f97ab' }, { hex: '#b8ccd8' }, { hex: '#e8eef2' }],
    mood: ['清晨', '安静', '通透'], modelVersion: model,
  };
  const L2 = [
    { id: 'L2-roadshow-edit-fog', layer: 'L2', label: '冷雾带', source: 'inferred', confidence: 0.8, bbox: [260, 330, 1010, 700], importance: 0.94, anchor: { type: 'bbox', value: [260, 330, 1010, 700] } },
    { id: 'L2-roadshow-edit-light', layer: 'L2', label: '右侧晨光', source: 'inferred', confidence: 0.72, bbox: [980, 240, 560, 640], importance: 0.7, anchor: { type: 'bbox', value: [980, 240, 560, 640] } },
    { id: 'L2-roadshow-edit-water', layer: 'L2', label: '近水笔触', source: 'inferred', confidence: 0.74, bbox: [260, 1180, 1080, 320], importance: 0.76, anchor: { type: 'bbox', value: [260, 1180, 1080, 320] } },
  ];
  const L4 = [
    { id: 'L4-roadshow-edit-1', layer: 'L4', kind: 'observation', source: 'inferred', author: 'ai', confidence: 0.82, text: '冷雾带更冷、更通透，与远山形成清晰层次；客户选定冷灰蓝。', anchor: { type: 'bbox', value: [260, 330, 1010, 700] }, evidenceRefs: ['L2-roadshow-edit-fog'], modelVersion: model },
    { id: 'L4-roadshow-edit-2', layer: 'L4', kind: 'observation', source: 'inferred', author: 'ai', confidence: 0.73, text: '紫 / 赛博朋克方向会破坏低饱和纸感，客户已否决。', anchor: { type: 'whole', value: null }, evidenceRefs: ['L1'], modelVersion: model },
    { id: 'L4-roadshow-edit-3', layer: 'L4', kind: 'observation', source: 'inferred', author: 'ai', confidence: 0.76, text: '近水手绘笔触与纸纹保留，晨光从右侧山口进入。', anchor: { type: 'bbox', value: [260, 1180, 1080, 320] }, evidenceRefs: ['L2-roadshow-edit-water'], modelVersion: model },
  ];
  // 演示剧本时间：不是真实事件时间。L5 的 source 保持 'user-confirmed' 以维持
  // 档案回指/确认态 UI 的数据契约，但用 synthetic + timestamp_kind 明确它是剧本，不是真人决策。
  const at = roadshowYesterday(15, 24);
  const L5 = [
    { id: 'L5-roadshow-preset-keep', layer: 'L5', kind: 'confirm', targetId: 'L4-roadshow-edit-1', tags: ['冷灰蓝', '冷雾', '保留近水笔触'], at, source: 'user-confirmed', created_by: 'demo_preset', session_id: 'demo-script-2026-11-06', preset: true, synthetic: true, timestamp_kind: 'scripted_demo', note: '演示剧本（非真实客户评审）· 假设的昨日评审：选定冷灰蓝、保留近水笔触' },
    { id: 'L5-roadshow-preset-reject', layer: 'L5', kind: 'reject', targetId: 'L4-roadshow-edit-2', tags: ['赛博朋克紫', '否决'], at, source: 'user-confirmed', created_by: 'demo_preset', session_id: 'demo-script-2026-11-06', preset: true, synthetic: true, timestamp_kind: 'scripted_demo', note: '演示剧本（非真实客户评审）· 假设的昨日评审：否决赛博朋克紫方向' },
    { id: 'L5-roadshow-preset-use', layer: 'L5', kind: 'use', targetId: 'L2-roadshow-edit-fog', tags: ['交付候选', '冷雾实验'], at, source: 'user-confirmed', created_by: 'demo_preset', session_id: 'demo-script-2026-11-06', preset: true, synthetic: true, timestamp_kind: 'scripted_demo', note: '演示剧本（非真实客户评审）· 冷雾实验被选为交付候选' },
  ];
  asset.fileName = String((sample && sample.meta && (sample.meta.file || '').split('/').pop()) || 'roadshow-edit2.png');
  asset.tags = [...new Set([...tags, ...(asset.tags || [])])].slice(0, 32);
  asset.L1 = { ...(asset.L1 || {}), ...L1, anchor: { type: 'whole', value: null } };
  asset.L2 = L2; asset.L4 = L4; asset.L5 = L5;
  asset.source = ['observed', 'inferred', 'user-confirmed'];
  asset.modelVersion = model;
  asset.provenance = { source: 'roadshow-preset-edit', model, prompt: (sample && sample.meta && sample.meta.prompt) || null, generated_at: (sample && sample.meta && sample.meta.generated_at) || null, sha256: (sample && sample.sha256) || (sample && sample.meta && sample.meta.sha256) || null, source_sha256: (sample && sample.meta && sample.meta.source_sha256) || null, request_id: (sample && sample.meta && sample.meta.request_id) || null, preset_sample: true };
  asset.updatedAt = iso();
  await api.store.put(asset);
  return asset;
}
async function roadshowSeedLibrary(meta, baseFile, sample) {
  const api = await initLibrary();
  let list = await api.list();
  const importOne = async (name, dataUrl, model) => {
    const r = await api.importDataUrls([{ name, dataUrl, mime: 'image/png' }], { context: { source: 'roadshow-preset', model } });
    if (r.imported && r.imported[0]) return r.imported[0];
    if (r.duplicates && r.duplicates.length) return await api.get(r.duplicates[0].id);
    throw new Error('素材导入失败：' + ((r.errors && r.errors[0] && r.errors[0].error) || name));
  };
  let baseAsset = list.find((a) => a.fileName === 'roadshow-base.png') || (meta.base.sha256 ? list.find((a) => a.sha256 === meta.base.sha256) : null);
  if (!baseAsset) baseAsset = await importOne('roadshow-base.png', baseFile.dataUrl, meta.base.model);
  baseAsset = await roadshowCurateBase(api, baseAsset, meta.base, baseFile);
  let editAsset = sample ? (list.find((a) => a.sha256 === sample.sha256) || null) : null;
  if (!editAsset && sample) editAsset = await importOne(sample.fileName || 'roadshow-edit2.png', sample.dataUrl, sample.meta && sample.meta.model);
  if (editAsset) editAsset = await roadshowCurateEdit(api, editAsset, sample);
  let paperAsset = list.find((a) => /水彩纸/.test(a.fileName || ''));
  if (!paperAsset) {
    const art = sampleArtC();
    const r = await api.importDataUrls([{ name: art.name, dataUrl: art.dataUrl, mime: art.mime }]);
    paperAsset = (r.imported && r.imported[0]) || (r.duplicates && r.duplicates.length ? await api.get(r.duplicates[0].id) : null);
    if (paperAsset) { try { await curateSampleAsset(api, paperAsset); } catch (e) { console.warn('[roadshow] curate paper failed', e); } }
  }
  await refreshLibraryAssets();
  await refreshLibraryPrefs().catch(() => {});
  const all = state.library.assets || [];
  return { base: baseAsset, edit: editAsset, paper: paperAsset, count: all.length };
}
function roadshowSeedRecords(meta, lib, sample) {
  const existing = (state.records || []).filter((r) => r && r.layer === 'L6' && r.params && r.params.preset_sample);
  if (existing.length >= 6) return existing.length;
  const chat = { provider: 'qwen', model: 'qwen3.8-max' };
  const img = { provider: 'qwen', model: (meta.base && meta.base.model) || 'qwen-image-3.0' };
  const editModel = (sample && sample.meta && sample.meta.model) || 'qwen-image-3.0-pro';
  const edit = { provider: 'qwen', model: editModel };
  const baseId = (lib && lib.base && lib.base.id) || 'asset-roadshow-base';
  const editId = (lib && lib.edit && lib.edit.id) || 'asset-roadshow-edit';
  const editSha = (sample && sample.sha256) || (sample && sample.meta && sample.meta.sha256) || (meta.edit && meta.edit.sha256) || '';
  const baseSha = (meta.base && meta.base.sha256) || '';
  const common = { asset_id: baseId, mode: 'collab', ai_role: 'assistant', schema_version: '0.2.0' };
  const A = (k) => [{ type: k, value: true }, { type: 'no_training_use', value: true }];
  const seeds = [
    { id: 'L6-preset-observe', kind: 'critique', created_at: roadshowYesterday(14, 12), model: { ...chat }, params: { preset_sample: true, action: 'observe', asset_id: editId, scope: '雾带', observations: 3 }, input_refs: [], assertions: A('preset_sample'), source: 'inferred', author: 'ai', note: '演示剧本（预置样本 · 脚本时间）· 14:12 观察：雾带三层 / 冷灰蓝 / 近水笔触（预置档案，不是本次会话）' },
    { id: 'L6-preset-directions', kind: 'critique', created_at: roadshowYesterday(14, 31), model: { ...chat }, params: { preset_sample: true, action: 'directions', count: 2, directions: ['清晨冷雾', '赛博朋克紫'], l5_ids: ['L5-roadshow-preset-keep', 'L5-roadshow-preset-reject'] }, input_refs: [], assertions: A('preset_sample'), source: 'inferred', author: 'ai', note: '演示剧本（预置样本 · 脚本时间）· 14:31 两个方向：清晨冷雾 / 赛博朋克紫（后者被客户否决）' },
    { id: 'L6-preset-cand-purple', kind: 'generation', created_at: roadshowYesterday(14, 49), model: { ...img }, output_asset_id: 'asset-preset-candidate-purple', cost_cny: 0, credits: 0, historical_cost_cny: 0.18, params: { preset_sample: true, direction: '赛博朋克紫', rejected: true, l5_ids: ['L5-roadshow-preset-reject'], note: '样本未落盘（被否决）' }, input_refs: [], assertions: A('preset_sample'), source: 'inferred', author: 'ai', note: '演示剧本（预置样本 · 脚本时间）· 14:49 候选 A：赛博朋克紫（客户否决；仅存档，不落画布；历史成本不計入本场）' },
    { id: 'L6-preset-cand-cool', kind: 'generation', created_at: roadshowYesterday(15, 2), model: { ...edit }, output_asset_id: editId, cost_cny: 0, credits: 0, historical_cost_cny: 0.52, params: { preset_sample: true, direction: '清晨冷雾', selected: true, cached_sample: true, source_sha256: editSha, output_sha256: editSha, l5_ids: ['L5-roadshow-preset-keep'] }, input_refs: [], assertions: A('preset_sample'), source: 'inferred', author: 'ai', note: '演示剧本（预置样本 · 脚本时间）· 15:02 冷雾编辑（客户选定；文件 ' + String((sample && sample.meta && sample.meta.file) || 'demo/roadshow-edit2.png') + ' · sha256 ' + editSha.slice(0, 12) + '…；历史成本不計入本场）' },
    { id: 'L6-preset-export', kind: 'export', created_at: roadshowYesterday(15, 10), model: { ...edit }, params: { preset_sample: true, action: 'export', file: 'roadshow-edit2.png', sha256: editSha, format: 'png', purpose: '邮件沟通' }, input_refs: [], assertions: A('preset_sample'), ai_role: null, source: 'observed', author: 'user', note: '演示剧本（预置样本 · 脚本时间）· 15:10 导出冷雾版 PNG（用于邮件沟通）' },
    { id: 'L6-preset-import', kind: 'import', created_at: roadshowYesterday(15, 16), model: { ...img }, params: { preset_sample: true, action: 'import', file: 'roadshow-base.png', sha256: baseSha, width: 2048, height: 2048 }, input_refs: [], assertions: A('preset_sample'), ai_role: null, source: 'observed', author: 'user', note: '演示剧本（预置样本 · 脚本时间）· 15:16 成稿导入本地画布（原图 sha256 ' + baseSha.slice(0, 12) + '…）' },
    { id: 'L6-preset-client-note', kind: 'reference_used', created_at: roadshowYesterday(15, 24), model: { ...chat }, params: { preset_sample: true, action: 'client_note', asset_id: editId, l5_ids: ['L5-roadshow-preset-keep', 'L5-roadshow-preset-reject'], decision: '冷灰蓝（保留）· 赛博朋克紫（否决）' }, input_refs: [], assertions: A('preset_sample'), source: 'inferred', author: 'ai', note: '演示剧本（预置样本 · 脚本时间）· 15:24 客户批注：冷雾 / 保留笔触；L5 记忆：选定冷灰蓝、否决赛博朋克紫' },
  ];
  let added = 0;
  for (const r of seeds) {
    if (state.records.some((x) => x.id === r.id)) continue;
    // P0-2：演示剧本事件统一打合成标记。source/author 必须落在档案枚举内
    // （observed|inferred|user-confirmed / ai|user|ai-suggested-user-accepted），
    // 因此用 'inferred' + 'ai' 表达「系统推断」而非冒充用户观察/用户操作，
    // 再靠 synthetic / timestamp_kind / decision_source 明确这是剧本。
    const rec = baseRecord('L6', {
      ...common, ...r,
      anchor: { type: 'whole', value: null },
      source: 'inferred',
      author: 'ai',
      synthetic: true,
      timestamp_kind: 'scripted_demo',
      decision_source: 'roadshow_script',
      model: { provider: 'demo', model: 'scripted-preset', source_model: (r.model && r.model.model) || null },
      model_disclaimer: '模型 / 成本 / 时间均为演示剧本数值，非本次会话的真实调用',
      note: '【演示剧本 · 非真实事件】' + String(r.note || ''),
      params: { ...(r.params || {}), preset_sample: true, synthetic: true, scripted: true },
    });
    if (rec.historical_cost_cny != null) { rec.scripted_cost_cny = rec.historical_cost_cny; delete rec.historical_cost_cny; }
    if (addRecord(rec)) added += 1;
  }
  return added;
}
function roadshowApplyRealSelection(notify) {
  const sel = roadshowSelectionRect();
  ROADSHOW.selection = sel;
  state.feather = 0;
  try { setTool('select'); } catch (e) { /* ignore */ }
  if (selectionManager) {
    try { selectionManager.setFeather(0); selectionManager.rect(sel.x, sel.y, sel.x + sel.width, sel.y + sel.height, 'replace', 0); } catch (e) { console.warn('[roadshow] 真实选区建立失败', e); }
  }
  state.selection = sel;
  try { drawSelection(); } catch (e) { /* ignore */ }
  try { updateToolOptions(); } catch (e) { /* ignore */ }
  const has = !!(engine && typeof engine.hasSelection === 'function' && engine.hasSelection());
  if (notify) showToast(has ? '已建立真实选区：AI 落层会按选区裁切，框外像素不变' : '选区已设置，但引擎 mask 未写入（可点「重设雾带选区」）', !has);
  return { selection: sel, engineHasSelection: has };
}
async function roadshowPrepare() {
  if (ROADSHOW.prepared) return true;
  if (ROADSHOW.preparing) return ROADSHOW.preparing;
  ROADSHOW.preparing = (async () => {
    roadshowNow('正在载入预置项目…');
    await initLibrary();
    // 1) 清空 + 1600×1600
    await wipeCanvas();
    try { await engine.resizeCanvas(1600, 1600, { offsetX: 0, offsetY: 0 }); } catch (e) { throw new Error('画布 resize 失败：' + (e.message || e)); }
    try { if (selectionManager && selectionManager.resize) selectionManager.resize(1600, 1600); } catch (e) { /* ignore */ }
    try { applyDocCanvasSizeUI(); } catch (e) { /* ignore */ }
    try { fitView(); } catch (e) { /* ignore */ }
    // 2) 素材清单 + 原图
    const meta = await roadshowLoadManifest();
    ROADSHOW.manifest = meta;
    const baseFile = await roadshowFetchImage(meta.base);
    ROADSHOW.baseFile = baseFile;
    if (meta.base.sha256 && baseFile.sha256 !== meta.base.sha256) roadshowLog('warn', '原图 sha256 与 assets.json 不一致（仍使用本地文件）');
    const baseLayer = await importImageAsLayer(baseFile.dataUrl, '成稿 · 山谷', { x: 0, y: 0, width: 1600, height: 1600 });
    ROADSHOW.baseLayerId = baseLayer.id;
    roadshowPresent();
    // 3) 批注文字层
    ROADSHOW.noteLayerId = await roadshowAddNoteLayer();
    roadshowPresent();
    // 4) 预置样本（编辑 2 → 编辑 1；失败则明确降级）
    let sample = null;
    const tryFiles = [];
    if (meta.assets && meta.assets.edit2) tryFiles.push(meta.assets.edit2);
    if (meta.assets && meta.assets.edit) tryFiles.push(meta.assets.edit);
    if (!tryFiles.length) tryFiles.push(meta.edit);
    for (const spec of tryFiles) {
      try { sample = await roadshowFetchImage(spec); sample.fileName = String(spec.file || '').split('/').pop(); break; } catch (e) { roadshowLog('warn', '预置样本读取失败：' + (spec && spec.file) + '（' + (e.message || e) + '）'); }
    }
    if (!sample && baseFile) {
      sample = await roadshowFallbackSample(baseFile);
      if (sample) roadshowLog('warn', '真实编辑样本未就绪：已用「本地合成占位」并在界面标明（不冒充真实结果）');
    }
    ROADSHOW.sample = sample;
    if (sample) roadshowLog(sample.meta && sample.meta.fallback ? 'warn' : 'ok', '预置样本已载入：' + sample.fileName + ' · sha256 ' + sample.sha256.slice(0, 12) + '…');
    else roadshowLog('err', '预置样本缺失：第 5 拍将只能真实提交');
    // 5) 素材库 + 昨天档案
    const lib = await roadshowSeedLibrary(meta, baseFile, sample);
    ROADSHOW.lib = lib;
    ROADSHOW.libCount = lib.count || 0;
    const seeded = roadshowSeedRecords(meta, lib, sample);
    // 6) 新画布的 L0（真实文件 sha256，不伪造）
    if (!state.records.some((r) => r.id === 'L0-roadshow-base')) {
      addRecord(baseRecord('L0', {
        id: 'L0-roadshow-base', asset_id: (lib.base && lib.base.id) || 'asset-roadshow-base',
        anchor: { type: 'whole', value: null }, source: 'observed', author: 'user', ai_role: null,
        file_path: 'demo/roadshow-base.png', sha256: baseFile.sha256, format: 'png', width: 2048, height: 2048, color_space: 'sRGB', imported_at: iso(),
        consent: { allow_training: false, allow_ai_processing: true, allow_display: true },
        note: '路演预置项目：成稿 · 山谷（本地素材，sha256 已核对）',
      }));
    }
    // 7) 真实选区
    const selInfo = roadshowApplyRealSelection(false);
    // 8) 收尾
    try { fitView(); } catch (e) { /* ignore */ }
    try { hideQuickStart(false); } catch (e) { /* ignore */ }
    try { renderAll(); } catch (e) { /* ignore */ }
    try { renderLayers(); } catch (e) { /* ignore */ }
    try { renderAIReferenceBar && renderAIReferenceBar(); } catch (e) { /* ignore */ }
    try { scheduleProjectAutosave(); } catch (e) { /* ignore */ }
    ROADSHOW.prepared = true;
    roadshowLog('ok', '预置项目就绪：1600×1600 · 成稿 · 山谷 · 素材 ' + ROADSHOW.libCount + ' 张 · 演示剧本 L6 ' + seeded + ' 条（synthetic，不进正式证据链） · 真实选区 mask=' + selInfo.engineHasSelection);
    roadshowNow('');
    return true;
  })().catch((e) => {
    ROADSHOW.error = (e && (e.message || String(e))) || '未知错误';
    roadshowLog('err', '预置项目载入失败：' + ROADSHOW.error);
    showToast('路演预置失败：' + ROADSHOW.error, true);
    roadshowNow('预置载入失败：' + ROADSHOW.error + '（可退出后重试）');
    return false;
  }).finally(() => { ROADSHOW.preparing = null; });
  return ROADSHOW.preparing;
}

/* ---- 第 1~6 拍执行 ---- */
async function roadshowOpenLibrary() {
  await openLibrarySheet();
  const edit = ROADSHOW.lib && ROADSHOW.lib.edit;
  if (edit) { try { selectLibraryAsset(edit.id); } catch (e) { /* ignore */ } }
  try { renderLibrary(); } catch (e) { /* ignore */ }
  // 演示档案是剧本，不宣称「昨天真实编辑」；降级为本地合成占位时同样不冒充真实模型结果。
  roadshowHighlight('#libDetail', '演示剧本 · L5 决策（预置样本）');
  roadshowLog('ok', '素材库已打开：演示剧本档案（预置样本 + L5 决策，非真实用户历史；若样本降级则为本地合成占位）');
}
async function rsStepBrief() {
  const ok = await roadshowPrepare();
  if (!ok) return false;
  await roadshowOpenLibrary();
  return true;
}
async function rsStepSelect() {
  const ok = await roadshowPrepare();
  if (!ok) return false;
  try { closeLibrarySheet(); } catch (e) { /* ignore */ }
  state.aiReference = null;
  try { renderAIReferenceBar && renderAIReferenceBar(); } catch (e) { /* ignore */ }
  const info = roadshowApplyRealSelection(true);
  try { openPopover('popAI'); switchAiTab('obs'); renderAIPanel(); } catch (e) { /* ignore */ }
  try { fitView(); } catch (e) { /* ignore */ }
  roadshowHighlight('#canvasWrap', '画布选区（真实 mask）');
  setTimeout(() => roadshowHighlight('#popAI', 'AI 对话'), 350);
  roadshowLog('ok', '真实选区 ' + Math.round(info.selection.width) + '×' + Math.round(info.selection.height) + ' · engineHasSelection=' + info.engineHasSelection);
  try { scheduleProjectAutosave(); } catch (e) { /* ignore */ }
  return info.engineHasSelection;
}
async function rsStepObserve() {
  const ok = await roadshowPrepare();
  if (!ok) return false;
  try { closeLibrarySheet(); } catch (e) { /* ignore */ }
  try { openPopover('popAI'); switchAiTab('obs'); } catch (e) { /* ignore */ }
  try { renderAIPanel(); } catch (e) { /* ignore */ }
  if (state.tool !== 'select') { try { setTool('select'); } catch (e) { /* ignore */ } }
  ROADSHOW.decisions = null;
  const real = aiRealEligible();
  const res = await roadshowBusy(real ? 'AI 正在看…（真实视觉 · 实测约 3–15s）' : 'AI 正在看…（Mock 占位 · 不联网）', () => runAnalyze(), { timeoutMs: 180000 });
  if (!res) {
    roadshowLog('warn', '真实视觉失败/超时：可点「用 Mock 重看一次」降级；第 5 拍仍会先尝试真实编辑，失败再显式降级预置样本');
    roadshowNow('真实视觉调用失败或超时：没有静默降级。可点下方「用 Mock 重看一次」；第 5 拍会先尝试真实编辑，失败才显式降级为预置样本。');
    return false;
  }
  const meta = state.aiLastCall || {};
  const lastL6 = (state.records || []).filter((r) => r.layer === 'L6' && r.params && r.params.task === 'analyze').slice(-1)[0];
  const l5n = lastL6 && lastL6.params && Array.isArray(lastL6.params.l5_refs) ? lastL6.params.l5_refs.length : 0;
  ROADSHOW.lastL5Context = l5n;
  roadshowLog('ok', 'AI 观察 ' + ((res.observations || []).length) + ' 条 · ' + (meta.mock ? 'Mock' : '真实') + ' · ' + (meta.latencyMs || 0) + 'ms · L5 上下文 ' + l5n + ' 条');
  roadshowHighlight('#aiBody', '观察列表（可确认 / 否决）');
  return true;
}
async function roadshowMockObserve() {
  const saved = { allowReal: aiRuntime.allowReal, privacyMode: aiRuntime.privacyMode, requireConfirm: aiRuntime.requireConfirm };
  aiRuntime.allowReal = false; aiRuntime.privacyMode = true; aiRuntime.requireConfirm = false;
  try { try { renderAiProviderBadge(); } catch (e) { /* ignore */ } return await rsStepObserve(); }
  finally { Object.assign(aiRuntime, saved); try { renderAiProviderBadge(); } catch (e) { /* ignore */ } }
}
async function rsStepDecide() {
  if (ROADSHOW.decisions && ROADSHOW.decisions.length) { showToast('本拍已写回：可继续下一拍'); return true; }
  const analysis = state.analysis;
  if (!analysis || !(analysis.observations || []).length) { showToast('先完成第 3 拍：让 AI 看看', true); return false; }
  const obs = analysis.observations.slice(0, 3);
  const decisions = [];
  for (let i = 0; i < obs.length; i += 1) {
    const accept = i < 2;
    if (confirmObservation(obs[i].id, accept)) decisions.push({ id: obs[i].id, accept, text: obs[i].text });
  }
  if (!decisions.length) { showToast('没有可写回的观察（可能已处理）', true); return false; }
  // 第 4 拍的 accept = i < 2 是演示脚本代点，不是真人判断。打标后
  // buildEvidence() 会把这些 L5 排除出正式证据链，避免「脚本决策冒充用户确认」。
  const recentL5 = (state.records || []).filter((r) => r.layer === 'L5' && Date.parse(r.created_at || '') > ROADSHOW.startedAt - 1500);
  for (const r of recentL5) {
    r.synthetic = true;
    r.decision_source = 'roadshow_script';
    r.timestamp_kind = 'scripted_demo';
    r.params = { ...(r.params || {}), scripted: true, synthetic: true };
  }
  const l5 = recentL5.map((r) => r.id);
  ROADSHOW.decisions = decisions;
  ROADSHOW.l5Ids = l5;
  state.aiIntent = RS_BRIEF_LINE + ' 本次已' + decisions.map((d) => (d.accept ? '确认「' : '否决「') + String(d.text || '').slice(0, 30) + '」').join('、') + '。';
  roadshowLog('ok', '记忆写回（演示脚本代点，非真人决策）：确认 ' + decisions.filter((d) => d.accept).length + ' · 否决 ' + decisions.filter((d) => !d.accept).length + ' → L5 ' + l5.length + ' 条（不计入正式证据链）');
  roadshowHighlight('#aiBody', 'L5 决策写回');
  return true;
}
function roadshowMoveEditBelowNote() {
  const editId = ROADSHOW.editLayerId, noteId = ROADSHOW.noteLayerId;
  if (!editId || !noteId) return;
  for (let i = 0; i < 5; i += 1) {
    const idx = engine.layers.findIndex((l) => l.id === editId);
    const nidx = engine.layers.findIndex((l) => l.id === noteId);
    if (idx < 0 || nidx < 0 || idx <= nidx) break;
    try { if (!engine.moveLayer(editId, -1)) break; } catch (e) { break; }
  }
}
async function roadshowMaskSampleToSelection(dataUrl, sel) {
  const s = sel || state.selection || ROADSHOW.selection;
  if (!s || !(s.width > 0) || !(s.height > 0)) return { dataUrl, rect: { x: 0, y: 0, width: engine.width, height: engine.height }, masked: false };
  const img = new Image(); img.src = dataUrl; await img.decode();
  const full = document.createElement('canvas'); full.width = engine.width; full.height = engine.height;
  const fctx = full.getContext('2d'); fctx.drawImage(img, 0, 0, engine.width, engine.height);
  const w = Math.max(1, Math.round(s.width)); const h = Math.max(1, Math.round(s.height));
  const crop = document.createElement('canvas'); crop.width = w; crop.height = h;
  const ctx = crop.getContext('2d');
  ctx.drawImage(full, s.x, s.y, w, h, 0, 0, w, h);
  let masked = false;
  try {
    if (selectionManager && selectionManager.mask && engine.hasSelection()) {
      ctx.globalCompositeOperation = 'destination-in';
      ctx.drawImage(selectionManager.mask, s.x, s.y, w, h, 0, 0, w, h);
      ctx.globalCompositeOperation = 'source-over';
      masked = true;
    }
  } catch (e) { /* ignore */ }
  return { dataUrl: crop.toDataURL('image/png'), rect: { x: Math.round(s.x), y: Math.round(s.y), width: w, height: h }, masked };
}
async function roadshowApplyPresetSample() {
  const ok = await roadshowPrepare();
  if (!ok) return false;
  const sample = ROADSHOW.sample;
  if (!sample) { showToast('预置样本未载入：请检查 v2/app/demo/ 下的 roadshow-edit2.png', true); roadshowNow('预置样本缺失：无法落层；可退出后重试，或等待素材生成完成。'); return false; }
  if (ROADSHOW.editLayerId) { showToast('本拍已落过图层：可调「对比比例」，或用真实提交再生成一版', false); return true; }
  try { closeLibrarySheet(); } catch (e) { /* ignore */ }
  try { closePopovers(); } catch (e) { /* ignore */ }
  await roadshowBusy('正在把预置样本落为新图层…', async () => {
    const isFallback = !!(sample.meta && sample.meta.fallback);
    const layerName = isFallback ? '[预置·占位] 冷雾实验 · 本地合成' : '[预置] 冷雾实验 · 历史 Qwen 样本（非本场）';
    const local = await roadshowMaskSampleToSelection(sample.dataUrl, state.selection || ROADSHOW.selection);
    const layer = await importImageAsLayer(local.dataUrl, layerName, { x: local.rect.x, y: local.rect.y, width: local.rect.width, height: local.rect.height });
    ROADSHOW.editLayerId = layer.id;
    ROADSHOW.appliedPreset = true;
    roadshowMoveEditBelowNote();
    roadshowPresent();
    try { setTool('select'); } catch (e) { /* ignore */ }
    try { drawSelection(); } catch (e) { /* ignore */ }
    renderLayers();
    const rec = baseRecord('L6', {
      kind: 'generation', anchor: { type: 'bbox', value: [0, 0, engine.width, engine.height] },
      model: { provider: isFallback ? 'local-composite' : 'qwen', model: (sample.meta && sample.meta.model) || 'qwen-image-3.0-pro', modelVersion: (sample.meta && sample.meta.model) || 'qwen-image-3.0-pro' },
      params: {
        cached_sample: true, fallback_composite: isFallback, source: String((sample.meta && sample.meta.file) || 'demo/roadshow-edit2.png'), source_sha256: sample.sha256,
        source_generated_at: (sample.meta && sample.meta.generated_at) || null, source_task_id: (sample.meta && sample.meta.task_id) || null,
        source_request_id: (sample.meta && sample.meta.request_id) || null, selection: [local.rect.x, local.rect.y, local.rect.width, local.rect.height], full_canvas_preset: false, local_patch: true, masked: local.masked, mask_policy: local.masked ? 'selection_alpha' : 'none',
        note: isFallback ? '本地合成占位：真实编辑样本未就绪，不是模型结果；本场 0 元' : '预置样本：历史 Qwen 编辑样本文件（演示剧本，非本场调用、非用户历史），按当前选区合成落层；本场未调用模型、未计费',
      },
      input_refs: (ROADSHOW.lib && ROADSHOW.lib.edit && ROADSHOW.lib.edit.L4 || []).map((o) => o.id).slice(0, 4),
      assertions: [{ type: 'cached_sample', value: true }, { type: 'no_training_use', value: true }],
      output_asset_id: (ROADSHOW.lib && ROADSHOW.lib.edit && ROADSHOW.lib.edit.id) || 'asset-preset-cold-fog-edit',
      cost_cny: 0, credits: 0, ai_role: 'assistant', source: 'inferred', author: 'ai',
      note: isFallback ? ('cached_sample · 本地合成占位落层（非真实模型结果 · sha256 ' + sample.sha256.slice(0, 12) + '…）· 本场 0 元') : ('cached_sample · 用预置样本落层（历史 Qwen 编辑结果，非本场调用 · sha256 ' + sample.sha256.slice(0, 12) + '…）· 本场 0 元'),
    });
    addRecord(rec);
    ROADSHOW.lastSampleRecord = rec;
    try { renderLayers(); } catch (e) { /* ignore */ }
    roadshowLog(isFallback ? 'warn' : 'ok', (isFallback ? '本地占位已落层' : '预置样本已落层') + ' · 0 元 · sha256 ' + sample.sha256.slice(0, 12) + '…');
    showToast(isFallback ? '已落本地合成占位（真实样本未就绪，已标明）' : '已用预置样本落新图层（历史样本 · 本场未调用模型 · 非用户历史）');
    try { scheduleProjectAutosave(); } catch (e) { /* ignore */ }
    setTimeout(() => { try { saveSnapshot().catch(() => {}); } catch (e) { /* ignore */ } }, 400);
  });
  return !!ROADSHOW.editLayerId;
}
async function roadshowRealEdit() {
  const ok = await roadshowPrepare();
  if (!ok) return false;
  if (!aiRealEligible()) { showToast('未启用真实调用（无 key / Mock 模式）：请用预置样本；不会把 Mock 候选落上大屏', true); roadshowNow('真实调用不可用：请用预置样本。Mock 候选不落大屏。'); return false; }
  try { closePopovers(); } catch (e) { /* ignore */ }
  state.aiImageScope = 'selection';
  state.aiImagePrompt = RS_EDIT_PROMPT;
  state.aiWorkshopRefs = [];
  roadshowApplyRealSelection(false);
  const res = await roadshowBusy('真实提交中…（选区裁切 → Qwen 图像编辑 · 实测约 12–25s）', () => runImageWorkshop('edit'), { timeoutMs: 180000 });
  if (!res || !state.candidates || !state.candidates.length) {
    roadshowNow('真实编辑没有返回结果：请改用预置样本（不会静默失败）。');
    return false;
  }
  const meta = state.aiLastCall || {};
  if (meta.mock) {
    state.candidates = null;
    showToast('模型返回 Mock 占位：不落大屏，请改用预置样本', true);
    roadshowNow('Mock 占位 · 未调用模型：不落层。请用预置样本。');
    return false;
  }
  await applyCandidate(0);
  const layer = activeLayer();
  if (!layer) { showToast('真实编辑已返回，但落层失败', true); return false; }
  ROADSHOW.editLayerId = layer.id;
  ROADSHOW.appliedReal = true;
  roadshowMoveEditBelowNote();
  roadshowPresent();
  try { renderLayers(); } catch (e) { /* ignore */ }
  const gen = (state.records || []).filter((r) => r.layer === 'L6' && r.kind === 'generation' && r.params && !r.params.preset_sample && !r.params.cached_sample).slice(-1)[0];
  if (gen && gen.params) ROADSHOW.maskPolicy = gen.params.mask_policy || null;
  const poly = gen && gen.params ? gen.params.mask_policy || 'none' : '—';
  ROADSHOW.lastRealRecord = gen || null;
  roadshowLog('ok', '真实编辑已落层 · mask_policy=' + poly + ' · ' + ((meta.latencyMs || 0)) + 'ms');
  showToast('真实编辑结果已按选区 mask 落为新图层（框外像素不变）');
  return true;
}
// T119：第 5 拍「执行本步」入口 —— 真实调用优先，失败显式降级到预置样本。
// 降级不是静默的：UI、控制台日志、L6 记录三处同时标明本次落层来源（real / preset_fallback）。
async function rsStepEdit() {
  if (ROADSHOW.editLayerId) { showToast('本拍已落过图层：可调「对比比例」，或退出重进再落一版', false); return true; }
  if (aiRealEligible()) {
    const t0 = Date.now();
    const ok = await roadshowRealEdit();
    if (ok) {
      ROADSHOW.editSource = 'real';
      roadshowLog('ok', '第 5 拍落层来源=真实模型调用（' + ((Date.now() - t0) / 1000).toFixed(1) + 's）');
      return true;
    }
    roadshowLog('warn', '真实编辑失败/超时：显式降级到预置样本（历史 Qwen 结果，非本场调用）');
    roadshowNow('真实编辑本次未成功：已显式降级为预置样本落层。证据链会分别记录两种来源，不会混同。');
  } else {
    roadshowLog('warn', '真实调用不可用（无 key / Mock 模式 / 隐私模式）：使用预置样本');
  }
  const ok2 = await roadshowApplyPresetSample();
  if (ok2) ROADSHOW.editSource = 'preset_fallback';
  return ok2;
}
function roadshowVerifyDigest(v) {
  if (!v) return '';
  const checks = Object.entries(v.checks || {}).filter(([, ok]) => ok).length;
  const total = Object.keys(v.checks || {}).length;
  return (v.ok ? '复核通过 ✓' : '复核失败 ✗') + ' · ' + checks + '/' + total + ' 项';
}
async function roadshowVerifyEvidence(pkg) {
  const checks = {};
  const errors = [];
  const ok = (id) => { checks[id] = true; };
  const fail = (id, msg) => { checks[id] = false; errors.push(id + ': ' + msg); };
  if (!pkg || pkg.schema !== 'inkproof.evidence.v1') fail('schema', 'schema 不是 inkproof.evidence.v1'); else ok('schema');
  const m = (pkg && pkg.manifest) || {};
  const events = Array.isArray(pkg && pkg.events) ? pkg.events : [];
  if (m.genesis_hash !== GENESIS_HASH) fail('genesis', '创世哈希不是 64 个 0'); else ok('genesis');
  if (Number(m.event_count) !== events.length) fail('eventCount', 'manifest.event_count 与 events 数量不一致'); else ok('eventCount');
  let prev = GENESIS_HASH, chainOk = true;
  for (let i = 0; i < events.length; i += 1) {
    const e = events[i] || {};
    if (e.chain_prev !== prev) { fail('chainSeq', '事件 ' + i + ' chain_prev 不匹配'); chainOk = false; break; }
    const rec = { ...e }; delete rec.chain_prev; delete rec.chain_hash;
    let expected;
    try { expected = await sha256Hex(prev + canonicalJson(rec)); } catch (err) { fail('chainHash', '事件 ' + i + ' 无法规范化'); chainOk = false; break; }
    if (expected !== e.chain_hash) { fail('chainHash', '事件 ' + i + ' 链哈希不匹配'); chainOk = false; break; }
    prev = e.chain_hash;
  }
  if (chainOk) ok('chain');
  const headExpected = events.length ? events[events.length - 1].chain_hash : GENESIS_HASH;
  if ((m.head_hash || GENESIS_HASH) !== headExpected) fail('headHash', 'head_hash 与链尾不一致'); else ok('headHash');
  // 画布：PNG 字节哈希（可与 Get-FileHash 对照）+ 旧版 dataURL 哈希（CLI verify 口径）
  let canvasBytesSha = null;
  if (pkg.project && pkg.project.canvas) {
    const c = pkg.project.canvas;
    if (c.width !== engine.width || c.height !== engine.height) fail('canvasSize', '画布尺寸与当前引擎不一致'); else ok('canvasSize');
    if (typeof pkg.canvas_png_data_url === 'string') {
      try {
        const bytes = roadshowDataUrlBytes(pkg.canvas_png_data_url);
        canvasBytesSha = await sha256Hex(bytes);
        if (c.png_sha256 && canvasBytesSha !== c.png_sha256) fail('canvasPngBytes', '画布 PNG 字节 SHA-256 不匹配'); else if (c.png_sha256) ok('canvasPngBytes');
        const du = await sha256Hex(pkg.canvas_png_data_url);
        if (c.sha256 && du !== c.sha256) fail('canvasDataUrl', '画布 dataURL 哈希不匹配'); else if (c.sha256) ok('canvasDataUrl');
      } catch (e) { fail('canvasPngBytes', '无法解码画布 PNG：' + (e.message || e)); }
    } else fail('canvasPngBytes', '缺少画布 PNG');
  } else fail('canvas', '缺少画布信息');
  // 图层 PNG 字节哈希
  const layers = Array.isArray(m.layers) ? m.layers : [];
  if (!layers.length) fail('layers', '缺少图层清单');
  else if (layers.some((l) => !l.png_sha256 && !(l.tile_count === 0))) fail('layerPngBytes', '图层缺少 PNG 字节哈希');
  else ok('layerPngBytes');
  // AI 清单一致性
  const ai = m.ai || {};
  const aiEvents = events.filter((e) => e.layer === 'L6' && e.params && e.params.task);
  if (Number(ai.calls || 0) !== aiEvents.length) fail('aiCalls', 'manifest.ai.calls 与 L6 AI 事件数不一致'); else ok('aiCalls');
  if (Number(ai.real_calls || 0) + Number(ai.mock_calls || 0) !== Number(ai.calls || 0)) fail('aiSplit', 'real + mock 不等于 calls'); else ok('aiSplit');
  const realFromEvents = aiEvents.filter((e) => e.params && !e.params.mock).length;
  if (Number(ai.real_calls || 0) !== realFromEvents) fail('aiRealCalls', 'real_calls 与事件不一致'); else ok('aiRealCalls');
  const tokens = Number(ai.total_tokens || 0);
  const cost = events.filter((e) => e.layer === 'L6' && e.cost_cny != null).reduce((n, e) => n + Number(e.cost_cny || 0), 0);
  return { ok: errors.length === 0, checks, errors, events: events.length, head: m.head_hash || null, canvasBytesSha, tokens, cost, calls: Number(ai.calls || 0), realCalls: Number(ai.real_calls || 0), mockCalls: Number(ai.mock_calls || 0), layers: layers.length, at: iso() };
}
function roadshowDownloadEvidencePng() {
  const pkg = ROADSHOW.evidence;
  if (!pkg || !pkg.canvas_png_data_url) { showToast('先生成证据包', true); return; }
  try {
    const bytes = roadshowDataUrlBytes(pkg.canvas_png_data_url);
    const blob = new Blob([bytes], { type: 'image/png' });
    downloadBlob('inkproof-canvas-' + String((pkg.project && pkg.project.canvas && pkg.project.canvas.png_sha256) || '').slice(0, 12) + '.png', blob);
    showToast('已下载画布 PNG：其字节 SHA-256 = 证据里的 canvas.png_sha256（可用 Get-FileHash 对照）');
  } catch (e) { showToast('下载失败：' + (e.message || e), true); }
}
async function rsStepEvidence() {
  if (ROADSHOW.busy) return false;
  try { closePopovers(); } catch (e) { /* ignore */ }
  const pkg = await roadshowBusy('生成证据包（画布 PNG 导出 + 哈希链 + 图层哈希）…', async () => {
    const p = await buildEvidence({ asyncPNG: typeof engine.exportPNGAsync === 'function', projectName: RS_PROJECT_NAME });
    state.evidence = p;
    ROADSHOW.evidence = p;
    ROADSHOW.verify = await roadshowVerifyEvidence(p);
    return p;
  }, { timeoutMs: 150000 });
  if (!pkg) { roadshowNow('证据包生成失败：可重试一次；失败原因见上方日志。'); return false; }
  const v = ROADSHOW.verify;
  roadshowLog(v.ok ? 'ok' : 'err', '证据包复核：' + roadshowVerifyDigest(v) + ' · 事件 ' + v.events + ' · real ' + v.realCalls + ' / mock ' + v.mockCalls + ' · ' + v.tokens + ' tokens');
  try { await openEvidence(pkg); } catch (e) { /* ignore */ }
  return v.ok;
}

/* ---- 控制台渲染 ---- */
function roadshowStepBody(step) {
  const lib = ROADSHOW.lib || {};
  const l6 = (state.records || []).filter((r) => r.layer === 'L6' && r.params && r.params.preset_sample);
  if (step.id === 'brief') {
    return '<div class="rs-sec"><div class="rs-sec-title">客户 brief</div>' +
      '<div class="rs-kv"><span>项目</span><b>《呼吸》· 短片概念图</b></div>' +
      '<div class="rs-kv"><span>要求</span><b>雾带改清晨冷雾 · 保留近水手绘笔触</b></div>' +
      '<div class="rs-kv"><span>交付</span><b>明早 10:00 · PNG + 证据包</b></div>' +
      '<div class="rs-kv"><span>L5 记忆</span><b>冷灰蓝（选定）· 赛博朋克紫（否决）</b></div></div>' +
      '<div class="rs-sec"><div class="rs-sec-title">本地档案（昨天 · 预置样本）</div>' +
      '<div class="rs-note">' + (ROADSHOW.prepared ? ('昨天 <b>' + l6.length + '</b> 条 L6：观察 / 方向 / 2 个候选 / 导出 / 导入；素材库 <b>' + (ROADSHOW.libCount || 0) + '</b> 张。') : '执行本步载入预置项目（1600×1600 + 素材 + 昨天档案）。') + '</div>' +
      (ROADSHOW.sample ? ('<div class="rs-note">冷雾实验：<code>' + escapeHtml((ROADSHOW.sample.meta && ROADSHOW.sample.meta.file) || '') + '</code><br>sha256 <code>' + escapeHtml(String(ROADSHOW.sample.sha256 || '').slice(0, 22)) + '…</code><br>' + escapeHtml((ROADSHOW.sample.meta && ROADSHOW.sample.meta.model) || 'qwen-image-3.0-pro') + ' · ' + escapeHtml(String((ROADSHOW.sample.meta && ROADSHOW.sample.meta.generated_at) || '').slice(0, 16).replace('T', ' ')) + '</div>') : '') +
      '<div class="rs-btns"><button class="rs-btn" data-rs-act="openLibrary">打开素材库</button><button class="rs-btn ghost" data-rs-act="showArchive">看档案记录</button></div></div>';
  }
  if (step.id === 'select') {
    const sel = state.selection || ROADSHOW.selection || null;
    const has = !!(engine && typeof engine.hasSelection === 'function' && engine.hasSelection());
    return '<div class="rs-sec"><div class="rs-sec-title">选区 = AI 的边界</div>' +
      '<div class="rs-kv"><span>选区</span><b>' + (sel ? (Math.round(sel.width) + '×' + Math.round(sel.height) + ' @ (' + Math.round(sel.x) + ',' + Math.round(sel.y) + ')') : '未建立') + '</b></div>' +
      '<div class="rs-kv"><span>真实 mask</span><b class="' + (has ? 'rs-ok' : 'rs-warn') + '">' + (has ? '已写入引擎（落层按选区裁切）' : '尚未建立（执行本步）') + '</b></div>' +
      '<div class="rs-note">框选雾带（约 60% 宽 / 42% 高）：AI 只读这块裁切图，框外像素不会被发送、也不会被落层覆盖。</div>' +
      '<div class="rs-btns"><button class="rs-btn" data-rs-act="reselect">重设雾带选区</button><button class="rs-btn ghost" data-rs-act="openAI">打开 AI 对话</button></div></div>';
  }
  if (step.id === 'observe') {
    const obs = (state.analysis && state.analysis.observations) || [];
    const last = state.aiLastCall;
    const real = aiRealEligible();
    let html = '<div class="rs-sec"><div class="rs-sec-title">这次调用</div>' +
      '<div class="rs-kv"><span>模式</span><b class="' + (real ? 'rs-ok' : 'rs-warn') + '">' + (real ? ('真实视觉 · ' + aiProviderLabel() + ' / ' + aiRuntimeModel()) : 'Mock 占位 · 未调用模型') + '</b></div>';
    if (last) html += '<div class="rs-kv"><span>上次</span><b>' + escapeHtml((last.mock ? 'Mock' : '真实') + ' · ' + (last.latencyMs || 0) + 'ms · ' + (last.model || last.modelVersion || '')) + '</b></div>';
    html += '<div class="rs-kv"><span>L5 上下文</span><b>' + (ROADSHOW.lastL5Context || 0) + ' 条用户决策（已进 L6 的 l5_refs）</b></div>';
    html += '<div class="rs-note">发送：选区裁切图 + 档案摘要（含 L5 决策与素材库记忆）。真实视觉基线 8.7–21.3s；没有 key 时走 Mock，观察文字可用，但 Mock 候选不会落上大屏。</div></div>';
    if (obs.length) html += '<div class="rs-sec"><div class="rs-sec-title">观察（' + obs.length + '）</div><ul class="rs-list">' + obs.slice(0, 4).map((o) => '<li><span class="dim">' + Math.round((o.confidence || 0) * 100) + '%</span> ' + escapeHtml(o.text || '') + '</li>').join('') + '</ul></div>';
    html += '<div class="rs-btns"><button class="rs-btn" data-rs-act="mockObserve">' + (real ? '用 Mock 重看一次' : '让 AI 看（Mock）') + '</button>' + (last && last.mock ? '<span class="rs-note">当前是 Mock 占位</span>' : '') + '</div>';
    return html;
  }
  if (step.id === 'decide') {
    const obs = (state.analysis && state.analysis.observations) || [];
    const decisions = ROADSHOW.decisions;
    let html = '<div class="rs-sec"><div class="rs-sec-title">待决定（本拍写回 L5）</div>';
    if (!obs.length) html += '<div class="rs-note">还没有观察：先完成第 3 拍「让 AI 看看」。</div>';
    else html += '<ul class="rs-list">' + obs.slice(0, 3).map((o, i) => '<li>' + (decisions ? (decisions[i] && decisions[i].accept ? '<span class="ok">✓</span>' : '<span class="no">✕</span>') : '<span class="dim">' + (i < 2 ? '待确认' : '待否决') + '</span>') + ' ' + escapeHtml(o.text || '') + '</li>').join('') + '</ul>';
    html += '<div class="rs-note">执行本步 = 你确认前 2 条、否决第 3 条；每条决定都写 L5，并进入下一次观察/生成的上下文（不是假装记住）。</div></div>';
    const l5 = (state.records || []).filter((r) => r.layer === 'L5' && Date.parse(r.created_at || '') > (ROADSHOW.startedAt || 0) - 1500);
    html += '<div class="rs-sec"><div class="rs-sec-title">本次已写回</div><ul class="rs-list">' + (l5.length ? l5.slice(-4).map((r) => '<li><span class="dim">L5</span> ' + escapeHtml(r.note || r.kind || '') + '</li>').join('') : '<li class="dim">还没有决策写回</li>') + '</ul></div>';
    return html;
  }
  if (step.id === 'edit') {
    const sample = ROADSHOW.sample;
    let html = '<div class="rs-sec"><div class="rs-sec-title">方向（由昨日 L5 锁定）</div><div class="rs-choices">' +
      '<div class="rs-choice locked"><span class="ic">✓</span><div class="tx"><b>清晨冷雾 · 冷灰蓝</b><span>客户选定（L5）· 保留近水手绘笔触</span></div></div>' +
      '<div class="rs-choice rejected"><span class="ic">✕</span><div class="tx"><b>赛博朋克紫</b><span>客户已否决（L5）· 不再生成</span></div></div></div></div>';
    if (sample) {
      const fb = !!(sample.meta && sample.meta.fallback);
      html += '<div class="rs-sec"><div class="rs-sec-title">' + (fb ? '本地合成占位（真实样本未就绪）' : '预置样本（历史 Qwen 结果 · 非本场调用）') + '</div>' +
        '<div class="rs-note">文件 <code>' + escapeHtml((sample.meta && sample.meta.file) || '') + '</code><br>sha256 <code>' + escapeHtml(String(sample.sha256 || '').slice(0, 32)) + '…</code><br>' + escapeHtml((sample.meta && sample.meta.model) || 'qwen-image-3.0-pro') + ' · ' + escapeHtml(String((sample.meta && sample.meta.generated_at) || '').slice(0, 19).replace('T', ' ')) + '<br>' + (fb ? '<b class="rs-warn">这是本地合成占位，不是真实模型结果</b>；落层会标「占位」。' : '落层走本地文件：本场不调用模型、不计费。') + '</div>' +
        '<div class="rs-btns"><button class="rs-btn primary" data-rs-act="applySample">' + (fb ? '用本地占位落层' : '用预置样本（历史 Qwen 结果）') + '</button><button class="rs-btn" data-rs-act="realEdit"' + (aiRealEligible() ? ' title="真实调用实测约 12–25s；同一提示词每次结果可能不同；失败会显式降级到预置样本，不静默"' : ' disabled title="未启用真实调用（无 key / Mock 模式）"') + '>真实提交（实测约 12–25s）</button></div></div>';
    } else {
      html += '<div class="rs-sec"><div class="rs-note rs-warn">预置样本未载入：点「执行本步」重试，或退出后检查 demo/roadshow-edit2.png。</div></div>';
    }
    if (ROADSHOW.editLayerId) {
      const layer = (engine.layers || []).find((l) => l.id === ROADSHOW.editLayerId) || {};
      const rec = ROADSHOW.lastSampleRecord || ROADSHOW.lastRealRecord;
      const recText = rec && rec.params ? (rec.params.cached_sample ? 'cached_sample · 本场 0 元' : ('real_model · mask ' + String(rec.params.mask_policy || '—'))) : '—';
      html += '<div class="rs-sec"><div class="rs-sec-title">已落层</div>' +
        '<div class="rs-kv"><span>图层</span><b>' + escapeHtml(layer.name || '') + '</b></div>' +
        '<div class="rs-kv"><span>L6</span><b>' + escapeHtml(recText) + '</b></div>' +
        '<div class="rs-compare"><div class="rs-compare-head"><span>对比比例（局部图层不透明度）</span><b id="rsCompareVal">100%</b></div><input type="range" id="rsCompareRange" min="0" max="100" value="100"><div class="rs-compare-labels"><span>原画</span><span>冷雾</span></div></div></div>';
    }
    return html;
  }
  if (step.id === 'evidence') {
    const v = ROADSHOW.verify;
    if (!v) {
      return '<div class="rs-sec"><div class="rs-note">执行本步：导出 PNG + 生成证据包 + 本地复核哈希链 / 画布 PNG 字节 SHA-256 / 图层 SHA-256 / AI 调用清单。</div>' +
        '<div class="rs-note">复核口径（不夸大）：<br>· <code>canvas.png_sha256</code> = 导出 PNG 文件字节（下载后用 <code>Get-FileHash</code> 可对照）<br>· <code>canvas.sha256</code> = dataURL 字符串哈希（旧版 / CLI verify 口径）<br>· <code>layers[].png_sha256</code> = 图层 PNG 字节</div></div>';
    }
    const vsum = roadshowVerifyDigest(v);
    return '<div class="rs-sec"><div class="rs-sec-title">包内复核</div>' +
      '<div class="rs-kv"><span>结果</span><b class="' + (v.ok ? 'rs-ok' : 'rs-bad') + '">' + escapeHtml(vsum) + '</b></div>' +
      '<div class="rs-kv"><span>哈希链</span><b>' + v.events + ' 事件 · 链头 ' + escapeHtml(String(v.head || '').slice(0, 12)) + '…</b></div>' +
      '<div class="rs-kv"><span>画布 PNG</span><b><code>' + escapeHtml(String(v.canvasBytesSha || '').slice(0, 24)) + '…</code></b></div>' +
      '<div class="rs-kv"><span>AI 调用</span><b>真实 ' + v.realCalls + ' · Mock ' + v.mockCalls + ' · ' + v.tokens + ' tokens</b></div>' +
      '<div class="rs-kv"><span>已记录成本</span><b>' + (roadshowStats().costKnown ? ('¥' + roadshowStats().cost.toFixed(2)) : '—') + '</b></div>' +
      (v.errors.length ? '<div class="rs-note rs-bad">' + v.errors.map((x) => escapeHtml(x)).join('<br>') + '</div>' : '') +
      '<div class="rs-btns"><button class="rs-btn" data-rs-act="openEvidence">再次打开证据包</button><button class="rs-btn" data-rs-act="downloadPng">下载画布 PNG（与哈希同字节）</button><button class="rs-btn ghost" data-rs-act="copyCli">复制 CLI 复核命令</button></div>' +
      '<div class="rs-note">第三方复核：下载画布 PNG 后 <code>Get-FileHash -Algorithm SHA256</code> 应与上面对照；包内哈希链可用 <code>node v2/qa/tools/verify-evidence.mjs inkproof-evidence.json</code> 复核（旧版 dataURL 口径）。</div></div>';
  }
  return '';
}
function roadshowBindStepBody() {
  const body = document.getElementById('roadshowBody');
  if (!body) return;
  body.querySelectorAll('[data-rs-act]').forEach((b) => {
    b.addEventListener('click', (e) => {
      e.preventDefault();
      const act = b.dataset.rsAct;
      if (act === 'openLibrary') roadshowOpenLibrary().catch(() => {});
      else if (act === 'showArchive') { try { renderArchive(); openModal('archiveModal'); } catch (err) { /* ignore */ } }
      else if (act === 'reselect') roadshowApplyRealSelection(true);
      else if (act === 'openAI') { try { openPopover('popAI'); switchAiTab('obs'); } catch (err) { /* ignore */ } }
      else if (act === 'mockObserve') roadshowMockObserve().catch(() => {});
      else if (act === 'applySample') roadshowApplyPresetSample().catch(() => {});
      else if (act === 'realEdit') roadshowRealEdit().catch(() => {});
      else if (act === 'openEvidence') { if (ROADSHOW.evidence) openEvidence(ROADSHOW.evidence).catch(() => {}); }
      else if (act === 'downloadPng') roadshowDownloadEvidencePng();
      else if (act === 'copyCli') { const cmd = 'node v2/qa/tools/verify-evidence.mjs inkproof-evidence.json'; try { navigator.clipboard.writeText(cmd).then(() => showToast('复核命令已复制'), () => showToast(cmd)); } catch (err) { showToast(cmd); } }
    });
  });
  const range = body.querySelector('#rsCompareRange');
  if (range) {
    const label = body.querySelector('#rsCompareVal');
    range.addEventListener('input', () => {
      const val = Number(range.value) || 0;
      if (label) label.textContent = val + '%';
      try { if (ROADSHOW.editLayerId) engine.setLayerOpacity(ROADSHOW.editLayerId, val / 100); } catch (err) { /* ignore */ }
    });
  }
}
function roadshowRender() {
  if (!ROADSHOW.active) return;
  const step = RS_STEPS[clamp(ROADSHOW.step, 0, RS_STEPS.length - 1)];
  const set = (id, text) => { const el = document.getElementById(id); if (el) el.textContent = text; };
  set('roadshowStepNo', step.n + ' / ' + String(RS_STEPS.length).padStart(2, '0'));
  set('roadshowStepTitle', step.title);
  set('roadshowStepHint', step.hint);
  set('roadshowStepBudget', '目标 ' + step.budget + 's');
  const pips = document.getElementById('roadshowPips');
  if (pips) pips.innerHTML = RS_STEPS.map((s, i) => '<button class="rs-pip' + (i === ROADSHOW.step ? ' active' : '') + (ROADSHOW.done && ROADSHOW.done[i] ? ' done' : '') + '" data-rs-step="' + i + '"><span class="n">' + s.n + '</span>' + s.pip + '</button>').join('');
  const body = document.getElementById('roadshowBody');
  if (body) { body.innerHTML = roadshowStepBody(step); roadshowBindStepBody(); }
  const exec = document.getElementById('btnRoadshowExec');
  if (exec) { exec.textContent = step.exec; exec.disabled = !!ROADSHOW.busy; }
  roadshowRenderAutoBtn();
  const prev = document.getElementById('btnRoadshowPrev'); if (prev) prev.disabled = ROADSHOW.step <= 0;
  const next = document.getElementById('btnRoadshowNext'); if (next) next.disabled = ROADSHOW.step >= RS_STEPS.length - 1;
  roadshowRenderBadge();
}
function roadshowGoto(index) {
  if (!ROADSHOW.active) return;
  const next = clamp(Number(index) || 0, 0, RS_STEPS.length - 1);
  ROADSHOW.step = next;
  ROADSHOW.stepStartedAt = Date.now();
  roadshowNow('');
  roadshowRender();
  const step = RS_STEPS[next];
  if (step && step.target) setTimeout(() => { try { roadshowHighlight(step.target, step.targetLabel); } catch (e) { /* ignore */ } }, 120);
}
function roadshowNext() { if (!ROADSHOW.active) return; roadshowGoto(ROADSHOW.step + 1); }
function roadshowPrev() { if (!ROADSHOW.active) return; roadshowGoto(ROADSHOW.step - 1); }
async function roadshowBusy(label, fn, opts = {}) {
  if (ROADSHOW.busy) { showToast('上一步还在执行，请稍候', true); return null; }
  ROADSHOW.busy = true;
  const exec = document.getElementById('btnRoadshowExec'); if (exec) exec.disabled = true;
  const t0 = Date.now();
  roadshowNow(label);
  const timer = setInterval(() => { roadshowNow(label + ' · ' + roadshowFmt(Date.now() - t0)); }, 500);
  try {
    const run = Promise.resolve().then(fn);
    if (opts.timeoutMs) {
      return await Promise.race([run, new Promise((resolve, reject) => setTimeout(() => { const e = new Error('超时（' + Math.round(opts.timeoutMs / 1000) + 's）：请求可能仍在后台继续，结果不会自动采用'); e.timeout = true; reject(e); }, opts.timeoutMs))]);
    }
    return await run;
  } catch (e) {
    const msg = (e && e.timeout) ? e.message : ((e && (e.userMessage || e.message)) || String(e));
    ROADSHOW.lastError = msg;
    roadshowLog('err', msg);
    showToast('路演：' + msg, true);
    return null;
  } finally {
    clearInterval(timer);
    ROADSHOW.busy = false;
    roadshowNow('');
    const ex = document.getElementById('btnRoadshowExec'); if (ex) ex.disabled = false;
    roadshowRender();
  }
}
async function roadshowExecCurrent() {
  if (!ROADSHOW.active) return null;
  if (ROADSHOW.busy) { showToast('正在执行，请稍候', true); return null; }
  const step = RS_STEPS[ROADSHOW.step];
  const map = { brief: rsStepBrief, select: rsStepSelect, observe: rsStepObserve, decide: rsStepDecide, edit: rsStepEdit, evidence: rsStepEvidence };
  const fn = map[step.id];
  if (!fn) return null;
  let out = null;
  try { out = await fn(); } finally { if (out !== false) ROADSHOW.done[ROADSHOW.step] = true; roadshowRender(); }
  return out;
}

/* ---- T120 自动演示：从当前拍开始逐拍自动执行（实机运行，像交互动画一样推进） ----
   规则：每拍执行完停留 dwell 秒让评委看清结果，再自动进入下一拍；
   任何一拍返回 false（如真实调用失败）→ 停止自动播放，交还人工（不静默跳过）；
   用户点「停止」、退出路演或手动切换拍 → 立即停止。 */
const RS_AUTO_DWELL = { brief: 3500, select: 2200, observe: 2600, decide: 2600, edit: 4200, evidence: 3600 };
async function roadshowAutoPlay() {
  if (!ROADSHOW.active) return;
  if (ROADSHOW.auto) { roadshowAutoStop('已停止自动演示'); return; }
  ROADSHOW.auto = true;
  roadshowRenderAutoBtn();
  roadshowLog('ok', '自动演示开始：从第 ' + RS_STEPS[ROADSHOW.step].n + ' 拍起，逐拍实机执行');
  while (ROADSHOW.auto && ROADSHOW.active && ROADSHOW.step < RS_STEPS.length) {
    const step = RS_STEPS[ROADSHOW.step];
    const out = await roadshowExecCurrent();
    if (!ROADSHOW.auto || !ROADSHOW.active) break;
    if (out === false) {
      ROADSHOW.auto = false;
      roadshowRenderAutoBtn();
      roadshowLog('warn', '第 ' + step.n + ' 拍失败：自动演示已停，请人工处理（不静默跳过）');
      break;
    }
    if (ROADSHOW.step >= RS_STEPS.length - 1) {
      roadshowLog('ok', '自动演示完成：六拍全部执行（含真实调用与证据包）');
      showToast('自动演示完成 · 六拍全部执行');
      break;
    }
    const dwell = RS_AUTO_DWELL[step.id] || 3000;
    roadshowNow('自动演示 · ' + dwell / 1000 + 's 后进入第 ' + RS_STEPS[ROADSHOW.step + 1].n + ' 拍');
    await new Promise((r) => { ROADSHOW.autoTimer = setTimeout(r, dwell); });
    if (!ROADSHOW.auto || !ROADSHOW.active) break;
    roadshowNext();
  }
  ROADSHOW.auto = false;
  roadshowRenderAutoBtn();
  roadshowNow('');
}
function roadshowAutoStop(msg) {
  ROADSHOW.auto = false;
  if (ROADSHOW.autoTimer) { clearTimeout(ROADSHOW.autoTimer); ROADSHOW.autoTimer = null; }
  roadshowRenderAutoBtn();
  if (msg) roadshowLog('info', msg);
}
function roadshowRenderAutoBtn() {
  const b = document.getElementById('btnRoadshowAuto');
  if (!b) return;
  b.textContent = ROADSHOW.auto ? '■ 停止自动演示' : '▶ 自动演示';
  b.classList.toggle('danger', !!ROADSHOW.auto);
}

/* ---- 进入 / 退出 / 模odal ---- */
function openRoadshowBrief() {
  if (ROADSHOW.active) { roadshowToggleCollapse(); return; }
  if (state.demo.active) { try { takeoverDemo(); } catch (e) { /* ignore */ } }
  try { closePopovers(); } catch (e) { /* ignore */ }
  const note = document.getElementById('roadshowBriefNote');
  if (note) note.innerHTML = '开始后会：切换到 <b>1600×1600</b> 预置项目（成稿 · 山谷）、种入 <b>3 个素材</b>与 <b>7 条「昨天」的 L6</b>、建立<b>真实选区</b>（雾带 x≈18% / y≈22% / w≈60% / h≈42%）；这些都可手动接管。';
  const assetsEl = document.getElementById('roadshowBriefAssets');
  if (assetsEl) assetsEl.textContent = '预置素材：检查中…';
  openModal('roadshowBrief');
  roadshowPeekAssets().then((info) => {
    const el = document.getElementById('roadshowBriefAssets');
    if (!el) return;
    if (info.ok) {
      el.innerHTML = '预置素材：<b>原图 + 冷雾编辑样本已就绪</b>（' + info.count + ' 张）<br><code>' + escapeHtml((info.editFile || '') + (info.editSha ? (' · sha256 ' + String(info.editSha).slice(0, 14) + '…') : '')) + '</code>';
    } else {
      el.innerHTML = '预置素材：<b>未读取到</b>（' + escapeHtml(info.error || '') + '）；开始后会重试。';
    }
  }).catch(() => {});
}
function roadshowToggleCollapse() {
  const bar = document.getElementById('roadshowBar');
  if (!bar) return;
  bar.classList.toggle('is-collapsed');
  const btn = document.getElementById('btnRoadshowCollapse');
  if (btn) btn.textContent = bar.classList.contains('is-collapsed') ? '+' : '–';
}
async function roadshowStart() {
  if (ROADSHOW.active) return;
  closeModal('roadshowBrief');
  if (state.demo.active) { try { takeoverDemo(); } catch (e) { /* ignore */ } }
  try { closeLibrarySheet(); } catch (e) { /* ignore */ }
  ['evidenceModal', 'archiveModal', 'aboutModal', 'aiConfirmModal', 'batchReviewModal', 'guidesModal', 'adjustModal', 'canvasResizeModal', 'newCanvasModal'].forEach((id) => { try { closeModal(id); } catch (e) { /* ignore */ } });
  try { closePopovers(); } catch (e) { /* ignore */ }
  try { hideQuickStart(false); } catch (e) { /* ignore */ }
  ROADSHOW.active = true;
  ROADSHOW.step = 0;
  ROADSHOW.busy = false;
  ROADSHOW.log = [];
  ROADSHOW.done = {};
  ROADSHOW.error = null;
  ROADSHOW.prepared = false;
  ROADSHOW.preparing = null;
  ROADSHOW.manifest = null;
  ROADSHOW.sample = null;
  ROADSHOW.baseLayerId = null;
  ROADSHOW.noteLayerId = null;
  ROADSHOW.editLayerId = null;
  ROADSHOW.appliedPreset = false;
  ROADSHOW.appliedReal = false;
  ROADSHOW.decisions = null;
  ROADSHOW.l5Ids = [];
  ROADSHOW.lastSampleRecord = null;
  ROADSHOW.lastRealRecord = null;
  ROADSHOW.evidence = null;
  ROADSHOW.verify = null;
  ROADSHOW.maskPolicy = null;
  ROADSHOW.lastL5Context = 0;
  ROADSHOW.savedRecords = (state.records || []).slice();
  ROADSHOW.savedProjectLabel = (document.getElementById('projectLabel') || {}).textContent || '';
  if (state.mode === 'attest') { try { setMode('collab', { silent: true }); } catch (e) { /* ignore */ } }
  const bar = document.getElementById('roadshowBar');
  if (bar) { bar.hidden = false; bar.classList.remove('is-collapsed'); }
  const cbtn = document.getElementById('btnRoadshowCollapse'); if (cbtn) cbtn.textContent = '–';
  document.body.classList.add('roadshow-running');
  const label = document.getElementById('projectLabel'); if (label) label.textContent = RS_PROJECT_NAME;
  roadshowLog('info', '进入路演：' + RS_PROJECT_NAME + ' · 客户交付');
  try { await refreshAiConfig({ keepPreset: true, quiet: true }).catch(() => {}); } catch (e) { /* ignore */ }
  const real = roadshowEnableRealRuntime();
  roadshowLog(real ? 'ok' : 'warn', real ? ('真实调用已启用：' + aiProviderLabel() + ' / ' + aiRuntimeModel() + '（已写入本地设置，不弹逐次确认）') : '未检测到真实 key：本轮为 Mock 观察 + 预置样本落层（徽章会显示 Mock）');
  roadshowStartTimer();
  roadshowRender();
  await roadshowPrepare();
  roadshowRender();
  const effStep = RS_STEPS[0];
  if (effStep) { try { roadshowHighlight(effStep.target, effStep.targetLabel); } catch (e) { /* ignore */ } }
  return ROADSHOW.prepared;
}
function roadshowExit() {
  if (!ROADSHOW.active) return;
  ROADSHOW.active = false;
  ROADSHOW.busy = false;
  ROADSHOW.auto = false;
  if (ROADSHOW.autoTimer) { clearTimeout(ROADSHOW.autoTimer); ROADSHOW.autoTimer = null; }
  roadshowStopTimer();
  clearTimeout(ROADSHOW.hlTimer);
  document.querySelectorAll('.rs-hl').forEach((el) => el.classList.remove('rs-hl'));
  const bar = document.getElementById('roadshowBar');
  if (bar) { bar.hidden = true; bar.classList.remove('is-collapsed'); }
  document.body.classList.remove('roadshow-running');
  const label = document.getElementById('projectLabel');
  if (label && ROADSHOW.savedProjectLabel) label.textContent = ROADSHOW.savedProjectLabel;
  roadshowRestoreAiRuntime();
  // 预置档案（昨天）与本次路演记录：退出时回到进入前的档案，避免污染用户自己的项目
  if (Array.isArray(ROADSHOW.savedRecords)) {
    state.records = ROADSHOW.savedRecords;
    ROADSHOW.savedRecords = null;
  }
  ROADSHOW.prepared = false;
  ROADSHOW.preparing = null;
  ROADSHOW.sample = null;
  ROADSHOW.editLayerId = null;
  ROADSHOW.baseLayerId = null;
  ROADSHOW.noteLayerId = null;
  ROADSHOW.appliedPreset = false;
  ROADSHOW.appliedReal = false;
  ROADSHOW.evidence = null;
  ROADSHOW.verify = null;
  try { closeModal('roadshowBrief'); } catch (e) { /* ignore */ }
  try { closePopovers(); } catch (e) { /* ignore */ }
  try { closeLibrarySheet(); } catch (e) { /* ignore */ }
  try { renderAll(); } catch (e) { /* ignore */ }
  try { renderArchiveCount(); } catch (e) { /* ignore */ }
  try { scheduleSave(); } catch (e) { /* ignore */ }
  showToast('已退出路演模式：画布与素材保留，可继续手动编辑；档案已恢复到进入前');
}
function initRoadshowUI() {
  if (initRoadshowUI._bound) return;
  initRoadshowUI._bound = true;
  const on = (id, fn) => { const el = document.getElementById(id); if (!el) return; el.addEventListener('click', (e) => { e.preventDefault(); try { fn(e); } catch (err) { console.warn('[roadshow]', err); } }); };
  on('btnRoadshow', () => { if (ROADSHOW.active) roadshowToggleCollapse(); else openRoadshowBrief(); });
  on('btnRoadshowStart', () => { roadshowStart().catch(() => {}); });
  on('btnRoadshowExitBrief', () => closeModal('roadshowBrief'));
  on('btnRoadshowBriefClose', () => closeModal('roadshowBrief'));
  on('btnRoadshowPrev', () => { roadshowAutoStop('人工切换：自动演示已停'); roadshowPrev(); });
  on('btnRoadshowNext', () => { roadshowAutoStop('人工切换：自动演示已停'); roadshowNext(); });
  on('btnRoadshowExit', () => { roadshowAutoStop(); roadshowExit(); });
  on('btnRoadshowExec', () => { roadshowExecCurrent().catch(() => {}); });
  on('btnRoadshowAuto', () => { roadshowAutoPlay().catch(() => {}); });
  on('btnRoadshowCollapse', () => roadshowToggleCollapse());
  const pips = document.getElementById('roadshowPips');
  if (pips) pips.addEventListener('click', (e) => { const b = e.target && e.target.closest ? e.target.closest('[data-rs-step]') : null; if (b) { roadshowAutoStop('人工跳拍：自动演示已停'); roadshowGoto(parseInt(b.dataset.rsStep, 10)); } });
}

/* ---------------- 一键演示（T120 扩展：20 步完整叙事，像交互动画一样自动推进） ----------------
   结构（与路演讲稿对应）：
   幕A 引擎基础(1-4)：示例画布→笔刷→撤销/重做→图层
   幕B 画到一半(5-6)：继续画几笔→「卡住了」
   幕C 文图双轨(7-9)：说意图→画红圈标注→AI 看（真实/Mock）
   幕D 结合与写回(10-13)：确认/否决→选方向→生成落层→对比滑杆
   幕E 素材库(14-18)：入口→选中→L1/L2→确认写回→插入图层
   幕F 证据(19-20)：撤销 AI 图层（原画无损）→证据包
   规则：AI 步（runAnalyze/runDirections/runGenerate/applyCandidate）为 await 长任务，
   enter 返回 Promise 时演示框架等它完成 + 额外停留，不再被固定时长拦腰切断。 */
const DEMO_STEPS = [
  /* ---- 幕 A · 绘图引擎与基本功能 ---- */
  { title: '打开示例作品', label: '示例画布', narr: '先看一张本地示例作品：整幅画都在你的浏览器里，不上传、不联网。这是我们的自研画布引擎。', target: '#mainCanvas', enter: async () => { closeLibrarySheet(); closeModal('evidenceModal'); await wipeCanvas(); await demoDraw(); } },
  { title: '笔刷：压感与多笔型', label: '笔刷面板', narr: '引擎基础能力：多种笔刷、压感、透明度和流量都可以调——画起来跟专业软件一个手感。', target: '#btnToolBrush', enter: async () => { setTool('brush'); try { openPopover('popBrush'); } catch (e) { /* ignore */ } await demoSketchStroke({ x0: 220, y0: 660, x1: 980, y1: 700, color: '#37424f' }); } },
  { title: '撤销 / 重做：每一步可逆', label: '撤销按钮', narr: '画错不怕：全历史撤销重做，笔迹、图层、蒙版都能回退——这也是后面「AI 改动可撤销」的基础。', target: '#btnUndo', enter: async () => { try { engine.undo(); engine.compositor.compositeAll(engine.store); engine.presentFull && engine.presentFull(); } catch (e) { /* ignore */ } await sleep(1400); try { engine.redo(); engine.compositor.compositeAll(engine.store); engine.presentFull && engine.presentFull(); } catch (e) { /* ignore */ } try { closePopovers(); } catch (e) { /* ignore */ } } },
  { title: '图层：非破坏性编辑', label: '图层面板', narr: '图层面板：新建、编组、蒙版、混合模式。所有编辑都是非破坏性的——原画永远在。', target: '#btnPanelLayers', enter: async () => { try { openPopover('popLayers'); } catch (e) { /* ignore */ } } },
  /* ---- 幕 B · 画到一半，卡住了 ---- */
  { title: '画到一半…', label: '画布', narr: '现在进入真实场景：一张画到一半的图。远山、雾带、近水都有了，但她卡住了——这块雾，不知道往哪走。', target: '#mainCanvas', enter: async () => { try { closePopovers(); } catch (e) { /* ignore */ } setTool('brush'); await demoSketchStroke({ x0: 300, y0: 240, x1: 760, y1: 210, color: '#2c3540' }); await demoSketchStroke({ x0: 340, y0: 520, x1: 860, y1: 560, color: '#424c5a' }); } },
  { title: '以前：切屏、抽卡、再导回来', label: '卡住的雾带', narr: '以前的解法：截图、切屏、打开生图网站、写提示词、抽卡、再导回来——心流断了，还不认识她这张画。现在，她只需要框住卡住的地方。', target: '#canvasWrap', enter: async () => { setTool('select'); state.selection = { x: 620, y: 160, width: 420, height: 320 }; drawSelection(); } },
  /* ---- 幕 C · 文图双轨：用画面跟 AI 沟通 ---- */
  { title: '说意图：一句话', label: '意图输入框', narr: '文图双轨的第一轨——文字：她说「让雾更冷，但保留我的笔触」。意图会随选区一起发给 AI。', target: '#btnAiPanel', enter: async () => { try { openPopover('popAI'); switchAiTab('obs'); } catch (e) { /* ignore */ } state.aiIntent = '让雾更冷，但保留我的笔触'; const ta = document.getElementById('aiIntentInput'); if (ta) ta.value = state.aiIntent; } },
  { title: '画给 AI 看：红圈标注', label: '标注模式', narr: '第二轨——视觉：文字说不清的，直接在画布上圈出来、画个箭头。标注会叠加在选区裁切图上一起发送，AI 看的是「你指的地方」。', target: '#canvasWrap', enter: async () => { try { toggleAnnotationMode(true); } catch (e) { /* ignore */ } await demoDrawAnnotation(); } },
  { title: '让 AI 看看（真实视觉）', label: 'AI 观察浮层', narr: 'AI 读选区裁切图 + 标注 + 她的意图 + 素材档案，给出观察——每一条都能定位回画布，也都能被确认或否决。', target: '#aiBody', aiLong: true, enter: async () => { try { toggleAnnotationMode(false); } catch (e) { /* ignore */ } const r = await runAnalyze(); if (!r) { await roadshowMockObserveIfAny(); } } },
  /* ---- 幕 D · 与 AI 作图结合：确认、方向、落层 ---- */
  { title: '确认 / 否决：写回档案', label: '观察列表', narr: '她的判断就是 AI 的下一次上下文：确认「雾带是视线停留处」，否决「加暖色」——否决不是删掉，是写回档案，AI 下次不再这么建议。', target: '#aiBody', enter: async () => { const obs = (state.analysis && state.analysis.observations) || []; if (obs[0]) confirmObservation(obs[0].id, true); if (obs[1]) confirmObservation(obs[1].id, false); } },
  { title: '方向是建议，由她选', label: 'AI 方向建议', narr: 'AI 给出几个方向，每个都带理由和置信度——但决定权在人：她选「清晨冷雾」，因为客户 brief 就是这么写的。', target: '#aiBody', aiLong: true, enter: async () => { await runDirections(); } },
  { title: '生成：只改框内', label: '生成进度', narr: '按所选方向生成局部方案：只针对选区内容，输出的是 patch，不重绘整图。', target: '#aiBody', aiLong: true, enter: async () => { const d = state.directions && state.directions[0]; await runGenerate(d ? d.id : 'mock-dir-1'); } },
  { title: '落新图层：可编辑可撤销', label: '新图层', narr: '接受的方案落成新图层：可以继续画、可以调、可以一键撤销——AI 从不直接改她的原画。', target: '#canvasWrap', aiLong: true, enter: async () => { if ((state.candidates || []).length) await applyCandidate(0); } },
  /* ---- 幕 E · 素材库：私有视觉记忆怎么起作用 ---- */
  { title: '素材库：私人视觉记忆', label: '素材库入口', narr: '她为什么信任这个方向？因为 AI 认识她的素材库——每张参考图都被读成结构化档案：整体、区域、观察。', target: '#btnLibrary', enter: async () => { await ensureSampleLibrary(); const b = document.getElementById('btnLibrary'); if (b) b.click(); } },
  { title: '选「雾中山谷」', label: '素材网格', narr: '选一张她之前收集的「雾中山谷」：缩略图、标签、AI 已读状态一目了然，右侧是完整档案。', target: '#libGrid', enter: async () => { await ensureSampleLibrary(); const list = state.library.assets || []; const a = list.find((x) => String(x.fileName || '').includes('雾中山谷')) || list[0]; if (a) selectLibraryAsset(a.id); } },
  { title: 'AI 读过整体与区域', label: 'L1/L2 档案', narr: '档案不是文件名：L1 是整体解读（冷灰蓝、低饱和），L2 是区域定位（远山、雾带、近水各有框）——点哪就能定位到哪。', target: '#libDetail', enter: async () => { state.library.highlightRegion = -1; renderLibrary(); const d = document.getElementById('libDetail'); if (d) d.scrollTop = 120; await sleep(1600); const a = libSelectedAsset(); if (a && a.L2 && a.L2.length) { state.library.highlightRegion = 0; renderLibrary(); } } },
  { title: '确认观察：教 AI 懂你', label: 'L4 观察确认', narr: '对档案里的观察点「确认」或「不对」：她的每一次判断都写回档案，成为下次生成的偏好依据——越用越懂她。', target: '#libDetail .lib-obs-actions button.primary', enter: async () => { const a = libSelectedAsset(); if (!a) return; const obs = (a.L4 || [])[0]; if (obs) { const api = await initLibrary(); await api.confirm(a.id, { targetId: obs.id, tags: a.tags || [] }); await refreshLibraryAssets(); await refreshLibraryPrefs(); renderLibrary(); } } },
  { title: '插入画布：成为图层', label: '插入图层按钮', narr: '素材随时可以插入画布当参考层：独立图层、可移动可撤销，原素材像素不会被改写。', target: '#libInsertLayer', enter: async () => { const a = libSelectedAsset(); if (a) await insertAssetLayer(a); try { closeLibrarySheet(); } catch (e) { /* ignore */ } } },
  /* ---- 幕 F · 证据：过程可复核 ---- */
  { title: '不满意？一键撤销', label: '画布', narr: '万一她对 AI 的结果不满意：一键撤销，原画分毫不动——刚才所有 AI 改动都在独立图层上。', target: '#canvasWrap', enter: async () => { try { const layers = engine.getLayers(); for (let i = layers.length - 1; i >= 0; i -= 1) { const l = layers[i]; if (/AI|方案|生成|候选/.test(l.name || '')) { engine.setLayerVisible(l.id, false); engine.compositor.compositeAll(engine.store); engine.presentFull && engine.presentFull(); await sleep(1200); engine.setLayerVisible(l.id, true); engine.compositor.compositeAll(engine.store); engine.presentFull && engine.presentFull(); break; } } } catch (e) { /* ignore */ } } },
  { title: '导出证据包', label: '证据包', narr: '最后导出本地过程记录：事件 SHA-256 链、画布字节哈希、每次 AI 调用的模型与用量。过程可复核——但说清边界：它不是法律鉴定。', target: '#aiBody', enter: async () => { openModal('archiveModal'); await sleep(900); await openEvidence(); } },
];
const DEMO_BASE_MS = 4400;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function roadshowMockObserveIfAny() { try { await roadshowMockObserve(); } catch (e) { /* ignore */ } }
/* 演示用：画一笔（有笔迹动画感），不弹任何面板 */
async function demoSketchStroke(o) {
  const p = presets.brushes[o.brush || 0];
  controller.setPreset(p);
  controller.setColor(hexToRgb(o.color || state.color || '#333333'));
  const t0 = performance.now();
  controller.begin({ x: o.x0, y: o.y0, pressure: 0.3, timestamp: t0 });
  const pts = o.pts || 22;
  for (let i = 1; i <= pts; i += 1) {
    const t = i / pts;
    controller.append({ x: o.x0 + (o.x1 - o.x0) * t, y: o.y0 + (o.y1 - o.y0) * t + Math.sin(t * Math.PI * 2) * 18, pressure: 0.25 + 0.6 * Math.sin(t * Math.PI), timestamp: t0 + i * 16 });
    await sleep(28);
  }
  controller.end();
  engine.compositor.compositeAll(engine.store);
  engine.presentFull && engine.presentFull();
  controller.setPreset(presets.brushes[state.brushIndex]);
  controller.setColor(hexToRgb(state.color));
}
/* 演示用：在选区上画一个红圈 + 箭头（标注层） */
async function demoDrawAnnotation() {
  try {
    const c = document.getElementById('annotationCanvas');
    if (!c) return;
    const ctx = c.getContext('2d');
    const sel = state.selection || { x: 620, y: 160, width: 420, height: 320 };
    const cx = sel.x + sel.width * 0.52, cy = sel.y + sel.height * 0.55, rx = sel.width * 0.26, ry = sel.height * 0.3;
    ctx.strokeStyle = '#ef4444'; ctx.lineWidth = 5; ctx.lineCap = 'round';
    for (let i = 0; i <= 24; i += 1) {
      const a = (i / 24) * Math.PI * 2;
      const x = cx + Math.cos(a) * rx, y = cy + Math.sin(a) * ry;
      if (i === 0) ctx.beginPath(), ctx.moveTo(x, y); else ctx.lineTo(x, y);
      ctx.stroke();
      await sleep(22);
    }
    // 箭头：从右下指向圈心
    const ax0 = sel.x + sel.width * 0.95, ay0 = sel.y + sel.height * 0.95;
    ctx.beginPath(); ctx.moveTo(ax0, ay0);
    for (let i = 1; i <= 10; i += 1) { ctx.lineTo(ax0 + (cx + rx * 0.7 - ax0) * (i / 10), ay0 + (cy + ry * 0.7 - ay0) * (i / 10)); ctx.stroke(); await sleep(25); }
    state.annotationDirty = true;
  } catch (e) { /* ignore */ }
}
function demoStepDuration(step) {
  let d = 4400 + ((step && step.narr || '').length >= 40 ? 400 : 0);
  if (step && step.dwell) d = step.dwell;
  return d;
}
async function demoDraw() {
  const jobs = [
    { brush: 0, pts: 34, x0: 160, y0: 300, x1: 1040, y1: 260, pressure: (t) => 0.2 + 0.75 * Math.sin(t * Math.PI), color: '#232a33' },
    { brush: 1, pts: 26, x0: 200, y0: 430, x1: 980, y1: 470, pressure: (t) => 0.15 + 0.7 * t, color: '#3f4a58' },
    { brush: 4, pts: 22, x0: 260, y0: 560, x1: 900, y1: 610, pressure: () => 0.55, color: '#4a4038' },
  ];
  for (const job of jobs) {
    const p = presets.brushes[job.brush];
    controller.setPreset(p);
    controller.setColor(hexToRgb(job.color));
    const t0 = performance.now();
    controller.begin({ x: job.x0, y: job.y0, pressure: job.pressure(0), timestamp: t0 });
    for (let i = 1; i <= job.pts; i += 1) {
      const t = i / job.pts;
      controller.append({ x: job.x0 + (job.x1 - job.x0) * t, y: job.y0 + (job.y1 - job.y0) * t + Math.sin(t * Math.PI * 2.4) * 28, pressure: job.pressure(t), timestamp: t0 + i * 16 });
    }
    controller.end();
    engine.compositor.compositeAll(engine.store);
    await new Promise((r) => setTimeout(r, 90));
  }
  controller.setPreset(presets.brushes[state.brushIndex]);
  controller.setColor(hexToRgb(state.color));
  await saveSnapshot();
}
function startDemo(reset = true) {
  if (state.demo.active) return;
  if (ROADSHOW.active) { showToast('先退出路演模式，再播一键演示', true); return; }
  closeLibrarySheet();
  closeModal('evidenceModal');
  closeModal('archiveModal');
  $('demoEnd').style.display = 'none';
  if (reset) {
    state.demo.snapshot = null;
    state.demo.savedRecords = state.records.slice();
    state.demo.savedMode = state.mode;
    state.demo.step = 0;
    state.demo.takenOver = false;
    try { engine.pauseHistory(); state.demo.historyPaused = true; } catch (e) { state.demo.historyPaused = false; }
  }
  state.demo.active = true;
  state.demo.paused = false;
  document.body.classList.add('demo-running');
  $('demoBar').style.display = 'flex';
  $('demoNarr').style.display = 'block';
  $('btnDemoPause').textContent = '⏸ 暂停';
  runDemoStep(state.demo.step);
}
function runDemoStep(index) {
  const total = DEMO_STEPS.length;
  const safe = clamp(index, 0, total - 1);
  const step = DEMO_STEPS[safe];
  state.demo.step = safe;
  clearTimeout(state.demo.timer);
  // T120-fix：代际 token——手动跳步/暂停恢复后，旧的 aiLong 异步链不再把步骤拉回去
  const myToken = (state.demo.token = (state.demo.token || 0) + 1);
  const stillMine = () => state.demo.active && !state.demo.takenOver && state.demo.token === myToken && state.demo.step === safe;
  $('demoStepLabel').textContent = (safe + 1) + ' / ' + total;
  $('demoNarrStep').textContent = String(safe + 1).padStart(2, '0') + ' / ' + String(total).padStart(2, '0');
  $('demoNarrTitle').textContent = step.title || '';
  $('demoNarrText').textContent = step.narr || '';
  $('demoProgressBar').style.width = (((safe + 1) / total) * 100) + '%';
  $('demoNarrHint').textContent = state.demo.paused ? '已暂停 · 点「继续」恢复自动播放，或点「接管」自由操作' : '自动播放 · ' + (demoStepDuration(step) / 1000).toFixed(1) + ' 秒后进入下一步';
  const np = $('demoNarrProgress');
  if (np) { np.style.animation = 'none'; void np.offsetWidth; np.style.animation = 't87-card-progress ' + demoStepDuration(step) + 'ms linear forwards'; np.style.animationPlayState = state.demo.paused ? 'paused' : 'running'; }
  $('btnDemoPause').textContent = state.demo.paused ? '▶ 继续' : '⏸ 暂停';
  $('btnDemoPrev').disabled = safe === 0;
  positionSpotlight(step.target, step.label);
  const scrim = $('demoScrim'); if (scrim) scrim.style.display = state.demo.paused ? 'none' : 'block';
  // T120：aiLong 步（真实 AI 调用）必须等执行完再走下一步，不被固定时长拦腰切断
  if (step.aiLong) {
    $('demoNarrHint').textContent = state.demo.paused ? '已暂停 · 点「继续」恢复自动播放，或点「接管」自由操作' : 'AI 实机执行中 · 完成后自动进入下一步';
    const npL = $('demoNarrProgress'); if (npL) npL.style.animation = 'none';
    Promise.resolve(step.enter && step.enter())
      .catch((e) => console.warn('[demo]', e))
      .then(() => sleep(2200))
      .then(() => {
        if (!stillMine()) return; // T120-fix：用户已手动跳步/接管/退出/切到别的步——本链作废，绝不把步骤拉回去
        if (state.demo.paused) { // 暂停中：等用户点继续（pauseDemo 的恢复逻辑会读 resumePending）
          state.demo.resumePending = true; return;
        }
        if (safe >= total - 1) endDemo(); else runDemoStep(safe + 1);
      });
    return;
  }
  Promise.resolve(step.enter && step.enter()).catch((e) => console.warn('[demo]', e));
  if (!state.demo.paused) {
    state.demo.timer = setTimeout(() => {
      if (!stillMine()) return;
      if (safe >= total - 1) endDemo(); else runDemoStep(safe + 1);
    }, demoStepDuration(step));
  }
}
function pauseDemo(showTip) {
  if (!state.demo.active) return;
  state.demo.paused = !state.demo.paused;
  $('btnDemoPause').textContent = state.demo.paused ? '▶ 继续' : '⏸ 暂停';
  if (state.demo.paused) {
    clearTimeout(state.demo.timer);
    const scrim = $('demoScrim'); if (scrim) scrim.style.display = 'none';
    $('demoNarrHint').textContent = '已暂停 · 点「继续」恢复自动播放，或点「接管」自由操作';
    if (showTip) showToast('演示已暂停：可以点「接管」自由编辑');
    const np = $('demoNarrProgress'); if (np) np.style.animationPlayState = 'paused';
  } else {
    const scrim = $('demoScrim'); if (scrim) scrim.style.display = 'block';
    const step = DEMO_STEPS[state.demo.step];
    // T120：aiLong 步在等待期间被暂停 → 恢复时直接进下一步（任务已完成）
    if (state.demo.resumePending) {
      state.demo.resumePending = false;
      clearTimeout(state.demo.timer);
      if (state.demo.step >= DEMO_STEPS.length - 1) endDemo(); else runDemoStep(state.demo.step + 1);
      return;
    }
    $('demoNarrHint').textContent = '自动播放 · ' + (demoStepDuration(step) / 1000).toFixed(1) + ' 秒后进入下一步';
    const np2 = $('demoNarrProgress'); if (np2) np2.style.animationPlayState = 'running';
    clearTimeout(state.demo.timer);
    const tokNow = state.demo.token; // T120-fix：恢复后若 aiLong 链先推进了，这个定时器作废，避免双推进跳步
    state.demo.timer = setTimeout(() => { if (!state.demo.active || state.demo.token !== tokNow) return; if (state.demo.step >= DEMO_STEPS.length - 1) endDemo(); else runDemoStep(state.demo.step + 1); }, demoStepDuration(step));
  }
}
function resumeDemoHistory() {
  if (!state.demo.historyPaused) return;
  state.demo.historyPaused = false;
  try { engine.resumeHistory(); } catch (e) { /* ignore */ }
}
function endDemo() {
  state.demo.active = false;
  clearTimeout(state.demo.timer);
  resumeDemoHistory();
  document.body.classList.remove('demo-running');
  $('demoBar').style.display = 'none';
  $('demoNarr').style.display = 'none';
  $('demoSpotlight').style.display = 'none';
  $('demoScrim').style.display = 'none';
  closeModal('archiveModal');
  $('demoEndStep').textContent = '演示完成 · ' + DEMO_STEPS.length + ' / ' + DEMO_STEPS.length;
  const end = $('demoEnd'); end.style.display = 'block'; end.classList.add('done');
}
function takeoverDemo() {
  if (!state.demo.active && $('demoEnd').style.display !== 'block') { showToast('演示已结束；点顶部演示按钮可重播'); return; }
  resumeDemoHistory();
  state.demo.active = false;
  state.demo.paused = true;
  state.demo.takenOver = true;
  clearTimeout(state.demo.timer);
  document.body.classList.remove('demo-running');
  $('demoBar').style.display = 'none';
  $('demoNarr').style.display = 'none';
  $('demoSpotlight').style.display = 'none';
  $('demoScrim').style.display = 'none';
  $('demoEnd').style.display = 'none';
  showToast('已接管画布：可以自由编辑、撤销；点顶部「演示」可重播');
}
async function exitDemo() {
  state.demo.active = false;
  state.demo.paused = false;
  state.demo.takenOver = false;
  resumeDemoHistory();
  closeLibrarySheet();
  state.aiReference = null;
  state.assetLayerRefs = new Map();
  renderAIReferenceBar && renderAIReferenceBar();
  clearTimeout(state.demo.timer);
  document.body.classList.remove('demo-running');
  $('demoBar').style.display = 'none';
  $('demoNarr').style.display = 'none';
  $('demoEnd').style.display = 'none';
  $('demoSpotlight').style.display = 'none';
  $('demoScrim').style.display = 'none';
  closeModal('archiveModal'); closeModal('evidenceModal');
  if (state.demo.savedRecords) state.records = state.demo.savedRecords;
  if (state.demo.savedMode) { state.mode = state.demo.savedMode; applyAttestUI(state.mode === 'attest'); }
  renderAll();
  await wipeCanvas();
  await restoreSnapshot();
}
function positionSpotlight(sel, label) {
  const el = sel && document.querySelector(sel);
  const sp = $('demoSpotlight');
  const lb = $('demoSpotlightLabel');
  if (!el) { sp.style.display = 'none'; if (lb) lb.textContent = ''; return; }
  const r = el.getBoundingClientRect();
  const pad = 8;
  sp.style.display = 'block';
  sp.style.left = Math.max(6, r.left - pad) + 'px';
  sp.style.top = Math.max(6, r.top - pad) + 'px';
  sp.style.width = Math.min(window.innerWidth - 12, r.width + pad * 2) + 'px';
  sp.style.height = Math.min(window.innerHeight - 12, r.height + pad * 2) + 'px';
  const right = r.top < 60;
  const below = !right && (r.top - pad) < 44;
  sp.classList.toggle('label-right', right);
  sp.classList.toggle('label-below', below);
  if (lb) lb.textContent = label || '';
}

/* ---------------- 渲染全部 / 绑定 ---------------- */
function renderAll() {
  renderLayers();
  renderArchiveCount();
  renderAIPanel();
  renderBrushGrid();
  renderGuideCanvas();
  renderArchive();
  $('statusModeText').textContent = state.mode === 'attest' ? '存证模式 · AI 禁用 · 证据包 zero_generation' : '协作模式 · AI 可参与局部方案';
  $('statusLayers').textContent = `图层 ${engine.layers.length}`;
  $('statusStrokes').textContent = `笔触 ${state.strokes}`;
  updateHeadHash().catch(() => {});
}
function bindUI() {
  bindCanvasGuards();
  applyIcons(document);
  bindModals();
  document.getElementById('btnPanelLayers').addEventListener('click', () => togglePopover('popLayers'));
  document.getElementById('btnPanelColor').addEventListener('click', () => togglePopover('popColor'));
  document.getElementById('btnAiPanel').addEventListener('click', () => togglePopover('popAI'));
  document.getElementById('btnMore').addEventListener('click', () => togglePopover('popMore'));
  document.querySelectorAll('.ai-tab').forEach((b) => b.addEventListener('click', () => switchAiTab(b.dataset.aiTab)));
  document.querySelectorAll('[data-record-tab]').forEach((b) => b.addEventListener('click', () => setRecordSubtab(b.dataset.recordTab)));
  const aiBadge = document.getElementById('aiProviderBadge'); if (aiBadge) { aiBadge.title = '查看模型与能力'; aiBadge.addEventListener('click', () => switchAiTab('model')); }
  const evRefresh = document.getElementById('btnAiEvidenceRefresh');
  if (evRefresh) evRefresh.addEventListener('click', () => renderAiEvidence());
  document.addEventListener('pointerdown', (e) => {
    if (!activePopoverId) return;
    const pop = document.getElementById(activePopoverId);
    if (!pop) return;
    if (pop.contains(e.target)) return;
    if (e.target.closest && e.target.closest('.pro-topbar')) { setTimeout(closePopovers, 0); return; }
    if (state.annotationMode || state.tool === 'text') { closePopovers(); return; } // 标注/文字模式：关闭面板但让事件继续到画布
    if (state.spaceDown || state.tool === 'move') { closePopovers(); return; } // 平移手势优先：不要让关闭浮层吞掉拖拽
    e.preventDefault();
    e.stopPropagation();
    closePopovers();
  }, true);
  window.addEventListener('resize', () => { const pop = activePopoverId ? document.getElementById(activePopoverId) : null; if (pop) positionPopover(pop); });
  renderSwatches();
  setBrushColor(state.color, { silent: true });
  bindViewControls();
  const sz = document.getElementById('statusZoom');
  if (sz) sz.addEventListener('dblclick', () => zoomTo100());
  $('btnUndo').addEventListener('click', () => { engine.undo(); renderAll(); });
  $('btnRedo').addEventListener('click', () => { engine.redo(); renderAll(); });
  $('btnArchive').addEventListener('click', () => { renderArchive(); openModal('archiveModal'); });
  $('btnEvidence').addEventListener('click', () => openEvidence());
  $('btnAbout').addEventListener('click', () => { closePopovers(); refreshPresentStatusUI(); openModal('aboutModal'); refreshAiConfig({ keepPreset: true }).catch(() => {}); });
  $('btnAiSettings').addEventListener('click', openAiSettingsPanel);
  const aiClose = document.getElementById('btnAiClose');
  if (aiClose) aiClose.addEventListener('click', () => closePopovers());
  const chipAsk = document.getElementById('btnSelectionAsk');
  if (chipAsk) chipAsk.addEventListener('click', () => { openPopover('popAI'); runAnalyze(); });
  const chipAnno = document.getElementById('btnSelectionAnnotate');
  if (chipAnno) chipAnno.addEventListener('click', () => toggleAnnotationMode(true));
  const aiCancelBtn = document.getElementById('btnAiCancel');
  if (aiCancelBtn) aiCancelBtn.addEventListener('click', cancelAiRequest);
  $('btnAskAi').addEventListener('click', () => runAnalyze().then((r) => { if (r) showToast('AI 已给出观察 · ' + aiProviderLabel(state.aiLastCall) + ' / ' + (state.aiLastCall && (state.aiLastCall.model || state.aiLastCall.modelVersion) || aiRuntimeModel())); }));
  $('btnIgnoreArchive').addEventListener('click', () => { state.ignoreArchive = !state.ignoreArchive; $('btnIgnoreArchive').classList.toggle('active', state.ignoreArchive); showToast(state.ignoreArchive ? '本次 AI 请求不参考档案（D4）' : '已恢复参考档案'); });
  $('modeSwitch').addEventListener('click', (e) => { const b = e.target.closest('.mode-opt'); if (b) setMode(b.dataset.mode); });
  $('btnToggleAttest').addEventListener('click', () => setMode(state.mode === 'attest' ? 'collab' : 'attest'));
  $('btnClearLocal').addEventListener('click', () => { localStorage.removeItem(LS_RECORDS); localStorage.removeItem(LS_SNAPSHOT); state.records = []; renderAll(); showToast('本地数据已清空（刷新后生效）'); });
  $('btnDownloadJson').addEventListener('click', downloadJson);
  $('btnDownloadPng').addEventListener('click', () => downloadPng().catch((e) => showToast(e.message, true)));
  $('btnExportBoth').addEventListener('click', () => exportBoth().catch((e) => showToast(e.message, true)));
  $('btnExportPng').addEventListener('click', () => downloadPng().catch((e) => showToast(e.message, true)));
  $('btnLoadExample').addEventListener('click', async () => { await wipeCanvas(); startDemo(true); });
  $('btnClearCanvas').addEventListener('click', async () => { await wipeCanvas(); showToast('画布已清空'); });
  $('btnDemo').addEventListener('click', () => startDemo(true));
  $('btnDemoPrev').addEventListener('click', () => { if (state.demo.step > 0) runDemoStep(state.demo.step - 1); });
  $('btnDemoTakeover').addEventListener('click', () => takeoverDemo());
  $('demoScrim').addEventListener('click', () => { if (state.demo.active) takeoverDemo(); });
  $('btnDemoNext').addEventListener('click', () => { if (state.demo.step < DEMO_STEPS.length - 1) runDemoStep(state.demo.step + 1); else endDemo(); });
  $('btnDemoPause').addEventListener('click', () => pauseDemo(false));
  $('btnDemoExit').addEventListener('click', () => exitDemo());
  $('btnDemoReplay').addEventListener('click', () => { $('demoEnd').style.display = 'none'; startDemo(true); });
  $('btnDemoEndTry').addEventListener('click', () => takeoverDemo());
  $('btnDemoEndRestore').addEventListener('click', () => exitDemo());
  document.querySelectorAll('.pro-topbar [data-tool]').forEach((b) => b.addEventListener('click', () => { setTool(b.dataset.tool); if (b.dataset.tool === 'brush') togglePopover('popBrush'); }));
  bindBrushControls();
  bindSimPressureControls();
  updateSimPressureUI();
  bindLayerControls();
  bindProjectControls();
  bindTransformControls();
  initTooltips();
  document.querySelectorAll('[data-shape]').forEach((b) => b.addEventListener('click', () => { state.shapeType = b.dataset.shape || 'rect'; updateToolOptions(); }));
  bindLibraryControls();
  bindAsyncTaskControls();
  initAiSettings();
  $('docSize').textContent = `${engine.width} × ${engine.height}`;
  window.addEventListener('resize', fitView);
  window.addEventListener('keydown', (e) => {
    const key = (e.key || '').toLowerCase();
    const inField = /^(INPUT|SELECT|TEXTAREA)$/.test((e.target && e.target.tagName) || '') || e.isComposing;
    if (e.code === 'Space' && !inField && !state.demo.active) e.preventDefault(); // 空格平移画布，不触发页面滚动/按钮激活
    if (key === 'escape') {
      e.preventDefault();
      const aiConfirmEl = document.getElementById('aiConfirmModal');
      if (aiConfirmEl && aiConfirmEl.classList.contains('show')) { closeModal('aiConfirmModal'); return; }
      if (state.library.open) { closeLibrarySheet(); return; }
      if (state.annotationMode) { toggleAnnotationMode(false); return; }
      if (textComposerEl) { closeTextComposer(); return; }
      if (state.voiceRec) { try { state.voiceRec.stop(); } catch (e) { /* ignore */ } state.voiceRec = null; }
      if (state.transformActive) { cancelTransformUI(); return; }
      if (activePopoverId) { closePopovers(); return; }
      if (ROADSHOW.active) {
        if (document.querySelector('.modal-mask.show')) { closeModal('evidenceModal'); closeModal('archiveModal'); closeModal('aboutModal'); closeModal('roadshowBrief'); return; }
        roadshowExit();
        return;
      }
      if (state.demo.active) { exitDemo(); return; }
      if (state.tool === 'select' || state.tool === 'transform' || state.tool === 'move' || state.tool === 'eyedropper') { setTool('brush'); return; }
      closeModal('archiveModal'); closeModal('evidenceModal'); closeModal('aboutModal');
      return;
    }
    const overlayOpen = state.library.open || !!document.querySelector('.modal.show');
    if (overlayOpen && !inField) return;
    if (e.ctrlKey && key === 'z') { e.preventDefault(); if (state.strokeActive) { showToast('正在绘制，先抬笔再撤销', true); return; } e.shiftKey ? engine.redo() : engine.undo(); syncTextLayersFromEngine(); renderAll(); return; }
    if (e.ctrlKey && key === 'y') { e.preventDefault(); if (state.strokeActive) { showToast('正在绘制，先抬笔再重做', true); return; } engine.redo(); syncTextLayersFromEngine(); renderAll(); return; }
    if (e.ctrlKey && key === 'j') { e.preventDefault(); duplicateLayerUI(); return; }
    if (e.ctrlKey && key === 'c' && !e.shiftKey) { e.preventDefault(); copySelectionPixels(false); return; }
    if (e.ctrlKey && key === 'x' && !e.shiftKey) { e.preventDefault(); copySelectionPixels(true); return; }
    if (e.ctrlKey && key === 'v' && !e.shiftKey) { e.preventDefault(); pasteClipboardPixels(); return; }
    if (e.ctrlKey && key === 's') { e.preventDefault(); saveSnapshot().then(() => showToast('画布快照已保存')); return; }
    if (e.ctrlKey && e.shiftKey && key === 'e') { e.preventDefault(); openPopupEvidence(); return; }
    if (e.ctrlKey && (e.key === '[' || e.key === ']')) {
      e.preventDefault();
      const cur = controller.preset.opacity.base;
      window.__setBrushOpacity && window.__setBrushOpacity(cur + (e.key === ']' ? 5 : -5) / 100);
      return;
    }
    if (!inField && e.ctrlKey && !e.shiftKey && e.key === ';') { e.preventDefault(); state.showGrid = !state.showGrid; syncGuideUI(); renderGuideCanvas(); return; }
    if (!inField && e.ctrlKey && !e.shiftKey && (e.key === "'" || e.code === 'Quote')) { e.preventDefault(); state.showThirds = !state.showThirds; syncGuideUI(); renderGuideCanvas(); return; }
    if (!inField && e.ctrlKey && e.shiftKey && e.key === ';') { e.preventDefault(); const order = [null, 'x', 'y', 'both']; state.symmetryAxis = order[(order.indexOf(state.symmetryAxis) + 1) % order.length]; syncGuideUI(); renderGuideCanvas(); return; }
    if (e.ctrlKey && (key === 'd' || key === 'D')) { e.preventDefault(); clearSelectionUI(); return; }
    if (e.ctrlKey) return;
    if (inField) return;
    if (key === '/' && state.library.open) { e.preventDefault(); const si = document.getElementById('libSearch'); if (si) si.focus(); return; }
    if (state.demo.active) {
      if (e.key === 'ArrowRight') { e.preventDefault(); $('btnDemoNext').click(); return; }
      if (e.key === 'ArrowLeft') { e.preventDefault(); $('btnDemoPrev').click(); return; }
      if (e.key === ' ') { e.preventDefault(); pauseDemo(false); return; }
      takeoverDemo();
    }
    if (key === 'b') { setTool('brush'); return; }
    if (key === 'e') { setTool('eraser'); return; }
    if (key === 's') { setTool(state.tool === 'smudge' ? 'brush' : 'smudge'); return; }
    if (e.key === 'Enter') { if (state.transformActive) { e.preventDefault(); commitTransformUI(); } return; }
    if (key === 'm') { state.selectionMode = e.shiftKey ? 'ellipse' : 'rect'; setTool('select'); return; }
    if (key === 'l') { state.selectionMode = 'lasso'; setTool('select'); return; }
    if (key === 'w') { state.selectionMode = 'wand'; setTool('select'); return; }
    if (key === 'v') { setTool('transform'); return; }
    if (key === 'u') { setTool('shape'); return; }
    if (key === 't') { setTool('text'); return; }
    if (key === 'h') { setTool(state.tool === 'move' ? 'brush' : 'move'); return; }
    if (key === 'i') { $('btnEyedropper').click(); return; }
    if (e.key === '[' || e.key === ']') { e.preventDefault(); const cur = controller.preset.size.base; window.__setBrushSize && window.__setBrushSize(cur + (e.key === ']' ? (e.shiftKey ? 10 : 5) : -(e.shiftKey ? 10 : 5))); return; }
    if (e.key === '0') { e.preventDefault(); fitView(); resetView(); return; }
    if (e.key === '1') { e.preventDefault(); zoomTo100(); return; }
    if (e.key === '+' || e.key === '=') { e.preventDefault(); zoomBy(1.2); return; }
    if (e.key === '-') { e.preventDefault(); zoomBy(1 / 1.2); return; }
    if (key === 'f') { toggleFullscreen(); return; }
    if (e.key === 'Tab') { e.preventDefault(); document.getElementById('app').classList.toggle('ui-hidden'); return; }
    if (e.key === '?' || e.key === 'F1') { e.preventDefault(); openPopover('popMore'); return; }
    if (/^[0-9]$/.test(e.key)) { const v = e.key === '0' ? 1 : parseInt(e.key, 10) / 10; window.__setBrushOpacity && window.__setBrushOpacity(v); return; }
  });
  document.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => closeModal(b.dataset.close)));
  initRoadshowUI();
}

function updateDebugBadge() {
  const badge = document.getElementById('debugBadge');
  if (!badge) return;
  let providerId = '?';
  try { providerId = engine && engine.getBrushProvider ? engine.getBrushProvider().id : '?'; } catch (e) { providerId = 'err'; }
  const st = engine ? engine.getStats() : null;
  badge.textContent =
    'DEBUG · ' + location.pathname + '\n' +
    'engine.ready=' + (engine && engine.ready) + ' · CanvasKit=' + (engine && engine.CK ? 'OK' : 'NULL') + '\n' +
    'provider=' + providerId + ' · tool=' + state.tool + '\n' +
    'pointerdown=' + state.pointerdowns + ' · last=' + JSON.stringify(state.lastPointer) + '\n' +
    'strokes=' + state.strokes + ' · undo=' + (st ? st.undoDepth : '?') + ' · tiles=' + (st ? st.tileCount : '?') + '\n' +
    'canvas=' + (mainCanvas ? mainCanvas.width + 'x' + mainCanvas.height + ' css=' + mainCanvas.style.width + 'x' + mainCanvas.style.height : '?') + '\n' +
    'records=' + state.records.length + ' · mode=' + state.mode + '\n' +
    'lastError=' + (state.lastError || (window.__P1P2_ERROR__ || 'none'));
  badge.style.borderColor = (engine && engine.ready) ? '#334155' : '#991b1b';
}
window.__APP_DEBUG__ = () => {
  try { return { ready: !!(engine && engine.ready), ck: !!(engine && engine.CK), provider: engine && engine.getBrushProvider ? engine.getBrushProvider().id : null, tool: state.tool, pointerdowns: state.pointerdowns, lastPointer: state.lastPointer, strokes: state.strokes, undo: engine ? engine.getStats().undoDepth : null, tiles: engine ? engine.getStats().tileCount : null, canvas: mainCanvas ? { w: mainCanvas.width, h: mainCanvas.height, cssW: mainCanvas.style.width, cssH: mainCanvas.style.height, rect: mainCanvas.getBoundingClientRect() } : null, records: state.records.length, mode: state.mode, lastError: state.lastError }; } catch (e) { return { error: String(e) }; }
};

/* ---------------- 启动 ---------------- */
(async function main() {
  try {
    loadStored();
    loadAiMemory();
    await initEngine();
    bindUI();
    bindQuickStart();
    renderAll();
    setMode(state.mode, { silent: true, force: true });
    $('statusHint').textContent = '就绪：拖动绘制 · 框选后让 AI 看看 · 一键演示 12 步';
    $('saveState').textContent = '已保存';
    window.__V2_APP__ = { engine, get controller() { return controller; }, state, get records() { return state.records; }, runAnalyze, confirmObservation, runDirections, runGenerate, applyCandidate, buildEvidence, setMode, startDemo, exitDemo, takeoverDemo, applySimPressure, updateSimPressureUI, setTool, openPopover, closePopovers, togglePopover, getActivePopover: () => activePopoverId, view, resetView, setBrushColor, switchAiTab, zoomTo100, snapDocPoint, quickStartBlank, showQuickStart: () => maybeShowQuickStart(), debugWait: { begin: aiBeginTask, end: aiEndTask },
    roadshowDebug: () => ({ active: ROADSHOW.active, step: ROADSHOW.step, busy: ROADSHOW.busy, auto: ROADSHOW.auto, doneCount: Object.values(ROADSHOW.done || {}).filter(Boolean).length, lastError: ROADSHOW.lastError || null, editSource: ROADSHOW.editSource || null }),
    copySelectionPixels, pasteClipboardPixels, drawSelection, enterImageTransformUI, importImageFileToCanvas, commitTransformUI, cancelTransformUI, cancelAiRequest, pixelClipboard, validateRecord: validateArchiveRecord, get aiSession() { return state.aiSession; }, toggleAnnotationMode, clearAnnotationInk, annotationInk, aiSelectionCrop, locateObservation, toggleAiCanvasOverlay, renderAiCanvasOverlay, runChat, get aiChat() { return state.aiChat; }, previewCandidate, clearCandidatePreview,
    t101: {
      renderAI: () => renderAIPanel(),
      openAI: () => openPopover('popAI'),
    },
    t96: {
      getState: () => ({ preset: aiRuntime.preset, config: aiRuntime.config, configError: aiRuntime.configError, allowReal: aiRuntime.allowReal, requireConfirm: aiRuntime.requireConfirm, privacyMode: aiRuntime.privacyMode, hasKey: aiRuntime.hasKey, realEligible: aiRealEligible(), label: aiProviderLabel(), lastCall: state.aiLastCall }),
      setToggles: (t = {}) => { if (t.allowReal !== undefined) aiRuntime.allowReal = !!t.allowReal; if (t.requireConfirm !== undefined) aiRuntime.requireConfirm = !!t.requireConfirm; if (t.privacyMode !== undefined) aiRuntime.privacyMode = !!t.privacyMode; saveAiLocalSettings(); renderAiSettings(); renderAiProviderBadge(); return { allowReal: aiRuntime.allowReal, requireConfirm: aiRuntime.requireConfirm, privacyMode: aiRuntime.privacyMode }; },
      setPreset: (id) => { if (AI_PRESETS[id]) aiRuntime.preset = id; saveAiLocalSettings(); renderAiSettings(); return aiRuntime.preset; },
      refreshConfig: () => refreshAiConfig(),
      saveConfig: () => saveAiConfigFromUI(),
      testConnection: () => testAiConnection(),
      clearKey: () => clearAiKeyFromUI(),
      confirmPending: () => !!aiRuntime.confirmResolver,
      getLastCall: () => state.aiLastCall,
      getPresets: () => AI_PRESETS,
      getSettings: () => ({ preset: aiRuntime.preset, hasKey: aiRuntime.hasKey, allowReal: aiRuntime.allowReal, requireConfirm: aiRuntime.requireConfirm, privacyMode: aiRuntime.privacyMode, configError: aiRuntime.configError }),
      getL6AiCalls: () => state.records.filter((r) => r.layer === 'L6' && r.kind === 'critique').map((r) => ({ model: r.model, params: r.params, latency_ms: r.latency_ms, usage: r.usage })),
      providerBadge: () => (document.getElementById('aiProviderBadge') || {}).textContent || '',
    },
    t90: {
      applyPresentStrategy: () => applyPresentStrategyForSize(engine.width, engine.height),
      applyPresentStrategyForSize: (w, h) => { const r = applyPresentStrategyForSize(w, h); return r; },
      decide: (w, h) => presentPolicyForSize(w, h),
      get: () => ({ strategy: typeof engine.getPresentStrategy === 'function' ? engine.getPresentStrategy() : 'full', retained: !!engine.presentSurface, stats: typeof engine.getPresentStats === 'function' ? engine.getPresentStats() : null, area: engine.width * engine.height }),
      setStrategy: (m) => { const r = engine.setPresentStrategy(m); engine.presentFull(); refreshPresentStatusUI(); return r; },
      refreshStatus: () => refreshPresentStatusUI(),
    },
    t85: {
      enterLayerMask: (layerId) => {
        const l = engine.getLayers().find((x) => x.id === layerId) || engine.getLayers()[0];
        engine.setActiveLayer(l.id); engine.setLayerLocked(l.id, false);
        if (!l.mask || !l.mask.exists) engine.addMask(l.id);
        engine.setMaskEnabled(l.id, true);
        engine.setActiveTarget('mask'); syncMaskPaintUI(); setupBrushInput(); renderLayers();
        return { layerId: l.id, target: engine.getActiveTarget(), paint: engine.getMaskStrokePaint ? engine.getMaskStrokePaint() : null };
      },
      enterGroupMask: (groupId) => {
        editGroupMaskUI(groupId);
        return { target: engine.getActiveTarget(), paint: engine.getMaskStrokePaint ? engine.getMaskStrokePaint() : null };
      },
      exitMask: () => { engine.setActiveTarget('layer'); if (engine.setMaskStrokePaint) engine.setMaskStrokePaint('white'); setupBrushInput(); renderLayers(); return engine.getActiveTarget(); },
      getMaskPaint: () => engine.getMaskStrokePaint ? engine.getMaskStrokePaint() : null,
      setMaskPaint: (m) => engine.setMaskStrokePaint ? engine.setMaskStrokePaint(m) : null,
      activeTarget: () => engine.getActiveTarget(),
      maskStats: (id) => {
        const map = engine.maskStore && engine.maskStore.layers.get(id);
        if (!map) return { tiles: 0, meanAlpha: 0, darkFraction: 0, samples: 0 };
        let sum = 0, dark = 0, samples = 0;
        for (const tile of map.values()) {
          let px; try { px = engine._readTileRGBA(tile); } catch (e) { continue; }
          for (let i = 3; i < px.length; i += 4 * 17) { const a = px[i]; sum += a; if (a < 128) dark += 1; samples += 1; }
        }
        return { tiles: map.size, meanAlpha: samples ? Math.round(sum / samples) : 0, darkFraction: samples ? Math.round((dark / samples) * 1000) / 1000 : 0, samples };
      },
      layerMaskStats: (id) => {
        const map = engine.maskStore && engine.maskStore.layers.get(id);
        return { tiles: map ? map.size : 0 };
      },
      compositeDataUrl: () => engine.getCompositeDataUrl(),
    },
    t82: {
      startDemo, exitDemo, takeoverDemo, pauseDemo, runDemoStep,
      next: () => { if (state.demo.step < DEMO_STEPS.length - 1) runDemoStep(state.demo.step + 1); else endDemo(); },
      prev: () => { if (state.demo.step > 0) runDemoStep(state.demo.step - 1); },
      steps: () => DEMO_STEPS.map((x) => ({ title: x.title, desc: x.narr, label: x.label, target: x.target, duration: demoStepDuration(x) })),
      state: () => ({ active: state.demo.active, paused: state.demo.paused, takenOver: !!state.demo.takenOver, step: state.demo.step, total: DEMO_STEPS.length, evidenceOpen: !!document.querySelector('#evidenceModal.show'), endVisible: $('demoEnd').style.display === 'block' }),
      stepCount: () => DEMO_STEPS.length,
    },
    t122: {
      openBrief: openRoadshowBrief,
      start: () => roadshowStart(),
      exit: () => roadshowExit(),
      exec: () => roadshowExecCurrent(),
      goto: (i) => roadshowGoto(i),
      autoPlay: () => roadshowAutoPlay(),
      autoStop: () => roadshowAutoStop(),
      steps: () => RS_STEPS.map((s) => ({ id: s.id, no: s.n, title: s.title, hint: s.hint, budget: s.budget, target: s.target, exec: s.exec })),
      state: () => ({
        active: ROADSHOW.active, step: ROADSHOW.step, prepared: ROADSHOW.prepared, busy: ROADSHOW.busy, error: ROADSHOW.error,
        canvas: engine ? { width: engine.width, height: engine.height } : null,
        selection: state.selection ? { ...state.selection } : null,
        engineHasSelection: !!(engine && typeof engine.hasSelection === 'function' && engine.hasSelection()),
        layers: (engine ? engine.layers : []).map((l) => ({ id: l.id, name: l.name, tileCount: engine.store.count(l.id) })),
        baseLayerId: ROADSHOW.baseLayerId, noteLayerId: ROADSHOW.noteLayerId, editLayerId: ROADSHOW.editLayerId,
        appliedPreset: ROADSHOW.appliedPreset, appliedReal: ROADSHOW.appliedReal,
        editSource: ROADSHOW.editSource || null,
        sample: ROADSHOW.sample ? { file: ROADSHOW.sample.meta && ROADSHOW.sample.meta.file, sha256: ROADSHOW.sample.sha256, model: ROADSHOW.sample.meta && ROADSHOW.sample.meta.model } : null,
        libCount: ROADSHOW.libCount,
        lib: { base: ROADSHOW.lib && ROADSHOW.lib.base ? ROADSHOW.lib.base.id : null, edit: ROADSHOW.lib && ROADSHOW.lib.edit ? ROADSHOW.lib.edit.id : null, paper: ROADSHOW.lib && ROADSHOW.lib.paper ? ROADSHOW.lib.paper.id : null },
        l6Preset: (state.records || []).filter((r) => r.layer === 'L6' && r.params && r.params.preset_sample).length,
        l6Total: (state.records || []).filter((r) => r.layer === 'L6').length,
        decisions: ROADSHOW.decisions ? ROADSHOW.decisions.slice() : null,
        l5Ids: ROADSHOW.l5Ids.slice(),
        stats: roadshowStats(),
        badge: roadshowBadgeInfo(),
        verify: ROADSHOW.verify,
        evidence: ROADSHOW.evidence ? { eventCount: ROADSHOW.evidence.manifest.event_count, head: ROADSHOW.evidence.manifest.head_hash, canvas: ROADSHOW.evidence.project.canvas } : null,
        realEligible: aiRealEligible(),
        aiSettings: (() => { try { return JSON.parse(localStorage.getItem(AI_SETTINGS_KEY) || 'null'); } catch (e) { return null; } })(),
      }),
      prepare: () => roadshowPrepare(),
      applySelection: () => roadshowApplyRealSelection(false),
      applyPreset: () => roadshowApplyPresetSample(),
      // T119：真实彩排测试钩子（test-roadshow-real.mjs 用）；UI 上同一能力由第 5 拍「真实提交」按钮触发
      realEdit: () => roadshowRealEdit(),
      buildEvidence: () => rsStepEvidence(),
      verifyEvidence: () => roadshowVerifyEvidence(ROADSHOW.evidence || state.evidence),
      badge: () => roadshowBadgeInfo(),
      stats: () => roadshowStats(),
    },
    t81: {
      saveProjectAsync: async (opts = {}) => {
        const progress = [];
        const blob = await engine.saveDocAsync({ compress: opts.compress !== false, signal: opts.signal, onProgress: (p) => { progress.push(p); if (opts.onProgress) opts.onProgress(p); } });
        return { blob, bytes: blob.size, compressed: opts.compress !== false, progress };
      },
      saveDocAsync: (opts = {}) => engine.saveDocAsync(opts),
      loadProjectData,
      loadProjectText,
      exportPsdAsync: async (opts = {}) => {
        const progress = [];
        const blob = await engine.exportPSDAsync({ signal: opts.signal, onProgress: (p) => { progress.push(p); if (opts.onProgress) opts.onProgress(p); } });
        const head = new Uint8Array(await blob.slice(0, 4).arrayBuffer());
        return { blob, bytes: blob.size, head: String.fromCharCode(...head), progress };
      },
      exportPsdBuffer: psdExportBuffer,
      saveProjectDownload,
      exportPsdDownload,
      warmUpSave: () => engine.warmUpSaveAsync ? engine.warmUpSaveAsync() : Promise.resolve(false),
      cancelSave: () => { try { return engine.cancelSave ? engine.cancelSave() : false; } catch (e) { return false; } },
      cancelPSD: () => { try { return engine.cancelPSDExport ? engine.cancelPSDExport() : false; } catch (e) { return false; } },
      getSupport: () => ({ saveDocAsync: typeof engine.saveDocAsync === 'function', exportPSDAsync: typeof engine.exportPSDAsync === 'function', worker: typeof Worker !== 'undefined' && typeof OffscreenCanvas !== 'undefined', compression: typeof CompressionStream !== 'undefined' }),
      getAutosaveRecord: () => idbGet('current'),
      getAsyncTask: () => ({ ...ASYNC_TASK }),
      showAsyncTask, updateAsyncTask, hideAsyncTask,
    },
    t78: {
      exportPngBlob: (opts = {}) => engine.exportPNGAsync({ tileSize: opts.tileSize || 256, signal: opts.signal, onProgress: opts.onProgress }),
      downloadPng,
      warmUp: () => engine.warmUpExportAsync ? engine.warmUpExportAsync() : Promise.resolve(false),
      cancelExport: () => { try { return engine.cancelExport(); } catch (e) { return false; } },
      saveProjectBlob: async () => {
        let blob; let compressed = true;
        try { blob = await engine.getDocFileBlob({ compress: true }); } catch (e) { compressed = false; blob = await engine.getDocFileBlob({ compress: false }); }
        return { blob, bytes: blob.size, compressed };
      },
      saveProjectDownload,
      loadProjectData,
      loadProjectText,
      getAutosaveRecord: () => idbGet('current'),
      getAutosaveMeta,
      getAsyncTask: () => ({ ...ASYNC_TASK }),
      showAsyncTask, updateAsyncTask, hideAsyncTask,
      getFileSizes: async () => ({ v1: new Blob([engine.serializeDoc()], { type: 'application/json' }).size, v2: (await engine.getDocFileBlob({ compress: true })).size }),
      isCompressionSupported: () => typeof CompressionStream !== 'undefined',
      isWorkerSupported: () => typeof Worker !== 'undefined' && typeof OffscreenCanvas !== 'undefined',
      psdExportBuffer,
    },
    t71: { openLibrarySheet, closeLibrarySheet, ensureSampleLibrary, refreshLibraryAssets, listAssets: () => state.library.assets.slice(), selectedAsset: libSelectedAsset, selectLibraryAsset, importDataUrls: async (items) => { const api = await initLibrary(); const r = await api.importDataUrls(items); await refreshLibraryAssets(); renderLibrary(); return r; }, confirmAsset: async (id, opts) => { const api = await initLibrary(); const r = await api.confirm(id, opts || {}); await refreshLibraryAssets(); renderLibrary(); return r; }, rejectAsset: async (id, opts) => { const api = await initLibrary(); const r = await api.reject(id, opts || {}); await refreshLibraryAssets(); renderLibrary(); return r; }, insertAssetLayer, useAssetAsReference, clearAIReference, getAIReference: () => state.aiReference, reanalyzeAsset, deleteLibraryAsset, getPreferences: () => state.library.prefs, refreshPrefs: refreshLibraryPrefs, getLibraryApi: () => state.library.api, getDemoStepCount: () => DEMO_STEPS.length, isLibraryOpen: () => state.library.open },
    t68: { editGroupMaskUI, toggleGroupClipUI, applyGroupMaskUI: (id) => engine.applyGroupMask(id), addGroupMask: (id) => engine.addGroupMask(id), removeGroupMask: (id) => engine.removeGroupMask(id), setGroupMaskEnabled: (id, v) => engine.setGroupMaskEnabled(id, v), setGroupClip: (id, v) => engine.setGroupClip(id, v), getActiveTarget: () => engine.getActiveTarget(), getActiveGroup: () => engine.getActiveGroup(), renderGroupMaskThumb },
    t64: { attachSelectionInput, setTool, beginTransformUI, commitTransformUI, cancelTransformUI, drawTransformOverlay, clearSelectionUI, invertSelectionUI, updateToolOptions, get selectionManager() { return selectionManager; }, hasSelection: () => engine.hasSelection(), getTransformHandles: () => engine.getTransformHandles(), setSelectionMode: (m) => { state.selectionMode = m; updateToolOptions(); }, setSelectionBool: (b) => { state.selectionBool = b; updateToolOptions(); }, setFeather: (f) => { state.feather = f; if (selectionManager) selectionManager.setFeather(f); updateToolOptions(); } },
    t61: { addGroup: addGroupUI, addLayer: addLayerUI, assignLayerToGroup, applyLayerMask, duplicateLayerUI, mergeDownUI, flattenUI, moveLayerUI, deleteLayerUI, saveProjectText: () => engine.serializeDoc(), loadProjectText, getAutosaveMeta, saveProjectDownload, psdImportBuffer, psdExportBuffer, loadPsdModules, renderLayers, commitDocUI, getProjectStatus: () => ($('projectStatus') ? $('projectStatus').textContent : '') } };
    if (DEBUG) {
      const _dbg = document.getElementById('debugBadge');
      if (_dbg) _dbg.style.display = 'block';
      setInterval(updateDebugBadge, 400);
    }
    const _bf = document.getElementById("bootFatal"); if (_bf) _bf.style.display = "none";
    window.__V2_APP_READY__ = true;
    setTimeout(() => { try { maybeShowQuickStart(); } catch (e) { /* ignore */ } }, 700);
    setTimeout(() => { try { if (engine.warmUpExportAsync) engine.warmUpExportAsync().catch(() => {}); } catch (e) {} try { if (engine.warmUpSaveAsync) engine.warmUpSaveAsync().catch(() => {}); } catch (e) {} }, 1200);
  } catch (e) {
    console.error(e);
    state.lastError = String(e && (e.stack || e.message) || e);
    showFatalBar(state.lastError);
    $('statusHint').textContent = '初始化失败：' + (e.message || e);
    showToast('初始化失败：' + (e.message || e), true);
  }
})();
