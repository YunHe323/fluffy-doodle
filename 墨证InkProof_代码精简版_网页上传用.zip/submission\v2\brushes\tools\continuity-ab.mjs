/**
 * v2/brushes/tools/continuity-ab.mjs
 * 真实浏览器跑 continuity-ab.html：同一输入分别用 T41 旧实现 / T43 新实现绘制，
 * 导出 4 张 PNG（fast-s 旧/新、slow-curve 旧/新）供 Python 计算断点/粗细/滞后指标。
 * 用法：node v2/brushes/tools/continuity-ab.mjs [--cdp=9550]
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
const OUT = path.join(ROOT, 'v2', 'brushes', 'samples', 'continuity');
fs.mkdirSync(OUT, { recursive: true });
const CDP_PORT = Number((process.argv.find((a) => a.startsWith('--cdp=')) || '').split('=')[1] || 9550);
const URL_ARG = (process.env.INKPROOF_BASE || (() => {
  try {
    const port = fs.readFileSync(path.join(ROOT, 'v2', '.runtime-port'), 'utf8').trim();
    if (/^\d+$/.test(port)) return 'http://127.0.0.1:' + port;
  } catch (e) { /* ignore */ }
  return 'http://127.0.0.1:4200';
})()) + '/v2/brushes/tools/continuity-ab.html';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const EDGE = ['C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'].find((p) => fs.existsSync(p));

const report = { url: URL_ARG, files: {}, ok: false };
let ws = null; let id = 0; const pending = new Map();
const send = (method, params = {}) => new Promise((resolve) => { const i = ++id; pending.set(i, resolve); ws.send(JSON.stringify({ id: i, method, params })); });
async function ev(expression, timeout = 90000) {
  const r = await Promise.race([send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true }), sleep(timeout).then(() => ({ __t: true }))]);
  if (r.__t) throw new Error('evaluate timeout');
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1500));
  return r.result?.result?.value;
}

const profile = path.join(os.tmpdir(), 'conab-' + Date.now());
// 团队规范：自动化一律 headless（不弹窗）
const HEADLESS = !process.argv.includes('--headed');
const launchArgs = [
  '--remote-debugging-port=' + CDP_PORT, '--user-data-dir=' + profile,
  '--no-first-run', '--no-default-browser-check',
];
if (HEADLESS) {
  launchArgs.push('--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1400,1000');
} else {
  launchArgs.push('--window-size=1400,1000', '--window-position=-3000,-3000', '--start-minimized');
}
launchArgs.push(URL_ARG);
const browser = spawn(EDGE, launchArgs, { stdio: 'ignore' });
try {
  let target = null;
  for (let i = 0; i < 400 && !target; i += 1) {
    try { const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json(); target = list.find((t) => t.type === 'page' && /^https?:/.test(t.url)); } catch (e) { /* wait */ }
    if (!target) await sleep(150);
  }
  if (!target) throw new Error('no target');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { const r = pending.get(m.id); pending.delete(m.id); r(m); } };
  await send('Runtime.enable');
  const t0 = Date.now();
  let ready = false;
  while (Date.now() - t0 < 90000) {
    const err = await ev('window.__AB_ERROR__ || null').catch(() => null);
    if (err) throw new Error('page error: ' + err);
    ready = await ev('!!window.__AB_READY__').catch(() => false);
    if (ready) break;
    await sleep(300);
  }
  if (!ready) throw new Error('AB page not ready');
  report.ab = await ev('window.__runAB__()');
  const mapping = [
    ['fastS', 'old', 'continuity-fast-s-old.png'],
    ['fastS', 'new', 'continuity-fast-s-new.png'],
    ['slow', 'old', 'continuity-slow-old.png'],
    ['slow', 'new', 'continuity-slow-new.png'],
  ];
  report.metrics = {};
  for (const [sc, kind, file] of mapping) {
    const item = report.ab[sc] && report.ab[sc][kind];
    if (!item || !item.url) throw new Error('missing ' + sc + '/' + kind);
    fs.writeFileSync(path.join(OUT, file), Buffer.from(item.url.split(',')[1], 'base64'));
    report.files[`${sc}-${kind}`] = path.relative(ROOT, path.join(OUT, file)).replace(/\\/g, '/');
    report.metrics[`${sc}-${kind}`] = item.stats;
  }
  report.ab = Object.fromEntries(Object.entries(report.ab).map(([k, v]) => [k, {
    old: v.old ? { bytes: (v.old.url || '').length, stats: v.old.stats } : null,
    new: v.new ? { bytes: (v.new.url || '').length, stats: v.new.stats } : null,
  }]));
  report.ok = true;
  console.log(JSON.stringify(report, null, 2));
} catch (e) {
  report.fatal = String(e && e.stack || e);
  console.log(JSON.stringify(report, null, 2));
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  try { browser.kill(); } catch (e) { /* ignore */ }
  await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  fs.writeFileSync(path.join(OUT, 'ab-data.json'), JSON.stringify(report, null, 2));
  process.exit(report.ok ? 0 : 1);
}
