/**
 * v2/brushes/tools/klecks-probe.mjs — 探查 Klecks dist 页面结构/可用 API（供 T43 对照用）
 * 用法：node v2/brushes/tools/klecks-probe.mjs [url] [cdpPort]
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
const URL_ARG = process.argv[2] || 'http://127.0.0.1:4200/spike/klecks/vendor/klecks/dist/index.html';
const CDP_PORT = Number(process.argv[3] || 9540);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const OUT = path.join(ROOT, 'v2', 'brushes', 'samples');
fs.mkdirSync(OUT, { recursive: true });
const EDGE = ['C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe']
  .find((p) => fs.existsSync(p));
const profile = path.join(os.tmpdir(), 'klecksprobe-' + Date.now());
// 团队规范：自动化一律 headless（不弹窗）
const HEADLESS = !process.argv.includes('--headed');
const launchArgs = [
  '--remote-debugging-port=' + CDP_PORT, '--user-data-dir=' + profile,
  '--no-first-run', '--no-default-browser-check',
];
if (HEADLESS) {
  launchArgs.push('--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1680,1050');
} else {
  launchArgs.push('--window-size=1680,1050', '--window-position=-3000,-3000', '--start-minimized');
}
launchArgs.push(URL_ARG);
const browser = spawn(EDGE, launchArgs, { stdio: 'ignore' });

let ws = null; let id = 0; const pending = new Map();
const send = (method, params = {}) => new Promise((resolve) => { const i = ++id; pending.set(i, resolve); ws.send(JSON.stringify({ id: i, method, params })); });
async function ev(expression, timeout = 30000) {
  const r = await Promise.race([send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true }), sleep(timeout).then(() => ({ __t: true }))]);
  if (r.__t) throw new Error('timeout');
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 800));
  return r.result?.result?.value;
}
const out = { url: URL_ARG };
try {
  let target = null;
  for (let i = 0; i < 300 && !target; i += 1) {
    try { const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json(); target = list.find((t) => t.type === 'page' && /^https?:/.test(t.url)); } catch (e) { /* wait */ }
    if (!target) await sleep(200);
  }
  if (!target) throw new Error('no target');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && pending.has(m.id)) { const r = pending.get(m.id); pending.delete(m.id); r(m); } };
  await send('Runtime.enable'); await send('Page.enable');
  for (let i = 0; i < 100; i += 1) {
    const loaded = await ev(`(() => { const l = document.getElementById('loading-screen'); return !l || getComputedStyle(l).display === 'none' || l.textContent === ''; })()`).catch(() => false);
    if (loaded) break;
    await sleep(300);
  }
  await sleep(2500);
  out.title = await ev('document.title');
  out.globals = await ev(`Object.keys(window).filter((k) => /kleck|kl-|app/i.test(k)).slice(0, 40)`);
  out.canvases = await ev(`[...document.querySelectorAll('canvas')].map((c) => { const r = c.getBoundingClientRect(); return { id: c.id, cls: c.className, w: c.width, h: c.height, cssW: Math.round(r.width), cssH: Math.round(r.height), x: Math.round(r.x), y: Math.round(r.y), visible: r.width > 0 && r.height > 0 && getComputedStyle(c).display !== 'none' }; })`);
  out.bodyText = await ev('document.body.innerText.slice(0, 500)');
  out.buttons = await ev(`[...document.querySelectorAll('button')].slice(0, 40).map((b) => ({ cls: b.className, title: b.title, text: (b.innerText || '').slice(0, 20), aria: b.getAttribute('aria-label') }))`);
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync(path.join(OUT, 'klecks-probe.png'), Buffer.from(shot.result.data, 'base64'));
  out.screenshot = 'v2/brushes/samples/klecks-probe.png';
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e && e.stack || e);
  console.log(JSON.stringify(out, null, 2));
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  try { browser.kill(); } catch (e) { /* ignore */ }
  await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  process.exit(0);
}
