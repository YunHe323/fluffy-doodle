#!/usr/bin/env node
// v2/engine/test/alpha-lock.mjs —— T65 Alpha Lock + 结构快照释放（零依赖 CDP）
// 用法：node v2/engine/test/alpha-lock.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const checks = {};
  const mkEngine = async () => {
    const canvas = document.createElement('canvas'); canvas.width = 512; canvas.height = 512;
    const eng = new Engine({ canvas, width: 512, height: 512, layers: 1 });
    await eng.init(); eng.setBrush({ type: 'soft', sizePx: 26 });
    return eng;
  };
  const draw = (eng, x0, y, x1) => {
    eng.beginStroke({ x: x0, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
    for (let i = 1; i < 24; i += 1) eng.appendPoint({ x: x0 + (x1 - x0) * i / 23, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
    return eng.endStroke();
  };
  const regionInk = async (url, x0, y0, x1, y1) => {
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const cx = c.getContext('2d'); cx.drawImage(img, 0, 0);
    const d = cx.getImageData(0, 0, c.width, c.height).data;
    let ink = 0;
    for (let y = y0; y < y1; y += 1) for (let x = x0; x < x1; x += 1) {
      const i = (y * c.width + x) * 4;
      if (d[i] < 220 || d[i + 1] < 220 || d[i + 2] < 220) ink += 1;
    }
    return ink;
  };
  const eng = await mkEngine();
  const layerId = eng.getLayers()[0].id;
  // 1) 基础笔迹（受控小段）
  draw(eng, 100, 200, 240); await raf(); await raf();
  const baseUrl = await eng.getCompositeDataUrl();
  const baseInk = await regionInk(baseUrl, 80, 180, 460, 220);
  // 2) Alpha Lock 后长笔：只允许在已有 alpha 内（100..240）
  eng.setLayerAlphaLock(layerId, true);
  draw(eng, 40, 200, 470); await raf(); await raf();
  const lockedUrl = await eng.getCompositeDataUrl();
  const inside = await regionInk(lockedUrl, 120, 180, 220, 220);
  const rightOutside = await regionInk(lockedUrl, 300, 180, 460, 220);
  const leftOutside = await regionInk(lockedUrl, 40, 180, 75, 220);
  checks.alphaLockPaint = baseInk > 0 && inside > 0 && rightOutside < 20 && leftOutside < 20;
  // 3) undo 恢复
  eng.undo(); await raf();
  const undoUrl = await eng.getCompositeDataUrl();
  const undoInside = await regionInk(undoUrl, 120, 180, 220, 220);
  checks.alphaLockUndo = undoInside > 0;
  // 4) 橡皮 + alpha lock：擦除只作用于已有 alpha
  eng.redo(); await raf();
  let eraserPaint = null;
  const prevProvider = eng.setBrushProvider({
    id: 'test-eraser', eraser: true,
    radiusFor() { return 18; },
    paintFor(ctx) {
      if (!eraserPaint) { eraserPaint = new ctx.CK.Paint(); eraserPaint.setAntiAlias(true); eraserPaint.setBlendMode(ctx.CK.BlendMode.Clear); }
      return eraserPaint;
    },
    stampFor(ctx) { ctx.canvas.drawCircle(ctx.x, ctx.y, ctx.radius, ctx.paint); },
  });
  eng.beginStroke({ x: 160, y: 200, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
  for (let i = 0; i < 14; i += 1) eng.appendPoint({ x: 160 + i * 6, y: 200, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
  eng.endStroke(); await raf(); await raf();
  const eraseUrl = await eng.getCompositeDataUrl();
  const erasedCenter = await regionInk(eraseUrl, 150, 190, 200, 210);
  const outsideStill = await regionInk(eraseUrl, 50, 190, 90, 210);
  checks.eraserAlphaLock = erasedCenter < 5 && outsideStill < 5;
  eng.setBrushProvider(prevProvider);
  // 5) V2Doc / 序列化同步
  checks.docAlphaLock = eng.getLayers()[0].alphaLock === true;
  const json = eng.serializeDoc();
  const container = JSON.parse(json);
  const eng2 = await mkEngine();
  eng2.deserializeDoc(json);
  checks.serializeAlphaLock = container.doc.layers[0].alphaLock === true && eng2.getLayers()[0].alphaLock === true;
  eng2.dispose();
  // 6) 结构快照引用释放
  eng.addLayer({ name: '临时' });
  eng.deleteLayer(eng.getLayers()[0].id);
  eng.undo(); eng.undo();
  const released = eng.releaseHistorySnapshots();
  checks.releaseSnapshots = released === true && eng.canUndo() === false && eng.canRedo() === false;
  eng.setActiveLayer(eng.getLayers()[0].id);
  eng.setLayerAlphaLock(eng.getLayers()[0].id, false);
  draw(eng, 80, 100, 200); await raf();
  checks.afterReleasePaint = (await regionInk(await eng.getCompositeDataUrl(), 60, 80, 240, 120)) > 0;
  // 7) LayerSystem doc 同步 alphaLock
  const { LayerSystem } = await import('/v2/layers/layer-system.js');
  const engLS = await mkEngine();
  const ls = new LayerSystem(engLS);
  const lsLayer = ls.getLayers ? ls.getLayers() : ls.listLayers();
  ls.setLayerAlphaLock(lsLayer[0].id, true);
  const lsDoc = ls.getDoc();
  checks.layerSystemAlphaLock = lsDoc.layers[0].alphaLock === true;
  engLS.dispose();
  eng.dispose();
  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  return { ok: checks.ok, checks, ink: { base: baseInk, inside, rightOutside, leftOutside }, environment: { headless: /HeadlessChrome/.test(navigator.userAgent) } };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 180000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value) { console.error('无返回', JSON.stringify(r).slice(0, 1500)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
