// v2/app/test-layer-doc.mjs — T61 图层树/组/蒙版/剪贴/16 混合 + .mozheng 保存打开 + IDB 自动保存 + PSD 导入导出
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8107, CDP = 9419;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
await sleep(800);
const profile = path.join(os.tmpdir(), 'layerdoc-' + Date.now());
const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', ['--headless=new', '--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist', '--window-size=1366,768', `--remote-debugging-port=${CDP}`, `--user-data-dir=${profile}`, 'about:blank'], { stdio: 'ignore' });
let target = null;
for (let i = 0; i < 150 && !target; i++) { try { const r = await fetch(`http://127.0.0.1:${CDP}/json/list`); target = (await r.json()).find((t) => t.type === 'page'); } catch (e) {} if (!target) await sleep(150); }
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let id = 0; const pending = new Map(); const errors = [];
ws.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); return; }
  if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text);
  if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push(m.params.args.map((a) => a.value || a.description).join(' '));
};
const send = (m, p = {}) => new Promise((r) => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method: m, params: p })); });
async function ev(expression) {
  const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true });
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1200));
  return r.result?.result?.value;
}
const out = { schema: 'mozheng.app.layer-doc-test.v1', cases: {}, errors: [] };
try {
  await send('Runtime.enable'); await send('Page.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: 1366, height: 768, deviceScaleFactor: 1, mobile: false });
  await send('Page.navigate', { url: `http://127.0.0.1:${PORT}/v2/app/index.html` });
  let ready = false;
  for (let i = 0; i < 400; i++) { ready = await ev('!!window.__V2_APP_READY__').catch(() => false); if (ready) break; await sleep(250); }
  if (!ready) throw new Error('app not ready: ' + JSON.stringify(await ev('({s:document.getElementById("statusHint")?.textContent})')));
  await ev('window.__V2_APP__.openPopover("popLayers")');
  await sleep(300);

  out.cases.ui = await ev(`(() => {
    const pop = document.getElementById('popLayers').getBoundingClientRect();
    return {
      popWidth: Math.round(pop.width), popHeight: Math.round(pop.height), overflowX: pop.right > innerWidth, overflowY: pop.bottom > innerHeight - 26,
      rows: document.querySelectorAll('#layerList .layer-row').length,
      toolbar: ['btnAddLayer','btnAddGroup','btnLayerUp','btnLayerDown','btnDuplicateLayer','btnMergeDown','btnFlatten','btnLayerDelete'].every((id) => !!document.getElementById(id)),
      detail: !!document.getElementById('layerDetail'),
    };
  })()`);

  out.cases.layerOps = await ev(`(async () => {
    const app = window.__V2_APP__, t = app.t61;
    const engine = app.engine;
    const g = t.addGroup();
    t.addLayer();
    const layer = engine.getLayers()[engine.getLayers().length - 1];
    t.assignLayerToGroup(layer.id, g.id);
    engine.setLayerBlend(layer.id, 'multiply');
    engine.setLayerClip(layer.id, true);
    engine.setLayerLocked(layer.id, true);
    engine.addMask(layer.id);
    engine.setMaskEnabled(layer.id, true);
    t.renderLayers();
    const doc = engine.getDoc();
    return {
      groups: doc.groups.length, layers: doc.layers.length,
      grouped: doc.layers.filter((l) => l.group === g.id).length,
      blend: engine.getLayers().find((l) => l.id === layer.id).blend,
      clip: engine.getLayers().find((l) => l.id === layer.id).clip,
      locked: engine.getLayers().find((l) => l.id === layer.id).locked,
      mask: engine.getLayers().find((l) => l.id === layer.id).mask,
    };
  })()`);

  // 画一笔（真实 pointer），验证 tile 序列化
  const rect = await ev(`(() => { const r = document.getElementById('mainCanvas').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
  await ev('window.__V2_APP__.closePopovers()');
  await ev(`(() => { const app = window.__V2_APP__; const l = app.engine.getLayers()[0]; app.engine.setActiveLayer(l.id); app.engine.setLayerLocked(l.id, false); app.setTool('brush'); app.engine.setActiveTarget('layer'); return l.id; })()`);
  await sleep(200);
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: rect.x + rect.w * 0.35, y: rect.y + rect.h * 0.45, button: 'left', clickCount: 1 });
  for (let i = 1; i <= 8; i++) {
    await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: rect.x + rect.w * (0.35 + i * 0.02), y: rect.y + rect.h * (0.45 + i * 0.015), button: 'left' });
    await sleep(30);
  }
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: rect.x + rect.w * 0.51, y: rect.y + rect.h * 0.57, button: 'left', clickCount: 1 });
  await sleep(600);

  // ---------- 组蒙版 / 组剪贴（T68） ----------
  out.cases.groupMaskStart = await ev(`(async () => {
    const app = window.__V2_APP__; const t = app.t68; const e = app.engine;
    const base = e.getLayers()[0]; e.setActiveLayer(base.id); e.setLayerLocked(base.id, false);
    const g = e.getDoc().groups[0];
    t.editGroupMaskUI(g.id);
    return { pd: app.state.pointerdowns, strokes: app.state.strokes, target: e.getActiveTarget(), activeGroup: e.getActiveGroup(), exists: !!(e.getDoc().groups[0].mask && e.getDoc().groups[0].mask.exists), tiles: e.maskStore.count(g.id) };
  })()`);
  // 在组蒙版上画一笔（用真实 pointer；先关闭浮层避免点外关闭吞掉第一次 pointerdown）
  await ev('window.__V2_APP__.closePopovers()');
  const gmRect = await ev(`(() => { const r = document.getElementById('mainCanvas').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: gmRect.x + gmRect.w * 0.4, y: gmRect.y + gmRect.h * 0.4, button: 'left', clickCount: 1 });
  await sleep(120);
  for (let i = 1; i <= 6; i++) {
    await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: gmRect.x + gmRect.w * (0.4 + i * 0.02), y: gmRect.y + gmRect.h * (0.4 + i * 0.015), button: 'left' });
    await sleep(30);
  }
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: gmRect.x + gmRect.w * 0.52, y: gmRect.y + gmRect.h * 0.49, button: 'left', clickCount: 1 });
  await sleep(500);
  out.cases.groupMaskPaint = await ev(`(() => { const app = window.__V2_APP__; const e = app.engine; const g = e.getDoc().groups[0]; return { pd: app.state.pointerdowns, strokes: app.state.strokes, target: e.getActiveTarget(), tiles: e.maskStore.count(g.id), undo: e.getStats().undoDepth, hint: document.getElementById('statusHint').textContent }; })()`);
  await ev('window.__V2_APP__.engine.undo()');
  await sleep(250);
  out.cases.groupMaskUndo = await ev(`(() => { const e = window.__V2_APP__.engine; const g = e.getDoc().groups[0]; return { undo: e.getStats().undoDepth, tiles: e.maskStore.count(g.id) }; })()`);
  // 组剪贴开关
  out.cases.groupClip = await ev(`(() => { const app = window.__V2_APP__; const e = app.engine; const g = e.getDoc().groups[0]; app.t68.toggleGroupClipUI(g.id); return { clip: !!e.getDoc().groups[0].clip }; })()`);
  await sleep(200);

  out.cases.projectSaveOpen = await ev(`(async () => {
    const app = window.__V2_APP__, t = app.t61;
    const before = app.engine.getDoc();
    const text = t.saveProjectText();
    const parsed = JSON.parse(text);
    const doc = await t.loadProjectText(text);
    const after = app.engine.getDoc();
    const png = await new Promise((res) => app.engine.getCompositeDataUrl ? res(app.engine.getCompositeDataUrl()) : res(''));
    return {
      bytes: text.length, format: parsed.format, version: parsed.version,
      layersBefore: before.layers.length, layersAfter: after.layers.length,
      groupsBefore: before.groups.length, groupsAfter: after.groups.length,
      groupMaskBefore: !!(before.groups[0] && before.groups[0].mask && before.groups[0].mask.exists), groupMaskAfter: !!(after.groups[0] && after.groups[0].mask && after.groups[0].mask.exists),
      groupClipBefore: !!(before.groups[0] && before.groups[0].clip), groupClipAfter: !!(after.groups[0] && after.groups[0].clip), groupMaskTiles: app.engine.maskStore.count((after.groups[0] || {}).id || ''),
      blendRoundtrip: after.layers.map((l) => l.blend).join(','),
      tiles: Object.values(parsed.tiles || {}).reduce((n, m) => n + Object.keys(m || {}).length, 0),
      pngLen: (png || '').length,
    };
  })()`);

  await ev('window.__V2_APP__.t61.commitDocUI()');
  await sleep(2200);
  out.cases.autosave = await ev(`(async () => { const m = await window.__V2_APP__.t61.getAutosaveMeta(); return { has: !!m, bytes: m ? m.bytes : 0, savedAt: m ? m.savedAt : 0 }; })()`);

  out.cases.smudge = await ev(`(async () => {
    const app = window.__V2_APP__;
    app.setTool('smudge');
    const mode = app.controller.getMode();
    const isSmudge = app.controller.isSmudge();
    app.setTool('brush');
    return { mode, isSmudge, back: app.controller.getMode() };
  })()`);
  out.cases.reloadRestore = await ev('null');
  await send('Page.reload');
  for (let i = 0; i < 400; i++) { if (await ev('!!window.__V2_APP_READY__').catch(() => false)) break; await sleep(250); }
  out.cases.reloadRestore = await ev(`(() => { const d = window.__V2_APP__.engine.getDoc(); return { layers: d.layers.length, groups: d.groups.length, blend: d.layers.map((l) => l.blend).join(','), masks: d.layers.filter((l) => l.mask && l.mask.exists).length, groupMasks: d.groups.filter((g) => g.mask && g.mask.exists).length, groupClip: d.groups.filter((g) => g.clip).length, status: document.getElementById('projectStatus') ? document.getElementById('projectStatus').textContent : '' }; })()`);
  await ev('window.__V2_APP__.openPopover("popLayers")');
  await sleep(300);

  out.cases.psd = await ev(`(async () => {
    const t = window.__V2_APP__.t61;
    const exported = await t.psdExportBuffer();
    const imported = await t.psdImportBuffer(exported.buffer, 'roundtrip.psd');
    return { exportBytes: exported.buffer.byteLength, summary: exported.summary, imported: { layers: imported.layers, groups: imported.groups, items: imported.items } };
  })()`);

  for (const [w, h] of [[1920,1080],[1536,864],[1366,768]]) {
    await send('Emulation.setDeviceMetricsOverride', { width: w, height: h, deviceScaleFactor: 1, mobile: false });
    await send('Page.navigate', { url: `http://127.0.0.1:${PORT}/v2/app/index.html` });
    for (let i = 0; i < 400; i++) { if (await ev('!!window.__V2_APP_READY__').catch(() => false)) break; await sleep(250); }
    await ev(`(() => { const app = window.__V2_APP__; const e = app.engine; let d = e.getDoc(); if (!d.groups.length) { const g = e.addGroup('组 A'); const l = e.getLayers()[0]; e.moveToGroup(l.id, g.id); e.addGroupMask(g.id); e.setGroupClip(g.id, true); e.presentFull(); } d = e.getDoc(); app.state.selectedGroupId = d.groups[0].id; app.t61.renderLayers(); })()`);
    await ev('window.__V2_APP__.openPopover("popLayers")');
    await sleep(600);
    const im = await send('Page.captureScreenshot', { format: 'png' });
    fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'ui-layergroup-' + w + '.png'), Buffer.from(im.result.data, 'base64'));
    const ov = await ev('({ x: document.documentElement.scrollWidth > innerWidth + 1, y: document.documentElement.scrollHeight > innerHeight + 1, popBottom: document.getElementById("popLayers").getBoundingClientRect().bottom, bottom: document.querySelector(".pro-bottombar").getBoundingClientRect().top })');
    if (!ov.x && !ov.y && ov.popBottom <= ov.bottom + 1) out.cases['layerPopover' + w] = true; else out.cases['layerPopover' + w] = ov;
  }
  out.cases.layerScreenshotsPass = out.cases.layerPopover1920 === true && out.cases.layerPopover1536 === true && out.cases.layerPopover1366 === true;

  await sleep(400);
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'ui-layer-1366.png'), Buffer.from(shot.result.data, 'base64'));
  out.layout = await ev(`(() => ({ inner: [innerWidth, innerHeight], scrollX: document.documentElement.scrollWidth > innerWidth + 1, scrollY: document.documentElement.scrollHeight > innerHeight + 1, bottom: document.querySelector('.pro-bottombar').getBoundingClientRect().bottom }))()`);
  out.cases.maskEraser = await ev(`(async () => {
    const app = window.__V2_APP__; const e = app.engine; const th = app.t85;
    const l = e.getLayers()[0]; e.setActiveLayer(l.id); e.setLayerLocked(l.id, false);
    th.enterLayerMask(l.id); app.setTool('eraser');
    const paintBlack = th.getMaskPaint();
    const hint = document.getElementById('statusHint').textContent;
    const layerStroke = (mode) => { e.beginStroke({ x: 300, y: 260, pressure: 0.8 }, { maskPaint: mode }); for (let i = 1; i <= 6; i += 1) e.appendPoint({ x: 300 + i * 24, y: 260 + i * 12, pressure: 0.8 }); e.endStroke(); e.presentFull(); };
    layerStroke('black');
    const afterBlack = th.maskStats(l.id);
    const undoBefore = e.getStats().undoDepth;
    e.undo();
    const afterUndo = th.maskStats(l.id);
    app.setTool('brush');
    layerStroke('white');
    const afterWhite = th.maskStats(l.id);
    const paintWhite = th.getMaskPaint();
    // 组蒙版：黑隐藏 + undo
    let g = e.getDoc().groups[0];
    if (!g) { g = e.addGroup('组'); const l0 = e.getLayers()[0]; e.moveToGroup(l0.id, g.id); }
    th.enterGroupMask(g.id); app.setTool('eraser');
    const groupHint = document.getElementById('statusHint').textContent;
    layerStroke('black');
    const groupBlack = th.maskStats(g.id);
    const groupUndoBefore = e.getStats().undoDepth;
    e.undo();
    const groupUndo = th.maskStats(g.id);
    return { paintBlack, paintWhite, hint, groupHint, afterBlack, afterUndo, afterWhite, groupBlack, groupUndo, undoBefore, groupUndoBefore, undoAfter: e.getStats().undoDepth, target: th.activeTarget() };
  })()`);
  await sleep(300);
  out.pass = {
    ui: out.cases.ui.popWidth > 250 && !out.cases.ui.overflowX,
    layerOps: out.cases.layerOps.groups >= 1 && out.cases.layerOps.grouped >= 1 && out.cases.layerOps.blend === 'multiply' && out.cases.layerOps.clip === true && out.cases.layerOps.locked === true && out.cases.layerOps.mask && out.cases.layerOps.mask.exists,
    saveOpen: out.cases.projectSaveOpen.groupMaskBefore && out.cases.projectSaveOpen.groupMaskAfter && out.cases.projectSaveOpen.groupClipBefore && out.cases.projectSaveOpen.groupClipAfter && out.cases.projectSaveOpen.tiles > 0 && out.cases.projectSaveOpen.format === 'mozheng' && out.cases.projectSaveOpen.layersBefore === out.cases.projectSaveOpen.layersAfter && out.cases.projectSaveOpen.groupsBefore === out.cases.projectSaveOpen.groupsAfter,
    autosave: out.cases.autosave.has && out.cases.autosave.bytes > 100 && out.cases.autosave.savedAt > 0,
    reloadRestore: out.cases.reloadRestore.layers === 3 && out.cases.reloadRestore.groups === 1 && out.cases.reloadRestore.masks === 1 && out.cases.reloadRestore.groupMasks === 1 && out.cases.reloadRestore.groupClip === 1,
    smudge: out.cases.smudge.mode === 'smudge' && out.cases.smudge.isSmudge === true && out.cases.smudge.back === 'brush',
    psd: out.cases.psd.exportBytes > 100 && out.cases.psd.imported.layers >= 1,
    groupMask: out.cases.groupMaskStart.exists && out.cases.groupMaskStart.target === 'group-mask' && out.cases.groupMaskPaint.tiles > 0 && out.cases.groupMaskPaint.hint.includes('组蒙版'),
    groupMaskUndo: out.cases.groupMaskUndo.undo < out.cases.groupMaskPaint.undo,
    groupClip: out.cases.groupClip.clip === true,
  maskEraser: out.cases.maskEraser.paintBlack === 'black' && out.cases.maskEraser.paintWhite === 'white' && out.cases.maskEraser.hint.includes('白=显示') && out.cases.maskEraser.groupHint.includes('组蒙版') && out.cases.maskEraser.afterBlack.darkFraction > 0 && out.cases.maskEraser.afterUndo.darkFraction < out.cases.maskEraser.afterBlack.darkFraction && out.cases.maskEraser.afterWhite.darkFraction < out.cases.maskEraser.afterBlack.darkFraction && out.cases.maskEraser.groupBlack.darkFraction > 0 && out.cases.maskEraser.groupUndo.darkFraction <= out.cases.maskEraser.groupBlack.darkFraction,
    layerScreenshots: out.cases.layerScreenshotsPass === true,
    layout: !out.layout.scrollX && !out.layout.scrollY && out.layout.bottom <= 768,
  };
  out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} catch (e) {
  out.fatal = String(e.stack || e); out.errors = errors.slice(0, 10);
  console.log(JSON.stringify(out, null, 2));
} finally {
  try { ws.close(); } catch (e) {}
  chrome.kill(); py.kill(); await sleep(300);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) {}
  fs.writeFileSync(path.join(ROOT, 'v2', 'app', 'test-layer-doc-result.json'), JSON.stringify(out, null, 2), 'utf8');
  process.exit(0);
}
