# Contributing to Mozheng

Thanks for your interest in improving Mozheng! This project is local-first, offline-capable, and intentionally dependency-free. Contributions of all sizes are welcome — code, docs, bug reports, translations, and design feedback.

By participating, you agree to follow our [Code of Conduct](CODE_OF_CONDUCT.md).

---

## Before you start

- **Open an issue first** for anything larger than a typo fix or a small bug fix. Describe the problem and your proposed approach. This avoids duplicated or misaligned work.
- **v0.1 scope is frozen around:** local-first canvas, archive (L0/L1/L2/L4/L5 + minimal L6), stuck moment, evidence package, mock AI, sample project + one-click demo, persistence. New features usually go to the v0.2 list (tracked in issues) — ask first.
- **Do not add third-party runtime dependencies.** The project must run with `node server/server.mjs` and no `npm install`.
- **Do not add telemetry, analytics, or silent network requests.** Mock mode must make zero external requests.
- **Never commit API keys, personal artwork, exported evidence packages, or logs.** `config/provider.json` is gitignored.

---

## Requirements

- **Node.js 22+** (for the local service and tests)
- A Chromium-based browser (Chrome/Edge) for manual testing
- No package installation required; no build step

```bash
node server/server.mjs     # local service → http://127.0.0.1:4173
node --test                # unit tests
```

On Windows you can also double-click `start.bat`. On macOS/Linux: `./start.sh`.

---

## Repository layout

| Path | Responsibility |
|---|---|
| `app/` | Frontend: canvas rendering, layers, archive UI, stuck panel, evidence UI, onboarding/demo, state |
| `server/` | Zero-dependency local HTTP service: static files + `/api/*` (health, mock AI, config) |
| `core/` | Environment-agnostic pure logic (hash chain, archive schema, deterministic mock AI) — must run in both browser and Node |
| `test/` | Node test runner (`node --test`) |
| `docs/` | User/developer docs (getting started, architecture, privacy) |
| `CONTRACT.md` | Interface contract between `app/` and `server/` — update it before changing API shapes |

**Architecture boundaries:**

- `app/` must not import anything from `server/` directly; talk via `/api/*` (or the local mock modules in `core/` for offline fallback).
- `core/` must have no browser-only or Node-only assumptions; keep it pure and testable.
- `server/` must stay stateless: it should not persist artwork, archives, or evidence.
- Evidence and archives live in the browser's IndexedDB; the server only relays mock/provider AI calls.

---

## Code style

- **Vanilla ES modules**, no framework, no bundler, no TypeScript. Keep it readable for beginners.
- Prefer small, focused modules; avoid over-abstraction.
- File names: lowercase with dashes (`mock-ai.mjs`, `archive-schema.mjs`). `.mjs` for shared/ESM modules.
- Comments: explain **why**, not what. Keep comments in English or Chinese; be consistent within a file.
- UI strings: Simplified Chinese for user-facing text in v0.1 (English UI is a future item); code identifiers in English.
- Accessibility: do not rely on color alone; respect `prefers-reduced-motion`; keep keyboard paths working.
- Never use `innerHTML` with untrusted content; SVG candidates are only drawn to `<img>`/canvas.
- Keep the mock deterministic: same input → same output. Mocks must never call the network.

---

## Tests

- Add unit tests under `test/` for pure logic (`core/`) — hash chain, archive schema, mock determinism, import/export validation.
- Run `node --test` before opening a PR. CI will run the same command.
- For UI changes, describe the manual steps you ran in the PR (browser, viewport, expected result). Screenshots/recording help.

---

## Pull request process

1. Fork the repo and create a branch: `fix/…`, `feat/…`, `docs/…`.
2. Keep PRs small and focused; one topic per PR.
3. Fill in [PULL_REQUEST_TEMPLATE.md](.github/PULL_REQUEST_TEMPLATE.md), including:
   - what changed and why;
   - linked issue (if any);
   - tests run (`node --test`) and manual checks;
   - screenshots for UI changes;
   - confirmation of no new dependencies / no telemetry / no secrets.
4. A maintainer reviews within a few days. Address review comments by pushing new commits (avoid force-pushing during review).
5. Squash-merge when approved. Commit messages should be short and descriptive; `type: summary` (e.g. `fix: keep layer order after undo`) is preferred but not enforced.

---

## Assets and licensing

- **Example assets must be self-made or use permissively licensed resources** (e.g. ISC, OFL, CC0), and must be attributed where the license requires it. Do not add copied artwork, screenshots, or icons with unclear provenance.
- Icons: prefer inline SVG or the project's existing Lucide (ISC) icons; note the source.
- Fonts: use system fonts only; no external/CDN fonts.
- By contributing, you agree that your contribution is licensed under the project's license (currently MIT placeholder — see `LICENSE`).

---

## Documentation and translation

- English docs are the primary open-source docs; the README also contains a Chinese section.
- If you add a user-facing feature, update `README.md` and `docs/` in the same PR.
- Translation fixes are welcome — keep terminology consistent (`Mock / 模拟`, `协作模式 / collab`, `存证模式 / attest`, `证据包 / evidence package`).

---

## Security and privacy

- Do not include secrets, API keys, user data, or private artwork in issues, PRs, or commits.
- Report security or privacy issues privately to the maintainers rather than opening a public issue. See [docs/privacy.md](docs/privacy.md).
- When adding anything that could transmit data, it must be **explicit, opt-in, documented**, and disabled by default.
