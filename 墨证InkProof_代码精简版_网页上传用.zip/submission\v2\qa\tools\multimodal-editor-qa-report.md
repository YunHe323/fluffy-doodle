﻿# AI 深度嵌入 + 编辑器基础 · 独立 QA 报告（T103）

> 执行：qa-engineer（独立 QA｜只读 app，不改源码；只写 `v2/qa/tools/`）｜环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、各测试独立端口、0 残留
> 范围：Lead 增量（AI 深度嵌入 + 编辑器基础）；先读脚本再跑，不只信 owner 结论。

## 结论

**可交付（Deliverable）——P0/P1/P2 = 0。**
5 个新增测试 + 回归全部通过；过程中发现 **2 个 P1** 与 **1 个 P2（标注层缩放同步）**，均已由 Lead 修复并经 QA 复核关闭（2026-11-07 14:4x）。

> 增补（P2 关闭）：Lead 已把 `annotationCanvas`/`candidatePreviewCanvas` 补进 `fitView` 适配尺寸循环（app.js L361）与相关尺寸循环；`test-multimodal` 新增「坐标对齐」断言并通过。QA 复跑：`align.main/annotation/preview` 三者 rect 完全一致 **(212.5, 66, 993×662)**、`alignOk=true`；annotation/done/locate/voice/noErrors 全 true，0 error。

## 1. 新增测试结果

| # | 测试 | 结果 | 关键证据 |
|---|---|---|---|
| 1 | `test-editor-basics.mjs` | **PASS**（连跑 2 次均为 PASS、0 error） | 选区复制粘贴 2→3 图层；数值变换 X/Y/W/H=100/80/200/120（实测 bounds w=200 h=120 cx=200）；Ctrl+J 3→4；双击重命名 ok；AI 会话时间线 session=1/rows=1/steps=5 |
| 2 | `test-image-pan.mjs` | **PASS** | 插入素材自动变换（tool=transform、transformActive、9 手柄）；拖动+提交+undo 通过；移动工具 H / 空格平移 dx/dy 达标；放大后平移通过 |
| 3 | `test-multimodal.mjs` | **PASS（修复 P1 后）** | 标注 mode/dirty/ink/bar/annotatedCrop=true；cropLen 5179（>未标注基线 1815）；完成：mode=false/bar=false/ink 保留；清空 ink=false；「在画布定位」按钮与移动生效；语音入口 + 标注按钮存在；观察/意图等会话字段存在 |
| 4 | `test-chat.mjs` | **PASS** | 表单（输入+≥2 快捷问题）→ 发送 → assistant 回复；`aiChat.len=2`、roles=[user,assistant]、UI 行数≥2、文本长度>10、meta 存在 |
| 5 | `test-canvas-size.mjs` | **PASS（修复 P1-2 后）** | `?new=1&w=1600&h=1000`：engine=1600×1000、docSize「1600 × 1000」、绘制 undo=1；新建画布弹窗可见且 W/H=1600/1000；预设 1920×1080 |

## 2. 回归

| 项 | 结果 |
|---|---|
| `test-app.mjs` | PASS（0 error，截图产出） |
| `test-ui.mjs` | PASS（0 error，p1Checks 全过） |
| `test-interaction-sequences.mjs` | **9/9 PASS**（0 error） |
| `test-library.mjs` | PASS（19/19，含 scrim=true） |
| `test-demo.mjs` | PASS |
| `test-ai-provider.mjs` | PASS（16/16，0 error） |
| 三页冒烟 / GATE | 本增量未改画布/present 路径；保持 T97/T102 基线全绿（本次抽测了 app 交互，无回退） |

## 3. 安全与证据复核

| 检查 | 结果 |
|---|---|
| 密钥运行时泄漏 | ✅ DOM / localStorage / sessionStorage / 已加载 JS / 静态源码均无 key（只做内存比对，未打印 key） |
| config 脱敏 | ✅ config GET 仅 `hasKey/keyLast4`，无 `apiKey` 字段；T99 token 注入正常 |
| `.ai-config.json` 权限 / `.gitignore` | ✅ ACL 仅 SYSTEM/Administrators/当前用户（T102 复核）；根 `.gitignore` 已含 `.ai-config.json`/`.ai-token` |
| Qwen 视觉证据 | ✅ `qwen-real-e2e-results.json`：pass=true、provider=qwen、mock=false、latency=11014ms、usage=1094 tokens、证据 real_calls=1（verify-evidence 通过） |
| Qwen 对话证据 | ✅ `qwen-chat-real-results.json`：pass=true、provider=qwen、mode=real、latency=2689ms、usage=330 tokens、内容合理 |
| 本次真实调用 | **未发起**（未再花钱；仅核对既有证据） |

## 4. 发现的问题

### P1-1（已修复并经 QA 复核）标注层 CSS 被覆盖，标注功能不可用
- 现象（初测）：`test-multimodal` 红 —— annotationMode=true、标注条正常，但画圈后 `annotationDirty=false`、`annotationInk()=false`、`aiSelectionCrop().annotated=false`。
- 根因（QA 独立定位，证据 `annotation-probe-results.json`）：Lead 重写 `ai-collab.css` 时丢失覆盖层规则 → `#annotationCanvas` 回到 static 文档流，rect=(-1091,-403,1200×800)，`elementFromPoint` 命中 `mainCanvas`，笔迹到不了标注画布（alpha=0）。
- 修复（Lead）：补 `#annotationCanvas` absolute/居中/z-index:6/pointer-events（.active=auto），`#candidatePreviewCanvas`、`.annotation-bar`、`.selection-ai-chip` 同套规则。
- 复核：`multimodal` PASS；QA 探针 `annotation-probe2-results.json`：mode/dirty/ink=true、alphaPixels=2223、annotatedCrop=true、完成后 ink 保留、清空 ink=false。

### P1-2（已修复并经 QA 复核）`hidden` 被 display:flex 覆盖，隐藏 chip 拦截画布点击
- 现象：`?new=1` 新画布 draw 测试 undo=0（点击被隐藏的 `.selection-ai-chip` 吃掉）。
- 修复（Lead）：`.selection-ai-chip[hidden], .annotation-bar[hidden] { display:none!important }`。
- 复核：`test-canvas-size` 重跑 PASS（init/draw undo=1/modal/preset 全过，0 error）。

### P2（**已修复并复核关闭**，owner=lead）标注/候选覆盖层未随「适配缩放」同步尺寸
- 证据（`annotation-probe2-results.json` / `_probe-align2`）：1366×768 下 `view.baseScale=0.8275`，`mainCanvas` inline size=993×662（rect 213,66,993×662），但 `annotationCanvas`/`candidatePreviewCanvas` inline size 仍为 1200×800（rect 109,-3,1200×800）。
- 根因：`v2/app/js/app.js` 约 L413 的适配缩放循环只处理 `[mainCanvas, overlayCanvas, selectionOverlay, transformOverlay]`，未包含 `annotationCanvas`/`candidatePreviewCanvas`（其尺寸仍在 L301 `applyDocCanvasSizeUI` 设为 1200×800）。
- 影响：标注笔迹/红圈相对画面**有约 104px/69px 偏移且未随缩放**；AI 收到的标注排版位置会偏（功能可用、测试只校验 ink 存在故未暴露）。
- **修复（Lead）**：两个 id 已补进 `fitView` 适配尺寸循环（app.js L361 及对应尺寸循环）；`test-multimodal` 已增加坐标对齐断言。
- **QA 复核（2026-11-07 14:4x）**：`test-multimodal` PASS —— `align` 三层 rect 完全一致 `(212.5,66,993×662)`、`alignOk=true`，annotation/done/locate/voice/noErrors 全 true，0 error；P2 关闭。

## 5. 截图（产物）

- `v2/app/ui-editor-basics-1920.png`
- `v2/app/ui-multimodal-1920.png`
- `v2/app/ui-chat-1920.png`
- `v2/app/ui-canvas-1600x1000.png`
- `v2/app/ui-image-transform-1920.png`、`v2/app/ui-pan-1920.png`

## 6. 残留检查

- Edge 测试进程：**0**（含 crashpad/gpu/renderer 子进程已清理）
- 测试端口（8148–8153、8172–8176）：**0** 监听
- 未改动 `v2/app|engine|library`；本报告/证据均在 `v2/qa/`。

## 7. 建议

1. ~~修 P2（标注覆盖层缩放同步）+ 增加坐标对齐断言~~ → **已完成并复核关闭**。
2. 为「隐藏元素不拦截点击」补一条持久化回归（本次 P1-2 由 canvas-size 间接覆盖）。
3. 其余保持，无需回退。
