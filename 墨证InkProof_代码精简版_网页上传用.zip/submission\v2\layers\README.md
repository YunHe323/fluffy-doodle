# v2 layers · 图层体系（T37）

> 依赖 T35 `v2/engine`（只读复用 Engine/TileStore/Stroke/attachInput，**未修改 engine**）。
> 演示：`v2/layers/demo.html`｜测试：`v2/layers/test/t37-smoke.mjs`｜结果：`v2/layers/results/layers-smoke.json`
> 选型/计划：`06-技术/三路线选型对比.md` v1.3、`06-技术/v2实现计划.md` M4.3。

## T67 组蒙版 / 组剪贴

- `addGroupMask/removeGroupMask/setGroupMaskEnabled/applyGroupMask`、`setGroupClip`、`setActiveGroup` + `setActiveTarget('group-mask')`；组蒙版笔触 undo（同一栈，storeKind `group-mask`）。
- 语义：空白 mask tile 隐藏、白色笔触显示；组剪贴 = 组整体被下方图层 alpha 裁切（最小）。
- `getDoc/applyDoc` 保留 `groups[].mask/clip`；测试 `v2/engine/test/group-mask.mjs`（engine）+ t37 smoke 不回退。

## T65 Alpha Lock / 快照释放

- `setLayerAlphaLock(id,true/false)`：笔刷/擦除只作用于已有 alpha；`getLayerAlphaLock`；`getDoc/applyDoc` 保留 `alphaLock`。
- `releaseHistorySnapshots()`：显式释放结构/历史快照与 detach image（跳过当前 tile 引用），清空 undo/redo。
- 组蒙版/组剪贴最小版未做（T37 已知差异）。

## T63 结构操作 undo

- `addGroup/addLayer/deleteLayer/duplicateLayer/moveLayer/mergeDown/flattenAll` 均自动记录结构快照（V2Doc + tile image 引用），与笔触/变换共用同一 undo 栈；`undo()/redo()` 恢复结构 + 像素。
- 结构快照不立即 delete 旧 image（避免历史 undo 悬空），M4.5 做引用计数释放。
- 测试：`test/structural-undo.mjs`（全过）。

## 目录

```
v2/layers/
├─ demo.html            # 组/蒙版/剪贴/16 混合/图层操作 demo（2048²，可绘制）
├─ compositor16.js      # 16 种混合模式 → CanvasKit BlendMode 映射
├─ layer-system.js      # LayerSystem：图层树/组/蒙版/剪贴/合成/图层操作/undo
├─ test/t37-smoke.mjs   # 零依赖 CDP 冒烟（组/混合/蒙版/剪贴/操作/PNG）
└─ results/             # 冒烟结果留档
```

## 实时预览（T45 修复，2026-11-06）

- **审计出的同源 bug**：`beginStroke/appendPoint` 调 `currentStroke.stampLive(this.mainCanvas)`、`_maskStamp(drawLive)` 直接把蒙版白点画到主 canvas，`requestFrame` 只 `surface.flush()` → 未开 `preserveDrawingBuffer` 时拖动中内容跨帧丢失（与 T44 engine 同源，layers demo/app 会复现）。
- **修复**：与 T44 同一确定性模型——离屏 **live surface**（GPU RenderTarget）；笔触/蒙版 stamp 写 live；每帧 rAF 执行 `_drawAll(mainCanvas, live)`：`clear → 全部图层/组 → live → flush`；`endStroke/cancel/undo/redo` 清空 live 再重合成；`getCompositeDataUrl` 含 live。
- **蒙版 live**：现有蒙版先对图层做 `DstIn`（遮掉），再补一遍「本层内容 × live mask `DstIn`」→ 实时露出新覆盖区域（不是白盖）。
- **回归**：`v2/layers/test/live-preview.mjs`（未 end 时第一笔仍在 + 新笔迹可见；cancel/undo/redo；蒙版 live 露出/未覆盖区隐藏/undo）。结果：`results/live-preview.json`。
- **成本**：每帧全量合成（2048² demo 实测合成 ~ms 级）；live surface 额外一份画布内存（2048²≈16MB，4096²≈64MB）→ 与 T44 一并记入 M4.5 优化。
- `v2/layers` 未修改 `v2/engine`；engine 的 `Stroke.stampTo`（T44）被复用。

## 运行

```powershell
# 仓库根目录（推荐用 Lead 提供的 v2/serve.mjs，起在 4200）
node v2/serve.mjs
# 或 python -m http.server 8899 --bind 127.0.0.1
# 浏览器打开：
# http://127.0.0.1:4200/v2/layers/demo.html
```

需要 Chrome/Edge（WebGL2 + WASM）；CanvasKit 从 `../engine/vendor/` 本地加载，无外网请求。

## 数据模型

```ts
interface Layer {
  id: string; name: string;
  group: string | null;      // 1 级组 id
  visible: boolean; opacity: number;      // 0–1
  blend: BlendMode16;        // normal/dissolve/.../luminosity（16 种）
  locked: boolean; alphaLock: boolean;
  clip: boolean;             // 剪贴到下方图层 alpha
  mask: { enabled: boolean; exists: boolean };
}
interface Group { id: string; name: string; visible: boolean; opacity: number; }
```

- 图层顺序 = `layers[]` 顺序（下→上）；组 = 连续同 `group` 的图层段，合成时用 `saveLayer` 做**组透明度隔离**。
- 像素：`engine.store` 按 layerId 存 256² tile；蒙版：`LayerSystem.maskStore` 独立 tile（alpha 通道，white=可见）。
- 混合：`compositor16.js` 映射到 Skia BlendMode（`dissolve` 暂以 SrcOver 表示）。
- 剪贴：图层内容与「下方图层 alpha」做 `DstIn`。
- undo：笔触/蒙版 = tile patch（before/after）；变换 = 整层图像快照（1 步）。**结构操作（新建/删除/复制/排序/合并/拼合）暂不可撤销**（M4.3 已知限制）。

## 接口（LayerSystem）

| 类别 | 方法 |
|---|---|
| 构造 | `new LayerSystem(engine)`（engine 已 init） |
| 图层/组 | `addLayer`, `addGroup`, `deleteLayer`, `duplicateLayer`, `moveLayer`, `mergeDown`, `flattenAll`, `getLayer`, `listLayers`, `listGroups`, `setActiveLayer` |
| 元数据 | `setLayerVisible`, `setLayerOpacity`, `setLayerBlend`（16 种）, `setLayerClip`, `setLayerLocked` |
| 蒙版 | `addMask`, `setMaskEnabled`, `deleteMask`, `applyMask`（烘焙进图层）, `setActiveTarget('layer'\|'mask')` |
| 绘制 | `beginStroke/appendPoint/endStroke/cancelStroke`（可直接被 `attachInput` 调用）, `setBrush` |
| 选区 | `setSelectionImage(CKImage)` / `clearSelection`（选区约束在笔触提交时按 tile DstIn） |
| 合成/导出 | `composite`, `compositeDirtySafe`, `getCompositeDataUrl`, `getStats` |
| 撤销 | `undo`, `redo`, `canUndo`, `canRedo` |
| 变换辅助 | `renderLayerToImage`, `replaceLayerFromImage`（供 selection 模块） |

## 已实现 / 未实现

- ✅ 1 级组 + 组透明度隔离；图层元数据（可见/不透明度/混合/锁定/Alpha Lock 字段）
- ✅ 16 种混合模式（Skia 映射；dissolve 暂近似）
- ✅ 图层蒙版：新建/启停/删除/应用（烘焙）；编辑走笔刷管线（目标=蒙版）
- ✅ 剪贴蒙版（下方图层 alpha）
- ✅ 图层操作：新建/删除/复制/排序/向下合并/拼合（全量 tile 分配，用于演示）
- ✅ 笔触/蒙版 tile patch undo（80 步）；变换整层图像 undo
- ⬜ 组蒙版/组剪贴、多级嵌套（P0 只要求 1 级）
- ⬜ 结构操作 undo、合并保留上层混合模式
- ⬜ 自由变换手柄（在 selection demo 中以按钮式变换实现）
- ⬜ Alpha Lock 实际约束绘制（字段已留）

## 冒烟结果（2026-11-06，Headless Chrome + RTX 4060/D3D11）

`results/layers-smoke.json`：`ok=true`；3 笔绘制 tileCount=3；组+11 种混合切换+不透明度；蒙版绘制并应用（`maskApplied=true`）；剪贴；复制/排序/拼合（tile 64，内存 164.5MB 估算）；PNG 68,000B。

```powershell
node v2/layers/test/t37-smoke.mjs layers http://127.0.0.1:8899/v2/layers/demo.html 9333
# T45 实时预览回归
node v2/layers/test/live-preview.mjs http://127.0.0.1:8899/v2/layers/demo.html 9333 v2/layers/results/live-preview.json
```

## 已知限制 / 风险

1. 结构操作不可撤销（仅笔触/蒙版/变换可 undo）。
2. 合并（mergeDown）以 normal 方式烘焙上层，忽略其混合模式/组关系。
3. 拼合/变换会全量分配 64 个 tile（16MB），并触发全量合成；M4.5 做按区分配/释放。
4. 每次 `_paint()` 新建 Paint 未统一释放，长会话有内存增长（demo 级别可接受；M4.5 优化）。
5. 蒙版应用后删除蒙版通道；蒙版作为普通 alpha 掩码，不支持 8-bit 灰度可视化编辑（以画笔覆盖）。
6. 组内图层顺序与组边界仍以扁平数组表示，移动跨组需手动改 group 字段（demo 提供下拉）。

## 许可 / 范围

- 本目录自制代码；仅依赖 `v2/engine/vendor` 的 CanvasKit（BSD-3，见该目录 `THIRD_PARTY_NOTICES.md`）。
- 写入范围：`v2/layers/`；未改 `v2/engine/`、`v2/brushes/`、`product/`。
