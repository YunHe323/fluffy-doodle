/**
 * 内置 Skill 定义（v0.1）
 * 这些是"平台自己的技能"，不是某个模型的 prompt。
 * 换 Qwen / Kimi / Hunyuan 时，技能契约不变，只换 provider 适配。
 */

export const ASSET_DECOMPOSE_SKILL = {
  id: 'asset.decompose',
  version: '1.0.0',
  title: '素材理解与拆解',
  description: '读整张素材 → L1 整体 / L2 区域 / L4 观察 / 标签 / 色板；可确认、可复用、可追溯。',
  capability: 'vision',
  method: 'analyze',
  buildPayload({ input }) {
    return {
      image: input.image,
      width: input.width,
      height: input.height,
      selection: { x: 0, y: 0, width: input.width, height: input.height },
      archive: input.archive || {},
      userIntent: input.userIntent || '请把这张素材读懂并拆解：整体、区域、观察、可用标签与色板。',
      mode: 'library',
      aiRole: 'assistant',
      live: { scope: 'asset', fileName: input.fileName || null, source: 'library' },
      context: { mode: 'library', aiRole: 'assistant', fileName: input.fileName || null },
    };
  },
  normalize(res) { return res; },
  validate(res) {
    const errors = [];
    if (!res || !res.global) errors.push('缺少 global');
    if (!res || !Array.isArray(res.observations)) errors.push('缺少 observations');
    return { ok: errors.length === 0, errors };
  },
};

export const CANVAS_OBSERVE_SKILL = {
  id: 'canvas.observe',
  version: '1.0.0',
  title: '画布观察',
  description: '选区 + 实时状态 + 档案 → 结构化观察与区域；AI 不直接改画布。',
  capability: 'vision',
  method: 'analyze',
  buildPayload({ input }) {
    return {
      image: input.image, width: input.width, height: input.height,
      selection: input.selection || null,
      archive: input.archive || {},
      userIntent: input.userIntent || '',
      mode: input.mode || 'collab', aiRole: input.aiRole || 'assistant',
      live: input.live || null,
      context: input.context || {},
    };
  },
  normalize(res) { return res; },
  validate(res) {
    return { ok: !!(res && res.global && Array.isArray(res.observations)), errors: [] };
  },
};

export const IMAGE_EDIT_SKILL = {
  id: 'image.edit',
  version: '1.0.0',
  title: '图像编辑',
  description: '选区/整图/图层 + 描述 → 图像编辑候选；结果落新图层，可继续改。',
  capability: 'image-edit',
  method: 'editImage',
  buildPayload({ input }) {
    return {
      prompt: input.prompt || '',
      image: input.image || null,
      images: input.images || (input.image ? [input.image] : []),
      size: input.size || '1024x1024',
      count: input.count || 1,
    };
  },
  normalize(res) { return res; },
  validate(res) {
    const errors = [];
    if (!res || !Array.isArray(res.candidates) || !res.candidates.length) errors.push('缺少候选');
    return { ok: errors.length === 0, errors };
  },
};

export const CANVAS_DIRECTIONS_SKILL = {
  id: 'canvas.directions',
  version: '1.0.0',
  title: '画布方向建议',
  description: '观察 + 选区 + 档案 → 2–3 个可执行方向；先选方向再花钱生成。',
  capability: 'vision',
  method: 'directions',
  buildPayload({ input }) {
    return {
      image: input.image, width: input.width, height: input.height,
      selection: input.selection || null,
      archive: input.archive || {},
      userIntent: input.userIntent || '',
      observationIds: input.observationIds || [],
      count: input.count || 2,
      mode: input.mode || 'collab', aiRole: input.aiRole || 'assistant',
      live: input.live || null,
      context: input.context || {},
    };
  },
  normalize(res) { return res; },
  validate(res) {
    return { ok: !!(res && Array.isArray(res.directions) && res.directions.length > 0), errors: [] };
  },
};

export const IMAGE_GENERATE_SKILL = {
  id: 'image.generate',
  version: '1.0.0',
  title: '图像生成',
  description: '选区/整图/图层 + 描述 + 0–3 张素材 → 候选；结果落新图层。',
  capability: 'image-gen',
  method: 'generate',
  buildPayload({ input }) {
    return {
      prompt: input.prompt || '',
      directionId: input.directionId || 'skill-generate',
      image: input.image || null,
      images: input.images || (input.image ? [input.image] : []),
      size: input.size || '1024x1024',
      count: input.count || 2,
    };
  },
  normalize(res) { return res; },
  validate(res) {
    return { ok: !!(res && Array.isArray(res.candidates) && res.candidates.length > 0), errors: [] };
  },
};

export const BUILTIN_SKILLS = [ASSET_DECOMPOSE_SKILL, CANVAS_OBSERVE_SKILL, CANVAS_DIRECTIONS_SKILL, IMAGE_GENERATE_SKILL, IMAGE_EDIT_SKILL];
export default BUILTIN_SKILLS;
