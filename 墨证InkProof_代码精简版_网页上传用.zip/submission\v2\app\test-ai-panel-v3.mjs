// v2/app/test-ai-panel-v3.mjs —— AI 面板 3 primary tab / 模型 badge / 固定上下文条 / 长对话记忆
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8168;
const out = { schema: 'mozheng.app.ai-panel-v3.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => { try { await browser.close(); } catch (e) {} try { py.kill(); } catch (e) {} fs.writeFileSync(ROOT + '\\v2\\app\\test-ai-panel-v3-result.json', JSON.stringify(out, null, 2), 'utf8'); process.exit(code); };
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11'] });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('mozheng.ai.settings.v1', JSON.stringify({ preset: 'qwen', allowReal: false, requireConfirm: true, privacyMode: true })); } catch (e) {} });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(900);
  await page.evaluate(() => window.__V2_APP__.openPopover('popAI'));
  await page.waitForTimeout(300);
  out.cases.tabs = await page.evaluate(() => {
    const tabs = [...document.querySelectorAll('.ai-tabs .ai-tab')].filter((b) => !b.hidden && getComputedStyle(b).display !== 'none');
    return { labels: tabs.map((b) => b.textContent.trim()), active: tabs.filter((b) => b.classList.contains('active')).map((b) => b.textContent.trim()), pinned: (document.getElementById('aiPinnedStatus') || {}).innerText || '', status: (document.getElementById('statusContext') || {}).textContent || '' };
  });
  // 记录 tab → 证据子页
  await page.click('#btnAiTabRecords'); await page.waitForTimeout(300);
  out.cases.records = await page.evaluate(() => ({ records: getComputedStyle(document.getElementById('aiTabRecords')).display !== 'none', archive: !!document.getElementById('aiArchiveBody'), evidence: !!document.getElementById('aiEvidenceBody') }));
  await page.click('#btnAiRecordEvidence'); await page.waitForTimeout(250);
  out.cases.recEvidence = await page.evaluate(() => ({ evidenceDisplay: getComputedStyle(document.getElementById('aiRecordEvidence')).display, active: (document.querySelector('[data-record-tab].active') || {}).dataset ? document.querySelector('[data-record-tab].active').dataset.recordTab : '' }));
  // 模型 badge → 模型面板
  await page.click('#aiProviderBadge'); await page.waitForTimeout(300);
  out.cases.model = await page.evaluate(() => ({ display: getComputedStyle(document.getElementById('aiTabModel')).display, hasBody: /模型控制台/.test((document.getElementById('aiModelBody') || {}).innerText || ''), badgeActive: document.getElementById('aiProviderBadge').classList.contains('active-tab') }));
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-ai-panel-v3-1366.png' });
  await page.click('#btnAiTabObs'); await page.waitForTimeout(250);
  // 长对话：两轮 Mock，写入画像，发送并检查记忆
  await page.fill('#aiChatInput', '第一轮：先说说这幅画的问题');
  await page.click('#btnAiChatSend'); await page.waitForTimeout(500);
  await page.fill('#aiChatInput', '第二轮：结合我的风格偏好再说一次');
  await page.click('#btnAiChatSend'); await page.waitForTimeout(500);
  await page.evaluate(() => { const el = document.getElementById('aiProfileStyle'); if (el) { el.value = '冷灰蓝、留白、颗粒'; el.dispatchEvent(new Event('input', { bubbles: true })); } });
  await page.fill('#aiChatInput', '第三轮：按你记住的风格给建议');
  await page.click('#btnAiChatSend'); await page.waitForTimeout(500);
  out.cases.chat = await page.evaluate(() => ({ len: window.__V2_APP__.aiChat.length, last: (window.__V2_APP__.aiChat.slice(-1)[0] || {}).content || '', profile: (document.getElementById('aiProfileStyle') || {}).value || '', chips: document.querySelectorAll('[data-chat-ctx]').length, stored: !!localStorage.getItem('mozheng.ai.chat.v1'), profileStored: !!localStorage.getItem('mozheng.ai.profile.v1') }));
  // 重载后记忆仍在
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(800);
  out.cases.persist = await page.evaluate(() => ({ len: window.__V2_APP__.aiChat.length, profile: (window.__V2_APP__.state.aiProfile || {}).style || '' }));
  out.cases.tabsOk = out.cases.tabs.labels.join('/') === '观察/生成/记录' && /模型/.test(out.cases.tabs.pinned) && /成本|¥0/.test(out.cases.tabs.pinned) && /Mock/.test(out.cases.tabs.status);
  out.cases.tabsOk = out.cases.tabsOk || (out.cases.tabs.labels.length === 3 && out.cases.tabs.labels.join('/') === '观察/生成/记录');
  out.cases.recordsOk = out.cases.records.records && out.cases.records.archive && out.cases.records.evidence && out.cases.recEvidence.evidenceDisplay !== 'none' && out.cases.recEvidence.active === 'evidence';
  out.cases.modelOk = out.cases.model.display !== 'none' && out.cases.model.hasBody && out.cases.model.badgeActive;
  out.cases.chatOk = out.cases.chat.len >= 6 && /风格|记住|冷灰蓝/.test(out.cases.chat.last) && out.cases.chat.chips === 5 && out.cases.chat.stored && out.cases.chat.profileStored;
  out.cases.persistOk = out.cases.persist.len >= 6 && out.cases.persist.profile.includes('冷灰蓝');
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.tabsOk && out.cases.recordsOk && out.cases.modelOk && out.cases.chatOk && out.cases.persistOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) { out.fatal = String(e && e.stack || e); await finish(3); }
