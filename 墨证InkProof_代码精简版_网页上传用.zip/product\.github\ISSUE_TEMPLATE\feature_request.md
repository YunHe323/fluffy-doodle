---
name: Feature request
about: Suggest an idea or improvement for Mozheng
labels: enhancement
---

## Problem

<!-- What problem are you trying to solve? Who is affected? -->

## Proposed solution

<!-- What would you like to see? Sketches/wireframes are welcome. -->

## Scope fit

- Is this within the **v0.1 scope** (local canvas, archive, stuck moment, evidence package, mock AI, onboarding/demo, persistence)?
- Or is it a candidate for a later version (e.g. PSD, cloud sync, real models, mobile)? Please say which.

> v0.1 deliberately excludes accounts, payments, cloud sync, multi-user collaboration, PSD import/export, L3 relationship archive, automatic semantic layer decomposition, and real model quality promises.

## Alternatives considered

<!-- Workarounds or other designs you have considered. -->

## Privacy / offline impact

- Does it require network access? <!-- yes (optional, opt-in) / no -->
- Does it send data outside the machine? <!-- yes / no / not sure -->
- Would it work in mock mode? <!-- yes / no -->

## Additional context

<!-- Mockups, references, related issues. Please do not paste private artwork or sensitive data. -->
