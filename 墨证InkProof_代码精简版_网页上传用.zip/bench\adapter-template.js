// bench/adapter-template.js
// ---------------------------------------------------------------
// 统一 BenchAdapter 模板（复制到 spike/<route>/adapter.js 后改名实现）
// 契约：bench/README.md §3（schema: mozheng.bench.v1）
//
// 使用方法：
//   1) copy bench/adapter-template.js spike/klecks/adapter.js（或 spike/webgl/、spike/canvaskit/）
//   2) 把 id/version/license 改成真实值（license 必须真实：MIT/BSD-3/...）
//   3) 用真实渲染器替换下面 TODO 标出的 Canvas2D 占位实现
//   4) 启动静态服务器，打开 bench/index.html，在 "Adapter 脚本 URL" 填相对路径 → 加载
//
// 约束：零依赖；不在此文件发任何网络请求；不缓存/读取用户数据。
// 本模板用 Canvas2D 占位（仅作接口示例；它会被测量，但不是选型候选）。
// ---------------------------------------------------------------
(function () {
  'use strict';

  /** @typedef {{x:number,y:number,pressure:number,timestamp:number,pointerType:string,tiltX?:number,tiltY?:number}} StrokePoint */

  const adapter = {
    id: 'template',          // TODO: 'klecks' | 'canvaskit' | 'webgl2' | 'selftest'
    version: '0.0.1',        // TODO: 被测代码版本/commit
    license: 'MIT',          // TODO: 真实许可（MIT / BSD-3-Clause / ...）

    /**
     * @param {{canvas: HTMLCanvasElement, width: number, height: number, layers: number,
     *          blendMode?: string, brush?: {type: string, sizePx: number}}} config
     */
    async init(config) {
      this._canvas = config.canvas;
      this._width = config.width;
      this._height = config.height;
      this._layers = config.layers || 1;
      this._brush = config.brush || { type: 'soft-round', sizePx: 32 };
      this._blend = config.blendMode || 'normal';
      this._undo = [];

      // TODO: 替换为真实渲染器（WebGL2 tile / CanvasKit surface / Klecks engine）
      this._ctx = this._canvas.getContext('2d', { willReadFrequently: true });
      this._ctx.fillStyle = '#ffffff';
      this._ctx.fillRect(0, 0, this._width, this._height);
      this._ctx.lineCap = 'round';
      this._ctx.lineJoin = 'round';
      this._dirty = true;
      await new Promise((r) => requestAnimationFrame(r));
    },

    /** @param {StrokePoint} p */
    beginStroke(p) {
      this._last = p;
      this._ctx.strokeStyle = '#1f2328';
      this._ctx.lineWidth = Math.max(1, (this._brush.sizePx || 32) * (0.15 + p.pressure * 0.85));
      this._ctx.beginPath();
      this._ctx.moveTo(p.x, p.y);
    },

    /** @param {StrokePoint} p */
    moveStroke(p) {
      // TODO: 真实实现要处理 coalesced/predicted 点、压感/tilt、脏 tile 增量
      this._ctx.lineTo(p.x, p.y);
      this._ctx.stroke();
      this._ctx.strokeStyle = '#1f2328';
      this._ctx.lineWidth = Math.max(1, (this._brush.sizePx || 32) * (0.15 + (p.pressure ?? 0.5) * 0.85));
      this._last = p;
    },

    endStroke() {
      // TODO: 真实实现：提交 tile patch 到 undo 历史（不要整画布快照）
      if (this._undo.length < 90) {
        this._undo.push(this._canvas.toDataURL('image/png'));
      }
    },

    /** @param {number} steps */
    async undo(steps) {
      for (let i = 0; i < steps; i += 1) {
        const dataUrl = this._undo.pop();
        if (!dataUrl) break;
        const img = new Image();
        img.src = dataUrl;
        await img.decode();
        this._ctx.drawImage(img, 0, 0);
      }
    },

    /** 可选：B5 混合模式测量需要 */
    setBlendMode(mode) {
      // TODO: WebGL blend / CanvasKit blendMode 实现
      this._blend = mode;
    },

    async getCompositeDataUrl() {
      return this._canvas.toDataURL('image/png');
    },

    /** 可选：扩展统计（显存估算/tile 数等），不得挤占标准字段 */
    getStats() {
      return { renderer: 'canvas2d-template', layers: this._layers };
    },

    dispose() {
      this._undo = [];
      this._ctx = null;
    },
  };

  window.BenchAdapter = adapter;
})();
