// v2/app/test-image-workshop.mjs —— AI 图像工作台：生成 / 编辑（Mock），结果可预览/落层/变换
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8155;
const out = { schema: 'mozheng.app.image-workshop.v1', cases: {}, errors: [], pass: false };
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser = null;
const finish = async (code) => {
  try { await browser.close(); } catch (e) {}
  try { py.kill(); } catch (e) {}
  fs.writeFileSync(ROOT + '\\v2\\app\\test-image-workshop-result.json', JSON.stringify(out, null, 2), 'utf8');
  process.exit(code);
};
try {
  await sleep(900);
  browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
  page.on('pageerror', (e) => out.errors.push(String(e.message || e).slice(0, 200)));
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|401|Unauthorized/i.test(m.text())) out.errors.push(m.text().slice(0, 200)); });
  await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 45000 });
  await page.waitForTimeout(1000);
  await page.evaluate(() => { const a = window.__V2_APP__; a.t96.setToggles({ allowReal: false, privacyMode: true }); a.state.selection = { x: 320, y: 240, width: 360, height: 260 }; a.drawSelection(); a.openPopover('popAI'); a.switchAiTab('image'); });
  await page.waitForTimeout(400);
  out.cases.tab = await page.evaluate(() => ({ visible: getComputedStyle(document.getElementById('aiTabImage')).display !== 'none', prompt: !!document.getElementById('aiImagePrompt'), gen: !!document.getElementById('btnImgGenerate'), edit: !!document.getElementById('btnImgEdit') }));
  await page.fill('#aiImagePrompt', '把选区改成清晨冷雾，保留笔触');
  await page.click('#btnImgGenerate');
  await page.waitForTimeout(1200);
  out.cases.generate = await page.evaluate(() => { const a = window.__V2_APP__; return { candidates: (a.state.candidates || []).length, cards: document.querySelectorAll('#aiImageBody .cand-card').length, meta: a.state.aiLastCall, transform: !!a.state.transformActive }; });
  // 画布预览
  await page.click('[data-img-preview="0"]');
  await page.waitForTimeout(300);
  out.cases.preview = await page.evaluate(() => { const a = window.__V2_APP__; const c = document.getElementById('candidatePreviewCanvas'); const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let alpha = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 8) { alpha += 1; if (alpha > 1000) break; } return { idx: a.state.previewCandidateIndex, alpha }; });
  // 落层 + 自动变换
  const before = await page.evaluate(() => window.__V2_APP__.engine.getLayers().length);
  await page.click('[data-img-apply="0"]');
  await page.waitForTimeout(800);
  out.cases.apply = await page.evaluate(() => { const a = window.__V2_APP__; return { layers: a.engine.getLayers().length, transformActive: !!a.state.transformActive, tool: a.state.tool, undo: a.engine.getStats().undoDepth }; });
  out.cases.before = before;
  // 编辑模式
  await page.evaluate(() => window.__V2_APP__.switchAiTab('image'));
  await page.waitForTimeout(300);
  await page.fill('#aiImagePrompt', '换成水彩风格');
  await page.click('#btnImgEdit');
  await page.waitForTimeout(1500);
  out.cases.edit = await page.evaluate(() => { const a = window.__V2_APP__; return { candidates: (a.state.candidates || []).length, task: a.state.aiLastCall && a.state.aiLastCall.task, mock: a.state.aiLastCall && a.state.aiLastCall.mock }; });
  await page.screenshot({ path: ROOT + '\\v2\\app\\ui-image-workshop-1920.png' });
  out.cases.tabOk = out.cases.tab.visible && out.cases.tab.prompt && out.cases.tab.gen && out.cases.tab.edit;
  out.cases.generateOk = out.cases.generate.candidates >= 1 && out.cases.generate.cards >= 1;
  out.cases.previewOk = out.cases.preview.alpha > 100;
  out.cases.applyOk = out.cases.apply.layers === before + 1 && out.cases.apply.transformActive;
  out.cases.editOk = out.cases.edit.candidates >= 1 && out.cases.edit.task === 'edit';
  out.cases.noErrors = out.errors.length === 0;
  out.pass = out.cases.tabOk && out.cases.generateOk && out.cases.previewOk && out.cases.applyOk && out.cases.editOk && out.cases.noErrors;
  await finish(out.pass ? 0 : 1);
} catch (e) {
  out.fatal = String(e && e.stack || e);
  await finish(3);
}
