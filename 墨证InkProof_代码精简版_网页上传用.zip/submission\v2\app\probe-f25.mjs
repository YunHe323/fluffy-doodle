import { spawn } from 'node:child_process';
import { chromium } from '../qa/node_modules/playwright-core/index.mjs';
const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const PORT = 8123;
const py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore' });
const b = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'] });
const page = await b.newPage({ viewport: { width: 1366, height: 768 } });
await page.goto(`http://127.0.0.1:${PORT}/v2/app/index.html`); await page.waitForFunction('window.__V2_APP_READY__ === true'); await page.waitForTimeout(1000);
const box = await page.locator('#mainCanvas').boundingBox();
await page.evaluate(() => { const a = window.__V2_APP__; a.engine.setActiveLayer(a.engine.getLayers()[0].id); a.setTool('brush'); });
await page.mouse.move(box.x + box.width * 0.25, box.y + box.height * 0.4); await page.mouse.down();
for (let i = 1; i <= 10; i++) await page.mouse.move(box.x + box.width * (0.25 + i * 0.05), box.y + box.height * (0.4 + i * 0.015));
await page.mouse.up(); await page.waitForTimeout(1800);
const save = await page.evaluate(async () => {
  const app = window.__V2_APP__; const e = app.engine;
  const norm = (doc) => JSON.stringify({ layers: (doc.layers || []).map((l) => ({ id: l.id, name: l.name, visible: l.visible, blend: l.blend })), groups: (doc.groups || []).map((g) => g.id) });
  const doc = JSON.stringify(e.getDoc());
  const normJson = norm(e.getDoc());
  const saved = await app.t81.saveProjectAsync({ compress: true });
  const bytes = new Uint8Array(await saved.blob.arrayBuffer());
  const head = [bytes[0], bytes[1]];
  // gzip decompress in page
  const json = await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
  const parsed = JSON.parse(json);
  let bin = ''; const CH = 0x8000; for (let i = 0; i < bytes.length; i += CH) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  return { doc, normJson, parsedDoc: JSON.stringify(parsed.doc), parsedNorm: norm(parsed.doc), head, bytes: saved.bytes, b64: btoa(bin) };
});
await page.reload({ waitUntil: 'load' }); await page.waitForFunction('window.__V2_APP_READY__ === true'); await page.waitForTimeout(1200);
const open = await page.evaluate(async (b64) => {
  const app = window.__V2_APP__; const t = app.t81; const e = app.engine;
  const norm = (doc) => JSON.stringify({ layers: (doc.layers || []).map((l) => ({ id: l.id, name: l.name, visible: l.visible, blend: l.blend })), groups: (doc.groups || []).map((g) => g.id) });
  const before = norm(e.getDoc());
  const bin = atob(b64); const bytes = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
  await t.loadProjectData(bytes);
  await new Promise((r) => setTimeout(r, 500));
  return { autoNorm: before, openedNorm: norm(e.getDoc()), openedDoc: JSON.stringify(e.getDoc()) };
}, save.b64);
console.log(JSON.stringify({ savedNormEqualsOriginal: save.parsedNorm === save.normJson, openedNormEqualsOriginal: open.openedNorm === save.normJson, save: { doc: save.doc, parsedDoc: save.parsedDoc, norm: save.normJson, parsedNorm: save.parsedNorm }, open }, null, 2));
await b.close(); py.kill(); process.exit(0);
