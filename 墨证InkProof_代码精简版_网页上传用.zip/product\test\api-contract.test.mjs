// product/test/api-contract.test.mjs
// 起真实 HTTP 服务打请求，验证 product/CONTRACT.md §1–§2 的接口与错误格式。
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';

import { startServer } from '../server/server.mjs';

const CANVAS = {
  dataUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
  width: 1024,
  height: 768,
  layerCount: 3,
};

let srv = null;
let base = '';
let state = null;

before(async () => {
  srv = await startServer({ port: 0, loadConfigFile: false, logger: false });
  base = srv.url;
});

after(async () => {
  if (srv) await srv.close();
});

async function request(pathname, options = {}) {
  const response = await fetch(`${base}${pathname}`, options);
  const text = await response.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* 静态资源不是 JSON */ }
  return { response, json, text };
}

function jsonPost(pathname, body) {
  return request(pathname, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

test('契约：health / analyze / directions / generate / config / 错误 / 静态', async (t) => {
  await t.test('GET /api/health', async () => {
    const { response, json } = await request('/api/health');
    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type'), /application\/json/);
    assert.ok(response.headers.get('x-request-id'));
    assert.equal(json.ok, true);
    assert.equal(typeof json.version, 'string');
    assert.equal(json.mode, 'mock');
    assert.equal(json.provider, 'mock');
    assert.equal(json.network, 'none');
    assert.equal(json.telemetry, false);
    assert.equal(json.core.archiveSchema, '0.2.0');
    assert.ok(json.uptimeSec >= 0);
  });

  await t.test('POST /api/ai/analyze 正常路径', async () => {
    const { response, json } = await jsonPost('/api/ai/analyze', {
      canvas: CANVAS,
      selection: { mode: 'rect', rect: { x: 200, y: 120, width: 300, height: 260 } },
      context: { mode: 'collab', aiRole: 'assistant', userNote: '袖口有点闷' },
    });
    assert.equal(response.status, 200);
    assert.equal(json.ok, true);
    assert.equal(json.mode, 'mock');
    assert.equal(json.model, 'mock-ai@0.1.0');
    assert.match(json.requestId, /^r_[0-9a-f]{8}$/);
    assert.ok(json.result.observations.length >= 2);
    assert.ok(json.result.regions.length >= 1);
    assert.equal(typeof json.result.global.summary, 'string');
    assert.ok(json.result.confidence >= 0 && json.result.confidence <= 1);
  });

  await t.test('POST /api/ai/analyze 参数错误 → 400 统一错误格式', async () => {
    const { response, json } = await jsonPost('/api/ai/analyze', { canvas: { dataUrl: 'not-a-data-url', width: 10, height: 10 } });
    assert.equal(response.status, 400);
    assert.equal(json.ok, false);
    assert.equal(json.code, 'BAD_REQUEST');
    assert.equal(typeof json.message, 'string');
    assert.ok(Array.isArray(json.detail) && json.detail.length > 0);
    assert.ok(json.detail.some((e) => e.path === 'canvas.dataUrl'));
  });

  await t.test('POST /api/ai/analyze 选区越界 → 400', async () => {
    const { response, json } = await jsonPost('/api/ai/analyze', {
      canvas: CANVAS,
      selection: { mode: 'rect', rect: { x: 1000, y: 700, width: 500, height: 500 } },
    });
    assert.equal(response.status, 400);
    assert.ok(json.detail.some((e) => e.path === 'selection.rect' && e.error === 'exceeds_canvas_width'));
  });

  await t.test('选区坐标为小数 → 服务端取整后接受', async () => {
    const { response, json } = await jsonPost('/api/ai/analyze', {
      canvas: CANVAS,
      selection: { mode: 'rect', rect: { x: 200.4, y: 120.6, width: 300.2, height: 260.8 } },
    });
    assert.equal(response.status, 200);
    assert.equal(json.ok, true);
    assert.ok(json.result.regions.length >= 1);
  });

  await t.test('兼容前端 buildAnalyzeInput 形状（archiveSummary:null、userNote:""）', async () => {
    const { response, json } = await jsonPost('/api/ai/analyze', {
      canvas: CANVAS,
      selection: { mode: 'rect', rect: { x: 200, y: 120, width: 300, height: 260 } },
      context: { mode: 'collab', aiRole: 'assistant', archiveSummary: null, userNote: '' },
    });
    assert.equal(response.status, 200);
    assert.equal(json.ok, true);
  });

  await t.test('Content-Type 非 JSON → 415', async () => {
    const { response, json } = await request('/api/ai/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain' },
      body: '{"a":1}',
    });
    assert.equal(response.status, 415);
    assert.equal(json.code, 'UNSUPPORTED_MEDIA_TYPE');
  });

  await t.test('GET /api/health 方法错误 → 405 + Allow', async () => {
    const { response, json } = await request('/api/health', { method: 'DELETE' });
    assert.equal(response.status, 405);
    assert.equal(json.code, 'METHOD_NOT_ALLOWED');
    assert.match(response.headers.get('allow'), /GET/);
  });

  await t.test('未知 API → 404', async () => {
    const { response, json } = await request('/api/unknown');
    assert.equal(response.status, 404);
    assert.equal(json.code, 'NOT_FOUND');
  });

  await t.test('POST /api/ai/directions 与 generate 正常路径', async () => {
    const analyze = await jsonPost('/api/ai/analyze', { canvas: CANVAS });
    assert.equal(analyze.response.status, 200);
    const observationIds = analyze.json.result.observations.map((o) => o.id);

    const directions = await jsonPost('/api/ai/directions', { canvas: CANVAS, observationIds, count: 3 });
    assert.equal(directions.response.status, 200);
    assert.equal(directions.json.result.directions.length, 3);

    const directionId = directions.json.result.directions[0].id;
    const generate = await jsonPost('/api/ai/generate', {
      canvas: CANVAS,
      directionId,
      count: 2,
      size: { width: 512, height: 384 },
    });
    assert.equal(generate.response.status, 200);
    assert.equal(generate.json.result.candidates.length, 2);
    assert.equal(generate.json.result.credits, 0);
    assert.ok(generate.json.result.candidates[0].imageDataUrl.startsWith('data:image/svg+xml;base64,'));
  });

  await t.test('generate 缺 directionId → 400', async () => {
    const { response, json } = await jsonPost('/api/ai/generate', { canvas: CANVAS });
    assert.equal(response.status, 400);
    assert.ok(json.detail.some((e) => e.path === 'directionId'));
  });

  await t.test('GET /api/config：默认 mock、密钥不返回', async () => {
    const { response, json } = await request('/api/config');
    assert.equal(response.status, 200);
    assert.equal(json.config.provider, 'mock');
    assert.equal(json.config.apiKeySet, false);
    assert.equal(json.config.apiKey, undefined);
    assert.equal(typeof json.config.updatedAt, 'string');
  });

  await t.test('PUT /api/config：部分更新 + apiKey 只进不出', async () => {
    const put = await request('/api/config', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider: 'mock', model: 'demo-model', apiKey: 'sk-secret-should-not-return' }),
    });
    assert.equal(put.response.status, 200);
    assert.equal(put.json.config.model, 'demo-model');
    assert.equal(put.json.config.apiKeySet, true);
    assert.equal(put.json.config.apiKey, undefined);

    const get = await request('/api/config');
    assert.equal(get.json.config.apiKeySet, true);
    assert.equal(get.json.config.apiKey, undefined);
    assert.ok(!get.text.includes('sk-secret-should-not-return'), 'GET 不得返回明文密钥');
    assert.ok(!put.text.includes('sk-secret-should-not-return'), 'PUT 响应不得返回明文密钥');
  });

  await t.test('PUT /api/config 非法 provider → 400 CONFIG_INVALID', async () => {
    const { response, json } = await request('/api/config', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider: 'nope' }),
    });
    assert.equal(response.status, 400);
    assert.equal(json.code, 'CONFIG_INVALID');
    assert.ok(Array.isArray(json.detail));
  });

  await t.test('provider 非 mock → AI 接口 501（不发起任何网络调用）', async () => {
    try {
      const put = await request('/api/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: 'openai-compatible',
          baseUrl: 'https://api.example.invalid/v1',
          model: 'example-model',
        }),
      });
      assert.equal(put.response.status, 200);

      const ai = await jsonPost('/api/ai/analyze', { canvas: CANVAS });
      assert.equal(ai.response.status, 501);
      assert.equal(ai.json.code, 'NOT_IMPLEMENTED');
    } finally {
      await request('/api/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider: 'mock' }),
      });
    }
  });

  await t.test('静态：GET / → HTML（app 未就绪时为占位页）', async () => {
    const { response, text } = await request('/');
    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type'), /text\/html/);
    assert.match(text.toLowerCase(), /<!doctype html>/);
  });

  await t.test('静态：/core/hash-chain.mjs 可被前端 import', async () => {
    const { response, text } = await request('/core/hash-chain.mjs');
    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type'), /text\/javascript/);
    assert.ok(text.includes('export async function sha256Hex'));
  });

  await t.test('安全：路径穿越被拒绝', async () => {
    const attempts = [
      '/..%2f..%2fpackage.json',
      '/..%2f..%2fserver%2fserver.mjs',
      '/%2e%2e/%2e%2e/package.json',
    ];
    for (const pathname of attempts) {
      const { response } = await request(pathname);
      assert.ok(response.status === 400 || response.status === 404, `${pathname} 不应 200（得到 ${response.status}）`);
    }
    const nul = await request('/%00');
    assert.ok(nul.response.status >= 400);
  });

  await t.test('静态：不存在且带扩展名 → 404', async () => {
    const { response, json } = await request('/nope.js');
    assert.equal(response.status, 404);
    assert.equal(json.code, 'NOT_FOUND');
  });

  await t.test('请求体超限 → 413（独立小上限服务）', async () => {
    const small = await startServer({ port: 0, loadConfigFile: false, logger: false, maxBodyBytes: 256 });
    try {
      const payload = JSON.stringify({ canvas: { dataUrl: `data:image/png;base64,${'A'.repeat(600)}`, width: 10, height: 10 } });
      const response = await fetch(`${small.url}/api/ai/analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: payload,
      });
      assert.equal(response.status, 413);
      const json = await response.json();
      assert.equal(json.code, 'PAYLOAD_TOO_LARGE');
    } finally {
      await small.close();
    }
  });
});
