# 墨证 InkProof

> 给画师的**创作记忆与本地过程记录层**——AI 帮你画，每一步留下可复核的本地记录。
> 中源黑客松 × 郑州轻工业大学 · 2026-11-08｜主题「身边的小问题，值得一个新产品」· 主赛道
> 现场：**5 分钟展示 + 3 分钟问答**。时长、截止时间与评审权重已于 **2026-11-08 10:10 与主办方公布文本核对一致**（见 `官方规则待核实.md`，已更新为「已核实」）；现场如另有口头调整，以主办方当场公布为准。

---

## 30 秒了解

AI 能画得很好看，但它记不住**你为什么这样画**，也不掌握**哪些改动出自你**。墨证把三件事缝进一个**本地**画布：

1. **私人视觉记忆**：素材被 AI 读成结构化档案（L0 原图 / L1 全局 / L2 区域 / L4 观察 / L5 决策），成为 AI 协作的依据；
2. **本地过程记录**：对 `events[]` 中的 AI 介入、确认 / 否决事件记录模型、时间、token、花费与哈希，可导出证据包供本地完整性复核；
3. **卡住时刻协作**：框选一块，AI 读懂它，给观察与方向；选中的方案**只落在框内**，落成可继续编辑的图层。

**不是让 AI 替你画，而是让 AI 帮你画，并把协作过程如实记录下来。**

> 对应主题方向：**少折腾**——把「卡住时的重复试错」变成一次有依据的协作。墨证不是学习陪伴产品，走主赛道。

---

## 截图（真实 Qwen 模式 · 路演模式）

> 图片路径以**提交仓库根目录**为准（`hackathon/assets/`）；从 `hackathon/README.md` 单独预览时，相对图片路径可能显示不到，请回到仓库根查看。

![路演 · 真实视觉观察](hackathon/assets/roadshow-observe.png)

| 局部落层（框外不变） | 证据包（真实调用 1 次） |
|---|---|
| ![路演 · 预置样本局部落层](hackathon/assets/roadshow-apply.png) | ![路演 · 证据包](hackathon/assets/roadshow-evidence.png) |

> 第 3 拍为**实时** Qwen 视觉（实测 3–15s）；第 5 拍默认**实时**图像编辑（实测 12–25s，官价估算 ¥0.52/张），真实失败或无 key 时**显式降级**为预置样本（此前真实 Qwen 生成的历史文件，`v2/app/demo/assets.json` 记有 sha256 / model / task_id / 生成时间；按选区合成，框外 0 像素变化，本场 0 元、非本场调用）。三类真实度（实时 / 预置样本 / Mock）在 UI、图层名、L6 三处同时标注，降级不静默。
> **诚实边界**：包住预置样本的「昨天 / 客户决定」是**演示剧本**，不是真实用户历史；脚本代点的 L5 与 7 条预置 L6 均标 `synthetic`，**不进入正式 `events[]` 证据链**，见 `v2/app/js/app.js` 的 `buildEvidence()`。真实调用的延迟与用量实测见 `v2/app/test-roadshow-real-result.json`；成本为官价估算，非账单实测。

## 证据与复现

本 README **不罗列「已跑通 N/N」之类的数字断言**：那些测试依赖开发工作区的浏览器自动化组件与本地服务，在本提交包内不保证能重跑。所有原始证据随包提供，**逐条断言 → 证据文件**如下；复现命令、依赖与替代读法见 [`VERIFY.md`](VERIFY.md)。结果 JSON / 回归日志 / 彩排截图随包放在 `v2/qa/tools/` 与 `v2/app/`。

| 断言 | 证据文件（包内相对路径） |
|---|---|
| 路演 6 拍端到端脚本 | `v2/app/test-roadshow.mjs` |
| 路演 6 拍端到端结果 | `v2/app/test-roadshow-result.json` |
| 核心回归日志 | `v2/qa/tools/final-core-regression.txt` |
| 扩展回归日志 | `v2/qa/tools/extended-regression.txt` |
| 功能回归结果与报告 | `v2/qa/tools/functional-regression.json` · `v2/qa/tools/functional-regression-report.md` |
| 性能回归报告 | `v2/qa/tools/perf-regression-report.md` |
| 真实 Qwen 调用证据 | `v2/qa/tools/qwen-real-evidence.json` |
| 最终彩排结果 | `v2/qa/tools/rehearse-final-result.json` |
| 真实路演彩排结果 | `v2/qa/tools/rehearse-roadshow-real-result.json` |
| 证据包第三方复核集成结果 | `v2/qa/tools/verify-evidence-integration-results.json` |
| 证据包复核器（零依赖） | `v2/qa/tools/verify-evidence.mjs` |
| 复核器自测结果 | `v2/qa/tools/verify-evidence-test-results.json` |
| 录屏前自检脚本 | `v2/qa/tools/demo-preflight.mjs` |
| T117 收口 QA 记录 | `v2/qa/tools/T117-final-qa.md` |
| T117 48 项 QA 结果（41 PASS / 7 FAIL，未改断言） | `v2/qa/tools/T117-mask-qa-result.json` |
| 整改轮证据链隔离独立回归（13/13 PASS） | `v2/qa/tools/T118-fix-verification.mjs` · `v2/qa/tools/T118-fix-verification-result.json` |
| 运行期敏感路径黑盒自检（零依赖，可现场直接跑） | `v2/qa/tools/port-hygiene.mjs` · `v2/qa/tools/port-hygiene-result.json` |
| 提交包只读验证器与结果（FAIL=0） | `hackathon/verify-submission.mjs` · `VERIFY-RESULT.json` |
| 彩排 6 拍截图 | `v2/app/rehearsal-1-brief.png` … `v2/app/rehearsal-6-evidence.png` |
| 断网降级单文件演示 | `hackathon/demo/index.html` |

---

## 许可与第三方

- CanvasKit / Skia：**BSD-3-Clause**（见 `v2/engine/vendor/THIRD_PARTY_NOTICES.md` 与 `v2/engine/vendor/LICENSE`）；
- ag-psd：**MIT**（`v2/psd/THIRD_PARTY_NOTICES.md`）；perfect-freehand：**MIT**（`v2/brushes/THIRD_PARTY_NOTICES.md`）；
- QA 测试期依赖（playwright-core / 本机 Edge）的许可与用途见 `v2/qa/THIRD_PARTY_NOTICES.md`，仅测试期使用、不进产品运行时；
- 各目录第三方声明的汇总索引见包根 `THIRD_PARTY_NOTICES.md`；
- Krita / Krita AI Diffusion / ComfyUI / Fooocus / GIMP 等 **GPL 项目只做交互与工作流参考，未复制代码**；tldraw 的自定义许可代码未采用；
- **项目自身源码许可：MIT，见包根 `LICENSE`**（Copyright 2026 墨证 InkProof 团队）。

---

## 立即运行（本地，无需联网）

1. 双击 **`v2/start.bat`**；
2. **看弹出的黑色窗口**：`start.bat` 会先删除旧的 `v2/.runtime-port`，服务起来后把**实际端口**写入该文件，并用这个端口自动打开正确的产品地址（`http://127.0.0.1:<实际端口>/v2/app/index.html`）。端口是动态的（可能被占用而顺延），**不要手写死地址**；窗口里会列出 App / Diag / Engine 等地址，以窗口打印的为准；
3. 若窗口提示「Server failed to start」，看「Mozheng v2 demo server」窗口里的报错；
4. 顶部点 **「路演」** → 「开始路演」→ 按 6 拍走。

> 没有 Node 时无法运行主产品（v2 依赖本地 Node 服务）。**降级演示：直接用浏览器打开 `hackathon/demo/index.html`**——这是**无需 Node、无需联网的单文件降级演示**，可离线直接打开，不是旧版备份。
> 启动服务后建议跑一次 `node v2/qa/tools/port-hygiene.mjs`（零依赖、只读）复核敏感路径无泄露——**磁盘上的安全修复不会热更新已启动的 Node 进程**，若机器上残留整改前启动的旧实例，仍可能对外提供旧路由。

### 真实模型（可选）

- 路径一：AI 面板 →「模型」→「配置模型接入」，填 DashScope / Qwen key；
- 路径二：本地 `v2/.ai-config.json`（**已在 `.gitignore`，不要提交**）；
- 没有 key 或开隐私模式：自动 Mock，界面标注「Mock 占位 · 未调用模型」，不联网、不花钱。

---

## 5 分钟展示 + 3 分钟问答（路演模式 · 6 拍）

1. **客户 brief / 本地档案**：项目《呼吸》· 短片概念图；客户要求把山谷雾带改成清晨冷雾、保留近水笔触；明早 10:00 交付；
2. **框选雾带 + 打开 AI 对话**：真选区（mask 生效），不是假框；
3. **让 AI 看看**：真实视觉理解；观察可确认 / 否决；L5 决策进上下文，AI 能回指此前的取舍；
4. **确认 2 条 / 否决 1 条**：写回 L5，成为下一次的依据；
5. **选方向 → 落新图层**：默认**真实编辑**（实测 12–25s）；失败或无 key 时显式降级为同一模型的**预置样本**（标注 sha256 / model / 时间，本场 0 元）；框外像素不变（逐像素验证 0 变化）；
6. **导出证据包**：事件哈希链、画布 PNG 字节 SHA-256（可 `Get-FileHash` 对照）、图层哈希、AI 调用清单。

> 详细旁白与镜头见 `scripts/演示视频脚本_v2.md`，现场操作见 `路演操作手册.md`。

---

## 已实现 / 诚实边界

**已实现**
- CanvasKit/Skia tile 画布、11 笔刷、压感、选区 / 套索 / 魔棒、图层 / 组 / 蒙版 / 剪贴、变换、历史撤销、PSD 导入导出、`.mozheng` 单文件；
- AI：Qwen 视觉 / 对话 / 生图 / 图像编辑；选区局部落层，**框外像素 diff=0**；Mock 与真实同协议；
- 素材库 L0/L1/L2/L4/L5/L6、批量重读 review、素材引用（最多 3 张）、结果回库 provenance；
- 非破坏调整层（快照缓存）、结构化文字层、参考线 / 网格 / 对称、批量 review、证据包 + 包内校验器；
- 路演模式（6 拍、真实 / 预置 / Mock 三档标注、控制台、退出恢复）。

**明确边界**
- 调整层是**栅格快照缓存**，不是 Photoshop 式实时调整层；
- 文字是结构字段 + 栅格缓存，不是运行时排版；
- 证据链是**本地事件完整性校验链**：`chain_hash = SHA256(prev + canonicalJson(record))`，**无密钥、无 HMAC、无数字签名、无第三方时间戳（RFC 3161 / TSA）、无外部锚定**；任何人拿到证据包都能从头重算整条链，改任意事件后重算后续 hash，包内校验器仍会通过；它只能检测顺序错乱与无意损坏，**不能抵御蓄意改写，不是法律鉴定，也不构成归属证明**。`manifest.attest` 等元数据不在链上；
- L6 是**事件级**记录，不是逐笔留痕；
- **4096² 大画布蒙版写入仍有性能限制**（T117 G2/G3）：写入约 1.1–2.3s、端到端约 7.8s、最长长任务约 4.1s，仍超 2s 门槛。T117 四个功能 P1 已修，但 48 项 QA 仍有 7 项红（5 项为原脚本前提失效的非回归失败、2 项为真实性能未达标），**未改断言凑通过**，逐条判定见 `VERIFY.md` §2.7；路演不演示该大画布场景；
- 演示 / 预置 / 脚本代点事件**不进入正式证据链**，`manifest.demo_events_excluded` 记录被排除条数；
- 用户验证（权重 25%）**仍是空白模板，由真实用户执行，未由 AI 代填**；本包只提供工具与 SOP，不提供人数、评分或原话；
- Qwen 图像编辑**没有 mask 参数**：我们做的是「选区裁切 → 编辑 → 客户端按选区合成」，不是模型内 inpaint。

---

## 评审对齐（官方权重 25% / 30% / 25% / 20%，2026-11-08 已与主办方公布文本核对一致）

> 以下权重 / 时长 / 截止时间已与主办方公布文本核对一致（出处见 `官方规则待核实.md`）；现场如另有口头调整，以主办方当场公布为准。

| 维度（官方权重） | 我们怎么回答 | 材料 |
|---|---|---|
| 需求洞察 25% | 插画师 / 概念设计师的「卡住时刻」；AI 记不住素材 / 决策、不掌握归属 | 路演开头 |
| 原型完成度 30% | 现场 6 拍真实跑通；真实视觉 + 预置局部落层 + 证据包 | `彩排记录.md`、`路演操作手册.md`、包内结果 JSON 与彩排截图 |
| 用户验证 25% | **本项由真实用户执行，提交时如未完成即如实标注未完成；不编造人数、评分、原话** | `用户验证.md` / `用户验证表.html`（模板，未填则为空） |
| 价值与可持续 20% | 关系型记忆 + 本地过程记录；订阅 / 积分假设 | `路演5分钟脚本.md` |

> 提交 11/8 12:00 截止、12:00 后冻结；5 分钟展示 + 3 分钟问答——已与主办方公布文本核对一致（2026-11-08 10:10）。现场规则以主办方当场公布为准。

---

## 提交仓库

```powershell
# 在项目根目录执行：从工作区重建干净提交目录（纯 Node、零依赖、幂等，可重复运行）
node hackathon/package-submission.mjs
# 脚本会先清空再重建 submission/，复制运行时与全部证据，做密钥扫描，
# 并打印文件数 / 大小 / 各类计数 / 证据对照表；发现明文密钥会以退出码 1 阻断。
cd submission
git init
git add .
git commit -m "墨证 InkProof · 黑客松提交（v2 路演版）"
git branch -M main
git remote add origin <你的仓库地址>
git push -u origin main
```

> 注：上面这条打包命令是**开发工作区**的构建脚本，用于从工作区重建本提交目录，**不在提交包内**；评委在包内只需核对证据与 `VERIFY.md`。
> `.ai-config.json` / `.ai-token` 由脚本排除且写入 `.gitignore`，不进入提交包；`node_modules/`、`*.mp4`、`*.log` 同样排除。

## 目录

以下为**本提交包实际生成**的结构（由工作区打包脚本重建；**构建脚本 `package-submission.mjs` 不随包**，但**只读验证器 `verify-submission.mjs` 随包**）：

```
submission/                       # 提交仓库根目录
├─ README.md                      # 本文件（交付说明）
├─ VERIFY.md                      # 复现命令与证据对照说明
├─ VERIFY-RESULT.json             # 提交包只读验证器结果（FAIL=0）
├─ LICENSE                        # 项目自身 MIT 许可
├─ THIRD_PARTY_NOTICES.md         # 包内第三方许可声明索引
├─ CHANGELOG.md
├─ .gitignore
├─ _archive_pitch_DEPRECATED/     # mock 时代旧 PPT/PDF/py，非当前材料（见 DEPRECATED.md）
├─ v2/
│  ├─ start.bat / stop.bat / _server.bat
│  ├─ serve.mjs                   # 零依赖本地服务 + AI 代理
│  ├─ diag.html
│  ├─ app/                        # index.html + js/ css/ core/ demo/
│  │                             # + test-*.mjs + test-*-result.json + rehearsal-*.png
│  ├─ engine/                     # src/ vendor/(CanvasKit BSD-3-Clause) demo.html
│  ├─ brushes/ layers/ selection/ library/ psd/
│  └─ qa/
│     ├─ THIRD_PARTY_NOTICES.md
│     └─ tools/                   # 全部 .mjs / 结果 JSON / 回归日志 /
│                                # T1xx-final-qa.md / shots/t117-*.png
└─ hackathon/
   ├─ README.md                   # 与根 README 一致的修正版
   ├─ verify-submission.mjs       # 只读提交包验证器（零依赖，可现场运行）
   ├─ *.md / *.html              # 路演 / 问答 / 用户验证 / 彩排等工作材料
   ├─ scripts/                   # 演示视频脚本
   ├─ assets/                    # 路演截图（本文件截图段引用）
   └─ demo/                      # index.html + README.md（无需 Node/联网的降级演示）
```

---

## 团队

- 项目一团队（Lead + 情报 / 理论 / 技术 / 产品 / 交互 / demo / 独立 QA）
- 联系：[待填]
