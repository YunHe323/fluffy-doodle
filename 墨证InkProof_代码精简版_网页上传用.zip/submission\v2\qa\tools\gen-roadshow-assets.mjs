// v2/qa/tools/gen-roadshow-assets.mjs
// 路演 demo 视觉资产：生成一张原创概念插画 + 做一次真实局部编辑，落盘并记录 sha256/model/时间。
// 一次运行 ≈ ¥0.18（生图）+ ¥0.50（2K 编辑）≈ ¥0.68；只在需要换素材时重跑。
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const ROOT = 'C:\\Users\\xiao1\\Desktop\\项目一';
const OUT = path.join(ROOT, 'v2', 'app', 'demo');
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'v2', '.ai-config.json'), 'utf8'));
const provider = cfg.providers && cfg.providers.qwen ? cfg.providers.qwen : {};
const apiKey = provider.apiKey || cfg.apiKey;
if (!apiKey) { console.error('NO_KEY'); process.exit(2); }
const base = (provider.imageBaseUrl || cfg.imageBaseUrl || 'https://dashscope.aliyuncs.com').replace(/\/$/, '');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex');
const manifestPath = path.join(OUT, 'assets.json');
const manifest = fs.existsSync(manifestPath) ? JSON.parse(fs.readFileSync(manifestPath, 'utf8')) : { assets: {} };

const BASE_PROMPT = '电影概念场景插画：清晨的北方山谷，层叠远山被薄雾分成三层，前景一条近水倒映天光，冷灰蓝低饱和色调，水彩与水墨融合，保留手绘笔触与纸张纹理，留白构图，安静克制，高质量，画面中不要出现任何文字或水印';
const EDIT_PROMPT = '把画面中部的雾带改为清晨冷雾：更冷、更通透、有层次，保留远山轮廓、近水的手绘笔触与纸张纹理，整体构图不变，不要添加文字或水印';

async function download(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error('download ' + res.status);
  const ab = await res.arrayBuffer();
  const buf = Buffer.from(ab);
  const mime = (res.headers.get('content-type') || 'image/png').split(';')[0];
  const ext = mime.includes('jpeg') ? '.jpg' : mime.includes('webp') ? '.webp' : '.png';
  return { buf, mime, ext };
}
function save(name, buf, ext) {
  fs.mkdirSync(OUT, { recursive: true });
  const file = path.join(OUT, name + ext);
  fs.writeFileSync(file, buf);
  return { file, sha256: sha(buf), bytes: buf.length, ext };
}

async function generate(prompt, size) {
  const submitBody = {
    model: provider.imageModel || cfg.imageModel || 'qwen-image-3.0',
    input: { messages: [{ role: 'user', content: [{ text: prompt }] }] },
    parameters: { size, n: 1, prompt_extend: true, watermark: false, enable_thinking: false },
  };
  const res = await fetch(base + '/api/v1/services/aigc/image-generation/generation', {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + apiKey, 'X-DashScope-Async': 'enable' },
    body: JSON.stringify(submitBody),
  });
  if (!res.ok) throw new Error('submit ' + res.status + ' ' + (await res.text()).slice(0, 400));
  const data = await res.json();
  const taskId = (data.output && (data.output.task_id || data.output.taskId)) || data.task_id || data.id;
  if (!taskId) throw new Error('no task_id');
  let last = null;
  for (let i = 0; i < 60; i += 1) {
    await sleep(3000);
    const poll = await fetch(base + '/api/v1/tasks/' + encodeURIComponent(taskId), { headers: { authorization: 'Bearer ' + apiKey } });
    if (!poll.ok) throw new Error('poll ' + poll.status);
    last = await poll.json();
    const st = (last.output && (last.output.task_status || last.output.status)) || last.task_status || last.status;
    if (/SUCCEEDED|SUCCESS/i.test(String(st))) break;
    if (/FAILED|CANCELED|UNKNOWN/i.test(String(st))) throw new Error('task ' + st + ' ' + JSON.stringify(last).slice(0, 400));
  }
  const output = (last && last.output) || {};
  let results = output.results || output.result || (last && last.results) || [];
  if ((!Array.isArray(results) || !results.length) && Array.isArray(output.choices)) {
    results = [];
    for (const ch of output.choices) {
      const content = ch && ch.message && ch.message.content;
      if (Array.isArray(content)) for (const part of content) if (part && (part.image || part.url)) results.push(part);
    }
  }
  const url = Array.isArray(results) ? (results[0] && (results[0].url || results[0].image || results[0].image_url)) : (results && (results.url || results.image));
  if (!url) throw new Error('no result url: ' + JSON.stringify(last).slice(0, 500));
  return { url, taskId, model: submitBody.model, usage: last.usage || null };
}

async function edit(baseFile, prompt) {
  const b64 = fs.readFileSync(baseFile).toString('base64');
  const ext = path.extname(baseFile).replace('.', '') || 'png';
  const dataUrl = 'data:image/' + (ext === 'jpg' ? 'jpeg' : ext) + ';base64,' + b64;
  const model = provider.imageEditModel || 'qwen-image-3.0-pro';
  const submitBody = {
    model,
    input: { messages: [{ role: 'user', content: [{ image: dataUrl }, { text: prompt }] }] },
    parameters: { prompt_extend: true, watermark: false, enable_thinking: false },
  };
  const res = await fetch(base + '/api/v1/services/aigc/multimodal-generation/generation', {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + apiKey },
    body: JSON.stringify(submitBody),
  });
  if (!res.ok) throw new Error('edit ' + res.status + ' ' + (await res.text()).slice(0, 500));
  const data = await res.json();
  const choices = (data.output && data.output.choices) || data.choices || [];
  const urls = [];
  for (const ch of choices) {
    const content = ch && ch.message && ch.message.content;
    const parts = Array.isArray(content) ? content : (content ? [content] : []);
    for (const part of parts) if (part && (part.image || part.url || part.image_url)) urls.push(part.image || part.url || part.image_url);
  }
  if (!urls.length) throw new Error('edit no image: ' + JSON.stringify(data).slice(0, 500));
  return { url: urls[0], model, requestId: data.request_id || null, usage: data.usage || null };
}

try {
  const t0 = Date.now();
  const gen = await generate(BASE_PROMPT, '2048*2048');
  const baseDl = await download(gen.url);
  const baseSave = save('roadshow-base', baseDl.buf, baseDl.ext);
  manifest.assets.base = { file: 'demo/' + path.basename(baseSave.file), sha256: baseSave.sha256, bytes: baseSave.bytes, model: gen.model, prompt: BASE_PROMPT, generated_at: new Date().toISOString(), task_id: gen.taskId };
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
  console.log('BASE_OK', baseSave.file, baseSave.sha256.slice(0, 12), baseSave.bytes);

  const ed = await edit(baseSave.file, EDIT_PROMPT);
  const editDl = await download(ed.url);
  const editSave = save('roadshow-edit', editDl.buf, editDl.ext);
  manifest.assets.edit = { file: 'demo/' + path.basename(editSave.file), sha256: editSave.sha256, bytes: editSave.bytes, model: ed.model, prompt: EDIT_PROMPT, generated_at: new Date().toISOString(), source_sha256: baseSave.sha256, request_id: ed.requestId || null };
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
  console.log('EDIT_OK', editSave.file, editSave.sha256.slice(0, 12), editSave.bytes);
  console.log('TOTAL_MS', Date.now() - t0);
} catch (e) {
  console.error('FAILED', String(e && e.message || e));
  process.exit(1);
}
