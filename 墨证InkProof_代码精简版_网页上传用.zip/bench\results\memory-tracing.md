# CanvasKit 4096²×8 全满内存 tracing 实测（T38）

> 日期：2026-11-06｜作者：demo-builder（T38）｜写入范围：`bench/results/`、`bench/tools/`（未改 `v2/`、`product/`、`spike/` 实现）
> 被测：`canvaskit-wasm@0.42.0`（`spike/canvaskit/vendor/`），通过 **T34 的 `bench/p1p2.html?case=p1-4096`** 场景页复测；原始 trace：`bench/results/traces/p1-4096-memory.trace.json`（21.07MB，114,240 events）；摘要：`bench/results/memory-tracing.json`；复现脚本：`bench/tools/memory-trace.mjs`（零依赖）。

---

## 0. 结论（是否可进入 M4）

**有条件可进入 M4，但不能宣称「内存硬门槛 800MB 已通过」。**

- P1 的 704MB 估算被本次实测**结构性地确认**：图层纹理 **512 MiB** + 主 surface **64 MiB** + WASM 堆 **128 MiB** = **704 MiB**；JS heap 稳定态仅 **3.9 MB**（与 T34 的 4.2MB 一致）。
- 距 800MB 门槛余量 **96 MiB（12%）**；**GPU 驱动/缓存额外开销本次仍未能直接观测**（Chrome 无法读显存；memory-infra 在本次 trace 中无 dump，见 §3 局限）——这 96MB 余量正好可能被驱动/缓存吃掉。
- 建议：**M4 可以启动**（功能/性能已达标），但需把「内存 × 真实 GPU 驱动开销」列为 M4 期间的**持续监控项**（800MB 为硬上限），并预置降内存方案（tile 压缩 / 分辨率或层数上限 / 导出 Worker），在真实桌面 Chrome + 同一台机器上补一次带驱动开销的验收。

---

## 1. 方法与口径

| 项 | 本次做法 | 口径/局限 |
|---|---|---|
| 场景 | `bench/p1p2.html?case=p1-4096`：4096²×8 层**全满**（每层 = 全尺寸 GPU 图像，220 个确定性大圆覆盖整层；预热 120 帧 + 3 次完整合成后测 3 轮） | 与 T34 P1 完全同一页面/同一路径，数据可比 |
| JS heap | `performance.memory.usedJSHeapSize` 稳定态 + CDP `Performance.getMetrics`（`JSHeapUsedSize`） | 只统计 JS 堆；不含 WASM/GPU |
| WASM heap | 页面 `CanvasKit HEAPU8.length`（T34 页面在结果中输出） | CanvasKit 堆固定/增长策略由 wasm 决定 |
| 图层纹理 | `w×h×4×layers` = 4096×4096×4×8 = **512 MiB**（每层 `MakeRenderTarget` 快照为 GPU 纹理） | 字节→MiB 换算；不含 mipmap |
| 主 surface | `w×h×4` = **64 MiB** | — |
| 估算总量 | 图层 + 主 surface + WASM 堆 = **704 MiB**（与 T34 估算一致） | **不含 GPU 驱动/缓存** |
| Chrome tracing | CDP `Tracing.start`（`devtools.timeline,disabled-by-default-memory-infra,v8,blink,cc`，`record-as-much-as-possible`），覆盖页面加载→场景完成→稳定态，结束后保存原始 trace | trace 保存 21.07MB / 114,240 events；本次未解析出 memory-infra dump（见 §3） |
| 环境 | headless=new + `--enable-gpu --use-angle=d3d11`，**NVIDIA RTX 4060 Laptop GPU（D3D11）**，1600×1000，无手绘板/无输入 | 非“真实桌面窗口”环境；需真机复测 |

---

## 2. 实测结果

### 2.1 稳定态内存分项（4096²×8 全满）

| 分项 | 数值 | 来源 | 备注 |
|---|---|---|---|
| 图层 GPU 纹理 | **512 MiB** | 页面估算（每层全尺寸快照） | 8 × 64 MiB |
| 主 surface | **64 MiB** | 页面估算 | 4096²×4B |
| CanvasKit WASM 堆 | **128 MiB** | 页面 `HEAPU8.length` | 固定堆 |
| **估算合计** | **704 MiB** | ①+②+③ | **与 T34/P1 的 704MB 完全一致** |
| JS heap（稳定态） | **3.9 MB**（CDP：3.79MiB；`performance.memory`：3.93MiB） | 实测 | 页面结果 `jsHeapMB=3.9` |
| **门槛** | 800 MiB | 计划 §7 / G3 | — |
| **余量** | **96 MiB（12%）** | 800−704 | **不含 GPU 驱动/缓存** |
| 性能（同场景） | fps P95 **144.93**、延迟 P50/P95 **6.5/6.6ms**、maxFrame 7.1ms、掉帧 0 | 实测 | 与 T34 一致；非 vsync 限制口径 |
| 原始 trace | **21.07 MB / 114,240 events** | `bench/results/traces/p1-4096-memory.trace.json` | 保留可复查 |
| JS heap 峰值（trace 派生） | **不可用**（trace 中未见 `UpdateCounters` 事件） | — | 已用稳定态 + CDP metrics 代替 |

### 2.2 与 P1 估算对比

| 来源 | 4096²×8 总内存 | JS heap | 说明 |
|---|---|---|---|
| T34/P1（`canvaskit-p1p2.json`） | **704MB（估算）** | 4.2MB | 图层纹理+主 surface+WASM 堆；不含驱动/缓存 |
| T38 本次实测 | **704 MiB（结构确认）** | **3.9MB（实测稳定态）** | 各分项一致；trace 保留了时间线证据 |
| 800MB 门槛 | 余量 **96 MiB** | — | 风险点：GPU 驱动/缓存 |

---

## 3. 局限（必须写进选型材料）

1. **显存不可直接观测**：浏览器无可靠 API 读 VRAM；`memory-infra` 设计可提供 GPU/进程内存 dump，但本次 trace 中未出现 `MemoryDump`/`periodic_interval`（memDumpCount=0，categories 可能被 headless 或采样周期限制），因此 **GPU 驱动/缓存开销仍是未知项**。
2. **headless + 硬件 GPU**：GPU 为 RTX 4060（D3D11），但 headless 的合成/纹理管理可能与真实桌面 Chrome 不同；需真机窗口复测。
3. **估算公式不含 mipmap/驱动分配器碎片/合成缓存**：96MB 余量可能被这些吃掉。
4. **无真实手绘板/输入**：本测试是 load+绘制场景，不涉及交互延迟（交互数据见 T30/T34）。
5. 本次 trace 中 JS heap 峰值事件未采集到，峰值只能用 P1 的 3 轮数据与稳定态代表；对「突发峰值」需用 DevTools Memory 面板手动录制一次。

---

## 4. 结论与建议

- **功能/性能层面**：4096²×8 全满 fps P95 144.93、延迟 6.5/6.6ms、0 掉帧 → 与 T34 一致，M4 可启动。
- **内存层面**：704MiB 估算被实测结构确认（JS heap 仅 3.9MB），**距 800MB 余量 96MiB**；若 GPU 驱动/缓存 ≤96MiB 则通过，否则会触碰门槛——**当前无法给出「已通过」的确定性结论**。
- **给 M4 的动作**：
  1. 把「4096²×8 全满内存 ≤800MB（含驱动/缓存）」列为 M4 持续监控指标，在真实桌面 Chrome（非 headless）用 DevTools Memory + `chrome://gpu` 补一次；
  2. 预置降内存预案：图层按需 tile/压缩、分辨率降采样（4096→3072/2048 导出）、层数硬上限、导出走 Worker（T34 已定位 4096² PNG 导出 983ms）；
  3. 若实测 GPU 开销 >96MiB：优先启用 tile 压缩或「可见层全分辨率 + 非可见层降采样」，再评估是否按计划 §7 回退条款处理。

---

## 5. 复现

```powershell
# 项目根目录
node bench/tools/memory-trace.mjs
# 输出：
#   bench/results/traces/p1-4096-memory.trace.json   （原始 trace，可拖入 Chrome DevTools Performance 查看）
#   bench/results/memory-tracing.json                 （测量摘要：分项/门槛/环境/trace 元数据）
# 场景页（T34）：http://127.0.0.1:8096/bench/p1p2.html?case=p1-4096
```

文件清单：`bench/results/memory-tracing.md`（本文件）、`bench/results/memory-tracing.json`、`bench/results/traces/p1-4096-memory.trace.json`、`bench/tools/memory-trace.mjs`。
