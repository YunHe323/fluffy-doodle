#!/usr/bin/env node
// v2/engine/test/present-perf.mjs —— T88 present A/B/C spike（零依赖 CDP）
// 用法：node v2/engine/test/present-perf.mjs <demoUrl> [port] [outJson]
import process from 'node:process';
import { writeFileSync } from 'node:fs';

const pageUrl = process.argv[2] || 'http://127.0.0.1:8899/v2/engine/demo.html';
const port = Number(process.argv[3] || 9333);
const outPath = process.argv[4] || '';
const base = `http://127.0.0.1:${port}`;

async function findPage() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const list = await (await fetch(`${base}/json/list`)).json();
      const page = list.find((t) => t.type === 'page' && t.url.includes('v2/engine/demo.html'));
      if (page) return page;
    } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 500));
  }
  return null;
}
const page = await findPage();
if (!page) { console.error('找不到 demo 页面'); process.exit(2); }
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let seq = 0; const pend = new Map();
ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } };
const send = (method, params) => new Promise((res) => { const id = ++seq; pend.set(id, res); ws.send(JSON.stringify({ id, method, params })); });

const expression = `(async () => {
  const t0 = Date.now();
  while (!window.__V2_READY__) { if (Date.now() - t0 > 20000) throw new Error('ready timeout'); await new Promise((r) => setTimeout(r, 200)); }
  const { Engine } = await import('/v2/engine/src/engine.js');
  const raf = () => new Promise((r) => requestAnimationFrame(r));
  const pct = (arr, p) => { const a = arr.slice().sort((x, y) => x - y); return Math.round(a[Math.min(a.length - 1, Math.floor(a.length * p))] * 100) / 100; };
  const stats = (arr) => ({ p50: pct(arr, 0.5), p95: pct(arr, 0.95), avg: Math.round(arr.reduce((a, b) => a + b, 0) / arr.length * 100) / 100, n: arr.length });
  const results = {};
  const checks = {};
  for (const size of [2048, 4096]) {
    const canvas = document.createElement('canvas'); canvas.width = size; canvas.height = size;
    const eng = new Engine({ canvas, width: size, height: size, layers: 2, presentRetained: true });
    await eng.init(); eng.setBrush({ type: 'soft', sizePx: 48 });
    for (let s = 0; s < 3; s += 1) {
      const y = 100 + s * 140;
      eng.beginStroke({ x: 100, y, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
      for (let i = 1; i < 18; i += 1) eng.appendPoint({ x: 100 + i * 30, y: y + Math.sin(i / 4) * 20, pressure: 0.8, timestamp: performance.now(), pointerType: 'synthetic' });
      eng.endStroke();
    }
    await raf(); await raf();
    const memBase = eng.getStats().memoryEstimateMB;
    const sample = (fn, n, syncSurface) => {
      const times = [];
      const CK = eng.CK;
      const info = { width: 1, height: 1, colorType: CK.ColorType.RGBA_8888, alphaType: CK.AlphaType.Unpremul, colorSpace: CK.ColorSpace.SRGB };
      for (let i = 0; i < n; i += 1) {
        const t = performance.now();
        fn();
        if (syncSurface) {
          // 强制 GPU 完成（否则 headless 只测到命令提交，数字失真）
          try { const im = syncSurface.makeImageSnapshot(); im.readPixels(0, 0, info); im.delete(); } catch (e) { /* ignore */ }
        }
        times.push(performance.now() - t);
      }
      return times;
    };
    // A 基线：全量重绘 + 整帧 blit
    eng.setPresentStrategy('full');
    sample(() => eng.presentFull(), 3);
    const a = sample(() => eng.presentFull(), size === 4096 ? 12 : 20, eng.presentSurface);
    // B 脏区：只重绘 1 tile 区域 + 整帧 blit
    eng.setPresentStrategy('dirty');
    sample(() => eng.presentDirty(['0,0']), 3);
    const b = sample(() => eng.presentDirty(['0,0']), size === 4096 ? 12 : 20, eng.presentSurface);
    const redrawPct = eng.getPresentStats().lastRedrawPct;
    // C 双缓冲：额外 RenderTarget 全量重绘 + blit（模拟 ping-pong 的至少双倍保留帧内存）
    const CK = eng.CK;
    const surf2 = CK.MakeRenderTarget(eng.gr, size, size);
    const cTimes = sample(() => {
      const c = surf2.getCanvas();
      eng._drawComposite(c, false);
      surf2.flush();
      const img = surf2.makeImageSnapshot();
      eng.compositor.canvas.drawImage(img, 0, 0);
      eng.compositor.surface.flush();
      img.delete();
    }, size === 4096 ? 8 : 12, surf2);
    try { surf2.delete(); } catch (e) { /* ignore */ }
    const memC = Math.round((memBase + size * size * 4 / 1048576) * 10) / 10;
    results[size] = {
      retained: !!eng.presentSurface,
      memoryMB: { A: memBase, B: memBase, C: memC, CExtra: Math.round(size * size * 4 / 1048576 * 10) / 10 },
      A: { ...stats(a), redrawPct: 1, lastMode: 'full' },
      B: { ...stats(b), redrawPct, lastMode: eng.getPresentStats().lastMode },
      C: { ...stats(cTimes), redrawPct: 1, memory: memC },
    };
    checks['retained' + size] = !!eng.presentSurface;
    checks['dirtyMode' + size] = eng.getPresentStats().lastMode === 'dirty' && redrawPct < 0.5;
    eng.dispose();
  }
  checks.ok = Object.entries(checks).every(([k, v]) => typeof v !== 'boolean' || v);
  return { ok: checks.ok, checks, results, environment: { headless: /HeadlessChrome/.test(navigator.userAgent) } };
})()`;

const r = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, timeout: 300000 });
const value = r.result && r.result.result && r.result.result.value;
if (!value || !value.results) { console.error('无返回/异常', JSON.stringify(r).slice(0, 3000)); process.exit(3); }
console.log(JSON.stringify(value, null, 2));
if (outPath) { try { writeFileSync(outPath, JSON.stringify(value, null, 2), 'utf8'); } catch (e) { console.error('写结果失败', e && e.message); } }
ws.close();
process.exit(value.ok ? 0 : 1);
