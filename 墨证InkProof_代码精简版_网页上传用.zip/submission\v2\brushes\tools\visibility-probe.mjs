/**
 * v2/brushes/tools/visibility-probe.mjs
 * 定位「数据已画出但屏幕上看不见」：真实浏览器（Edge 非 headless）+ CDP。
 *
 * 分别测量四种口径：
 *   dataInk    —— engine.getCompositeDataUrl() 轮询合成结果（tile 数据是否正确）
 *   backbuffer —— WebGL readPixels（当前帧 backbuffer 是否画上）
 *   shotInk    —— Page.captureScreenshot 截图中画布区域的实际像素（浏览器呈现）
 *   afterRaf   —— 强制 rAF + 再次截图（判断是否「呈现时机」问题）
 * 用法：node v2/brushes/tools/visibility-probe.mjs [url] [cdpPort]
 */
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(fileURLToPath(new URL('../../..', import.meta.url)));
/** 本地服务端口：优先 INKPROOF_BASE，其次 v2/.runtime-port，最后 4200 */
function resolveBase() {
  if (process.env.INKPROOF_BASE) return process.env.INKPROOF_BASE;
  try {
    const port = fs.readFileSync(path.join(ROOT, 'v2', '.runtime-port'), 'utf8').trim();
    if (/^\d+$/.test(port)) return 'http://127.0.0.1:' + port;
  } catch (e) { /* ignore */ }
  return 'http://127.0.0.1:4200';
}
const URL_ARG = process.argv[2] || `${resolveBase()}/v2/brushes/demo.html`;
const CDP_PORT = Number(process.argv[3] || 9510);
/** 团队规范：自动化一律 headless（本工具默认 headless=new + 真实 GPU，不弹窗） */
const HEADLESS = true;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const OUT = path.join(ROOT, 'v2', 'brushes', 'samples');
fs.mkdirSync(OUT, { recursive: true });

function findBrowser() {
  return [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  ].find((p) => fs.existsSync(p));
}
const EXE = findBrowser();
const profile = path.join(os.tmpdir(), 'visprobe-' + Date.now());
const browser = spawn(EXE, [
  '--remote-debugging-port=' + CDP_PORT, '--user-data-dir=' + profile,
  '--no-first-run', '--no-default-browser-check', '--headless=new', '--enable-gpu', '--use-angle=d3d11',
  '--ignore-gpu-blocklist', '--window-size=1680,1050',
  URL_ARG,
], { stdio: 'ignore' });

let ws = null; let msgId = 0; const pending = new Map();
const send = (method, params = {}) => new Promise((resolve, reject) => { const id = ++msgId; pending.set(id, { resolve, reject }); ws.send(JSON.stringify({ id, method, params })); });
async function ev(expression, timeoutMs = 60000) {
  const r = await Promise.race([
    send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true }),
    sleep(timeoutMs).then(() => ({ __timeout: true })),
  ]);
  if (r.__timeout) throw new Error('evaluate timeout: ' + expression.slice(0, 100));
  if (r.result?.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 1200));
  return r.result?.result?.value;
}
async function waitFor(expr, timeoutMs = 90000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) { if (await ev(expr).catch(() => false)) return true; await sleep(200); }
  return false;
}

const report = { schema: 'inkproof.visibility-probe.v1', url: URL_ARG, headless: HEADLESS, steps: {} };

/** 页面内截图分析工具：返回整页截图 → 渲染到 2D canvas → 裁画布区域统计像素 */
const SHOT_ANALYZER = `
window.__visAnalyzeShot__ = async (b64) => {
  const img = new Image(); img.src = 'data:image/png;base64,' + b64; await img.decode();
  const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
  const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
  const stage = document.getElementById('stage') || document.querySelector('canvas');
  const r = stage.getBoundingClientRect();
  const s = img.width / window.innerWidth;
  const x = Math.max(0, Math.round(r.x * s)), y = Math.max(0, Math.round(r.y * s));
  const w = Math.max(1, Math.min(img.width - x, Math.round(r.width * s)));
  const h = Math.max(1, Math.min(img.height - y, Math.round(r.height * s)));
  const d = ctx.getImageData(x, y, w, h).data;
  let dark = 0, nonWhite = 0;
  for (let i = 0; i < d.length; i += 4) {
    const R = d[i], G = d[i + 1], B = d[i + 2];
    if (R < 235 || G < 235 || B < 235) dark += 1;
    if (R < 250 || G < 250 || B < 250) nonWhite += 1;
  }
  return { dark, nonWhite, box: { x, y, w, h }, scale: s, img: [img.width, img.height] };
}; 'ok'`;

async function screenshotAnalysis(label) {
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  const b64 = shot.result?.data || '';
  const analysis = await ev(`window.__visAnalyzeShot__(${JSON.stringify(b64)})`);
  const out = path.join(OUT, `vis-${label}.png`);
  try { fs.writeFileSync(out, Buffer.from(b64, 'base64')); } catch (e) { /* ignore */ }
  return { ...analysis, screenshot: path.relative(ROOT, out).replace(/\\/g, '/') };
}

async function dataInk() {
  return ev(`(async () => {
    const e = window.__V2__; e.compositor.compositeAll(e.store);
    const url = await e.getCompositeDataUrl();
    const img = new Image(); img.src = url; await img.decode();
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    let dark = 0;
    for (let i = 0; i < d.length; i += 4) if (d[i] < 235 || d[i + 1] < 235 || d[i + 2] < 235) dark += 1;
    return { dark, w: c.width, h: c.height };
  })()`);
}

/** WebGL backbuffer 读像素（同帧内 flush 后读，preserveDrawingBuffer=false 时唯一可靠口径） */
async function backbufferInk() {
  return ev(`(() => {
    const e = window.__V2__; const c = document.getElementById('stage');
    const gl = c.getContext('webgl2');
    if (!gl) return { error: 'no webgl2 context' };
    e.compositor.compositeAll(e.store);
    e.compositor.surface.flush();
    const w = c.width, h = c.height;
    const px = new Uint8Array(w * h * 4);
    gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, px);
    let dark = 0;
    for (let i = 0; i < px.length; i += 4) if (px[i] < 235 || px[i + 1] < 235 || px[i + 2] < 235) dark += 1;
    return { dark, glError: gl.getError(), lost: gl.isContextLost(), w, h };
  })()`);
}

async function drawStroke(opts = {}) {
  const rect = await ev(`(() => { const r = document.getElementById('stage').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
  const y = rect.y + rect.h * (opts.yRatio || 0.4);
  const x0 = rect.x + rect.w * 0.15, x1 = rect.x + rect.w * 0.85;
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: x0, y, button: 'left', buttons: 1, clickCount: 1 });
  for (let i = 1; i <= 24; i += 1) {
    await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: x0 + (x1 - x0) * i / 24, y: y + Math.sin(i / 4) * 20, button: 'left', buttons: 1 });
    await sleep(12);
  }
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: x1, y, button: 'left', buttons: 0, clickCount: 1 });
}

try {
  let target = null;
  for (let i = 0; i < 400 && !target; i += 1) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`)).json();
      target = list.find((t) => t.type === 'page' && /^https?:/.test(t.url));
    } catch (e) { /* wait */ }
    if (!target) await sleep(150);
  }
  if (!target) throw new Error('CDP target not found');
  ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (m.id && pending.has(m.id)) { pending.get(m.id).resolve(m); pending.delete(m.id); }
  };
  await send('Runtime.enable');
  await send('Page.enable');
  report.ready = await waitFor('!!window.__BRUSH_READY__ || !!window.__V2_APP_READY__');
  if (!report.ready) throw new Error('page not ready');
  await ev(SHOT_ANALYZER);
  report.context = await ev(`(() => ({
    url: location.href, protocol: location.protocol, dpr: devicePixelRatio,
    canvas: (() => { const c = document.getElementById('stage'); const r = c.getBoundingClientRect();
      return { w: c.width, h: c.height, css: [c.style.width, c.style.height], rect: [r.x, r.y, r.width, r.height],
        contextType: (() => { try { const gl = c.getContext('webgl2'); return gl ? 'webgl2' : 'other'; } catch (e) { return 'err'; } })() }; })()
  }))()`);

  // 清空基线
  await ev(`(async () => { const e = window.__V2__; let g = 0; while (e.canUndo() && g < 300) { e.undo(); g += 1; } e.compositor.compositeAll(e.store); return g; })()`);
  await sleep(500);
  report.steps.baseline = {
    data: await dataInk(),
    backbuffer: await backbufferInk(),
    shot: await screenshotAnalysis('0-baseline'),
  };

  // 画一笔（真实 CDP 输入）
  await drawStroke({ yRatio: 0.4 });
  await sleep(900);
  report.steps.afterStroke = {
    data: await dataInk(),
    backbuffer: await backbufferInk(),
    shot: await screenshotAnalysis('1-after-stroke'),
  };

  // 强制 rAF + 再截图（排除「呈现时机」问题）
  await ev(`new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve(true))))`);
  await sleep(600);
  report.steps.afterRaf = {
    data: await dataInk(),
    backbuffer: await backbufferInk(),
    shot: await screenshotAnalysis('2-after-raf'),
  };

  // ---- 复现冒烟测试序列：切换 10 笔刷各画一笔，观察是否变空白 ----
  const rect = await ev(`(() => { const r = document.getElementById('stage').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
  for (let i = 0; i < 10; i += 1) {
    const exists = await ev(`!!document.querySelectorAll('.brushBtn')[${i}]`);
    if (!exists) break;
    await ev(`document.querySelectorAll('.brushBtn')[${i}].click()`);
    await sleep(120);
    const y = rect.y + rect.h * (0.16 + 0.075 * i);
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: rect.x + rect.w * 0.12, y, button: 'left', buttons: 1, clickCount: 1 });
    for (let k = 1; k <= 14; k += 1) {
      await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: rect.x + rect.w * (0.12 + 0.38 * k / 14), y: y + rect.h * 0.012 * k / 14, button: 'left', buttons: 1 });
      await sleep(4);
    }
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: rect.x + rect.w * 0.5, y, button: 'left', buttons: 0, clickCount: 1 });
    await sleep(120);
  }
  report.steps.afterBrushLoop = {
    data: await dataInk(),
    backbuffer: await backbufferInk(),
    shot: await screenshotAnalysis('3-after-brush-loop'),
  };

  // 立刻截图（页面无新帧，模拟冒烟测试 200ms 后截图）
  await sleep(200);
  report.steps.afterBrushLoopImmediate = {
    shot: await screenshotAnalysis('4-after-brush-loop-immediate'),
  };

  // 显式再显影：rAF 内 re-composite + flush，然后截图
  await ev(`new Promise((resolve) => requestAnimationFrame(() => { const e = window.__V2__; e.compositor.compositeAll(e.store); e.compositor.surface.flush(); requestAnimationFrame(() => resolve(true)); }))`);
  await sleep(500);
  report.steps.afterExplicitPresent = {
    backbuffer: await backbufferInk(),
    shot: await screenshotAnalysis('5-after-explicit-present'),
  };

  // 显式 flush + present 尝试：在 rAF 内 composite + flush
  await ev(`new Promise((resolve) => requestAnimationFrame(() => { const e = window.__V2__; e.compositor.compositeAll(e.store); e.compositor.surface.flush(); requestAnimationFrame(() => resolve(true)); }))`);
  await sleep(600);
  report.steps.afterRafComposite = {
    data: await dataInk(),
    backbuffer: await backbufferInk(),
    shot: await screenshotAnalysis('3-after-raf-composite'),
  };

  // 对比：canvas CSS 尺寸设为 1:1（排除缩放假说）
  await ev(`(() => { const c = document.getElementById('stage'); c.style.width = c.width + 'px'; c.style.height = c.height + 'px'; return true; })()`);
  await sleep(400);
  await ev(`new Promise((resolve) => requestAnimationFrame(() => { const e = window.__V2__; e.compositor.compositeAll(e.store); e.compositor.surface.flush(); resolve(true); }))`);
  await sleep(600);
  report.steps.afterCss1to1 = {
    backbuffer: await backbufferInk(),
    shot: await screenshotAnalysis('4-after-css-1to1'),
  };

  report.verdict = (() => {
    const a = report.steps.afterStroke;
    const b = report.steps.afterBrushLoop;
    const c = report.steps.afterExplicitPresent;
    return {
      dataDrawn: a.data.dark > 1000,
      backbufferDrawn: a.backbuffer.dark > 1000,
      presentedInScreenshot: a.shot.dark > 1000,
      dataVsPresentedMismatch: a.data.dark > 1000 && a.shot.dark < 1000,
      afterBrushLoop: { dataLight: b.data.dark, backbuffer: b.backbuffer.dark, presented: b.shot.dark },
      afterExplicitPresent: { backbuffer: c.backbuffer.dark, presented: c.shot.dark },
      captureTimingIssue: b.data.dark > 1000 && b.shot.dark < 1000 && c.shot.dark > 1000,
      css1to1Presented: report.steps.afterCss1to1.shot.dark > 1000,
    };
  })();
  console.log(JSON.stringify(report, null, 2));
} catch (e) {
  report.fatal = String(e && e.stack || e);
  console.log(JSON.stringify(report, null, 2));
} finally {
  try { ws && ws.close(); } catch (e) { /* ignore */ }
  try { spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { stdio: 'ignore' }); } catch (e) { /* ignore */ }
  try { browser.kill(); } catch (e) { /* ignore */ }
  await sleep(400);
  try { fs.rmSync(profile, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  try { fs.writeFileSync(path.join(OUT, 'visibility-probe.json'), JSON.stringify(report, null, 2)); } catch (e) { /* ignore */ }
  process.exit(0);
}
