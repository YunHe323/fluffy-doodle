// product/app/js/example.js
// 示例作品：由 canvas 代码绘制（自制素材，无外部图片；项目自有，MIT）。
import { DOC_W, DOC_H } from './state.js';

export function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* 底图：夜空 + 星 + 月 */
export function paintNightSky(ctx) {
  const rnd = mulberry32(20261106);
  const bg = ctx.createLinearGradient(0, 0, 0, DOC_H);
  bg.addColorStop(0, '#07111d');
  bg.addColorStop(0.34, '#0e2438');
  bg.addColorStop(0.58, '#1b3b52');
  bg.addColorStop(0.78, '#2b4f60');
  bg.addColorStop(1, '#122433');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, DOC_W, DOC_H);

  // 银河薄雾
  const neb = ctx.createRadialGradient(720, 210, 30, 720, 210, 560);
  neb.addColorStop(0, 'rgba(150,190,255,.10)');
  neb.addColorStop(0.5, 'rgba(130,170,235,.05)');
  neb.addColorStop(1, 'rgba(130,170,235,0)');
  ctx.fillStyle = neb;
  ctx.fillRect(0, 0, DOC_W, DOC_H);

  // 星星
  for (let i = 0; i < 240; i++) {
    const x = rnd() * DOC_W;
    const y = rnd() * DOC_H * 0.62;
    const r = 0.5 + rnd() * 1.5;
    const a = 0.15 + rnd() * 0.75;
    ctx.fillStyle = rnd() > 0.82 ? `rgba(255,244,214,${a})` : `rgba(206,228,255,${a})`;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // 月晕
  const moonX = 905, moonY = 168;
  const halo = ctx.createRadialGradient(moonX, moonY, 24, moonX, moonY, 250);
  halo.addColorStop(0, 'rgba(255,246,214,.32)');
  halo.addColorStop(0.22, 'rgba(255,246,214,.12)');
  halo.addColorStop(1, 'rgba(255,246,214,0)');
  ctx.fillStyle = halo;
  ctx.fillRect(0, 0, DOC_W, DOC_H);

  // 月盘
  const moon = ctx.createRadialGradient(moonX - 20, moonY - 22, 4, moonX, moonY, 68);
  moon.addColorStop(0, '#fffdf4');
  moon.addColorStop(0.72, '#f4ecd6');
  moon.addColorStop(1, '#d8cdab');
  ctx.fillStyle = moon;
  ctx.beginPath();
  ctx.arc(moonX, moonY, 66, 0, Math.PI * 2);
  ctx.fill();
  // 月面纹理
  ctx.save();
  ctx.beginPath(); ctx.arc(moonX, moonY, 66, 0, Math.PI * 2); ctx.clip();
  for (let i = 0; i < 9; i++) {
    ctx.fillStyle = `rgba(190,178,148,${0.05 + rnd() * 0.08})`;
    ctx.beginPath();
    ctx.arc(moonX - 40 + rnd() * 80, moonY - 40 + rnd() * 80, 3 + rnd() * 13, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // 近地平线的暖灰雾光
  const hz = ctx.createLinearGradient(0, 380, 0, 700);
  hz.addColorStop(0, 'rgba(140,185,200,0)');
  hz.addColorStop(0.5, 'rgba(140,185,200,.14)');
  hz.addColorStop(1, 'rgba(140,185,200,0)');
  ctx.fillStyle = hz;
  ctx.fillRect(0, 380, DOC_W, 320);

  // 暗角
  const vig = ctx.createRadialGradient(DOC_W / 2, DOC_H * 0.44, 240, DOC_W / 2, DOC_H * 0.44, 820);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, 'rgba(0,0,0,.45)');
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, DOC_W, DOC_H);
}

/* 图层：远山 / 近山剪影 + 山脊微光 */
export function paintMountains(ctx) {
  const rnd = mulberry32(88117);

  // 远山
  const far = [[-60, 540], [90, 452], [230, 500], [400, 436], [545, 482], [700, 428], [840, 470], [985, 424], [1130, 478], [1260, 446]];
  ctx.beginPath();
  ctx.moveTo(-60, DOC_H);
  for (const [x, y] of far) ctx.lineTo(x, y);
  ctx.lineTo(1260, DOC_H);
  ctx.closePath();
  const fg = ctx.createLinearGradient(0, 420, 0, 760);
  fg.addColorStop(0, '#2c5a74');
  fg.addColorStop(0.55, '#1c3c50');
  fg.addColorStop(1, '#122c3b');
  ctx.fillStyle = fg;
  ctx.fill();
  // 山脊微光（月光从右上打来）
  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  ctx.strokeStyle = 'rgba(190,225,245,.20)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  far.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
  ctx.stroke();
  ctx.restore();

  // 中景山
  const mid = [[-60, 650], [110, 560], [250, 616], [400, 542], [545, 606], [690, 556], [830, 620], [975, 566], [1120, 628], [1260, 580]];
  ctx.beginPath();
  ctx.moveTo(-60, DOC_H);
  for (const [x, y] of mid) ctx.lineTo(x, y);
  ctx.lineTo(1260, DOC_H);
  ctx.closePath();
  const mg = ctx.createLinearGradient(0, 540, 0, 800);
  mg.addColorStop(0, '#1a3a4c');
  mg.addColorStop(1, '#0c2230');
  ctx.fillStyle = mg;
  ctx.fill();
  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  ctx.strokeStyle = 'rgba(150,200,225,.12)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  mid.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
  ctx.stroke();
  ctx.restore();

  // 近景山脊（压住画面下缘）
  const near = [[-60, 790], [150, 700], [330, 776], [520, 724], [700, 796], [900, 736], [1080, 800], [1260, 754]];
  ctx.beginPath();
  ctx.moveTo(-60, DOC_H);
  ctx.lineTo(-60, 790);
  for (const [x, y] of near) ctx.lineTo(x, y);
  ctx.lineTo(1260, DOC_H);
  ctx.closePath();
  ctx.fillStyle = '#081722';
  ctx.fill();

  // 山体轻微笔触（让画面不像纯矢量）
  for (let i = 0; i < 140; i++) {
    const x = rnd() * DOC_W;
    const y = 470 + rnd() * 250;
    ctx.strokeStyle = `rgba(${120 + rnd() * 60},${160 + rnd() * 50},${180 + rnd() * 40},${0.02 + rnd() * 0.04})`;
    ctx.lineWidth = 1 + rnd() * 2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + 20 + rnd() * 60, y - 4 - rnd() * 14);
    ctx.stroke();
  }
}

/* 细节层：雾带 / 湖面 / 月影 / 小船与灯 / 松树 / 飞鸟 */
export function paintMistAndDetails(ctx) {
  const rnd = mulberry32(51508);

  // 雾带（横向辉光椭圆）
  function mist(cx, cy, rx, ry, alpha) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(1, ry / rx);
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, rx);
    g.addColorStop(0, `rgba(198,224,235,${alpha})`);
    g.addColorStop(0.55, `rgba(198,224,235,${alpha * 0.45})`);
    g.addColorStop(1, 'rgba(198,224,235,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, rx, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  mist(640, 512, 540, 84, 0.20);
  mist(300, 590, 460, 70, 0.13);
  mist(920, 556, 400, 62, 0.11);
  mist(600, 648, 620, 54, 0.10);

  // 月光柱
  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  const shaft = ctx.createLinearGradient(900, 180, 560, 700);
  shaft.addColorStop(0, 'rgba(220,240,255,.16)');
  shaft.addColorStop(1, 'rgba(220,240,255,0)');
  ctx.fillStyle = shaft;
  ctx.beginPath();
  ctx.moveTo(830, 170);
  ctx.lineTo(990, 190);
  ctx.lineTo(800, 690);
  ctx.lineTo(560, 690);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // 湖面
  const lake = ctx.createLinearGradient(0, 632, 0, DOC_H);
  lake.addColorStop(0, 'rgba(16,40,52,.38)');
  lake.addColorStop(0.22, 'rgba(9,27,38,.92)');
  lake.addColorStop(1, '#04131d');
  ctx.fillStyle = lake;
  ctx.fillRect(0, 632, DOC_W, DOC_H - 632);

  // 水面波纹
  for (let i = 0; i < 70; i++) {
    const y = 642 + rnd() * 152;
    const x = rnd() * DOC_W;
    const w = 20 + rnd() * 130;
    ctx.strokeStyle = `rgba(150,196,214,${0.02 + rnd() * 0.06})`;
    ctx.lineWidth = 1 + rnd() * 1.4;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(x + w / 2, y - 1.5, x + w, y);
    ctx.stroke();
  }

  // 月影（倒影）
  for (let i = 0; i < 30; i++) {
    const y = 646 + i * 5.2;
    const w = 92 - i * 2.1 + rnd() * 26;
    const a = 0.20 * (1 - i / 34);
    ctx.fillStyle = `rgba(238,240,214,${Math.max(0, a)})`;
    ctx.beginPath();
    ctx.ellipse(905 + Math.sin(i * 0.7) * 5, y, Math.max(4, w / 2), 1.6, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // 松树剪影
  function pine(x, baseY, h, w, color) {
    ctx.fillStyle = color;
    for (let i = 0; i < 3; i++) {
      const top = baseY - h * (1 - i * 0.26);
      const half = w * (0.36 + i * 0.30);
      ctx.beginPath();
      ctx.moveTo(x, top - h * 0.12);
      ctx.lineTo(x - half, baseY - (h * 0.12) * (2 - i));
      ctx.lineTo(x + half, baseY - (h * 0.12) * (2 - i));
      ctx.closePath();
      ctx.fill();
    }
    ctx.fillRect(x - 3, baseY - 22, 6, 24);
  }
  pine(96, 800, 250, 52, '#040d14');
  pine(176, 800, 190, 40, '#061019');
  pine(246, 800, 140, 30, '#030b11');
  pine(1108, 800, 170, 38, '#040d14');
  pine(1170, 800, 120, 28, '#02090e');

  // 小船 + 灯
  const bx = 420, by = 652;
  // 灯光辉光
  const glow = ctx.createRadialGradient(bx + 4, by - 20, 1, bx + 4, by - 20, 58);
  glow.addColorStop(0, 'rgba(255,196,120,.85)');
  glow.addColorStop(0.25, 'rgba(255,170,80,.28)');
  glow.addColorStop(1, 'rgba(255,160,60,0)');
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(bx + 4, by - 20, 58, 0, Math.PI * 2);
  ctx.fill();
  // 船体
  ctx.fillStyle = '#04101a';
  ctx.beginPath();
  ctx.moveTo(bx - 30, by - 4);
  ctx.quadraticCurveTo(bx, by + 14, bx + 30, by - 4);
  ctx.quadraticCurveTo(bx, by + 4, bx - 30, by - 4);
  ctx.closePath();
  ctx.fill();
  // 人
  ctx.strokeStyle = '#06131d';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(bx + 12, by - 8);
  ctx.lineTo(bx + 13, by - 34);
  ctx.moveTo(bx + 13, by - 34);
  ctx.lineTo(bx + 19, by - 42);
  ctx.stroke();
  // 灯
  ctx.fillStyle = '#ffd08a';
  ctx.beginPath();
  ctx.arc(bx + 4, by - 20, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,180,90,.9)';
  ctx.fillRect(bx + 2, by - 16, 4, 18);
  // 灯的倒影
  for (let i = 0; i < 8; i++) {
    ctx.fillStyle = `rgba(255,190,110,${0.2 - i * 0.022})`;
    ctx.beginPath();
    ctx.ellipse(bx + 4, by + 8 + i * 6, 6 + i * 1.4, 1.4, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // 飞鸟
  ctx.strokeStyle = 'rgba(10,20,28,.75)';
  ctx.lineWidth = 2;
  for (const [x, y, s] of [[330, 236, 9], [366, 218, 7], [398, 246, 8], [452, 226, 6]]) {
    ctx.beginPath();
    ctx.moveTo(x - s, y);
    ctx.quadraticCurveTo(x - s / 2, y - s * 0.7, x, y);
    ctx.quadraticCurveTo(x + s / 2, y - s * 0.7, x + s, y);
    ctx.stroke();
  }

  // 星点高光（画面细碎颗粒，避免死板）
  for (let i = 0; i < 320; i++) {
    ctx.fillStyle = `rgba(200,225,240,${0.015 + rnd() * 0.03})`;
    ctx.fillRect(rnd() * DOC_W, rnd() * DOC_H, 1, 1);
  }
}
