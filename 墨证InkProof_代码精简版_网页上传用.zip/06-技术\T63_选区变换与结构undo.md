# T63 选区 / 变换 / 图层结构 undo（app T64 接口）

> 项目一 · v2 画布｜作者：tech-architect｜版本 v1.0｜日期 2026-11-06
> 范围：`v2/selection/`、`v2/engine/`、`v2/layers/`；供 **T64（app 顶栏选区/变换、图层结构操作）** 接入。
> 测试：`v2/selection/test/selection.mjs`、`v2/engine/test/selection-transform.mjs`、`v2/layers/test/structural-undo.mjs`；结果在各自 `results/`。

---

## 1. 能力

### 选区（SelectionManager）

- 形状：**矩形 / 椭圆 / 自由套索（多边形）/ 魔棒**（flood fill，512 降采样）。
- 布尔：`mode = 'add' | 'subtract' | 'intersect' | 'replace'`；羽化 0–50（`setFeather`）。
- 蚂蚁线：独立 overlay canvas，rect/ellipse/lasso 虚线动画（wand 由掩码边缘近似）。
- 选区掩码：`getMaskImage()`（CanvasKit Image，alpha）；`hasSelection`；`clear()`；`selectAll()`。
- 约束：传给 engine/LayerSystem 后，笔触提交按掩码 DstIn 裁剪（engine 会同时裁切实际 tile + undo patch）。

```js
const sm = new SelectionManager({ width, height, overlayCanvas, layerSystem });
sm.rect(100, 100, 400, 400, 'replace');
sm.ellipse(600, 100, 900, 400, 'add');
sm.lasso([{x:50,y:50},{x:400,y:80},{x:350,y:450},{x:80,y:400}], 'subtract');
await sm.wandAt(x, y, 'add', 32);
sm.setFeather(12);
engine.setSelectionImage(sm.getMaskImage());   // engine 侧约束
sm.clear(); engine.clearSelection();
```

### 变换（engine / SelectionManager 双端）

- 预览：`beginTransform(layerId)` → `updateTransform({x,y,scaleX,scaleY,rotate,flipH,flipV})`，不改像素。
- 手柄：`getTransformHandles()` 返回 8 缩放手柄 + rotate（世界坐标）；`hitTestHandle(x,y)`；`dragHandle(id,x,y,{snap:true})`（旋转 Shift 15° 吸附）。
- 提交：`commitTransform()` → 写入 tile + **1 步 undo**（engine: `kind:'image'` 整层前后 image；LayerSystem: `kind:'image'`）；`cancelTransform()` 放弃。
- 选区存在时：只变换选区内像素（选区外保留原像素）。

```js
engine.setSelectionImage(sm.getMaskImage());
engine.beginTransform(layerId);
engine.updateTransform({ x: 40, y: -20, scaleX: 1.1, rotate: 30 });
engine.dragTransformHandle('rotate', px, py, { snap: true });
engine.commitTransform();       // 1 步 undo
// 或 sm.beginTransform / sm.commitTransform（LayerSystem 路径）
```

### 图层结构 undo（同一 Undo 栈）

- engine：`addGroup / addLayer / deleteLayer / duplicateLayer / moveLayer / moveToGroup / mergeDown / flattenAll` 均带结构 undo；笔触、变换（image）、结构（structure）共用 `UndoManager`。
- LayerSystem：同名方法 + `undo()/redo()`（结构快照含 `V2Doc` + tile image 引用）。
- 结构快照与 T60 `serializeDoc()` 兼容（doc 结构正确）；undo 后 `getDoc()` 即当前结构。
- 限制：结构快照以 image 引用保存（`_detach` 不立即 delete，M4.5 做引用计数释放）；`duplicateLayer` 复制完整层图像；结构操作频率低但大文档内存需关注。

---

## 2. app T64 接入要点

1. **工具状态**：矩形/椭圆/套索/魔棒 + 布尔下拉 + 羽化滑杆；拖拽生成选区 → `SelectionManager` 对应方法；`engine.setSelectionImage`。
2. **蚂蚁线**：把 `overlayCanvas` 叠在画布上（同尺寸 CSS），SelectionManager 自动动画。
3. **变换 UI**：选择图层 → `engine.beginTransform(layerId)`（或 `sm.beginTransform`）→ 画 9 个手柄（`getTransformHandles()`）→ pointerdown `hitTestHandle`/`dragTransformHandle`（Shift 传 `snap:true`）→ 回车/按钮 `commitTransform()`，ESC `cancelTransform()`。
4. **结构操作**：图层面板按钮调用 engine/LayerSystem 同名方法（自动入栈）；顶栏 undo/redo 调 `engine.undo()/redo()`；结构 undo 与笔触同一栈，无需分开按钮。
5. **保存/加载**：沿用 T60 `serializeDoc/deserializeDoc`；变换/结构提交后 doc 状态即最新，可直接保存。
6. **涂抹（T62）**：使用 `engine.snapshotRegion(layerId,bbox)` 取区域图，避免每笔整画布快照。

---

## 3. 测试与结果

| 测试 | 覆盖 | 结果 |
|---|---|---|
| `v2/selection/test/selection.mjs` | rect/ellipse/lasso/wand、布尔、羽化、9 手柄、命中、15° 吸附、变换提交+undo | 全过 |
| `v2/engine/test/selection-transform.mjs` | 选区约束笔触、变换 commit/undo/redo、结构 undo（增/删/复制/排序/合并/拼合）、T60 序列化、同栈 | 全过 |
| `v2/layers/test/structural-undo.mjs` | LayerSystem 结构操作 undo/redo、doc 兼容、与笔触同栈 | 全过 |
| `v2/engine/test/doc.mjs`、`smoke`、`present-stability` | 回归 | 全过（不回退） |

---

## 4. 已知限制

- 组仅 1 级（T60 范围）；结构快照 image 引用内存（M4.5）；选区仅约束**图层笔触**（蒙版笔触暂不约束）；自由套索为多边形（无曲线拟合）；魔棒降采样近似边缘；变换后选区不自动跟随（app 可清选区）。
- `rotate` 使用 CanvasKit `rotate(degrees, cx, cy)`（三参）；其他 CanvasKit 版本注意签名。
