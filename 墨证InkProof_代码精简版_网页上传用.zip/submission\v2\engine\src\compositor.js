/**
 * v2 engine · 图层合成器（CanvasKit）
 * - 主 surface：MakeOnScreenGLSurface（WebGL2 GPU）
 * - 图层 blend：normal/multiply/screen/overlay/soft-light（saveLayer 图层隔离）
 * - 脏区合成：只重绘受影响 tile（clipRect + 全部图层重放该 tile）
 */
const BLEND = {
  normal: 'SrcOver', dissolve: 'SrcOver',
  darken: 'Darken', multiply: 'Multiply', 'color-burn': 'ColorBurn',
  lighten: 'Lighten', screen: 'Screen', 'color-dodge': 'ColorDodge',
  overlay: 'Overlay', 'soft-light': 'SoftLight', 'hard-light': 'HardLight',
  difference: 'Difference', exclusion: 'Exclusion',
  hue: 'Hue', saturation: 'Saturation', color: 'Color', luminosity: 'Luminosity',
};

export class Compositor {
  constructor(CK, gr, canvas, width, height) {
    this.CK = CK;
    this.gr = gr;
    this.width = width;
    this.height = height;
    this.surface = CK.MakeOnScreenGLSurface(gr, width, height, CK.ColorSpace.SRGB, 0, 0);
    if (!this.surface) throw new Error('MakeOnScreenGLSurface 失败');
    this.canvas = this.surface.getCanvas();
    /** @type {any[]} 图层元数据（顺序即合成顺序） */
    this.layers = [];
    this._layerPaint = new CK.Paint();
    this._layerPaint.setAntiAlias(false);
    this.lastCompositeMs = 0;
    this.TILE = 256;
  }

  setLayers(layers) {
    this.layers = layers;
  }

  blendOf(name) {
    return this.CK.BlendMode[BLEND[name] || 'SrcOver'];
  }

  /** 全量合成（白底 + 全部图层/全部 tile） */
  composite() {
    const t0 = performance.now();
    const CK = this.CK, c = this.canvas;
    c.clear(CK.WHITE);
    for (const layer of this.layers) {
      if (!layer.visible) continue;
      this._drawLayer(c, layer, null);
    }
    this.surface.flush();
    this.lastCompositeMs = Math.round((performance.now() - t0) * 100) / 100;
  }

  /** 脏区合成：dirtyKeys 为 tile key 列表；空=全量 */
  compositeDirty(store, dirtyKeys) {
    if (!dirtyKeys || dirtyKeys.length === 0) return this.composite();
    const t0 = performance.now();
    const CK = this.CK, c = this.canvas;
    for (const key of dirtyKeys) {
      const [tx, ty] = key.split(',').map(Number);
      c.save();
      c.clipRect([tx * this.TILE, ty * this.TILE, this.TILE, this.TILE], CK.ClipOp.Intersect, false);
      c.clear(CK.WHITE);
      for (const layer of this.layers) {
        if (!layer.visible) continue;
        this._drawLayerTile(c, store, layer, key);
      }
      c.restore();
    }
    this.surface.flush();
    this.lastCompositeMs = Math.round((performance.now() - t0) * 100) / 100;
  }

  // ---------- T60：V2Doc 渲染（组/蒙版/剪贴/16 混合/live） ----------
  /** 把 V2Doc 全量合成到给定 canvas（主 surface / 保留帧 / 离屏快照共用）
   * opts.live: { layerId, mode:'paint'|'erase'|'mask-union', image }（当前实时预览）
   */
  drawDocument(c, doc, store, maskStore, opts = {}) {
    const CK = this.CK;
    c.clear(CK.WHITE);
    const layers = (doc && doc.layers) || [];
    const groups = (doc && doc.groups) || [];
    const live = opts.live || null;
    let i = 0;
    while (i < layers.length) {
      const layer = layers[i];
      if (layer.group) {
        const groupStart = i;
        const group = groups.find((g) => g.id === layer.group);
        const members = [];
        while (i < layers.length && layers[i].group === layer.group) { members.push(layers[i]); i += 1; }
        if (group && group.visible === false) continue;
        if (group) {
          const gp = this._layerPaint;
          gp.setBlendMode(CK.BlendMode.SrcOver);
          gp.setAlphaf(group.opacity == null ? 1 : group.opacity);
          c.saveLayer(gp);
        } else {
          c.save();
        }
        for (const m of members) this.drawLayerFull(c, m, layers, store, maskStore, live);
        // T67：组蒙版（整组 × mask）
        if (group && group.mask && group.mask.enabled && group.mask.exists && maskStore) {
          const mp = this._layerPaint;
          mp.setBlendMode(CK.BlendMode.DstIn);
          mp.setAlphaf(1);
          this._drawTiles(c, maskStore, group.id, mp);
        }
        // T67：组剪贴（组整体被其下方图层 alpha 裁切；最小语义）
        if (group && group.clip) {
          const base = groupStart > 0 ? layers[groupStart - 1] : null;
          if (base && !base.group) {
            const cp = this._layerPaint;
            cp.setBlendMode(CK.BlendMode.DstIn);
            cp.setAlphaf(1);
            this._drawTiles(c, store, base.id, cp);
          }
        }
        // T67：组蒙版实时预览（live：本组内容 × live mask DstIn 再补一遍）
        if (group && live && live.groupId === group.id && live.image) {
          const lp = this._livePaint || (this._livePaint = new CK.Paint());
          lp.setAntiAlias(false);
          lp.setAlphaf(1);
          if (live.mode === 'group-mask-erase') {
            // T84：黑蒙版实时橡皮（隐藏组内容）
            lp.setBlendMode(CK.BlendMode.DstOut);
            c.drawImage(live.image, 0, 0, lp);
          } else {
            c.save();
            for (const m of members) this.drawLayerFull(c, m, layers, store, maskStore, null);
            lp.setBlendMode(CK.BlendMode.DstIn);
            c.drawImage(live.image, 0, 0, lp);
            c.restore();
          }
        }
        c.restore();
      } else {
        this.drawLayerFull(c, layer, layers, store, maskStore, live);
        i += 1;
      }
    }
  }

  /** 单个图层的完整绘制（内容 + 蒙版 + 剪贴 + 实时预览） */
  drawLayerFull(c, layer, allLayers, store, maskStore, live) {
    if (!layer.visible || (layer.opacity != null && layer.opacity <= 0)) return;
    const CK = this.CK;
    const blend = this.blendOf(layer.blend);
    const opacity = layer.opacity == null ? 1 : layer.opacity;
    const hasMask = !!(layer.mask && layer.mask.enabled && layer.mask.exists && maskStore);
    const liveHere = !!(live && live.layerId === layer.id && live.image);
    const needsIsolation = blend !== CK.BlendMode.SrcOver || opacity < 1 || hasMask || layer.clip || (liveHere && (live.mode === 'erase' || live.mode === 'mask-erase'));
    if (needsIsolation) {
      this._layerPaintFor(layer);
      c.saveLayer(this._layerPaint);
    } else {
      c.save();
    }
    this._drawTiles(c, store, layer.id);
    if (hasMask) {
      const p = this._layerPaint;
      p.setBlendMode(CK.BlendMode.DstIn);
      p.setAlphaf(1);
      this._drawTiles(c, maskStore, layer.id, p);
    }
    if (layer.clip) {
      const idx = allLayers.indexOf(layer);
      const base = idx > 0 ? allLayers[idx - 1] : null;
      if (base) {
        const p = this._layerPaint;
        p.setBlendMode(CK.BlendMode.DstIn);
        p.setAlphaf(1);
        this._drawTiles(c, store, base.id, p);
      }
    }
    if (liveHere) {
      const lp = this._livePaint || (this._livePaint = new CK.Paint());
      lp.setAntiAlias(false);
      if (live.mode === 'erase') {
        lp.setBlendMode(CK.BlendMode.DstOut);
        lp.setAlphaf(1);
        c.drawImage(live.image, 0, 0, lp);
      } else if (live.mode === 'mask-union') {
        // 现有蒙版已 DstIn（可见区域被裁掉）；再补一遍「本层内容 × live mask DstIn」→ 实时露出新覆盖区
        c.save();
        this._drawTiles(c, store, layer.id);
        const mp = this._layerPaint;
        mp.setBlendMode(CK.BlendMode.DstIn);
        mp.setAlphaf(1);
        c.drawImage(live.image, 0, 0, mp);
        c.restore();
      } else if (live.mode === 'mask-erase') {
        // T84：黑蒙版实时橡皮（隐藏本层内容）
        lp.setBlendMode(CK.BlendMode.DstOut);
        lp.setAlphaf(1);
        c.drawImage(live.image, 0, 0, lp);
      } else {
        lp.setBlendMode(CK.BlendMode.SrcOver);
        lp.setAlphaf(1);
        c.drawImage(live.image, 0, 0, lp);
      }
    }
    c.restore();
  }

  _drawTiles(c, store, layerId, paint) {
    if (!store || !layerId) return;
    for (const key of store.listTiles(layerId)) {
      const t = store.get(layerId, key);
      if (!t) continue;
      const [tx, ty] = key.split(',').map(Number);
      if (paint) c.drawImage(t.image, tx * this.TILE, ty * this.TILE, paint);
      else c.drawImage(t.image, tx * this.TILE, ty * this.TILE);
    }
  }

  _layerPaintFor(layer) {
    const p = this._layerPaint;
    p.setBlendMode(this.blendOf(layer.blend));
    p.setAlphaf(layer.opacity == null ? 1 : layer.opacity);
    return p;
  }

  _drawLayer(c, layer, store) {
    const blend = this.blendOf(layer.blend);
    const opacity = layer.opacity == null ? 1 : layer.opacity;
    if (blend !== this.CK.BlendMode.SrcOver || opacity < 1) {
      this._layerPaintFor(layer);
      c.saveLayer(this._layerPaint);
    } else {
      c.save();
    }
    this.drawLayerContent(c, layer, store);
    c.restore();
  }

  /** 只画图层内容（不处理 blend/opacity 的 saveLayer；调用方负责包围） */
  drawLayerContent(c, layer, store) {
    if (!store) return;
    for (const key of store.listTiles(layer.id)) {
      const t = store.get(layer.id, key);
      if (!t) continue;
      const [tx, ty] = key.split(',').map(Number);
      c.drawImage(t.image, tx * this.TILE, ty * this.TILE);
    }
  }

  /** 画图层内容 + 实时预览内容（T44：live surface 的图像）
   *  mode='erase' 时用 DstOut 擦除图层内容（擦除笔刷实时预览正确显示下层）
   */
  drawLayerWithLive(c, layer, store, liveImage, opts = {}) {
    const blend = this.blendOf(layer.blend);
    const opacity = layer.opacity == null ? 1 : layer.opacity;
    // erase 模式必须做图层隔离（saveLayer）：DstOut 只擦本层内容，
    // 不能把下层/白底一起擦成透明（否则实时预览/截图会变透明而非“露出下层”）
    const needsIsolation = blend !== this.CK.BlendMode.SrcOver || opacity < 1 || opts.mode === 'erase';
    if (needsIsolation) {
      this._layerPaintFor(layer);
      c.saveLayer(this._layerPaint);
    } else {
      c.save();
    }
    this.drawLayerContent(c, layer, store);
    if (liveImage) {
      if (!this._livePaint) {
        this._livePaint = new this.CK.Paint();
        this._livePaint.setAntiAlias(false);
      }
      const lp = this._livePaint;
      lp.setBlendMode(opts.mode === 'erase' ? this.CK.BlendMode.DstOut : this.CK.BlendMode.SrcOver);
      lp.setAlphaf(1);
      c.drawImage(liveImage, 0, 0, lp);
    }
    c.restore();
  }

  _drawLayerTile(c, store, layer, key) {
    const t = store.get(layer.id, key);
    if (!t) return;
    const blend = this.blendOf(layer.blend);
    const opacity = layer.opacity == null ? 1 : layer.opacity;
    if (blend !== this.CK.BlendMode.SrcOver || opacity < 1) {
      this._layerPaintFor(layer);
      c.saveLayer(this._layerPaint);
    } else {
      c.save();
    }
    const [tx, ty] = key.split(',').map(Number);
    c.drawImage(t.image, tx * this.TILE, ty * this.TILE);
    c.restore();
  }

  /** 全量合成变体：从 store 取所有图层 tile */
  compositeAll(store) {
    const t0 = performance.now();
    const CK = this.CK, c = this.canvas;
    c.clear(CK.WHITE);
    for (const layer of this.layers) {
      if (!layer.visible) continue;
      this._drawLayer(c, layer, store);
    }
    this.surface.flush();
    this.lastCompositeMs = Math.round((performance.now() - t0) * 100) / 100;
  }

  dispose() {
    try { this._livePaint && this._livePaint.delete(); } catch (e) { /* ignore */ }
    try { this._layerPaint.delete(); } catch (e) { /* ignore */ }
    try { this.surface.delete(); } catch (e) { /* ignore */ }
    this.surface = null;
  }
}
