# 最终回归执行清单（待 T67/T68/T69 落地后执行）

> 状态：**待命**（Lead 指示：等 T67 组蒙版/组剪贴、T68 app UI、T69 涂抹 snapshotRegion + 压感默认 A/B 完成后执行）。
> 执行人：qa-engineer｜前置：不启动浏览器、不弹窗；全程 headless + 独立端口。

## 0. 执行前

| 步骤 | 命令 / 动作 | 产物 |
|---|---|---|
| 0.1 记录改动 | `Get-Item v2/engine/src/engine.js, v2/app/js/app.js, v2/brushes/src/brush-controller.js, v2/brushes/presets/defaults.json \| Select LastWriteTime`（确认 T67/68/69 已落） | 时间戳记录 |
| 0.2 备份当前基线 | 复制 `tools/{GATE-pw.md,results.json,legacy-vs-pw.md,round-*.json,functional-regression.json,functional-regression-report.md}` → `tools/archive/baseline-before-final/` | 归档目录 |
| 0.3 清理残留 | `Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" \| ?{$_.CommandLine -match 'v2-qa-profile\|playwright'} \| measure` 应为 0 | — |

## 1. 三页冒烟 + 4 目标×3 轮 GATE

```powershell
cd v2/qa
node tools/harness.mjs
```

通过标准：
- 冒烟 `ours-app/ours-brushes/ours-engine` 3/3 PASS；
- GATE 结论「全部闸门通过」；逐项：帧稳定（0/16/50/200ms）、undo 帧完整、S1/S2 断点、3 轮结构稳定（断点 ±1 + 帧稳定）；
- 记录与 Klecks 对比变化（尤其 S1/S2 粗细 CV 是否因 T69 压感默认 A/B 改善 → 回填 T59 复测）；
- 若出现 ❌：按 owner 归属（帧/undo→tech；连续性/粗细→brush；UI 相关→demo）登记，不掩盖。

## 2. 功能回归（含 T67/T68/T69 扩展）

```powershell
node tools/functional-regression.mjs
```

现有 9 项（F1–F9）必须继续全绿：图层组/蒙版/剪贴/16 混合、`.mozheng` 保存→刷新→打开（结构+像素双对比）、自动保存恢复、PSD 导出→导入、涂抹、选区约束、变换 1 步 undo、结构 undo/redo、Alpha Lock。

**本轮新增（待 T67/T68/T69 API 落地后补入脚本）**：
- **F10 组蒙版**：建组 → 组蒙版添加/启用停用/应用 → 断言：组内图层像素被组蒙版裁剪（组外区域 0 变化）、doc 结构含 group.mask；
- **F11 组剪贴**：组剪贴（clipping mask）生效/关闭 → 断言：被剪贴组内容只在基底层 alpha 内可见；
- **F12 涂抹 snapshotRegion（T69）**：涂抹前后像素变化 + 区域外不变；连续涂抹 2 次仍正常（无 snapshot 泄漏/花屏）；
- **F13 压感默认 A/B（T69）**：同一速度 S1 线，模拟压感开/关两组的线宽 CV 有显著差异且默认值符合 T69 约定（记录数值，供 T59 对照）。

## 3. 保存 / PSD 往返（强制）

- `.mozheng`：保存 → 刷新 → 打开 → **结构归一化 JSON 相等 + 像素 diff=0**（像素 diff 用合成图逐像素比较，阈值 ≤1%）；
- PSD：导出 → 导入 → **像素 diff ≤5%** + 图层/组数一致 + fidelity 摘要记录；
- 两项均写入 `functional-regression.json` 与报告。

## 4. 汇总与交付

| 产物 | 内容 |
|---|---|
| `tools/GATE-pw.md` | 新最终基线：冒烟 + GATE + 功能回归段（含 F10–F13） |
| `tools/functional-regression-report.md` | 功能回归逐项结果、失败 owner |
| `tools/archive/baseline-final/` | 最终基线归档（GATE+results+rounds+功能报告） |
| 汇报 | ≤300 字：冒烟、GATE 结论、功能回归通过率、遗留差距（T59 CV 等）与 owner |

**「目标可验收」判定**：冒烟 3/3 + GATE 全绿 + 功能回归全绿（F1–F13）+ 保存/PSD 往返达标 + 0 残留进程 = 可验收；任一 ❌ 需列 owner 与复测计划，不得以「已知问题」代替。
