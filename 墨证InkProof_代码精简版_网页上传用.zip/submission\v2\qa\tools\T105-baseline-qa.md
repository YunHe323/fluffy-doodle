# T105 基线 QA：当前功能 / Skill / 素材 AI / 编辑器 验收清单

> 执行：qa-engineer（独立 QA｜T105-D）｜日期：2026-11-07 16:4x｜只写 `v2/qa/tools/`；**未改 app/engine/CSS/HTML**
> 环境：headless Edge（channel:msedge、GPU/ANGLE-D3D11）、独立端口、单浏览器串行；**小批次执行**（每批 1–3 个测试，完整输出落盘 `archive/baseline-t105/logs/`，终端只打摘要）；执行期间系统可用内存仅 **~2GB**，已严格避免并发浏览器。

## 结论（供合并前 baseline）

**当前基线可交付（P0/P1 = 0），但需注意 1 项 P2 回归与 2 项流程问题：**
- 关键测试 9/9 有效通过（test-library 首跑因低内存超时一次，单跑重试通过；但 `pass.scrim=false` 为真实 P2 回归）
- Skill Runtime 单测 1/1 全过；asset-real-read 证据复核通过（**未新增任何真实调用**）
- 密钥无泄漏（DOM/localStorage/sessionStorage/已加载 JS）、0 残留 Edge/端口

## 1. 小批次复跑结果

| 批次 | 测试 | 结果 | 关键证据 |
|---|---|---|---|
| A | `skill-runtime-test.mjs`（node-only） | **PASS** | 3 skills；asset.decompose/canvas.observe/image.edit 全 ok；未知 skill 抛错；logs=3；0 error |
| A | `asset-real-read-results.json`（仅核对，不重跑） | **PASS** | source=real、model=qwen3.8-max、latency=26348ms、skill=asset.decompose、L2=5/L4=4、1 条 critique 记录；errors=[] |
| B | `test-app.mjs` | **PASS**（exit 0，errors 0） | 截图产出，无 pass 字段（owner 脚本） |
| B | `test-ui.mjs` | **PASS**（exit 0，errors 0） | p1Checks/interactions 全 true（见 result JSON） |
| C | `test-library.mjs` | ⚠️ **P2**（详见 §4） | 首跑 fatal：reload `waitForFunction` 45s 超时（低内存）；单跑重试 19 项 detail 全过，但 `pass.scrim=false` |
| C | `test-image-workshop.mjs` | **PASS** | 2 候选/2 卡片；预览 alpha=1001；落层 2→3+transformActive；编辑 task=edit |
| D | `test-chat.mjs` | **PASS** | 表单→发送→assistant 回复；行数/元数据齐全 |
| D | `test-multimodal.mjs` | **PASS** | 标注 annotatedCrop=true；对齐 alignOk=true；AI 标注层 alpha=5001；定位/语音 ok |
| E | `test-text.mjs` | **PASS** | 图层「文字 · 雾中山谷」；**textRecord=1 已纳入 pass 断言** |
| E | `test-canvas-size.mjs` | **PASS** | `?new=1&w=1600&h=1000` → 1600×1000、draw undo=1、弹窗/预设全过 |
| E | `test-library-ai.mjs`（附加） | **PASS** | refs/gen/save 全 true，0 error |

> 说明：T104 两个 P2 已关闭 —— ①`v2/app/qwen-image-edit-real.meta.json` 已说明该 PNG 为“代理直连验证输出、与 app 候选非同字节”，格式/尺寸/sha256 均已登记；②`test-text.mjs` 已把 `textRecord>=1` 纳入 pass。

## 2. 证据与静态核对

| 项 | 结果 |
|---|---|
| Skill Runtime 模块 | `v2/app/core/skills/runtime.mjs` + `builtin.mjs` 存在；单测覆盖 run/list/日志/未知 skill |
| asset-real-read 截图 | `v2/app/ui-asset-real-read-1920.png` 有效 PNG（303,789 B） |
| 真实调用 | **本次未新增任何真实调用**（仅核对已有 JSON/截图） |
| 密钥 | ✅ 无 DOM/localStorage/sessionStorage/已加载 JS/静态源码泄漏；config GET 仅 `hasKey/keyLast4`；T99 token 注入正常 |
| 残留 | ✅ Edge=0、测试端口=0（每批后清理；低内存期间曾出现一次测试自身 45s reload 超时，已单跑复核） |

## 3. P0 / P1 / P2 清单

| 级别 | # | 问题 | owner | 说明/建议 |
|---|---|---|---|---|
| **P0** | — | 无 | — | 无阻塞 |
| **P1** | — | 无 | — | 无阻塞 |
| P2 | 1 | **素材库遮罩 scrim 回归**：`ui-polish.css:189` 覆盖 paper 主题 → 实际 `rgba(35,27,18,.46)` + `blur(7px) saturate(1.02)`；`test-library` 断言要求 alpha 0.55–0.75 + `blur(2px)` → `pass.scrim=false` | **demo-builder** | 若新视觉是刻意调整：请 Lead 确认后同步更新断言与设计系统；否则恢复 `.62/blur(2px)`。当前不影响功能，但不满足既有视觉契约 |
| P2 | 2 | `test-library.mjs` **恒以 exit 0 结束**（`finish(0)`，即使 `pass.scrim=false`）→ CI/批量脚本无法捕获失败 | **demo-builder/lead** | 改为 `finish(pass ? 0 : 1)`，并在结果 JSON 落 `pass` 对象（当前 pass 仅打印在 stdout） |
| P2 | 3 | `test-library` 首跑在低内存（~1.7GB free）下 reload 45s 超时；单跑重试通过 | qa/demo | 低内存是环境问题；建议 CI 前置检查 free≥3GB，或把 reload 超时提到 60s（owner 酌情） |

## 4. Skill / 素材 AI / 编辑器合并后应新增的断言

### 4.1 接口级（Skill Runtime）

1. **注册表**：`rt.list()` 恰含 `asset.decompose`、`canvas.observe`、`image.edit`（新增 skill 必须显式登记版本）；`register` 重复 id 抛错/覆盖策略明确。
2. **运行契约**：`rt.run(id, input, {provider})` 返回 `{ok, result, skill:{id,version}, meta, log}`；未知 id 抛错；`logs.length` 随调用线性增长且内存有界。
3. **输入透传**：`width/height/image/selection/userIntent/mode` 必须原样到 provider（防止合并后丢字段）；图片仅传裁剪/压缩后的 dataURL。
4. **输出归一化**：各 skill 输出结构固定（decompose → L1/L2/L4；observe → observations；edit → candidates[{imageDataUrl,sha256}]）；缺字段/类型错必须报可读错误。
5. **错误映射**：provider 401/429/timeout/网络错 → `{code,retryable,billed:false}`；UI 显示中文提示；不得写假记录/假候选。
6. **并发/顺序**：两个 run 顺序执行无共享可变状态；同一 provider 调用不得并行（image 队列并发 1）。
7. **L6 契约**：成功记录必须含 `model{provider,model,modelVersion}`、`params.skill{id,version}`、`params.task`、`usage`、`latency_ms`、`ai_role`（generation=tool / critique=assistant；text/paste/asset 类=null）；`validateArchiveRecord` 必须通过。

### 4.2 接口级（素材 AI）

8. **分析来源状态机**：asset.analysisSource：`mock → real`（重读）可持久化；刷新后仍为 real；失败回退 mock 且保留旧分析（不丢）。
9. **L1/L2/L4 一致性**：真实重读后 L1.summary 非空、L2≥3、L4≥2，且 tags/summary 同步；`critique` L6 记录 `params.task='asset_decompose'`、含 skill/obs 数。
10. **证据一致**：导出证据包时 `manifest.ai.real_calls` == L6 AI 事件数；`verify-evidence.mjs` 全绿；asset 引用（refs）出现在 evidence.refs。
11. **成本/隐私**：无 key/privacy 模式不得发起真实请求；真实调用必须 `x-ai-confirm`；响应/证据不出现上游 URL 与 key。

### 4.3 UI 级（编辑器 / 工作台 / 多模态）

12. **图像工作台**：生成 2 候选/2 卡片；点预览后 `candidatePreviewCanvas` alpha>100；落层后自动进入 transform（9 手柄、transformActive、undo=1）；编辑模式按钮存在且发起 `task=edit`。
13. **文字工具**：点击画布出现 composer（文本框/字号/确认）；提交后图层名以「文字 ·」开头、图层+1、undo≥1、**L6 `text_inserted`≥1**（已纳入断言）。
14. **画布标注**：标注模式 pointer 命中标注层；`annotationInk=true`、`annotatedCrop=true`；完成后 ink 保留、bar 收起；清空 ink=false；**三层 rect 对齐（alignOk）**。
15. **AI 标注层**：按钮可切换；橙色框 `alpha>500`；退出后隐藏；与标注层/选区层 z-index 不互相吞事件。
16. **多模态发送**：确认弹窗文案包含「含你手绘的红圈/箭头标注」；取消不发请求/不写记录；确认后 AI 请求携带 annotated 图。
17. **画布尺寸**：`?new=1&w/h` 生效（engine/docSize/canvas 属性一致）；弹窗/预设值正确；新画布可绘制且 undo=1。
18. **素材库**：插入 source=original-bitmap、L5 确认/否决、导入去重、刷新持久化、引用 chip 省略号/aria；**遮罩视觉契约（scrim alpha/blur）**。

## 5. 建议的验收门槛（合并后 Gate）

| 级别 | 门槛 | 动作 |
|---|---|---|
| **P0（阻塞）** | app 启动/READY、画布绘制与 undo、保存→刷新→打开 像素 diff=0、AI 代理安全基线（token/confirm/Origin/尺寸/密钥不泄漏）任一失败 | 禁止合并/交付 |
| **P1（阻塞合并）** | Skill Runtime 单测失败；图像工作台候选<2 或落层无 transform；文字 L6 text_inserted<1 或 schema 拒收；多模态标注 annotated=false / alignOk=false / AI 标注层 alpha≤500；素材插入 source≠original-bitmap；test-library 19 项任一 false | 修复后重跑 |
| **P2（跟踪，不阻塞）** | 视觉 scrim/backdrop 偏差、测试恒 exit 0、低内存 flaky、证据文件包装不一致 | 记录 owner + 计划 |
| 稳定性 | 关键测试小批次连跑 2 次一致（本基线 test-image-workshop 已 ×2）；0 console error；0 残留 Edge/端口 | 每轮执行 |
| 资源 | 执行前 free≥3GB、单浏览器串行；单批 ≤3 测试 | 防 OOM/flake |

## 6. 证据与归档

- 报告：`v2/qa/tools/T105-baseline-qa.md`（本文件）
- 归档：`v2/qa/tools/archive/baseline-t105/`（logs/ 全部原始输出、各 result JSON、keycheck-results.json、asset-real-read-results.json、README）
- 关键数据：skill-runtime pass=true；asset-real-read pass=true（real/qwen3.8-max/26348ms/L2=5/L4=4）；test-library pass.scrim=false（P2-1）；测试批次全部 0 console error（除 test-library 自身低内存超时一次）。
