#!/usr/bin/env node
/**
 * v2/qa/tools/app-dirty-default-check.mjs — T90 验证：app 默认 present 策略（≤2048² 用 dirty、>2048² 回 full）
 *
 * 覆盖：默认策略断言 / present 正确性（dirty present 帧 vs 合成图 diff=0）/ 绘制与 undo 像素 / 导出像素 diff=0 / 长任务
 * 运行：node v2/qa/tools/app-dirty-default-check.mjs [--port 4262]
 */
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const QA = path.resolve(__dirname, '..');
const REPO = path.resolve(QA, '..', '..');
const require = createRequire(import.meta.url);
const argv = process.argv.slice(2);
const argOf = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? argv[i + 1] : d; };
const PORT = Number(argOf('--port', 4262));
const OUT = path.join(__dirname, 'app-dirty-default.json');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function startServer() {
  const portFile = path.join(REPO, 'v2', '.runtime-port');
  await fsp.rm(portFile, { force: true }).catch(() => {});
  const proc = spawn(process.execPath, [path.join(REPO, 'v2', 'serve.mjs')], { cwd: REPO, env: { ...process.env, PORT: String(PORT) }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  for (let i = 0; i < 120; i += 1) { await sleep(150); try { const p = Number(String(await fsp.readFile(portFile, 'utf8')).trim()); const r = await fetch(`http://127.0.0.1:${p}/v2/app/index.html`); if (r.ok) return { origin: `http://127.0.0.1:${p}`, proc }; } catch { /* wait */ } }
  throw new Error('无法启动静态服务');
}

const HELPERS = `
window.__QA__ = window.__QA__ || {};
window.__QA__.raf = () => new Promise((r) => requestAnimationFrame(r));
window.__QA__.grab = async () => { const e = window.__V2_APP__.engine; try { e.compositor.compositeAll(e.store); } catch (err) {} return await e.getCompositeDataUrl(); };
window.__QA__.presentSnapshot = (e) => {
  const CK = e.CK;
  const im = e.presentSurface.makeImageSnapshot();
  const info = { width: e.width, height: e.height, colorType: CK.ColorType.RGBA_8888, alphaType: CK.AlphaType.Unpremul, colorSpace: CK.ColorSpace.SRGB };
  const px = im.readPixels(0, 0, info);
  try { im.delete(); } catch (err) {}
  return { w: e.width, h: e.height, d: px };
};
window.__QA__.decode = async (url) => {
  const img = new Image(); img.src = url; await img.decode();
  const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
  const g = c.getContext('2d'); g.drawImage(img, 0, 0);
  return { w: c.width, h: c.height, d: g.getImageData(0, 0, c.width, c.height).data };
};
window.__QA__.diff = (A, B, stride) => {
  const step = stride || 4; let changed = 0, total = 0, maxD = 0;
  for (let i = 0; i < A.d.length; i += 4 * step) {
    total += 1;
    const d = Math.max(Math.abs(A.d[i] - B.d[i]), Math.abs(A.d[i + 1] - B.d[i + 1]), Math.abs(A.d[i + 2] - B.d[i + 2]));
    if (d > 8) changed += 1;
    if (d > maxD) maxD = d;
  }
  return { changed, total, maxDelta: maxD };
};
try {
  if (!window.__QA_LT__) {
    window.__QA_LT__ = [];
    new PerformanceObserver((l) => { for (const e of l.getEntries()) window.__QA_LT__.push(Math.round(e.duration)); }).observe({ entryTypes: ['longtask'] });
  }
} catch (err) {}
`;

async function main() {
  const { chromium } = require('playwright-core');
  const srv = await startServer();
  const report = { schema: 'mozheng.qa.t90-dirty-default.v1', at: new Date().toISOString(), origin: srv.origin, checks: {}, pass: null };
  const browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-gpu', '--use-angle=d3d11', '--window-size=1600,1000', '--window-position=-3000,-3000'] });
  const ctx = await browser.newContext({ viewport: { width: 1532, height: 791 }, deviceScaleFactor: 1, acceptDownloads: true });
  const page = await ctx.newPage();
  page.setDefaultTimeout(120000);
  report.errors = [];
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|status of 404/i.test(m.text())) report.errors.push(m.text().slice(0, 200)); });
  page.on('pageerror', (e) => report.errors.push(String(e.message || e).slice(0, 200)));
  const ev = (fn, arg) => page.evaluate(fn, arg);
  try {
    await page.goto(`${srv.origin}/v2/app/index.html`, { waitUntil: 'load' });
    await page.waitForFunction('window.__V2_APP_READY__ === true', { timeout: 120000 });
    await page.waitForTimeout(1500);
    await page.evaluate(HELPERS);

    // 1) 默认策略断言（app 画布 1200×800 ≤ 2048² → dirty）
    report.defaults = await ev(() => {
      const app = window.__V2_APP__, e = app.engine;
      return { canvas: [e.width, e.height], strategy: e.getPresentStrategy(), retained: !!e.presentSurface, presentSurfaceMB: e.getStats().presentSurfaceMB };
    });
    // 1b) T90 策略决策函数：≤2048² dirty / >2048² full
    report.policy = await ev(() => {
      const t = window.__V2_APP__.t90;
      if (!t || typeof t.decide !== 'function') return { missing: true };
      const small = t.decide(1200, 800), edge = t.decide(2048, 2048), over = t.decide(2049, 2049), large = t.decide(4096, 4096);
      return { small, edge, over, large };
    }).catch((e) => ({ error: String(e.message || e) }));

    // 2) 绘制（真实指针）+ 帧稳定（pointerup 后 4 帧）+ 长任务
    const box = await ev(() => { const r = document.getElementById('mainCanvas').getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; });
    await ev(() => { window.__V2_APP__.engine.setActiveLayer(window.__V2_APP__.engine.getLayers()[0].id); window.__V2_APP__.setTool('brush'); window.__QA_LT__ = []; });
    await page.waitForTimeout(200);
    const beforeStroke = await ev(() => window.__QA__.grab());
    await page.mouse.move(box.x + box.w * 0.2, box.y + box.h * 0.45);
    await page.mouse.down();
    for (let i = 1; i <= 24; i += 1) { await page.mouse.move(box.x + box.w * (0.2 + 0.55 * i / 24), box.y + box.h * (0.45 + Math.sin(i / 3) * 0.12)); await sleep(12); }
    await page.mouse.up();
    await page.waitForTimeout(120);
    const frames = [];
    for (let i = 0; i < 4; i += 1) { frames.push(await ev(() => window.__QA__.grab())); await page.waitForTimeout(i === 0 ? 0 : 14); }
    // present 输出 vs 合成图（dirty 策略下）
    report.present = await ev(async () => {
      const app = window.__V2_APP__, e = app.engine;
      const present = window.__QA__.presentSnapshot(e);
      const comp = await window.__QA__.decode(await window.__QA__.grab());
      const diff = window.__QA__.diff(present, comp, 3);
      const lt = (window.__QA_LT__ || []).slice();
      return { diff, longTasks: { count: lt.length, over50: lt.filter((d) => d > 50).length, longest: lt.length ? Math.max(...lt) : 0 } };
    });
    report.frameStable = frames.every((u) => u === frames[0]);
    // 3) undo 像素还原
    const undo = await ev(async () => {
      const app = window.__V2_APP__, e = app.engine;
      const beforeUndo = await window.__QA__.grab();
      const ok = e.undo();
      await window.__QA__.raf(); await window.__QA__.raf(); await window.__QA__.raf();
      const afterUndo = await window.__QA__.grab();
      const beforePx = await window.__QA__.decode(beforeUndo);
      const afterPx = await window.__QA__.decode(afterUndo);
      const changed = window.__QA__.diff(beforePx, afterPx, 3);
      return { ok, changed };
    }).catch((e) => ({ error: String(e.message || e) }));
    report.undo = undo;
    // 4) 导出 PNG（dirty 下）与合成图 diff
    report.export = await ev(async () => {
      const app = window.__V2_APP__, e = app.engine;
      const blob = await e.exportPNGAsync({ tileSize: 256 });
      const bmp = await createImageBitmap(blob);
      const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height;
      const g = c.getContext('2d'); g.drawImage(bmp, 0, 0);
      const exported = { w: c.width, h: c.height, d: g.getImageData(0, 0, c.width, c.height).data };
      const comp = await window.__QA__.decode(await window.__QA__.grab());
      return { bytes: blob.size, diff: window.__QA__.diff(exported, comp, 3) };
    }).catch((e) => ({ error: String(e.message || e) }));
    // 5) 策略切换：full 下 present 输出 vs dirty 下 present 输出（像素一致）
    report.strategy = await ev(async () => {
      const app = window.__V2_APP__, e = app.engine;
      e.setPresentStrategy('dirty'); e.presentFull(); await window.__QA__.raf();
      const dirtySnap = window.__QA__.presentSnapshot(e);
      e.setPresentStrategy('full'); e.presentFull(); await window.__QA__.raf();
      const fullSnap = window.__QA__.presentSnapshot(e);
      const diff = window.__QA__.diff(dirtySnap, fullSnap, 3);
      const mode = e.getPresentStats();
      e.setPresentStrategy('dirty');
      return { diff, dirtyMode: mode.lastMode, canvas: [e.width, e.height] };
    }).catch((e) => ({ error: String(e.message || e) }));
    report.checks = {
      defaultDirty: report.defaults.strategy === 'dirty' && report.defaults.retained === true,
      policyThreshold: !!report.policy && !report.policy.missing && !report.policy.error
        && report.policy.small.strategy === 'dirty' && report.policy.edge.strategy === 'dirty'
        && report.policy.over.strategy === 'full' && report.policy.over.retained === false
        && report.policy.large.strategy === 'full' && report.policy.large.retained === false,
      frameStable: report.frameStable === true,
      presentCorrect: report.present && report.present.diff && report.present.diff.changed === 0,
      undoPixel: !!report.undo && report.undo.ok === true && report.undo.changed && report.undo.changed.changed > 0,
      exportPixel: !!report.export && !report.export.error && report.export.diff && report.export.diff.changed === 0,
      strategyParity: !!report.strategy && !report.strategy.error && report.strategy.diff && report.strategy.diff.changed === 0,
      longTaskClean: !!report.present && report.present.longTasks && report.present.longTasks.over50 <= 1,
      noConsoleErrors: report.errors.length === 0,
    };
    report.pass = Object.values(report.checks).every(Boolean);
  } catch (e) {
    report.fatal = String(e.stack || e.message || e);
    report.pass = false;
  } finally {
    await browser.close().catch(() => {});
    try { srv.proc.kill(); } catch { /* ignore */ }
    await fsp.rm(path.join(REPO, 'v2', '.runtime-port'), { force: true }).catch(() => {});
  }
  await fsp.writeFile(OUT, JSON.stringify(report, null, 2), 'utf8');
  console.log('[t90] ' + (report.pass ? 'PASS' : 'FAIL') + ' checks=' + JSON.stringify(report.checks));
  console.log('[t90] defaults=' + JSON.stringify(report.defaults) + ' presentDiff=' + JSON.stringify(report.present && report.present.diff) + ' undoDiff=' + JSON.stringify(report.undo && report.undo.changed) + ' exportBytes=' + (report.export && report.export.bytes));
  process.exit(report.pass ? 0 : 1);
}
main().catch((e) => { console.error('t90 检查失败：', e.stack || e); process.exit(2); });
