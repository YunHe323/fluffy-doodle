#!/usr/bin/env node
/**
 * T117 独立 QA —— 调整层「仅作用到当前选区」蒙版（mask）
 *
 * 只读产品代码，不修改 app.js / engine.js / index.html / css。
 * 覆盖：A mask UI 状态 / B 创建（框外像素严格不变）/ C 更新（mask 跟随选区 + 预填）/
 *      D 取消勾选语义 / E undo·redo（创建、更新、mask 是否随 undo 恢复）/
 *      F 保存·加载 / G 4096×4096 性能 / H 安全性·整洁（console/pageerror/网络/Mock/密钥）/
 *      I 回归由命令行单独执行（见报告）。
 *
 * 运行：node v2/qa/tools/T117-mask-qa.mjs
 * 产物：v2/qa/tools/T117-mask-qa-result.json、v2/qa/tools/shots/t117-*.png
 * 端口：默认 8181（可用 T117_PORT 覆盖）；headless Edge；跑完 close 浏览器 + kill python。
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from '../node_modules/playwright-core/index.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..', '..', '..');
const PORT = Number(process.env.T117_PORT || 8181);
const URL_APP = `http://127.0.0.1:${PORT}/v2/app/index.html`;
const OUT_JSON = path.join(__dirname, 'T117-mask-qa-result.json');
const SHOTS = path.join(__dirname, 'shots');
const VIEWPORT = { width: 1366, height: 768 };
const SEL1 = { x: 320, y: 240, width: 260, height: 200 };
const SEL2 = { x: 700, y: 440, width: 220, height: 180 };

const out = {
  schema: 'mozheng.qa.T117.mask.v1',
  startedAt: new Date().toISOString(),
  env: { node: process.version, platform: process.platform, port: PORT, viewport: VIEWPORT, browser: 'msedge headless (channel:msedge, gpu/angle-d3d11)' },
  cases: {},
  checks: [],
  observations: [],
  consoleErrors: [],
  pageErrors: [],
  network: { external: [], tokenRequests: [] },
  pages: {},
  shots: [],
  errors: [],
  pass: false,
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let py = null;
let browser = null;
let browserClosed = false;

function addCheck(id, title, pass, actual, expected, meta = {}) {
  const rec = { id, title, pass: !!pass, actual, expected, at: new Date().toISOString(), ...meta };
  out.checks.push(rec);
  return rec;
}

function recordError(stage, e) {
  out.errors.push({ stage, error: String((e && e.stack) || e).slice(0, 2000), at: new Date().toISOString() });
}

/* ======================================================================
 * 页面内工具（不动产品文件；只通过 window.__V2_APP__ / DOM 读取）
 * ==================================================================== */
function installPageHelpers() {
  const qa = {
    async load(url) {
      if (!url) return null;
      const img = new Image();
      img.src = url;
      await img.decode();
      const c = document.createElement('canvas');
      c.width = img.naturalWidth || img.width;
      c.height = img.naturalHeight || img.height;
      const g = c.getContext('2d', { willReadFrequently: true });
      g.drawImage(img, 0, 0);
      return { w: c.width, h: c.height, d: g.getImageData(0, 0, c.width, c.height).data };
    },
    async grab() {
      const e = window.__V2_APP__.engine;
      return await e.getCompositeDataUrl();
    },
    /** 直读图层 tile 像素（不套用 mask/混合），用于隔离“像素是否恢复” */
    rawLayerUrl(id) {
      const e = window.__V2_APP__.engine;
      const img = e._renderStoreLayerImage(e.store, id);
      let bytes = null;
      try { bytes = img.encodeToBytes(); } finally { try { img.delete(); } catch (err) { /* ignore */ } }
      let binary = '';
      const chunk = 0x8000;
      for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
      return 'data:image/png;base64,' + btoa(binary);
    },
    /** 两幅整画布合成图逐像素对比；regions 内分别统计，区域外合并统计 */
    async diff(urlA, urlB, regions) {
      const A = await this.load(urlA);
      const B = await this.load(urlB);
      if (!A || !B) return { error: 'decode-failed' };
      if (A.w !== B.w || A.h !== B.h) return { error: `size-mismatch ${A.w}x${A.h} vs ${B.w}x${B.h}` };
      const W = A.w, H = A.h, ad = A.d, bd = B.d;
      const regs = (regions || []).map((r) => ({
        id: r.id || 'r', x: Math.round(r.x), y: Math.round(r.y), width: Math.round(r.width), height: Math.round(r.height),
        strict: 0, visible: 0, maxDelta: 0, pixels: 0,
      }));
      const outside = { strict: 0, visible: 0, maxDelta: 0, pixels: 0 };
      const all = { strict: 0, visible: 0, maxDelta: 0, pixels: W * H };
      for (let y = 0; y < H; y += 1) {
        for (let x = 0; x < W; x += 1) {
          const i = (y * W + x) * 4;
          const d = Math.max(
            Math.abs(ad[i] - bd[i]),
            Math.abs(ad[i + 1] - bd[i + 1]),
            Math.abs(ad[i + 2] - bd[i + 2]),
          );
          if (d > 0) all.strict += 1;
          if (d > 8) all.visible += 1;
          if (d > all.maxDelta) all.maxDelta = d;
          let hit = null;
          for (let k = 0; k < regs.length; k += 1) {
            const r = regs[k];
            if (x >= r.x && x < r.x + r.width && y >= r.y && y < r.y + r.height) { hit = r; break; }
          }
          if (hit) {
            hit.pixels += 1;
            if (d > 0) hit.strict += 1;
            if (d > 8) hit.visible += 1;
            if (d > hit.maxDelta) hit.maxDelta = d;
          } else {
            outside.pixels += 1;
            if (d > 0) outside.strict += 1;
            if (d > 8) outside.visible += 1;
            if (d > outside.maxDelta) outside.maxDelta = d;
          }
        }
      }
      return { size: [W, H], all, outside, regions: regs };
    },
    async sample(url, points) {
      const A = await this.load(url);
      if (!A) return null;
      return (points || []).map((p) => {
        const x = Math.max(0, Math.min(A.w - 1, Math.round(p.x)));
        const y = Math.max(0, Math.min(A.h - 1, Math.round(p.y)));
        const i = (y * A.w + x) * 4;
        return { name: p.name || null, x, y, rgba: [A.d[i], A.d[i + 1], A.d[i + 2], A.d[i + 3]] };
      });
    },
    /** 读取图层蒙版（maskStore）的白色区域 bbox / 透明度统计 */
    maskInfo(id) {
      const e = window.__V2_APP__.engine;
      if (!e || !e.maskStore || !id) return null;
      const store = e.maskStore;
      const keys = store.listTiles(id);
      const T = store.tileSize;
      let minX = Infinity, minY = Infinity, maxX = -1, maxY = -1, white = 0, total = 0, alphaSum = 0;
      for (const key of keys) {
        const tile = store.get(id, key);
        if (!tile) continue;
        const parts = key.split(',');
        const tx = Number(parts[0]), ty = Number(parts[1]);
        let px;
        try { px = e._readTileRGBA(tile); } catch (err) { continue; }
        for (let y = 0; y < T; y += 1) {
          for (let x = 0; x < T; x += 1) {
            const idx = (y * T + x) * 4;
            const a = px[idx + 3];
            total += 1;
            alphaSum += a;
            if (a > 127) {
              white += 1;
              const wx = tx * T + x, wy = ty * T + y;
              if (wx < minX) minX = wx;
              if (wy < minY) minY = wy;
              if (wx > maxX) maxX = wx;
              if (wy > maxY) maxY = wy;
            }
          }
        }
      }
      return {
        tiles: keys.length,
        totalPixels: total,
        whitePixels: white,
        meanAlpha: total ? Math.round(alphaSum / total) : 0,
        bbox: white ? [minX, minY, maxX - minX + 1, maxY - minY + 1] : null,
      };
    },
    state() {
      const a = window.__V2_APP__;
      const e = a.engine;
      const layers = e.getLayers();
      const adj = layers.filter((l) => (l.kind || 'raster') === 'adjust');
      const last = adj.length ? adj[adj.length - 1] : null;
      const cb = document.getElementById('adjMaskSelection');
      const hintEl = document.getElementById('adjMaskHint');
      const applyBtn = document.getElementById('btnAdjustApply');
      const modalEl = document.getElementById('adjustModal');
      const stats = e.getStats ? e.getStats() : null;
      return {
        width: e.width,
        height: e.height,
        layers: layers.length,
        layerBrief: layers.map((l) => ({ id: l.id, name: l.name, kind: l.kind || 'raster', hasMask: !!(l.mask && l.mask.exists) })),
        activeLayerId: e.activeLayerId,
        adjustLayers: adj.map((l) => ({ id: l.id, name: l.name, kind: l.kind, adjust: l.adjust, meta: l.meta, mask: l.mask })),
        adjustId: last ? last.id : null,
        maskExists: !!(last && last.mask && last.mask.exists),
        maskTiles: last ? e.maskStore.listTiles(last.id).length : 0,
        adjustRecords: a.state.records.filter((r) => r.kind === 'adjust_layer').map((r) => ({
          layer: r.layer,
          action: r.params && r.params.action,
          masked: r.params && r.params.masked,
          brightness: r.params && r.params.brightness,
          contrast: r.params && r.params.contrast,
          saturation: r.params && r.params.saturation,
          hue: r.params && r.params.hue,
          nonDestructive: r.params && r.params.non_destructive,
          note: r.note || null,
          valid: !!(a.validateRecord && a.validateRecord(r).ok),
        })),
        undoDepth: stats ? stats.undoDepth : null,
        redoDepth: stats ? stats.redoDepth : null,
        stats: stats ? { layers: stats.layers, masks: stats.masks, tileCount: stats.tileCount, memoryEstimateMB: stats.memoryEstimateMB } : null,
        selection: a.state.selection ? { ...a.state.selection } : null,
        modal: {
          open: !!(modalEl && modalEl.classList.contains('show')),
          checked: cb ? !!cb.checked : null,
          disabled: cb ? !!cb.disabled : null,
          hint: hintEl ? hintEl.textContent : null,
          applyText: applyBtn ? applyBtn.textContent : null,
        },
      };
    },
    sliders() {
      const val = (id) => { const el = document.getElementById(id); return el ? Number(el.value) : null; };
      const cb = document.getElementById('adjMaskSelection');
      const nameEl = document.getElementById('adjustLayerName');
      const modalEl = document.getElementById('adjustModal');
      return {
        brightness: val('adjBrightness'),
        contrast: val('adjContrast'),
        saturation: val('adjSaturation'),
        hue: val('adjHue'),
        checked: cb ? !!cb.checked : null,
        disabled: cb ? !!cb.disabled : null,
        hint: (document.getElementById('adjMaskHint') || {}).textContent || null,
        applyText: (document.getElementById('btnAdjustApply') || {}).textContent || null,
        name: nameEl ? nameEl.textContent : null,
        open: !!(modalEl && modalEl.classList.contains('show')),
      };
    },
  };
  window.__QA__ = qa;
}

/* ======================================================================
 * 浏览器 / 页面管理
 * ==================================================================== */
async function newTrackedPage(tag) {
  const page = await browser.newPage({ viewport: VIEWPORT });
  page.setDefaultTimeout(60000);
  page.setDefaultNavigationTimeout(60000);
  const rec = { tag, consoleErrors: [], consoleWarnings: [], pageErrors: [], requests: [], responses: [], requestFailed: [] };
  out.pages[tag] = rec;
  page.on('console', (m) => {
    const text = String(m.text() || '');
    if (m.type() === 'error') {
      rec.consoleErrors.push(text.slice(0, 800));
      if (!/favicon|401|Unauthorized/i.test(text)) out.consoleErrors.push({ tag, text: text.slice(0, 800) });
    } else if (m.type() === 'warning') {
      rec.consoleWarnings.push(text.slice(0, 400));
    }
  });
  page.on('pageerror', (e) => {
    const msg = String((e && e.message) || e).slice(0, 800);
    rec.pageErrors.push(msg);
    out.pageErrors.push({ tag, message: msg });
  });
  page.on('request', (req) => {
    const url = req.url();
    if (rec.requests.length < 500) rec.requests.push(url);
    const same = url.startsWith(`http://127.0.0.1:${PORT}/`) || url.startsWith('http://localhost:') || url.startsWith('data:') || url.startsWith('blob:');
    if (!same) out.network.external.push({ tag, url });
    if (/\.ai-token|\.ai-config/i.test(url)) out.network.tokenRequests.push({ tag, url });
  });
  page.on('response', (res) => {
    if (res.status() >= 400) rec.responses.push({ url: res.url(), status: res.status() });
  });
  page.on('requestfailed', (req) => {
    rec.requestFailed.push({ url: req.url(), failure: (req.failure() && req.failure().errorText) || null });
  });
  return page;
}

async function gotoReady(page, url, readyTimeout = 60000) {
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: readyTimeout });
  await page.waitForTimeout(1200);
  await page.evaluate(installPageHelpers);
}

const q = {
  state: (page) => page.evaluate(() => window.__QA__.state()),
  grab: (page) => page.evaluate(() => window.__QA__.grab()),
  diff: (page, a, b, regions) => page.evaluate(([a2, b2, regs]) => window.__QA__.diff(a2, b2, regs), [a, b, regions || []]),
  sample: (page, url, points) => page.evaluate(([u, pts]) => window.__QA__.sample(u, pts), [url, points || []]),
  mask: (page, id) => page.evaluate((layerId) => window.__QA__.maskInfo(layerId), id),
  sliders: (page) => page.evaluate(() => window.__QA__.sliders()),
  rawLayerUrl: (page, id) => page.evaluate((layerId) => window.__QA__.rawLayerUrl(layerId), id),
};

const RGB4 = (rgba) => (rgba ? `rgba(${rgba.join(',')})` : 'n/a');

async function shot(page, name) {
  const file = path.join(SHOTS, name);
  try { await page.screenshot({ path: file }); out.shots.push(file); } catch (e) { /* ignore */ }
}

/* ---------- UI 操作 ---------- */
async function setSelection(page, sel) {
  await page.evaluate((s) => {
    const a = window.__V2_APP__;
    a.state.selection = s ? { ...s } : null;
    try { a.drawSelection(); } catch (e) { /* overlay optional */ }
  }, sel);
  await page.waitForTimeout(150);
}

async function drawTestStrokes(page) {
  await page.evaluate(() => {
    const el = document.getElementById('leftSizeRange');
    if (el) { el.value = '52'; el.dispatchEvent(new Event('input', { bubbles: true })); }
  });
  const box = await page.locator('#mainCanvas').boundingBox();
  if (!box) throw new Error('mainCanvas boundingBox 为空');
  const pt = (fx, fy) => ({ x: box.x + box.width * fx, y: box.y + box.height * fy });
  const segments = [
    [0.30, 0.36, 0.45, 0.50],
    [0.31, 0.49, 0.45, 0.37],
    [0.62, 0.61, 0.72, 0.72],
    [0.62, 0.71, 0.72, 0.62],
  ];
  for (const [x0, y0, x1, y1] of segments) {
    const a = pt(x0, y0);
    const b = pt(x1, y1);
    await page.mouse.move(a.x, a.y);
    await page.mouse.down();
    await page.mouse.move(b.x, b.y, { steps: 14 });
    await page.mouse.up();
    await page.waitForTimeout(180);
  }
  await page.waitForTimeout(500);
}

async function openAdjustModal(page) {
  await page.click('#btnMore');
  await page.waitForSelector('#popMore.open', { timeout: 10000 });
  await page.waitForTimeout(120);
  await page.click('#btnAdjustLayer');
  await page.waitForSelector('#adjustModal.show', { timeout: 10000 });
  await page.waitForTimeout(250);
  return q.state(page);
}

async function closeAdjustModal(page) {
  const target = page.locator('#adjustModal [data-close="adjustModal"]').first();
  await target.click();
  await page.waitForFunction(() => !document.querySelector('#adjustModal.show'), null, { timeout: 10000 }).catch(() => {});
  await page.waitForTimeout(120);
}

async function setMaskChecked(page, checked) {
  await page.evaluate((c) => {
    const el = document.getElementById('adjMaskSelection');
    if (el) { el.checked = !!c; el.dispatchEvent(new Event('change', { bubbles: true })); }
  }, checked);
}

async function setSliderValues(page, v) {
  await page.evaluate((vals) => {
    const set = (id, val) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.value = String(val);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    };
    set('adjBrightness', vals.brightness);
    set('adjContrast', vals.contrast);
    set('adjSaturation', vals.saturation);
    set('adjHue', vals.hue);
  }, v);
}

async function clickApplyWait(page, action, timeout = 60000) {
  const before = await page.evaluate((act) => window.__V2_APP__.state.records.filter((r) => r.kind === 'adjust_layer' && (!act || (r.params && r.params.action === act))).length, action);
  const t0 = Date.now();
  await page.click('#btnAdjustApply');
  await page.waitForFunction(({ act, n }) => {
    const rs = window.__V2_APP__.state.records.filter((r) => r.kind === 'adjust_layer' && (!act || (r.params && r.params.action === act)));
    return rs.length > n;
  }, { act: action, n: before }, { timeout });
  await page.waitForFunction(() => !document.querySelector('#adjustModal.show'), null, { timeout: 15000 }).catch(() => {});
  await page.waitForTimeout(400);
  return Date.now() - t0;
}

async function createMaskedAdjust(page, opts = {}) {
  const sel = opts.sel || SEL1;
  const sliders = {
    brightness: opts.brightness == null ? 20 : opts.brightness,
    contrast: opts.contrast == null ? 0 : opts.contrast,
    saturation: opts.saturation == null ? 0 : opts.saturation,
    hue: opts.hue == null ? 0 : opts.hue,
  };
  await setSelection(page, sel);
  const beforeOpen = await q.state(page);
  const info = await openAdjustModal(page);
  await setMaskChecked(page, true);
  await setSliderValues(page, sliders);
  const beforeUrl = await q.grab(page);
  const applyMs = await clickApplyWait(page, 'create', opts.timeout || 60000);
  const created = await q.state(page);
  const afterUrl = await q.grab(page);
  const mask = created.adjustId ? await q.mask(page, created.adjustId) : null;
  return { sel, info, beforeOpen, beforeUrl, afterUrl, applyMs, created, mask };
}

const pickState = (s) => ({
  width: s.width, height: s.height, layers: s.layers, layerBrief: s.layerBrief,
  activeLayerId: s.activeLayerId, adjustId: s.adjustId, maskExists: s.maskExists, maskTiles: s.maskTiles,
  adjustLayers: s.adjustLayers, adjustRecords: s.adjustRecords,
  undoDepth: s.undoDepth, redoDepth: s.redoDepth, stats: s.stats, selection: s.selection, modal: s.modal,
});

/* ======================================================================
 * A/B/C/D/F/H —— 主功能页（1200×800 默认画布）
 * ==================================================================== */
async function runMainPage() {
  const page = await newTrackedPage('main');
  out.cases.main = {};
  try {
    await gotoReady(page, URL_APP);
    await drawTestStrokes(page);
    const srcState = await q.state(page);
    const srcLayerId = srcState.activeLayerId;
    const srcUrl = await q.grab(page);
    const srcLayerUrl = await page.evaluate((id) => window.__V2_APP__.engine.getLayerDataUrl(id), srcLayerId);
    out.cases.main.baseline = { layers: srcState.layers, srcLayerId, srcLayerUrlBytes: String(srcLayerUrl || '').length };
    const points = [
      { name: 'strokeA', x: 430, y: 350 },
      { name: 'strokeB', x: 810, y: 530 },
      { name: 'blankOutside', x: 1000, y: 120 },
    ];
    const srcSamples = await q.sample(page, srcUrl, points);

    /* ---------- A1：无选区打开 modal ---------- */
    await setSelection(page, null);
    let st = await openAdjustModal(page);
    out.cases.A1 = st.modal;
    addCheck('A1', '无选区打开「图像调整」：checkbox disabled、hint=先框选一块区域、默认未勾选',
      st.modal.disabled === true && st.modal.checked === false && /先框选一块区域/.test(String(st.modal.hint || '')),
      st.modal, { disabled: true, checked: false, hint: /先框选一块区域/ }, { level: 'P1' });
    await shot(page, 't117-A1-no-selection.png');
    await closeAdjustModal(page);

    /* ---------- A2：有选区打开 modal ---------- */
    await setSelection(page, SEL1);
    st = await openAdjustModal(page);
    out.cases.A2 = st.modal;
    addCheck('A2', '有选区打开「图像调整」：checkbox enabled、默认未勾选、hint=只影响选框内像素',
      st.modal.disabled === false && st.modal.checked === false && /只影响选框内像素/.test(String(st.modal.hint || '')),
      st.modal, { disabled: false, checked: false, hint: /只影响选框内像素/ }, { level: 'P1' });
    await shot(page, 't117-A2-modal.png');
    await closeAdjustModal(page);

    /* ---------- B：创建（有选区、勾选） ---------- */
    const b = await createMaskedAdjust(page, { sel: SEL1, brightness: 25, contrast: 10, saturation: 8, hue: 5 });
    const srcLayerUrlAfter = await page.evaluate((id) => window.__V2_APP__.engine.getLayerDataUrl(id), srcLayerId);
    const diffCreate = await q.diff(page, b.beforeUrl, b.afterUrl, [
      { id: 'sel1', ...SEL1 }, { id: 'sel2', ...SEL2 },
    ]);
    const afterSamples = await q.sample(page, b.afterUrl, points);
    out.cases.B = {
      create: pickState(b.created), mask: b.mask, applyMs: b.applyMs,
      sourceLayerUnchanged: srcLayerUrl === srcLayerUrlAfter,
      diffCreate, samples: { before: srcSamples, after: afterSamples },
    };
    const createdLayer = b.created.adjustLayers[0] || null;
    const createRecs = b.created.adjustRecords.filter((r) => r.action === 'create');
    const createRec = createRecs[createRecs.length - 1] || null;
    const adj = createdLayer && createdLayer.adjust;
    addCheck('B1', '创建后新增 1 个 kind=adjust 图层（不覆盖源层）',
      b.created.layers === srcState.layers + 1 && b.created.adjustLayers.length === 1 && createdLayer && createdLayer.kind === 'adjust',
      { layersBefore: srcState.layers, layersAfter: b.created.layers, adjustLayers: b.created.adjustLayers.length, kind: createdLayer && createdLayer.kind },
      { layersBefore: srcState.layers, layersAfter: srcState.layers + 1, kind: 'adjust' }, { level: 'P1' });
    addCheck('B2', '调整参数落库正确（brightness=0.25 / contrast=0.10 / saturation=1.08 / hue=5）',
      !!adj && adj.brightness === 0.25 && adj.contrast === 0.10 && adj.saturation === 1.08 && adj.hue === 5,
      adj, { brightness: 0.25, contrast: 0.10, saturation: 1.08, hue: 5 }, { level: 'P1' });
    addCheck('B3', 'mask.exists=true、maskTiles>0、蒙版白色 bbox=当前选区',
      b.created.maskExists === true && b.created.maskTiles > 0 && !!b.mask && b.mask.whitePixels > 0 && JSON.stringify(b.mask.bbox) === JSON.stringify([SEL1.x, SEL1.y, SEL1.width, SEL1.height]),
      { maskExists: b.created.maskExists, maskTiles: b.created.maskTiles, mask: b.mask, expectedBBox: [SEL1.x, SEL1.y, SEL1.width, SEL1.height] },
      { maskExists: true, maskTiles: 20, bbox: [SEL1.x, SEL1.y, SEL1.width, SEL1.height] }, { level: 'P1' });
    addCheck('B4', 'L6 adjust_layer 记录 params.masked=true（create、可校验）',
      !!createRec && createRec.masked === true && createRec.action === 'create' && createRec.valid === true,
      createRec, { action: 'create', masked: true, valid: true }, { level: 'P1' });
    addCheck('B5', '框外像素严格不变（勾选前 vs 创建后，选区外逐像素 diff 全为 0）',
      diffCreate && !diffCreate.error && diffCreate.outside && diffCreate.outside.strict === 0,
      diffCreate && !diffCreate.error ? { outside: diffCreate.outside, all: diffCreate.all } : diffCreate,
      { outsideStrict: 0, outsideMaxDelta: 0 }, { level: 'P1' });
    addCheck('B6', '框内像素确实变化（选区 1 内可见差异像素 > 0）',
      diffCreate && !diffCreate.error && (diffCreate.regions.find((r) => r.id === 'sel1') || {}).visible > 0,
      diffCreate && !diffCreate.error ? diffCreate.regions : diffCreate,
      { sel1Visible: '> 0' }, { level: 'P1' });
    addCheck('B7', '蒙版外区域（选区 2）像素也不变',
      diffCreate && !diffCreate.error && (diffCreate.regions.find((r) => r.id === 'sel2') || {}).strict === 0,
      diffCreate && !diffCreate.error ? diffCreate.regions : diffCreate,
      { sel2Strict: 0 }, { level: 'P1' });
    addCheck('B8', '源图层像素未被调整层修改（非破坏）',
      b.created.sourceLayerUnchanged !== false && out.cases.B.sourceLayerUnchanged === true,
      { sourceLayerUnchanged: out.cases.B.sourceLayerUnchanged }, { sourceLayerUnchanged: true }, { level: 'P1' });
    await shot(page, 't117-B-create.png');

    /* ---------- A3：已存在 mask 的调整层重开 modal ---------- */
    st = await openAdjustModal(page);
    const a3Sliders = await q.sliders(page);
    out.cases.A3 = { modal: st.modal, sliders: a3Sliders };
    addCheck('A3', '已有 mask 的调整层重开 modal：checkbox 默认勾选（且有选区时可用）',
      st.modal.checked === true && st.modal.disabled === false && !!a3Sliders && a3Sliders.checked === true,
      { modal: st.modal, sliders: a3Sliders }, { checked: true, disabled: false }, { level: 'P1' });
    await closeAdjustModal(page);

    /* ---------- C：更新（改参数 + 移动选区） ---------- */
    await setSelection(page, SEL2);
    st = await openAdjustModal(page);
    const cPrefill = await q.sliders(page);
    await setSliderValues(page, { brightness: 40, contrast: 10, saturation: 8, hue: 5 });
    await clickApplyWait(page, 'update');
    const cUpdated = await q.state(page);
    const cAfterUrl = await q.grab(page);
    const cMask = cUpdated.adjustId ? await q.mask(page, cUpdated.adjustId) : null;
    const diffC_vs_src = await q.diff(page, srcUrl, cAfterUrl, [{ id: 'sel2', ...SEL2 }]);
    const diffC_vs_created = await q.diff(page, b.afterUrl, cAfterUrl, [{ id: 'sel1', ...SEL1 }, { id: 'sel2', ...SEL2 }]);
    // 重开预填（更新后）
    st = await openAdjustModal(page);
    const cReopen = await q.sliders(page);
    await closeAdjustModal(page);
    out.cases.C = {
      prefillBeforeUpdate: cPrefill, updated: pickState(cUpdated), mask: cMask,
      diff_vs_source: diffC_vs_src, diff_vs_created: diffC_vs_created, reopen: cReopen,
    };
    const cAdj = cUpdated.adjustLayers[0] && cUpdated.adjustLayers[0].adjust;
    const cUpdateRecs = cUpdated.adjustRecords.filter((r) => r.action === 'update');
    const cUpdateRec = cUpdateRecs[cUpdateRecs.length - 1] || null;
    addCheck('C1', '更新不新增图层（层数不变、adjustId 不变）',
      cUpdated.layers === b.created.layers && cUpdated.adjustId === b.created.adjustId,
      { layers: cUpdated.layers, adjustId: cUpdated.adjustId, before: { layers: b.created.layers, adjustId: b.created.adjustId } },
      { layers: b.created.layers, adjustId: b.created.adjustId }, { level: 'P1' });
    addCheck('C2', '更新参数生效（brightness=0.40）',
      !!cAdj && cAdj.brightness === 0.40 && cAdj.contrast === 0.10,
      cAdj, { brightness: 0.40, contrast: 0.10 }, { level: 'P1' });
    addCheck('C3', 'mask 跟随当前选区（bbox=选区 2）',
      cUpdated.maskExists === true && cUpdated.maskTiles > 0 && !!cMask && JSON.stringify(cMask.bbox) === JSON.stringify([SEL2.x, SEL2.y, SEL2.width, SEL2.height]),
      { maskExists: cUpdated.maskExists, maskTiles: cUpdated.maskTiles, mask: cMask },
      { maskExists: true, bbox: [SEL2.x, SEL2.y, SEL2.width, SEL2.height] }, { level: 'P1' });
    addCheck('C4', 'L6 update 记录 params.masked=true',
      !!cUpdateRec && cUpdateRec.masked === true && cUpdateRec.action === 'update' && cUpdateRec.valid === true,
      cUpdateRec, { action: 'update', masked: true, valid: true }, { level: 'P1' });
    addCheck('C5', '选区移到别处后：新选区外恢复原图（整幅合成 vs 初始源图，新选区外 strict diff=0）',
      diffC_vs_src && !diffC_vs_src.error && diffC_vs_src.outside.strict === 0,
      diffC_vs_src, { outsideStrict: 0 }, { level: 'P1' });
    addCheck('C6', '新选区内确实有调整变化（vs 初始源图，选区 2 可见差异 > 0）',
      diffC_vs_src && !diffC_vs_src.error && (diffC_vs_src.regions.find((r) => r.id === 'sel2') || {}).visible > 0,
      diffC_vs_src, { sel2Visible: '> 0' }, { level: 'P1' });
    addCheck('C7', '重开 modal 预填正确（更新前 brightness=25、更新后=40，checkbox 保持勾选）',
      !!cPrefill && cPrefill.brightness === 25 && cPrefill.checked === true && !!cReopen && cReopen.brightness === 40 && cReopen.checked === true,
      { before: cPrefill, after: cReopen }, { beforeBrightness: 25, afterBrightness: 40, checked: true }, { level: 'P1' });
    addCheck('C8', '更新时旧选区已恢复（选区 1 相对创建后画面可见差异 > 0）',
      diffC_vs_created && !diffC_vs_created.error && (diffC_vs_created.regions.find((r) => r.id === 'sel1') || {}).visible > 0,
      diffC_vs_created, { sel1Visible: '> 0' }, { level: 'P1' });
    await shot(page, 't117-C-update.png');

    /* ---------- D：取消勾选（重点怀疑项） ---------- */
    st = await openAdjustModal(page);
    await setMaskChecked(page, false);
    await setSliderValues(page, { brightness: 30, contrast: 10, saturation: 8, hue: 5 });
    const dBeforeUncheckUrl = await q.grab(page);
    await clickApplyWait(page, 'update');
    const dAfter = await q.state(page);
    const dAfterUrl = await q.grab(page);
    const dMask = dAfter.adjustId ? await q.mask(page, dAfter.adjustId) : null;
    const dLatestRecs = dAfter.adjustRecords.filter((r) => r.action === 'update');
    const dLatestRec = dLatestRecs[dLatestRecs.length - 1] || null;
    const diffD_vs_src = await q.diff(page, srcUrl, dAfterUrl, [{ id: 'sel1', ...SEL1 }, { id: 'sel2', ...SEL2 }]);
    const diffD_uncheck_vs_before = await q.diff(page, dBeforeUncheckUrl, dAfterUrl, [{ id: 'sel1', ...SEL1 }, { id: 'sel2', ...SEL2 }]);
    out.cases.D = {
      modalAtOpen: st.modal, after: pickState(dAfter), mask: dMask, latestRecord: dLatestRec,
      diff_vs_source: diffD_vs_src, diff_uncheck_vs_before: diffD_uncheck_vs_before,
    };
    addCheck('D1', '取消勾选后应用：mask 被移除（mask.exists=false）',
      dAfter.maskExists === false, { maskExists: dAfter.maskExists, maskTiles: dAfter.maskTiles, mask: dMask }, { maskExists: false }, { level: 'P1' });
    addCheck('D2', '取消勾选后 mask tiles 清空（maskTiles=0）',
      dAfter.maskTiles === 0, { maskTiles: dAfter.maskTiles }, { maskTiles: 0 }, { level: 'P1' });
    addCheck('D3', '取消勾选后 L6 记录与实际 mask 状态一致（记录 masked=false 时应无 mask）',
      !(dLatestRec && dLatestRec.masked === false && dAfter.maskExists === true),
      { recordMasked: dLatestRec && dLatestRec.masked, maskExists: dAfter.maskExists, record: dLatestRec },
      { recordMasked: false, maskExists: false }, { level: 'P1' });
    addCheck('D4', '取消勾选后画面不再受旧选区限制（选区 1 内容 vs 初始源图应变化）',
      diffD_vs_src && !diffD_vs_src.error && (diffD_vs_src.regions.find((r) => r.id === 'sel1') || {}).visible > 0,
      diffD_vs_src, { sel1Visible: '> 0' }, { level: 'P1' });
    addCheck('D5', '取消勾选后旧选区外仍被限制（选区 1 无变化 => 仍被旧 mask 限制）——反向证据',
      diffD_vs_src && !diffD_vs_src.error && (diffD_vs_src.regions.find((r) => r.id === 'sel1') || {}).strict === 0,
      diffD_vs_src, { sel1StrictWhenMaskStillExists: 0 }, { level: 'P1', note: '与 D4 互斥；用于证明 D1 缺陷的画面后果' });
    await shot(page, 't117-D-uncheck.png');

    /* ---------- F：保存 / 加载 ---------- */
    const json = await page.evaluate(() => window.__V2_APP__.engine.serializeDoc());
    const parsed = JSON.parse(json);
    const docAdjust = (parsed.doc.layers || []).find((l) => l.kind === 'adjust') || null;
    const maskKeys = Object.keys(parsed.masks || {});
    const beforeSaveUrl = await q.grab(page);
    const saveState = await q.state(page);
    await page.evaluate(async (text) => { await window.__V2_APP__.t61.loadProjectText(text); }, json);
    await page.waitForTimeout(900);
    const loaded = await q.state(page);
    const loadedMask = loaded.adjustId ? await q.mask(page, loaded.adjustId) : null;
    const afterLoadUrl = await q.grab(page);
    const diffF = await q.diff(page, beforeSaveUrl, afterLoadUrl, []);
    // 说明：serializeDoc→deserializeDoc 走 tile PNG 重编码，可能有极少量 ±1 噪声；
    // 真正要求是“可见差异为 0”（mask/参数/像素结构未变）。F5 前显式选中调整层：
    // 当前引擎 doc.activeLayerId 不随 addLayer/setActiveLayer 同步（既有行为），加载后默认选中的是图层 2。
    const loadedActiveBeforeSelect = loaded.activeLayerId;
    if (loaded.adjustId) await page.evaluate((id) => { window.__V2_APP__.engine.setActiveLayer(id); }, loaded.adjustId);
    st = await openAdjustModal(page);
    const fReopen = await q.sliders(page);
    await closeAdjustModal(page);
    out.cases.F = {
      serializeBytes: json.length,
      docAdjust,
      maskKeys,
      maskTilesByLayer: Object.fromEntries(maskKeys.map((k) => [k, Object.keys(parsed.masks[k] || {}).length])),
      beforeSave: { adjustId: saveState.adjustId, maskExists: saveState.maskExists, maskTiles: saveState.maskTiles },
      loaded: pickState(loaded),
      loadedActiveBeforeSelect,
      loadedMask,
      diffRoundtrip: diffF,
      reopen: fReopen,
    };
    addCheck('F1', 'serializeDoc 中含 kind=adjust 图层与 masks 数据',
      !!docAdjust && maskKeys.length > 0 && Object.keys(parsed.masks[docAdjust.id] || {}).length > 0,
      { docAdjustId: docAdjust && docAdjust.id, adjust: docAdjust && docAdjust.adjust, maskKeys, maskTilesByLayer: out.cases.F.maskTilesByLayer },
      { hasAdjust: true, hasMasks: true }, { level: 'P1' });
    addCheck('F2', 'loadProjectText 后调整层、参数、mask.exists/maskTiles 保留',
      loaded.layers === saveState.layers && loaded.adjustLayers.length === 1 && !!loaded.adjustLayers[0].adjust && loaded.adjustLayers[0].adjust.brightness === 0.30
      && loaded.maskExists === true && loaded.maskTiles > 0 && loaded.maskTiles === saveState.maskTiles,
      { layers: loaded.layers, adjust: loaded.adjustLayers[0] && loaded.adjustLayers[0].adjust, maskExists: loaded.maskExists, maskTiles: loaded.maskTiles, before: { layers: saveState.layers, maskTiles: saveState.maskTiles } },
      { layers: saveState.layers, brightness: 0.30, maskExists: true, maskTiles: saveState.maskTiles }, { level: 'P1' });
    addCheck('F3', '加载后 mask 白色区域仍等于最后选区（bbox=选区 2）',
      !!loadedMask && JSON.stringify(loadedMask.bbox) === JSON.stringify([SEL2.x, SEL2.y, SEL2.width, SEL2.height]),
      loadedMask, { bbox: [SEL2.x, SEL2.y, SEL2.width, SEL2.height] }, { level: 'P1' });
    addCheck('F4', '加载前后整幅合成一致（可见差异=0；允许 tile PNG 重编码的极少量 ±1 噪声）',
      diffF && !diffF.error && diffF.all.visible === 0 && diffF.all.maxDelta <= 2,
      diffF, { visible: 0, maxDelta: '<= 2' }, { level: 'P1', note: 'strict 噪声来自 tile PNG 序列化往返，非 mask 语义变化' });
    addCheck('F5', '加载后选中调整层重开 modal：预填 brightness=30 且 mask 默认勾选（无选区时 disabled）',
      !!fReopen && fReopen.brightness === 30 && fReopen.checked === true && fReopen.disabled === true,
      { reopen: fReopen, loadedActiveBeforeSelect }, { brightness: 30, checked: true, disabled: true }, { level: 'P1' });
    await shot(page, 't117-F-roundtrip.png');

    /* ---------- H：Mock / 密钥 / 前端扫描 ---------- */
    const security = await page.evaluate(async () => {
      const a = window.__V2_APP__;
      const ai = a.t96.getState();
      const ls = {};
      for (let i = 0; i < localStorage.length; i += 1) { const k = localStorage.key(i); ls[k] = String(localStorage.getItem(k) || '').slice(0, 300); }
      const ss = {};
      for (let i = 0; i < sessionStorage.length; i += 1) { const k = sessionStorage.key(i); ss[k] = String(sessionStorage.getItem(k) || '').slice(0, 300); }
      const patterns = {
        openai_sk: /sk-[A-Za-z0-9_-]{12,}/,
        bearer: /Bearer\s+[A-Za-z0-9._-]{12,}/,
        api_key_assign: /(?:api[_-]?key|apiKey|secret[_-]?key)\s*[:=]\s*['"][^'"]{8,}['"]/i,
        google: /AIza[0-9A-Za-z_-]{20,}/,
        github: /gh[pousr]_[A-Za-z0-9]{20,}/,
      };
      const hits = [];
      const scan = (label, text) => {
        if (!text) return;
        for (const [kind, re] of Object.entries(patterns)) {
          if (re.test(text)) hits.push({ label, kind });
        }
      };
      const html = document.documentElement.innerHTML;
      scan('dom', html);
      scan('localStorage', JSON.stringify(ls));
      scan('sessionStorage', JSON.stringify(ss));
      const srcs = [...document.querySelectorAll('script[src]')].map((s) => s.src).filter((s) => s.startsWith(location.origin));
      const scanned = [];
      for (const src of srcs) {
        try {
          const res = await fetch(src);
          const text = await res.text();
          scanned.push({ src, bytes: text.length });
          scan(src, text);
        } catch (e) {
          scanned.push({ src, error: String(e).slice(0, 150) });
        }
      }
      return {
        ai, localStorageKeys: Object.keys(ls), localStorage: ls, sessionStorageKeys: Object.keys(ss),
        scriptSrcs: srcs, scriptsScanned: scanned, keyHits: hits,
        domMentionsTokenFile: /\.ai-token|\.ai-config\.json/.test(html),
      };
    });
    out.cases.mainSecurity = security;
    addCheck('H3', 'Mock 模式且未配置 key（hasKey=false / realEligible=false / preset=mock）',
      security.ai && security.ai.hasKey === false && security.ai.realEligible === false && security.ai.preset === 'mock',
      { ai: security.ai }, { hasKey: false, realEligible: false, preset: 'mock' }, { level: 'P1' });
    addCheck('H4', '前端（DOM/LS/SS/已加载脚本）无明文密钥命中',
      security.keyHits.length === 0,
      { keyHits: security.keyHits, domMentionsTokenFile: security.domMentionsTokenFile, localStorageKeys: security.localStorageKeys, scriptsScanned: security.scriptsScanned },
      { keyHits: [] }, { level: 'P1', note: 'DOM 中 “v2/.ai-config.json” 仅出现在 license 说明文字里，不是密钥' });
  } catch (e) {
    recordError('main', e);
  } finally {
    await page.close().catch(() => {});
  }
}

/* ======================================================================
 * E-更新：参数 + 像素 undo 恢复；mask 是否随 undo 一并恢复
 * ==================================================================== */
async function runUpdateUndoPage() {
  const page = await newTrackedPage('update-undo');
  out.cases.E_update = {};
  try {
    await gotoReady(page, URL_APP);
    await drawTestStrokes(page);
    const b = await createMaskedAdjust(page, { sel: SEL1, brightness: 20 });
    const adjustId = b.created.adjustId;
    const createdRawUrl = await page.evaluate((id) => window.__QA__.rawLayerUrl(id), adjustId);
    // 更新：参数 20 -> 45，选区 SEL1 -> SEL2
    await setSelection(page, SEL2);
    const info = await openAdjustModal(page);
    await setSliderValues(page, { brightness: 45, contrast: 0, saturation: 0, hue: 0 });
    await clickApplyWait(page, 'update');
    const updated = await q.state(page);
    const updatedUrl = await q.grab(page);
    const updatedMask = updated.adjustId ? await q.mask(page, updated.adjustId) : null;
    const updatedRawUrl = await page.evaluate((id) => window.__QA__.rawLayerUrl(id), adjustId);
    // undo
    const undoRet = await page.evaluate(() => window.__V2_APP__.engine.undo());
    await page.waitForTimeout(700);
    const afterUndo = await q.state(page);
    const undoUrl = await q.grab(page);
    const undoMask = afterUndo.adjustId ? await q.mask(page, afterUndo.adjustId) : null;
    const undoRawUrl = await page.evaluate((id) => window.__QA__.rawLayerUrl(id), adjustId);
    // redo
    const redoRet = await page.evaluate(() => window.__V2_APP__.engine.redo());
    await page.waitForTimeout(700);
    const afterRedo = await q.state(page);
    const redoUrl = await q.grab(page);
    const redoMask = afterRedo.adjustId ? await q.mask(page, afterRedo.adjustId) : null;
    const redoRawUrl = await page.evaluate((id) => window.__QA__.rawLayerUrl(id), adjustId);
    const diffUndoVsCreated = await q.diff(page, b.afterUrl, undoUrl, [{ id: 'sel1', ...SEL1 }, { id: 'sel2', ...SEL2 }]);
    const diffRedoVsUpdated = await q.diff(page, updatedUrl, redoUrl, [{ id: 'sel1', ...SEL1 }, { id: 'sel2', ...SEL2 }]);
    const rawDiffUndoVsCreated = await q.diff(page, createdRawUrl, undoRawUrl, []);
    const rawDiffRedoVsUpdated = await q.diff(page, updatedRawUrl, redoRawUrl, []);
    out.cases.E_update = {
      created: pickState(b.created), createdMask: b.mask,
      modalAtOpen: info.modal,
      updated: pickState(updated), updatedMask,
      undoRet, redoRet,
      afterUndo: pickState(afterUndo), undoMask,
      afterRedo: pickState(afterRedo), redoMask,
      adjustPixels: {
        createdVsUpdatedEqual: createdRawUrl === updatedRawUrl,
        createdVsUndoEqual: createdRawUrl === undoRawUrl,
        rawDiffUndoVsCreated,
        rawDiffRedoVsUpdated,
      },
      diffUndoVsCreated, diffRedoVsUpdated,
    };
    addCheck('E-u1', '更新后 undo：调整参数恢复（45 -> 20）',
      afterUndo.adjustLayers[0] && afterUndo.adjustLayers[0].adjust && afterUndo.adjustLayers[0].adjust.brightness === 0.20,
      { undoRet, adjust: afterUndo.adjustLayers[0] && afterUndo.adjustLayers[0].adjust, undoDepth: afterUndo.undoDepth, redoDepth: afterUndo.redoDepth },
      { brightness: 0.20 }, { level: 'P1' });
    addCheck('E-u2', '更新后 undo：调整层原始像素恢复（剥离 mask 后逐像素 diff=0）',
      rawDiffUndoVsCreated && !rawDiffUndoVsCreated.error && rawDiffUndoVsCreated.all.strict === 0,
      rawDiffUndoVsCreated, { allStrict: 0 }, { level: 'P1', note: '用 _renderStoreLayerImage 直读 tile，不受 mask 影响' });
    addCheck('E-u3', '更新后 undo：mask 一并恢复（白色 bbox 回到选区 1）',
      !!undoMask && JSON.stringify(undoMask.bbox) === JSON.stringify([SEL1.x, SEL1.y, SEL1.width, SEL1.height]),
      { undoMask, expectedBBox: [SEL1.x, SEL1.y, SEL1.width, SEL1.height] }, { bbox: [SEL1.x, SEL1.y, SEL1.width, SEL1.height] }, { level: 'P1' });
    addCheck('E-u4', '更新后 undo：整幅画面回到「创建后」状态（strict diff=0）',
      diffUndoVsCreated && !diffUndoVsCreated.error && diffUndoVsCreated.all.strict === 0,
      diffUndoVsCreated, { allStrict: 0 }, { level: 'P1' });
    addCheck('E-u5', 'redo：参数恢复 45 且整幅画面回到「更新后」状态（strict diff=0）',
      afterRedo.adjustLayers[0] && afterRedo.adjustLayers[0].adjust && afterRedo.adjustLayers[0].adjust.brightness === 0.45
      && diffRedoVsUpdated && !diffRedoVsUpdated.error && diffRedoVsUpdated.all.strict === 0,
      { adjust: afterRedo.adjustLayers[0] && afterRedo.adjustLayers[0].adjust, diff: diffRedoVsUpdated, redoMask, rawDiffRedoVsUpdated }, { brightness: 0.45, allStrict: 0 }, { level: 'P1' });
    await shot(page, 't117-E-update-undo.png');
  } catch (e) {
    recordError('update-undo', e);
  } finally {
    await page.close().catch(() => {});
  }
}

/* ======================================================================
 * E-创建：undo 移除调整层；redo 恢复（重点检查像素/参数/mask）
 * ==================================================================== */
async function runCreateUndoPage() {
  const page = await newTrackedPage('create-undo');
  out.cases.E_create = {};
  try {
    await gotoReady(page, URL_APP);
    await drawTestStrokes(page);
    const beforeLayers = (await q.state(page)).layers;
    await setSelection(page, SEL1);
    const beforeUrl = await q.grab(page);
    const b = await createMaskedAdjust(page, { sel: SEL1, brightness: 20 });
    const adjustId = b.created.adjustId;
    // undo（创建）
    const undoRet = await page.evaluate(() => window.__V2_APP__.engine.undo());
    await page.waitForTimeout(800);
    const afterUndo = await q.state(page);
    const undoUrl = await q.grab(page);
    const undoMaskTiles = await page.evaluate((id) => window.__V2_APP__.engine.maskStore.listTiles(id).length, adjustId);
    // redo（创建）
    const redoRet = await page.evaluate(() => window.__V2_APP__.engine.redo());
    await page.waitForTimeout(800);
    const afterRedo = await q.state(page);
    const redoUrl = await q.grab(page);
    const redoMask = afterRedo.adjustId ? await q.mask(page, afterRedo.adjustId) : null;
    const diffUndoVsBefore = await q.diff(page, beforeUrl, undoUrl, []);
    const diffRedoVsCreated = await q.diff(page, b.afterUrl, redoUrl, [{ id: 'sel1', ...SEL1 }]);
    out.cases.E_create = {
      beforeLayers, created: pickState(b.created), createdMask: b.mask,
      undoRet, redoRet,
      afterUndo: pickState(afterUndo), undoMaskTiles,
      afterRedo: pickState(afterRedo), redoMask,
      diffUndoVsBefore, diffRedoVsCreated,
    };
    addCheck('E-c1', '创建后 undo：调整层消失（层数回到创建前，无 adjust 层）',
      afterUndo.layers === beforeLayers && afterUndo.adjustLayers.length === 0,
      { layers: afterUndo.layers, adjustLayers: afterUndo.adjustLayers.length, beforeLayers },
      { layers: beforeLayers, adjustLayers: 0 }, { level: 'P1' });
    addCheck('E-c2', '创建后 undo：画面回到创建前（strict diff=0）',
      diffUndoVsBefore && !diffUndoVsBefore.error && diffUndoVsBefore.all.strict === 0,
      diffUndoVsBefore, { allStrict: 0 }, { level: 'P1' });
    addCheck('E-c3', '创建后 redo：调整层恢复（层数 +1 且 kind=adjust）',
      afterRedo.layers === beforeLayers + 1 && afterRedo.adjustLayers.length === 1 && afterRedo.adjustLayers[0].kind === 'adjust',
      { layers: afterRedo.layers, adjustLayers: afterRedo.adjustLayers },
      { layers: beforeLayers + 1, adjustLayers: 1, kind: 'adjust' }, { level: 'P1' });
    addCheck('E-c4', '创建后 redo：参数恢复（brightness=0.20）',
      !!afterRedo.adjustLayers[0] && !!afterRedo.adjustLayers[0].adjust && afterRedo.adjustLayers[0].adjust.brightness === 0.20,
      { adjust: afterRedo.adjustLayers[0] && afterRedo.adjustLayers[0].adjust },
      { brightness: 0.20 }, { level: 'P1' });
    addCheck('E-c5', '创建后 redo：mask 恢复（exists=true、tiles>0、bbox=选区 1）',
      afterRedo.maskExists === true && afterRedo.maskTiles > 0 && !!redoMask && JSON.stringify(redoMask.bbox) === JSON.stringify([SEL1.x, SEL1.y, SEL1.width, SEL1.height]),
      { maskExists: afterRedo.maskExists, maskTiles: afterRedo.maskTiles, redoMask },
      { maskExists: true, bbox: [SEL1.x, SEL1.y, SEL1.width, SEL1.height] }, { level: 'P1' });
    addCheck('E-c6', '创建后 redo：画面恢复为创建后（strict diff=0）',
      diffRedoVsCreated && !diffRedoVsCreated.error && diffRedoVsCreated.all.strict === 0,
      diffRedoVsCreated, { allStrict: 0 }, { level: 'P1' });
    await shot(page, 't117-E-create-redo.png');

    /* ---------- 对照：无 mask 的调整层同样 undo/redo（界定缺陷归属） ---------- */
    let control = null;
    try {
      await page.goto(`${URL_APP}?new=1`, { waitUntil: 'domcontentloaded', timeout: 60000 });
      await page.waitForFunction('window.__V2_APP_READY__ === true', null, { timeout: 60000 });
      await page.waitForTimeout(1200);
      await page.evaluate(installPageHelpers);
      await drawTestStrokes(page);
      await setSelection(page, null);
      await openAdjustModal(page);
      await setSliderValues(page, { brightness: 20, contrast: 0, saturation: 0, hue: 0 });
      await clickApplyWait(page, 'create');
      const mCreated = await q.state(page);
      const mCreatedRaw = mCreated.adjustId ? await page.evaluate((id) => window.__QA__.rawLayerUrl(id), mCreated.adjustId) : null;
      await page.evaluate(() => window.__V2_APP__.engine.undo());
      await page.waitForTimeout(500);
      const mUndo = await q.state(page);
      await page.evaluate(() => window.__V2_APP__.engine.redo());
      await page.waitForTimeout(600);
      const mRedo = await q.state(page);
      const mRedoRaw = mRedo.adjustId ? await page.evaluate((id) => window.__QA__.rawLayerUrl(id), mRedo.adjustId) : null;
      const rawDiff = mCreatedRaw && mRedoRaw ? await q.diff(page, mCreatedRaw, mRedoRaw, []) : null;
      control = {
        created: pickState(mCreated),
        afterUndo: { layers: mUndo.layers, adjustLayers: mUndo.adjustLayers.length },
        afterRedo: pickState(mRedo),
        rawDiffRedoVsCreated: rawDiff,
      };
    } catch (e) {
      control = { error: String((e && e.message) || e).slice(0, 600) };
    }
    out.cases.E_create.control = control;
    out.observations.push({
      id: 'O1',
      title: '对照（无 mask）：调整层创建后 undo/redo 是否恢复像素/参数/kind',
      data: control,
      note: '用于界定 E-c3~E-c6 是否 T117 引入；若同样失败，说明根因在通用“新建图层”结构 undo（addLayer 时拍快照，像素随后写入）。',
    });
  } catch (e) {
    recordError('create-undo', e);
  } finally {
    await page.close().catch(() => {});
  }
}

/* ======================================================================
 * G：4096×4096 性能
 * ==================================================================== */
async function run4096Page() {
  const page = await newTrackedPage('perf-4096');
  out.cases.G = {};
  try {
    const url = `${URL_APP}?new=1&w=4096&h=4096`;
    await gotoReady(page, url, 90000);
    const st0 = await q.state(page);
    out.cases.G.doc = { width: st0.width, height: st0.height, layers: st0.layers };
    const sel = { x: 1024, y: 768, width: 1536, height: 1024 };
    await setSelection(page, sel);
    const info = await openAdjustModal(page);
    out.cases.G.modalAtOpen = info.modal;
    await setMaskChecked(page, true);
    await setSliderValues(page, { brightness: 20, contrast: 0, saturation: 0, hue: 0 });
    await page.evaluate(() => {
      window.__PERF__ = { t0: performance.now(), longtasks: [], ltError: null };
      try {
        window.__PERF_OBS__ = new PerformanceObserver((list) => {
          for (const e of list.getEntries()) window.__PERF__.longtasks.push(Math.round(e.duration));
        });
        window.__PERF_OBS__.observe({ entryTypes: ['longtask'] });
      } catch (e) { window.__PERF__.ltError = String(e); }
    });
    await page.click('#btnAdjustApply');
    await page.waitForFunction(() => {
      const a = window.__V2_APP__;
      const l = a.engine.getLayers().find((x) => x.kind === 'adjust');
      return !!(l && l.mask && l.mask.exists && a.engine.maskStore.listTiles(l.id).length > 0
        && a.state.records.some((r) => r.kind === 'adjust_layer' && r.params && r.params.action === 'create'));
    }, null, { timeout: 240000 });
    await page.evaluate(() => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))));
    const perf = await page.evaluate(() => {
      const p = window.__PERF__ || { longtasks: [] };
      const lts = p.longtasks || [];
      return {
        e2eMs: Math.round(performance.now() - p.t0),
        longtaskCount: lts.length,
        longtaskMaxMs: lts.length ? Math.max(...lts) : 0,
        longtaskTotalMs: lts.reduce((a, b) => a + b, 0),
        longtasks: lts.slice(0, 200),
        ltError: p.ltError || null,
      };
    });
    const created = await q.state(page);
    const direct = await page.evaluate(async () => {
      const a = window.__V2_APP__;
      const e = a.engine;
      const l = e.getLayers().find((x) => x.kind === 'adjust') || e.getLayers()[e.getLayers().length - 1];
      const build = () => {
        const c = document.createElement('canvas');
        c.width = e.width; c.height = e.height;
        const g = c.getContext('2d');
        g.clearRect(0, 0, c.width, c.height);
        g.fillStyle = '#fff';
        g.fillRect(1024, 768, 1536, 1024);
        return c.toDataURL('image/png');
      };
      const tBuild0 = performance.now();
      const maskUrl = build();
      const buildMs = performance.now() - tBuild0;
      const t1 = performance.now();
      await e.setMaskFromDataUrl(l.id, maskUrl);
      const write1 = performance.now() - t1;
      const t2 = performance.now();
      await e.setMaskFromDataUrl(l.id, maskUrl);
      const write2 = performance.now() - t2;
      return {
        buildMs: Math.round(buildMs * 10) / 10,
        maskWriteMs: [Math.round(write1 * 10) / 10, Math.round(write2 * 10) / 10],
        maskTiles: e.maskStore.listTiles(l.id).length,
        maskExists: !!(e.getLayers().find((x) => x.id === l.id).mask || {}).exists,
        size: [e.width, e.height],
        stats: (() => { const s = e.getStats(); return { memoryEstimateMB: s.memoryEstimateMB, tileCount: s.tileCount, undoDepth: s.undoDepth }; })(),
      };
    });
    out.cases.G = {
      doc: out.cases.G.doc, modalAtOpen: out.cases.G.modalAtOpen,
      created: pickState(created),
      maskTiles: created.maskTiles,
      maskExists: created.maskExists,
      applyE2E: perf,
      directMaskWrite: direct,
    };
    addCheck('G1', '4096×4096：有选区 + 勾选可成功创建调整层并写入 mask（无异常）',
      created.adjustLayers.length === 1 && created.maskExists === true && created.maskTiles > 0,
      { layers: created.layers, maskExists: created.maskExists, maskTiles: created.maskTiles, doc: out.cases.G.doc },
      { maskExists: true, maskTiles: '> 0' }, { level: 'P1' });
    addCheck('G2', '4096×4096：mask 写入耗时 ≤ 2000ms（直接 setMaskFromDataUrl 计时）',
      direct.maskWriteMs.every((ms) => ms <= 2000),
      direct, { maskWriteMs: '<= 2000 per run' }, { level: 'P2' });
    addCheck('G3', '4096×4096：按钮应用端到端未明显冻结（e2e < 10s 且最长 longtask < 2000ms）',
      perf.e2eMs < 10000 && perf.longtaskMaxMs < 2000,
      { e2eMs: perf.e2eMs, longtaskMaxMs: perf.longtaskMaxMs, longtaskCount: perf.longtaskCount, longtaskTotalMs: perf.longtaskTotalMs },
      { e2eMs: '< 10000', longtaskMaxMs: '< 2000' }, { level: 'P2' });
    await shot(page, 't117-G-4096.png');
  } catch (e) {
    recordError('perf-4096', e);
  } finally {
    await page.close().catch(() => {});
  }
}

/* ======================================================================
 * 汇总 / 收尾
 * ==================================================================== */
function finalizeChecks() {
  addCheck('H1', '全程 0 console error（过滤 favicon/401 资源噪声）且 0 pageerror',
    out.consoleErrors.length === 0 && out.pageErrors.length === 0,
    { consoleErrors: out.consoleErrors, pageErrors: out.pageErrors, pages: Object.fromEntries(Object.entries(out.pages).map(([k, v]) => [k, { consoleErrorCount: v.consoleErrors.length, consoleWarningCount: v.consoleWarnings.length, pageErrorCount: v.pageErrors.length, responses4xx5xx: v.responses.length, requestFailed: v.requestFailed.length }])) },
    { consoleErrors: 0, pageErrors: 0 }, { level: 'P1' });
  addCheck('H2', '无外部/AI 网络请求，无 .ai-token/.ai-config 请求（Mock 本地运行）',
    out.network.external.length === 0 && out.network.tokenRequests.length === 0,
    { external: out.network.external, tokenRequests: out.network.tokenRequests },
    { external: 0, tokenRequests: 0 }, { level: 'P1' });
  addCheck('H5', '浏览器已 close、临时 python 静态服务已 kill（端口释放）',
    browserClosed === true && out.env.serverStopped === true,
    { browserClosed, serverStopped: out.env.serverStopped }, { browserClosed: true, serverStopped: true }, { level: 'P1' });
}

function portOpen(port) {
  return new Promise((resolve) => {
    const sock = net.connect({ port, host: '127.0.0.1' });
    const done = (v) => { try { sock.destroy(); } catch (e) { /* ignore */ } resolve(v); };
    sock.setTimeout(1200);
    sock.once('connect', () => done(true));
    sock.once('timeout', () => done(false));
    sock.once('error', () => done(false));
  });
}

async function startServer() {
  py = spawn('python', ['-m', 'http.server', String(PORT), '--bind', '127.0.0.1'], { cwd: ROOT, stdio: 'ignore', windowsHide: true });
  py.on('error', (e) => recordError('python-spawn', e));
  for (let i = 0; i < 80; i += 1) {
    await sleep(150);
    if (await portOpen(PORT)) {
      await sleep(400);
      return;
    }
  }
  throw new Error(`python http.server 未能在 127.0.0.1:${PORT} 就绪`);
}

async function main() {
  fs.mkdirSync(SHOTS, { recursive: true });
  await startServer();
  browser = await chromium.launch({
    channel: 'msedge',
    headless: true,
    args: ['--enable-gpu', '--use-angle=d3d11', '--ignore-gpu-blocklist'],
  });
  await runMainPage();
  await runUpdateUndoPage();
  await runCreateUndoPage();
  await run4096Page();
}

function summarize() {
  const failed = out.checks.filter((c) => !c.pass);
  out.summary = {
    totalChecks: out.checks.length,
    passed: out.checks.length - failed.length,
    failed: failed.length,
    failedChecks: failed.map((c) => ({ id: c.id, title: c.title, actual: c.actual, expected: c.expected })),
    consoleErrorCount: out.consoleErrors.length,
    pageErrorCount: out.pageErrors.length,
    externalRequests: out.network.external.length,
    tokenRequests: out.network.tokenRequests.length,
    errors: out.errors.length,
    browserClosed,
    serverStopped: !!out.env.serverStopped,
  };
  out.pass = out.errors.length === 0 && out.consoleErrors.length === 0 && out.pageErrors.length === 0 && failed.length === 0;
  out.finishedAt = new Date().toISOString();
}

(async () => {
  let exitCode = 3;
  try {
    await main();
    exitCode = 0;
  } catch (e) {
    recordError('main', e);
    exitCode = 3;
  } finally {
    try { if (browser) { await browser.close(); browserClosed = true; } } catch (e) { recordError('browser-close', e); }
    try { if (py) py.kill(); } catch (e) { recordError('python-kill', e); }
    await sleep(900);
    out.env.serverStopped = !(await portOpen(PORT));
    out.env.browserClosed = browserClosed;
    try {
      finalizeChecks();
      summarize();
    } catch (e) {
      recordError('finalize', e);
    }
    try {
      fs.writeFileSync(OUT_JSON, JSON.stringify(out, null, 2), 'utf8');
    } catch (e) {
      console.error('[T117-QA] 写结果 JSON 失败', e);
    }
    if (out.pass) exitCode = 0;
    else if (exitCode === 0) exitCode = 1;
    console.log(`[T117-QA] pass=${out.pass} checks=${out.checks.length} failed=${out.summary ? out.summary.failed : '?'} errors=${out.errors.length}`);
    if (out.summary) console.log(`[T117-QA] failed: ${(out.summary.failedChecks || []).map((c) => c.id).join(', ') || 'none'}`);
    process.exit(exitCode);
  }
})();
